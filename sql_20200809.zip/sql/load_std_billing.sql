-- findCsStandardBillingKeyForStandardPolicy--
SELECT serviceCatId
  ||'_'
  ||NVL(icd10Category,'null')
  ||'_'
  ||NVL(lengthOfStayCategory,'null')
  ||'_'
  ||NVL(procedureCategory,'null')
  ||'_'
  ||NVL(treatmentType,'null')
  ||'_'
  ||NVL(productCode,'null')
  ||'_'
  ||NVL(benefitCode,'null')
  ||'_'
  ||NVL(rolloverBenefitCode1,'null')
  ||'_'
  ||NVL(rolloverBenefitCode2,'null')
  ||'_'
  ||NVL(rolloverBenefitCode3,'null')
  ||'_'
  ||NVL(rolloverBenefitCode4,'null')
  ||'_'
  ||NVL(rolloverBenefitCode5,'null') AS KEY
FROM StandardBilling 
WHERE businessLine = 'CS'
AND companyId      = '051'
AND policyNo      IS NULL
AND planId         = 0;
/* key --
StringBuilder text = new StringBuilder(90);
			text.append(serviceCatId);
			text.append('_');
			text.append(icd10Category);
			text.append('_');
			text.append(lengthOfStayCategory);
			text.append('_');
			text.append(procedureCategory);
			text.append('_');
			text.append(treatmentType);
			text.append('_');
			text.append(productCode);
excel			
1_Accident_null_null_4_null=
new 
1_Maternity_null_null_5_null=

"1.1.5(2)(12)_Accident_Admit LE 31 days_Major_2_30111"
*/
SELECT *
FROM StandardBilling 
WHERE businessLine = 'CS'
AND companyId      = '051'
AND policyNo      = ''
order by serviceCatId, treatmentType, icd10Category, procedureCategory;
AND policyNo      IS NULL;

select  SERVICECATID||'_'||nvl(icd10Category,'null')||'_'||nvl(lengthOfStayCategory,'null')||'_'||nvl(procedureCategory,'null')
||'_'||nvl(treatmentType,'null')||'_'||nvl(productCode,'null')
from STANDARDBILLING where policyno = '00000R0002' and SERVICECATID = '1.1.1(1)' and ICD10CATEGORY = 'Healthcheck' 
and productcode = '30100';
--1.1.1(1)_Healthcheck_null_Intermediate_5_30100
INTERMEDIATE
Intermediate
(Dialysis)