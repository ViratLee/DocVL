SELECT a.*,
  rownum
FROM
  (SELECT *
  FROM
    (SELECT crl.CLAIMRULESLOGID ,
      crl.claimno,
      crl.OCCURRENCE ,
      cp.SETTLEMENTDATE ,
      crl.POLICYNO ,
      p.PLANNAME ,
      crl.RULENO,
      crl.REASON ,
      cp.APPROVEDAMT    AS amount,
      cp.LASTMODIFIEDBY AS approval ,
      crl.RULEREVIEWDECISION ,
      crl.RULEREVIEWACTION ,
      CASE
        WHEN crl.RULEREVIEWER ='SYSTEM'
        THEN ''
        ELSE crl.RULEREVIEWER
      END          AS reviewer ,
      RULEREVIEWDT AS LASTMODIFIEDDT
    FROM CLAIMRULESLOG crl
    LEFT OUTER JOIN plan p
    ON crl.PLANID = p.PLANID
    INNER JOIN claimpayment cp
    ON crl.CLAIMNO          = cp.claimno
    AND crl.OCCURRENCE      = cp.OCCURRENCE
    AND crl.POLICYNO        = cp.POLICYNO
    AND crl.PLANID          = cp.PLANID
    WHERE cp.PAYMENTSTATUS IN ('50','65','70')
    AND cp.ELIGIBILITY      = 10
    AND cp.APPROVEDAMT      > 0
    --AND crl.ruleno LIKE :ruleno
    --AND TO_CHAR(crl.lastmodifieddt,'MM/dd/yyyy') = :lastUpdateDate
	AND crl.ruleno LIKE '%R0031%'
	AND TO_CHAR(crl.lastmodifieddt,'MM/dd/yyyy') = '05/31/2018' 
    AND crl.claimno  IN
      (SELECT claimno
      FROM claimpayment
      --WHERE :dateStart <= SETTLEMENTDATE
      --AND :dateEnd     >= SETTLEMENTDATE
	  WHERE '05/01/2019' <= TO_CHAR(SETTLEMENTDATE,'MM/dd/yyyy')
	  AND '05/08/2019'   >= TO_CHAR(SETTLEMENTDATE,'MM/dd/yyyy')
      )
    UNION
    SELECT claim_level.*
    FROM
      (SELECT crl.CLAIMRULESLOGID ,
        crl.claimno,
        crl.OCCURRENCE ,
        (SELECT MAX(cp.SETTLEMENTDATE)
        FROM claimpayment cp
        WHERE cp.claimno  = crl.CLAIMNO
        AND cp.OCCURRENCE = crl.OCCURRENCE
        ) AS SETTLEMENTDATE ,
        crl.POLICYNO ,
        '' ,
        crl.RULENO,
        crl.REASON ,
        (SELECT SUM(cp.approvedamt)
        FROM claimpayment cp
        WHERE cp.claimno  = crl.CLAIMNO
        AND cp.OCCURRENCE = crl.OCCURRENCE
        )  AS amount,
        '' AS approval ,
        crl.RULEREVIEWDECISION ,
        crl.RULEREVIEWACTION ,
        CASE
          WHEN crl.RULEREVIEWER ='SYSTEM'
          THEN ''
          ELSE crl.RULEREVIEWER
        END          AS reviewer ,
        RULEREVIEWDT AS LASTMODIFIEDDT
      FROM CLAIMRULESLOG crl
      LEFT OUTER JOIN plan p
      ON crl.PLANID       = p.PLANID
      WHERE crl.policyno IS NULL
      --AND crl.ruleno LIKE :ruleno
      --AND TO_CHAR(crl.lastmodifieddt,'MM/dd/yyyy') = :lastUpdateDate
	  AND crl.ruleno LIKE '%R0031%'
	  AND TO_CHAR(crl.lastmodifieddt,'MM/dd/yyyy') = '05/31/2018' 
      AND crl.claimno                             IN
        (SELECT claimno
        FROM claimpayment
        --WHERE :dateStart <= SETTLEMENTDATE
        --AND :dateEnd     >= SETTLEMENTDATE
		WHERE '05/01/2019' <= TO_CHAR(SETTLEMENTDATE,'MM/dd/yyyy')
	    AND '05/08/2019'   >= TO_CHAR(SETTLEMENTDATE,'MM/dd/yyyy')
        )
      ) claim_level
    WHERE claim_level.amount > 0
    UNION
    SELECT policy_level.*
    FROM
      (SELECT crl.CLAIMRULESLOGID ,
        crl.claimno,
        crl.OCCURRENCE ,
        (SELECT MAX(cp.SETTLEMENTDATE)
        FROM claimpayment cp
        WHERE cp.claimno  = crl.CLAIMNO
        AND cp.OCCURRENCE = crl.OCCURRENCE
        AND cp.POLICYNO   = crl.POLICYNO
        ) AS SETTLEMENTDATE,
        crl.POLICYNO ,
        '' ,
        crl.RULENO,
        crl.REASON ,
        (SELECT SUM(cp.approvedamt)
        FROM claimpayment cp
        WHERE cp.claimno  = crl.CLAIMNO
        AND cp.OCCURRENCE = crl.OCCURRENCE
        AND cp.POLICYNO   = crl.POLICYNO
        )  AS amount,
        '' AS approval ,
        crl.RULEREVIEWDECISION ,
        crl.RULEREVIEWACTION ,
        CASE
          WHEN crl.RULEREVIEWER ='SYSTEM'
          THEN ''
          ELSE crl.RULEREVIEWER
        END          AS reviewer ,
        RULEREVIEWDT AS LASTMODIFIEDDT
      FROM CLAIMRULESLOG crl
      LEFT OUTER JOIN plan p
      ON crl.PLANID       = p.PLANID
      WHERE crl.policyno IS NOT NULL
      AND crl.planid      = 0
      --AND crl.ruleno LIKE :ruleno
      --AND TO_CHAR(crl.lastmodifieddt,'MM/dd/yyyy') = :lastUpdateDate
	  AND crl.ruleno LIKE '%R0031%'
	  AND TO_CHAR(crl.lastmodifieddt,'MM/dd/yyyy') = '05/31/2018' 
	  AND crl.claimno                             IN
        (SELECT claimno
        FROM claimpayment
        --WHERE :dateStart <= SETTLEMENTDATE
        --AND :dateEnd     >= SETTLEMENTDATE
		WHERE '05/01/2019' <= TO_CHAR(SETTLEMENTDATE,'MM/dd/yyyy')
	    AND '05/08/2019'   >= TO_CHAR(SETTLEMENTDATE,'MM/dd/yyyy')
        )
      ) policy_level
    WHERE policy_level.amount > 0
    )
  ORDER BY SETTLEMENTDATE,
    claimno,
    OCCURRENCE,
    NVL(POLICYNO,'T000000000'),
    PLANNAME
  ) a