select claimno, occurrence, claimstatus, BILLINGSTATUS, BILLINGDECLINEREASON from claim where claimno = 'C000126077';
select claimpaymentid, claimno,OCCURRENCE,paymentstatus,
policyno, planid, SYSTEMELIGIBILITY, ELIGIBILITY,ELIGIBLEAMT, APPROVEDAMT, ADJUSTEDAMT  
from claimpayment where CLAIMNO = 'C000126077' and occurrence = 2;  
select claimno, occurrence,cycledate, TRANSACTIONAMT, TRANSACTIONDT, lastmodifieddt from mclworking where claimno = 'C000126077' and occurrence = 2;
select claimno, POLICYNO, occurrence, pabonusdeductamt from claimpolicy where claimno = 'C000126077' and occurrence = 2;

select * from plan where planid = 243;


