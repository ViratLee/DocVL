select claimid, claimno, occurrence,claimstatus, processstatus, ACCIDENTDT, SYMPTOMDATE, DISABILITYSTARTDT, DISABILITYENDDT, HOSPITALIZATIONDATE, CONSULTATIONDT 
from claim where claimno = 'C000005536';

select currentCycleDt from CycleDate where trim(upper(applicationName)) =  'BCLAIMS';
select caseid, claimno,claimstatus,claimstatusdt, DOUBLEINDEMNITY, MAJORINJURYDETAIL from claim where claimno = 'C000003400';
select claimpaymentid, claimno,OCCURRENCE,paymentstatus,SETTLEMENTDATE,
policyno, planid, SYSTEMELIGIBILITY, ELIGIBILITY,ELIGIBLEAMT, APPROVEDAMT, ADJUSTEDAMT 
from claimpayment where CLAIMNO = 'C000003400';

select * from claimpaymentdetail where CLAIMNO = 'C000005536';
select distinct a.benefitItemCode from BenefitItem a,PlanBenefit b 
where a.benefitItemCode=b.benefitItemCode and b.planId=174 and a.hsBenefitInd='N';

select * from BenefitItem; --where planid = 174;
select * from PlanBenefit where planid = 174;
-------------------insert script sql to systemconfig table -----------------------------
Insert into SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT)
values ('cmic.editclaim.enable','Y','wMUser',(CURRENT_TIMESTAMP),
'wMUser',(CURRENT_TIMESTAMP));
------------------------------------------------

‘Y’ = show edit claim button.
‘N’   = hide edit claim button

--------- edit claim --
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT)
values ('cmic.editclaim.enable','N','wMUser',(CURRENT_TIMESTAMP),
'wMUser',(CURRENT_TIMESTAMP));

update MAPPCMIC.SYSTEMCONFIG 
set PARAMVALUE = 'Y'
where PARAMKEY = 'cmic.editclaim.enable';


--  
select caseid, claimno,claimstatus, DOUBLEINDEMNITY, MAJORINJURYDETAIL from claim where claimno = 'C000003400';

update claimpayment
set settlementdate = (select currentCycleDt from CycleDate where trim(upper(applicationName)) =  'BCLAIMS')
where CLAIMNO = 'C000005698' and PAYMENTSTATUS = '91';

update claim 
set claimstatus = '65', claimstatusdt = to_timestamp('31-JAN-17 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM')
where claimno = 'C000003156';

to_timestamp('28-NOV-17 09.44.43.108000000 AM','DD-MON-RR HH.MI.SSXFF AM')

select myCycleDate.currentCycleDt from CycleDate myCycleDate where trim(upper(myCycleDate.applicationName)) =  'BCLAIMS';

update claim 
set claimstatus = '91', claimstatusdt = current_timestamp
where claimno = 'C000004450' and caseid = 1054385 ;

update claim 
set claimstatus = '91', claimstatusdt = current_timestamp
where claimno = 'C000005259'; 

select claimno, occurrence, claimstatus, claimstatusdt from claim where claimstatus in('91','95') and claimno like 'C00000%' order by claimno desc;