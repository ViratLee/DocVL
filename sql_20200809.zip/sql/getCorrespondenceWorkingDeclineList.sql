
select corr.*, claim.CLAIMSTATUSDT, claim.CLAIMNO ,
claim.OCCURRENCE ,claim.CERTNO ,claim.CASEID ,claim.ACCIDENTDT ,claim.HOSPITALIZATIONDATE,claim.DISCHARGEDATE ,claim.LASTMODIFIEDBY ,cp.SETTLEMENTDATE , cp.PLANID ,p.PLANSHORTNAME ,p.PLANTHAIDESC ,cp.POLICYNO PAYMENTPOLICYNO ,cp.DECLINEREASON ,provider.PROVIDERREGNAMETHAI PROVIDERNAMETHAI ,claim.RECEIVEDDATE ,cc.CODEDESCLONGTHAI , payee.CITY ,payee.STATE , cc2.codedesc statename , payee.postalcode ,claim.RECEIVEDDATE as CLAIMRECEIVEDDATE  
from CORRESPONDENCEWORKING corr 
 ,claim claim ,claimpayment cp ,plan p ,PROVIDER provider ,commoncode cc , payee payee ,commoncode cc2 
where to_char(corr.CREATEDDT,'MM/DD/YYYY') =  '03/21/2019'
and corr.formid =  'DCLM_NC' 
and claim.CLAIMID = corr.CLAIMID  
and cp.planid = p.planid 
and claim.claimno = cp.CLAIMNO and claim.OCCURRENCE = cp.OCCURRENCE and corr.POLICYNO = cp.POLICYNO and corr.PLANSHORTNAME = p.PLANSHORTNAME 
and provider.PROVIDERCODE = claim.PROVIDERCODE 
and cc.CODEVALUE = cp.DECLINEREASON 
and cc.CODENAME = 'DeclineReason'  
and payee.CLAIMNO = claim.claimno and payee.OCCURRENCE = claim.OCCURRENCE and payee.POLICYNO = corr.POLICYNO 
and payee.state = cc2.codevalue and cc2.category = 'State' and cc2.codename = 'State' 
AND corr.policyno = 'T211446071'
order by claim.CLAIMNO,claim.OCCURRENCE ,corr.POLICYNO, cp.POLICYNO ,cp.planid;