-------------update 2020/02/20---------------------------------------------------------------------------
--level 1-w/ PolicyNo and ProductCode
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND policyNo              =?2
AND productCode           = ?3
AND treatmentType         =?4
AND icd10Category         =?5
AND ( procedureCategory   =?6
OR (?6                    IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?7
OR (lengthOfStayCategory IS NULL))
AND businessLine          =?8
AND benefitCode          IS NOT NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' );
---- level 2-w/ PolicyNo 
SELECT FROM StandardBilling 
WHERE serviceCatId        =?1
AND policyNo              =?2
AND productCode          IS NULL
AND treatmentType         =?3
AND icd10Category         =?4
AND ( procedureCategory   =?5
OR (?5                    IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?6
OR (?6                   IS NULL
AND lengthOfStayCategory IS NULL))
AND businessLine          =?7
AND benefitCode          IS NOT NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' );
---- level 3-w/ productCode
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND productCode           = ?2
AND treatmentType         =?3
AND icd10Category         =?4
AND ( procedureCategory   =?5
OR (?5                   IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?6
OR (lengthOfStayCategory IS NULL ))
AND businessLine          =?7
AND benefitCode          IS NOT NULL
AND policyNo             IS NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' );
---- level 4-w/out PolicyNo and ProductCode
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND treatmentType         =?2
AND icd10Category         =?3
AND ( procedureCategory   =?4
OR (?4                   IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?5
OR (?5                   IS NULL
AND lengthOfStayCategory IS NULL))
AND businessLine          =?6
AND benefitCode          IS NOT NULL
AND policyNo             IS NULL
AND productCode          IS NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' );

-------------update 2020/02/10---------------------------------------------------------------------------
--level 1-w/ PolicyNo and ProductCode
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND policyNo              =?2
AND productCode           = ?3
AND treatmentType         =?4
AND icd10Category         =?5
AND ( procedureCategory   =?6
OR (?6        IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?7
OR (lengthOfStayCategory IS NULL))
AND businessLine          =?8
AND benefitCode          IS NOT NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' );

---- level 2-w/ ProductCode 
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND productCode           =?2
AND treatmentType         =?3
AND icd10Category         =?4
AND ( procedureCategory   =?5
OR (?5 IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?6
OR (?6 IS NULL
AND lengthOfStayCategory IS NULL))
AND businessLine          =?7
AND benefitCode          IS NOT NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' );
---- level 3-w/ PolicyNo 
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND policyNo              = ?2
AND treatmentType         =?3
AND icd10Category         =?4
AND ( procedureCategory   =?5
OR (?5  IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?6
OR (lengthOfStayCategory IS NULL ))
AND businessLine          =?7
AND benefitCode          IS NOT NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N'
AND productCode          IS NULL);
---- level 4-w/out PolicyNo and ProductCode
SELECT * FROM StandardBilling 
WHERE serviceCatId        =?1
AND treatmentType         =?2
AND icd10Category         =?3
AND ( procedureCategory   =?4
OR (?4 IS NULL
AND procedureCategory    IS NULL))
AND ( lengthOfStayCategory=?5
OR (?5 IS NULL
AND lengthOfStayCategory IS NULL))
AND businessLine          =?6
AND benefitCode          IS NOT NULL
AND policyNo             IS NULL
AND productCode          IS NULL
AND ( followUpInd        IS NULL
OR followUpInd            ='N' )

--------example of level 2
SELECT myStandardBilling.*
FROM StandardBilling myStandardBilling
WHERE myStandardBilling.serviceCatId        = '1.2.2'
AND myStandardBilling.policyNo              = '0000010848'
AND myStandardBilling.treatmentType         = '2'
AND myStandardBilling.icd10Category         = 'Others Illness'
AND ( myStandardBilling.procedureCategory   = 'Intermediate'
OR ('Intermediate'                           IS NULL
AND myStandardBilling.procedureCategory    IS NULL))
AND ( myStandardBilling.lengthOfStayCategory= 'Admit LE 31 days'
OR ('Admit LE 31 days'                        IS NULL
AND myStandardBilling.lengthOfStayCategory IS NULL))
AND myStandardBilling.businessLine          = 'CS'
AND myStandardBilling.benefitCode          IS NOT NULL
AND ( myStandardBilling.followUpInd        IS NULL
OR myStandardBilling.followUpInd            ='N' );


SELECT myStandardBilling
FROM StandardBilling myStandardBilling
WHERE myStandardBilling.serviceCatId        = '1.1.1(2)'
AND myStandardBilling.treatmentType         = '2'
AND myStandardBilling.icd10Category         = 'Accident'
AND ( myStandardBilling.procedureCategory   =?4
OR (?4                                     IS NULL
AND myStandardBilling.procedureCategory    IS NULL))
AND ( myStandardBilling.lengthOfStayCategory=?5
OR (?5                                     IS NULL
AND myStandardBilling.lengthOfStayCategory IS NULL))
AND myStandardBilling.businessLine          =?6
AND myStandardBilling.benefitCode          IS NOT NULL
AND myStandardBilling.policyNo             IS NULL
AND myStandardBilling.productCode          IS NULL
AND ( myStandardBilling.followUpInd        IS NULL
OR myStandardBilling.followUpInd            ='N' );



SELECT myStandardBilling.*
FROM StandardBilling myStandardBilling
WHERE myStandardBilling.serviceCatId        = '1.1.1(2)'
AND myStandardBilling.treatmentType         = '2'
AND myStandardBilling.icd10Category         in('Accident','Others Illness')
AND ( myStandardBilling.procedureCategory   = 'Intermediate'
OR ( 'Intermediate'                         IS NULL
AND myStandardBilling.procedureCategory    IS NULL))
AND ( myStandardBilling.lengthOfStayCategory= 'Admit LE 31 days'
OR ('Admit LE 31 days'                                     IS NULL
AND myStandardBilling.lengthOfStayCategory IS NULL))
AND myStandardBilling.businessLine          = 'CS'
AND myStandardBilling.benefitCode          IS NOT NULL
AND myStandardBilling.policyNo             IS NULL
AND myStandardBilling.productCode          IS NULL
AND ( myStandardBilling.followUpInd        IS NULL
OR myStandardBilling.followUpInd            ='N' );





