select cpm.POLICYNO ,(select cp.CHEQUENO from claimPolicy cp where cp.claimno = cpm.claimno 
and  cp.occurrence = cpm.occurrence and cp.policyno = cpm.policyno ) as CHEQUENO ,
TOOLKIT.decrypt(p.BANKACCOUNTNO,'1234567812345678') bankaccno ,p.BANKCODE,
TOOLKIT.decrypt(p.FIRSTNAME,'1234567812345678') payeef,
TOOLKIT.decrypt(p.LASTNAME,'1234567812345678') payeel,
cpm.settlementdate , cc.codedesc bankname, cpm.payeeType payeetype 
from payee p 
left join claimpayment cpm 
on p.CLAIMNO = cpm.CLAIMNO  
and p.OCCURRENCE = cpm.OCCURRENCE  
and p.POLICYNO = cpm.POLICYNO  
left join commoncode cc on cc.category = 'Common' and cc.codename = 'BankCode' and cc.codevalue = p.bankcode  
where p.claimno = 'C000015911 '
and p.OCCURRENCE = 1
and p.payeeType = cpm.payeeType and p.payeeType != 'P' 
and cpm.settlementdate is not null 
order by cpm.settlementdate asc, CHEQUENO asc, 
bankaccno asc,p.BANKCODE asc,concat(payeef,payeel) asc,cpm.POLICYNO asc ;