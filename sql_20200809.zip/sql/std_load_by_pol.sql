-- standard , policyNo is null
SELECT serviceCatId
  ||'_'
  ||NVL(icd10Category,'null')
  ||'_'
  ||NVL(lengthOfStayCategory,'null')
  ||'_'
  ||NVL(procedureCategory,'null')
  ||'_'
  ||NVL(treatmentType,'null')
  ||'_'
  ||NVL(productCode,'null')
  ||'_'
  ||NVL(benefitCode,'null')
  ||'_'
  ||NVL(rolloverBenefitCode1,'null')
  ||'_'
  ||NVL(rolloverBenefitCode2,'null')
  ||'_'
  ||NVL(rolloverBenefitCode3,'null')
  ||'_'
  ||NVL(rolloverBenefitCode4,'null')
  ||'_'
  ||NVL(rolloverBenefitCode5,'null') AS KEY
FROM StandardBilling 
WHERE businessLine = 'CS'
AND companyId      = '051'
AND policyNo      IS NULL
AND PLANID = 0
and SERVICECATID = '2.6.6' and icd10Category = 'Healthcheck' 
and procedureCategory = 'Intermediate' and TREATMENTTYPE = '5' and productCode = '30112';
---------- by policyNo 
SELECT serviceCatId
  ||'_'
  ||NVL(icd10Category,'null')
  ||'_'
  ||NVL(lengthOfStayCategory,'null')
  ||'_'
  ||NVL(procedureCategory,'null')
  ||'_'
  ||NVL(treatmentType,'null')
  ||'_'
  ||NVL(productCode,'null')
  ||'_'
  ||NVL(benefitCode,'null')
  ||'_'
  ||NVL(rolloverBenefitCode1,'null')
  ||'_'
  ||NVL(rolloverBenefitCode2,'null')
  ||'_'
  ||NVL(rolloverBenefitCode3,'null')
  ||'_'
  ||NVL(rolloverBenefitCode4,'null')
  ||'_'
  ||NVL(rolloverBenefitCode5,'null') AS KEY
FROM StandardBilling 
WHERE businessLine = 'CS'
AND companyId      = '051'
AND policyNo      = '00000R0002'
and SERVICECATID = '2.6.6' and icd10Category = 'Healthcheck' 
and procedureCategory = 'Intermediate' and TREATMENTTYPE = '5' and productCode = '30112';
--------------