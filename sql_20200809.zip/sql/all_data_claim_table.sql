select * from claimpolicy where CLAIMNO = 'C000017225';
select * from CLAIMPOLICYPLAN where CLAIMNO = 'C000017225';
select * from CLAIMPOLICYCOVERAGE where CLAIMNO = 'C000017225';
select * from claimpayment where CLAIMNO = 'C000017225';
select * from CLAIMPAYMENTDETAIL where CLAIMNO = 'C000017225';
select * from FSUWORKING where CLAIMNO = 'C000017225';