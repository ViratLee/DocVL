--"findEligiblePlans"
select a.claimNo as claimNo,a.companyId as companyId,a.occurrence as occurrence,a.policyNo as policyNo,
c.businessLine as businessLine,c.productCode as productCode,b.fullCreditInd as fullCreditInd,
b.csProductCategory as csProductCategory,a.planId as planId,a.planCoverageNo as planCoverageNo, 
a.productType as productType, b.paBonusAmt as paBonusAmt,b.paBonusDt as paBonusDt,b.productCode as csProductCode,
c.planName as planName,b.policyIssueDt as policyIssueDt 
from ClaimPayment a inner join ClaimPolicy b 
on a.claimNo = b.claimNo and a.occurrence = b.occurrence 
and a.policyNo = b.policyNo inner join Plan c on a.planId=c.planId 
where  a.companyId = '051' and  a.claimNo = 'C900000340' and a.occurrence=1 and 
( a.eligibility = '10' or ( trim(a.eligibility) is null and a.systemEligibility='10' ) )
 and a.paymentStatus in ('10','40');
		
		
--"findStandardBillingForOLBenefitCode",
select * from StandardBilling 
where serviceCatId='1.1.12'
--and ( lengthOfStayCategory like ?2 or ?2 is null or ?2='') 
and treatmentType='1' and icd10Category=?4 
and productCode=?5 and businessLine='OL';

select * from StandardBilling 
where serviceCatId='1.1.12'
--and ( lengthOfStayCategory like ?2 or ?2 is null or ?2='') 
--and treatmentType='1' and icd10Category=?4 
--and productCode=?5
 and businessLine='OL';
 
 
 	select * from StandardBilling 
	where serviceCatId=?1 and 
	( lengthOfStayCategory like ?2 or ?2 is null or ?2='')
	 and treatmentType=?3 and icd10Category=?4 
	 and productCode=?5 and businessLine='OL'
	 
[C000015782/1] s


--findStandardBillingForOLBenefitCode 
select * from StandardBilling 
where serviceCatId='1.2.1' and 
( lengthOfStayCategory like null or null is null or null='') 
and treatmentType='12' and icd10Category='Others Illness' 
and productCode='HSN7' and businessLine='OL';


--findStandardBillingForCSGEBenefitCodeLevel3
select * from StandardBilling where serviceCatId='1.1.1(1)' and  
productCode = '30100' and treatmentType=1 and icd10Category='Others Illness'
and ( procedureCategory=null or (null is null and procedureCategory is null)) 
and ( lengthOfStayCategory=null or (lengthOfStayCategory is null ))  
and businessLine='GE' 
and benefitCode is not null and policyNo is null 
and ( followUpInd is null or followUpInd ='N' )