SELECT COUNT(*) AS totalPrevCallAllocated
FROM
  ( SELECT DISTINCT cpd.companyId,
    cl.claimId
  FROM ClaimPaymentDetail cpd
  INNER JOIN Claim cl
  ON cpd.companyId  =cl.companyId
  AND cpd.claimNo   =cl.claimNo
  AND cpd.occurrence=cl.occurrence
  INNER JOIN ClaimPayment cp
  ON cpd.companyId                       =cp.companyId
  AND cpd.claimNo                        =cp.claimNo
  AND cpd.occurrence                     =cp.occurrence
  AND cpd.policyNo                       =cp.policyNo
  AND cpd.productCode                    =cp.productCode
  WHERE cpd.companyId                    = ?
  AND cl.claimStatus                    IN ('40', '50','65', '70')
  AND ( cl.deleteInd                     = 'N'
  OR cl.deleteInd                       IS NULL)
  AND cl.memberId                        = ?
  AND cpd.policyNo                       =?
  AND cpd.productCode                    =?
  AND cpd.planCoverageNo                IS NULL
  AND cpd.benefitCode                    =?
  AND ( ( TRUNC(cl.hospitalizationDate) >= ?
  AND TRUNC(cl.hospitalizationDate)     <=?)
  OR ( TRUNC(cl.accidentDt)             >=?
  AND TRUNC(cl.accidentDt)              <= ?) )
  AND cp.paymentStatus                  IN ('50', '70')
  AND cpd.presentedAmt                   >0
  AND cpd.eligibleAmt                    >0
  );