---------script for set seq ---  
-- 1. Get the max value from the table
-- 2. update/recreate the sequence
-- The script could look like this:
  declare
  maxval number;
begin
  select max(id) into maxval from <table_1>;
  execute immediate 'ALTER SEQUENCE <sequence_name_1> START WITH '|| maxval+1 ||';';

  select max(id) into maxval from <table_2>;
  execute immediate 'ALTER SEQUENCE <sequence_name_2> START WITH '|| maxval+1 ||';';
end;
/
--- end script --
  select * from all_sequences;
  
  REVOKE SELECT ON s_standardbilling FROM PUBLIC;
  ALTER SEQUENCE s_standardbilling  INCREMENT BY 999821;
  SELECT s_standardbilling.nextval  FROM dual;
  ALTER SEQUENCE s_standardbilling  INCREMENT BY 1;
  REVOKE SELECT ON s_standardbilling TO PUBLIC;