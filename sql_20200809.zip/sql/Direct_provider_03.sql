 select claimno, claimstatus, billingstatus from claim where claimno = 'C000002100'; 
 select * from claimpayment where claimpaymentid in (770174,770169);
 select * from claimcomment where CLAIMNO = 'C000002100';

 select CLAIMPAYMENTID,PROVIDERCODE,PROVIDERNAMETHAI,
sum(approvedAMT) as approvedAMT,
BILLDTFROM,PAYMENTTRANSFERDT,PAYMENTTRANSFERREMARK,CLAIMNO,OCCURRENCE,TREATMENTTYPE,
  SETTLEMENTDATE,NAME,INCIDENTDT, CLAIMNOCOMMENT,INVOICENUM from 
  (
 select '' as claimPaymentId, p.providerCode, p.providerNameThai, cp.approvedAMT,c.BILLDTFROM, 
 cp.paymentTransferDt, cp.paymentTransferRemark,cp.claimno,cp.occurrence ,c.billNo  as invoiceNum  , 
 case 
 when c.treatmentType in ('1', '2', '6', '7', '11', '12', '13') 
 then 'IPD'  
 when c.treatmentType = '5' 
 then 'OPD-Illness'   
 when c.treatmentType = '4' 
 then 'OPD-Accident'   
 else '' 
 end  as treatmentType
 , null as settlementDate , TOOLKIT.DECRYPT(c.firstName,'1234567812345678') || ' ' || TOOLKIT.DECRYPT(c.lastName,'1234567812345678') as name   , 
 case 
 when c.ACCIDENTDT is null 
 then c.HOSPITALIZATIONDATE 
 else c.ACCIDENTDT
 end as incidentDT   ,
 (select commentdetail from CLAIMCOMMENT cmt where c.claimno = cmt.claimno and c.occurrence = cmt.occurrence
        and seqno = (   
		select max(seqno) from CLAIMCOMMENT tmp  WHERE tmp.claimno = cmt.claimno
		and tmp.occurrence = cmt.occurrence and tmp.commenttype = '7' )
  ) as claimnocomment  
 --cp.PAYMENTTRANSFERREMARK  as remark    
 from claim c, claimpayment cp, provider p    
 where c.claimno = cp.claimno and c.occurrence = cp.occurrence and c.providercode = p.providercode and cp.payeetype = 'P'   
 and c.billingstatus = '10' and cp.paymentstatus = '70' and cp.approvedAMT > 0 
 and cp.paymentTransferDt is not null   
 and p.providerCode = '1001010001'
  )  
  group by CLAIMPAYMENTID, PROVIDERCODE, PROVIDERNAMETHAI,BILLDTFROM, PAYMENTTRANSFERDT, 
  PAYMENTTRANSFERREMARK,CLAIMNO,OCCURRENCE,TREATMENTTYPE,SETTLEMENTDATE,NAME,INCIDENTDT,CLAIMNOCOMMENT,INVOICENUM  
  order by NAME, BILLDTFROM, PROVIDERNAMETHAI, INVOICENUM, PROVIDERCODE, SETTLEMENTDATE, PAYMENTTRANSFERDT, TREATMENTTYPE;
  --		,(select commentdetail from CLAIMCOMMENT cmt where c.claimno = cmt.claimno and c.occurrence = cmt.occurrence and seqno = (   
--		  	select max(seqno) from CLAIMCOMMENT tmp  WHERE tmp.claimno = cmt.claimno and tmp.occurrence = cmt.occurrence)
--		 	) as remark 				
  
  -- claimcomment.commenttype = 7, last seqno.
  
  --select * from claimpayment where claimno in('C000002957','C000002918','C000004630','C000000797','C5599467');