select * from pendingcode where pendingcode like 'I%'; (customer)
select * from pendingcode where pendingcode like 'A%'; (agent)
select * from pendingcode where pendingcode like 'H%'; (Hospital) 
select * from pendingcode where pendingcode like 'E%'; (IE)
select * from pendingcode where pendingcode like 'O%'; (Other)

select * from PENDINGCODE
where pendingcode in (
select pendingcode from CLAIMREQUIREMENTINFO where claimno = 'C000015323'
);