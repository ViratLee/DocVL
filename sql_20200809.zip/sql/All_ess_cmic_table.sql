select claimid, caseid, claimno, occurrence, policyno, claimstatus, createddt, CREATEDBY
from claim order by CREATEDDT desc;
select * from claim where claimno = 'C000017492' and occurrence = 1; --CLAIM_C000017492_1
select * from CLAIMPOLICY where claimno = 'C000017492' and occurrence = 1; --CLAIMPOLICY_C000017492_1
select * from claimpayment where claimno = 'C000017492' and occurrence = 1; --claimpayment_C000017492_1
select * from CLAIMPOLICYPLAN where claimno = 'C000017492' and occurrence = 1; --CLAIMPOLICYPLAN_C000017492_1
select * from CLAIMPAYMENTDETAIL where claimno = 'C000017492' and occurrence = 1; --CLAIMPAYMENTDETAIL_C000017492_1
select * from CLAIMPOLICYCOVERAGE where claimno = 'C000017492' and occurrence = 1; --CLAIMPOLICYCOVERAGE_C000017492_1
select * from FSUWORKING where claimno = 'C000017492' and occurrence = 1; --FSUWORKING_C000017492_1
select * from CLAIMBENEFITITEM where claimno = 'C000017492' and occurrence = 1;--CLAIMBENEFITITEM_C000017492_1
select * from CLAIMSUPPLEMENT where claimno = 'C000017492' and occurrence = 1; --CLAIMSUPPLEMENT_C000017492_1

delete from CLAIMSUPPLEMENT where claimno = 'C900000549' and occurrence = 1; 
delete from CLAIMBENEFITITEM where claimno = 'C900000549' and occurrence = 1; 
delete from FSUWORKING where claimno = 'C900000549' and occurrence = 1; 
delete from CLAIMPOLICYCOVERAGE where claimno = 'C900000549' and occurrence = 1; 
delete from CLAIMPAYMENTDETAIL where claimno = 'C900000549' and occurrence = 1; 
delete from CLAIMPOLICYPLAN where claimno = 'C900000549' and occurrence = 1; 
delete from claimpayment where claimno = 'C900000549' and occurrence = 1; 
delete from CLAIMPOLICY where claimno = 'C900000549' and occurrence = 1; 
delete from claim where claimno = 'C900000549' and occurrence = 1; 


update claim
set processstatus = '30'
where claimid = 1224493;

claim_C006364838_1.sql
claimpolicy_C006364838_1.sql
claimpayment_C006364838_1.sql
claimpolicyplan_C006364838_1.sql
claimpaymentdetail_C006364838_1.sql
claimpolicycoverage_C006364838_1.sql
fsuworking_C006364838_1.sql
claimbenefititem_C006364838_1.sql
claimsupplement_C006364838_1.sql
-------------------------------
select claimno, occurrence, policyno, certno, memberid,dependentno, dependenttype, partyid, submissiontype, treatmenttype, CAUSEOFTREATMENT,
HOSPITALIZATIONDATE, ACCIDENTDT, FIRSTADMITDT
from claim where claimno = 'C006762105';
select claimno, occurrence, policyno, CERTNO, memberid, productcode from CLAIMPOLICY where claimno = 'C006762105' and occurrence = 1; 
select claimno, occurrence, policyno, planid, productcode from CLAIMPOLICYPLAN where claimno = 'C006762105' and occurrence = 1; --CLAIMPOLICYPLAN_C000017492_1
select claimno, occurrence, policyno, PLANCODE, planid, PLANCOVERAGENO, PRODUCTCODE, PRODUCTTYPE, ELIGIBILITY, ELIGIBLEAMT
from claimpayment where claimno = 'C006762105' and occurrence = 1;
select  claimno, occurrence, policyno, planid, productcode, BENEFITCODE, ACCUMULATORNO, sumcategory, SUMTIMEFRAME, PLANCOVERAGENO
from CLAIMPOLICYCOVERAGE where claimno = 'C006762105' and occurrence = 1; --CLAIMPOLICYCOVERAGE_C000017492_1
select claimno, occurrence, policyno, planid, productcode,PRODUCTTYPE, BENEFITCODE, PAYMENTSTATUS, ELIGIBLEAMT 
from CLAIMPAYMENTDETAIL where claimno = 'C006762105' and occurrence = 1; --CLAIMPAYMENTDETAIL_C000017492_1

C005493329

