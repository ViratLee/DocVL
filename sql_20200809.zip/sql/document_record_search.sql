SELECT DISTINCT c.claimid,
  c.batchno ,
  p.providerNameThai,
  p.providerCode,
  po.BUSINESSLINE,
  c.stpInd ,
  c.ediInd,
  cp.SETTLEMENTDATE ,
  cp.PAYMENTDATE ,
  cp.paymentTransferDt,
  cp.approvedAMT,
  c.RECEIVEDDOCDATE,
  c.DOCREMARK,
  c.RECEIVEDDOCMODIFIEDDT,
  cd.CURRENTCYCLEDT,
  CASE
    WHEN c.treatmentType IN ('1','2','6','7','11','12','13','14')
    THEN 'IPD'
    WHEN c.treatmentType = '5'
    THEN 'OPD-Illness'
    WHEN c.treatmentType = '4'
    THEN 'OPD-Accident'
    ELSE ''
  END AS treatmentType
FROM claim c,
  claimpayment cp,
  provider p ,
  claimpolicy po,
  cycledate cd
WHERE c.claimno       = cp.claimno
AND c.occurrence      = cp.occurrence
AND c.providercode    = p.providercode
AND c.policyno        = po.policyno
AND cp.claimno        = po.claimno
AND cp.occurrence     = po.occurrence
AND c.submissiontype  = 'Cashless'
AND cp.payeetype      = 'P'
AND cp.paymentstatus IN ('70','50' )
AND cp.approvedAMT    > 0
AND c.companyId       = '051'
AND c.claimno NOT LIKE 'Q%'
AND cd.APPLICATIONNAME LIKE 'bclaims%'
AND c.stpind         = 'Y'
AND c.ediind         = 'Y'
AND c.providerCode   = :providerCode
AND po.businessline IN ( 'CS')
AND cp.settlementdate BETWEEN :settlementStartDate AND :settlementEndDate
ORDER BY BATCHNO,
  PROVIDERCODE,
  TREATMENTTYPE,
  BUSINESSLINE,
  SETTLEMENTDATE,
  PAYMENTDATE,
  PAYMENTTRANSFERDT ;