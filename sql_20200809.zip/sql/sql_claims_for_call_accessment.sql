select c.claimno, c.occurrence, c.submissiontype, c.treatmenttype, c.createdby
from claim c
where CREATEDDT > = trunc(sysdate)
and c.claimno like 'C%'
and not exists (
  select 1
  from claimruleslog r
  where r.claimno = c.claimno
  and r.occurrence = c.occurrence)
and not exists (
  select 1
  from claim c2
  where c2.claimno = c.claimno
  and c2.occurrence = c.occurrence
  and c2.submissiontype = 'Cashless'
  and c2.treatmenttype = '4'
  and c2.createdby = 'bclm998');
  -- find is benefit rider exists ---
  select * from claimpayment where claimno = 'C000118143' and occurrence = 1;