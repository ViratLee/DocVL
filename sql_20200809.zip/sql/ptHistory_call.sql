select * from plan where productcode = 'HNW' order by planid desc;
select * from claimpolicyplan WHERE CLAIMNO = 'C000020185';
select * from claimpayment WHERE PLANID in (4150853,4150854);
select * from CLAIMPAYMENTDETAIL WHERE PLANID in (4150853,4150854) and BENEFITCODE in ('H29');
----------

 select planid, plancode, productcode, planname, planshortname from plan where productcode = 'HNW' order by planid desc;
select cpp.planid, (select planshortname from plan where planid = cpp.planid) as planshortname, 
policyno, POLICYYEARTODT, POLICYYEARFROMDT from claimpolicyplan cpp WHERE cpp.CLAIMNO = 'C000020185' and cpp.planid in 
 (select DISTINCT(planid) from plan where productcode = 'HNW');
 --Loop each planid
  select sum(noOfDaysAllocated) as noOfDaysAllocatedSum from CLAIMPAYMENTDETAIL-- WHERE CLAIMNO = 'C000020185' 
 where policyNo = 'T206016461' and planId = 4150854
 and BENEFITCODE in ('H29') and PAYMENTSTATUS in ('65','70');
 ----
  --'C000020239' and  occurrence = 2
  
  select sum(distinct(nvl(cpd.noOfDaysAllocated,0)) from ClaimPaymentDetail cpd, Claim cl 
  where  cl.claimStatus    IN ('50','65','70') and cpd.paymentStatus IN ('65','70')
  and  cpd.policyNo = 'T206016461' and cpd.planId = 4150854   and cpd.benefitCode='H29');
  
    @NamedQuery(name = "findH29TotalNoOfDaysAllocatedByPolicyNoPlanId", query = "select sum(nvl(cpd.noOfDaysAllocated,0))  from ClaimPaymentDetail cpd where cpd.policyNo = ?1 and cpd.planId = ?2 and cpd.paymentStatus in ('65','70') and  cpd.benefitCode = 'H29' "),
        @NamedQuery(name = "findClaimPaidH29TotalNoOfDaysAllocatedByPolicyNoPlanId", query = "select sum(distinct(nvl(cpd.noOfDaysAllocated,0))) from ClaimPaymentDetail cpd, Claim cl where and cpd.policyNo = ?1 and cpd.planId = ?2 and cl.claimStatus in ('50','65','70') and cpd.paymentStatus in ('65','70') and cpd.benefitCode='H29' ")})
-------------------------------------------------
select CLAIMPOLICYPLANID, claimno, occurrence, policyno, planid, POLICYYEARTODT, POLICYYEARFROMDT  
from claimpolicyplan where claimno = 'C000020185';

update claimpolicyplan
set POLICYYEARFROMDT = current_timestamp, POLICYYEARTODT = current_timestamp
where claimno = 'C000020185' and planid = 4150854;
