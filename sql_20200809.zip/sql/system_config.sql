Insert into SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.gpse.enable','N','wMUser',to_timestamp('25 �.�.  2019 15.25.21.000176000','DD MON RRRR HH24.MI.SSXFF'),
'wMUser',to_timestamp('25 �.�.  2019 15.25.21.000176000','DD MON RRRR HH24.MI.SSXFF'));
Insert into SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT)
values ('cmic.std.limit',100000,'wMUser',(CURRENT_TIMESTAMP),
'wMUser',(CURRENT_TIMESTAMP));
update systemconfig
set PARAMVALUE = REPLACE(PARAMVALUE,'localhost','thadcslwmi01')
where PARAMKEY like 'cmic.ods.endpoint%';
update systemconfig
set PARAMVALUE = '30000'
where PARAMKEY = 'cmic.std.limit';


Insert into SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT)
values ('cmic.std.limit',50000,'wMUser',(CURRENT_TIMESTAMP),'wMUser',(CURRENT_TIMESTAMP));
select * from systemconfig where paramkey = 'cmic.std.limit';

Insert into SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT)
values ('cmic.std.batch.size',3,'wMUser',(CURRENT_TIMESTAMP),'wMUser',(CURRENT_TIMESTAMP));

delete from SYSTEMCONFIG where paramkey = 'cmic.std.batch.size';

select * from  