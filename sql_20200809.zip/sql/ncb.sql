select * from provider where PROVIDERNAMETHAI like '%เจ้าพระยา%';
กรุงเทพ   - 1001010001
กรุงเทพระยอง - 1035010032
รามคำแหง
เกษมราษฎร์
สินแพทย์
บำรุงราษฎร์  - 1001240005
ศรีระยอง - 1035360011
ศุภมิตร - 1032360134
เจ้าพระยา
เขลางค์นครราม - 1084020002
กรุงเทพไชน่าทาวน์  
รพ.บางปะกอก 1 - 1001240006
1,228,960.45
12,407,791.2
92316.7
92125.7
C7548579/51

727
287
2294.90
1160 * 2
1001380003


สมิติเวชธนบุรี
414998.97

21/11 77108

2215547.87

select CYCLEDATE,sum(TRANSACTIONAMT)
 	from MCLWORKING m
 	where trunc(CYCLEDATE) between to_date('01/01/2018','MM/dd/yyyy') and  to_date('01/31/2018','MM/dd/yyyy') 
	and m.providercode = '1084020002' 
	and mcltarget = 'P' 
 	group by CYCLEDATE order by CYCLEDATE;
----------------------------------------
select claimno || '/' || OCCURRENCE, TRANSACTIONAMT
from MCLWORKING m
where trunc(CYCLEDATE) = to_date('02/22/2018','MM/dd/yyyy') and m.providercode = 'xxxxxxxxxx' and mcltarget = 'P' 
order by claimno || '/' || OCCURRENCE, TRANSACTIONAMT;
-----------
	     select c.claimno || '/' || c.OCCURRENCE, APPROVEDAMT
	     from claim c, claimpayment cp, provider p
	     where c.claimno = cp.claimno
	     and c.occurrence = cp.occurrence
	     and c.providercode = p.providercode
	     and cp.payeetype = 'P'
	     and c.billingstatus = '10'
	     and cp.paymentstatus = '70'
	     and trunc(cp.LASTMODIFIEDDT) = to_date('03/02/2018', 'MM/dd/yyyy') 	and c.PROVIDERCODE = 'xxxxxxxxxx'
	     and APPROVEDAMT > 0 
	     order by c.claimno || '/' || c.OCCURRENCE, APPROVEDAMT;
		 
-----------	 หรือ  ----------
		 
		 select c.claimno || '/' || c.OCCURRENCE, APPROVEDAMT
	     from claim c, claimpayment cp, provider p
	     where c.claimno = cp.claimno
	     and c.occurrence = cp.occurrence
	     and c.providercode = p.providercode
	     and cp.payeetype = 'P'
	     and c.billingstatus = '10'
	     and cp.paymentstatus = '70'
	     and trunc(cp.PAYMENTTRANSFERDT) = to_date('02/14/2018', 'MM/dd/yyyy') 
         and c.PROVIDERCODE = 'xxxxxxxxxx'
	     and APPROVEDAMT > 0 
	     order by c.claimno || '/' || c.OCCURRENCE, APPROVEDAMT;
		 
------------------------		 
    	  select  sum(APPROVEDAMT), c.PROVIDERCODE
	     from claim c, claimpayment cp, provider p
	     where c.claimno = cp.claimno
	     and c.occurrence = cp.occurrence
	     and c.providercode = p.providercode
	     and cp.payeetype = 'P'
	     and c.billingstatus = '10'
	     and cp.paymentstatus = '70'
	     and trunc(cp.PAYMENTTRANSFERDT) = to_date('01/18/2018', 'MM/dd/yyyy') 
         --and c.PROVIDERCODE = 'xxxxxxxxxx'
	     and APPROVEDAMT > 0 
	     group by c.PROVIDERCODE;
		 
		 select  sum(APPROVEDAMT), c.PROVIDERCODE
	     from claim c, claimpayment cp, provider p
	     where c.claimno = cp.claimno
	     and c.occurrence = cp.occurrence
	     and c.providercode = p.providercode
	     and cp.payeetype = 'P'
	     and c.billingstatus = '10'
	     and cp.paymentstatus = '70'
	     and trunc(cp.PAYMENTTRANSFERDT) = to_date('01/18/2018', 'MM/dd/yyyy') 
         and c.PROVIDERCODE in (select PROVIDERCODE from provider where PROVIDERNAMETHAI like '%บางปะกอก%')
	     and APPROVEDAMT > 0 
	     group by c.PROVIDERCODE;
		 

select m.claimno || '/' || m.OCCURRENCE, m.INSUREDFIRSTNAME, m.INSUREDLASTNAME,
  m.TRANSACTIONAMT, m.LASTMODIFIEDDT, c.CLAIMSTATUSDT 
from MCLWORKING m, claim c
where trunc(CYCLEDATE) = to_date('01/12/2018','MM/dd/yyyy') 
and m.providercode = '1001060001' 
and m.mcltarget = 'P' 
and m.claimno = c.claimno
and m.occurrence = c.occurrence 
order by m.claimno || '/' || m.OCCURRENCE, m.TRANSACTIONAMT;	


--------------FYR,----------------------------------------------
	select  paymentAmount , a.claimno , b.claimno , mclAmount
from(
select c.claimno || '/' || c.OCCURRENCE as claimno, sum(APPROVEDAMT ) as paymentAmount
from claim c, claimpayment cp, provider p
where c.claimno = cp.claimno
and c.occurrence = cp.occurrence
and c.providercode = p.providercode
and cp.payeetype = 'P'
and c.billingstatus = '10'
and cp.paymentstatus = '70'
and trunc(cp.LASTMODIFIEDDT) = to_date('01/16/2018', 'MM/dd/yyyy') 
and APPROVEDAMT > 0 
group by c.claimno || '/' || c.OCCURRENCE
) a full outer join (		
select claimno || '/' || OCCURRENCE as claimno , sum(TRANSACTIONAMT) as mclAmount	
from MCLWORKING m		
where trunc(CYCLEDATE) = to_date('01/16/2018','MM/dd/yyyy') and mcltarget = 'P' 		
group by claimno || '/' || OCCURRENCE		
) b on a.claimno = b.claimno
order by a.claimno

   
		 
		 
		 
		 
		 
		 
		
