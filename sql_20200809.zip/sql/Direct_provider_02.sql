select CLAIMPAYMENTID,PROVIDERCODE,PROVIDERNAMETHAI,
sum(approvedAMT) as approvedAMT,
BILLDTFROM,PAYMENTTRANSFERDT,PAYMENTTRANSFERREMARK,CLAIMNO,OCCURRENCE,TREATMENTTYPE,
  SETTLEMENTDATE,NAME,INCIDENTDT,REMARK,INVOICENUM from 
  (
 select '' as claimPaymentId, p.providerCode, p.providerNameThai, cp.approvedAMT,c.BILLDTFROM, 
 cp.paymentTransferDt, cp.paymentTransferRemark,cp.claimno,cp.occurrence ,c.billNo  as invoiceNum  , 
 case 
 when c.treatmentType in ('1', '2', '6', '7', '11', '12', '13') 
 then 'IPD'  
 when c.treatmentType = '5' 
 then 'OPD-Illness'   
 when c.treatmentType = '4' 
 then 'OPD-Accident'   
 else '' 
 end  as treatmentType
 , null as settlementDate , TOOLKIT.DECRYPT(c.firstName,'1234567812345678') || ' ' || TOOLKIT.DECRYPT(c.lastName,'1234567812345678') as name   , 
 case 
 when c.ACCIDENTDT is null 
 then c.HOSPITALIZATIONDATE 
 else c.ACCIDENTDT
 end as incidentDT   ,
 cp.PAYMENTTRANSFERREMARK  as remark    
 from claim c, claimpayment cp, provider p    
 where c.claimno = cp.claimno and c.occurrence = cp.occurrence and c.providercode = p.providercode and cp.payeetype = 'P'   
 and c.billingstatus = '10' and cp.paymentstatus = '70' and cp.approvedAMT > 0 
 and cp.paymentTransferDt is not null   
 and p.providerCode = '1001280005';
  )  
  group by CLAIMPAYMENTID, PROVIDERCODE, PROVIDERNAMETHAI,BILLDTFROM, PAYMENTTRANSFERDT, PAYMENTTRANSFERREMARK,CLAIMNO,OCCURRENCE,TREATMENTTYPE,SETTLEMENTDATE,NAME,INCIDENTDT,REMARK,INVOICENUM  order by PROVIDERCODE, SETTLEMENTDATE, PAYMENTTRANSFERDT, TREATMENTTYPE 
  
  
  
  -- claimcomment.commenttype = 7, last seqno.