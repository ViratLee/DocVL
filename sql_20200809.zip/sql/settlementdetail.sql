---------------for ol -------------------------
select distinct(policyno), businessline from claimpolicy 
where claimno = 'C000020680' and occurrence = 1
and companyid = '051' and businessline in ('OL','PA') 
order by policyno;
--loop each policyno from prvious policy list.--
select distinct(c.planid) as planid, c.plancoverageno as plancoverageno, c.producttype as producttype, 
(select p.planname from plan p where p.planid = c.planid) as planname 
from claimpaymentdetail c 
where  claimno = 'C000020680' and occurrence = 1 and companyid = '051'
and policyno = 'T206016445'
 order by planid;
 --- loop each planid from previous plan list
  -- query 1
 --with benefitItemTemp AS ( select benefititemcode,benefititemdesc from benefitItem where businessline = :businessline ) 
select g.companyid,g.benefitcode,g.claimpaymentdetailid,g.policyno,g.planid,g.plancoverageno--,g.benefititemdesc
,g.eligibleamt,g.allocatedamt, g.percentageallocated, g.noofdaysallocated,g.reimbursedday,g.presentedamt 
from 
( 
 select claimpaymentdetailid,claimno,occurrence,planid,plancoverageno,policyno,companyid, benefitcode, 
-- ( select benefititemdesc from benefitItemTemp where benefitItemTemp.benefititemcode = benefitcode 
--  ) as benefititemdesc, 
 eligibleamt, allocatedamt, percentageallocated, noofdaysallocated,reimbursedday,presentedamt FROM claimpaymentdetail 
 ) g 
 where 
 g.claimno = 'C000020680' and g.occurrence = 1 and g.companyid = '051' 
 and g.policyno = 'T206016445' and g.planid = 4150854 and g.plancoverageno = 02
 and g.eligibleamt > 0 order by g.benefitcode;
-- query 2
 --with benefitItemTemp as ( select benefititemcode,benefititemdesc from benefitItem where businessline = :businessline ) 
select claimpaymentdetailid, claimno, policyno, planid, producttype, benefitcode, 
 --( select benefititemdesc from benefitItemTemp where benefitItemTemp.benefititemcode = benefitcode 
 -- ) as benefititemdesc, 
    eligibleamt, plancoverageno, allocatedamt, percentageallocated, noofdaysallocated 
    reimbursedday, presentedamt 
    from claimpaymentdetail 
 where claimno = 'C000020680' and occurrence = 1 and policyno = 'T206016445' 
 and planid = 4150854 and plancoverageno = 02
 and eligibleamt =  0 and benefitcode like 'H%' 
 and producttype in ('HNW')
 and exists( 
     select 1 from claimpayment where claimno = 'C000020680'
        and occurrence = 1 and companyid = '051' and policyno = 'T206016445' and eligibility = '10'
   ) order by benefitcode;currence and companyid = :companyid and policyno = :policyno and eligibility = '10'
   ) order by benefitcode
 ---- combine query 1 & 2
 ---------------  
---------------for cs,ge -------------------------
select distinct(policyno), businessline from claimpolicy 
where claimno = 'C006364838' and occurrence = 1
and companyid = '051' and businessline in ('CS','GE') 
order by policyno;
--- loop by policyno from prrevious query. ---
SELECT cpp.productcode AS productcode,
  (SELECT p.productname FROM product p WHERE p.productcode = cpp.productcode
  ) AS productname
FROM claimpolicyplan cpp
WHERE cpp.claimno  = 'C006364838'
AND cpp.occurrence = 1
AND cpp.policyno   = '0000006652';
-- loop by productcode from previous query ---
select g.companyid,g.claimpaymentdetailid,g.policyno,g.eligibleamt,g.allocatedamt, 
  g.percentageallocated, g.noofdaysallocated,g.reimbursedday,g.presentedamt, 
  g.productcode as productcode, g.producttype as producttype, g.benefitcode as benefitcode, 
  b.benefititemdesc, g.shortfallamt 
from claimpaymentdetail g, benefitItem b  
where  g.claimno = 'C006364838' and g.occurrence = 1 and g.companyid = '051'
and g.policyno = '0000006652' and g.productcode = '31110' 
and g.eligibleamt > 0 
and b.businessline = 'GE'
and b.benefititemcode = g.benefitcode 
order by g.benefitcode;