-- "quotaionNo" : "Q000007754/1",  
select * from claimpayment where claimno = 'Q000007754';
select * from CLAIMRULESLOG where claimno = 'Q000007754' and decision <> '10'; --select by decsion is 93 get ruleno for rule
select * from rule where ruleno = 'R0067' ; -- // falsedecision is declined