SELECT distinct c.claimid, c.receiveddate  ,  max(cp.settlementdate) as settlementdate, cc.codedesc , 
c.claimno , c.policyno , c.certno , c.memberid , TOOLKIT.decrypt(c.firstname,'1234567812345678') , TOOLKIT.decrypt(c.lastname,'1234567812345678') ,
c.accidentdt , c.hospitalizationdate , p.PROVIDERNAMETHAI , c.submissiontype , cctt.codedesc as TREATMENTTYPE , 
c.LASTMODIFIEDBY , 
c.caseid ,c.OCCURRENCE ,cm2.seqno ,cm2.commentdetail ,c.DISCHARGEDATE ,c.LASTMODIFIEDDT 
from claim c 
left join provider p  on c.providercode = p.providercode 
left join claimpayment cp on c.claimno = cp.claimno  and c.OCCURRENCE = cp.OCCURRENCE 
left join COMMONCODE cc on cc.codevalue = c.claimstatus and cc.codename = 'ClaimStatus'
left join COMMONCODE cctt on cctt.codevalue = c.TREATMENTTYPE and cctt.codename = 'TreatmentType' 
left join (select CLAIMNO,OCCURRENCE ,MAX(SEQNO) seqno from claimcomment cm  
group by CLAIMNO,OCCURRENCE) cmm on cmm.CLAIMNO = c.CLAIMNO and cmm.OCCURRENCE = c.OCCURRENCE 
left join claimcomment cm2 on cm2.CLAIMNO = c.CLAIMNO and cm2.OCCURRENCE = c.OCCURRENCE and cm2.SEQNO = cmm.seqno 
WHERE 1=1 
and c.claimno = 'C000015000' 
group by c.claimid, c.receiveddate  , cc.codedesc , c.claimno , c.policyno , c.certno , c.memberid ,c.firstname, c.lastname , c.accidentdt , 
c.hospitalizationdate , p.PROVIDERNAMETHAI , c.submissiontype , cctt.codedesc , c.LASTMODIFIEDBY , c.caseid ,c.OCCURRENCE ,
cm2.seqno ,cm2.commentdetail ,c.DISCHARGEDATE ,c.LASTMODIFIEDDT
order by c.receiveddate desc;
--------------------------------

SELECT distinct c.claimid, c.receiveddate  ,  max(cp.settlementdate) as settlementdate, cc.codedesc , 
c.claimno , c.policyno , c.certno , c.memberid , TOOLKIT.decrypt(c.firstname,'1234567812345678') , TOOLKIT.decrypt(c.lastname,'1234567812345678') , 
c.accidentdt , c.hospitalizationdate , p.PROVIDERNAMETHAI , c.submissiontype , cctt.codedesc as TREATMENTTYPE , 
ccttt.codedesc as CAUSEOFTREATMENT, c.LASTMODIFIEDBY , 
c.caseid ,c.OCCURRENCE ,cm2.seqno ,cm2.commentdetail ,c.DISCHARGEDATE ,c.LASTMODIFIEDDT 
from claim c 
left join provider p  on c.providercode = p.providercode 
left join claimpayment cp on c.claimno = cp.claimno  and c.OCCURRENCE = cp.OCCURRENCE 
left join COMMONCODE cc on cc.codevalue = c.claimstatus and cc.codename = 'ClaimStatus'
left join COMMONCODE cctt on cctt.codevalue = c.TREATMENTTYPE and cctt.codename = 'TreatmentType' 
left join COMMONCODE ccttt on ccttt.codevalue = c.CAUSEOFTREATMENT and ccttt.codename = 'CauseOfTreatment' 
left join (select CLAIMNO,OCCURRENCE ,MAX(SEQNO) seqno from claimcomment cm  
group by CLAIMNO,OCCURRENCE) cmm on cmm.CLAIMNO = c.CLAIMNO and cmm.OCCURRENCE = c.OCCURRENCE 
left join claimcomment cm2 on cm2.CLAIMNO = c.CLAIMNO and cm2.OCCURRENCE = c.OCCURRENCE and cm2.SEQNO = cmm.seqno 
WHERE 1=1 
and c.claimno = 'C000015000' 
group by c.claimid, c.receiveddate  , cc.codedesc , c.claimno , c.policyno , c.certno , c.memberid ,c.firstname, c.lastname , c.accidentdt , 
c.hospitalizationdate , p.PROVIDERNAMETHAI , c.submissiontype , cctt.codedesc , ccttt.codedesc, c.LASTMODIFIEDBY , c.caseid ,c.OCCURRENCE ,
cm2.seqno ,cm2.commentdetail ,c.DISCHARGEDATE ,c.LASTMODIFIEDDT
order by c.receiveddate desc;
------------
SELECT DISTINCT c.claimid,
  c.receiveddate ,
  MAX(cp.settlementdate) AS settlementdate,
  cc.codedesc ,
  c.claimno ,
  c.policyno ,
  c.certno ,
  c.memberid ,
  TOOLKIT.decrypt(c.firstname,'1234567812345678'),
  TOOLKIT.decrypt(c.lastname,'1234567812345678'),
  c.accidentdt ,
  c.hospitalizationdate ,
  p.PROVIDERNAMETHAI ,
  c.submissiontype ,
  cctt.codedesc  AS TREATMENTTYPE ,
  ccttt.codedesc AS CAUSEOFTREATMENT ,
  c.LASTMODIFIEDBY ,
  c.caseid ,
  c.OCCURRENCE ,
  cm2.seqno ,
  cm2.commentdetail ,
  c.DISCHARGEDATE ,
  c.LASTMODIFIEDDT
FROM claim c
LEFT JOIN provider p
ON c.providercode = p.providercode
LEFT JOIN claimpayment cp
ON c.claimno     = cp.claimno
AND c.OCCURRENCE = cp.OCCURRENCE
LEFT JOIN COMMONCODE cc
ON cc.codevalue = c.claimstatus
AND cc.codename =  'ClaimStatus'
LEFT JOIN COMMONCODE cctt
ON cctt.codevalue = c.TREATMENTTYPE
AND cctt.codename = 'TreatmentType' 
LEFT JOIN COMMONCODE ccttt
ON ccttt.codevalue = c.CAUSEOFTREATMENT
AND ccttt.codename = 'CauseOfTreatment'
LEFT JOIN
  (SELECT CLAIMNO,
    OCCURRENCE ,
    MAX(SEQNO) seqno
  FROM claimcomment cm
  GROUP BY CLAIMNO,
    OCCURRENCE
  ) cmm
ON cmm.CLAIMNO     = c.CLAIMNO
AND cmm.OCCURRENCE = c.OCCURRENCE
LEFT JOIN claimcomment cm2
ON cm2.CLAIMNO     = c.CLAIMNO
AND cm2.OCCURRENCE = c.OCCURRENCE
AND cm2.SEQNO      = cmm.seqno
WHERE 1            =1
AND (c.deleteInd  IS NULL
OR c.deleteInd     = 'N')
AND c.certno       = '2012000019'
AND c.policyno     = '0000002996'
GROUP BY c.claimid,
  c.receiveddate ,
  cc.codedesc ,
  c.claimno ,
  c.policyno ,
  c.certno ,
  c.memberid ,
  c.firstname,
  c.lastname ,
  c.accidentdt ,
  c.hospitalizationdate ,
  p.PROVIDERNAMETHAI ,
  c.submissiontype ,
  cctt.codedesc ,
  ccttt.codedesc ,
  c.LASTMODIFIEDBY ,
  c.caseid ,
  c.OCCURRENCE ,
  cm2.seqno ,
  cm2.commentdetail ,
  c.DISCHARGEDATE ,
  c.LASTMODIFIEDDT
ORDER BY c.receiveddate DESC;