select distinct c.* 
			, cp.LASTMODIFIEDUSERDEPT 
			, cp.LASTMODIFIEDUSERDESK 
			, cp.PRODUCTCODE 
			, p.TITLE PAYEETITLE 
			, p.FIRSTNAME PAYEEFIRSTNAME 
			, p.LASTNAME PAYEELASTNAME 
			, p.ADDRESSLINE1 
			, p.ADDRESSLINE2 
			, p.ADDRESSLINE3 
			, p.ADDRESSLINE4 
			, p.BANKCODE 
			, i.TITLE INSUREDTITLE 
			, i.FIRSTNAME INSUREDFIRSTNAME 
			, i.LASTNAME INSUREDLASTNAME 
			, pl.PLANTHAIDESC 
			, cp.APPROVEDAMT 
			, pl.PLANSHORTNAME 
			, p.CITY 
			, p.STATE 
	--		, cc2.codedesc statename 
			, pl.plancode  
			,cp.policyno as claimpaymentpolicy 
			,cc.CODEDESC as claimpaymentdecline 
			from claim c 
			inner join CLAIMPAYMENT cp 
			on cp.CLAIMNO = c.CLAIMNO 
			and cp.OCCURRENCE = c.OCCURRENCE 
			left join commoncode cc 
			on cc.CODEVALUE = cp.DECLINEREASON 
			inner join payee p 
			on cp.CLAIMNO = p.CLAIMNO 
			and cp.OCCURRENCE = c.OCCURRENCE 
			AND cp.policyno   = p.policyno 
			inner join insured i 
			on cp.CLAIMNO = i.CLAIMNO 
			and cp.OCCURRENCE = i.OCCURRENCE 
			inner join plan pl 
			on cp.PLANID = pl.PLANID 
			inner join CLAIMREQUIREMENTINFO cr 
			on cp.claimno = cr.CLAIMNO 
			and cp.OCCURRENCE = cr.OCCURRENCE 

		--	left join commoncode cc2 on p.state = cc2.codevalue and cc2.category = 'State' and cc2.codename = 'State'  

			where 
			to_char(cr.REQUESTEDDT,'MM/DD/YYYY') = '10/27/2017' 
			and 
			(c.DELETEIND is null or c.DELETEIND <> 'Y') 
			and c.CLAIMSTATUS in ('25','30','50','65') 
			--and cp.ELIGIBILITY = '30' 
			and cr.PENDINGCODE not like 'C%' and cr.TARGET <> 'O' 
			and (cr.RESOLVEIND is null or cr.RESOLVEIND <> 'Y');