----------------------------------
select cp.claimPaymentId,cp.SETTLEMENTDATE,c.claimstatusdt, c.billno, c.billdtfrom, p.providerCode,
 p.providerNameThai, cp.approvedAMT - (select sum(nvl(PaBonusDeductAmt,0))
 from Claimpolicy cpc 
 where cp.claimno = cpc.claimno and cp.occurrence = cpc.occurrence 
 and cp.POLICYNO = cpc.POLICYNO) as approvedAMT, cp.paymentTransferDt, cp.paymentTransferRemark   ,
 case when c.treatmentType in ('1','2','6','7','11','12','13','14') then 'IPD'  
 when c.treatmentType = '5' then 'OPD-Illness'  
 when c.treatmentType = '4' then 'OPD-Accident'  
 else '' end  as treatmentType  
 from claim c, claimpayment cp, provider p    
 where c.claimno = cp.claimno and c.occurrence = cp.occurrence 
 and c.providercode = p.providercode and cp.payeetype = 'P'   
 and c.billingstatus = '10' and cp.paymentstatus = '70'  
 and TRUNC(c.claimstatusdt)  = to_date('08/15/2018','MM/dd/yyyy')
 order by p.providerNameThai, c.billdtfrom, p.providercode, c.treatmentType, cp.paymenttransferdt, cp.paymenttransferremark;