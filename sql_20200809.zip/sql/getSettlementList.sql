select distinct settle.*, cp.SUPPRESSIND , cws.PICKUPCHQIND ,pro.productType, p.subplancode, com1.COMMENTDETAIL , 
cp.POLICYISSUEDT ,cc.CODEDESC , com3.COMMENTDETAIL commentfax ,
pay.payeeid , provider.PROVIDERCODE , provider.PROVIDERREGNAMETHAI PROVIDERNAMETHAI ,
--toolkit.decrypt( insured.FIRSTNAME ,?) insuredfirstname,toolkit.decrypt( insured.LASTNAME,?) insuredlastname , 
payment.ADJUSTEDAMT ,payment.LASTMODIFIEDUSERDEPT,payment.LASTMODIFIEDUSERDESK ,pay.POSTALCODE as PAYEEPOSTALCODE ,
pay.state as PAYEESTATE ,cc2.codedesclongthai declineThaiDesc , 0  as ENDINGLETTER 
from
SETTLEMENTWORKING settle left join CWSWORKING cws
on settle.OCCURRENCE = cws.OCCURRENCE and settle.CLAIMNO = cws.CLAIMNO
left join CLAIMPAYMENT payment on settle.CLAIMNO = payment.CLAIMNO and settle.POLICYNO = payment.POLICYNO 
and settle.OCCURRENCE = payment.OCCURRENCE and settle.planid = payment.planid and settle.PLANCOVERAGENO = payment.PLANCOVERAGENO 
left join plan p on settle.planid = p.planid
left join product pro on pro.PRODUCTCODE  = p.productcode
left join CLAIMCOMMENT com1 on settle.CLAIMNO = com1.CLAIMNO and settle.OCCURRENCE = com1.OCCURRENCE and com1.commenttype = 6 
left join CLAIMCOMMENT com2 on settle.CLAIMNO = com2.CLAIMNO and settle.OCCURRENCE = com2.OCCURRENCE and com1.SEQNO < com2.SEQNO and com2.commenttype = 6 
left join CLAIMCOMMENT com3 on settle.CLAIMNO = com3.CLAIMNO and settle.OCCURRENCE = com3.OCCURRENCE and com3.commenttype = 4 
left join CLAIMCOMMENT com4 on settle.CLAIMNO = com4.CLAIMNO and settle.OCCURRENCE = com4.OCCURRENCE and com3.SEQNO < com4.SEQNO and com4.commenttype = 4 

left join CLAIM c on settle.CLAIMNO = c.CLAIMNO and settle.OCCURRENCE = c.OCCURRENCE 
left join payee pay on settle.claimno = pay.claimno and settle.OCCURRENCE = pay.OCCURRENCE and pay.POLICYNO = settle.POLICYNO 
left join claimpolicy cp on settle.CLAIMNO = cp.CLAIMNO and settle.OCCURRENCE = cp.OCCURRENCE and settle.POLICYNO = cp.POLICYNO 
left join commoncode cc on settle.state = cc.codevalue and cc.category = 'State' and cc.codename = 'State' 
left join commoncode cc2 on payment.declinereason = cc2.codevalue and cc2.category = 'ClaimPayment' and cc2.codename = 'DeclineReason' 

left join provider provider on c.PROVIDERCODE = provider.providercode 
left join insured insured on c.CLAIMNO = insured.CLAIMNO and c.OCCURRENCE = insured.OCCURRENCE and c.POLICYNO = insured.POLICYNO 
where 1=1
	
	and settle.CLAIMNO =  'C000001700'
	and settle.OCCURRENCE =  1 
	and (settle.PRODUCTCODE like 'HS%' or p.PLANNAME = 'ME') 
	and to_char(settle.CYCLEDATE,'MM/DD/YYYY') =  '09/29/2017'? 
	and ((c.submissiontype = 'Cash') or (c.submissiontype = 'Cashless' and payment.PayeeType <> 'P')) 
and com2.CLAIMNO is null and com2.OCCURRENCE is null 
and com4.CLAIMNO is null and com4.OCCURRENCE is null 
order by  settle.CLAIMNO, settle.OCCURRENCE,settle.PAYEEFIRSTNAME, 
CASE  
WHEN settle.PRODUCTCODE = 'HSUD' THEN 'HS' 
else  settle.PRODUCTCODE 
END desc , 
settle.PRODUCTCODE,cp.POLICYISSUEDT desc , settle.POLICYNO desc , settle.PLANNAME, 
settle.PLANID,settle.PLANCOVERAGENO ,settle.DECLINEDESCLONG desc ;