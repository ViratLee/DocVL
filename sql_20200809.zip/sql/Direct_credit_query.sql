select cp.claimno, cp.occurrence,
TOOLKIT.DECRYPT(c.firstName,'1234567812345678') || ' ' || TOOLKIT.DECRYPT(c.lastName,'1234567812345678') as name,
c.hospitalizationdate as incidentdt,
c.treatmentType, c.PROVIDERCODE,
sum(NVL(cp.approvedAMT,0)) as amount,
cp.settlementdate,
c.billno, c.billdtfrom as invoiceDate 
from claimpayment cp, claim c,  provider p
where c.claimno = cp.claimno
and c.occurrence = cp.occurrence
and c.providercode = p.providercode
and cp.payeetype = 'P' 
and cp.claimpaymentId in ( '302520','302521','302519','302518','302511','302510')
group by cp.claimno, cp.occurrence, c.firstName, c.lastName,c.treatmentType, c.billdtfrom, cp.SETTLEMENTDATE,
c.accidentdt, c.hospitalizationdate, c.billno, c.PROVIDERCODE 
having sum(NVL(cp.approvedAMT,0)) > 0 
order by  c.PROVIDERCODE, c.billdtfrom ,cp.claimno, cp.occurrence ,c.treatmentType ;
-------------
select cp.claimno, cp.occurrence, 
TOOLKIT.DECRYPT(c.firstName,'1234567812345678') || ' ' || TOOLKIT.DECRYPT(c.lastName,'1234567812345678') as name,
c.hospitalizationdate as incidentdt, sum(NVL(cp.approvedAMT,0)) as amount, cp.settlementdate, 
c.billno, c.billdtfrom as invoiceDate  from claimpayment cp, claim c,  provider p 
where c.claimno = cp.claimno and c.occurrence = cp.occurrence and c.providercode = p.providercode 
and cp.payeetype = 'P'  and cp.claimpaymentId in ('302520', '302521', '302519', '302518', '302511', '302510')  
group by cp.claimno, cp.occurrence, c.firstName, c.lastName,c.treatmentType, c.billdtfrom, cp.SETTLEMENTDATE, 
c.accidentdt, c.hospitalizationdate, c.billno having sum(NVL(cp.approvedAMT,0)) > 0  
order by cp.claimno, cp.occurrence , c.treatmentType;

----------
select cp.claimno, cp.occurrence, 
TOOLKIT.DECRYPT(c.firstName,'1234567812345678') || ' ' || TOOLKIT.DECRYPT(c.lastName,'1234567812345678') as name,
c.hospitalizationdate as incidentdt, sum(NVL(cp.approvedAMT,0)) as amount, cp.settlementdate, 
c.billno, c.billdtfrom as invoiceDate  from claimpayment cp, claim c,  provider p 
where c.claimno = cp.claimno and c.occurrence = cp.occurrence and c.providercode = p.providercode 
and cp.payeetype = 'P'  and cp.claimpaymentId in ('302520', '302521', '302519', '302518', '302511', '302510')  
group by cp.claimno, cp.occurrence, c.firstName, c.lastName,c.treatmentType, c.billdtfrom, cp.SETTLEMENTDATE, 
c.accidentdt, c.hospitalizationdate, c.billno having sum(NVL(cp.approvedAMT,0)) > 0  
order by cp.claimno, cp.occurrence , c.treatmentType;