SELECT clm.claimid,
  clm.caseId ,
  clm.batchNo,
  clm.ediInd,
  clm.stpInd,
  SUM(NVL(APPROVEDAMT,0) - NVL(pol.PaBonusDeductAmt,0) - NVL(pay.DEDUCTAMT,0)) AS totalBilledAmt,
  (SELECT codedesc
  FROM commoncode code
  WHERE category    = 'TreatmentType'
  AND codename      = 'TreatmentType'
  AND treatmentType = codevalue
  ) AS treatmentType,
  clm.policyNo,
  clm.certNo,
  clm.memberId,
  TOOLKIT.decrypt(firstName,'1234567812345678') AS firstName,
  TOOLKIT.decrypt(lastName,'1234567812345678')  AS lastName ,
  clm.claimNo
  || '/'
  || clm.OCCURRENCE AS claimNo,
  clm.hospitalizationDate,
  clm.dischargeDate,
  clm.providerCode,
  (SELECT providerNameThai
  FROM provider pvd
  WHERE clm.PROVIDERCODE = pvd.PROVIDERCODE
  ) AS providerName,
  CASE
    WHEN CLAIMSTATUS IN ('65','70')
    THEN clm.lastModifiedDt
    ELSE NULL
  END AS lastModifiedDt ,
  clm.billingStatus ,
  clm.billingDeclineReason,
  (SELECT codedesc
  FROM commoncode cc
  WHERE category        = 'Claim'
  AND codename          = 'BillingStatus'
  AND clm.billingStatus = cc.codevalue
  )AS billingStatusDesc ,
  (SELECT codedesc
  FROM commoncode cc
  WHERE category               = 'Claim'
  AND codename                 = 'BillingDeclineReason'
  AND clm.BillingDeclineReason = cc.codevalue
  )AS BillingDeclineReasonDesc ,
  pay.SETTLEMENTDATE ,
  ACCIDENTDT ,
  NVL(
  (SELECT LISTAGG(cs.STRVALUE, ', ') WITHIN GROUP (
  ORDER BY cs.STRVALUE)
  FROM claimsupplement cs
  WHERE cs.codetype  = 'DiagnosisCode'
  AND clm.CLAIMNO    = cs.CLAIMNO
  AND clm.OCCURRENCE = cs.OCCURRENCE
  ),'') AS ICD10 ,
  SUM(COALESCE(
  CASE
    WHEN pay.producttype = 'HSX'
    THEN pay.HSBONUSDEDUCTAMT
    ELSE NULL
  END,0)) AS HSBONUSDEDUCTAMT
FROM Claim clm
INNER JOIN CLAIMPAYMENT pay
ON clm.claimno     = pay.claimno
AND clm.OCCURRENCE = pay.OCCURRENCE
INNER JOIN CLAIMPOLICY pol
ON pay.claimno          = pol.claimno
AND pay.OCCURRENCE      = pol.OCCURRENCE
AND pay.policyno        = pol.policyno
AND ((pol.businessline IN ('CS', 'GE')
AND pay.productcode     = pol.productcode)
OR pol.businessline    IN ('OL','PA') )
AND (( EXISTS
  (SELECT 1
  FROM Claimpaymentdetail cpd
  WHERE cpd.claimno        = pay.claimno
  AND cpd.OCCURRENCE       = pay.OCCURRENCE
  AND pay.policyno         = cpd.policyno
  AND pay.planid           = cpd.planid
  AND pay.PLANCOVERAGENO   = cpd.PLANCOVERAGENO
  AND ( ( cpd.PRODUCTTYPE IN ('PA','HS','HSPG','HSJR','HSNEW','HSOLD','HSUD','HSX','CSME','BBL') )
  OR ( cpd.benefitcode     = 'A09') )
  ) )
OR ( pay.PRODUCTTYPE  IN ('AMR/AME' ,'HS' ,'H+S(NON)' ,'HS' ,'HS - Lumsum' ,'CLINICAL' ,'XRAY+LAB' ,'SPEC CONS','MATERNITY','DENTAL','SUPP MED','EXT MED','EXT MJ MED','COMP MM', 'HNW') ) )
WHERE clm.COMPANYID    ='051'
AND SUBMISSIONTYPE     = 'Cashless'
AND clm.CLAIMSTATUS   IN ('40','50','65','70')
AND pay.PAYMENTSTATUS IN ('50','70')
AND ELIGIBILITY        = '10'
AND pay.payeetype      = 'P'
AND SETTLEMENTDATE    IS NOT NULL
AND clm.treatmentType IN ('1','2','11','12','14') -- if ipd
  --and clm.treatmentType in ('4','5','6','7','13') -- if opd
AND clm.claimno NOT LIKE 'Q%'
and providerCode = '1001280005'
GROUP BY clm.claimid,
  clm.caseId ,
  clm.batchNo,
  clm.ediInd,
  clm.stpInd,
  clm.treatmentType,
  clm.policyNo,
  clm.certNo,
  clm.memberId,
  firstName,
  lastName,
  clm.claimNo ,
  clm.OCCURRENCE,
  clm.hospitalizationDate,
  clm.dischargeDate,
  clm.providerCode,
  CLAIMSTATUS,
  clm.lastModifiedDt ,
  clm.billingStatus ,
  clm.billingDeclineReason,
  pay.SETTLEMENTDATE ,
  ACCIDENTDT
ORDER BY clm.dischargeDate;