Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.retrieveAccidentIcd10List','http://localhost:5455/rest/AIAService/lookup/retrieveLookup/RetrieveAccidentIcd10List','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.retrieveClaimDetail','http://localhost:5455/rest/AIAService/claim/retrieveClaim/RetrieveClaimDetail','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.retrieveIllnessIcd10Value','http://localhost:5455/rest/AIAService/lookup/retrieveLookup/RetrieveIllnessIcd10Value','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.retrieveIndividual','http://localhost:5455/rest/AIAService/party/retrieveParty/RetrieveIndividual','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.retrievePartyDetail','http://localhost:5455/rest/AIAService/party/retrieveParty/RetrievePartyDetail','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.retrievePolicyDetailHistory','http://localhost:5455/rest/AIAService/policy/retrievePolicy/RetrievePolicyDetailHistory','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchClaimByClaimNo','http://localhost:5455/rest/AIAService/claim/searchClaim/SearchClaimByClaimNo','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchClaimByCriteria','http://localhost:5455/rest/AIAService/claim/searchClaim/SearchClaimByCriteria','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchClaimParticipantByPartyId','http://localhost:5455/rest/AIAService/claim/searchClaim/SearchClaimParticipantByPartyId','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchClaimPerLifeByPartyId','http://localhost:5455/rest/AIAService/claim/searchClaim/SearchClaimPerLifeByPartyId','wMUser',to_timestamp('09-JUL-17 09.45.43.000000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('09-JUL-17 09.45.43.000000000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchPolicy','http://localhost:5455/rest/AIAService/policy/searchPolicy/SearchPolicy','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchPolicyHistory','http://localhost:5455/rest/AIAService/policy/searchPolicy/SearchPolicyHistory','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchPolicyPerlifeByPartyId','http://localhost:5455/rest/AIAService/policy/searchPolicy/SearchPolicyPerlifeByPartyId','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchPolicyPerlifeInsuredByPartyId','http://localhost:5455/rest/AIAService/policy/searchPolicy/SearchPolicyPerlifeInsuredByPartyId','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into MAPPCMIC.SYSTEMCONFIG (PARAMKEY,PARAMVALUE,CREATEDBY,CREATEDDT,LASTMODIFIEDBY,LASTMODIFIEDDT) 
values ('cmic.ods.endpoint.searchProducer','http://localhost:5455/rest/AIAService/agency/retrieveProducer/SearchProducer','wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),'wMUser',to_timestamp('01-NOV-16 09.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));


update systemconfig
set paramvalue = 'http://localhost:5455/rest/AIAService/lookup/retrieveLookup/RetrieveAccidentIcd10List'
where paramkey = 'cmic.ods.endpoint.retrieveAccidentIcd10List';