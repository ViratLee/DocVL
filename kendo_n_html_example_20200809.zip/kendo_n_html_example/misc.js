document.getElementById('btnPTCallHistInquiry').style.display = 'block'; // show
document.getElementById('btnPTCallHistInquiry').style.display = 'none'; // hide
document.getElementById('btnPTCallHist').style.display = 'none'; // hide
  
<input id="combobox" />
<script>
$("#combobox").kendoComboBox({
  dataSource: [ "Apples", "Oranges" ],
  change: function(e) {
    var value = this.value();
    // Use the value of the widget
  }
});
</script>  