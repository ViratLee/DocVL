
$(function() {
  $('#grid').kendoGrid({
    dataSource: {
      data: [
        { a: "dafdsf" }
      ],
      schema: {
        model: {
          id: "a"
        }
      }
          
    },
    columns: [
      {
        field: "a",
        width: 120,
        template: 'template: #= a #'
      }
    ]
  });
  
  $('#add').click(function() {
    $('#grid').data('kendoGrid').addRow();
  });
});