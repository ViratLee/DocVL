package com.aia.cmic.exception;

public class CMiCInvalidInputException extends CMiCException {
	private static final long serialVersionUID = 2958429324888384005L;

	public CMiCInvalidInputException() {
		super();
	}

	public CMiCInvalidInputException(String message) {
		super(message);
	}

	public CMiCInvalidInputException(String message, Throwable cause) {
		super(message, cause);
	}

	public CMiCInvalidInputException(Throwable cause) {
		super(cause);
	}
}
