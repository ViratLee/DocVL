package com.aia.cmic.exception;

public class CMiCUnauthorizedAccessException extends CMiCException {
	private static final long serialVersionUID = 3631438767282224474L;

	public CMiCUnauthorizedAccessException() {
		super();
	}

	public CMiCUnauthorizedAccessException(String message) {
		super(message);
	}

	public CMiCUnauthorizedAccessException(String message, Throwable cause) {
		super(message, cause);
	}

	public CMiCUnauthorizedAccessException(Throwable cause) {
		super(cause);
	}
}
