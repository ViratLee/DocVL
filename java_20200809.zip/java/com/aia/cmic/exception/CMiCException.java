package com.aia.cmic.exception;

public class CMiCException extends RuntimeException {
	private static final long serialVersionUID = 8990467090574702556L;

	public CMiCException() {
		super();
	}

	public CMiCException(String message) {
		super(message);
	}

	public CMiCException(String message, Throwable cause) {
		super(message, cause);
	}

	public CMiCException(Throwable cause) {
		super(cause);
	}
}
