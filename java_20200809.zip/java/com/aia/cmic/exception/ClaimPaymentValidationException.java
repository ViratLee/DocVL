package com.aia.cmic.exception;

public class ClaimPaymentValidationException extends CMiCException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -718669893129793312L;

	public ClaimPaymentValidationException(String message) {
		super(message);
	}

}
