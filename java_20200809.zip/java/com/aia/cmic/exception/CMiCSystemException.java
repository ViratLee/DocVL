package com.aia.cmic.exception;

public class CMiCSystemException extends CMiCException {
	private static final long serialVersionUID = -1550444973901292086L;

	public CMiCSystemException() {
		super();
	}

	public CMiCSystemException(String message) {
		super(message);
	}

	public CMiCSystemException(String message, Throwable cause) {
		super(message, cause);
	}

	public CMiCSystemException(Throwable cause) {
		super(cause);
	}
}
