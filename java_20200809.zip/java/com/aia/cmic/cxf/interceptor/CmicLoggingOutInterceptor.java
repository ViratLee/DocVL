package com.aia.cmic.cxf.interceptor;

import org.apache.cxf.common.injection.NoJSR250Annotations;
import org.apache.cxf.interceptor.LoggingMessage;

/**
 * A simple logging handler which outputs the bytes of the message to the
 * Logger.
 */
@NoJSR250Annotations
public class CmicLoggingOutInterceptor extends org.apache.cxf.interceptor.LoggingOutInterceptor {

	protected String formatLoggingMessage(LoggingMessage loggingMessage) {
		return loggingMessage.getAddress().append(":Outbound Payload: ").append(loggingMessage.getPayload().toString()).toString();
	}

}
