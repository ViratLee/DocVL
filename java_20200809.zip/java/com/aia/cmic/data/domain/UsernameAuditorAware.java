package com.aia.cmic.data.domain;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.domain.AuditorAware;

import com.aia.cmic.util.SecurityUtil;

public class UsernameAuditorAware implements AuditorAware<String> {
	@Override
	public String getCurrentAuditor() {
		if (!StringUtils.isEmpty(SecurityUtil.userInfo.get().getSaveAsUserId())) {
			return SecurityUtil.userInfo.get().getSaveAsUserId();
		}
		return SecurityUtil.userInfo.get().getUserId();
	}
}
