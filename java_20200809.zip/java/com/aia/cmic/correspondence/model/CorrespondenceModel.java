package com.aia.cmic.correspondence.model;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.aia.cmic.services.CorrespondenceManagerService;
import com.aia.cmic.xml.common.FIELD;
import com.aia.cmic.xml.common.FORM;
import com.aia.cmic.xml.common.KEY;

public abstract class CorrespondenceModel {

	public abstract <T> FORM getObjectCorresponedence(CorrespondenceModel corrObject, List<T> objList);
	
	
	private CorrespondenceManagerService managerService;
	
	//KEY 
	private Date keyCurrentCycleDate;
	private String formId;
	private String claimNo;
	private String policyNo;
	private String companyId;
	private String pendingCode;
	private String userId;
	private String userDept;
	private String subCorr;
	//
	

	public CorrespondenceManagerService getManagerService() {
		return managerService;
	}
	
	public void setManagerService(CorrespondenceManagerService managerService) {
		this.managerService = managerService;
	}
	
	public Date getKeyCurrentCycleDate() {
		return keyCurrentCycleDate;
	}

	public void setKeyCurrentCycleDate(Date keyCurrentCycleDate) {
		this.keyCurrentCycleDate = keyCurrentCycleDate;
	}

	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserDept() {
		return userDept;
	}
	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getPendingCode() {
		return pendingCode;
	}
	public void setPendingCode(String pendingCode) {
		this.pendingCode = pendingCode;
	}
	
	public String getSubCorr() {
		return subCorr;
	}

	public void setSubCorr(String subCorr) {
		this.subCorr = subCorr;
	}

	protected KEY addKey(String formId, String companyId, String policyNo, String pendingCode, Date cycleDate, String userId, String userDept, String subCorr) {
		KEY key = new KEY();
		key.setFormid(formId);
		key.setCompany(companyId);
		key.setPolicyno(policyNo);
		key.setPendingcode(pendingCode);
		key.setUserid(userId);
		key.setUserdept(userDept);
		key.setCycledate(DateformatToString(cycleDate));
		key.setSubCorr(subCorr);
		return key;
	}
	
	protected FIELD addFieldContent(String name, String value) {
		FIELD field = new FIELD();
		field.setName(name);
		field.setValue(value);
		
		return field;
	}
	
	private String DateformatToString(Date date){
		String strDate = "";
		
		if (date != null) { 
			Format formatter;
	    	formatter = new SimpleDateFormat("dd MMMM yyyy", new Locale("th", "TH"));
	    	strDate = formatter.format(date);
		}
		
		return strDate;
	}
}
