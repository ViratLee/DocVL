package com.aia.cmic.correspondence.model;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import com.aia.cmic.xml.common.CONTENT;
import com.aia.cmic.xml.common.FIELD;
import com.aia.cmic.xml.common.FORM;

public class TemplateAHOSPModel extends CorrespondenceModel {

	private String claimLastModified;
	private String claimName;
	private String dateTime;
	private String agentName;
	private String officeCode;
	private String agencyName;
	private String agencyCode;
	private String hospitalDate;
	private String receiveDate;
	private String dischargeDate;
	private String assessor;
	private String providerNameThai;
	private String providerRegNameThai;
	private String resultDesc;
	private String memoText;

	@Override
	public <T> FORM getObjectCorresponedence(CorrespondenceModel corrObject, List<T> objList) {

		Date keyCurrentCycleDate;
		String formId;
		String claimNo;
		String policyNo;
		String companyId;
		String userId;
		String userDept;
		String pendingCode;
		String subCorr;

		FORM form = null;

		if (corrObject instanceof TemplateAHOSPModel) {

			if (objList != null) {
				for (Object pReq : objList) {

					form = new FORM();
					CONTENT content = form.getContent();
					List<FIELD> fieldList = content.getField();
					FIELD field;

					try {

						// add Key 
						formId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getFormId").invoke(pReq, null);
						claimNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getClaimNo").invoke(pReq, null);
						policyNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPolicyNo").invoke(pReq, null);
						pendingCode = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPendingCode").invoke(pReq, null);
						companyId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getCompanyId").invoke(pReq, null);
						userId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserId").invoke(pReq, null);
						userDept = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserDept").invoke(pReq, null);
						keyCurrentCycleDate = (Date) pReq.getClass().getSuperclass().getDeclaredMethod("getKeyCurrentCycleDate").invoke(pReq, null);
						subCorr = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getSubCorr").invoke(pReq, null);
						form.setKey(addKey(formId, companyId, policyNo, pendingCode, keyCurrentCycleDate, userId, userDept, subCorr));

						// add Content
						field = addFieldContent("claimNo", claimNo);
						fieldList.add(field);
						field = addFieldContent("ClaimLastModified", (String) pReq.getClass().getDeclaredMethod("getClaimLastModified").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ClaimName", (String) pReq.getClass().getDeclaredMethod("getClaimName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DateTime", (String) pReq.getClass().getDeclaredMethod("getDateTime").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgentName", (String) pReq.getClass().getDeclaredMethod("getAgentName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("OfficeCode", (String) pReq.getClass().getDeclaredMethod("getOfficeCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyName", (String) pReq.getClass().getDeclaredMethod("getAgencyName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyCode", (String) pReq.getClass().getDeclaredMethod("getAgencyCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("HospitalDate", (String) pReq.getClass().getDeclaredMethod("getHospitalDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ReceiveDate", (String) pReq.getClass().getDeclaredMethod("getReceiveDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DisChargeDate", (String) pReq.getClass().getDeclaredMethod("getDischargeDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Assessor", (String) pReq.getClass().getDeclaredMethod("getAssessor").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ProviderNameThai", (String) pReq.getClass().getDeclaredMethod("getProviderRegNameThai").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ResultDesc", (String) pReq.getClass().getDeclaredMethod("getResultDesc").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("MemoText", (String) pReq.getClass().getDeclaredMethod("getMemoText").invoke(pReq, null));
						fieldList.add(field);

					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}

				}

			}
		}

		return form;
	}

	public String getClaimLastModified() {
		return claimLastModified;
	}

	public void setClaimLastModified(String claimLastModified) {
		this.claimLastModified = claimLastModified;
	}

	public String getClaimName() {
		return claimName;
	}

	public void setClaimName(String claimName) {
		this.claimName = claimName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getOfficeCode() {
		return officeCode;
	}

	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getHospitalDate() {
		return hospitalDate;
	}

	public void setHospitalDate(String hospitalDate) {
		this.hospitalDate = hospitalDate;
	}

	public String getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}
	
	public String getProviderRegNameThai() {
		return providerRegNameThai;
	}

	public void setProviderRegNameThai(String providerRegNameThai) {
		this.providerRegNameThai = providerRegNameThai;
	}

	public String getResultDesc() {
		return resultDesc;
	}

	public void setResultDesc(String resultDesc) {
		this.resultDesc = resultDesc;
	}

	public String getMemoText() {
		return memoText;
	}

	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}

	public String getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

}
