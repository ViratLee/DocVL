package com.aia.cmic.correspondence.model;

public class PendingReportResponseModel {
	
	private String numRow;
	private String claimNo;
	private String occ;
	private String policy;
	private String firstName;
	private String lastName;
	private String submissionDate;
	private String pendingDate;
	private String claimDur;
	private String pendingdur;
	private String type;
	private String appr;
	private String pendingCode;
	private String submissionAgt;
	private String hospitalName;
	public String getNumRow() {
		return numRow;
	}
	public void setNumRow(String numRow) {
		this.numRow = numRow;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public String getOcc() {
		return occ;
	}
	public void setOcc(String occ) {
		this.occ = occ;
	}
	public String getPolicy() {
		return policy;
	}
	public void setPolicy(String policy) {
		this.policy = policy;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}
	public String getPendingDate() {
		return pendingDate;
	}
	public void setPendingDate(String pendingDate) {
		this.pendingDate = pendingDate;
	}
	public String getClaimDur() {
		return claimDur;
	}
	public void setClaimDur(String claimDur) {
		this.claimDur = claimDur;
	}
	public String getPendingdur() {
		return pendingdur;
	}
	public void setPendingdur(String pendingdur) {
		this.pendingdur = pendingdur;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAppr() {
		return appr;
	}
	public void setAppr(String appr) {
		this.appr = appr;
	}
	public String getPendingCode() {
		return pendingCode;
	}
	public void setPendingCode(String pendingCode) {
		this.pendingCode = pendingCode;
	}
	public String getSubmissionAgt() {
		return submissionAgt;
	}
	public void setSubmissionAgt(String submissionAgt) {
		this.submissionAgt = submissionAgt;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	
}
