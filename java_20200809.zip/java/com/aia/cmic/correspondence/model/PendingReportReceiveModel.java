package com.aia.cmic.correspondence.model;

import java.util.Date;

public class PendingReportReceiveModel {
	
	private String claimNo;
	private String submissionType; //cashCashless; 
	private String policyNo;
	private String typeOfClaim;
	private String apporvalCode;
	private String pendingCode;
	private String claimDuration;
	private String submissionAgt;
	private String providerCode;
	private Date receivedDate; // submissionDate
	private Date requestedDt; // pendingDate
	
	
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	
	public String getSubmissionType() {
		return submissionType;
	}
	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getTypeOfClaim() {
		return typeOfClaim;
	}
	public void setTypeOfClaim(String typeOfClaim) {
		this.typeOfClaim = typeOfClaim;
	}
	public String getApporvalCode() {
		return apporvalCode;
	}
	public void setApporvalCode(String apporvalCode) {
		this.apporvalCode = apporvalCode;
	}
	public String getPendingCode() {
		return pendingCode;
	}
	public void setPendingCode(String pendingCode) {
		this.pendingCode = pendingCode;
	}
	public String getClaimDuration() {
		return claimDuration;
	}
	public void setClaimDuration(String claimDuration) {
		this.claimDuration = claimDuration;
	}
	public String getSubmissionAgt() {
		return submissionAgt;
	}
	public void setSubmissionAgt(String submissionAgt) {
		this.submissionAgt = submissionAgt;
	}
	
	public String getProviderCode() {
		return providerCode;
	}
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}
	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}
	public Date getRequestedDt() {
		return requestedDt;
	}
	public void setRequestedDt(Date requestedDt) {
		this.requestedDt = requestedDt;
	}
	
	
	
}
