package com.aia.cmic.correspondence.model;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import com.aia.cmic.xml.common.CONTENT;
import com.aia.cmic.xml.common.FIELD;
import com.aia.cmic.xml.common.FORM;

public class TemplateHAPSModel extends CorrespondenceModel{
	private String claimLastModified;
	private String claimName;
	private String dateTime;
	private String agentName;
	private String officeCode;
	private String agencyName;
	private String agencyCode;
	private String hospitalDate;
	private String disChargeDate;
	private String receiveDate;
	private String assessor;
	private String providerNameThai;
	private String resultDesc;
	private String memoText;
	private String hospitalAddr1;
	private String hospitalAddr2;
	private String hospitalAddr3;
	private String hospitalAddr4;
	private String insuredAge;
	private String insuredOldName;
	private String hn;
	private String insuredAddr;
	private String insuredPhone;
	
	
	private String claimName2;
	private String insuredAge2;
	private String insuredOldName2;
	private String hn2;
	private String hospitalAddr5;
	private String insuredPhone2;
	private String concern;
	
	
	@Override
	public <T> FORM getObjectCorresponedence(
			CorrespondenceModel corrObject, List<T> objList) {
		
		Date keyCurrentCycleDate;
		String formId;
		String claimNo;
		String policyNo;
		String companyId;
		String userId;
		String userDept;
		String pendingCode;
		String subCorr;

		FORM form = null;
		
		if(corrObject instanceof TemplateHAPSModel) {
			
			if (objList != null) {
				for (Object pReq : objList) {
					
					form = new FORM();
					CONTENT content = form.getContent();
					List<FIELD> fieldList = content.getField();
					FIELD field;
					
					try {
						
						// add Key 
						formId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getFormId").invoke(pReq, null);
						claimNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getClaimNo").invoke(pReq, null);
						policyNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPolicyNo").invoke(pReq, null);
						pendingCode =(String) pReq.getClass().getSuperclass().getDeclaredMethod("getPendingCode").invoke(pReq, null);
						companyId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getCompanyId").invoke(pReq, null);
						userId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserId").invoke(pReq, null);
						userDept = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserDept").invoke(pReq, null);
						keyCurrentCycleDate = (Date) pReq.getClass().getSuperclass().getDeclaredMethod("getKeyCurrentCycleDate").invoke(pReq, null);
						subCorr = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getSubCorr").invoke(pReq, null);
						form.setKey(addKey(formId, companyId, policyNo, pendingCode, keyCurrentCycleDate, userId, userDept, subCorr));
						
						// add Content
						field = addFieldContent("claimNo", claimNo);
						fieldList.add(field);
						field = addFieldContent("ClaimLastModified", (String) pReq.getClass().getDeclaredMethod("getClaimLastModified").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ClaimName", (String) pReq.getClass().getDeclaredMethod("getClaimName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DateTime", (String) pReq.getClass().getDeclaredMethod("getDateTime").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgentName", (String) pReq.getClass().getDeclaredMethod("getAgentName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("OfficeCode", (String) pReq.getClass().getDeclaredMethod("getOfficeCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyName", (String) pReq.getClass().getDeclaredMethod("getAgencyName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyCode", (String) pReq.getClass().getDeclaredMethod("getAgencyCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("HospitalDate", (String) pReq.getClass().getDeclaredMethod("getHospitalDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DisChargeDate", (String) pReq.getClass().getDeclaredMethod("getDisChargeDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ReceiveDate", (String) pReq.getClass().getDeclaredMethod("getReceiveDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Assessor", (String) pReq.getClass().getDeclaredMethod("getAssessor").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ProviderNameThai", (String) pReq.getClass().getDeclaredMethod("getProviderNameThai").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ResultDesc", (String) pReq.getClass().getDeclaredMethod("getResultDesc").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("MemoText", (String) pReq.getClass().getDeclaredMethod("getMemoText").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hospitalAddr1", (String) pReq.getClass().getDeclaredMethod("getHospitalAddr1").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hospitalAddr2", (String) pReq.getClass().getDeclaredMethod("getHospitalAddr2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hospitalAddr3", (String) pReq.getClass().getDeclaredMethod("getHospitalAddr3").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hospitalAddr4", (String) pReq.getClass().getDeclaredMethod("getHospitalAddr4").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredAge", (String) pReq.getClass().getDeclaredMethod("getInsuredAge").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredOldName", (String) pReq.getClass().getDeclaredMethod("getInsuredOldName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hn", (String) pReq.getClass().getDeclaredMethod("getHn").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredAddr", (String) pReq.getClass().getDeclaredMethod("getInsuredAddr").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredPhone", (String) pReq.getClass().getDeclaredMethod("getInsuredPhone").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("claimName2", (String) pReq.getClass().getDeclaredMethod("getClaimName2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredAge2", (String) pReq.getClass().getDeclaredMethod("getInsuredAge2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredOldName2", (String) pReq.getClass().getDeclaredMethod("getInsuredOldName2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hn2", (String) pReq.getClass().getDeclaredMethod("getHn2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hospitalAddr5", (String) pReq.getClass().getDeclaredMethod("getHospitalAddr5").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("insuredPhone2", (String) pReq.getClass().getDeclaredMethod("getInsuredPhone2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("concern", (String) pReq.getClass().getDeclaredMethod("getConcern").invoke(pReq, null));
						fieldList.add(field);
						
						
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}
					
				}
					
			}
		}
		
		return form;
	}

	public String getClaimLastModified() {
		return claimLastModified;
	}

	public void setClaimLastModified(String claimLastModified) {
		this.claimLastModified = claimLastModified;
	}

	public String getClaimName() {
		return claimName;
	}

	public void setClaimName(String claimName) {
		this.claimName = claimName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getOfficeCode() {
		return officeCode;
	}

	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getHospitalDate() {
		return hospitalDate;
	}

	public void setHospitalDate(String hospitalDate) {
		this.hospitalDate = hospitalDate;
	}

	public String getDisChargeDate() {
		return disChargeDate;
	}

	public void setDisChargeDate(String disChargeDate) {
		this.disChargeDate = disChargeDate;
	}

	public String getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getResultDesc() {
		return resultDesc;
	}

	public void setResultDesc(String resultDesc) {
		this.resultDesc = resultDesc;
	}

	public String getMemoText() {
		return memoText;
	}

	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}
	

	
	

	public String getHospitalAddr1() {
		return hospitalAddr1;
	}

	public String getHospitalAddr2() {
		return hospitalAddr2;
	}

	public String getHospitalAddr3() {
		return hospitalAddr3;
	}

	public String getHospitalAddr4() {
		return hospitalAddr4;
	}

	public String getInsuredAge() {
		return insuredAge;
	}

	public String getInsuredOldName() {
		return insuredOldName;
	}

	public String getHn() {
		return hn;
	}

	public String getInsuredAddr() {
		return insuredAddr;
	}

	public String getInsuredPhone() {
		return insuredPhone;
	}

	public void setHospitalAddr1(String hospitalAddr1) {
		this.hospitalAddr1 = hospitalAddr1;
	}

	public void setHospitalAddr2(String hospitalAddr2) {
		this.hospitalAddr2 = hospitalAddr2;
	}

	public void setHospitalAddr3(String hospitalAddr3) {
		this.hospitalAddr3 = hospitalAddr3;
	}

	public void setHospitalAddr4(String hospitalAddr4) {
		this.hospitalAddr4 = hospitalAddr4;
	}

	public void setInsuredAge(String insuredAge) {
		this.insuredAge = insuredAge;
	}

	public void setInsuredOldName(String insuredOldName) {
		this.insuredOldName = insuredOldName;
	}

	public void setHn(String hn) {
		this.hn = hn;
	}

	public void setInsuredAddr(String insuredAddr) {
		this.insuredAddr = insuredAddr;
	}

	public void setInsuredPhone(String insuredPhone) {
		this.insuredPhone = insuredPhone;
	}

	public String getConcern() {
		return concern;
	}

	public void setConcern(String concern) {
		this.concern = concern;
	}

	public String getClaimName2() {
		return claimName2;
	}

	public String getInsuredAge2() {
		return insuredAge2;
	}

	public String getInsuredOldName2() {
		return insuredOldName2;
	}

	public String getHn2() {
		return hn2;
	}

	public String getHospitalAddr5() {
		return hospitalAddr5;
	}

	public String getInsuredPhone2() {
		return insuredPhone2;
	}

	public void setClaimName2(String claimName2) {
		this.claimName2 = claimName2;
	}

	public void setInsuredAge2(String insuredAge2) {
		this.insuredAge2 = insuredAge2;
	}

	public void setInsuredOldName2(String insuredOldName2) {
		this.insuredOldName2 = insuredOldName2;
	}

	public void setHn2(String hn2) {
		this.hn2 = hn2;
	}

	public void setHospitalAddr5(String hospitalAddr5) {
		this.hospitalAddr5 = hospitalAddr5;
	}

	public void setInsuredPhone2(String insuredPhone2) {
		this.insuredPhone2 = insuredPhone2;
	}
	
	
	
	
}
