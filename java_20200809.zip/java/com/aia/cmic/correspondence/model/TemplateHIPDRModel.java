package com.aia.cmic.correspondence.model;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import com.aia.cmic.xml.common.CONTENT;
import com.aia.cmic.xml.common.FIELD;
import com.aia.cmic.xml.common.FORM;

public class TemplateHIPDRModel extends CorrespondenceModel{
	private String claimLastModified;
	private String claimName;
	private String dateTime;
	private String agentName;
	private String officeCode;
	private String agencyName;
	private String agencyCode;
	private String hospitalDate;
	private String disChargeDate;
	private String receiveDate;
	private String assessor;
	private String providerNameThai;
	private String resultDesc;
	private String memoText;
	
	private String pendingDate;
	private String ClaimName2;
	private String hn;
	private String an;
	private String headOpd;
	private String opdAll;
	private String opdDate;
	private String opdDateStart;
	private String headIpd;
	private String ipdDateStart;
	private String ipdDateEnd;
	private String admissionNote;
	private String summaryDis;
	private String doctorOrder;
	private String proGressNote;
	private String craphicChart;
	private String operationNote;
	private String nurseNote;
	private String medician;
	private String report;
	private String xRayAll;
	private String xRayCheck;
	private String xRayDate;
	private String ultraSoundAll;
	private String ultraSoundCheck;
	private String ultraSoundDate;
	private String ctAll;
	private String ctCheck;
	private String ctDate;
	private String mriAll;
	private String mriCheck;
	private String mriDate;
	private String reportAll;
	private String reportCheck;
	private String reportDate;
	private String labAll;
	private String labCheck;
	private String labDate;
	private String otherCheck;
	private String otherComment;
	private String ask;
	private String phone;
	
	
	@Override
	public <T> FORM getObjectCorresponedence(
			CorrespondenceModel corrObject, List<T> objList) {
		
		Date keyCurrentCycleDate;
		String formId;
		String claimNo;
		String policyNo;
		String companyId;
		String userId;
		String userDept;
		String pendingCode;
		String subCorr;

		FORM form = null;
		
		if(corrObject instanceof TemplateHIPDRModel) {
			
			if (objList != null) {
				for (Object pReq : objList) {
					
					form = new FORM();
					CONTENT content = form.getContent();
					List<FIELD> fieldList = content.getField();
					FIELD field;
					
					try {
						
						// add Key 
						formId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getFormId").invoke(pReq, null);
						claimNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getClaimNo").invoke(pReq, null);
						policyNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPolicyNo").invoke(pReq, null);
						pendingCode =(String) pReq.getClass().getSuperclass().getDeclaredMethod("getPendingCode").invoke(pReq, null);
						companyId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getCompanyId").invoke(pReq, null);
						userId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserId").invoke(pReq, null);
						userDept = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserDept").invoke(pReq, null);
						keyCurrentCycleDate = (Date) pReq.getClass().getSuperclass().getDeclaredMethod("getKeyCurrentCycleDate").invoke(pReq, null);
						subCorr = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getSubCorr").invoke(pReq, null);
						form.setKey(addKey(formId, companyId, policyNo, pendingCode, keyCurrentCycleDate, userId, userDept, subCorr));
						
						// add Content
						field = addFieldContent("claimNo", claimNo);
						fieldList.add(field);
						field = addFieldContent("ClaimLastModified", (String) pReq.getClass().getDeclaredMethod("getClaimLastModified").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ClaimName", (String) pReq.getClass().getDeclaredMethod("getClaimName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DateTime", (String) pReq.getClass().getDeclaredMethod("getDateTime").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgentName", (String) pReq.getClass().getDeclaredMethod("getAgentName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("OfficeCode", (String) pReq.getClass().getDeclaredMethod("getOfficeCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyName", (String) pReq.getClass().getDeclaredMethod("getAgencyName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyCode", (String) pReq.getClass().getDeclaredMethod("getAgencyCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("HospitalDate", (String) pReq.getClass().getDeclaredMethod("getHospitalDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DisChargeDate", (String) pReq.getClass().getDeclaredMethod("getDisChargeDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ReceiveDate", (String) pReq.getClass().getDeclaredMethod("getReceiveDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Assessor", (String) pReq.getClass().getDeclaredMethod("getAssessor").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ProviderNameThai", (String) pReq.getClass().getDeclaredMethod("getProviderNameThai").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ResultDesc", (String) pReq.getClass().getDeclaredMethod("getResultDesc").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("MemoText", (String) pReq.getClass().getDeclaredMethod("getMemoText").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("pendingDate", (String) pReq.getClass().getDeclaredMethod("getPendingDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("claimName2", (String) pReq.getClass().getDeclaredMethod("getClaimName2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("hn", (String) pReq.getClass().getDeclaredMethod("getHn").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("an", (String) pReq.getClass().getDeclaredMethod("getAn").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("headOpd", (String) pReq.getClass().getDeclaredMethod("getHeadOpd").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("opdAll", (String) pReq.getClass().getDeclaredMethod("getOpdAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("opdDate", (String) pReq.getClass().getDeclaredMethod("getOpdDate").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("opdDateStart", (String) pReq.getClass().getDeclaredMethod("getOpdDateStart").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("headIpd", (String) pReq.getClass().getDeclaredMethod("getHeadIpd").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ipdDateStart", (String) pReq.getClass().getDeclaredMethod("getIpdDateStart").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ipdDateEnd", (String) pReq.getClass().getDeclaredMethod("getIpdDateEnd").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("admissionNote", (String) pReq.getClass().getDeclaredMethod("getAdmissionNote").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("summaryDis", (String) pReq.getClass().getDeclaredMethod("getSummaryDis").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("doctorOrder", (String) pReq.getClass().getDeclaredMethod("getDoctorOrder").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("proGressNote", (String) pReq.getClass().getDeclaredMethod("getProGressNote").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("craphicChart", (String) pReq.getClass().getDeclaredMethod("getCraphicChart").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("operationNote", (String) pReq.getClass().getDeclaredMethod("getOperationNote").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("nurseNote", (String) pReq.getClass().getDeclaredMethod("getNurseNote").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("medician", (String) pReq.getClass().getDeclaredMethod("getMedician").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("report", (String) pReq.getClass().getDeclaredMethod("getReport").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("xRayAll", (String) pReq.getClass().getDeclaredMethod("getxRayAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("xRayCheck", (String) pReq.getClass().getDeclaredMethod("getxRayCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("xRayDate", (String) pReq.getClass().getDeclaredMethod("getxRayDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ultraSoundAll", (String) pReq.getClass().getDeclaredMethod("getUltraSoundAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ultraSoundCheck", (String) pReq.getClass().getDeclaredMethod("getUltraSoundCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ultraSoundDate", (String) pReq.getClass().getDeclaredMethod("getUltraSoundDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ctAll", (String) pReq.getClass().getDeclaredMethod("getCtAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ctCheck", (String) pReq.getClass().getDeclaredMethod("getCtCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ctDate", (String) pReq.getClass().getDeclaredMethod("getCtDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("mriAll", (String) pReq.getClass().getDeclaredMethod("getMriAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("mriCheck", (String) pReq.getClass().getDeclaredMethod("getMriCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("mriDate", (String) pReq.getClass().getDeclaredMethod("getMriDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("reportAll", (String) pReq.getClass().getDeclaredMethod("getReportAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("reportCheck", (String) pReq.getClass().getDeclaredMethod("getReportCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("reportDate", (String) pReq.getClass().getDeclaredMethod("getReportDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("labAll", (String) pReq.getClass().getDeclaredMethod("getLabAll").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("labCheck", (String) pReq.getClass().getDeclaredMethod("getLabCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("labDate", (String) pReq.getClass().getDeclaredMethod("getLabDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("otherCheck", (String) pReq.getClass().getDeclaredMethod("getOtherCheck").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("otherComment", (String) pReq.getClass().getDeclaredMethod("getOtherComment").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ask", (String) pReq.getClass().getDeclaredMethod("getAsk").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("phone", (String) pReq.getClass().getDeclaredMethod("getPhone").invoke(pReq, null));
						fieldList.add(field);
						
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}
					
				}
					
			}
		}
		
		return form;
	}

	public String getClaimLastModified() {
		return claimLastModified;
	}

	public void setClaimLastModified(String claimLastModified) {
		this.claimLastModified = claimLastModified;
	}

	public String getClaimName() {
		return claimName;
	}

	public void setClaimName(String claimName) {
		this.claimName = claimName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getOfficeCode() {
		return officeCode;
	}

	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getHospitalDate() {
		return hospitalDate;
	}

	public void setHospitalDate(String hospitalDate) {
		this.hospitalDate = hospitalDate;
	}

	public String getDisChargeDate() {
		return disChargeDate;
	}

	public void setDisChargeDate(String disChargeDate) {
		this.disChargeDate = disChargeDate;
	}

	public String getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getResultDesc() {
		return resultDesc;
	}

	public void setResultDesc(String resultDesc) {
		this.resultDesc = resultDesc;
	}

	public String getMemoText() {
		return memoText;
	}

	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}

	public String getPendingDate() {
		return pendingDate;
	}

	public String getClaimName2() {
		return ClaimName2;
	}

	public String getHn() {
		return hn;
	}

	public String getAn() {
		return an;
	}

	public String getHeadOpd() {
		return headOpd;
	}

	public String getOpdAll() {
		return opdAll;
	}

	public String getOpdDate() {
		return opdDate;
	}

	public void setPendingDate(String pendingDate) {
		this.pendingDate = pendingDate;
	}

	public void setClaimName2(String claimName2) {
		ClaimName2 = claimName2;
	}

	public void setHn(String hn) {
		this.hn = hn;
	}

	public void setAn(String an) {
		this.an = an;
	}

	public void setHeadOpd(String headOpd) {
		this.headOpd = headOpd;
	}

	public void setOpdAll(String opdAll) {
		this.opdAll = opdAll;
	}

	public void setOpdDate(String opdDate) {
		this.opdDate = opdDate;
	}

	public String getOpdDateStart() {
		return opdDateStart;
	}

	public String getHeadIpd() {
		return headIpd;
	}

	public String getIpdDateStart() {
		return ipdDateStart;
	}

	public String getIpdDateEnd() {
		return ipdDateEnd;
	}

	public String getAdmissionNote() {
		return admissionNote;
	}

	public String getSummaryDis() {
		return summaryDis;
	}

	public String getDoctorOrder() {
		return doctorOrder;
	}

	public String getProGressNote() {
		return proGressNote;
	}

	public String getCraphicChart() {
		return craphicChart;
	}

	public String getOperationNote() {
		return operationNote;
	}

	public String getNurseNote() {
		return nurseNote;
	}

	public String getMedician() {
		return medician;
	}

	public String getReport() {
		return report;
	}

	public String getxRayAll() {
		return xRayAll;
	}

	public String getxRayCheck() {
		return xRayCheck;
	}

	public String getxRayDate() {
		return xRayDate;
	}

	public String getUltraSoundAll() {
		return ultraSoundAll;
	}

	public String getUltraSoundCheck() {
		return ultraSoundCheck;
	}

	public String getUltraSoundDate() {
		return ultraSoundDate;
	}

	public String getCtAll() {
		return ctAll;
	}

	public String getCtCheck() {
		return ctCheck;
	}

	public String getCtDate() {
		return ctDate;
	}

	public String getMriAll() {
		return mriAll;
	}

	public String getMriCheck() {
		return mriCheck;
	}

	public String getMriDate() {
		return mriDate;
	}

	public String getReportAll() {
		return reportAll;
	}

	public String getReportCheck() {
		return reportCheck;
	}

	public String getReportDate() {
		return reportDate;
	}

	public String getLabAll() {
		return labAll;
	}

	public String getLabCheck() {
		return labCheck;
	}

	public String getLabDate() {
		return labDate;
	}

	public String getOtherCheck() {
		return otherCheck;
	}

	public String getOtherComment() {
		return otherComment;
	}

	public String getAsk() {
		return ask;
	}

	public String getPhone() {
		return phone;
	}

	public void setOpdDateStart(String opdDateStart) {
		this.opdDateStart = opdDateStart;
	}

	public void setHeadIpd(String headIpd) {
		this.headIpd = headIpd;
	}

	public void setIpdDateStart(String ipdDateStart) {
		this.ipdDateStart = ipdDateStart;
	}

	public void setIpdDateEnd(String ipdDateEnd) {
		this.ipdDateEnd = ipdDateEnd;
	}

	public void setAdmissionNote(String admissionNote) {
		this.admissionNote = admissionNote;
	}

	public void setSummaryDis(String summaryDis) {
		this.summaryDis = summaryDis;
	}

	public void setDoctorOrder(String doctorOrder) {
		this.doctorOrder = doctorOrder;
	}

	public void setProGressNote(String proGressNote) {
		this.proGressNote = proGressNote;
	}

	public void setCraphicChart(String craphicChart) {
		this.craphicChart = craphicChart;
	}

	public void setOperationNote(String operationNote) {
		this.operationNote = operationNote;
	}

	public void setNurseNote(String nurseNote) {
		this.nurseNote = nurseNote;
	}

	public void setMedician(String medician) {
		this.medician = medician;
	}

	public void setReport(String report) {
		this.report = report;
	}

	public void setxRayAll(String xRayAll) {
		this.xRayAll = xRayAll;
	}

	public void setxRayCheck(String xRayCheck) {
		this.xRayCheck = xRayCheck;
	}

	public void setxRayDate(String xRayDate) {
		this.xRayDate = xRayDate;
	}

	public void setUltraSoundAll(String ultraSoundAll) {
		this.ultraSoundAll = ultraSoundAll;
	}

	public void setUltraSoundCheck(String ultraSoundCheck) {
		this.ultraSoundCheck = ultraSoundCheck;
	}

	public void setUltraSoundDate(String ultraSoundDate) {
		this.ultraSoundDate = ultraSoundDate;
	}

	public void setCtAll(String ctAll) {
		this.ctAll = ctAll;
	}

	public void setCtCheck(String ctCheck) {
		this.ctCheck = ctCheck;
	}

	public void setCtDate(String ctDate) {
		this.ctDate = ctDate;
	}

	public void setMriAll(String mriAll) {
		this.mriAll = mriAll;
	}

	public void setMriCheck(String mriCheck) {
		this.mriCheck = mriCheck;
	}

	public void setMriDate(String mriDate) {
		this.mriDate = mriDate;
	}

	public void setReportAll(String reportAll) {
		this.reportAll = reportAll;
	}

	public void setReportCheck(String reportCheck) {
		this.reportCheck = reportCheck;
	}

	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public void setLabAll(String labAll) {
		this.labAll = labAll;
	}

	public void setLabCheck(String labCheck) {
		this.labCheck = labCheck;
	}

	public void setLabDate(String labDate) {
		this.labDate = labDate;
	}

	public void setOtherCheck(String otherCheck) {
		this.otherCheck = otherCheck;
	}

	public void setOtherComment(String otherComment) {
		this.otherComment = otherComment;
	}

	public void setAsk(String ask) {
		this.ask = ask;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	
	
	
}
