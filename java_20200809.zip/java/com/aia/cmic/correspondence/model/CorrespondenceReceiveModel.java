package com.aia.cmic.correspondence.model;

import java.util.Date;

public class CorrespondenceReceiveModel {
	
	private Date startDate;
	private Date endDate;
	private String claimNo;
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	
}
