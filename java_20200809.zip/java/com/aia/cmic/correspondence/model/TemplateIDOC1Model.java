package com.aia.cmic.correspondence.model;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import com.aia.cmic.xml.common.CONTENT;
import com.aia.cmic.xml.common.FIELD;
import com.aia.cmic.xml.common.FORM;

public class TemplateIDOC1Model extends CorrespondenceModel {

	private String claimLastModified;
	private String claimName;
	private String address1;
	private String address2;
	private String address3;
	private String address4;
	private String zipCode;
	private String assessor;
	private String comment;
	private String memoText;

	@Override
	public <T> FORM getObjectCorresponedence(CorrespondenceModel corrObject, List<T> objList) {

		Date keyCurrentCycleDate;
		String formId;
		String claimNo;
		String policyNo;
		String companyId;
		String userId;
		String userDept;
		String pendingCode;
		String subCorr;
		FORM form = null;

		if (corrObject instanceof TemplateIDOC1Model) {

			if (objList != null) {
				for (Object pReq : objList) {

					form = new FORM();
					CONTENT content = form.getContent();
					List<FIELD> fieldList = content.getField();
					FIELD field;

					try {

						// add Key 
						formId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getFormId").invoke(pReq, null);
						claimNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getClaimNo").invoke(pReq, null);
						policyNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPolicyNo").invoke(pReq, null);
						companyId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getCompanyId").invoke(pReq, null);
						pendingCode = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPendingCode").invoke(pReq, null);
						userId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserId").invoke(pReq, null);
						userDept = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserDept").invoke(pReq, null);
						keyCurrentCycleDate = (Date) pReq.getClass().getSuperclass().getDeclaredMethod("getKeyCurrentCycleDate").invoke(pReq, null);
						subCorr = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getSubCorr").invoke(pReq, null);
						form.setKey(addKey(formId, companyId, policyNo, pendingCode, keyCurrentCycleDate, userId, userDept, subCorr));

						// add Content
						field = addFieldContent("claimNo", claimNo);
						fieldList.add(field);
						field = addFieldContent("ClaimLastModified", (String) pReq.getClass().getDeclaredMethod("getClaimLastModified").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ClaimName", (String) pReq.getClass().getDeclaredMethod("getClaimName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Address1", (String) pReq.getClass().getDeclaredMethod("getAddress1").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Address2", (String) pReq.getClass().getDeclaredMethod("getAddress2").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Address3", (String) pReq.getClass().getDeclaredMethod("getAddress3").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Address4", (String) pReq.getClass().getDeclaredMethod("getAddress4").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ZipCode", (String) pReq.getClass().getDeclaredMethod("getZipCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Assessor", (String) pReq.getClass().getDeclaredMethod("getAssessor").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Comment", (String) pReq.getClass().getDeclaredMethod("getComment").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("MemoText", (String) pReq.getClass().getDeclaredMethod("getMemoText").invoke(pReq, null));
						fieldList.add(field);

					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}

				}

			}
		}

		System.out.println("form : " + form);
		return form;
	}

	public String getClaimLastModified() {
		return claimLastModified;
	}

	public void setClaimLastModified(String claimLastModified) {
		this.claimLastModified = claimLastModified;
	}

	public String getClaimName() {
		return claimName;
	}

	public void setClaimName(String claimName) {
		this.claimName = claimName;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getMemoText() {
		return memoText;
	}

	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}
	

}
