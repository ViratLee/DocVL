package com.aia.cmic.correspondence.model;

import java.util.ArrayList;
import java.util.List;

import com.aia.cmic.entity.Claim;
import com.aia.cmic.entity.ClaimRequirementInfo;
import com.aia.cmic.entity.Payee;
import com.aia.cmic.entity.Provider;

public class CorrespondenceRepositoryModel {

	private String claimNo;
	private Integer occurrence;
	private String formId;
	private String subCorr;
	private Claim claim;
	private List<ClaimRequirementInfo> claimRequirementInfo;
	private String comment;	
	private String memoText;
	private String userDept;
	private Provider provider;
	private Payee payee;
	
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public Integer getOccurrence() {
		return occurrence;
	}
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public Claim getClaim() {
		return claim;
	}
	
	public void setClaim(Claim claim) {
		this.claim = claim;
	}
	
	public String getSubCorr() {
		return subCorr;
	}
	
	public void setSubCorr(String subCorr) {
		this.subCorr = subCorr;
	}
	public List<ClaimRequirementInfo> getClaimRequirementInfo() {
		if (claimRequirementInfo == null) {
			claimRequirementInfo = new ArrayList<ClaimRequirementInfo>();
		}
		return claimRequirementInfo;
	}
	public void setClaimRequirementInfo(
			List<ClaimRequirementInfo> claimRequirementInfo) {
		this.claimRequirementInfo = claimRequirementInfo;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getMemoText() {
		return memoText;
	}
	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}
	public String getUserDept() {
		return userDept;
	}
	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}
	public Provider getProvider() {
		return provider;
	}
	public void setProvider(Provider provider) {
		this.provider = provider;
	}
	public Payee getPayee() {
		return payee;
	}
	public void setPayee(Payee payee) {
		this.payee = payee;
	}	

}
