package com.aia.cmic.correspondence.model;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import com.aia.cmic.xml.common.CONTENT;
import com.aia.cmic.xml.common.FIELD;
import com.aia.cmic.xml.common.FORM;

public class TemplateOCRModel extends CorrespondenceModel{
	
	private String policyNo;
	private String claimLastModified;
	private String claimName;
	private String dateTime;
	private String agentName;
	private String officeCode;
	private String agencyName;
	private String agencyCode;
	private String hospitalDate;
	private String disChargeDate;
	private String receiveDate;
	private String assessor;
	private String providerNameThai;
	private String memoText;
	private String insuredAge;
	
	private String policyNo1;
	private String policyNo2;
	private String policyNo3;
	private String policyNo4;
	private String ctr1;
	private String ctr2;
	private String ctr3;
	private String ctr4;
	
	private String riderShortPlanName1  ;
	private String riderShortPlanName2  ;
	private String riderShortPlanName3  ;
	private String riderShortPlanName4  ;
	private String riderShortPlanName5  ;
	private String riderShortPlanName6  ;
	private String riderShortPlanName7  ;
	private String riderShortPlanName8  ;
	private String riderShortPlanName9  ;
	private String riderShortPlanName10  ;
	
	private String riderShortPlanName11  ;
	private String riderShortPlanName12  ;
	private String riderShortPlanName13  ;
	private String riderShortPlanName14  ;
	private String riderShortPlanName15  ;
	private String riderShortPlanName16  ;
	private String riderShortPlanName17  ;
	private String riderShortPlanName18  ;
	private String riderShortPlanName19  ;
	private String riderShortPlanName20  ;
	
	private String riderShortPlanName21  ;
	private String riderShortPlanName22  ;
	private String riderShortPlanName23  ;
	private String riderShortPlanName24  ;
	private String riderShortPlanName25  ;
	private String riderShortPlanName26  ;
	private String riderShortPlanName27  ;
	private String riderShortPlanName28  ;
	private String riderShortPlanName29  ;
	private String riderShortPlanName30  ;
	
	private String riderShortPlanName31  ;
	private String riderShortPlanName32  ;
	private String date1  ;
	private String date2  ;
	private String date3  ;
	private String date4  ;
	private String hctHb1  ;
	private String hctHb2  ;
	private String hctHb3  ;
	private String hctHb4  ;
	
	private String totalBili1;  
	private String totalBili2 ; 
	private String totalBili3  ;
	private String totalBili4  ;
	private String totalPro1  ;
	private String totalPro2  ;
	private String totalPro3  ;
	private String totalPro4  ;
	private String alt1  ;
	private String alt2  ;
	
	private String alt3  ;
	private String alt4  ;
	private String ggt1  ;
	private String ggt2  ;
	private String ggt3  ;
	private String ggt4  ;
	private String proTime1;  
	private String proTime2 ; 
	private String proTime3 ;
	private String proTime4 ;
	
	private String proTimeTest1;  
	private String proTimeTest2; 
	private String proTimeTest3;  
	private String proTimeTest4; 
	private String tumorMarker1 ; 
	private String tumorMarker2  ;
	private String tumorMarker3  ;
	private String tumorMarker4  ;
	private String tumorMarker5  ;
	private String tumorMarker6  ;
	
	private String tumorMarker7  ;
	private String tumorMarker8  ;
	private String tumorMarker9  ;
	private String tumorMarker10  ;
	private String tumorMarker11  ;
	private String tumorMarker12  ;
	private String tumorMarker13  ;
	private String tumorMarker14  ;
	private String tumorMarker15  ;
	private String tumorMarker16  ;
	
	private String hiv1  ;
	private String hiv2  ;
	private String hiv3  ;
	private String hiv4  ;
	private String checkYes;  
	private String checkNo  ;
	private String comment  ;
	private String date ; 
	private String signed1  ;
	private String approvedDate1; 
	
	private String signed2  ;
	private String approvedDate2;  
	private String medicalConHisTextArea  ;
	private String ultrasoundTextArea  ;
	private String treatMentTextArea  ;
	private String accessorRecTextArea  ;
	private String approveDoctorTextArea  ;
	

	@Override
	public <T> FORM getObjectCorresponedence(CorrespondenceModel corrObject, List<T> objList) {
		// TODO Auto-generated method stub

		Date keyCurrentCycleDate;
		String formId;
		String claimNo;
		String policyNo;
		String companyId;
		String userId;
		String userDept;
		String pendingCode;
		String subCorr;

		FORM form = null;

		if (corrObject instanceof TemplateOCRModel) {

			if (objList != null) {
				for (Object pReq : objList) {

					form = new FORM();
					CONTENT content = form.getContent();
					List<FIELD> fieldList = content.getField();
					FIELD field;
				
					try {

						// add Key 
						formId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getFormId").invoke(pReq, null);
						claimNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getClaimNo").invoke(pReq, null);
						policyNo = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPolicyNo").invoke(pReq, null);
						pendingCode = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getPendingCode").invoke(pReq, null);
						companyId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getCompanyId").invoke(pReq, null);
						userId = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserId").invoke(pReq, null);
						userDept = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getUserDept").invoke(pReq, null);
						keyCurrentCycleDate = (Date) pReq.getClass().getSuperclass().getDeclaredMethod("getKeyCurrentCycleDate").invoke(pReq, null);
						subCorr = (String) pReq.getClass().getSuperclass().getDeclaredMethod("getSubCorr").invoke(pReq, null);
						form.setKey(addKey(formId, companyId, policyNo, pendingCode, keyCurrentCycleDate, userId, userDept, subCorr));

						// add Content
						field = addFieldContent("claimNo", claimNo);
						fieldList.add(field);
						field = addFieldContent("ClaimLastModified", (String) pReq.getClass().getDeclaredMethod("getClaimLastModified").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ClaimName", (String) pReq.getClass().getDeclaredMethod("getClaimName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DateTime", (String) pReq.getClass().getDeclaredMethod("getDateTime").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgentName", (String) pReq.getClass().getDeclaredMethod("getAgentName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("OfficeCode", (String) pReq.getClass().getDeclaredMethod("getOfficeCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyName", (String) pReq.getClass().getDeclaredMethod("getAgencyName").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("AgencyCode", (String) pReq.getClass().getDeclaredMethod("getAgencyCode").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("HospitalDate", (String) pReq.getClass().getDeclaredMethod("getHospitalDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("DisChargeDate", (String) pReq.getClass().getDeclaredMethod("getDisChargeDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ReceiveDate", (String) pReq.getClass().getDeclaredMethod("getReceiveDate").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("Assessor", (String) pReq.getClass().getDeclaredMethod("getAssessor").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("ProviderNameThai", (String) pReq.getClass().getDeclaredMethod("getProviderNameThai").invoke(pReq, null));
						fieldList.add(field);
						field = addFieldContent("MemoText", (String) pReq.getClass().getDeclaredMethod("getMemoText").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("insuredAge", (String) pReq.getClass().getDeclaredMethod("getInsuredAge").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("policyNo1", (String) pReq.getClass().getDeclaredMethod("getPolicyNo1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("policyNo2", (String) pReq.getClass().getDeclaredMethod("getPolicyNo2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("policyNo3", (String) pReq.getClass().getDeclaredMethod("getPolicyNo3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("policyNo4", (String) pReq.getClass().getDeclaredMethod("getPolicyNo4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ctr1", (String) pReq.getClass().getDeclaredMethod("getCtr1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ctr2", (String) pReq.getClass().getDeclaredMethod("getCtr2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ctr3", (String) pReq.getClass().getDeclaredMethod("getCtr3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ctr4", (String) pReq.getClass().getDeclaredMethod("getCtr4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName1", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName2", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName3", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName4", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName5", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName5").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName6", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName6").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName7", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName7").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName8", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName8").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName9", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName9").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName10", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName10").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName11", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName11").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName12", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName12").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName13", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName13").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName14", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName14").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName15", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName15").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName16", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName16").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName17", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName17").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName18", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName18").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName19", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName19").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName20", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName20").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName21", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName21").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName22", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName22").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName23", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName23").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName24", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName24").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName25", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName25").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName26", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName26").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName27", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName27").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName28", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName28").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName29", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName29").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName30", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName30").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName31", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName31").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("riderShortPlanName32", (String) pReq.getClass().getDeclaredMethod("getRiderShortPlanName32").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("date1", (String) pReq.getClass().getDeclaredMethod("getDate1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("date2", (String) pReq.getClass().getDeclaredMethod("getDate2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("date3", (String) pReq.getClass().getDeclaredMethod("getDate3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("date4", (String) pReq.getClass().getDeclaredMethod("getDate4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hctHb1", (String) pReq.getClass().getDeclaredMethod("getHctHb1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hctHb2", (String) pReq.getClass().getDeclaredMethod("getHctHb2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hctHb3", (String) pReq.getClass().getDeclaredMethod("getHctHb3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hctHb4", (String) pReq.getClass().getDeclaredMethod("getHctHb4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalBili1", (String) pReq.getClass().getDeclaredMethod("getTotalBili1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalBili2", (String) pReq.getClass().getDeclaredMethod("getTotalBili2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalBili3", (String) pReq.getClass().getDeclaredMethod("getTotalBili3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalBili4", (String) pReq.getClass().getDeclaredMethod("getTotalBili4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalPro1", (String) pReq.getClass().getDeclaredMethod("getTotalPro1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalPro2", (String) pReq.getClass().getDeclaredMethod("getTotalPro2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalPro3", (String) pReq.getClass().getDeclaredMethod("getTotalPro3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("totalPro4", (String) pReq.getClass().getDeclaredMethod("getTotalPro4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("alt1", (String) pReq.getClass().getDeclaredMethod("getAlt1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("alt2", (String) pReq.getClass().getDeclaredMethod("getAlt2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("alt3", (String) pReq.getClass().getDeclaredMethod("getAlt3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("alt4", (String) pReq.getClass().getDeclaredMethod("getAlt4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ggt1", (String) pReq.getClass().getDeclaredMethod("getGgt1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ggt2", (String) pReq.getClass().getDeclaredMethod("getGgt2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ggt3", (String) pReq.getClass().getDeclaredMethod("getGgt3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ggt4", (String) pReq.getClass().getDeclaredMethod("getGgt4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTime1", (String) pReq.getClass().getDeclaredMethod("getProTime1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTime2", (String) pReq.getClass().getDeclaredMethod("getProTime2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTime3", (String) pReq.getClass().getDeclaredMethod("getProTime3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTime4", (String) pReq.getClass().getDeclaredMethod("getProTime4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTimeTest1", (String) pReq.getClass().getDeclaredMethod("getProTimeTest1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTimeTest2", (String) pReq.getClass().getDeclaredMethod("getProTimeTest2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTimeTest3", (String) pReq.getClass().getDeclaredMethod("getProTimeTest3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("proTimeTest4", (String) pReq.getClass().getDeclaredMethod("getProTimeTest4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker1", (String) pReq.getClass().getDeclaredMethod("getTumorMarker1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker2", (String) pReq.getClass().getDeclaredMethod("getTumorMarker2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker3", (String) pReq.getClass().getDeclaredMethod("getTumorMarker3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker4", (String) pReq.getClass().getDeclaredMethod("getTumorMarker4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker5", (String) pReq.getClass().getDeclaredMethod("getTumorMarker5").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker6", (String) pReq.getClass().getDeclaredMethod("getTumorMarker6").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker7", (String) pReq.getClass().getDeclaredMethod("getTumorMarker7").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker8", (String) pReq.getClass().getDeclaredMethod("getTumorMarker8").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker9", (String) pReq.getClass().getDeclaredMethod("getTumorMarker9").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker10", (String) pReq.getClass().getDeclaredMethod("getTumorMarker10").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker11", (String) pReq.getClass().getDeclaredMethod("getTumorMarker11").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker12", (String) pReq.getClass().getDeclaredMethod("getTumorMarker12").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker13", (String) pReq.getClass().getDeclaredMethod("getTumorMarker13").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker14", (String) pReq.getClass().getDeclaredMethod("getTumorMarker14").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker15", (String) pReq.getClass().getDeclaredMethod("getTumorMarker15").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("tumorMarker16", (String) pReq.getClass().getDeclaredMethod("getTumorMarker16").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hiv1", (String) pReq.getClass().getDeclaredMethod("getHiv1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hiv2", (String) pReq.getClass().getDeclaredMethod("getHiv2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hiv3", (String) pReq.getClass().getDeclaredMethod("getHiv3").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("hiv4", (String) pReq.getClass().getDeclaredMethod("getHiv4").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("checkYes", (String) pReq.getClass().getDeclaredMethod("getCheckYes").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("checkNo", (String) pReq.getClass().getDeclaredMethod("getCheckNo").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("comment", (String) pReq.getClass().getDeclaredMethod("getComment").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("date", (String) pReq.getClass().getDeclaredMethod("getDate").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("signed1", (String) pReq.getClass().getDeclaredMethod("getSigned1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("approvedDate1", (String) pReq.getClass().getDeclaredMethod("getApprovedDate1").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("signed2", (String) pReq.getClass().getDeclaredMethod("getSigned2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("approvedDate2", (String) pReq.getClass().getDeclaredMethod("getApprovedDate2").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("medicalConHisTextArea", (String) pReq.getClass().getDeclaredMethod("getMedicalConHisTextArea").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("ultrasoundTextArea", (String) pReq.getClass().getDeclaredMethod("getUltrasoundTextArea").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("treatMentTextArea", (String) pReq.getClass().getDeclaredMethod("getTreatMentTextArea").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("accessorRecTextArea", (String) pReq.getClass().getDeclaredMethod("getAccessorRecTextArea").invoke(pReq, null));
						fieldList.add(field);
						
						field = addFieldContent("approveDoctorTextArea", (String) pReq.getClass().getDeclaredMethod("getApproveDoctorTextArea").invoke(pReq, null));
						fieldList.add(field);
						
					
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}

				}

			}
		}

		return form;

	}

	public String getClaimName() {
		return claimName;
	}


	public String getInsuredAge() {
		return insuredAge;
	}


	public void setClaimName(String claimName) {
		this.claimName = claimName;
	}


	public void setInsuredAge(String insuredAge) {
		this.insuredAge = insuredAge;
	}

	public String getClaimLastModified() {
		return claimLastModified;
	}

	public String getDateTime() {
		return dateTime;
	}

	public String getAgentName() {
		return agentName;
	}

	public String getOfficeCode() {
		return officeCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public String getHospitalDate() {
		return hospitalDate;
	}

	public String getDisChargeDate() {
		return disChargeDate;
	}

	public String getReceiveDate() {
		return receiveDate;
	}

	public String getAssessor() {
		return assessor;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public String getMemoText() {
		return memoText;
	}

	public void setClaimLastModified(String claimLastModified) {
		this.claimLastModified = claimLastModified;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public void setHospitalDate(String hospitalDate) {
		this.hospitalDate = hospitalDate;
	}

	public void setDisChargeDate(String disChargeDate) {
		this.disChargeDate = disChargeDate;
	}

	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicyNo1() {
		return policyNo1;
	}

	public void setPolicyNo1(String policyNo1) {
		this.policyNo1 = policyNo1;
	}

	public String getPolicyNo2() {
		return policyNo2;
	}

	public void setPolicyNo2(String policyNo2) {
		this.policyNo2 = policyNo2;
	}

	public String getPolicyNo3() {
		return policyNo3;
	}

	public void setPolicyNo3(String policyNo3) {
		this.policyNo3 = policyNo3;
	}

	public String getPolicyNo4() {
		return policyNo4;
	}

	public void setPolicyNo4(String policyNo4) {
		this.policyNo4 = policyNo4;
	}

	public String getCtr1() {
		return ctr1;
	}

	public void setCtr1(String ctr1) {
		this.ctr1 = ctr1;
	}

	public String getCtr2() {
		return ctr2;
	}

	public void setCtr2(String ctr2) {
		this.ctr2 = ctr2;
	}

	public String getCtr3() {
		return ctr3;
	}

	public void setCtr3(String ctr3) {
		this.ctr3 = ctr3;
	}

	public String getCtr4() {
		return ctr4;
	}

	public void setCtr4(String ctr4) {
		this.ctr4 = ctr4;
	}

	public String getRiderShortPlanName1() {
		return riderShortPlanName1;
	}

	public void setRiderShortPlanName1(String riderShortPlanName1) {
		this.riderShortPlanName1 = riderShortPlanName1;
	}

	public String getRiderShortPlanName2() {
		return riderShortPlanName2;
	}

	public void setRiderShortPlanName2(String riderShortPlanName2) {
		this.riderShortPlanName2 = riderShortPlanName2;
	}

	public String getRiderShortPlanName3() {
		return riderShortPlanName3;
	}

	public void setRiderShortPlanName3(String riderShortPlanName3) {
		this.riderShortPlanName3 = riderShortPlanName3;
	}

	public String getRiderShortPlanName4() {
		return riderShortPlanName4;
	}

	public void setRiderShortPlanName4(String riderShortPlanName4) {
		this.riderShortPlanName4 = riderShortPlanName4;
	}

	public String getRiderShortPlanName5() {
		return riderShortPlanName5;
	}

	public void setRiderShortPlanName5(String riderShortPlanName5) {
		this.riderShortPlanName5 = riderShortPlanName5;
	}

	public String getRiderShortPlanName6() {
		return riderShortPlanName6;
	}

	public void setRiderShortPlanName6(String riderShortPlanName6) {
		this.riderShortPlanName6 = riderShortPlanName6;
	}

	public String getRiderShortPlanName7() {
		return riderShortPlanName7;
	}

	public void setRiderShortPlanName7(String riderShortPlanName7) {
		this.riderShortPlanName7 = riderShortPlanName7;
	}

	public String getRiderShortPlanName8() {
		return riderShortPlanName8;
	}

	public void setRiderShortPlanName8(String riderShortPlanName8) {
		this.riderShortPlanName8 = riderShortPlanName8;
	}

	public String getRiderShortPlanName9() {
		return riderShortPlanName9;
	}

	public void setRiderShortPlanName9(String riderShortPlanName9) {
		this.riderShortPlanName9 = riderShortPlanName9;
	}

	public String getRiderShortPlanName10() {
		return riderShortPlanName10;
	}

	public void setRiderShortPlanName10(String riderShortPlanName10) {
		this.riderShortPlanName10 = riderShortPlanName10;
	}

	public String getRiderShortPlanName11() {
		return riderShortPlanName11;
	}

	public void setRiderShortPlanName11(String riderShortPlanName11) {
		this.riderShortPlanName11 = riderShortPlanName11;
	}

	public String getRiderShortPlanName12() {
		return riderShortPlanName12;
	}

	public void setRiderShortPlanName12(String riderShortPlanName12) {
		this.riderShortPlanName12 = riderShortPlanName12;
	}

	public String getRiderShortPlanName13() {
		return riderShortPlanName13;
	}

	public void setRiderShortPlanName13(String riderShortPlanName13) {
		this.riderShortPlanName13 = riderShortPlanName13;
	}

	public String getRiderShortPlanName14() {
		return riderShortPlanName14;
	}

	public void setRiderShortPlanName14(String riderShortPlanName14) {
		this.riderShortPlanName14 = riderShortPlanName14;
	}

	public String getRiderShortPlanName15() {
		return riderShortPlanName15;
	}

	public void setRiderShortPlanName15(String riderShortPlanName15) {
		this.riderShortPlanName15 = riderShortPlanName15;
	}

	public String getRiderShortPlanName16() {
		return riderShortPlanName16;
	}

	public void setRiderShortPlanName16(String riderShortPlanName16) {
		this.riderShortPlanName16 = riderShortPlanName16;
	}

	public String getRiderShortPlanName17() {
		return riderShortPlanName17;
	}

	public void setRiderShortPlanName17(String riderShortPlanName17) {
		this.riderShortPlanName17 = riderShortPlanName17;
	}

	public String getRiderShortPlanName18() {
		return riderShortPlanName18;
	}

	public void setRiderShortPlanName18(String riderShortPlanName18) {
		this.riderShortPlanName18 = riderShortPlanName18;
	}

	public String getRiderShortPlanName19() {
		return riderShortPlanName19;
	}

	public void setRiderShortPlanName19(String riderShortPlanName19) {
		this.riderShortPlanName19 = riderShortPlanName19;
	}

	public String getRiderShortPlanName20() {
		return riderShortPlanName20;
	}

	public void setRiderShortPlanName20(String riderShortPlanName20) {
		this.riderShortPlanName20 = riderShortPlanName20;
	}

	public String getRiderShortPlanName21() {
		return riderShortPlanName21;
	}

	public void setRiderShortPlanName21(String riderShortPlanName21) {
		this.riderShortPlanName21 = riderShortPlanName21;
	}

	public String getRiderShortPlanName22() {
		return riderShortPlanName22;
	}

	public void setRiderShortPlanName22(String riderShortPlanName22) {
		this.riderShortPlanName22 = riderShortPlanName22;
	}

	public String getRiderShortPlanName23() {
		return riderShortPlanName23;
	}

	public void setRiderShortPlanName23(String riderShortPlanName23) {
		this.riderShortPlanName23 = riderShortPlanName23;
	}

	public String getRiderShortPlanName24() {
		return riderShortPlanName24;
	}

	public void setRiderShortPlanName24(String riderShortPlanName24) {
		this.riderShortPlanName24 = riderShortPlanName24;
	}

	public String getRiderShortPlanName25() {
		return riderShortPlanName25;
	}

	public void setRiderShortPlanName25(String riderShortPlanName25) {
		this.riderShortPlanName25 = riderShortPlanName25;
	}

	public String getRiderShortPlanName26() {
		return riderShortPlanName26;
	}

	public void setRiderShortPlanName26(String riderShortPlanName26) {
		this.riderShortPlanName26 = riderShortPlanName26;
	}

	public String getRiderShortPlanName27() {
		return riderShortPlanName27;
	}

	public void setRiderShortPlanName27(String riderShortPlanName27) {
		this.riderShortPlanName27 = riderShortPlanName27;
	}

	public String getRiderShortPlanName28() {
		return riderShortPlanName28;
	}

	public void setRiderShortPlanName28(String riderShortPlanName28) {
		this.riderShortPlanName28 = riderShortPlanName28;
	}

	public String getRiderShortPlanName29() {
		return riderShortPlanName29;
	}

	public void setRiderShortPlanName29(String riderShortPlanName29) {
		this.riderShortPlanName29 = riderShortPlanName29;
	}

	public String getRiderShortPlanName30() {
		return riderShortPlanName30;
	}

	public void setRiderShortPlanName30(String riderShortPlanName30) {
		this.riderShortPlanName30 = riderShortPlanName30;
	}

	public String getRiderShortPlanName31() {
		return riderShortPlanName31;
	}

	public void setRiderShortPlanName31(String riderShortPlanName31) {
		this.riderShortPlanName31 = riderShortPlanName31;
	}

	public String getRiderShortPlanName32() {
		return riderShortPlanName32;
	}

	public void setRiderShortPlanName32(String riderShortPlanName32) {
		this.riderShortPlanName32 = riderShortPlanName32;
	}

	public String getDate1() {
		return date1;
	}

	public void setDate1(String date1) {
		this.date1 = date1;
	}

	public String getDate2() {
		return date2;
	}

	public void setDate2(String date2) {
		this.date2 = date2;
	}

	public String getDate3() {
		return date3;
	}

	public void setDate3(String date3) {
		this.date3 = date3;
	}

	public String getDate4() {
		return date4;
	}

	public void setDate4(String date4) {
		this.date4 = date4;
	}

	public String getHctHb1() {
		return hctHb1;
	}

	public void setHctHb1(String hctHb1) {
		this.hctHb1 = hctHb1;
	}

	public String getHctHb2() {
		return hctHb2;
	}

	public void setHctHb2(String hctHb2) {
		this.hctHb2 = hctHb2;
	}

	public String getHctHb3() {
		return hctHb3;
	}

	public void setHctHb3(String hctHb3) {
		this.hctHb3 = hctHb3;
	}

	public String getHctHb4() {
		return hctHb4;
	}

	public void setHctHb4(String hctHb4) {
		this.hctHb4 = hctHb4;
	}

	public String getTotalBili1() {
		return totalBili1;
	}

	public void setTotalBili1(String totalBili1) {
		this.totalBili1 = totalBili1;
	}

	public String getTotalBili2() {
		return totalBili2;
	}

	public void setTotalBili2(String totalBili2) {
		this.totalBili2 = totalBili2;
	}

	public String getTotalBili3() {
		return totalBili3;
	}

	public void setTotalBili3(String totalBili3) {
		this.totalBili3 = totalBili3;
	}

	public String getTotalBili4() {
		return totalBili4;
	}

	public void setTotalBili4(String totalBili4) {
		this.totalBili4 = totalBili4;
	}

	public String getTotalPro1() {
		return totalPro1;
	}

	public void setTotalPro1(String totalPro1) {
		this.totalPro1 = totalPro1;
	}

	public String getTotalPro2() {
		return totalPro2;
	}

	public void setTotalPro2(String totalPro2) {
		this.totalPro2 = totalPro2;
	}

	public String getTotalPro3() {
		return totalPro3;
	}

	public void setTotalPro3(String totalPro3) {
		this.totalPro3 = totalPro3;
	}

	public String getTotalPro4() {
		return totalPro4;
	}

	public void setTotalPro4(String totalPro4) {
		this.totalPro4 = totalPro4;
	}

	public String getAlt1() {
		return alt1;
	}

	public void setAlt1(String alt1) {
		this.alt1 = alt1;
	}

	public String getAlt2() {
		return alt2;
	}

	public void setAlt2(String alt2) {
		this.alt2 = alt2;
	}

	public String getAlt3() {
		return alt3;
	}

	public void setAlt3(String alt3) {
		this.alt3 = alt3;
	}

	public String getAlt4() {
		return alt4;
	}

	public void setAlt4(String alt4) {
		this.alt4 = alt4;
	}

	public String getGgt1() {
		return ggt1;
	}

	public void setGgt1(String ggt1) {
		this.ggt1 = ggt1;
	}

	public String getGgt2() {
		return ggt2;
	}

	public void setGgt2(String ggt2) {
		this.ggt2 = ggt2;
	}

	public String getGgt3() {
		return ggt3;
	}

	public void setGgt3(String ggt3) {
		this.ggt3 = ggt3;
	}

	public String getGgt4() {
		return ggt4;
	}

	public void setGgt4(String ggt4) {
		this.ggt4 = ggt4;
	}

	public String getProTime1() {
		return proTime1;
	}

	public void setProTime1(String proTime1) {
		this.proTime1 = proTime1;
	}

	public String getProTime2() {
		return proTime2;
	}

	public void setProTime2(String proTime2) {
		this.proTime2 = proTime2;
	}

	public String getProTime3() {
		return proTime3;
	}

	public void setProTime3(String proTime3) {
		this.proTime3 = proTime3;
	}

	public String getProTime4() {
		return proTime4;
	}

	public void setProTime4(String proTime4) {
		this.proTime4 = proTime4;
	}

	public String getProTimeTest1() {
		return proTimeTest1;
	}

	public void setProTimeTest1(String proTimeTest1) {
		this.proTimeTest1 = proTimeTest1;
	}

	public String getProTimeTest2() {
		return proTimeTest2;
	}

	public void setProTimeTest2(String proTimeTest2) {
		this.proTimeTest2 = proTimeTest2;
	}

	public String getProTimeTest3() {
		return proTimeTest3;
	}

	public void setProTimeTest3(String proTimeTest3) {
		this.proTimeTest3 = proTimeTest3;
	}

	public String getProTimeTest4() {
		return proTimeTest4;
	}

	public void setProTimeTest4(String proTimeTest4) {
		this.proTimeTest4 = proTimeTest4;
	}

	public String getTumorMarker1() {
		return tumorMarker1;
	}

	public void setTumorMarker1(String tumorMarker1) {
		this.tumorMarker1 = tumorMarker1;
	}

	public String getTumorMarker2() {
		return tumorMarker2;
	}

	public void setTumorMarker2(String tumorMarker2) {
		this.tumorMarker2 = tumorMarker2;
	}

	public String getTumorMarker3() {
		return tumorMarker3;
	}

	public void setTumorMarker3(String tumorMarker3) {
		this.tumorMarker3 = tumorMarker3;
	}

	public String getTumorMarker4() {
		return tumorMarker4;
	}

	public void setTumorMarker4(String tumorMarker4) {
		this.tumorMarker4 = tumorMarker4;
	}

	public String getTumorMarker5() {
		return tumorMarker5;
	}

	public void setTumorMarker5(String tumorMarker5) {
		this.tumorMarker5 = tumorMarker5;
	}

	public String getTumorMarker6() {
		return tumorMarker6;
	}

	public void setTumorMarker6(String tumorMarker6) {
		this.tumorMarker6 = tumorMarker6;
	}

	public String getTumorMarker7() {
		return tumorMarker7;
	}

	public void setTumorMarker7(String tumorMarker7) {
		this.tumorMarker7 = tumorMarker7;
	}

	public String getTumorMarker8() {
		return tumorMarker8;
	}

	public void setTumorMarker8(String tumorMarker8) {
		this.tumorMarker8 = tumorMarker8;
	}

	public String getTumorMarker9() {
		return tumorMarker9;
	}

	public void setTumorMarker9(String tumorMarker9) {
		this.tumorMarker9 = tumorMarker9;
	}

	public String getTumorMarker10() {
		return tumorMarker10;
	}

	public void setTumorMarker10(String tumorMarker10) {
		this.tumorMarker10 = tumorMarker10;
	}

	public String getTumorMarker11() {
		return tumorMarker11;
	}

	public void setTumorMarker11(String tumorMarker11) {
		this.tumorMarker11 = tumorMarker11;
	}

	public String getTumorMarker12() {
		return tumorMarker12;
	}

	public void setTumorMarker12(String tumorMarker12) {
		this.tumorMarker12 = tumorMarker12;
	}

	public String getTumorMarker13() {
		return tumorMarker13;
	}

	public void setTumorMarker13(String tumorMarker13) {
		this.tumorMarker13 = tumorMarker13;
	}

	public String getTumorMarker14() {
		return tumorMarker14;
	}

	public void setTumorMarker14(String tumorMarker14) {
		this.tumorMarker14 = tumorMarker14;
	}

	public String getTumorMarker15() {
		return tumorMarker15;
	}

	public void setTumorMarker15(String tumorMarker15) {
		this.tumorMarker15 = tumorMarker15;
	}

	public String getTumorMarker16() {
		return tumorMarker16;
	}

	public void setTumorMarker16(String tumorMarker16) {
		this.tumorMarker16 = tumorMarker16;
	}

	public String getHiv1() {
		return hiv1;
	}

	public void setHiv1(String hiv1) {
		this.hiv1 = hiv1;
	}

	public String getHiv2() {
		return hiv2;
	}

	public void setHiv2(String hiv2) {
		this.hiv2 = hiv2;
	}

	public String getHiv3() {
		return hiv3;
	}

	public void setHiv3(String hiv3) {
		this.hiv3 = hiv3;
	}

	public String getHiv4() {
		return hiv4;
	}

	public void setHiv4(String hiv4) {
		this.hiv4 = hiv4;
	}

	public String getCheckYes() {
		return checkYes;
	}

	public void setCheckYes(String checkYes) {
		this.checkYes = checkYes;
	}

	public String getCheckNo() {
		return checkNo;
	}

	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getSigned1() {
		return signed1;
	}

	public void setSigned1(String signed1) {
		this.signed1 = signed1;
	}

	public String getApprovedDate1() {
		return approvedDate1;
	}

	public void setApprovedDate1(String approvedDate1) {
		this.approvedDate1 = approvedDate1;
	}

	public String getSigned2() {
		return signed2;
	}

	public void setSigned2(String signed2) {
		this.signed2 = signed2;
	}

	public String getApprovedDate2() {
		return approvedDate2;
	}

	public void setApprovedDate2(String approvedDate2) {
		this.approvedDate2 = approvedDate2;
	}

	public String getMedicalConHisTextArea() {
		return medicalConHisTextArea;
	}

	public void setMedicalConHisTextArea(String medicalConHisTextArea) {
		this.medicalConHisTextArea = medicalConHisTextArea;
	}

	public String getUltrasoundTextArea() {
		return ultrasoundTextArea;
	}

	public void setUltrasoundTextArea(String ultrasoundTextArea) {
		this.ultrasoundTextArea = ultrasoundTextArea;
	}

	public String getTreatMentTextArea() {
		return treatMentTextArea;
	}

	public void setTreatMentTextArea(String treatMentTextArea) {
		this.treatMentTextArea = treatMentTextArea;
	}

	public String getAccessorRecTextArea() {
		return accessorRecTextArea;
	}

	public void setAccessorRecTextArea(String accessorRecTextArea) {
		this.accessorRecTextArea = accessorRecTextArea;
	}

	public String getApproveDoctorTextArea() {
		return approveDoctorTextArea;
	}

	public void setApproveDoctorTextArea(String approveDoctorTextArea) {
		this.approveDoctorTextArea = approveDoctorTextArea;
	}
	
	
}
