package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProviderContacts", query = "select myProviderContact from ProviderContact myProviderContact"),
		@NamedQuery(name = "findProviderContactByAddressLine1", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.addressLine1 = ?1"),
		@NamedQuery(name = "findProviderContactByAddressLine1Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.addressLine1 like ?1"),
		@NamedQuery(name = "findProviderContactByAddressLine2", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.addressLine2 = ?1"),
		@NamedQuery(name = "findProviderContactByAddressLine2Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.addressLine2 like ?1"),
		@NamedQuery(name = "findProviderContactByAddressLine3", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.addressLine3 = ?1"),
		@NamedQuery(name = "findProviderContactByAddressLine3Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.addressLine3 like ?1"),
		@NamedQuery(name = "findProviderContactByAreaCode", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.areaCode = ?1"),
		@NamedQuery(name = "findProviderContactByAreaCodeContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.areaCode like ?1"),
		@NamedQuery(name = "findProviderContactByCity", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.city = ?1"),
		@NamedQuery(name = "findProviderContactByCityContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.city like ?1"),
		@NamedQuery(name = "findProviderContactByContactType", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.contactType = ?1"),
		@NamedQuery(name = "findProviderContactByContactTypeContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.contactType like ?1"),
		@NamedQuery(name = "findProviderContactByCountry", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.country = ?1"),
		@NamedQuery(name = "findProviderContactByCountryContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.country like ?1"),
		@NamedQuery(name = "findProviderContactByDistrict", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.district = ?1"),
		@NamedQuery(name = "findProviderContactByDistrictContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.district like ?1"),
		@NamedQuery(name = "findProviderContactByEmailAddress1", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.emailAddress1 = ?1"),
		@NamedQuery(name = "findProviderContactByEmailAddress1Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.emailAddress1 like ?1"),
		@NamedQuery(name = "findProviderContactByEmailAddress2", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.emailAddress2 = ?1"),
		@NamedQuery(name = "findProviderContactByEmailAddress2Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.emailAddress2 like ?1"),
		@NamedQuery(name = "findProviderContactByFaxNo1", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.faxNo1 = ?1"),
		@NamedQuery(name = "findProviderContactByFaxNo1Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.faxNo1 like ?1"),
		@NamedQuery(name = "findProviderContactByFaxNo2", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.faxNo2 = ?1"),
		@NamedQuery(name = "findProviderContactByFaxNo2Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.faxNo2 like ?1"),
		@NamedQuery(name = "findProviderContactByFirstName", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.firstName = ?1"),
		@NamedQuery(name = "findProviderContactByFirstNameContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.firstName like ?1"),
		@NamedQuery(name = "findProviderContactByLastName", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.lastName = ?1"),
		@NamedQuery(name = "findProviderContactByLastNameContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.lastName like ?1"),
		@NamedQuery(name = "findProviderContactByLatitude", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.latitude = ?1"),
		@NamedQuery(name = "findProviderContactByLongitude", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.longitude = ?1"),
		@NamedQuery(name = "findProviderContactByPhoneNo1", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.phoneNo1 = ?1"),
		@NamedQuery(name = "findProviderContactByPhoneNo1Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.phoneNo1 like ?1"),
		@NamedQuery(name = "findProviderContactByPhoneNo2", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.phoneNo2 = ?1"),
		@NamedQuery(name = "findProviderContactByPhoneNo2Containing", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.phoneNo2 like ?1"),
		@NamedQuery(name = "findProviderContactByDoctorCode", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.doctorCode = ?1"),
		@NamedQuery(name = "findProviderContactByPostalCode", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.postalCode = ?1"),
		@NamedQuery(name = "findProviderContactByPostalCodeContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.postalCode like ?1"),
		@NamedQuery(name = "findProviderContactByPrimaryKey", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.providerContactId = ?1"),
		@NamedQuery(name = "findProviderContactByProviderContactId", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.providerContactId = ?1"),
		@NamedQuery(name = "findProviderContactByProviderCode", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.providerCode = ?1"),
		@NamedQuery(name = "findProviderContactByProvince", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.province = ?1"),
		@NamedQuery(name = "findProviderContactByProvinceContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.province like ?1"),
		@NamedQuery(name = "findProviderContactByRegion", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.region = ?1"),
		@NamedQuery(name = "findProviderContactByRegionContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.region like ?1"),
		@NamedQuery(name = "findProviderContactByWebsite", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.website = ?1"),
		@NamedQuery(name = "findProviderContactByWebsiteContaining", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.website like ?1"),
		@NamedQuery(name = "findProviderContactByProviderCodeAndContactType", query = "select myProviderContact from ProviderContact myProviderContact where myProviderContact.providerCode = ?1 and myProviderContact.contactType= ?2"), })
@Table(name = "PROVIDERCONTACT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderContact")
public class ProviderContact extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "providerContactSequence")
	@SequenceGenerator(name = "providerContactSequence", sequenceName = "s_providercontact")
	@Column(name = "PROVIDERCONTACTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long providerContactId;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "DOCTORCODE", length = 13)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doctorCode;
	/**
	 */

	@Column(name = "CONTACTTYPE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String contactType;
	/**
	 */

	@Column(name = "FIRSTNAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	/**
	 */

	@Column(name = "LASTNAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	/**
	 */

	@Column(name = "ADDRESSLINE1")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;
	/**
	 */

	@Column(name = "ADDRESSLINE2")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;
	/**
	 */

	@Column(name = "ADDRESSLINE3")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;
	/**
	 */

	@Column(name = "DISTRICT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String district;
	/**
	 */

	@Column(name = "CITY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String city;
	/**
	 */

	@Column(name = "POSTALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postalCode;
	/**
	 */

	@Column(name = "AREACODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String areaCode;
	/**
	 */

	@Column(name = "REGION", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String region;
	/**
	 */

	@Column(name = "PROVINCE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String province;
	/**
	 */

	@Column(name = "COUNTRY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String country;
	/**
	 */

	@Column(name = "WEBSITE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String website;
	/**
	 */

	@Column(name = "PHONENO1", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String phoneNo1;
	/**
	 */

	@Column(name = "PHONENO2", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String phoneNo2;
	/**
	 */

	@Column(name = "FAXNO1", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String faxNo1;
	/**
	 */

	@Column(name = "FAXNO2", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String faxNo2;
	/**
	 */

	@Column(name = "EMAILADDRESS1", length = 60)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String emailAddress1;
	/**
	 */

	@Column(name = "EMAILADDRESS2", length = 60)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String emailAddress2;
	/**
	 */

	@Column(name = "LATITUDE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String latitude;
	/**
	 */

	@Column(name = "LONGITUDE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String longitude;

	@Column(name = "DEPARTMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String department;

	@Column(name = "WORKINGHOURS", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String workingHours;

	/**
	 */
	public void setProviderContactId(Long providerContactId) {
		this.providerContactId = providerContactId;
	}

	/**
	 */
	public Long getProviderContactId() {
		return this.providerContactId;
	}

	/**
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 */
	public String getProviderCode() {
		return this.providerCode;
	}

	/**
	 */
	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	/**
	 */
	public String getDoctorCode() {
		return this.doctorCode;
	}

	/**
	 */
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	/**
	 */
	public String getContactType() {
		return this.contactType;
	}

	/**
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 */
	public String getAddressLine1() {
		return this.addressLine1;
	}

	/**
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 */
	public String getAddressLine2() {
		return this.addressLine2;
	}

	/**
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 */
	public String getAddressLine3() {
		return this.addressLine3;
	}

	/**
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 */
	public String getDistrict() {
		return this.district;
	}

	/**
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 */
	public String getCity() {
		return this.city;
	}

	/**
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 */
	public String getPostalCode() {
		return this.postalCode;
	}

	/**
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	/**
	 */
	public String getAreaCode() {
		return this.areaCode;
	}

	/**
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 */
	public String getRegion() {
		return this.region;
	}

	/**
	 */
	public void setProvince(String province) {
		this.province = province;
	}

	/**
	 */
	public String getProvince() {
		return this.province;
	}

	/**
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 */
	public String getCountry() {
		return this.country;
	}

	/**
	 */
	public void setWebsite(String website) {
		this.website = website;
	}

	/**
	 */
	public String getWebsite() {
		return this.website;
	}

	/**
	 */
	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	/**
	 */
	public String getPhoneNo1() {
		return this.phoneNo1;
	}

	/**
	 */
	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}

	/**
	 */
	public String getPhoneNo2() {
		return this.phoneNo2;
	}

	/**
	 */
	public void setFaxNo1(String faxNo1) {
		this.faxNo1 = faxNo1;
	}

	/**
	 */
	public String getFaxNo1() {
		return this.faxNo1;
	}

	/**
	 */
	public void setFaxNo2(String faxNo2) {
		this.faxNo2 = faxNo2;
	}

	/**
	 */
	public String getFaxNo2() {
		return this.faxNo2;
	}

	/**
	 */
	public void setEmailAddress1(String emailAddress1) {
		this.emailAddress1 = emailAddress1;
	}

	/**
	 */
	public String getEmailAddress1() {
		return this.emailAddress1;
	}

	/**
	 */
	public void setEmailAddress2(String emailAddress2) {
		this.emailAddress2 = emailAddress2;
	}

	/**
	 */
	public String getEmailAddress2() {
		return this.emailAddress2;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getWorkingHours() {
		return workingHours;
	}

	public void setWorkingHours(String workingHours) {
		this.workingHours = workingHours;
	}

	/**
	 */
	public ProviderContact() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProviderContact that) {
		setProviderContactId(that.getProviderContactId());
		setProviderCode(that.getProviderCode());
		setDoctorCode(that.getDoctorCode());
		setContactType(that.getContactType());
		setFirstName(that.getFirstName());
		setLastName(that.getLastName());
		setAddressLine1(that.getAddressLine1());
		setAddressLine2(that.getAddressLine2());
		setAddressLine3(that.getAddressLine3());
		setDistrict(that.getDistrict());
		setCity(that.getCity());
		setPostalCode(that.getPostalCode());
		setAreaCode(that.getAreaCode());
		setRegion(that.getRegion());
		setProvince(that.getProvince());
		setCountry(that.getCountry());
		setWebsite(that.getWebsite());
		setPhoneNo1(that.getPhoneNo1());
		setPhoneNo2(that.getPhoneNo2());
		setFaxNo1(that.getFaxNo1());
		setFaxNo2(that.getFaxNo2());
		setEmailAddress1(that.getEmailAddress1());
		setEmailAddress2(that.getEmailAddress2());
		setLatitude(that.getLatitude());
		setLongitude(that.getLongitude());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setDepartment(that.getDepartment());
		setWorkingHours(that.getWorkingHours());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("providerContactId=[").append(providerContactId).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("doctorCode=[").append(doctorCode).append("] ");
		buffer.append("contactType=[").append(contactType).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("addressLine1=[").append(addressLine1).append("] ");
		buffer.append("addressLine2=[").append(addressLine2).append("] ");
		buffer.append("addressLine3=[").append(addressLine3).append("] ");
		buffer.append("district=[").append(district).append("] ");
		buffer.append("city=[").append(city).append("] ");
		buffer.append("postalCode=[").append(postalCode).append("] ");
		buffer.append("areaCode=[").append(areaCode).append("] ");
		buffer.append("region=[").append(region).append("] ");
		buffer.append("province=[").append(province).append("] ");
		buffer.append("country=[").append(country).append("] ");
		buffer.append("website=[").append(website).append("] ");
		buffer.append("phoneNo1=[").append(phoneNo1).append("] ");
		buffer.append("phoneNo2=[").append(phoneNo2).append("] ");
		buffer.append("faxNo1=[").append(faxNo1).append("] ");
		buffer.append("faxNo2=[").append(faxNo2).append("] ");
		buffer.append("emailAddress1=[").append(emailAddress1).append("] ");
		buffer.append("emailAddress2=[").append(emailAddress2).append("] ");
		buffer.append("latitude=[").append(latitude).append("] ");
		buffer.append("longitude=[").append(longitude).append("] ");
		buffer.append("department=[").append(department).append("] ");
		buffer.append("workingHours=[").append(workingHours).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((providerContactId == null) ? 0 : providerContactId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProviderContact))
			return false;
		ProviderContact equalCheck = (ProviderContact) obj;
		if ((providerContactId == null && equalCheck.providerContactId != null) || (providerContactId != null && equalCheck.providerContactId == null))
			return false;
		if (providerContactId != null && !providerContactId.equals(equalCheck.providerContactId))
			return false;
		return true;
	}

}
