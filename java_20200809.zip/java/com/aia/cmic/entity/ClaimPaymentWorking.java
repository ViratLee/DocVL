package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.cxf.common.util.StringUtils;

import com.aia.cmic.model.PaymentAllocationTemp;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "removeClaimPaymentWorkingByClaimNoOccurence", query = "delete from ClaimPaymentWorking myClaimPaymentWorking where myClaimPaymentWorking.claimNo = ?1 and myClaimPaymentWorking.occurrence = ?2 and myClaimPaymentWorking.policyNo=?3 and myClaimPaymentWorking.planId=?4 and (myClaimPaymentWorking.planCoverageNo= ?5 or ?5 is null or ?5='') and (myClaimPaymentWorking.productCode= ?6 or ?6 is null or ?6='')"),
		@NamedQuery(name = "findClaimPaymentWorkingForWriteSettlement", query = "select myClaimPaymentWorking,myClaimPayment from ClaimPaymentWorking myClaimPaymentWorking,ClaimPayment myClaimPayment where myClaimPaymentWorking.companyId = ?1 and myClaimPaymentWorking.claimNo=?2 and myClaimPaymentWorking.occurrence=?3 and myClaimPaymentWorking.policyNo=?4 and (myClaimPaymentWorking.productCode=?5 or ?5 is null or ?5='') and myClaimPaymentWorking.planId=?6 and myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3 and myClaimPayment.policyNo=?4 and (myClaimPayment.productCode=?5 or ?5 is null or ?5='') and myClaimPayment.planId=?6 and (myClaimPaymentWorking.planCoverageNo= ?7 or ?7 is null or ?7='') and ( myClaimPayment.planCoverageNo= ?7 or ?7 is null or ?7='') and myClaimPayment.paymentStatus=?8 and myClaimPaymentWorking.eligibleAmt>0"),
		@NamedQuery(name = "findClaimPaymentWorkingByCompanyIdClaimNoAndOccurrence", query = "select myClaimPaymentWorking from ClaimPaymentWorking myClaimPaymentWorking where myClaimPaymentWorking.companyId = ?1 and myClaimPaymentWorking.claimNo=?2 and myClaimPaymentWorking.occurrence=?3"),
		@NamedQuery(name = "findClaimPaymentWorkingNoRelateToClaimPayment", query = "SELECT myClaimPaymentWorking FROM ClaimPaymentWorking myClaimPaymentWorking	WHERE myClaimPaymentWorking.companyId = ?1 AND myClaimPaymentWorking.claimNo = ?2 AND myClaimPaymentWorking.occurrence = ?3 AND NOT EXISTS (SELECT myClaimPayment FROM ClaimPayment myClaimPayment WHERE myClaimPayment.companyId = ?4 AND myClaimPayment.claimNo =?5 AND myClaimPayment.occurrence = ?6 AND myClaimPayment.planId = myClaimPaymentWorking.planId)"),
		@NamedQuery(name = "removeClaimPaymentWorkingByClaimPaymentWorkingId", query = "delete from ClaimPaymentWorking myClaimPaymentWorking where myClaimPaymentWorking.claimPaymentWorkingId = ?1") })
@Table(name = "CLAIMPAYMENTWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPaymentWorking")
public class ClaimPaymentWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaymentWorkingSequence")
	@SequenceGenerator(name = "claimPaymentWorkingSequence", sequenceName = "s_claimpaymentworking")
	@Column(name = "CLAIMPAYMENTWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPaymentWorkingId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productCode;
	/**
	 */

	@Column(name = "PRODUCTTYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productType;
	/**
	 */

	@Column(name = "BUSINESSLINE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	/**
	 */

	@Column(name = "PROCEDURECATID", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String procedureCatId;
	/**
	 */

	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	/**
	 */

	@Column(name = "SERVICECATID", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceCatId;
	/**
	 */

	@Column(name = "SEQID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer seqId;
	/**
	 */

	@Column(name = "PRESENTEDAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt;
	/**
	 */

	@Column(name = "ELIGIBLEAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal eligibleAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "NOOFDAYSALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysAllocated;
	/**
	 */

	@Column(name = "PERCENTAGEALLOCATED", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal percentageAllocated;
	/**
	 */

	@Column(name = "SHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal shortFallAmt;
	/**
	 */

	@Column(name = "REIMBURSEDDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer reimbursedDay;

	/**
	 */
	public void setClaimPaymentWorkingId(Long claimPaymentWorkingId) {
		this.claimPaymentWorkingId = claimPaymentWorkingId;
	}

	/**
	 */
	public Long getClaimPaymentWorkingId() {
		return this.claimPaymentWorkingId;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	/**
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 */
	public String getBusinessLine() {
		return this.businessLine;
	}

	/**
	 */
	public void setProcedureCatId(String procedureCatId) {
		this.procedureCatId = procedureCatId;
	}

	/**
	 */
	public String getProcedureCatId() {
		return this.procedureCatId;
	}

	/**
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 */
	public String getBenefitCode() {
		return this.benefitCode;
	}

	/**
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 */
	public String getServiceCatId() {
		return this.serviceCatId;
	}

	/**
	 */
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}

	/**
	 */
	public Integer getSeqId() {
		return this.seqId;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 */
	public BigDecimal getEligibleAmt() {
		return this.eligibleAmt;
	}

	/**
	 */
	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	/**
	 */
	public Integer getNoOfDaysAllocated() {
		return this.noOfDaysAllocated;
	}

	/**
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 */
	public BigDecimal getPercentageAllocated() {
		return this.percentageAllocated;
	}

	/**
	 */
	public void setShortFallAmt(BigDecimal shortFallAmt) {
		this.shortFallAmt = shortFallAmt;
	}

	/**
	 */
	public BigDecimal getShortFallAmt() {
		return this.shortFallAmt;
	}

	/**
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	/**
	 */
	public Integer getReimbursedDay() {
		return this.reimbursedDay;
	}

	/**
	 */
	public ClaimPaymentWorking() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPaymentWorking that) {
		setClaimPaymentWorkingId(that.getClaimPaymentWorkingId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setBusinessLine(that.getBusinessLine());
		setProcedureCatId(that.getProcedureCatId());
		setBenefitCode(that.getBenefitCode());
		setServiceCatId(that.getServiceCatId());
		setSeqId(that.getSeqId());
		setPresentedAmt(that.getPresentedAmt());
		setEligibleAmt(that.getEligibleAmt());
		setNoOfDaysAllocated(that.getNoOfDaysAllocated());
		setPercentageAllocated(that.getPercentageAllocated());
		setShortFallAmt(that.getShortFallAmt());
		setReimbursedDay(that.getReimbursedDay());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPaymentWorkingId=[").append(claimPaymentWorkingId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("procedureCatId=[").append(procedureCatId).append("] ");
		buffer.append("benefitCode=[").append(benefitCode).append("] ");
		buffer.append("serviceCatId=[").append(serviceCatId).append("] ");
		buffer.append("seqId=[").append(seqId).append("] ");
		buffer.append("presentedAmt=[").append(presentedAmt).append("] ");
		buffer.append("eligibleAmt=[").append(eligibleAmt).append("] ");
		buffer.append("noOfDaysAllocated=[").append(noOfDaysAllocated).append("] ");
		buffer.append("percentageAllocated=[").append(percentageAllocated).append("] ");
		buffer.append("shortFallAmt=[").append(shortFallAmt).append("] ");
		buffer.append("reimbursedDay=[").append(reimbursedDay).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPaymentWorkingId == null) ? 0 : claimPaymentWorkingId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPaymentWorking))
			return false;
		ClaimPaymentWorking equalCheck = (ClaimPaymentWorking) obj;
		if ((claimPaymentWorkingId == null && equalCheck.claimPaymentWorkingId != null) || (claimPaymentWorkingId != null && equalCheck.claimPaymentWorkingId == null))
			return false;
		if (claimPaymentWorkingId != null && !claimPaymentWorkingId.equals(equalCheck.claimPaymentWorkingId))
			return false;
		return true;
	}

	public void copyProperties(PaymentAllocationTemp allocationTemp) {

		setCompanyId(allocationTemp.getCompanyId());
		setClaimNo(allocationTemp.getClaimNo());
		setOccurrence(allocationTemp.getOccurence());
		setPolicyNo(allocationTemp.getPolicyNo());
		setPlanId(allocationTemp.getPlanId());
		setPlanCoverageNo(allocationTemp.getPlanCoverageNo());
		setBusinessLine(allocationTemp.getBusinessLine());
		if (allocationTemp.getIcd9category() == null || StringUtils.isEmpty(allocationTemp.getIcd9category().getIcd9Category())) {
			setProcedureCatId(" ");
		} else {
			setProcedureCatId(allocationTemp.getIcd9category().getIcd9Category());
		}
		setBenefitCode(allocationTemp.getBenefitCode());
		setServiceCatId(allocationTemp.getServiceCatId());
		setProductCode(allocationTemp.getProductCode());
		setProductType(allocationTemp.getProductType());
		setSeqId(allocationTemp.getSeqId());
		setPresentedAmt(allocationTemp.getPresentedAmt());
		setEligibleAmt(allocationTemp.getEligibleAmt());
		setNoOfDaysAllocated(allocationTemp.getAllocatedDay());
		setPercentageAllocated(allocationTemp.getPercentageAllocated());
		setShortFallAmt(allocationTemp.getShortFallAmount());
		setReimbursedDay(allocationTemp.getReimbursedDay());
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}
}
