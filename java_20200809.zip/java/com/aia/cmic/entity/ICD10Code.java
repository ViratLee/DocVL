package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */
@Entity
@NamedQueries({
		@NamedQuery(name = "findAllICD10Codes", query = "select myICD10Code from ICD10Code myICD10Code"),
		@NamedQuery(name = "findAllActiveICD10Codes", query = "select myICD10Code from ICD10Code myICD10Code where myICD10Code.activeStatus is null or UPPER(myICD10Code.activeStatus) <> 'N' "),
		@NamedQuery(name = "findICD10CodeByFieldContaining", query = "select myICD10Code from ICD10Code myICD10Code where UPPER(myICD10Code.icd10Code || '.' || myICD10Code.icdSubCode) like ?1 or UPPER(myICD10Code.subCodeDesc) like ?2"),
		@NamedQuery(name = "findActiveICD10CodeByFieldContaining", query = "select myICD10Code from ICD10Code myICD10Code where (UPPER(myICD10Code.icd10Code || '.' || myICD10Code.icdSubCode) like ?1 or UPPER(myICD10Code.subCodeDesc) like ?2) and (myICD10Code.activeStatus is null or UPPER(myICD10Code.activeStatus) <> 'N')"),
		@NamedQuery(name = "findICD10CodeByFieldContainingAndCodePrefix", query = "select myICD10Code from ICD10Code myICD10Code where (myICD10Code.icd10Code like ?1 or myICD10Code.icd10Code like ?2) and (UPPER(myICD10Code.icd10Code || '.' || myICD10Code.icdSubCode) like ?3 or UPPER(myICD10Code.subCodeDesc) like ?4)"),
		@NamedQuery(name = "findICD10CodeByFieldContainingAndExcludeCodePrefix", query = "select myICD10Code from ICD10Code myICD10Code where (not (myICD10Code.icd10Code like ?1 or myICD10Code.icd10Code like ?2)) and (UPPER(myICD10Code.icd10Code || '.' || myICD10Code.icdSubCode) like ?3 or UPPER(myICD10Code.subCodeDesc) like ?4)"),
		@NamedQuery(name = "findICD10CodeByDiagnosisCode", query = "select myICD10Code from ICD10Code myICD10Code where myICD10Code.icd10Code in ?1 "),
		@NamedQuery(name = "findICD10CodeByDiagnosisCodes2", query = "select myICD10Code from ICD10Code myICD10Code where myICD10Code.icd10Code =?1 and ( myICD10Code.icdSubCode = ?2 or  ?2 is null or ?2='') order by createdDt desc "),
		@NamedQuery(name = "findActivedICD10CodeByICD10CodeAndICDSubCode", query = "select myICD10Code from ICD10Code myICD10Code where myICD10Code.icd10Code = ?1 and myICD10Code.icdSubCode = ?2 and (myICD10Code.activeStatus is null or UPPER(myICD10Code.activeStatus) <> 'N') "),
		@NamedQuery(name = "findICD10CodeByICD10CodeAndICDSubCode", query = "select myICD10Code from ICD10Code myICD10Code where myICD10Code.icd10Code = ?1 and myICD10Code.icdSubCode = ?2 ") })
@Table(name = "ICD10CODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ICD10Code")
public class ICD10Code extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "icd10CodeSequence")
	@SequenceGenerator(name = "icd10CodeSequence", sequenceName = "s_icd10code")
	@Column(name = "ICD10ID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long icd10Id;
	/**
	 */

	@Column(name = "ICD10CODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10Code;
	/**
	 */

	@Column(name = "ICDSUBCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icdSubCode;
	/**
	 */

	@Column(name = "SUBCODEDESC", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subCodeDesc;
	/**
	 */

	@Column(name = "ICD10CATEGORY", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10Category;
	/**
	 */

	@Column(name = "WAITINGPERIOD")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer waitingPeriod;
	/**
	 */

	@Column(name = "PRODUCTCODE3TIME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode3Time;

	@Column(name = "CODETYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeType;

	@Column(name = "TYPEOFINJURY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String typeofInjury;

	@Column(name = "INJURYPART", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String injuryPart;

	@Column(name = "CAUSEOFACCIDENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfAccident;

	@Column(name = "MATERNITY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String maternity;

	@Column(name = "CANCERIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cancerInd;

	/**
	 */

	@Column(name = "ICUIND", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icuInd;
	/**
	 */

	/**
	 */

	@Column(name = "AGEFROM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer ageFrom;
	/**
	 */

	@Column(name = "AGETO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer ageTo;
	/**
	 */

	@Column(name = "GENDER", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String gender;
	/**
	 */

	@Column(name = "SUSPECTPREEXISTCONDITION", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspectPreExistCondition;
	
	@Column(name = "ACTIVESTATUS", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String activeStatus;
	
	@Column(name = "STPIBIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String stpIBInd;
	
	@Column(name = "STPCSIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String stpCSInd;
	
	/**
	 * @return the icd10Id
	 */
	public Long getIcd10Id() {
		return icd10Id;
	}

	/**
	 * @param icd10Id the icd10Id to set
	 */
	public void setIcd10Id(Long icd10Id) {
		this.icd10Id = icd10Id;
	}

	/**
	 * @return the icd10Code
	 */
	public String getIcd10Code() {
		return icd10Code;
	}

	/**
	 * @param icd10Code the icd10Code to set
	 */
	public void setIcd10Code(String icd10Code) {
		this.icd10Code = icd10Code;
	}

	/**
	 * @return the icdSubCode
	 */
	public String getIcdSubCode() {
		return icdSubCode;
	}

	/**
	 * @param icdSubCode the icdSubCode to set
	 */
	public void setIcdSubCode(String icdSubCode) {
		this.icdSubCode = icdSubCode;
	}

	/**
	 * @return the subCodeDesc
	 */
	public String getSubCodeDesc() {
		return subCodeDesc;
	}

	/**
	 * @param subCodeDesc the subCodeDesc to set
	 */
	public void setSubCodeDesc(String subCodeDesc) {
		this.subCodeDesc = subCodeDesc;
	}

	/**
	 * @return the icd10Category
	 */
	public String getIcd10Category() {
		return icd10Category;
	}

	/**
	 * @param icd10Category the icd10Category to set
	 */
	public void setIcd10Category(String icd10Category) {
		this.icd10Category = icd10Category;
	}

	/**
	 * @return the waitingPeriod
	 */
	public Integer getWaitingPeriod() {
		return waitingPeriod;
	}

	public String getProductCode3Time() {
		return productCode3Time;
	}

	public void setProductCode3Time(String productCode3Time) {
		this.productCode3Time = productCode3Time;
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getTypeofInjury() {
		return typeofInjury;
	}

	public void setTypeofInjury(String typeofInjury) {
		this.typeofInjury = typeofInjury;
	}

	public String getInjuryPart() {
		return injuryPart;
	}

	public void setInjuryPart(String injuryPart) {
		this.injuryPart = injuryPart;
	}

	public String getCauseOfAccident() {
		return causeOfAccident;
	}

	public void setCauseOfAccident(String causeOfAccident) {
		this.causeOfAccident = causeOfAccident;
	}

	public String getMaternity() {
		return maternity;
	}

	public void setMaternity(String maternity) {
		this.maternity = maternity;
	}

	public String getCancerInd() {
		return cancerInd;
	}

	public void setCancerInd(String cancerInd) {
		this.cancerInd = cancerInd;
	}

	/**
	 * @param waitingPeriod the waitingPeriod to set
	 */
	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	/**
	 * @return the icuInd
	 */
	public String getIcuInd() {
		return icuInd;
	}

	/**
	 * @param icuInd the icuInd to set
	 */
	public void setIcuInd(String icuInd) {
		this.icuInd = icuInd;
	}

	/**
	 * @return the ageFrom
	 */
	public Integer getAgeFrom() {
		return ageFrom;
	}

	/**
	 * @param ageFrom the ageFrom to set
	 */
	public void setAgeFrom(Integer ageFrom) {
		this.ageFrom = ageFrom;
	}

	/**
	 * @return the ageTo
	 */
	public Integer getAgeTo() {
		return ageTo;
	}

	/**
	 * @param ageTo the ageTo to set
	 */
	public void setAgeTo(Integer ageTo) {
		this.ageTo = ageTo;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the suspectPreExistCondition
	 */
	public String getSuspectPreExistCondition() {
		return suspectPreExistCondition;
	}

	/**
	 * @param suspectPreExistCondition the suspectPreExistCondition to set
	 */
	public void setSuspectPreExistCondition(String suspectPreExistCondition) {
		this.suspectPreExistCondition = suspectPreExistCondition;
	}
	
	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	public String getStpIBInd() {
		return stpIBInd;
	}

	public String getStpCSInd() {
		return stpCSInd;
	}

	public void setStpIBInd(String stpIBInd) {
		this.stpIBInd = stpIBInd;
	}

	public void setStpCSInd(String stpCSInd) {
		this.stpCSInd = stpCSInd;
	}

	/**
	 */
	public ICD10Code() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ICD10Code that) {
		setIcd10Id(that.getIcd10Id());
		setIcd10Code(that.getIcd10Code());
		setIcdSubCode(that.getIcdSubCode());
		setSubCodeDesc(that.getSubCodeDesc());
		setIcd10Category(that.getIcd10Category());
		setWaitingPeriod(that.getWaitingPeriod());
		setProductCode3Time(that.getProductCode3Time());
		setCodeType(that.getCodeType());
		setTypeofInjury(that.getTypeofInjury());
		setInjuryPart(that.getInjuryPart());
		setCauseOfAccident(that.getCauseOfAccident());
		setMaternity(that.getMaternity());
		setCancerInd(that.getCancerInd());
		setIcuInd(that.getIcuInd());
		setAgeFrom(that.getAgeFrom());
		setAgeTo(that.getAgeTo());
		setGender(that.getGender());
		setSuspectPreExistCondition(that.getSuspectPreExistCondition());
		setActiveStatus(that.getActiveStatus());
		setStpIBInd(that.getStpIBInd());
		setStpCSInd(that.getStpCSInd());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("icd10Id=[").append(icd10Id).append("] ");
		buffer.append("icd10Code=[").append(icd10Code).append("] ");
		buffer.append("icdSubCode=[").append(icdSubCode).append("] ");
		buffer.append("subCodeDesc=[").append(subCodeDesc).append("] ");
		buffer.append("icd10Category=[").append(icd10Category).append("] ");
		buffer.append("productCode3Time=[").append(productCode3Time).append("] ");
		buffer.append("codeType=[").append(codeType).append("] ");
		buffer.append("typeofInjury=[").append(typeofInjury).append("] ");
		buffer.append("injuryPart=[").append(injuryPart).append("] ");
		buffer.append("causeOfAccident=[").append(causeOfAccident).append("] ");
		buffer.append("maternity=[").append(maternity).append("] ");
		buffer.append("cancerInd=[").append(cancerInd).append("] ");
		buffer.append("waitingPeriod=[").append(waitingPeriod).append("] ");
		buffer.append("icuInd=[").append(icuInd).append("] ");
		buffer.append("ageTo=[").append(ageTo).append("] ");
		buffer.append("gender=[").append(gender).append("] ");
		buffer.append("suspectPreExistCondition=[").append(suspectPreExistCondition).append("] ");
		buffer.append("activeStatus=[").append(activeStatus).append("] ");
		buffer.append("stpIBInd=[").append(stpIBInd).append("] ");
		buffer.append("stpCSInd=[").append(stpCSInd).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((icd10Id == null) ? 0 : icd10Id.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ICD10Code))
			return false;
		ICD10Code equalCheck = (ICD10Code) obj;
		if ((icd10Id == null && equalCheck.icd10Id != null) || (icd10Id != null && equalCheck.icd10Id == null))
			return false;
		if (icd10Id != null && !icd10Id.equals(equalCheck.icd10Id))
			return false;
		return true;
	}
}
