package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "ACCOUNT")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Account")
public class Account extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "accountSequence")
	@SequenceGenerator(name = "accountSequence", sequenceName = "s_account")
	@Column(name = "ACCOUNTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long accountId;
	/**
	 */

	@Column(name = "ACCOUNTINGTYPE", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountingType;
	/**
	 */

	@Column(name = "ACCOUNTINGDESC", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountingDesc;
	/**
	 */

	@Column(name = "ACCOUNTINGACTIONCODE", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountingActionCode;
	/**
	 */

	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;

	/**
	 */

	@Column(name = "ACCOUNTINGCATEGORY", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountingCategory;

	/**
	 */

	@Column(name = "PRODUCTTYPE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productType;

	/**
	 */

	@Column(name = "POLICYPREFIX", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyPrefix;

	@Column(name = "PHASE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String phase;

	/**
	 */

	@Column(name = "ACCOUNTCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountCode;

	@Column(name = "SUBMISSIONTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionType;

	@Column(name = "ACCOUNTINGSUBCATEGORY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountingSubCategory;
	
	@Column(name = "POSTSTEP", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postStep;
	
	
	@Column(name = "CAUSEOFTREATMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfTreatment;
	

	/**
	 * @return the accountId
	 */
	public Long getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	/**
	 * @return the accountingType
	 */
	public String getAccountingType() {
		return accountingType;
	}

	/**
	 * @param accountingType the accountingType to set
	 */
	public void setAccountingType(String accountingType) {
		this.accountingType = accountingType;
	}

	/**
	 * @return the accountingDesc
	 */
	public String getAccountingDesc() {
		return accountingDesc;
	}

	/**
	 * @param accountingDesc the accountingDesc to set
	 */
	public void setAccountingDesc(String accountingDesc) {
		this.accountingDesc = accountingDesc;
	}

	/**
	 * @return the accountingActionCode
	 */
	public String getAccountingActionCode() {
		return accountingActionCode;
	}

	/**
	 * @param accountingActionCode the accountingActionCode to set
	 */
	public void setAccountingActionCode(String accountingActionCode) {
		this.accountingActionCode = accountingActionCode;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 * @return the accountingCategory
	 */
	public String getAccountingCategory() {
		return accountingCategory;
	}

	/**
	 * @param accountingCategory the accountingCategory to set
	 */
	public void setAccountingCategory(String accountingCategory) {
		this.accountingCategory = accountingCategory;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the policyPrefix
	 */
	public String getPolicyPrefix() {
		return policyPrefix;
	}

	/**
	 * @param policyPrefix the policyPrefix to set
	 */
	public void setPolicyPrefix(String policyPrefix) {
		this.policyPrefix = policyPrefix;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}

	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getAccountingSubCategory() {
		return accountingSubCategory;
	}

	public void setAccountingSubCategory(String accountingSubCategory) {
		this.accountingSubCategory = accountingSubCategory;
	}

	
	public String getPostStep() {
		return postStep;
	}

	public void setPostStep(String postStep) {
		this.postStep = postStep;
	}

	public String getCauseOfTreatment() {
		return causeOfTreatment;
	}

	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	/**
	 */
	public Account() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Account that) {
		setAccountId(that.getAccountId());
		setAccountingType(that.getAccountingType());
		setAccountingDesc(that.getAccountingDesc());
		setAccountingActionCode(that.getAccountingActionCode());
		setBusinessLine(that.getBusinessLine());
		setAccountingCategory(that.getAccountingCategory());
		setProductType(that.getProductType());
		setPolicyPrefix(that.getPolicyPrefix());
		setAccountCode(that.getAccountCode());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("accountId=[").append(accountId).append("] ");
		buffer.append("accountingType=[").append(accountingType).append("] ");
		buffer.append("accountingDesc=[").append(accountingDesc).append("] ");
		buffer.append("accountingActionCode=[").append(accountingActionCode).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("accountingCategory=[").append(accountingCategory).append("] ");
		buffer.append("productType=[").append(productType).append("] ");
		buffer.append("policyPrefix=[").append(policyPrefix).append("] ");
		buffer.append("accountCode=[").append(accountCode).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((accountId == null) ? 0 : accountId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Account))
			return false;
		Account equalCheck = (Account) obj;
		if ((accountId == null && equalCheck.accountId != null) || (accountId != null && equalCheck.accountId == null))
			return false;
		if (accountId != null && !accountId.equals(equalCheck.accountId))
			return false;
		return true;
	}

}
