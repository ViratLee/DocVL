package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findPlanByBenefitTypeAccident", query = "select myPlan from Plan myPlan where myPlan.benefitTypeAccident = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeAccidentContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeAccident like ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeAssault", query = "select myPlan from Plan myPlan where myPlan.benefitTypeAssault = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeAssaultContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeAssault like ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeCancer", query = "select myPlan from Plan myPlan where myPlan.benefitTypeCancer = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeCancerContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeCancer like ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeDental", query = "select myPlan from Plan myPlan where myPlan.benefitTypeDental = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeDentalContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeDental like ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeMaternity", query = "select myPlan from Plan myPlan where myPlan.benefitTypeMaternity = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeMaternityContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeMaternity like ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeOthers", query = "select myPlan from Plan myPlan where myPlan.benefitTypeOthers = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeOthersContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeOthers like ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeVision", query = "select myPlan from Plan myPlan where myPlan.benefitTypeVision = ?1"),
		@NamedQuery(name = "findPlanByBenefitTypeVisionContaining", query = "select myPlan from Plan myPlan where myPlan.benefitTypeVision like ?1"),
		@NamedQuery(name = "findPlanByEffectiveDt", query = "select myPlan from Plan myPlan where myPlan.effectiveDt = ?1"),
		@NamedQuery(name = "findPlanByGeographicCoverage", query = "select myPlan from Plan myPlan where myPlan.geographicCoverage = ?1"),
		@NamedQuery(name = "findPlanByGeographicCoverageContaining", query = "select myPlan from Plan myPlan where myPlan.geographicCoverage like ?1"),
		@NamedQuery(name = "findPlanByPlanCode", query = "select myPlan from Plan myPlan where myPlan.planCode = ?1"),
		@NamedQuery(name = "findPlanByPlanCodeContaining", query = "select myPlan from Plan myPlan where myPlan.planCode like ?1"),
		@NamedQuery(name = "findPlanByPlanId", query = "select myPlan from Plan myPlan where myPlan.planId = ?1"),
		@NamedQuery(name = "findPlanByPlanName", query = "select myPlan from Plan myPlan where myPlan.planName = ?1"),
		@NamedQuery(name = "findPlanByPlanNameContaining", query = "select myPlan from Plan myPlan where myPlan.planName like ?1"),
		@NamedQuery(name = "findPlanByPlanShortName", query = "select myPlan from Plan myPlan where myPlan.planShortName = ?1"),
		@NamedQuery(name = "findPlanByPlanShortNameContaining", query = "select myPlan from Plan myPlan where myPlan.planShortName like ?1"),
		@NamedQuery(name = "findPlanByPlanStatus", query = "select myPlan from Plan myPlan where myPlan.planStatus = ?1"),
		@NamedQuery(name = "findPlanByPlanStatusContaining", query = "select myPlan from Plan myPlan where myPlan.planStatus like ?1"),
		@NamedQuery(name = "findPlanByPlanThaiDesc", query = "select myPlan from Plan myPlan where myPlan.planThaiDesc = ?1"),
		@NamedQuery(name = "findPlanByPlanThaiDescContaining", query = "select myPlan from Plan myPlan where myPlan.planThaiDesc like ?1"),
		@NamedQuery(name = "findPlanByPolicyNo", query = "select myPlan from Plan myPlan where myPlan.policyNo = ?1"),
		@NamedQuery(name = "findPlanByPolicyNoContaining", query = "select myPlan from Plan myPlan where myPlan.policyNo like ?1"),
		@NamedQuery(name = "findPlanByPrimaryKey", query = "select myPlan from Plan myPlan where myPlan.planId = ?1"),
		@NamedQuery(name = "findPlanByProductCode", query = "select myPlan from Plan myPlan where myPlan.productCode = ?1"),
		@NamedQuery(name = "findPlanByProductCodeContaining", query = "select myPlan from Plan myPlan where myPlan.productCode like ?1"),
		@NamedQuery(name = "findPlanByReserveCashlessPercentage", query = "select myPlan from Plan myPlan where myPlan.reserveCashlessPercentage = ?1"),
		@NamedQuery(name = "findPlanByReserveCashPercentage", query = "select myPlan from Plan myPlan where myPlan.reserveCashPercentage = ?1"),
		@NamedQuery(name = "findPlanBySubPlanCode", query = "select myPlan from Plan myPlan where myPlan.subPlanCode = ?1"),
		@NamedQuery(name = "findPlanByTypeOfServiceDayCase", query = "select myPlan from Plan myPlan where myPlan.typeOfServiceDayCase = ?1"),
		@NamedQuery(name = "findPlanByTypeOfServiceDayCaseContaining", query = "select myPlan from Plan myPlan where myPlan.typeOfServiceDayCase like ?1"),
		@NamedQuery(name = "findPlanByTypeOfServiceIpd", query = "select myPlan from Plan myPlan where myPlan.typeOfServiceIpd = ?1"),
		@NamedQuery(name = "findPlanByTypeOfServiceIpdContaining", query = "select myPlan from Plan myPlan where myPlan.typeOfServiceIpd like ?1"),
		@NamedQuery(name = "findPlanByTypeOfServiceOpd", query = "select myPlan from Plan myPlan where myPlan.typeOfServiceOpd = ?1"),
		@NamedQuery(name = "findPlanByTypeOfServiceOpdContaining", query = "select myPlan from Plan myPlan where myPlan.typeOfServiceOpd like ?1"),
		@NamedQuery(name = "findPlanByPolicyNoAndPlanId", query = "select myPlan from Plan myPlan where myPlan.policyNo=?1 and myPlan.planId=?2"),
		@NamedQuery(name = "findPlanByPolicyNoAndPlanCode", query = "select myPlan from Plan myPlan where myPlan.policyNo=?1 and myPlan.planCode=?2"),
		@NamedQuery(name = "findPlanByPolicyNoAndPlanCodeAndPlanShortNameAndEffDt", query = "select myPlan from Plan myPlan where myPlan.policyNo=?1 and myPlan.planCode=?2 and myPlan.planShortName =?3 and myPlan.effectiveDt<=?4 and myPlan.terminateDt>=?5"),
		@NamedQuery(name = "findPlanByPolicyNoAndPlanCodeAndPlanShortName", query = "select myPlan from Plan myPlan where myPlan.policyNo=?1 and myPlan.planCode=?2 and myPlan.planShortName=?3"),
		@NamedQuery(name = "findPlanByFieldContaining", query = "select myPlan from Plan myPlan where myPlan.planShortName like ?1 or myPlan.planName like ?2"),
		@NamedQuery(name = "findPlanByPlanCodeAndSubPlanCode", query = "select myPlan from Plan myPlan where myPlan.planCode = ?1 and myPlan.subPlanCode = ?2"),
		@NamedQuery(name = "deletePlanByPlanId", query = "delete from Plan myPlan where myPlan.planId = ?1"),
		@NamedQuery(name = "findPlanByPlanNameAndSubPlanCode", query = "select myPlan from Plan myPlan where myPlan.planName = ?1 and myPlan.subPlanCode = ?2"),
		@NamedQuery(name = "findPlanIdsWithSamePlanName", query = "select myPlan.planId from Plan myPlan where myPlan.planName = ?1"),
        @NamedQuery(name = "findPlanByBenefitType", query = "select myPlan from Plan myPlan where myPlan.benefitType = ?1 "),
        @NamedQuery(name = "findPlanByPlanCodeIn", query = "select myPlan from Plan myPlan where  myPlan.planCode in (?1) ")
        })
@Table(name = "PLAN")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Plan")
public class Plan extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "planSequence")
	@SequenceGenerator(name = "planSequence", sequenceName = "s_plan")
	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCODE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCode;
	/**
	 */

	@Column(name = "SUBPLANCODE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer subPlanCode;
	/**
	 */

	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "FURTHERCLAIMDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer furtherClaimDay;
	/**
	 */

	@Column(name = "EMERGENCYDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer emergencyDay;
	/**
	 */
	@Column(name = "EFFECTIVEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveDt;
	/**
	 */
	@Column(name = "TERMINATEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date terminateDt;
	/**
	 */

	@Column(name = "PLANSHORTNAME", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planShortName;
	/**
	 */

	@Column(name = "PLANNAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planName;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "PLANTHAIDESC", length = 90)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planThaiDesc;
	/**
	 */

	@Column(name = "BUSINESSLINE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	/**
	 */

	@Column(name = "NETWORKCODE", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer networkCode;
	/**
	 */

	@Column(name = "NETWORKBENEFITIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String networkBenefitInd;
	/**
	 */

	@Column(name = "BENEFITTYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitType;
	/**
	 */

	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "PLANSTATUS", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planStatus;
	/**
	 */

	@Column(name = "TYPEOFSERVICEIPD", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String typeOfServiceIpd;
	/**
	 */

	@Column(name = "TYPEOFSERVICEOPD", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String typeOfServiceOpd;
	/**
	 */

	@Column(name = "TYPEOFSERVICEDAYCASE", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String typeOfServiceDayCase;
	/**
	 */

	@Column(name = "BENEFITTYPEACCIDENT", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeAccident;
	/**
	 */

	@Column(name = "BENEFITTYPEASSAULT", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeAssault;
	/**
	 */

	@Column(name = "BENEFITTYPECANCER", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeCancer;
	/**
	 */

	@Column(name = "BENEFITTYPEOTHERS", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeOthers;
	/**
	 */

	@Column(name = "BENEFITTYPEMATERNITY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeMaternity;
	/**
	 */

	@Column(name = "BENEFITTYPEDENTAL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeDental;
	/**
	 */

	@Column(name = "BENEFITTYPEVISION", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitTypeVision;
	/**
	 */
	
	@Column(name = "HEALTHCHECKUP", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	@Transient
	String healthCheckup;

	@Column(name = "RESERVECASHPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal reserveCashPercentage;
	/**
	 */

	@Column(name = "RESERVECASHLESSPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal reserveCashlessPercentage;
	/**
	 */

	@Column(name = "GEOGRAPHICCOVERAGE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String geographicCoverage;

	/**
	 */

	@Column(name = "DEFAULTPLANID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long defaultPlanId;
	
	@Column(name = "DEDUCTLIMIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal deductLimit ;

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	/**
	 */
	public String getPlanCode() {
		return this.planCode;
	}

	/**
	 */
	public void setSubPlanCode(Integer subPlanCode) {
		this.subPlanCode = subPlanCode;
	}

	/**
	 */
	public Integer getSubPlanCode() {
		return this.subPlanCode;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setFurtherClaimDay(Integer furtherClaimDay) {
		this.furtherClaimDay = furtherClaimDay;
	}

	/**
	 */
	public Integer getFurtherClaimDay() {
		return this.furtherClaimDay;
	}

	/**
	 */
	public void setEmergencyDay(Integer emergencyDay) {
		this.emergencyDay = emergencyDay;
	}

	/**
	 */
	public Integer getEmergencyDay() {
		return this.emergencyDay;
	}

	/**
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 */
	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	/**
	 */
	public void setTerminateDt(Date terminateDt) {
		this.terminateDt = terminateDt;
	}

	/**
	 */
	public Date getTerminateDt() {
		return this.terminateDt;
	}

	/**
	 */
	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}

	/**
	 */
	public String getPlanShortName() {
		return this.planShortName;
	}

	/**
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}

	/**
	 */
	public String getPlanName() {
		return this.planName;
	}

	/**
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public String getProductCode() {
		return this.productCode;
	}

	/**
	 */
	public void setPlanThaiDesc(String planThaiDesc) {
		this.planThaiDesc = planThaiDesc;
	}

	/**
	 */
	public String getPlanThaiDesc() {
		return this.planThaiDesc;
	}

	/**
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 */
	public String getBusinessLine() {
		return this.businessLine;
	}

	public Integer getNetworkCode() {
		return networkCode;
	}

	public void setNetworkCode(Integer networkCode) {
		this.networkCode = networkCode;
	}

	/**
	 */
	public void setNetworkBenefitInd(String networkBenefitInd) {
		this.networkBenefitInd = networkBenefitInd;
	}

	/**
	 */
	public String getNetworkBenefitInd() {
		return this.networkBenefitInd;
	}

	/**
	 */
	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}

	/**
	 */
	public String getBenefitType() {
		return this.benefitType;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	/**
	 */
	public String getPlanStatus() {
		return this.planStatus;
	}

	/**
	 */
	public void setTypeOfServiceIpd(String typeOfServiceIpd) {
		this.typeOfServiceIpd = typeOfServiceIpd;
	}

	/**
	 */
	public String getTypeOfServiceIpd() {
		return this.typeOfServiceIpd;
	}

	/**
	 */
	public void setTypeOfServiceOpd(String typeOfServiceOpd) {
		this.typeOfServiceOpd = typeOfServiceOpd;
	}

	/**
	 */
	public String getTypeOfServiceOpd() {
		return this.typeOfServiceOpd;
	}

	/**
	 */
	public void setTypeOfServiceDayCase(String typeOfServiceDayCase) {
		this.typeOfServiceDayCase = typeOfServiceDayCase;
	}

	/**
	 */
	public String getTypeOfServiceDayCase() {
		return this.typeOfServiceDayCase;
	}

	/**
	 */
	public void setBenefitTypeAccident(String benefitTypeAccident) {
		this.benefitTypeAccident = benefitTypeAccident;
	}

	/**
	 */
	public String getBenefitTypeAccident() {
		return this.benefitTypeAccident;
	}

	/**
	 */
	public void setBenefitTypeAssault(String benefitTypeAssault) {
		this.benefitTypeAssault = benefitTypeAssault;
	}

	/**
	 */
	public String getBenefitTypeAssault() {
		return this.benefitTypeAssault;
	}

	/**
	 */
	public void setBenefitTypeCancer(String benefitTypeCancer) {
		this.benefitTypeCancer = benefitTypeCancer;
	}

	/**
	 */
	public String getBenefitTypeCancer() {
		return this.benefitTypeCancer;
	}

	/**
	 */
	public void setBenefitTypeOthers(String benefitTypeOthers) {
		this.benefitTypeOthers = benefitTypeOthers;
	}

	/**
	 */
	public String getBenefitTypeOthers() {
		return this.benefitTypeOthers;
	}

	/**
	 */
	public void setBenefitTypeMaternity(String benefitTypeMaternity) {
		this.benefitTypeMaternity = benefitTypeMaternity;
	}

	/**
	 */
	public String getBenefitTypeMaternity() {
		return this.benefitTypeMaternity;
	}

	/**
	 */
	public void setBenefitTypeDental(String benefitTypeDental) {
		this.benefitTypeDental = benefitTypeDental;
	}

	/**
	 */
	public String getBenefitTypeDental() {
		return this.benefitTypeDental;
	}

	/**
	 */
	public void setBenefitTypeVision(String benefitTypeVision) {
		this.benefitTypeVision = benefitTypeVision;
	}

	/**
	 */
	public String getBenefitTypeVision() {
		return this.benefitTypeVision;
	}
	
	public String getHealthCheckup() {
		return healthCheckup;
	}

	public void setHealthCheckup(String healthCheckup) {
		this.healthCheckup = healthCheckup;
	}

	/**
	 */
	public void setReserveCashPercentage(BigDecimal reserveCashPercentage) {
		this.reserveCashPercentage = reserveCashPercentage;
	}

	/**
	 */
	public BigDecimal getReserveCashPercentage() {
		return this.reserveCashPercentage;
	}

	/**
	 */
	public void setReserveCashlessPercentage(BigDecimal reserveCashlessPercentage) {
		this.reserveCashlessPercentage = reserveCashlessPercentage;
	}

	/**
	 */
	public BigDecimal getReserveCashlessPercentage() {
		return this.reserveCashlessPercentage;
	}

	/**
	 */
	public void setGeographicCoverage(String geographicCoverage) {
		this.geographicCoverage = geographicCoverage;
	}

	/**
	 */
	public String getGeographicCoverage() {
		return this.geographicCoverage;
	}

	public Long getDefaultPlanId() {
		return defaultPlanId;
	}

	public void setDefaultPlanId(Long defaultPlanId) {
		this.defaultPlanId = defaultPlanId;
	}

	/**
	 * @return the deductLimit
	 */
	public BigDecimal getDeductLimit() {
		return deductLimit;
	}

	/**
	 * @param deductLimit the deductLimit to set
	 */
	public void setDeductLimit(BigDecimal deductLimit) {
		this.deductLimit = deductLimit;
	}

	/**
	 */
	public Plan() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Plan that) {
		setPlanId(that.getPlanId());
		setPlanCode(that.getPlanCode());
		setSubPlanCode(that.getSubPlanCode());
		setPolicyNo(that.getPolicyNo());
		setFurtherClaimDay(that.getFurtherClaimDay());
		setEmergencyDay(that.getEmergencyDay());
		setEffectiveDt(that.getEffectiveDt());
		setTerminateDt(that.getTerminateDt());
		setPlanShortName(that.getPlanShortName());
		setPlanName(that.getPlanName());
		setProductCode(that.getProductCode());
		setPlanThaiDesc(that.getPlanThaiDesc());
		setBusinessLine(that.getBusinessLine());
		setNetworkCode(that.getNetworkCode());
		setNetworkBenefitInd(that.getNetworkBenefitInd());
		setBenefitType(that.getBenefitType());
		setCompanyId(that.getCompanyId());
		setPlanStatus(that.getPlanStatus());
		setTypeOfServiceIpd(that.getTypeOfServiceIpd());
		setTypeOfServiceOpd(that.getTypeOfServiceOpd());
		setTypeOfServiceDayCase(that.getTypeOfServiceDayCase());
		setBenefitTypeAccident(that.getBenefitTypeAccident());
		setBenefitTypeAssault(that.getBenefitTypeAssault());
		setBenefitTypeCancer(that.getBenefitTypeCancer());
		setBenefitTypeOthers(that.getBenefitTypeOthers());
		setBenefitTypeMaternity(that.getBenefitTypeMaternity());
		setBenefitTypeDental(that.getBenefitTypeDental());
		setBenefitTypeVision(that.getBenefitTypeVision());
		setHealthCheckup(that.getHealthCheckup());
		setReserveCashPercentage(that.getReserveCashPercentage());
		setReserveCashlessPercentage(that.getReserveCashlessPercentage());
		setGeographicCoverage(that.getGeographicCoverage());
		setDefaultPlanId(that.getDefaultPlanId());
		setDeductLimit(that.getDeductLimit());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCode=[").append(planCode).append("] ");
		buffer.append("subPlanCode=[").append(subPlanCode).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("furtherClaimDay=[").append(furtherClaimDay).append("] ");
		buffer.append("emergencyDay=[").append(emergencyDay).append("] ");
		buffer.append("effectiveDt=[").append(effectiveDt).append("] ");
		buffer.append("terminateDt=[").append(terminateDt).append("] ");
		buffer.append("planShortName=[").append(planShortName).append("] ");
		buffer.append("planName=[").append(planName).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("planThaiDesc=[").append(planThaiDesc).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("networkCode=[").append(networkCode).append("] ");
		buffer.append("networkBenefitInd=[").append(networkBenefitInd).append("] ");
		buffer.append("benefitType=[").append(benefitType).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("planStatus=[").append(planStatus).append("] ");
		buffer.append("typeOfServiceIpd=[").append(typeOfServiceIpd).append("] ");
		buffer.append("typeOfServiceOpd=[").append(typeOfServiceOpd).append("] ");
		buffer.append("typeOfServiceDayCase=[").append(typeOfServiceDayCase).append("] ");
		buffer.append("benefitTypeAccident=[").append(benefitTypeAccident).append("] ");
		buffer.append("benefitTypeAssault=[").append(benefitTypeAssault).append("] ");
		buffer.append("benefitTypeCancer=[").append(benefitTypeCancer).append("] ");
		buffer.append("benefitTypeOthers=[").append(benefitTypeOthers).append("] ");
		buffer.append("benefitTypeMaternity=[").append(benefitTypeMaternity).append("] ");
		buffer.append("benefitTypeDental=[").append(benefitTypeDental).append("] ");
		buffer.append("benefitTypeVision=[").append(benefitTypeVision).append("] ");
		buffer.append("healthCheckup=[").append(healthCheckup).append("] ");
		buffer.append("reserveCashPercentage=[").append(reserveCashPercentage).append("] ");
		buffer.append("reserveCashlessPercentage=[").append(reserveCashlessPercentage).append("] ");
		buffer.append("geographicCoverage=[").append(geographicCoverage).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((planId == null) ? 0 : planId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Plan))
			return false;
		Plan equalCheck = (Plan) obj;
		if ((planId == null && equalCheck.planId != null) || (planId != null && equalCheck.planId == null))
			return false;
		if (planId != null && !planId.equals(equalCheck.planId))
			return false;
		return true;
	}
}
