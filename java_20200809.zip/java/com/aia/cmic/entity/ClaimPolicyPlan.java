package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllClaimPolicyPlans", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan"),
		@NamedQuery(name = "findClaimPolicyPlanByClaimNo", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo=?1"),
		@NamedQuery(name = "findClaimPolicyPlanByClaimPolicyPlanId", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimPolicyPlanId = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByGeographicCoverage", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.geographicCoverage = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByGeographicCoverageContaining", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.geographicCoverage like ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPlanId", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.planId = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPlanIdContaining", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.planId like ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPlanStatus", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.planStatus = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPlanStatusContaining", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.planStatus like ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPoliyNo", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.policyNo = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPoliyNoContaining", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.policyNo like ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByPrimaryKey", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimPolicyPlanId = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanBySumAssured", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.sumAssured = ?1"),
		@NamedQuery(name = "findClaimPolicyPlanByCompanyIdClaimNoAndOccurrence", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo=?1 and myClaimPolicyPlan.occurrence= ?2 "),
		@NamedQuery(name = "findClaimPolicyPlanforWriteFSU", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo=?1 and myClaimPolicyPlan.occurrence= ?2 and myClaimPolicyPlan.policyNo =?3 and (myClaimPolicyPlan.productCode =?4 or ?4 is null) and myClaimPolicyPlan.planId= ?5 and (myClaimPolicyPlan.planCoverageNo= ?6 or ?6 is null or ?6='' )"),
		@NamedQuery(name = "deleteClaimPolicyPlanByCompanyIdAndClaimNo", query = "delete from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo=?1"),
		@NamedQuery(name = "getSumAssured", query = "select myClaimPolicyPlan.sumAssured from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo=?1 and myClaimPolicyPlan.occurrence= ?2 and myClaimPolicyPlan.policyNo =?3 and myClaimPolicyPlan.planId= ?4 and (myClaimPolicyPlan.planCoverageNo= ?5 or ?5 is null or  ?5='')"),
		@NamedQuery(name = "findClaimPolicyPlanByClaimNoOccurrencePolicyNo", query = "select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo = ?1 and myClaimPolicyPlan.occurrence= ?2 and myClaimPolicyPlan.policyNo = ?3 "),//
		@NamedQuery(name = "findPolicyYearByClaimNoOccurrence", query="select myClaimPolicyPlan from ClaimPolicyPlan myClaimPolicyPlan where myClaimPolicyPlan.claimNo = ?1 and myClaimPolicyPlan.occurrence= ?2 and myClaimPolicyPlan.policyYearFromDt is not null and myClaimPolicyPlan.policyYearToDt is not null ")//
})
@Table(name = "CLAIMPOLICYPLAN")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPolicyPlan")
public class ClaimPolicyPlan extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPolicyPlanSequence")
	@SequenceGenerator(name = "claimPolicyPlanSequence", sequenceName = "s_claimpolicyPlan")
	@Column(name = "CLAIMPOLICYPLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPolicyPlanId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "PAPACKAGENAME", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paPackageName;
	/**
	 */

	@Column(name = "PLANSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planStatus;
	/**
	 */

	@Column(name = "SUMASSURED", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal sumAssured;
	/**
	 */

	@Column(name = "FACEAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal faceAmt;
	
	@Column(name = "HSBONUSAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal hsBonusAmt;

	/**
	 */
	@Column(name = "HSBONUSDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date hsBonusDt;
	
	/**
	 */

	@Column(name = "RATEAGE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer rateAge;
	/**
	 */

	@Column(name = "NOOFUNIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal noOfUnit;
	/**
	 */

	@Column(name = "VALUEPERUNIT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer valuePerUnit;
	/**
	 */
	@Column(name = "PLANISSUEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date planIssueDt;
	/**
	 */
	@Column(name = "PLANPAIDUPDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date planPaidUpDt;
	/**
	 */
	@Column(name = "PLANEXPIRYDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date planExpiryDt;
	/**
	 */

	@Column(name = "GEOGRAPHICCOVERAGE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String geographicCoverage;
	/**
	 */

	@Column(name = "REINSURANCESCHEMECODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String reinsuranceSchemeCode;
	/**
	 */

	@Column(name = "PERCENTAGEREINSURANCE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal percentageReinsurance;

	/**
	 */

	@Column(name = "EXCLUSION1", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusion1;
	/**
	 */

	@Column(name = "EXCLUSION2", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusion2;
	/**
	 */

	@Column(name = "EXCLUSION3", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusion3;

	
	@Column(name = "ADMITAREA", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String admitArea;
	
	@Column(name = "POLICYYEARFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearFromDt;
	
	@Column(name = "POLICYYEARTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearToDt;
	
	@Column(name = "PAR", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String par;
	
	@Column(name = "INFORCEPLANCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String inforcePlanCode;
	
	@Column(name = "PLANCOVERAGENORCC")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNoRcc;
		
	@Column(name = "RELATEPLANCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String relatePlanCode;
	
	@Column(name = "RELATEINFORCEPLANCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String relateInforcePlanCode;
	
	@Column(name = "INFORCEPLANCODE01", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String inforcePlanCode01;
	
	@Column(name = "RIDERCONIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String riderConInd;
	
	
	/**
	 */

	/**
	 * @return the claimPolicyPlanId
	 */
	public Long getClaimPolicyPlanId() {
		return claimPolicyPlanId;
	}

	/**
	 * @param claimPolicyPlanId the claimPolicyPlanId to set
	 */
	public void setClaimPolicyPlanId(Long claimPolicyPlanId) {
		this.claimPolicyPlanId = claimPolicyPlanId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public void setPaPackageName(String paPackageName) {
		this.paPackageName = paPackageName;
	}

	/**
	 */
	public String getPaPackageName() {
		return this.paPackageName;
	}

	/**
	 */
	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	/**
	 */
	public String getPlanStatus() {
		return this.planStatus;
	}

	/**
	 */
	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	/**
	 */
	public BigDecimal getSumAssured() {
		return this.sumAssured;
	}

	/**
	 */
	public void setFaceAmt(BigDecimal faceAmt) {
		this.faceAmt = faceAmt;
	}

	/**
	 */
	public BigDecimal getFaceAmt() {
		return this.faceAmt;
	}

	public BigDecimal getHsBonusAmt() {
		return hsBonusAmt;
	}

	public void setHsBonusAmt(BigDecimal hsBonusAmt) {
		this.hsBonusAmt = hsBonusAmt;
	}

	public Date getHsBonusDt() {
		return hsBonusDt;
	}

	public void setHsBonusDt(Date hsBonusDt) {
		this.hsBonusDt = hsBonusDt;
	}

	/**
	 */
	public void setRateAge(Integer rateAge) {
		this.rateAge = rateAge;
	}

	/**
	 */
	public Integer getRateAge() {
		return this.rateAge;
	}

	/**
	 */
	public void setNoOfUnit(BigDecimal noOfUnit) {
		this.noOfUnit = noOfUnit;
	}

	/**
	 */
	public BigDecimal getNoOfUnit() {
		return this.noOfUnit;
	}

	/**
	 */
	public void setValuePerUnit(Integer valuePerUnit) {
		this.valuePerUnit = valuePerUnit;
	}

	/**
	 */
	public Integer getValuePerUnit() {
		return this.valuePerUnit;
	}

	/**
	 */
	public void setPlanIssueDt(Date planIssueDt) {
		this.planIssueDt = planIssueDt;
	}

	/**
	 */
	public Date getPlanIssueDt() {
		return this.planIssueDt;
	}

	/**
	 */
	public void setPlanPaidUpDt(Date planPaidUpDt) {
		this.planPaidUpDt = planPaidUpDt;
	}

	/**
	 */
	public Date getPlanPaidUpDt() {
		return this.planPaidUpDt;
	}

	/**
	 */
	public void setPlanExpiryDt(Date planExpiryDt) {
		this.planExpiryDt = planExpiryDt;
	}

	/**
	 */
	public Date getPlanExpiryDt() {
		return this.planExpiryDt;
	}

	/**
	 */
	public void setGeographicCoverage(String geographicCoverage) {
		this.geographicCoverage = geographicCoverage;
	}

	/**
	 */
	public String getGeographicCoverage() {
		return this.geographicCoverage;
	}

	/**
	 */
	public void setReinsuranceSchemeCode(String reinsuranceSchemeCode) {
		this.reinsuranceSchemeCode = reinsuranceSchemeCode;
	}

	/**
	 */
	public String getReinsuranceSchemeCode() {
		return this.reinsuranceSchemeCode;
	}

	/**
	 */
	public void setPercentageReinsurance(BigDecimal percentageReinsurance) {
		this.percentageReinsurance = percentageReinsurance;
	}

	/**
	 */
	public BigDecimal getPercentageReinsurance() {
		return this.percentageReinsurance;
	}

	public String getExclusion1() {
		return exclusion1;
	}

	public void setExclusion1(String exclusion1) {
		this.exclusion1 = exclusion1;
	}

	public String getExclusion2() {
		return exclusion2;
	}

	public void setExclusion2(String exclusion2) {
		this.exclusion2 = exclusion2;
	}

	public String getExclusion3() {
		return exclusion3;
	}

	public void setExclusion3(String exclusion3) {
		this.exclusion3 = exclusion3;
	}

	
	public String getAdmitArea() {
		return admitArea;
	}

	public void setAdmitArea(String admitArea) {
		this.admitArea = admitArea;
	}
	
	

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}
	
	public String getPar() {
		return par;
	}

	public void setPar(String par) {
		this.par = par;
	}
	
	public String getInforcePlanCode() {
		return inforcePlanCode;
	}

	public void setInforcePlanCode(String inforcePlanCode) {
		this.inforcePlanCode = inforcePlanCode;
	}

	public String getPlanCoverageNoRcc() {
		return planCoverageNoRcc;
	}

	public void setPlanCoverageNoRcc(String planCoverageNoRcc) {
		this.planCoverageNoRcc = planCoverageNoRcc;
	}

	public String getRelatePlanCode() {
		return relatePlanCode;
	}

	public void setRelatePlanCode(String relatePlanCode) {
		this.relatePlanCode = relatePlanCode;
	}
	
	public String getRelateInforcePlanCode() {
		return relateInforcePlanCode;
	}

	public void setRelateInforcePlanCode(String relateInforcePlanCode) {
		this.relateInforcePlanCode = relateInforcePlanCode;
	}

	public String getInforcePlanCode01() {
		return inforcePlanCode01;
	}

	public void setInforcePlanCode01(String inforcePlanCode01) {
		this.inforcePlanCode01 = inforcePlanCode01;
	}

	

	public String getRiderConInd() {
		return riderConInd;
	}

	public void setRiderConInd(String riderConInd) {
		this.riderConInd = riderConInd;
	}

	/**
	 */
	public ClaimPolicyPlan() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPolicyPlan that) {
		setClaimPolicyPlanId(that.getClaimPolicyPlanId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setProductCode(that.getProductCode());
		setPaPackageName(that.getPaPackageName());
		setPlanStatus(that.getPlanStatus());
		setSumAssured(that.getSumAssured());
		setFaceAmt(that.getFaceAmt());
		setRateAge(that.getRateAge());
		setNoOfUnit(that.getNoOfUnit());
		setValuePerUnit(that.getValuePerUnit());
		setPlanIssueDt(that.getPlanIssueDt());
		setPlanPaidUpDt(that.getPlanPaidUpDt());
		setPlanExpiryDt(that.getPlanExpiryDt());
		setGeographicCoverage(that.getGeographicCoverage());
		setReinsuranceSchemeCode(that.getReinsuranceSchemeCode());
		setPercentageReinsurance(that.getPercentageReinsurance());
		setExclusion1(that.getExclusion1());
		setExclusion2(that.getExclusion2());
		setExclusion3(that.getExclusion3());
		setAdmitArea(that.getAdmitArea());
		setPar(that.getPar());
		setInforcePlanCode(that.getInforcePlanCode());
		setPlanCoverageNoRcc(that.getPlanCoverageNoRcc());
		setRelatePlanCode(that.getRelatePlanCode());
		setRelateInforcePlanCode(that.getRelateInforcePlanCode());
		setInforcePlanCode01(that.getInforcePlanCode01());
		setRiderConInd(that.getRiderConInd());
		setPolicyYearFromDt(that.getPolicyYearFromDt());
		setPolicyYearToDt(that.getPolicyYearToDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPolicyPlanId=[").append(claimPolicyPlanId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("paPackageName=[").append(paPackageName).append("] ");
		buffer.append("planStatus=[").append(planStatus).append("] ");
		buffer.append("sumAssured=[").append(sumAssured).append("] ");
		buffer.append("faceAmt=[").append(faceAmt).append("] ");
		buffer.append("rateAge=[").append(rateAge).append("] ");
		buffer.append("noOfUnit=[").append(noOfUnit).append("] ");
		buffer.append("valuePerUnit=[").append(valuePerUnit).append("] ");
		buffer.append("planIssueDt=[").append(planIssueDt).append("] ");
		buffer.append("planPaidUpDt=[").append(planPaidUpDt).append("] ");
		buffer.append("planExpiryDt=[").append(planExpiryDt).append("] ");
		buffer.append("geographicCoverage=[").append(geographicCoverage).append("] ");
		buffer.append("reinsuranceSchemeCode=[").append(reinsuranceSchemeCode).append("] ");
		buffer.append("percentageReinsurance=[").append(percentageReinsurance).append("] ");
		buffer.append("exclusion1=[").append(exclusion1).append("] ");
		buffer.append("exclusion2=[").append(exclusion2).append("] ");
		buffer.append("exclusion3=[").append(exclusion3).append("] ");
		buffer.append("admitArea=[").append(admitArea).append("] ");
		buffer.append("par=[").append(par).append("] ");
		buffer.append("inforcePlanCode=[").append(inforcePlanCode).append("] ");
		buffer.append("planCoverageNoRcc=[").append(planCoverageNoRcc).append("] ");
		buffer.append("relatePlanCode=[").append(relatePlanCode).append("] ");
		buffer.append("relateInforcePlanCode=[").append(relateInforcePlanCode).append("] ");
		buffer.append("inforcePlanCode01=[").append(inforcePlanCode01).append("] ");
		buffer.append("riderConInd=[").append(riderConInd).append("] ");
		buffer.append("policyYearFromDt=[").append(policyYearFromDt).append("] ");
		buffer.append("policyYearToDt=[").append(policyYearToDt).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPolicyPlanId == null) ? 0 : claimPolicyPlanId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPolicyPlan))
			return false;
		ClaimPolicyPlan equalCheck = (ClaimPolicyPlan) obj;
		if ((claimPolicyPlanId == null && equalCheck.claimPolicyPlanId != null) || (claimPolicyPlanId != null && equalCheck.claimPolicyPlanId == null))
			return false;
		if (claimPolicyPlanId != null && !claimPolicyPlanId.equals(equalCheck.claimPolicyPlanId))
			return false;
		return true;
	}
}
