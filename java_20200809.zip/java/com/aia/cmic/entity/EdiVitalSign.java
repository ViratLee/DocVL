package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "EDIVITALSIGN")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "EdiVitalSign")
public class EdiVitalSign extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ediVitalSignSequence")
	@SequenceGenerator(name = "ediVitalSignSequence", sequenceName = "s_edivitalsign")
	@Column(name = "EDIVITALSIGNID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long ediVitalSignId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "RESPIRATORYRATE", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String respiratoryRate;

	@Column(name = "HEARTRATE", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String heartRate;

	@Column(name = "TEMPERATURE", length = 6)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String temperature;

	@Column(name = "SYSTOLICBP", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String systolicbp;

	@Column(name = "DIASTOLICBP", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String diastolicbp;

	@Column(name = "PAINSCORE", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String painScore;

	@Column(name = "VITALSIGNENTRYDATETIME")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date vitalSignEntryDateTime;

	public Long getEdiVitalSignId() {
		return ediVitalSignId;
	}

	public void setEdiVitalSignId(Long ediVitalSignId) {
		this.ediVitalSignId = ediVitalSignId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getRespiratoryRate() {
		return respiratoryRate;
	}

	public void setRespiratoryRate(String respiratoryRate) {
		this.respiratoryRate = setMaxLength("respiratoryRate", respiratoryRate);
	}

	public String getHeartRate() {
		return heartRate;
	}

	public void setHeartRate(String heartRate) {
		this.heartRate = setMaxLength("heartRate", heartRate);
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = setMaxLength("temperature", temperature);
	}

	public String getSystolicbp() {
		return systolicbp;
	}

	public void setSystolicbp(String systolicbp) {
		this.systolicbp = setMaxLength("systolicbp", systolicbp);
	}

	public String getDiastolicbp() {
		return diastolicbp;
	}

	public void setDiastolicbp(String diastolicbp) {
		this.diastolicbp = setMaxLength("diastolicbp", diastolicbp);
	}

	public String getPainScore() {
		return painScore;
	}

	public void setPainScore(String painScore) {
		this.painScore = setMaxLength("painScore", painScore);
	}

	public Date getVitalSignEntryDateTime() {
		return vitalSignEntryDateTime;
	}

	public void setVitalSignEntryDateTime(Date vitalSignEntryDateTime) {
		this.vitalSignEntryDateTime = vitalSignEntryDateTime;
	}

	public EdiVitalSign() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(EdiVitalSign that) {

		setEdiVitalSignId(this.getEdiVitalSignId());
		setClaimNo(this.getClaimNo());
		setOccurrence(this.getOccurrence());
		setRespiratoryRate(this.getRespiratoryRate());
		setHeartRate(this.getHeartRate());
		setTemperature(this.getTemperature());
		setSystolicbp(this.getSystolicbp());
		setDiastolicbp(this.getDiastolicbp());
		setPainScore(this.getPainScore());
		setVitalSignEntryDateTime(this.getVitalSignEntryDateTime());

	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("ediVitalSignId=[").append(ediVitalSignId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("respiratoryRate=[").append(respiratoryRate).append("] ");
		buffer.append("heartRate=[").append(heartRate).append("] ");
		buffer.append("temperature=[").append(temperature).append("] ");
		buffer.append("systolicbp=[").append(systolicbp).append("] ");
		buffer.append("diastolicbp=[").append(diastolicbp).append("] ");
		buffer.append("painScore=[").append(painScore).append("] ");

		buffer.append("vitalSignEntryDateTime=[").append(vitalSignEntryDateTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((ediVitalSignId == null) ? 0 : ediVitalSignId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof EdiVitalSign))
			return false;
		EdiVitalSign equalCheck = (EdiVitalSign) obj;
		if ((ediVitalSignId == null && equalCheck.ediVitalSignId != null) || (ediVitalSignId != null && equalCheck.ediVitalSignId == null))
			return false;
		if (ediVitalSignId != null && !ediVitalSignId.equals(equalCheck.ediVitalSignId))
			return false;
		return true;
	}

	private String setMaxLength(String columnName, String data) {
		if (data == null) {
			return data;
		}
		try {
			int size = getClass().getDeclaredField(columnName).getAnnotation(Column.class).length();
			int inLength = data.length();
			if (inLength > size) {
				data = data.substring(0, size);
			}
		} catch (NoSuchFieldException ex) {
		} catch (SecurityException ex) {
		}
		return data;
	}
}
