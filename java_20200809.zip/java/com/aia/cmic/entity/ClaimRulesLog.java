package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllClaimRulesLogs", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog"),
		@NamedQuery(name = "findClaimRulesLogByClaimNoOccurrence", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.claimNo = ?1 and myClaimRulesLog.occurrence= ?2"),
		@NamedQuery(name = "findClaimRulesLogByClaimNoContaining", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.claimNo like ?1"),
		@NamedQuery(name = "findClaimRulesLogByClaimRulesLogId", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.claimRulesLogId = ?1"),
		@NamedQuery(name = "findClaimRulesLogByDecision", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.decision = ?1"),
		@NamedQuery(name = "findClaimRulesLogByDecisionContaining", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.decision like ?1"),
		@NamedQuery(name = "findClaimRulesLogByOccurrence", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.occurrence = ?1"),
		@NamedQuery(name = "findClaimRulesLogByPolicyNo", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.policyNo = ?1"),
		@NamedQuery(name = "findClaimRulesLogByPolicyNoContaining", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.policyNo like ?1"),
		@NamedQuery(name = "findClaimRulesLogByPrimaryKey", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.claimRulesLogId = ?1"),
		@NamedQuery(name = "findClaimRulesLogByRiskLevel", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.riskLevel = ?1"),
		@NamedQuery(name = "findClaimRulesLogByRiskLevelContaining", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.riskLevel like ?1"),
		@NamedQuery(name = "findClaimRulesLogByRuleName", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.ruleName = ?1"),
		@NamedQuery(name = "findClaimRulesLogByRuleNameContaining", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.ruleName like ?1"),
		@NamedQuery(name = "retrieveEligibilityInformation", query = "select myClaimRulesLog from ClaimRulesLog myClaimRulesLog where myClaimRulesLog.claimNo= ?1 and myClaimRulesLog.occurrence= ?2 and myClaimRulesLog.policyNo= ?3 and myClaimRulesLog.planId=?4"), })
@Table(name = "CLAIMRULESLOG")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimRulesLog")
public class ClaimRulesLog extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimRulesLogSequence")
	@SequenceGenerator(name = "claimRulesLogSequence", sequenceName = "s_claimruleslog")
	@Column(name = "CLAIMRULESLOGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimRulesLogId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "RULENO", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ruleNo;

	@Column(name = "RULENAME", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ruleName;
	/**
	 */

	@Column(name = "RISKLEVEL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String riskLevel;
	/**
	 */

	@Column(name = "DECISION", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String decision;
	/**
	 */

	@Column(name = "RULEREVIEWDECISION", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ruleReviewDecision;
	/**
	 */

	@Column(name = "RULEREVIEWACTION", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ruleReviewAction;
	/**
	 */

	@Column(name = "RULEREVIEWCOMMENT", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ruleReviewComment;
	/**
	 */

	@Column(name = "RULEREVIEWER", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ruleReviewer;
	/**
	 */

	@Column(name = "RULEREVIEWDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date ruleReviewDt;

	@Column(name = "REASON", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String reason;

	/**
	 */

	/**
	 * @return the claimRulesLogId
	 */
	public Long getClaimRulesLogId() {
		return claimRulesLogId;
	}

	/**
	 * @param claimRulesLogId the claimRulesLogId to set
	 */
	public void setClaimRulesLogId(Long claimRulesLogId) {
		this.claimRulesLogId = claimRulesLogId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}

	public String getRuleNo() {
		return ruleNo;
	}

	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}

	/**
	 * @param ruleName the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	/**
	 * @return the riskLevel
	 */
	public String getRiskLevel() {
		return riskLevel;
	}

	/**
	 * @param riskLevel the riskLevel to set
	 */
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}

	/**
	 * @return the decision
	 */
	public String getDecision() {
		return decision;
	}

	/**
	 * @param decision the decision to set
	 */
	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getRuleReviewDecision() {
		return ruleReviewDecision;
	}

	public void setRuleReviewDecision(String ruleReviewDecision) {
		this.ruleReviewDecision = ruleReviewDecision;
	}

	public String getRuleReviewAction() {
		return ruleReviewAction;
	}

	public void setRuleReviewAction(String ruleReviewAction) {
		this.ruleReviewAction = ruleReviewAction;
	}

	public String getRuleReviewComment() {
		return ruleReviewComment;
	}

	public void setRuleReviewComment(String ruleReviewComment) {
		this.ruleReviewComment = ruleReviewComment;
	}

	public String getRuleReviewer() {
		return ruleReviewer;
	}

	public void setRuleReviewer(String ruleReviewer) {
		this.ruleReviewer = ruleReviewer;
	}

	public Date getRuleReviewDt() {
		return ruleReviewDt;
	}

	public void setRuleReviewDt(Date ruleReviewDt) {
		this.ruleReviewDt = ruleReviewDt;
	}

	/**
	 */
	public ClaimRulesLog() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimRulesLog that) {
		setClaimRulesLogId(that.getClaimRulesLogId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setRuleNo(that.getRuleNo());
		setRuleName(that.getRuleName());
		setRiskLevel(that.getRiskLevel());
		setDecision(that.getDecision());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimRulesLogId=[").append(claimRulesLogId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("ruleNo=[").append(ruleNo).append("] ");
		buffer.append("ruleName=[").append(ruleName).append("] ");
		buffer.append("riskLevel=[").append(riskLevel).append("] ");
		buffer.append("decision=[").append(decision).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimRulesLogId == null) ? 0 : claimRulesLogId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimRulesLog))
			return false;
		ClaimRulesLog equalCheck = (ClaimRulesLog) obj;
		if ((claimRulesLogId == null && equalCheck.claimRulesLogId != null) || (claimRulesLogId != null && equalCheck.claimRulesLogId == null))
			return false;
		if (claimRulesLogId != null && !claimRulesLogId.equals(equalCheck.claimRulesLogId))
			return false;
		return true;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
}
