package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCorrespondenceCodes", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode"),
		@NamedQuery(name = "findCorrespondenceCodeByBatchInd", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.batchInd = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByBatchIndContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.batchInd like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByBrokerInd", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.brokerInd = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByBrokerIndContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.brokerInd like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByClaimantInd", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.claimantInd = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByClaimantIndContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.claimantInd like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeBycorrespondenceCode", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.correspondenceCode = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeBycorrespondenceCodeContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.correspondenceCode like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByCorrespondenceDesc", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.correspondenceDesc = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByCorrespondenceDescContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.correspondenceDesc like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByOnlineInd", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.onlineInd = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByOnlineIndContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.onlineInd like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByPolicyHolderInd", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.policyHolderInd = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByPolicyHolderIndContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.policyHolderInd like ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByPrimaryKey", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.correspondenceCode = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByProviderInd", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.providerInd = ?1"),
		@NamedQuery(name = "findCorrespondenceCodeByProviderIndContaining", query = "select myCorrespondenceCode from CorrespondenceCode myCorrespondenceCode where myCorrespondenceCode.providerInd like ?1") })
@Table(name = "CORRESPONDENCECODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "CorrespondenceCode")
public class CorrespondenceCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@Column(name = "CORRESPONDENCECODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String correspondenceCode;
	/**
	 */

	@Column(name = "CORRESPONDENCEDESC", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String correspondenceDesc;
	/**
	 */

	@Column(name = "BATCHIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String batchInd;
	/**
	 */

	@Column(name = "ONLINEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String onlineInd;

	/**
	 */

	@Column(name = "POLICYHOLDERIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyHolderInd;
	/**
	 */

	@Column(name = "CLAIMANTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimantInd;
	/**
	 */

	@Column(name = "BROKERIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brokerInd;
	/**
	 */

	@Column(name = "PROVIDERIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerInd;

	/**
	 * @return the correspondenceCode
	 */
	public String getCorrespondenceCode() {
		return correspondenceCode;
	}

	/**
	 * @param correspondenceCode the correspondenceCode to set
	 */
	public void setCorrespondenceCode(String correspondenceCode) {
		this.correspondenceCode = correspondenceCode;
	}

	/**
	 * @return the correspondenceDesc
	 */
	public String getCorrespondenceDesc() {
		return correspondenceDesc;
	}

	/**
	 * @param correspondenceDesc the correspondenceDesc to set
	 */
	public void setCorrespondenceDesc(String correspondenceDesc) {
		this.correspondenceDesc = correspondenceDesc;
	}

	/**
	 * @return the batchInd
	 */
	public String getBatchInd() {
		return batchInd;
	}

	/**
	 * @param batchInd the batchInd to set
	 */
	public void setBatchInd(String batchInd) {
		this.batchInd = batchInd;
	}

	/**
	 * @param onlineInd the onlineInd to set
	 */
	public void setOnlineInd(String onlineInd) {
		this.onlineInd = onlineInd;
	}

	/**
	 * @return the onlineInd
	 */
	public String getOnlineInd() {
		return onlineInd;
	}

	/**
	 * @return the policyHolderInd
	 */
	public String getPolicyHolderInd() {
		return policyHolderInd;
	}

	/**
	 * @param policyHolderInd the policyHolderInd to set
	 */
	public void setPolicyHolderInd(String policyHolderInd) {
		this.policyHolderInd = policyHolderInd;
	}

	/**
	 * @return the claimantInd
	 */
	public String getClaimantInd() {
		return claimantInd;
	}

	/**
	 * @param claimantInd the claimantInd to set
	 */
	public void setClaimantInd(String claimantInd) {
		this.claimantInd = claimantInd;
	}

	/**
	 * @return the brokerInd
	 */
	public String getBrokerInd() {
		return brokerInd;
	}

	/**
	 * @param brokerInd the brokerInd to set
	 */
	public void setBrokerInd(String brokerInd) {
		this.brokerInd = brokerInd;
	}

	/**
	 * @return the providerInd
	 */
	public String getProviderInd() {
		return providerInd;
	}

	/**
	 * @param providerInd the providerInd to set
	 */
	public void setProviderInd(String providerInd) {
		this.providerInd = providerInd;
	}

	/**
	 */
	public CorrespondenceCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CorrespondenceCode that) {
		setCorrespondenceCode(that.getCorrespondenceCode());
		setCorrespondenceDesc(that.getCorrespondenceDesc());
		setBatchInd(that.getBatchInd());
		setOnlineInd(that.getOnlineInd());
		setPolicyHolderInd(that.getPolicyHolderInd());
		setClaimantInd(that.getClaimantInd());
		setBrokerInd(that.getBrokerInd());
		setProviderInd(that.getProviderInd());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("correspondenceCode=[").append(correspondenceCode).append("] ");
		buffer.append("correspondenceDesc=[").append(correspondenceDesc).append("] ");
		buffer.append("batchInd=[").append(batchInd).append("] ");
		buffer.append("onlineInd=[").append(onlineInd).append("] ");
		buffer.append("policyHolderInd=[").append(policyHolderInd).append("] ");
		buffer.append("claimantInd=[").append(claimantInd).append("] ");
		buffer.append("brokerInd=[").append(brokerInd).append("] ");
		buffer.append("providerInd=[").append(providerInd).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((correspondenceCode == null) ? 0 : correspondenceCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CorrespondenceCode))
			return false;
		CorrespondenceCode equalCheck = (CorrespondenceCode) obj;
		if ((correspondenceCode == null && equalCheck.correspondenceCode != null) || (correspondenceCode != null && equalCheck.correspondenceCode == null))
			return false;
		if (correspondenceCode != null && !correspondenceCode.equals(equalCheck.correspondenceCode))
			return false;
		return true;
	}
}
