package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllPhysicians", query = "select myPhysician from Physician myPhysician"),
		@NamedQuery(name = "findPhysicianByBlacklistInd", query = "select myPhysician from Physician myPhysician where myPhysician.blacklistInd = ?1"),
		@NamedQuery(name = "findPhysicianByBlacklistIndContaining", query = "select myPhysician from Physician myPhysician where myPhysician.blacklistInd like ?1"),
		@NamedQuery(name = "findPhysicianByBlacklistReason", query = "select myPhysician from Physician myPhysician where myPhysician.blacklistReason = ?1"),
		@NamedQuery(name = "findPhysicianByDeathInd", query = "select myPhysician from Physician myPhysician where myPhysician.deathInd = ?1"),
		@NamedQuery(name = "findPhysicianByDeathIndContaining", query = "select myPhysician from Physician myPhysician where myPhysician.deathInd like ?1"),
		@NamedQuery(name = "findPhysicianByDoctorCode", query = "select myPhysician from Physician myPhysician where myPhysician.doctorCode = ?1"),
		@NamedQuery(name = "findPhysicianByDoctorCodeContaining", query = "select myPhysician from Physician myPhysician where myPhysician.doctorCode like ?1"),
		@NamedQuery(name = "findPhysicianByFirstName", query = "select myPhysician from Physician myPhysician where myPhysician.firstName = ?1"),
		@NamedQuery(name = "findPhysicianByFirstNameContaining", query = "select myPhysician from Physician myPhysician where myPhysician.firstName like ?1"),
		@NamedQuery(name = "findPhysicianByLastName", query = "select myPhysician from Physician myPhysician where myPhysician.lastName = ?1"),
		@NamedQuery(name = "findPhysicianByLastNameContaining", query = "select myPhysician from Physician myPhysician where myPhysician.lastName like ?1"),
		@NamedQuery(name = "findPhysicianByLicenseNo", query = "select myPhysician from Physician myPhysician where myPhysician.licenseNo = ?1"),
		@NamedQuery(name = "findPhysicianByLicenseNoContaining", query = "select myPhysician from Physician myPhysician where myPhysician.licenseNo like ?1"),
		@NamedQuery(name = "findPhysicianByPhysicianId", query = "select myPhysician from Physician myPhysician where myPhysician.physicianId = ?1"),
		@NamedQuery(name = "findPhysicianByPrimaryKey", query = "select myPhysician from Physician myPhysician where myPhysician.physicianId = ?1"),
		@NamedQuery(name = "findPhysicianBySpecialist", query = "select myPhysician from Physician myPhysician where myPhysician.specialist = ?1"),
		@NamedQuery(name = "findPhysicianBySpecialistContaining", query = "select myPhysician from Physician myPhysician where myPhysician.specialist like ?1"),
		@NamedQuery(name = "findPhysicianByStatus", query = "select myPhysician from Physician myPhysician where myPhysician.status = ?1"),
		@NamedQuery(name = "findPhysicianByStatusContaining", query = "select myPhysician from Physician myPhysician where myPhysician.status like ?1"),
		@NamedQuery(name = "findPhysicianByType", query = "select myPhysician from Physician myPhysician where myPhysician.type = ?1"),
		@NamedQuery(name = "findPhysicianByTypeContaining", query = "select myPhysician from Physician myPhysician where myPhysician.type like ?1"),
		@NamedQuery(name = "findPhysicianByFieldContaining", query = "select myPhysician from Physician myPhysician where UPPER(myPhysician.licenseNo) like ?1 or UPPER(myPhysician.firstName) like ?2 or UPPER(myPhysician.lastName) like ?3"),
		@NamedQuery(name = "findPhysicianByFieldContainingAndStatus", query = "select myPhysician from Physician myPhysician where ( UPPER(myPhysician.licenseNo) like ?1 or UPPER(myPhysician.firstName) like ?2 or UPPER(myPhysician.lastName) like ?3 ) and myPhysician.status = ?4 "),
		@NamedQuery(name = "findPhysicianByPrevDoctorCode", query = "select myPhysician from Physician myPhysician where myPhysician.prevDoctorCode like ?1") })
@Table(name = "PHYSICIAN")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Physician")
public class Physician extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "physicianSequence")
	@SequenceGenerator(name = "physicianSequence", sequenceName = "s_physician")
	@Column(name = "PHYSICIANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long physicianId;
	/**
	 */

	@Column(name = "DOCTORCODE", length = 13, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doctorCode;
	/**
	 */

	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "LICENSENO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String licenseNo;
	/**
	 */

	@Column(name = "TYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String type;
	/**
	 */

	@Column(name = "FIRSTNAME", length = 50, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	/**
	 */

	@Column(name = "LASTNAME", length = 50, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	/**
	 */

	@Column(name = "STATUS", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;
	/**
	 */

	@Column(name = "SPECIALIST", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String specialist;
	/**
	 */
	@Column(name = "EFFECTIVEFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveFromDt;
	/**
	 */
	@Column(name = "EFFECTIVETODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveToDt;
	/**
	 */

	@Column(name = "DEATHIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deathInd;
	/**
	 */

	@Column(name = "BLACKLISTIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistInd;
	/**
	 */

	@Column(name = "BLACKLISTSTARTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date blacklistStartDate;
	/**
	 */

	@Column(name = "BLACKLISTENDDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date blacklistEndDate;

	@Column(name = "PREVDOCTORCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorCode;

	@Column(name = "BLACKLISTREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistReason;

	/**
	 */
	/**
	 */

	/**
	 * @return the physicianId
	 */
	public Long getPhysicianId() {
		return physicianId;
	}

	/**
	 * @param physicianId the physicianId to set
	 */
	public void setPhysicianId(Long physicianId) {
		this.physicianId = physicianId;
	}

	/**
	 * @return the doctorCode
	 */
	public String getDoctorCode() {
		return doctorCode;
	}

	/**
	 * @param doctorCode the doctorCode to set
	 */
	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the licenseNo
	 */
	public String getLicenseNo() {
		return licenseNo;
	}

	/**
	 * @param licenseNo the licenseNo to set
	 */
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the specialist
	 */
	public String getSpecialist() {
		return specialist;
	}

	/**
	 * @param specialist the specialist to set
	 */
	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}

	/**
	 * @return the effectiveFromDt
	 */
	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	/**
	 * @param effectiveFromDt the effectiveFromDt to set
	 */
	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	/**
	 * @return the effectiveToDt
	 */
	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	/**
	 * @param effectiveToDt the effectiveToDt to set
	 */
	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	/**
	 * @return the deathInd
	 */
	public String getDeathInd() {
		return deathInd;
	}

	/**
	 * @param deathInd the deathInd to set
	 */
	public void setDeathInd(String deathInd) {
		this.deathInd = deathInd;
	}

	/**
	 * @return the blacklistInd
	 */
	public String getBlacklistInd() {
		return blacklistInd;
	}

	/**
	 * @param blacklistInd the blacklistInd to set
	 */
	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	/**
	 * @return the blacklistStartDate
	 */
	public Date getBlacklistStartDate() {
		return blacklistStartDate;
	}

	/**
	 * @param blacklistStartDate the blacklistStartDate to set
	 */
	public void setBlacklistStartDate(Date blacklistStartDate) {
		this.blacklistStartDate = blacklistStartDate;
	}

	/**
	 * @return the blacklistEndDate
	 */
	public Date getBlacklistEndDate() {
		return blacklistEndDate;
	}

	/**
	 * @param blacklistEndDate the blacklistEndDate to set
	 */
	public void setBlacklistEndDate(Date blacklistEndDate) {
		this.blacklistEndDate = blacklistEndDate;
	}

	public String getPrevDoctorCode() {
		return prevDoctorCode;
	}

	public void setPrevDoctorCode(String prevDoctorCode) {
		this.prevDoctorCode = prevDoctorCode;
	}

	public String getBlacklistReason() {
		return blacklistReason;
	}

	public void setBlacklistReason(String blacklistReason) {
		this.blacklistReason = blacklistReason;
	}

	/**
	 */
	public Physician() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Physician that) {
		setPhysicianId(that.getPhysicianId());
		setDoctorCode(that.getDoctorCode());
		setCompanyId(that.getCompanyId());
		setLicenseNo(that.getLicenseNo());
		setType(that.getType());
		setFirstName(that.getFirstName());
		setLastName(that.getLastName());
		setStatus(that.getStatus());
		setSpecialist(that.getSpecialist());
		setEffectiveFromDt(that.getEffectiveFromDt());
		setEffectiveToDt(that.getEffectiveToDt());
		setDeathInd(that.getDeathInd());
		setBlacklistInd(that.getBlacklistInd());
		setBlacklistStartDate(that.getBlacklistStartDate());
		setBlacklistEndDate(that.getBlacklistEndDate());
		setPrevDoctorCode(that.getPrevDoctorCode());
		setBlacklistReason(that.getBlacklistReason());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setBlacklistReason(that.getBlacklistReason());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("physicianId=[").append(physicianId).append("] ");
		buffer.append("doctorCode=[").append(doctorCode).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("licenseNo=[").append(licenseNo).append("] ");
		buffer.append("type=[").append(type).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("specialist=[").append(specialist).append("] ");
		buffer.append("effectiveFromDt=[").append(effectiveFromDt).append("] ");
		buffer.append("effectiveToDt=[").append(effectiveToDt).append("] ");
		buffer.append("deathInd=[").append(deathInd).append("] ");
		buffer.append("blacklistInd=[").append(blacklistInd).append("] ");
		buffer.append("blacklistReason=[").append(blacklistReason).append("] ");
		buffer.append("blacklistStartDate=[").append(blacklistStartDate).append("] ");
		buffer.append("blacklistEndDate=[").append(blacklistEndDate).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((physicianId == null) ? 0 : physicianId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Physician))
			return false;
		Physician equalCheck = (Physician) obj;
		if ((physicianId == null && equalCheck.physicianId != null) || (physicianId != null && equalCheck.physicianId == null))
			return false;
		if (physicianId != null && !physicianId.equals(equalCheck.physicianId))
			return false;
		return true;
	}
}
