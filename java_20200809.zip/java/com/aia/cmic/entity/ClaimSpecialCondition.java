package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 */

//@Entity
@SqlResultSetMapping(name = "ClaimSpecialCondition", classes = { @ConstructorResult(targetClass = ClaimSpecialCondition.class, columns = { @ColumnResult(name = "claimSupplementId")

}) })
//@Table(name = "PROVIDER")
//@SecondaryTables({ @SecondaryTable(name = "PROVIDERCONTACT", pkJoinColumns = @PrimaryKeyJoinColumn(name = "PROVIDERCODE", referencedColumnName = "PROVIDERCODE")) })
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderJoinProviderContact")
public class ClaimSpecialCondition extends BaseEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 */
	@Id
	@Column(name = "CLAIMSUPPLEMENTID")
	Long claimSupplementId;
	/**
	 */

	@Column(name = "POLICYNO")
	String policyNo;
	/**
	 */

	@Column(name = "STRVALUE")
	String strValue;
	/**
	 */

	@Column(name = "DESCRIPTION")
	String description;

	/**
	 */
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public void copy(ProviderJoinProviderContact that) {

	}

	public Long getClaimSupplementId() {
		return claimSupplementId;
	}

	public void setClaimSupplementId(Long claimSupplementId) {
		this.claimSupplementId = claimSupplementId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getStrValue() {
		return strValue;
	}

	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ClaimSpecialCondition(Long claimSupplementId, String policyNo, String strValue, String description) {
		super();
		this.claimSupplementId = claimSupplementId;
		this.policyNo = policyNo;
		this.strValue = strValue;
		this.description = description;
	}

	public ClaimSpecialCondition() {

	}
}
