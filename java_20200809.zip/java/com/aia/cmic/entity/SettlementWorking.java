package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		//		@NamedQuery(name = "findAllSettlementWorking", query = "select mySettlmentWorking from SettlementWorking mySettlmentWorking"),
		//		@NamedQuery(name = "findSettlementWorkingBySettlementWorkingId", query = "select mySettlmentWorking from SettlementWorking mySettlmentWorking where mySettlmentWorking.settlementWorkingId = ?1"),
		@NamedQuery(name = "findSettlementWorkingByClaimNoOccurrencePolicyNoAndProductCode", query = "select mySettlmentWorking from SettlementWorking mySettlmentWorking where mySettlmentWorking.claimNo= ?1 and mySettlmentWorking.occurrence= ?2 and mySettlmentWorking.policyNo= ?3 and mySettlmentWorking.productCode= ?4 "),
		@NamedQuery(name = "findSettlementWorkingByClaimNoOccurrencePolicyNoAndProductCodePlanId", query = "select mySettlmentWorking from SettlementWorking mySettlmentWorking where mySettlmentWorking.claimNo= ?1 and mySettlmentWorking.occurrence= ?2 and mySettlmentWorking.policyNo= ?3 and mySettlmentWorking.productCode= ?4 and mySettlmentWorking.planId= ?5 "),
		@NamedQuery(name = "findSettlementWorkingByClaimNoOccurrence", query = "select mySettlmentWorking from SettlementWorking mySettlmentWorking where mySettlmentWorking.claimNo= ?1 and mySettlmentWorking.occurrence= ?2 "),
		@NamedQuery(name = "deleteSettlementWorkingByClaimNoOccurrence", query = "delete from SettlementWorking mySettlmentWorking where mySettlmentWorking.claimNo= ?1 and mySettlmentWorking.occurrence= ?2 "),

})
@Table(name = "SETTLEMENTWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "SettlementWorking")
public class SettlementWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "settlementWorkingSequence")
	@SequenceGenerator(name = "settlementWorkingSequence", sequenceName = "s_settlementworking")
	@Column(name = "SETTLEMENTWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long settlementWorkingId;

	/**
	 */
	@Column(name = "CYCLEDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date cycleDate;

	/**
	 */
	@Column(name = "PAYMENTCHANNEL", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentChannel;

	/**
	 */
	@Column(name = "KEYCLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String keyClaimNo;

	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	/**
	 */
	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	/**
	 */
	@Column(name = "TRANSACTIONDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date transactionDt;

	/**
	 */
	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;

	/**
	 */
	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;

	/**
	 */
	@Column(name = "CLAIMTYPE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimType;

	/**
	 */
	@Column(name = "DAYSALLOCH11")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer daysAllocH11;

	/**
	 */
	@Column(name = "DAYSALLOCA01")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer daysAllocA01;

	/**
	 */
	@Column(name = "DAYSALLOCA02")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer daysAllocA02;

	/**
	 */
	@Column(name = "PRESENTEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt;

	/**
	 */
	@Column(name = "REIMBURSEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal reimbursedAmt;

	/**
	 */
	@Column(name = "ACCIDENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date accidentDt;

	/**
	 */
	@Column(name = "HOSPITALIZATIONDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date hospitalizationDt;

	/**
	 */
	@Column(name = "DISCHARGEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dischargeDt;

	/**
	 */
	@Column(name = "PLANNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planName;

	/**
	 */
	@Column(name = "PLANCOVERAGENO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;

	/**
	 */
	@Column(name = "BENEFITCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;

	/**
	 */
	@Column(name = "BENEFITDESCTHAI", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitDescThai;

	/**
	 */
	@Column(name = "NOOFDAYSPRESENTED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysPresented;

	/**
	 */
	@Column(name = "PRESENTEDPERCENT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedPercent;

	/**
	 */
	@Column(name = "NOOFDAYALLOC")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDayAlloc;

	/**
	 */
	@Column(name = "ALLOCATEDPERCENT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal allocatedPercent;

	/**
	 */
	@Column(name = "BENEFITREIMBURSEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal benefitReimbursedAmt;

	/**
	 */
	@Column(name = "MAXCLAIMLIMITAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxClaimLimitAmt;

	/**
	 */
	@Column(name = "DEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal deductAmt;

	/**
	 */
	@Column(name = "COMMENTLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String commentLine;

	/**
	 */
	@Column(name = "DECLINEDESCLONG")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String declineDescLong;

	/**
	 */
	@Column(name = "DOUBLEINDEMNITYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doubleIndemnityInd;

	/**
	 */
	@Column(name = "LETTERIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String letterInd;

	/**
	 */
	@Column(name = "INSUREDLASTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredLastName;

	/**
	 */
	@Column(name = "INSUREDFIRSTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredFirstName;

	/**
	 */
	@Column(name = "SUMASSURED", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal sumAssured;

	/**
	 */
	@Column(name = "SUMREIMBURSED", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal sumReimbursed;

	/**
	 */
	@Column(name = "PABONUSDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal paBonusDeductAmt;

	/**
	 */
	@Column(name = "ADJUSTEDREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String adjustedReason;

	/**
	 */
	@Column(name = "CSFORMATPOLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csFormatPolicyNo;

	/**
	 */
	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;

	/**
	 * 
	 */
	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;

	/**
	 */
	@Column(name = "PAYEETITLE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTitle;

	/**
	 */
	@Column(name = "PAYEELASTNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeLastName;

	/**
	 */
	@Column(name = "PAYEEFIRSTNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeFirstName;

	/**
	 */
	@Column(name = "ADDRESSLINE1", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;

	/**
	 */
	@Column(name = "ADDRESSLINE2", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;

	/**
	 */
	@Column(name = "ADDRESSLINE3", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;

	/**
	 */
	@Column(name = "ADDRESSLINE4", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;

	/**
	 */

	@Column(name = "CITY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String city;

	/**
	 */
	@Column(name = "STATE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String state;

	/**
	 */
	@Column(name = "POSTALCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postalCode;

	/**
	 */
	@Column(name = "COUNTRY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String country;

	/**
	 */
	@Column(name = "CERTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String certNo;

	/**
	 */
	@Column(name = "PAYEETYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeType;

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;

	@Column(name = "DISTRIBUTIONIND", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String distributionInd;

	public Long getSettlementWorkingId() {
		return settlementWorkingId;
	}

	public void setSettlementWorkingId(Long settlementWorkingId) {
		this.settlementWorkingId = settlementWorkingId;
	}

	public Date getCycleDate() {
		return cycleDate;
	}

	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

	public String getKeyClaimNo() {
		return keyClaimNo;
	}

	public void setKeyClaimNo(String keyClaimNo) {
		this.keyClaimNo = keyClaimNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public Date getTransactionDt() {
		return transactionDt;
	}

	public void setTransactionDt(Date transactionDt) {
		this.transactionDt = transactionDt;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public Integer getDaysAllocH11() {
		return daysAllocH11;
	}

	public void setDaysAllocH11(Integer daysAllocH11) {
		this.daysAllocH11 = daysAllocH11;
	}

	public Integer getDaysAllocA01() {
		return daysAllocA01;
	}

	public void setDaysAllocA01(Integer daysAllocA01) {
		this.daysAllocA01 = daysAllocA01;
	}

	public Integer getDaysAllocA02() {
		return daysAllocA02;
	}

	public void setDaysAllocA02(Integer daysAllocA02) {
		this.daysAllocA02 = daysAllocA02;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	public BigDecimal getReimbursedAmt() {
		return reimbursedAmt;
	}

	public void setReimbursedAmt(BigDecimal reimbursedAmt) {
		this.reimbursedAmt = reimbursedAmt;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public Date getHospitalizationDt() {
		return hospitalizationDt;
	}

	public void setHospitalizationDt(Date hospitalizationDt) {
		this.hospitalizationDt = hospitalizationDt;
	}

	public Date getDischargeDt() {
		return dischargeDt;
	}

	public void setDischargeDt(Date dischargeDt) {
		this.dischargeDt = dischargeDt;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public String getBenefitDescThai() {
		return benefitDescThai;
	}

	public void setBenefitDescThai(String benefitDescThai) {
		this.benefitDescThai = benefitDescThai;
	}

	public Integer getNoOfDaysPresented() {
		return noOfDaysPresented;
	}

	public void setNoOfDaysPresented(Integer noOfDaysPresented) {
		this.noOfDaysPresented = noOfDaysPresented;
	}

	public BigDecimal getPresentedPercent() {
		return presentedPercent;
	}

	public void setPresentedPercent(BigDecimal presentedPercent) {
		this.presentedPercent = presentedPercent;
	}

	public Integer getNoOfDayAlloc() {
		return noOfDayAlloc;
	}

	public void setNoOfDayAlloc(Integer noOfDayAlloc) {
		this.noOfDayAlloc = noOfDayAlloc;
	}

	public BigDecimal getAllocatedPercent() {
		return allocatedPercent;
	}

	public void setAllocatedPercent(BigDecimal allocatedPercent) {
		this.allocatedPercent = allocatedPercent;
	}

	public BigDecimal getBenefitReimbursedAmt() {
		return benefitReimbursedAmt;
	}

	public void setBenefitReimbursedAmt(BigDecimal benefitReimbursedAmt) {
		this.benefitReimbursedAmt = benefitReimbursedAmt;
	}

	public BigDecimal getMaxClaimLimitAmt() {
		return maxClaimLimitAmt;
	}

	public void setMaxClaimLimitAmt(BigDecimal maxClaimLimitAmt) {
		this.maxClaimLimitAmt = maxClaimLimitAmt;
	}

	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	public String getCommentLine() {
		return commentLine;
	}

	public void setCommentLine(String commentLine) {
		this.commentLine = commentLine;
	}

	public String getDeclineDescLong() {
		return declineDescLong;
	}

	public void setDeclineDescLong(String declineDescLong) {
		this.declineDescLong = declineDescLong;
	}

	public String getDoubleIndemnityInd() {
		return doubleIndemnityInd;
	}

	public void setDoubleIndemnityInd(String doubleIndemnityInd) {
		this.doubleIndemnityInd = doubleIndemnityInd;
	}

	public String getLetterInd() {
		return letterInd;
	}

	public void setLetterInd(String letterInd) {
		this.letterInd = letterInd;
	}

	public String getInsuredLastName() {
		return insuredLastName;
	}

	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String getInsuredFirstName() {
		return insuredFirstName;
	}

	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	public BigDecimal getSumReimbursed() {
		return sumReimbursed;
	}

	public void setSumReimbursed(BigDecimal sumReimbursed) {
		this.sumReimbursed = sumReimbursed;
	}

	public BigDecimal getPaBonusDeductAmt() {
		return paBonusDeductAmt;
	}

	public void setPaBonusDeductAmt(BigDecimal paBonusDeductAmt) {
		this.paBonusDeductAmt = paBonusDeductAmt;
	}

	public String getAdjustedReason() {
		return adjustedReason;
	}

	public void setAdjustedReason(String adjustedReason) {
		this.adjustedReason = adjustedReason;
	}

	public String getCsFormatPolicyNo() {
		return csFormatPolicyNo;
	}

	public void setCsFormatPolicyNo(String csFormatPolicyNo) {
		this.csFormatPolicyNo = csFormatPolicyNo;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeLastName() {
		return payeeLastName;
	}

	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	public String getPayeeFirstName() {
		return payeeFirstName;
	}

	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	public String getDistributionInd() {
		return distributionInd;
	}

	public void setDistributionInd(String distributionInd) {
		this.distributionInd = distributionInd;
	}

	/**
	 */
	public SettlementWorking() {
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((settlementWorkingId == null) ? 0 : settlementWorkingId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof SettlementWorking))
			return false;
		SettlementWorking equalCheck = (SettlementWorking) obj;
		if ((settlementWorkingId == null && equalCheck.settlementWorkingId != null) || (settlementWorkingId != null && equalCheck.settlementWorkingId == null))
			return false;
		if (settlementWorkingId != null && !settlementWorkingId.equals(equalCheck.settlementWorkingId))
			return false;
		return true;
	}
}
