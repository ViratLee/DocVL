package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "EDIPROCEDURE")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "EdiProcedure")
public class EdiProcedure extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ediProcedureSequence")
	@SequenceGenerator(name = "ediProcedureSequence", sequenceName = "s_ediprocedure")
	@Column(name = "EDIPROCEDUREID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long ediProcedureId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "ICD9", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd9;

	@Column(name = "ICD9SUB", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd9Sub;

	@Column(name = "PROCEDURENAME", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String procedureName;

	@Column(name = "PROCEDUREDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date procedureDate;

	public Long getEdiProcedureId() {
		return ediProcedureId;
	}

	public void setEdiProcedureId(Long ediProcedureId) {
		this.ediProcedureId = ediProcedureId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getIcd9() {
		return icd9;
	}

	public void setIcd9(String icd9) {
		this.icd9 = setMaxLength("icd9", icd9);
	}

	public String getIcd9Sub() {
		return icd9Sub;
	}

	public void setIcd9Sub(String icd9Sub) {
		this.icd9Sub = setMaxLength("icd9Sub", icd9Sub);
	}

	public String getProcedureName() {
		return procedureName;
	}

	public void setProcedureName(String procedureName) {
		this.procedureName = setMaxLength("procedureName", procedureName);
	}

	public Date getProcedureDate() {
		return procedureDate;
	}

	public void setProcedureDate(Date procedureDate) {
		this.procedureDate = procedureDate;
	}

	public EdiProcedure() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(EdiProcedure that) {

		setEdiProcedureId(that.getEdiProcedureId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setIcd9(that.getIcd9());
		setIcd9Sub(that.getIcd9Sub());
		setProcedureName(that.getProcedureName());
		setProcedureDate(that.getProcedureDate());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("ediProcedureId=[").append(ediProcedureId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("icd9=[").append(icd9).append("] ");
		buffer.append("icd9Sub=[").append(icd9Sub).append("] ");
		buffer.append("procedureName=[").append(procedureName).append("] ");
		buffer.append("procedureDate=[").append(procedureDate).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((ediProcedureId == null) ? 0 : ediProcedureId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof EdiProcedure))
			return false;
		EdiProcedure equalCheck = (EdiProcedure) obj;
		if ((ediProcedureId == null && equalCheck.ediProcedureId != null) || (ediProcedureId != null && equalCheck.ediProcedureId == null))
			return false;
		if (ediProcedureId != null && !ediProcedureId.equals(equalCheck.ediProcedureId))
			return false;
		return true;
	}

	private String setMaxLength(String columnName, String data) {
		if (data == null) {
			return data;
		}
		try {
			int size = getClass().getDeclaredField(columnName).getAnnotation(Column.class).length();
			int inLength = data.length();
			if (inLength > size) {
				data = data.substring(0, size);
			}
		} catch (NoSuchFieldException ex) {
		} catch (SecurityException ex) {
		}
		return data;
	}
}
