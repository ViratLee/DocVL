package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllExclusions", query = "select myExclusion from Exclusion myExclusion"),
		@NamedQuery(name = "findExclusionByExclusionCode", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionCode = ?1"),
		@NamedQuery(name = "findExclusionByExclusionCodeContaining", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionCode like ?1"),
		@NamedQuery(name = "findExclusionByExclusionDesc", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionDesc = ?1"),
		@NamedQuery(name = "findExclusionByExclusionDescContaining", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionDesc like ?1"),
		@NamedQuery(name = "findExclusionByExclusionId", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionId = ?1"),
		@NamedQuery(name = "findExclusionByExclusionType", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionType = ?1"),
		@NamedQuery(name = "findExclusionByExclusionTypeContaining", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionType like ?1"),
		@NamedQuery(name = "findExclusionByExclusionValue", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionValue = ?1"),
		@NamedQuery(name = "findExclusionByExclusionValueContaining", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionValue like ?1"),
		@NamedQuery(name = "findExclusionByPrimaryKey", query = "select myExclusion from Exclusion myExclusion where myExclusion.exclusionId = ?1"),
		@NamedQuery(name = "findExclusionByWaitingPeriod", query = "select myExclusion from Exclusion myExclusion where myExclusion.waitingPeriod = ?1") })
@Table(name = "EXCLUSION")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Exclusion")
public class Exclusion extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "exclusionSequence")
	@SequenceGenerator(name = "exclusionSequence", sequenceName = "s_exclusion")
	@Column(name = "EXCLUSIONID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long exclusionId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "EXCLUSIONTYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusionType;
	/**
	 */

	@Column(name = "EXCLUSIONCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusionCode;
	/**
	 */

	@Column(name = "EXCLUSIONVALUE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusionValue;
	/**
	 */

	@Column(name = "EXCLUSIONDESC", length = 200, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusionDesc;
	/**
	 */

	@Column(name = "WAITINGPERIOD", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer waitingPeriod;

	@Column(name = "EFFFROMDT")
	@CreatedDate
	Date effFromDt;

	@Column(name = "EFFTODT")
	@LastModifiedDate
	Date effToDt;

	/**
	 */

	/**
	 * @return the exclusionId
	 */
	public Long getExclusionId() {
		return exclusionId;
	}

	/**
	 * @param exclusionId the exclusionId to set
	 */
	public void setExclusionId(Long exclusionId) {
		this.exclusionId = exclusionId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the exclusionType
	 */
	public String getExclusionType() {
		return exclusionType;
	}

	/**
	 * @param exclusionType the exclusionType to set
	 */
	public void setExclusionType(String exclusionType) {
		this.exclusionType = exclusionType;
	}

	/**
	 * @return the exclusionCode
	 */
	public String getExclusionCode() {
		return exclusionCode;
	}

	/**
	 * @param exclusionCode the exclusionCode to set
	 */
	public void setExclusionCode(String exclusionCode) {
		this.exclusionCode = exclusionCode;
	}

	/**
	 * @return the exclusionValue
	 */
	public String getExclusionValue() {
		return exclusionValue;
	}

	/**
	 * @param exclusionValue the exclusionValue to set
	 */
	public void setExclusionValue(String exclusionValue) {
		this.exclusionValue = exclusionValue;
	}

	/**
	 * @return the exclusionDesc
	 */
	public String getExclusionDesc() {
		return exclusionDesc;
	}

	/**
	 * @param exclusionDesc the exclusionDesc to set
	 */
	public void setExclusionDesc(String exclusionDesc) {
		this.exclusionDesc = exclusionDesc;
	}

	/**
	 * @return the waitingPeriod
	 */
	public Integer getWaitingPeriod() {
		return waitingPeriod;
	}

	/**
	 * @param waitingPeriod the waitingPeriod to set
	 */
	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	public Date getEffFromDt() {
		return effFromDt;
	}

	public void setEffFromDt(Date effFromDt) {
		this.effFromDt = effFromDt;
	}

	public Date getEffToDt() {
		return effToDt;
	}

	public void setEffToDt(Date effToDt) {
		this.effToDt = effToDt;
	}

	/**
	 */
	public Exclusion() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Exclusion that) {
		setExclusionId(that.getExclusionId());
		setCompanyId(that.getCompanyId());
		setExclusionType(that.getExclusionType());
		setExclusionCode(that.getExclusionCode());
		setExclusionValue(that.getExclusionValue());
		setExclusionDesc(that.getExclusionDesc());
		setWaitingPeriod(that.getWaitingPeriod());
		setEffFromDt(that.getEffFromDt());
		setEffToDt(that.getEffToDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("exclusionId=[").append(exclusionId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("exclusionType=[").append(exclusionType).append("] ");
		buffer.append("exclusionCode=[").append(exclusionCode).append("] ");
		buffer.append("exclusionValue=[").append(exclusionValue).append("] ");
		buffer.append("exclusionDesc=[").append(exclusionDesc).append("] ");
		buffer.append("waitingPeriod=[").append(waitingPeriod).append("] ");
		buffer.append("effFromDt=[").append(effFromDt).append("] ");
		buffer.append("effToDt=[").append(effToDt).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((exclusionId == null) ? 0 : exclusionId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Exclusion))
			return false;
		Exclusion equalCheck = (Exclusion) obj;
		if ((exclusionId == null && equalCheck.exclusionId != null) || (exclusionId != null && equalCheck.exclusionId == null))
			return false;
		if (exclusionId != null && !exclusionId.equals(equalCheck.exclusionId))
			return false;
		return true;
	}
}
