package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlElement;

/**
 */

//@Entity
//@NamedQueries({
//		@NamedQuery(name = "findAllStatusCodes", query = "select myStatusCode from StatusCode myStatusCode"),
//		@NamedQuery(name = "findStatusCodeByPrimaryKey", query = "select myStatusCode from StatusCode myStatusCode where myStatusCode.statusCodeField = ?1"),
//		@NamedQuery(name = "findStatusCodeByStatus", query = "select myStatusCode from StatusCode myStatusCode where myStatusCode.status = ?1"),
//		@NamedQuery(name = "findStatusCodeByStatusContaining", query = "select myStatusCode from StatusCode myStatusCode where myStatusCode.status like ?1"),
//		@NamedQuery(name = "findStatusCodeByStatusCodeField", query = "select myStatusCode from StatusCode myStatusCode where myStatusCode.statusCodeField = ?1"),
//		@NamedQuery(name = "findStatusCodeByStatusCodeFieldContaining", query = "select myStatusCode from StatusCode myStatusCode where myStatusCode.statusCodeField like ?1") })
//
//@Table(name = "STATUSCODE")
//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(namespace = "com/aia/cmic/entity", name = "StatusCode")

public class StatusCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "STATUSCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String statusCodeField;
	/**
	 */

	@Column(name = "STATUS", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;

	/**
	 */

	/**
	 * @return the statusCodeField
	 */
	public String getStatusCodeField() {
		return statusCodeField;
	}

	/**
	 * @param statusCodeField the statusCodeField to set
	 */
	public void setStatusCodeField(String statusCodeField) {
		this.statusCodeField = statusCodeField;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 */
	public StatusCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(StatusCode that) {
		setStatusCodeField(that.getStatusCodeField());
		setStatus(that.getStatus());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("statusCodeField=[").append(statusCodeField).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((statusCodeField == null) ? 0 : statusCodeField.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof StatusCode))
			return false;
		StatusCode equalCheck = (StatusCode) obj;
		if ((statusCodeField == null && equalCheck.statusCodeField != null) || (statusCodeField != null && equalCheck.statusCodeField == null))
			return false;
		if (statusCodeField != null && !statusCodeField.equals(equalCheck.statusCodeField))
			return false;
		return true;
	}
}
