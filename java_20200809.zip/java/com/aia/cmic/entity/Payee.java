package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllPayees", query = "select myPayee from Payee myPayee"),
		@NamedQuery(name = "findPayeeByAcctType", query = "select myPayee from Payee myPayee where myPayee.acctType = ?1"),
		@NamedQuery(name = "findPayeeByAcctTypeContaining", query = "select myPayee from Payee myPayee where myPayee.acctType like ?1"),
		@NamedQuery(name = "findPayeeByAddressLine1", query = "select myPayee from Payee myPayee where myPayee.addressLine1 = ?1"),
		@NamedQuery(name = "findPayeeByAddressLine1Containing", query = "select myPayee from Payee myPayee where myPayee.addressLine1 like ?1"),
		@NamedQuery(name = "findPayeeByAddressLine2", query = "select myPayee from Payee myPayee where myPayee.addressLine2 = ?1"),
		@NamedQuery(name = "findPayeeByAddressLine2Containing", query = "select myPayee from Payee myPayee where myPayee.addressLine2 like ?1"),
		@NamedQuery(name = "findPayeeByAddressLine3", query = "select myPayee from Payee myPayee where myPayee.addressLine3 = ?1"),
		@NamedQuery(name = "findPayeeByAddressLine3Containing", query = "select myPayee from Payee myPayee where myPayee.addressLine3 like ?1"),
		@NamedQuery(name = "findPayeeByAddressLine4", query = "select myPayee from Payee myPayee where myPayee.addressLine4 = ?1"),
		@NamedQuery(name = "findPayeeByAddressLine4Containing", query = "select myPayee from Payee myPayee where myPayee.addressLine4 like ?1"),
		@NamedQuery(name = "findPayeeByAmloInd", query = "select myPayee from Payee myPayee where myPayee.amloInd = ?1"),
		@NamedQuery(name = "findPayeeByAmloIndContaining", query = "select myPayee from Payee myPayee where myPayee.amloInd like ?1"),
		@NamedQuery(name = "findPayeeByBankAccountNo", query = "select myPayee from Payee myPayee where myPayee.bankAccountNo = ?1"),
		@NamedQuery(name = "findPayeeByBankAccountNoContaining", query = "select myPayee from Payee myPayee where myPayee.bankAccountNo like ?1"),
		@NamedQuery(name = "findPayeeByBankCode", query = "select myPayee from Payee myPayee where myPayee.bankCode = ?1"),
		@NamedQuery(name = "findPayeeByBankCodeContaining", query = "select myPayee from Payee myPayee where myPayee.bankCode like ?1"),
		@NamedQuery(name = "findPayeeByBankruptcyInd", query = "select myPayee from Payee myPayee where myPayee.bankruptcyInd = ?1"),
		@NamedQuery(name = "findPayeeByBankruptcyIndContaining", query = "select myPayee from Payee myPayee where myPayee.bankruptcyInd like ?1"),
		@NamedQuery(name = "findPayeeByBillingTypeCd", query = "select myPayee from Payee myPayee where myPayee.billingTypeCd = ?1"),
		@NamedQuery(name = "findPayeeByBillingTypeCdContaining", query = "select myPayee from Payee myPayee where myPayee.billingTypeCd like ?1"),
		@NamedQuery(name = "findPayeeByBlacklistInd", query = "select myPayee from Payee myPayee where myPayee.blacklistInd = ?1"),
		@NamedQuery(name = "findPayeeByBlacklistIndContaining", query = "select myPayee from Payee myPayee where myPayee.blacklistInd like ?1"),
		@NamedQuery(name = "findPayeeByCity", query = "select myPayee from Payee myPayee where myPayee.city = ?1"),
		@NamedQuery(name = "findPayeeByCityContaining", query = "select myPayee from Payee myPayee where myPayee.city like ?1"),
		@NamedQuery(name = "findPayeeByClaimNo", query = "select myPayee from Payee myPayee where myPayee.claimNo = ?1"),
		@NamedQuery(name = "findPayeeByCountry", query = "select myPayee from Payee myPayee where myPayee.country = ?1"),
		@NamedQuery(name = "findPayeeByCountryContaining", query = "select myPayee from Payee myPayee where myPayee.country like ?1"),
		@NamedQuery(name = "findPayeeByEmailAddress", query = "select myPayee from Payee myPayee where myPayee.emailAddress = ?1"),
		@NamedQuery(name = "findPayeeByEmailAddressContaining", query = "select myPayee from Payee myPayee where myPayee.emailAddress like ?1"),
		@NamedQuery(name = "findPayeeByFatcaInd", query = "select myPayee from Payee myPayee where myPayee.fatcaInd = ?1"),
		@NamedQuery(name = "findPayeeByFatcaIndContaining", query = "select myPayee from Payee myPayee where myPayee.fatcaInd like ?1"),
		@NamedQuery(name = "findPayeeByFirstName", query = "select myPayee from Payee myPayee where myPayee.firstName = ?1"),
		@NamedQuery(name = "findPayeeByFirstNameContaining", query = "select myPayee from Payee myPayee where myPayee.firstName like ?1"),
		@NamedQuery(name = "findPayeeByLastName", query = "select myPayee from Payee myPayee where myPayee.lastName = ?1"),
		@NamedQuery(name = "findPayeeByLastNameContaining", query = "select myPayee from Payee myPayee where myPayee.lastName like ?1"),
		@NamedQuery(name = "findPayeeByNationalId", query = "select myPayee from Payee myPayee where myPayee.nationalId = ?1"),
		@NamedQuery(name = "findPayeeByNationalIdContaining", query = "select myPayee from Payee myPayee where myPayee.nationalId like ?1"),
		@NamedQuery(name = "findPayeeByOfacInd", query = "select myPayee from Payee myPayee where myPayee.ofacInd = ?1"),
		@NamedQuery(name = "findPayeeByOfacIndContaining", query = "select myPayee from Payee myPayee where myPayee.ofacInd like ?1"),
		@NamedQuery(name = "findPayeeByPayeeId", query = "select myPayee from Payee myPayee where myPayee.payeeId = ?1"),
		@NamedQuery(name = "findPayeeByPayeeTaxNo", query = "select myPayee from Payee myPayee where myPayee.payeeTaxNo = ?1"),
		@NamedQuery(name = "findPayeeByPayeeTaxNoContaining", query = "select myPayee from Payee myPayee where myPayee.payeeTaxNo like ?1"),
		@NamedQuery(name = "findPayeeByPolicyNo", query = "select myPayee from Payee myPayee where myPayee.policyNo = ?1"),
		@NamedQuery(name = "findPayeeByPolicyNoContaining", query = "select myPayee from Payee myPayee where myPayee.policyNo like ?1"),
		@NamedQuery(name = "findPayeeByPostalCode", query = "select myPayee from Payee myPayee where myPayee.postalCode = ?1"),
		@NamedQuery(name = "findPayeeByPostalCodeContaining", query = "select myPayee from Payee myPayee where myPayee.postalCode like ?1"),
		@NamedQuery(name = "findPayeeByPrimaryKey", query = "select myPayee from Payee myPayee where myPayee.payeeId = ?1"),
		@NamedQuery(name = "findPayeeByState", query = "select myPayee from Payee myPayee where myPayee.state = ?1"),
		@NamedQuery(name = "findPayeeByStateContaining", query = "select myPayee from Payee myPayee where myPayee.state like ?1"),
		@NamedQuery(name = "findPayeeByTitle", query = "select myPayee from Payee myPayee where myPayee.title = ?1"),
		@NamedQuery(name = "findPayeeByTitleContaining", query = "select myPayee from Payee myPayee where myPayee.title like ?1"),
		@NamedQuery(name = "findPayeeByCompanyIdClaimNoAndOccurrence", query = "select myPayee from Payee myPayee where myPayee.claimNo = ?1 and myPayee.occurrence = ?2"),
		@NamedQuery(name = "findPayeeByClaimNoOccurrenceAndPolicyNo", query = "select myPayee from Payee myPayee where myPayee.claimNo = ?1 and myPayee.occurrence = ?2 and myPayee.policyNo = ?3"),
		@NamedQuery(name = "findPayeeByClaimNoOccurrencePolicyNoAndPayeeType",
				query = "select myPayee from Payee myPayee where myPayee.claimNo = ?1 and myPayee.occurrence = ?2 and myPayee.policyNo = ?3 and myPayee.payeeType = ?4"),
		@NamedQuery(name = "deletePayeeByCompanyIdAndClaimNo", query = "delete from Payee myPayee where myPayee.claimNo=?1"),
		@NamedQuery(name = "findPayeeByClaimNoOccurrencePolicyNoAndInPayeeTypes",
				query = "select myPayee from Payee myPayee where myPayee.claimNo = ?1 and myPayee.occurrence = ?2 and myPayee.policyNo = ?3 and myPayee.payeeType in (?4)"), })
@Table(name = "PAYEE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Payee")
public class Payee extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String OWNER_PAYEE_TYPE = "O";

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "payeeSequence")
	@SequenceGenerator(name = "payeeSequence", sequenceName = "s_payee")
	@Column(name = "PAYEEID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long payeeId;
	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PAYEETYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeType;
	/**
	 */

	@Column(name = "TITLE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String title;
	/**
	 */

	@Column(name = "FIRSTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(FIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	/**
	 */

	@Column(name = "LASTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(LASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	/**
	 */

	@Column(name = "NATIONALID", length = 15, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(NATIONALID, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String nationalId;
	/**
	 */

	@Column(name = "BANKRUPTCYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankruptcyInd;
	
	@Column(name = "BANKRUPTCYDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Date bankruptcyDt;
	

	@Column(name = "BLACKLISTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistInd;
	/**
	 */

	@Column(name = "AMLOIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String amloInd;
	/**
	 */

	@Column(name = "OFACIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ofacInd;
	/**
	 */

	@Column(name = "FATCAIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fatcaInd;
	/**
	 */

	@Column(name = "SECIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String secInd;
	/**
	 */

	@Column(name = "ONCBIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String oncbind;
	/**
	 */

	@Column(name = "POLITICALIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String politicalInd;
	/**
	 */

	@Column(name = "SUSPENSEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspenseInd;
	/**
	 */

	@Column(name = "WATCHLISTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String watchlistInd;
	/**
	 */

	@Column(name = "ADDRESSLINE1", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE1, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;
	/**
	 */

	@Column(name = "ADDRESSLINE2", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE2, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;
	/**
	 */

	@Column(name = "ADDRESSLINE3", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE3, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;
	/**
	 */

	@Column(name = "ADDRESSLINE4", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE4, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;
	/**
	 */

	@Column(name = "CITY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String city;
	/**
	 */

	@Column(name = "STATE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String state;
	/**
	 */

	@Column(name = "POSTALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postalCode;
	/**
	 */

	@Column(name = "COUNTRY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String country;
	/**
	 */

	@Column(name = "EMAILADDRESS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String emailAddress;
	/**
	 */

	@Column(name = "MOBILE", length = 20, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MOBILE, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String mobile;
	/**
	 */

	@Column(name = "TELEPHONE", length = 20, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(TELEPHONE, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String telephone;
	/**
	 */

	@Column(name = "BANKACCOUNTNO", length = 30, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(BANKACCOUNTNO, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankAccountNo;
	/**
	 */

	@Column(name = "BANKCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankCode;
	/**
	 */

	@Column(name = "ACCTTYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String acctType;
	/**
	 */

	@Column(name = "PAYEETAXNO", length = 20, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(PAYEETAXNO, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTaxNo;
	/**
	 */

	@Column(name = "BILLINGTYPECD", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingTypeCd;

	@Column(name = "ENCRYPTIONDOB", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ENCRYPTIONDOB, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String encryptionDob;

	/**
	 */

	/**
	 * @return the payeeId
	 */
	public Long getPayeeId() {
		return payeeId;
	}

	/**
	 * @param payeeId the payeeId to set
	 */
	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the nationalId
	 */
	public String getNationalId() {
		return nationalId;
	}

	/**
	 * @param nationalId the nationalId to set
	 */
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	/**
	 * @return the bankruptcyInd
	 */
	public String getBankruptcyInd() {
		return bankruptcyInd;
	}

	/**
	 * @param bankruptcyInd the bankruptcyInd to set
	 */
	public void setBankruptcyInd(String bankruptcyInd) {
		this.bankruptcyInd = bankruptcyInd;
	}

	/**
	 * @return the blacklistInd
	 */
	public String getBlacklistInd() {
		return blacklistInd;
	}

	/**
	 * @param blacklistInd the blacklistInd to set
	 */
	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	/**
	 * @return the amloInd
	 */
	public String getAmloInd() {
		return amloInd;
	}

	/**
	 * @param amloInd the amloInd to set
	 */
	public void setAmloInd(String amloInd) {
		this.amloInd = amloInd;
	}

	/**
	 * @return the ofacInd
	 */
	public String getOfacInd() {
		return ofacInd;
	}

	/**
	 * @param ofacInd the ofacInd to set
	 */
	public void setOfacInd(String ofacInd) {
		this.ofacInd = ofacInd;
	}

	/**
	 * @return the fatcaInd
	 */
	public String getFatcaInd() {
		return fatcaInd;
	}

	/**
	 * @param fatcaInd the fatcaInd to set
	 */
	public void setFatcaInd(String fatcaInd) {
		this.fatcaInd = fatcaInd;
	}

	/**
	 * @return the secInd
	 */
	public String getSecInd() {
		return secInd;
	}

	/**
	 * @param secInd the secInd to set
	 */
	public void setSecInd(String secInd) {
		this.secInd = secInd;
	}

	public String getOncbind() {
		return oncbind;
	}

	public void setOncbind(String oncbind) {
		this.oncbind = oncbind;
	}

	/**
	 * @return the politicalInd
	 */
	public String getPoliticalInd() {
		return politicalInd;
	}

	/**
	 * @param politicalInd the politicalInd to set
	 */
	public void setPoliticalInd(String politicalInd) {
		this.politicalInd = politicalInd;
	}

	/**
	 * @return the suspenseInd
	 */
	public String getSuspenseInd() {
		return suspenseInd;
	}

	/**
	 * @param suspenseInd the suspenseInd to set
	 */
	public void setSuspenseInd(String suspenseInd) {
		this.suspenseInd = suspenseInd;
	}

	/**
	 * @return the watchlistInd
	 */
	public String getWatchlistInd() {
		return watchlistInd;
	}

	/**
	 * @param watchlistInd the watchlistInd to set
	 */
	public void setWatchlistInd(String watchlistInd) {
		this.watchlistInd = watchlistInd;
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 * @return the addressLine4
	 */
	public String getAddressLine4() {
		return addressLine4;
	}

	/**
	 * @param addressLine4 the addressLine4 to set
	 */
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @return the bankAccountNo
	 */
	public String getBankAccountNo() {
		return bankAccountNo;
	}

	/**
	 * @param bankAccountNo the bankAccountNo to set
	 */
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the acctType
	 */
	public String getAcctType() {
		return acctType;
	}

	/**
	 * @param acctType the acctType to set
	 */
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	/**
	 * @return the payeeTaxNo
	 */
	public String getPayeeTaxNo() {
		return payeeTaxNo;
	}

	/**
	 * @param payeeTaxNo the payeeTaxNo to set
	 */
	public void setPayeeTaxNo(String payeeTaxNo) {
		this.payeeTaxNo = payeeTaxNo;
	}

	/**
	 * @return the billingTypeCd
	 */
	public String getBillingTypeCd() {
		return billingTypeCd;
	}

	/**
	 * @param billingTypeCd the billingTypeCd to set
	 */
	public void setBillingTypeCd(String billingTypeCd) {
		this.billingTypeCd = billingTypeCd;
	}

	public String getEncryptionDob() {
		return encryptionDob;
	}

	public void setEncryptionDob(String encryptionDob) {
		this.encryptionDob = encryptionDob;
	}
	
	public Date getBankruptcyDt() {
		return bankruptcyDt;
	}

	public void setBankruptcyDt(Date bankruptcyDt) {
		this.bankruptcyDt = bankruptcyDt;
	}

	
	public Payee() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Payee that) {
		setPayeeId(that.getPayeeId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPayeeType(that.getPayeeType());
		setTitle(that.getTitle());
		setFirstName(that.getFirstName());
		setLastName(that.getLastName());
		setNationalId(that.getNationalId());
		setBankruptcyInd(that.getBankruptcyInd());
		setBankruptcyDt(that.getBankruptcyDt());
		setBlacklistInd(that.getBlacklistInd());
		setAmloInd(that.getAmloInd());
		setOfacInd(that.getOfacInd());
		setFatcaInd(that.getFatcaInd());
		setAddressLine1(that.getAddressLine1());
		setAddressLine2(that.getAddressLine2());
		setAddressLine3(that.getAddressLine3());
		setAddressLine4(that.getAddressLine4());
		setCity(that.getCity());
		setState(that.getState());
		setPostalCode(that.getPostalCode());
		setCountry(that.getCountry());
		setEmailAddress(that.getEmailAddress());
		setBankAccountNo(that.getBankAccountNo());
		setBankCode(that.getBankCode());
		setMobile(that.getMobile());
		setTelephone(that.getTelephone());
		setAcctType(that.getAcctType());
		setPayeeTaxNo(that.getPayeeTaxNo());
		setBillingTypeCd(that.getBillingTypeCd());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setEncryptionDob(that.getEncryptionDob());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("payeeId=[").append(payeeId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("payeeType=[").append(payeeType).append("] ");
		buffer.append("title=[").append(title).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("nationalId=[").append(nationalId).append("] ");
		buffer.append("bankruptcyInd=[").append(bankruptcyInd).append("] ");
		buffer.append("bankruptcyDt=[").append(bankruptcyDt).append("] ");
		buffer.append("blacklistInd=[").append(blacklistInd).append("] ");
		buffer.append("amloInd=[").append(amloInd).append("] ");
		buffer.append("ofacInd=[").append(ofacInd).append("] ");
		buffer.append("fatcaInd=[").append(fatcaInd).append("] ");
		buffer.append("secInd=[").append(secInd).append("] ");
		buffer.append("politicalInd=[").append(politicalInd).append("] ");
		buffer.append("suspenseInd=[").append(suspenseInd).append("] ");
		buffer.append("watchlistInd=[").append(watchlistInd).append("] ");
		buffer.append("addressLine1=[").append(addressLine1).append("] ");
		buffer.append("addressLine2=[").append(addressLine2).append("] ");
		buffer.append("addressLine3=[").append(addressLine3).append("] ");
		buffer.append("addressLine4=[").append(addressLine4).append("] ");
		buffer.append("city=[").append(city).append("] ");
		buffer.append("state=[").append(state).append("] ");
		buffer.append("postalCode=[").append(postalCode).append("] ");
		buffer.append("country=[").append(country).append("] ");
		buffer.append("emailAddress=[").append(emailAddress).append("] ");
		buffer.append("bankAccountNo=[").append(bankAccountNo).append("] ");
		buffer.append("bankCode=[").append(bankCode).append("] ");
		buffer.append("acctType=[").append(acctType).append("] ");
		buffer.append("payeeTaxNo=[").append(payeeTaxNo).append("] ");
		buffer.append("billingTypeCd=[").append(billingTypeCd).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");
		buffer.append("encryptionDob=[").append(getEncryptionDob()).append("] ");
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((payeeId == null) ? 0 : payeeId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Payee))
			return false;
		Payee equalCheck = (Payee) obj;
		if ((payeeId == null && equalCheck.payeeId != null) || (payeeId != null && equalCheck.payeeId == null))
			return false;
		if (payeeId != null && !payeeId.equals(equalCheck.payeeId))
			return false;
		return true;
	}
}
