package com.aia.cmic.entity;

import java.util.Date;

public class ErrorCode {
	private String errorCode;
	private String errorDesc;
	private String errorDescThai;
	private String createdBy;
	private Date createdDt;
	private String lastModifiedBy;
	private Date lastModifiedDt;
}
