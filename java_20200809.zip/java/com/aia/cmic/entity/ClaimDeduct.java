package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;
@Entity
//@formatter:off
@NamedQueries({
		@NamedQuery(name = "findClaimDeductByClaimNoOccurrence", query = "select myClaimDeduct from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?1 and myClaimDeduct.occurrence = ?2"),
		@NamedQuery(name = "findClaimDeductByRefClaimNoRefOccurrence", query = "select myClaimDeduct from ClaimDeduct myClaimDeduct where myClaimDeduct.refClaimNo = ?1 and myClaimDeduct.refOccurrence = ?2"),
		@NamedQuery(name = "findClaimDeductByPolicyNo", query = "select myClaimDeduct from ClaimDeduct myClaimDeduct where myClaimDeduct.policyNo = ?1 "),
		@NamedQuery(name = "findClaimDeductByDeductId", query = "select myClaimDeduct from ClaimDeduct myClaimDeduct where myClaimDeduct.claimDeductId = ?1 "),
		@NamedQuery(name = "findClaimDeductByDeductNo", query = "select myClaimDeduct from ClaimDeduct myClaimDeduct where myClaimDeduct.claimDeductNo = ?1 "),
		@NamedQuery(name = "findClaimDeductByCaseId", query = "select myClaimDeduct from ClaimDeduct myClaimDeduct where myClaimDeduct.caseId = ?1 "),
		@NamedQuery(name = "removeClaimDeductByClaimNoPolicyCD", query = "delete from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?1 and myClaimDeduct.occurrence = ?2 and myClaimDeduct.submissionSource = 'CD' and myClaimDeduct.deductStatus = '40' "),
		@NamedQuery(name = "updateClaimDeductStatusByClaimNoPolicy", query = "update ClaimDeduct myClaimDeduct set myClaimDeduct.deductStatus=?1 where myClaimDeduct.claimNo = ?2 and myClaimDeduct.occurrence = ?3 and myClaimDeduct.policyNo=?4 and myClaimDeduct.submissionSource = 'CD' and myClaimDeduct.deductStatus = '40' "), //
		@NamedQuery(name = "updateClaimDeductStatusByClaimNoOccurrenceOnSettle", query = "update ClaimDeduct myClaimDeduct set myClaimDeduct.deductStatus = ?1 where myClaimDeduct.claimNo = ?2 and myClaimDeduct.occurrence = ?3 and myClaimDeduct.submissionSource in ('OT','CS') and myClaimDeduct.deductStatus in ('10','40') ")

})
//@formatter:on
@Table(name = "CLAIMDEDUCT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimDeduct")
public class ClaimDeduct extends BaseEntity implements Serializable {

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimdeductSequence")
	@SequenceGenerator(name = "claimdeductSequence", sequenceName = "s_claimdeduct")
	@Column(name = "CLAIMDEDUCTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimDeductId;
	
	@Column(name = "CLAIMDEDUCTNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimDeductNo;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	
	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	
	@Column(name = "REFCLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String refClaimNo;
	
	@Column(name = "REFOCCURRENCE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer refOccurrence;
	
	@Column(name = "RECEIVEDDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date receivedDate;
	
	@Column(name = "SUBMISSIONSOURCE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionSource;
	
	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	
	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	
	@Column(name = "LASTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(LASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	
	@Column(name = "FIRSTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(FIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	
	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	
	@Column(name = "TREATMENTTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String treatmentType;
	
	@Column(name = "ACCIDENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date accidentDt;
	
	@Column(name = "HOSPITALIZATIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date hospitalizationDate;
	
	@Column(name = "DISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dischargeDate;
	
	@Column(name = "ICUADMISSIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuAdmissionDate;
	
	@Column(name = "ICUDISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuDischargeDate;
	
	@Column(name = "LENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer lengthOfStay;
	
	@Column(name = "ICULENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer icuLengthOfStay;
	
	@Column(name = "DEDUCTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deductStatus;
	
	@Column(name = "POLICYYEARFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearFromDt;
	
	@Column(name = "POLICYYEARTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearToDt;
	
	@Column(name = "CASEID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long caseId;
	
	@Column(name = "PARTYID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long partyId;

	
	@Column(name = "CAUSEOFTREATMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfTreatment;
	
	@Column(name = "TOTALDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalDeductAmt;

	@Column(name = "LASTMODIFIEDUSERDEPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDept;

	@Column(name = "LASTMODIFIEDUSERDESK", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDesk;
	
	@Column(name = "SERVICINGAGENTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgentCode;

	@Column(name = "SERVICINGAGENCYCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyCode;

	@Column(name = "SERVICINGGAOFFICECODE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaOfficeCode;
	
	@Column(name = "PAYEETITLE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTitle;
	
	@Column(name = "PAYEEFIRSTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(PAYEEFIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeFirstName;
	

	@Column(name = "PAYEELASTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(PAYEELASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeLastName;
	
	@Column(name = "ADDRESSLINE1", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE1, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;
	
	@Column(name = "ADDRESSLINE2", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE2, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;
	
	@Column(name = "ADDRESSLINE3", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE3, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;

	@Column(name = "ADDRESSLINE4", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE4, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;
	
	@Column(name = "ZIPCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String zipCode;

	public Long getClaimDeductId() {
		return claimDeductId;
	}

	public String getClaimDeductNo() {
		return claimDeductNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public String getSubmissionSource() {
		return submissionSource;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public Date getIcuAdmissionDate() {
		return icuAdmissionDate;
	}

	public Date getIcuDischargeDate() {
		return icuDischargeDate;
	}

	public Integer getLengthOfStay() {
		return lengthOfStay;
	}

	public Integer getIcuLengthOfStay() {
		return icuLengthOfStay;
	}

	public String getDeductStatus() {
		return deductStatus;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public Long getCaseId() {
		return caseId;
	}

	public Long getPartyId() {
		return partyId;
	}

	public String getCauseOfTreatment() {
		return causeOfTreatment;
	}

	public BigDecimal getTotalDeductAmt() {
		return totalDeductAmt;
	}

	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	public String getServicingAgentCode() {
		return servicingAgentCode;
	}

	public String getServicingAgencyCode() {
		return servicingAgencyCode;
	}

	public String getServicingGaOfficeCode() {
		return servicingGaOfficeCode;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public String getPayeeFirstName() {
		return payeeFirstName;
	}

	public String getPayeeLastName() {
		return payeeLastName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setClaimDeductId(Long claimDeductId) {
		this.claimDeductId = claimDeductId;
	}

	public void setClaimDeductNo(String claimDeductNo) {
		this.claimDeductNo = claimDeductNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public void setSubmissionSource(String submissionSource) {
		this.submissionSource = submissionSource;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}

	public void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}

	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}

	public void setDeductStatus(String deductStatus) {
		this.deductStatus = deductStatus;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	public void setTotalDeductAmt(BigDecimal totalDeductAmt) {
		this.totalDeductAmt = totalDeductAmt;
	}

	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	public void setServicingAgentCode(String servicingAgentCode) {
		this.servicingAgentCode = servicingAgentCode;
	}

	public void setServicingAgencyCode(String servicingAgencyCode) {
		this.servicingAgencyCode = servicingAgencyCode;
	}

	public void setServicingGaOfficeCode(String servicingGaOfficeCode) {
		this.servicingGaOfficeCode = servicingGaOfficeCode;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getRefClaimNo() {
		return refClaimNo;
	}

	public Integer getRefOccurrence() {
		return refOccurrence;
	}

	public void setRefClaimNo(String refClaimNo) {
		this.refClaimNo = refClaimNo;
	}

	public void setRefOccurrence(Integer refOccurrence) {
		this.refOccurrence = refOccurrence;
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimDeduct that) {
		setClaimDeductId(that.getClaimDeductId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setReceivedDate(that.getReceivedDate());
		setPolicyNo(that.getPolicyNo());
		setSubmissionSource(that.getSubmissionSource());
		setBusinessLine(that.getBusinessLine());
		setDeductStatus(that.getDeductStatus());
		setLastName(that.getLastName());
		setFirstName(that.getFirstName());
		setProviderCode(that.getProviderCode());
		setAccidentDt(that.getAccidentDt());
		setTreatmentType(that.getTreatmentType());
		setHospitalizationDate(that.getHospitalizationDate());
		setDischargeDate(that.getDischargeDate());
		setLengthOfStay(that.getLengthOfStay());
		setIcuAdmissionDate(that.getIcuAdmissionDate());
		setIcuDischargeDate(that.getIcuDischargeDate());
		setIcuLengthOfStay(that.getIcuLengthOfStay());
		
		setDeductStatus(that.getDeductStatus());
		setPolicyYearFromDt(that.getPolicyYearFromDt());
		setPolicyYearToDt(that.getPolicyYearToDt());
		setCaseId(that.getCaseId());
		setLastModifiedUserDept(that.getLastModifiedUserDept());
		setLastModifiedUserDesk(that.getLastModifiedUserDesk());
		setServicingAgencyCode(that.getServicingAgencyCode());
		setServicingAgentCode(that.getServicingAgentCode());
		setServicingGaOfficeCode(that.getServicingGaOfficeCode());
		setPayeeTitle(that.getPayeeTitle());
		setPayeeLastName(that.getPayeeLastName());
		setPayeeFirstName(that.getPayeeFirstName());
		setAddressLine1(that.getAddressLine1());
		setAddressLine2(that.getAddressLine2());
		setAddressLine3(that.getAddressLine3());
		setAddressLine4(that.getAddressLine4());
		setZipCode(that.getZipCode());
		setRefClaimNo(that.getRefClaimNo());
		setRefOccurrence(that.getRefOccurrence());
		
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		
		
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimDeductId=[").append(claimDeductId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("submissionSource=[").append(submissionSource).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("deductStatus=[").append(deductStatus).append("] ");
		buffer.append("receivedDate=[").append(receivedDate).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("accidentDt=[").append(accidentDt).append("] ");
		buffer.append("treatmentType=[").append(treatmentType).append("] ");
		buffer.append("hospitalizationDate=[").append(hospitalizationDate).append("] ");
		buffer.append("dischargeDate=[").append(dischargeDate).append("] ");
		buffer.append("lengthOfStay=[").append(lengthOfStay).append("] ");
		buffer.append("icuAdmissionDate=[").append(icuAdmissionDate).append("] ");
		buffer.append("icuDischargeDate=[").append(icuDischargeDate).append("] ");
		buffer.append("icuLengthOfStay=[").append(icuLengthOfStay).append("] ");
		buffer.append("refClaimNo=[").append(refClaimNo).append("] ");
		buffer.append("refOccurrece=[").append(refOccurrence).append("] ");
		return buffer.toString();
	}
	
}
