package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllProducts", query = "select myProduct from Product myProduct"),
		@NamedQuery(name = "findProductByPrimaryKey", query = "select myProduct from Product myProduct where myProduct.productCode = ?1"),
		@NamedQuery(name = "findProductByProductCode", query = "select myProduct from Product myProduct where myProduct.productCode = ?1"),
		@NamedQuery(name = "findProductByProductCodeContaining", query = "select myProduct from Product myProduct where myProduct.productCode like ?1"),
		@NamedQuery(name = "findProductByProductName", query = "select myProduct from Product myProduct where myProduct.productName = ?1"),
		@NamedQuery(name = "findProductByProductNameContaining", query = "select myProduct from Product myProduct where myProduct.productName like ?1"),
		@NamedQuery(name = "findProductByProductShortName", query = "select myProduct from Product myProduct where myProduct.productShortName = ?1"),
		@NamedQuery(name = "findProductByProductShortNameContaining", query = "select myProduct from Product myProduct where myProduct.productShortName like ?1"),
		@NamedQuery(name = "findProductByProductType", query = "select myProduct from Product myProduct where myProduct.productType = ?1"),
		@NamedQuery(name = "findProductByProductTypeContaining", query = "select myProduct from Product myProduct where myProduct.productType like ?1"),
		@NamedQuery(name = "findProductByStatus", query = "select myProduct from Product myProduct where myProduct.status = ?1"),
		@NamedQuery(name = "findProductByStatusContaining", query = "select myProduct from Product myProduct where myProduct.status like ?1"),
		@NamedQuery(name = "findProductByFieldContaining", query = "select myProduct from Product myProduct where myProduct.productCode like ?1 or myProduct.productShortName like ?2") })
@Table(name = "PRODUCT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Product")
public class Product extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "PRODUCTSHORTNAME", length = 50, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productShortName;
	/**
	 */

	@Column(name = "PRODUCTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productName;
	/**
	 */

	@Column(name = "PRODUCTTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productType;
	/**
	 */

	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "EFFECTIVEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveDt;
	/**
	 */

	@Column(name = "STATUS", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;

	/**
	 */

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the productShortName
	 */
	public String getProductShortName() {
		return productShortName;
	}

	/**
	 * @param productShortName the productShortName to set
	 */
	public void setProductShortName(String productShortName) {
		this.productShortName = productShortName;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the effectiveDt
	 */
	public Date getEffectiveDt() {
		return effectiveDt;
	}

	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 */
	public Product() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Product that) {
		setProductCode(that.getProductCode());
		setProductShortName(that.getProductShortName());
		setProductName(that.getProductName());
		setProductType(that.getProductType());
		setCompanyId(that.getCompanyId());
		setEffectiveDt(that.getEffectiveDt());
		setStatus(that.getStatus());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("productShortName=[").append(productShortName).append("] ");
		buffer.append("productName=[").append(productName).append("] ");
		buffer.append("productType=[").append(productType).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("effectiveDt=[").append(effectiveDt).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((productCode == null) ? 0 : productCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Product))
			return false;
		Product equalCheck = (Product) obj;
		if ((productCode == null && equalCheck.productCode != null) || (productCode != null && equalCheck.productCode == null))
			return false;
		if (productCode != null && !productCode.equals(equalCheck.productCode))
			return false;
		return true;
	}
}
