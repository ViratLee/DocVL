package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllProviderDetails", query = "select myProviderDetail from ProviderDetail myProviderDetail"),
		@NamedQuery(name = "findProviderDetailByCodeName", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.codeName = ?1"),
		@NamedQuery(name = "findProviderDetailByCodeNameContaining", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.codeName like ?1"),
		//		@NamedQuery(name = "findProviderDetailByCodeType", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.codeType = ?1"),
		//		@NamedQuery(name = "findProviderDetailByCodeTypeContaining", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.codeType like ?1"),
		//		@NamedQuery(name = "findProviderDetailByDoctorCode", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.doctorCode = ?1"),
		//		@NamedQuery(name = "findProviderDetailByIntValue", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.intValue = ?1"),
		//		@NamedQuery(name = "findProviderDetailByPrimaryKey", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.providerDetailId = ?1"),
		//		@NamedQuery(name = "findProviderDetailByProviderDetailId", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.providerDetailId = ?1"),
		@NamedQuery(name = "findProviderDetailByProviderCode", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.providerCode = ?1")
//		@NamedQuery(name = "findProviderDetailByStrValue", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.strValue = ?1"),
//		@NamedQuery(name = "findProviderDetailByStrValueContaining", query = "select myProviderDetail from ProviderDetail myProviderDetail where myProviderDetail.strValue like ?1")
})
@Table(name = "PROVIDERDETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderDetail")
public class ProviderDetail extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "providerDetailSequence")
	@SequenceGenerator(name = "providerDetailSequence", sequenceName = "s_providerdetail")
	@Column(name = "PROVIDERDETAILID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long providerDetailId;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "DOCTORCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doctorCode;
	/**
	 */

	@Column(name = "CODETYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeType;
	/**
	 */

	@Column(name = "CODENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeName;
	/**
	 */

	@Column(name = "STRVALUE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String strValue;
	/**
	 */

	@Column(name = "INTVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal intValue;

	/**
	 */

	/**
	 * @return the providerDetailId
	 */
	public Long getProviderDetailId() {
		return providerDetailId;
	}

	/**
	 * @param providerDetailId the providerDetailId to set
	 */
	public void setProviderDetailId(Long providerDetailId) {
		this.providerDetailId = providerDetailId;
	}

	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}

	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 * @return the doctorCode
	 */
	public String getDoctorCode() {
		return doctorCode;
	}

	/**
	 * @param doctorCode the doctorCode to set
	 */
	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	/**
	 * @return the codeType
	 */
	public String getCodeType() {
		return codeType;
	}

	/**
	 * @param codeType the codeType to set
	 */
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	/**
	 * @return the codeName
	 */
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @param codeName the codeName to set
	 */
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}

	/**
	 * @return the strValue
	 */
	public String getStrValue() {
		return strValue;
	}

	/**
	 * @param strValue the strValue to set
	 */
	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	/**
	 * @return the intValue
	 */
	public BigDecimal getIntValue() {
		return intValue;
	}

	/**
	 * @param intValue the intValue to set
	 */
	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}

	/**
	 */
	public ProviderDetail() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProviderDetail that) {
		setProviderDetailId(that.getProviderDetailId());
		setProviderCode(that.getProviderCode());
		setDoctorCode(that.getDoctorCode());
		setCodeType(that.getCodeType());
		setCodeName(that.getCodeName());
		setStrValue(that.getStrValue());
		setIntValue(that.getIntValue());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("providerDetailId=[").append(providerDetailId).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("doctorCode=[").append(doctorCode).append("] ");
		buffer.append("codeType=[").append(codeType).append("] ");
		buffer.append("codeName=[").append(codeName).append("] ");
		buffer.append("strValue=[").append(strValue).append("] ");
		buffer.append("intValue=[").append(intValue).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((providerDetailId == null) ? 0 : providerDetailId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProviderDetail))
			return false;
		ProviderDetail equalCheck = (ProviderDetail) obj;
		if ((providerDetailId == null && equalCheck.providerDetailId != null) || (providerDetailId != null && equalCheck.providerDetailId == null))
			return false;
		if (providerDetailId != null && !providerDetailId.equals(equalCheck.providerDetailId))
			return false;
		return true;
	}
}
