package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllPlanBenefitLimits", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit"),
		@NamedQuery(name = "findPlanBenefitLimitByCategory", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.category = ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByCategoryContaining", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.category like ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByCategoryValue", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.categoryValue = ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByCategoryValueContaining", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.categoryValue like ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByEffFromDt", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.effFromDt = ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByEffToDt", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.effToDt = ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByPlanId", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.planId = ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByPlanBenefitLimitId", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.planBenefitLimitId = ?1"),
		@NamedQuery(name = "findPlanBenefitLimitByPrimaryKey", query = "select myPlanBenefitLimit from PlanBenefitLimit myPlanBenefitLimit where myPlanBenefitLimit.planBenefitLimitId = ?1"), })
@Table(name = "PLANBENEFITLIMIT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "PlanBenefitLimit")
public class PlanBenefitLimit extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "planBenefitLimitSequence")
	@SequenceGenerator(name = "planBenefitLimitSequence", sequenceName = "s_planbenefitlimit")
	@Column(name = "PLANBENEFITLIMITID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long planBenefitLimitId;
	/**
	 */

	@Column(name = "PLANID", length = 18, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "CATEGORY", length = 50, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String category;
	/**
	 */

	@Column(name = "CATEGORYVALUE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String categoryValue;
	/**
	 */
	@Column(name = "EFFFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effFromDt;
	/**
	 */
	@Column(name = "EFFTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effToDt;

	/**
	 */
	public void setPlanBenefitLimitId(Long planBenefitLimitId) {
		this.planBenefitLimitId = planBenefitLimitId;
	}

	/**
	 */
	public Long getPlanBenefitLimitId() {
		return this.planBenefitLimitId;
	}

	/**
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 */
	public String getCategory() {
		return this.category;
	}

	/**
	 */
	public void setCategoryValue(String categoryValue) {
		this.categoryValue = categoryValue;
	}

	/**
	 */
	public String getCategoryValue() {
		return this.categoryValue;
	}

	/**
	 */
	public void setEffFromDt(Date effFromDt) {
		this.effFromDt = effFromDt;
	}

	/**
	 */
	public Date getEffFromDt() {
		return this.effFromDt;
	}

	/**
	 */
	public void setEffToDt(Date effToDt) {
		this.effToDt = effToDt;
	}

	/**
	 */
	public Date getEffToDt() {
		return this.effToDt;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public PlanBenefitLimit() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(PlanBenefitLimit that) {
		setPlanBenefitLimitId(that.getPlanBenefitLimitId());
		setPlanId(that.getPlanId());
		setCategory(that.getCategory());
		setCategoryValue(that.getCategoryValue());
		setEffFromDt(that.getEffFromDt());
		setEffToDt(that.getEffToDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("planBenefitLimitId=[").append(planBenefitLimitId).append("] ");
		buffer.append("planId=[").append(getPlanId()).append("] ");
		buffer.append("category=[").append(category).append("] ");
		buffer.append("categoryValue=[").append(categoryValue).append("] ");
		buffer.append("effFromDt=[").append(effFromDt).append("] ");
		buffer.append("effToDt=[").append(effToDt).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((planBenefitLimitId == null) ? 0 : planBenefitLimitId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof PlanBenefitLimit))
			return false;
		PlanBenefitLimit equalCheck = (PlanBenefitLimit) obj;
		if ((planBenefitLimitId == null && equalCheck.planBenefitLimitId != null) || (planBenefitLimitId != null && equalCheck.planBenefitLimitId == null))
			return false;
		if (planBenefitLimitId != null && !planBenefitLimitId.equals(equalCheck.planBenefitLimitId))
			return false;
		return true;
	}
}
