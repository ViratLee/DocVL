package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCorrespondences", query = "select myCorrespondence from Correspondence myCorrespondence"),
		@NamedQuery(name = "findCorrespondenceByClaimNo", query = "select myCorrespondence from Correspondence myCorrespondence where myCorrespondence.claimNo = ?1"),
		@NamedQuery(name = "findCorrespondenceByCorrespondenceCode", query = "select myCorrespondence from Correspondence myCorrespondence where myCorrespondence.correspondenceCode = ?1"),
		@NamedQuery(name = "findCorrespondenceByCorrespondenceCodeContaining", query = "select myCorrespondence from Correspondence myCorrespondence where myCorrespondence.correspondenceCode like ?1"),
		@NamedQuery(name = "findCorrespondenceByCorrespondenceId", query = "select myCorrespondence from Correspondence myCorrespondence where myCorrespondence.correspondenceId = ?1"),
		@NamedQuery(name = "findCorrespondenceByPrimaryKey", query = "select myCorrespondence from Correspondence myCorrespondence where myCorrespondence.correspondenceId = ?1") })
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Correspondence")
public class Correspondence extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "correspondenceSequence")
	@SequenceGenerator(name = "correspondenceSequence", sequenceName = "s_correspondence")
	@Column(name = "CORRESPONDENCEID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long correspondenceId;
	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "CORRESPONDENCECODE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String correspondenceCode;

	/**
	 */
	public void setCorrespondenceId(Long correspondenceId) {
		this.correspondenceId = correspondenceId;
	}

	/**
	 */
	public Long getCorrespondenceId() {
		return this.correspondenceId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public void setCorrespondenceCode(String correspondenceCode) {
		this.correspondenceCode = correspondenceCode;
	}

	/**
	 */
	public String getCorrespondenceCode() {
		return this.correspondenceCode;
	}

	/**
	 */
	public Correspondence() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Correspondence that) {
		setCorrespondenceId(that.getCorrespondenceId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setCorrespondenceCode(that.getCorrespondenceCode());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("correspondenceId=[").append(correspondenceId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("correspondenceCode=[").append(correspondenceCode).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((correspondenceId == null) ? 0 : correspondenceId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Correspondence))
			return false;
		Correspondence equalCheck = (Correspondence) obj;
		if ((correspondenceId == null && equalCheck.correspondenceId != null) || (correspondenceId != null && equalCheck.correspondenceId == null))
			return false;
		if (correspondenceId != null && !correspondenceId.equals(equalCheck.correspondenceId))
			return false;
		return true;
	}
}
