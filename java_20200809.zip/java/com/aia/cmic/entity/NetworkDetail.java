package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@Table(name = "NETWORKDETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "NetworkDetail")
public class NetworkDetail extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "networkDetailSequence")
	@SequenceGenerator(name = "networkDetailSequence", sequenceName = "s_networkDetail")
	@Column(name = "NETWORKDETAILID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long networkDetailId;

	/**
	 */
	@Column(name = "NETWORKID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	//@ManyToOne
	Long networkId;

	@Column(name = "CODETYPE", length = 50, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeType;

	@Column(name = "STRVALUE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String strValue;

	public Long getNetworkDetailId() {
		return networkDetailId;
	}

	public void setNetworkDetailId(Long networkDetailId) {
		this.networkDetailId = networkDetailId;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getStrValue() {
		return strValue;
	}

	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	public NetworkDetail() {
	}

	public void copy(NetworkDetail that) {
		setNetworkDetailId(that.getNetworkDetailId());
		setNetworkId(that.getNetworkId());
		setCodeType(that.getCodeType());
		setStrValue(that.getStrValue());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();
		buffer.append("networkDetailId=[").append(networkDetailId).append("] ");
		buffer.append("networkId=[").append(networkId).append("] ");
		buffer.append("codeType=[").append(codeType).append("] ");
		buffer.append("strValue=[").append(strValue).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((networkDetailId == null) ? 0 : networkDetailId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof NetworkDetail))
			return false;
		NetworkDetail equalCheck = (NetworkDetail) obj;
		if ((networkDetailId == null && equalCheck.networkDetailId != null) || (networkDetailId != null && equalCheck.networkDetailId == null))
			return false;
		if (networkDetailId != null && !networkDetailId.equals(equalCheck.networkDetailId))
			return false;
		return true;
	}
}
