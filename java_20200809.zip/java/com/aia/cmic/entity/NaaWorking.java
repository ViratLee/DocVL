package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@NamedQueries({ @NamedQuery(name = "findAllNaaWorking", query = "select myNaaWorking from NaaWorking myNaaWorking"),
		@NamedQuery(name = "findNaaWorkingById", query = "select myNaaWorking from NaaWorking myNaaWorking where myNaaWorking.naaWorkingId=?1"),
		@NamedQuery(name = "checkAggregationNaaWorkings", query = "select myNaaWorking from NaaWorking myNaaWorking where myNaaWorking.companyId=?1 and myNaaWorking.claimNo=?2 and myNaaWorking.occurrence =?3 and myNaaWorking.policyNo=?4 and (myNaaWorking.cycleDate between ?5 and ?6) and myNaaWorking.transactionAmt >= 0"),
		@NamedQuery(name = "findNAAWorkingByFSURelated", query = "select myNaaWorking from NaaWorking myNaaWorking where myNaaWorking.claimNo=?2 and myNaaWorking.occurrence =?3 and myNaaWorking.fsuRelated like ?3"),
		@NamedQuery(name = "clearNAAWorking", query = "delete from NaaWorking myNaaWorking where myNaaWorking.naaWorkingId= ?1"),})
@Table(name = "NAAWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "NaaWorking")
public class NaaWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "naaWorkingSequence")
	@SequenceGenerator(name = "naaWorkingSequence", sequenceName = "s_naaworking")
	@Column(name = "NAAWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long naaWorkingId;

	@Column(name = "CYCLEDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date cycleDate;

	/**
	 */
	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;

	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	/**
	 */
	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	/**
	 */
	@Column(name = "TRANSACTIONDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date transactionDt;

	/**
	 */
	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;

	/**
	 */
	@Column(name = "AGENCYCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyCodeServicing;

	/**
	 */
	@Column(name = "AGENTCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentCodeServicing;

	/**
	 */
	@Column(name = "COVERAGEID", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String coverageId;

	/**
	 */
	@Column(name = "TRANSACTIONAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal transactionAmt;

	/**
	 */
	@Column(name = "CHANNELCODE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String channelCode;

	/**
	 */
	@Column(name = "INSUREDLASTNAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredLastName;

	/**
	 */
	@Column(name = "INSUREDFIRSTNAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredFirstName;

	/**
	 */
	@Column(name = "CSFORMATPOLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csFormatPolicyNo;

	
    @Column(name = "SUSPENDCODE", length = 15)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String suspendCode;


    @Column(name = "FSURELATED", length = 2000)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String fsuRelated;
    
	public Long getNaaWorkingId() {
		return naaWorkingId;
	}

	public void setNaaWorkingId(Long naaWorkingId) {
		this.naaWorkingId = naaWorkingId;
	}

	public Date getCycleDate() {
		return cycleDate;
	}

	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public Date getTransactionDt() {
		return transactionDt;
	}

	public void setTransactionDt(Date transactionDt) {
		this.transactionDt = transactionDt;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	public String getCoverageId() {
		return coverageId;
	}

	public void setCoverageId(String coverageId) {
		this.coverageId = coverageId;
	}

	public BigDecimal getTransactionAmt() {
		return transactionAmt;
	}

	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getInsuredLastName() {
		return insuredLastName;
	}

	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String getInsuredFirstName() {
		return insuredFirstName;
	}

	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	/**
	 * @return the csFormatPolicyNo
	 */
	public String getCsFormatPolicyNo() {
		return csFormatPolicyNo;
	}

	/**
	 * @param csFormatPolicyNo the csFormatPolicyNo to set
	 */
	public void setCsFormatPolicyNo(String csFormatPolicyNo) {
		this.csFormatPolicyNo = csFormatPolicyNo;
	}

	public String getSuspendCode() {
		return suspendCode;
	}

	public void setSuspendCode(String suspendCode) {
		this.suspendCode = suspendCode;
	}

	public String getFsuRelated() {
		return fsuRelated;
	}

	public void setFsuRelated(String fsuRelated) {
		this.fsuRelated = fsuRelated;
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(NaaWorking that) {
		setCycleDate(that.getCycleDate());
		setNaaWorkingId(that.getNaaWorkingId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setTransactionDt(that.getTransactionDt());
		setPolicyNo(that.getPolicyNo());
		setAgencyCodeServicing(that.getAgencyCodeServicing());
		setAgentCodeServicing(that.getAgentCodeServicing());
		setCoverageId(that.getCoverageId());
		setTransactionAmt(that.getTransactionAmt());
		setChannelCode(that.getChannelCode());
		setInsuredLastName(that.getInsuredLastName());
		setInsuredFirstName(that.getInsuredFirstName());
		setCsFormatPolicyNo(that.getCsFormatPolicyNo());
		setSuspendCode(that.getSuspendCode());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("naaWorkingId=[").append(naaWorkingId).append("] ");
		buffer.append("cycleDate=[").append(cycleDate).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("transactionDt=[").append(transactionDt).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("agencyCodeServicing=[").append(agencyCodeServicing).append("] ");
		buffer.append("agentCodeServicing=[").append(agentCodeServicing).append("] ");
		buffer.append("coverageId=[").append(coverageId).append("] ");
		buffer.append("transactionAmt=[").append(transactionAmt).append("] ");
		buffer.append("channelCode=[").append(channelCode).append("] ");
		buffer.append("insuredLastName=[").append(insuredLastName).append("] ");
		buffer.append("insuredFirstName=[").append(insuredFirstName).append("] ");
		buffer.append("csFormatPolicyNo=[").append(csFormatPolicyNo).append("] ");

		return buffer.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((naaWorkingId == null) ? 0 : naaWorkingId.hashCode()));
		return result;
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof NaaWorking))
			return false;
		NaaWorking equalCheck = (NaaWorking) obj;
		if ((naaWorkingId == null && equalCheck.naaWorkingId != null) || (naaWorkingId != null && equalCheck.naaWorkingId == null))
			return false;
		if (naaWorkingId != null && !naaWorkingId.equals(equalCheck.naaWorkingId))
			return false;
		return true;
	}
}
