package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "EDIORDERITEM")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "EdiOrderItem")
public class EdiOrderItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ediOrderItemSequence")
	@SequenceGenerator(name = "ediOrderItemSequence", sequenceName = "s_ediorderitem")
	@Column(name = "EDIORDERITEMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long ediOrderItemId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "ITEMID", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String itemId;

	@Column(name = "ITEMNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String itemName;

	@Column(name = "ITEMLOCALBILLINGCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String itemLocalBillingCode;

	@Column(name = "ITEMSIMBBILLINGCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String itemSimbBillingCode;

	@Column(name = "ITEMAMOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal itemAmount;

	@Column(name = "ITEMINITIAL", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal itemInitial;

	@Column(name = "DISCOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal discount;

	@Column(name = "NETAMOUNT", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String netAmount;

	public Long getEdiOrderItemId() {
		return ediOrderItemId;
	}

	public void setEdiOrderItemId(Long ediOrderItemId) {
		this.ediOrderItemId = ediOrderItemId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = setMaxLength("itemId", itemId);
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = setMaxLength("itemName", itemName);
	}

	public String getItemLocalBillingCode() {
		return itemLocalBillingCode;
	}

	public void setItemLocalBillingCode(String itemLocalBillingCode) {
		this.itemLocalBillingCode = setMaxLength("itemLocalBillingCode", itemLocalBillingCode);
	}

	public String getItemSimbBillingCode() {
		return itemSimbBillingCode;
	}

	public void setItemSimbBillingCode(String itemSimbBillingCode) {
		this.itemSimbBillingCode = setMaxLength("itemSimbBillingCode", itemSimbBillingCode);
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public BigDecimal getItemInitial() {
		return itemInitial;
	}

	public void setItemInitial(BigDecimal itemInitial) {
		this.itemInitial = itemInitial;
	}

	public BigDecimal getDiscount() {
		return discount;
	}

	public void setDiscount(BigDecimal discount) {
		this.discount = discount;
	}

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public EdiOrderItem() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(EdiOrderItem that) {

		setEdiOrderItemId(that.getEdiOrderItemId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setItemId(that.getItemId());
		setItemName(that.getItemName());
		setItemLocalBillingCode(that.getItemLocalBillingCode());
		setItemSimbBillingCode(that.getItemSimbBillingCode());
		setItemAmount(that.getItemAmount());
		setItemInitial(that.getItemInitial());
		setDiscount(that.getDiscount());
		setNetAmount(that.getNetAmount());

	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("ediOrderItemId=[").append(ediOrderItemId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("itemId=[").append(itemId).append("] ");
		buffer.append("itemName=[").append(itemName).append("] ");
		buffer.append("itemLocalBillingCode=[").append(itemLocalBillingCode).append("] ");
		buffer.append("itemSimbBillingCode=[").append(itemSimbBillingCode).append("] ");
		buffer.append("itemAmount=[").append(itemAmount).append("] ");
		buffer.append("itemInitial=[").append(itemInitial).append("] ");
		buffer.append("discount=[").append(discount).append("] ");
		buffer.append("netAmount=[").append(netAmount).append("] ");
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((ediOrderItemId == null) ? 0 : ediOrderItemId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof EdiOrderItem))
			return false;
		EdiOrderItem equalCheck = (EdiOrderItem) obj;
		if ((ediOrderItemId == null && equalCheck.ediOrderItemId != null) || (ediOrderItemId != null && equalCheck.ediOrderItemId == null))
			return false;
		if (ediOrderItemId != null && !ediOrderItemId.equals(equalCheck.ediOrderItemId))
			return false;
		return true;
	}

	private String setMaxLength(String columnName, String data) {
		if (data == null) {
			return data;
		}
		try {
			int size = getClass().getDeclaredField(columnName).getAnnotation(Column.class).length();
			int inLength = data.length();
			if (inLength > size) {
				data = data.substring(0, size);
			}
		} catch (NoSuchFieldException ex) {
		} catch (SecurityException ex) {
		}
		return data;
	}

}
