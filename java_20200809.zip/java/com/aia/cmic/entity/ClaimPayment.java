package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.aia.cmic.model.ClaimSettlementToCancel;
import com.aia.cmic.model.EligibleClaim;

/**
 */
@Entity
//@formatter:off
@SqlResultSetMapping(name = "claimPaymentTransferMap",
		classes = @ConstructorResult(targetClass = ClaimPaymentTransfer.class,
				columns = { @ColumnResult(name = "claimPaymentId", type = Long.class), @ColumnResult(name = "providerCode", type = String.class), @ColumnResult(name = "providerNameThai",
						type = String.class), @ColumnResult(name = "treatmentType", type = String.class), @ColumnResult(name = "presentedAmt",
						type = BigDecimal.class), @ColumnResult(name = "paymentTransferDt", type = Date.class), @ColumnResult(name = "paymentTransferRemark", type = String.class) }))
@SqlResultSetMappings({ @SqlResultSetMapping(name = "findEligiblePlansMapping", classes = @ConstructorResult(targetClass = EligibleClaim.class,
		columns = { @ColumnResult(name = "claimNo", type = String.class), @ColumnResult(name = "companyId", type = String.class), @ColumnResult(name = "occurrence",
				type = Integer.class), @ColumnResult(name = "policyNo", type = String.class), @ColumnResult(name = "businessLine", type = String.class), @ColumnResult(name = "productCode",
				type = String.class), @ColumnResult(name = "fullCreditInd", type = String.class), @ColumnResult(name = "csProductCategory", type = String.class), @ColumnResult(name = "planId",
				type = Long.class), @ColumnResult(name = "planCoverageNo", type = String.class), @ColumnResult(name = "productType",
				type = String.class), @ColumnResult(name = "paBonusAmt", type = BigDecimal.class), @ColumnResult(name = "paBonusDt", type = Date.class), @ColumnResult(
				name = "csProductCode", type = String.class), @ColumnResult(name = "planName", type = String.class),  @ColumnResult(name = "policyIssueDt", type = Date.class),
				@ColumnResult(name = "planCode", type = String.class),@ColumnResult(name = "claimPaymentId", type = Long.class) })), @SqlResultSetMapping(
		name = "ClaimSettlementToCancel",
		classes = @ConstructorResult(targetClass = ClaimSettlementToCancel.class,
				columns = { @ColumnResult(name = "claimNo", type = String.class), @ColumnResult(name = "companyId", type = String.class), @ColumnResult(
						name = "occurrence", type = Integer.class), @ColumnResult(name = "policyNo", type = String.class), @ColumnResult(
						name = "businessLine", type = String.class), @ColumnResult(name = "productCode", type = String.class) })) })
@NamedNativeQueries({ @NamedNativeQuery(
		name = "findClaimPaymentTransfer",
		query = "select cp.claimPaymentId, p.providerCode, p.providerNameThai, c.treatmentType, cp.presentedAmt, cp.paymentTransferDt, cp.paymentTransferRemark from claim c, claimpayment cp, provider p where c.claimno = cp.claimno and c.occurrence = cp.occurrence and c.providercode = p.providercode and cp.payeetype = 'P' and TO_CHAR(cp.settlementdate, 'YYYYMMDD') = TO_CHAR(?, 'YYYYMMDD') order by p.providercode, c.treatmentType, cp.paymenttransferdt, cp.paymenttransferremark",
		resultSetMapping = "claimPaymentTransferMap"), @NamedNativeQuery(
		name = "findClaimPaymentTransferWithProviderCode",
		query = "select cp.claimPaymentId, p.providerCode, p.providerNameThai, c.treatmentType, cp.presentedAmt, cp.paymentTransferDt, cp.paymentTransferRemark from claim c, claimpayment cp, provider p where c.claimno = cp.claimno and c.occurrence = cp.occurrence and c.providercode = p.providercode and cp.payeetype = 'P' and TO_CHAR(cp.settlementdate, 'YYYYMMDD') = TO_CHAR(?, 'YYYYMMDD')  and p.providercode = ? order by p.providercode, c.treatmentType, cp.paymenttransferdt, cp.paymenttransferremark",
		resultSetMapping = "claimPaymentTransferMap"), @NamedNativeQuery(
		name = "findEligiblePlans",
		query = "select a.claimNo as claimNo,a.companyId as companyId,a.occurrence as occurrence,a.policyNo as policyNo,c.businessLine as businessLine,c.productCode as productCode,b.fullCreditInd as fullCreditInd,b.csProductCategory as csProductCategory,a.planId as planId,a.planCoverageNo as planCoverageNo, a.productType as productType, b.paBonusAmt as paBonusAmt,b.paBonusDt as paBonusDt,b.productCode as csProductCode,c.planName as planName,b.policyIssueDt as policyIssueDt,a.planCode as planCode, a.claimPaymentId as claimPaymentId from ClaimPayment a inner join ClaimPolicy b on a.claimNo = b.claimNo and a.occurrence = b.occurrence and a.policyNo = b.policyNo inner join Plan c on a.planId=c.planId where  a.companyId = ?1 and  a.claimNo = ?2 and a.occurrence=?3 and ( a.eligibility = '10' or ( trim(a.eligibility) is null and a.systemEligibility='10' ) ) and a.paymentStatus in ('10','40') ",
		resultSetMapping = "findEligiblePlansMapping"), @NamedNativeQuery(
		name = "findClaimPaymentForCancel",
		query = "select a.claimNo as claimNo,a.companyId as companyId,a.occurrence as occurrence,a.policyNo as policyNo,b.businessLine as businessLine,b.productCode as productCode from ClaimPayment a inner join ClaimPolicy b on a.claimNo = b.claimNo and a.occurrence = b.occurrence and a.policyNo = b.policyNo where a.companyId = ?1 and a.claimNo = ?2 and  a.occurrence=?3 and a.policyNo=?4 and a.shortFallAmt > 0 and  b.productcode in ( select productCode from claimpayment where claimNo = ?2 and  occurrence=?3 and shortFallAmt > 0 )",
		resultSetMapping = "ClaimSettlementToCancel") })
@NamedQueries({ @NamedQuery(name = "findClaimPaymentByClaimPaymentId", query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.claimPaymentId = ?1"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrence",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 order by myClaimPayment.policyNo, myClaimPayment.productCode"), @NamedQuery(
		name = "deleteClaimPaymentByCompanyIdAndClaimNo",
		query = "delete from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2"), @NamedQuery(
		name = "resetClaimPayment",
		query = "update ClaimPayment myClaimPayment set myClaimPayment.eligibleAmt=0,myClaimPayment.noOfDaysAllocated=0,myClaimPayment.percentageAllocated=0,myClaimPayment.reimbursedDay=0,myClaimPayment.allocatedAmt=0,myClaimPayment.adjustedAmt=0,myClaimPayment.approvedAmt=0,myClaimPayment.interestAmt=0,myClaimPayment.deductAmt=0 where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3 and myClaimPayment.policyNo=?4 and myClaimPayment.planId=?5 and (myClaimPayment.planCoverageNo= ?6 or ?6 is null or ?6='') and (myClaimPayment.productCode= ?7 or ?7 is null or ?7='')"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrenceAndPaymentStatus",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3 and myClaimPayment.paymentStatus= ?4"), @NamedQuery(
		name = "checkingshortfallForSettleClaimService",
		query = "select sum(myClaimPayment.shortFallAmt),myClaimPayment.policyNo,myClaimPayment.productCode from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.shortFallAmt > ?4 and myClaimPayment.paymentStatus= ?5 and (myClaimPayment.lastModifiedDt between ?6 and ?7) group by myClaimPayment.companyId, myClaimPayment.claimNo, myClaimPayment.occurrence, myClaimPayment.policyNo,myClaimPayment.productCode"), @NamedQuery(
		name = "findAdjustedAmtByCompanyIdClaimNoOccurrenceAndPolicyNo",
		query = "select sum(myClaimPayment.approvedAmt),myClaimPayment.policyNo,myClaimPayment.productCode,myClaimPayment.planId from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.paymentStatus = ?4 group by myClaimPayment.companyId,myClaimPayment.claimNo,myClaimPayment.occurrence,myClaimPayment.policyNo,myClaimPayment.productCode,myClaimPayment.planId"), @NamedQuery(
		name = "findAdjustedAmtCashlessByCompanyIdClaimNoOccurrenceAndPolicyNo",
		query = "select sum(myClaimPayment.approvedAmt),myClaimPayment.policyNo,myClaimPayment.productCode from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.productType in (?4) and myClaimPayment.paymentStatus= ?5 group by myClaimPayment.companyId,myClaimPayment.claimNo,myClaimPayment.occurrence,myClaimPayment.policyNo,myClaimPayment.productCode"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrencePolicyNoAndProductCode",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 and (myClaimPayment.productCode= ?5 or ?5 is null or ?5='' ) and myClaimPayment.planId=?6 and myClaimPayment.eligibility IN ('10','93')"), @NamedQuery(
		name = "retrieveNonCashBenefitPlanPayment",
		query = "select sum(myClaimPayment.approvedAmt),myClaimPayment.policyNo,myClaimPayment.productCode,myClaimPayment.planId from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.paymentStatus=?4 group by myClaimPayment.companyId,myClaimPayment.claimNo,myClaimPayment.occurrence,myClaimPayment.policyNo,myClaimPayment.productCode,myClaimPayment.planId"), @NamedQuery(
		name = "countUnsettledRecs",
		query = "select count(myClaimPayment) from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.paymentStatus < ?4 and eligibility not in ('91')"), @NamedQuery(
		name = "findClaimPaymentForUpdate",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 and  (myClaimPayment.productCode=?5 or ?5 is null or ?5='') and myClaimPayment.planId= ?6 and (myClaimPayment.planCoverageNo= ?7 or ?7 is null or ?7='')"), @NamedQuery(
		name = "updateShortfallAmtInClaimPayment",
		query = "select myClaimPayment,myClaimPolicy from ClaimPayment myClaimPayment,ClaimPolicy myClaimPolicy where myClaimPayment.companyId= myClaimPolicy.companyId and myClaimPayment.claimNo= myClaimPolicy.claimNo and myClaimPayment.occurrence= myClaimPolicy.occurrence and myClaimPayment.policyNo= myClaimPolicy.policyNo and myClaimPayment.productCode = myClaimPolicy.productCode and myClaimPayment.companyId = ?1  and myClaimPolicy.companyId=?1 and myClaimPayment.claimNo = ?2 and myClaimPolicy.claimNo =?2 and myClaimPayment.occurrence=?3 and myClaimPolicy.occurrence=?3 and  myClaimPayment.shortFallAmt != ?4"), @NamedQuery(
	    name = "findClaimPaymentForReverse",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.claimNo=?1 and myClaimPayment.occurrence=?2"), @NamedQuery(
		name = "reverseClaimPayment",
		query = "update ClaimPayment myClaimPayment set myClaimPayment.paymentStatus=?1 where myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3"), @NamedQuery(
		name = "resetClaimPaymentToCalculate",
		query = "update ClaimPayment myClaimPayment set myClaimPayment.paymentStatus=?1,myClaimPayment.settlementDate=NULL where myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdPolicyNoAndHoldClaimInd",
		query = "select distinct myClaimPayment.claimNo, myClaimPayment.occurrence from ClaimPayment myClaimPayment, ClaimPolicy myClaimPolicy where myClaimPayment.claimNo= myClaimPolicy.claimNo and myClaimPayment.occurrence = myClaimPolicy.occurrence and myClaimPayment.companyId = ?1 and myClaimPolicy.companyId = ?1 and myClaimPayment.policyNo = ?2 and myClaimPolicy.policyNo = ?2 and myClaimPolicy.holdClaimInd=?3"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrencePaymentStatusAndEligibility",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3 and myClaimPayment.paymentStatus = ?4 and myClaimPayment.eligibility = ?5"), @NamedQuery(
		name = "findClaimPaymentToSettleByEligibility",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3 and myClaimPayment.paymentStatus in ('40','50') and myClaimPayment.eligibility = ?4"), @NamedQuery(
		name = "retrieveClaimsPaidAmount",
		query = "select sum(myClaimPayment.adjustedAmt) from ClaimPayment myClaimPayment,ClaimPolicy myClaimPolicy where myClaimPayment.claimNo= myClaimPolicy.claimNo and myClaimPayment.occurrence = myClaimPolicy.occurrence and myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and  myClaimPayment.eligibility=?4 and myClaimPolicy.businessLine =?5"), @NamedQuery(
		name = "retrieveDeclinedAmount",
		query = "select sum(myClaimPayment.adjustedAmt) from ClaimPayment myClaimPayment,ClaimPolicy myClaimPolicy where myClaimPayment.claimNo= myClaimPolicy.claimNo and myClaimPayment.occurrence = myClaimPolicy.occurrence and myClaimPayment.policyNo = myClaimPolicy.policyNo and myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and  myClaimPayment.policyNo= ?4 and myClaimPayment.eligibility=?5 and myClaimPolicy.businessLine !=?6"), @NamedQuery(
		name = "retrievePolicyNoForCoverage",
		query = "select distinct(myClaimPayment.policyNo) from ClaimPayment myClaimPayment  where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and  myClaimPayment.eligibility=?4 and myClaimPayment.adjustedAmt !=?5"), @NamedQuery(
		name = "retrieveClaimsPaidAmountCoverage",
		query = "select sum(myClaimPayment.adjustedAmt) from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo=?4 and  myClaimPayment.eligibility=?5"), @NamedQuery(
		name = "retrieveMemberShortfallAmount",
		query = "select sum(myClaimPayment.shortFallAmt) from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo=?4 and  myClaimPayment.eligibility=?5"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrenceAndPolicyNo",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 order by myClaimPayment.policyNo, myClaimPayment.productCode"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrenceToUpdate",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.eligibility='10'"), @NamedQuery(
		name = "checkDeclineforClaim",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and (myClaimPayment.eligibility != '91' and myClaimPayment.eligibility != '93')"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrencePolicyNoProductCodeAndEligibility",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 and (myClaimPayment.productCode= ?5 or ?5 is null or ?5='' ) and myClaimPayment.eligibility = ?6 and myClaimPayment.planId=?7"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrencePolicyNoProductCodeEligibilityAndProductType",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 and (myClaimPayment.productCode= ?5 or ?5 is null or ?5='' ) and myClaimPayment.eligibility = ?6 and myClaimPayment.productType not in (?7)"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrencePolicyNoProductCodePayeeAndPaymentStatus",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 and (myClaimPayment.productCode= ?5 or ?5 is null or ?5='' ) and myClaimPayment.eligibility = ?6 and myClaimPayment.payeeType = ?7 and myClaimPayment.paymentStatus =?8"), @NamedQuery(
		name = "findNonAllocatedClaimPayment",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and ( myClaimPayment.eligibleAmt = ?4 or ?4 is null ) and  ( myClaimPayment.reimbursedDay = ?5 or ?5 is null )"), @NamedQuery(
		name = "reportClaimPaymentToCOAST",
		query = "select myClaimPayment,myClaimPolicy from ClaimPayment myClaimPayment,ClaimPolicy myClaimPolicy where myClaimPayment.companyId= myClaimPolicy.companyId and myClaimPayment.claimNo= myClaimPolicy.claimNo and myClaimPayment.occurrence= myClaimPolicy.occurrence and myClaimPayment.policyNo= myClaimPolicy.policyNo and myClaimPayment.productCode = myClaimPolicy.productCode and myClaimPayment.companyId = ?1 and myClaimPayment.claimNo = ?2 and myClaimPayment.occurrence=?3  and  myClaimPayment.paymentStatus = ?4 and  myClaimPayment.eligibility = ?5 and myClaimPolicy.businessLine=?6"), @NamedQuery(
		name = "findDeclinedClaimPayment",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.claimNo = ?1 and myClaimPayment.occurrence = ?2 and myClaimPayment.eligibility='93' "), @NamedQuery(
		name = "findNAClaimPayment",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.claimNo = ?1 and myClaimPayment.occurrence = ?2 and myClaimPayment.eligibility='91' "), @NamedQuery(
		name = "findApprovedZeroAmt",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.claimNo = ?1 and myClaimPayment.occurrence = ?2 and ( myClaimPayment.eligibility='10' or ( trim(myClaimPayment.eligibility) is null and myClaimPayment.systemEligibility='10' ))  and myClaimPayment.approvedAmt=0 "), @NamedQuery(
		name = "checkEligibility",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.eligibility = ?4"), @NamedQuery(
		name = "checkDeclineForClaimPayment",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.eligibility != ?4"), @NamedQuery(
		name = "checkClaimPaymentForWriteSettlementWorking",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.paymentStatus = '50' and myClaimPayment.approvedAmt>0"), @NamedQuery(
		name = "findClaimPaymentByCompanyIdClaimNoOccurrenceAndPayeeType",
		query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.payeeType= 'P' and myClaimPayment.settlementDate is not null and myClaimPayment.eligibility not in ('30','91')"), @NamedQuery(
		name = "updateSuppressChequeIndClaimPayment",
		query = "update ClaimPayment myClaimPayment set myClaimPayment.suppressChequeInd=?1 where myClaimPayment.companyId = ?2 and myClaimPayment.claimNo = ?3 and myClaimPayment.occurrence = ?4 and myClaimPayment.policyNo=?5"), @NamedQuery(
		name = "findClaimPaymentForPaymentChannel",
		query = "select cp.claimPaymentId,cp.companyId,cp.claimNo,cp.occurrence,cp.productCode,cp.policyNo,cp.planId,pyee.title,pyee.lastName,pyee.firstName,insred.title,insred.lastName,insred.firstName,plcy.businessLine,plcy.policyIssueDt,cp.productType,cp.payeeType,pyee.bankCode,pyee.bankAccountNo from ClaimPayment cp,Payee pyee,Insured insred,ClaimPolicy plcy where cp.claimNo=pyee.claimNo and cp.occurrence=pyee.occurrence and cp.policyNo=pyee.policyNo and cp.payeeType=pyee.payeeType and cp.claimNo=insred.claimNo and cp.occurrence=insred.occurrence  and cp.companyId=plcy.companyId and cp.claimNo=plcy.claimNo and cp.occurrence=plcy.occurrence and cp.policyNo=plcy.policyNo and ( ( cp.productCode=plcy.productCode and plcy.businessLine='CS') or plcy.businessLine <> 'CS') and cp.companyId=?1 and cp.claimNo=?2 and cp.occurrence=?3  and cp.paymentStatus = '50' and cp.approvedAmt>0"), 
	    @NamedQuery(name = "checkClaimPaymentChanelInvalid",query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.eligibility= ?4 and myClaimPayment.approvedAmt is null"),//
		@NamedQuery(name = "findCalculatedPaymentStatusApprovedZeroAmt",query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo = ?2 and myClaimPayment.occurrence = ?3 and myClaimPayment.eligibility='10' and ( myClaimPayment.paymentStatus='40' or ( trim(myClaimPayment.paymentStatus) is null ))  and ( myClaimPayment.approvedAmt=0 or myClaimPayment.approvedAmt is null ) "),//
        @NamedQuery(name = "claimPaymentUpdateSuppressIndByClaimNo", query = "update ClaimPayment myClaimPayment set myClaimPayment.suppressChequeInd=?1 where myClaimPayment.companyId = ?2 and myClaimPayment.claimNo = ?3 and myClaimPayment.occurrence = ?4"),
        @NamedQuery(name = "findPreviousHSBonusAmt", query = "select sum(cp.hsBonusDeductAmt) from ClaimPayment cp,ClaimPolicyPlan cpp where cp.claimNo=cpp.claimNo and cp.occurrence=cpp.occurrence and cp.policyNo=cpp.policyNo and cp.planId=cpp.planId and cp.planCoverageNo=cpp.planCoverageNo and cp.policyNo=?1  and cp.planId=?2 and cp.planCoverageNo=?3 and cpp.hsBonusAmt=?4 and cpp.hsBonusDt=?5 and cp.paymentStatus in ('50','65','70') and cp.hsBonusDeductAmt > 0 group by cp.policyNo"),
        @NamedQuery(name = "findSumHSBonusDeductAmtByPolicynoPlanidPlancoverageno", query = "select sum(nvl(myClaimPayment.hsBonusDeductAmt,0)) from ClaimPayment myClaimPayment where myClaimPayment.claimNo = ?1  and myClaimPayment.occurrence = ?2 and myClaimPayment.companyId = ?3 and myClaimPayment.policyNo = ?4 and myClaimPayment.planId = ?5 and myClaimPayment.planCoverageNo = ?6 "), //
        @NamedQuery(name = "findSumInterestAmountByClaimNoAndOccurrence", query = "select sum(nvl(myClaimPayment.interestAmt,0)) from ClaimPayment myClaimPayment where myClaimPayment.claimNo = ?1  and myClaimPayment.occurrence = ?2 and myClaimPayment.companyId = ?3 "),//
        @NamedQuery(name = "retrieveSumShortfallAmount",	query = "select sum(nvl(myClaimPayment.shortFallAmt,0)) from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3"),//
        @NamedQuery(name = "findDeductAmtByClaimNoOccurrenceNot30111ProductCode", query="select sum(nvl(myClaimPayment.approvedAmt,0)) from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.paymentStatus in ('50','70') and myClaimPayment.planCode != '30111' "),
        @NamedQuery(name = "findSumShortFallAmtByClaimNoOccurrenceNot30111ProductCode", query="select sum(nvl(myClaimPayment.shortFallAmt,0)) from ClaimPayment myClaimPayment where myClaimPayment.companyId= ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.paymentStatus in ('50','70') and myClaimPayment.planCode != '30111' "),
        @NamedQuery(name = "findDeductAmtPolicyNoPlan",	query = "select nvl(sum(nvl(cp.deductAmt,0)),0) from ClaimPayment cp,Claim c where cp.claimNo=c.claimNo and cp.occurrence=c.occurrence and cp.companyId= ?1 and ( (c.hospitalizationDate between ?2 and ?3 ) or (c.accidentDt between ?2 and ?3)) and cp.policyNo=?4 and cp.planId=?5 and cp.paymentStatus in ('65','70') and cp.deductAmt > 0"),//
		@NamedQuery(name = "findClaimPaymentByCompanyIdClaimNoOccurrencePolicyNo", query = "select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?1 and myClaimPayment.claimNo= ?2 and myClaimPayment.occurrence= ?3 and myClaimPayment.policyNo= ?4 ")
})
//@formatter:on
@Table(name = "CLAIMPAYMENT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPayment")
public class ClaimPayment extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaymentSequence")
	@SequenceGenerator(name = "claimPaymentSequence", sequenceName = "s_claimpayment")
	@Column(name = "CLAIMPAYMENTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPaymentId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productCode;
	/**
	 */

	@Column(name = "PRODUCTTYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productType;
	/**
	 */

	@Column(name = "SYSTEMELIGIBILITY", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String systemEligibility;
	/**
	 */

	@Column(name = "ELIGIBILITY", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String eligibility;
	/**
	 */

	@Column(name = "DECLINEREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String declineReason;
	/**
	 */

	@Column(name = "PRESENTEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt = BigDecimal.ZERO;

	@Column(name = "ELIGIBLEAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal eligibleAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "ALLOCATEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal allocatedAmt;
	/**
	 */

	@Column(name = "INTERESTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private
	BigDecimal interestAmt;
	/**
	 */
	@Column(name = "HSBONUSDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private
	BigDecimal hsBonusDeductAmt = BigDecimal.ZERO;
	/**
	 */
	@Column(name = "ADJUSTEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal adjustedAmt;
	/**
	 */

	@Column(name = "ADJUSTEDREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String adjustedReason;
	/**
	 */

	@Column(name = "APPROVEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal approvedAmt;
	/**
	 */

	@Column(name = "PAYMENTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentStatus;
	/**
	 */

	@Column(name = "PAYEETYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeType;
	/**
	 */

	@Column(name = "COPAYMENTPERCENT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal coPaymentPercent;
	/**
	 */

	@Column(name = "COPAYMENTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal coPaymentAmt;
	/**
	 */

	@Column(name = "SUPPRESSCHEQUEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suppressChequeInd;
	/**
	 */

	@Column(name = "SHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal shortFallAmt;
	/**
	 */

	@Column(name = "NOOFDAYSALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysAllocated;
	/**
	 */

	@Column(name = "PERCENTAGEALLOCATED", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal percentageAllocated;
	/**
	 */

	@Column(name = "REIMBURSEDDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer reimbursedDay;
	/**
	 */

	@Column(name = "LASTMODIFIEDUSERDEPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDept;
	/**
	 */

	@Column(name = "LASTMODIFIEDUSERDESK", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDesk;

	@Column(name = "SETTLEMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date settlementDate;

	@Column(name = "MARKINGIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String markingInd;

	@Column(name = "MARKINGREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String markingReason;

	@Column(name = "MARKINGPERSON", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String markingPerson;

	@Column(name = "MARKINGDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date markingDate;

	@Column(name = "PAYMENTTRANSFERDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date paymentTransferDt;

	@Column(name = "PAYMENTTRANSFERREMARK", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentTransferRemark;
	
	@Column(name = "PAYMENTTRANSFERSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentTransferStatus;

	@Column(name = "PAYMENTCHANNEL", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String paymentChannel;

	@Column(name = "PLANCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCode;

	@Column(name = "PAYNONCOVERITEMIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String payNonCoverItemInd;

	@Column(name = "PAYMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Date paymentDate;
	
	@Column(name = "DEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private
	BigDecimal deductAmt = BigDecimal.ZERO;
	
	
	@Column(name = "AIELIGIBILITY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiEligibility;
	
	@Column(name = "AISCORE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiScore;
	
	@Column(name = "AIIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiInd;
	

	/**
	 */
	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	/**
	 */
	public Long getClaimPaymentId() {
		return this.claimPaymentId;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public void setSystemEligibility(String systemEligibility) {
		this.systemEligibility = systemEligibility;
	}

	/**
	 */
	public String getSystemEligibility() {
		return this.systemEligibility;
	}

	/**
	 */
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	/**
	 */
	public String getEligibility() {
		return this.eligibility;
	}

	/**
	 */
	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}

	/**
	 */
	public String getDeclineReason() {
		return this.declineReason;
	}

	/**
	 */
	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	/**
	 */
	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 */
	public BigDecimal getEligibleAmt() {
		return this.eligibleAmt;
	}

	/**
	 */
	public void setAllocatedAmt(BigDecimal allocatedAmt) {
		this.allocatedAmt = allocatedAmt;
	}

	/**
	 */
	public BigDecimal getAllocatedAmt() {
		return this.allocatedAmt;
	}

	/**
	 */
	public void setAdjustedAmt(BigDecimal adjustedAmt) {
		this.adjustedAmt = adjustedAmt;
	}

	/**
	 */
	public BigDecimal getAdjustedAmt() {
		return this.adjustedAmt;
	}

	/**
	 */
	public void setAdjustedReason(String adjustedReason) {
		this.adjustedReason = adjustedReason;
	}

	/**
	 */
	public String getAdjustedReason() {
		return this.adjustedReason;
	}

	/**
	 */
	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

	/**
	 */
	public BigDecimal getApprovedAmt() {
		return this.approvedAmt;
	}

	public BigDecimal getInterestAmt() {
		return interestAmt;
	}

	public void setInterestAmt(BigDecimal interestAmt) {
		this.interestAmt = interestAmt;
	}

	public BigDecimal getHsBonusDeductAmt() {
		return hsBonusDeductAmt;
	}

	public void setHsBonusDeductAmt(BigDecimal hsBonusDeductAmt) {
		this.hsBonusDeductAmt = hsBonusDeductAmt;
	}

	/**
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 */
	public String getPaymentStatus() {
		return this.paymentStatus;
	}

	/**
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 */
	public String getPayeeType() {
		return this.payeeType;
	}

	/**
	 */
	public void setCoPaymentPercent(BigDecimal coPaymentPercent) {
		this.coPaymentPercent = coPaymentPercent;
	}

	/**
	 */
	public BigDecimal getCoPaymentPercent() {
		return this.coPaymentPercent;
	}

	/**
	 */
	public void setCoPaymentAmt(BigDecimal coPaymentAmt) {
		this.coPaymentAmt = coPaymentAmt;
	}

	/**
	 */
	public BigDecimal getCoPaymentAmt() {
		return this.coPaymentAmt;
	}

	/**
	 */
	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	/**
	 */
	public String getSuppressChequeInd() {
		return this.suppressChequeInd;
	}

	/**
	 */
	public void setShortFallAmt(BigDecimal shortFallAmt) {
		this.shortFallAmt = shortFallAmt;
	}

	/**
	 */
	public BigDecimal getShortFallAmt() {
		return this.shortFallAmt;
	}

	/**
	 */
	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	/**
	 */
	public Integer getNoOfDaysAllocated() {
		return this.noOfDaysAllocated;
	}

	/**
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 */
	public BigDecimal getPercentageAllocated() {
		return this.percentageAllocated;
	}

	/**
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	/**
	 */
	public Integer getReimbursedDay() {
		return this.reimbursedDay;
	}

	/**
	 * @return the lastModifiedUserDept
	 */
	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	/**
	 * @param lastModifiedUserDept the lastModifiedUserDept to set
	 */
	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	/**
	 * @return the lastModifiedUserDesk
	 */
	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	/**
	 * @param lastModifiedUserDesk the lastModifiedUserDesk to set
	 */
	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getMarkingInd() {
		return markingInd;
	}

	public void setMarkingInd(String markingInd) {
		this.markingInd = markingInd;
	}

	public String getMarkingReason() {
		return markingReason;
	}

	public void setMarkingReason(String markingReason) {
		this.markingReason = markingReason;
	}

	public String getMarkingPerson() {
		return markingPerson;
	}

	public void setMarkingPerson(String markingPerson) {
		this.markingPerson = markingPerson;
	}

	public Date getMarkingDate() {
		return markingDate;
	}

	public void setMarkingDate(Date markingDate) {
		this.markingDate = markingDate;
	}

	public String getPaymentTransferRemark() {
		return paymentTransferRemark;
	}

	public void setPaymentTransferRemark(String paymentTransferRemark) {
		this.paymentTransferRemark = paymentTransferRemark;
	}
	
    public String getPaymentTransferStatus() {
		return paymentTransferStatus;
	}

	public void setPaymentTransferStatus(String paymentTransferStatus) {
		this.paymentTransferStatus = paymentTransferStatus;
	}

	public Date getPaymentTransferDt() {
		return paymentTransferDt;
	}

	public void setPaymentTransferDt(Date paymentTransferDt) {
		this.paymentTransferDt = paymentTransferDt;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	
	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	/**
	 */
	public ClaimPayment() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPayment that) {
		setClaimPaymentId(that.getClaimPaymentId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setProductCode(that.getProductCode());
		setProductType(that.getProductType());
		setSystemEligibility(that.getSystemEligibility());
		setEligibility(that.getEligibility());
		setDeclineReason(that.getDeclineReason());
		setPresentedAmt(that.getPresentedAmt());
		setEligibleAmt(that.getEligibleAmt());
		setAllocatedAmt(that.getAllocatedAmt());
		setAdjustedAmt(that.getAdjustedAmt());
		setAdjustedReason(that.getAdjustedReason());
		setApprovedAmt(that.getApprovedAmt());
		setPaymentStatus(that.getPaymentStatus());
		setPayeeType(that.getPayeeType());
		setCoPaymentPercent(that.getCoPaymentPercent());
		setCoPaymentAmt(that.getCoPaymentAmt());
		setSuppressChequeInd(that.getSuppressChequeInd());
		setShortFallAmt(that.getShortFallAmt());
		setNoOfDaysAllocated(that.getNoOfDaysAllocated());
		setPercentageAllocated(that.getPercentageAllocated());
		setReimbursedDay(that.getReimbursedDay());
		setLastModifiedUserDept(that.getLastModifiedUserDept());
		setLastModifiedUserDesk(that.getLastModifiedUserDesk());
		setInterestAmt(that.getInterestAmt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setPaymentChannel(that.getPaymentChannel());
		setPlanCode(that.getPlanCode());
		setPayNonCoverItemInd(that.getPayNonCoverItemInd());
		setPaymentDate(that.getPaymentDate());
		setPaymentTransferRemark(that.paymentTransferRemark);
		setPaymentTransferStatus(that.paymentTransferStatus);
		setDeductAmt(that.getDeductAmt());
		setAiEligibility(that.getAiEligibility());
		setAiScore(that.getAiScore());
		setAiInd(that.getAiInd());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPaymentId=[").append(claimPaymentId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("productType=[").append(productType).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("systemEligibility=[").append(systemEligibility).append("] ");
		buffer.append("eligibility=[").append(eligibility).append("] ");
		buffer.append("declineReason=[").append(declineReason).append("] ");
		buffer.append("presentedAmt=[").append(presentedAmt).append("] ");
		buffer.append("eligibleAmt=[").append(eligibleAmt).append("] ");
		buffer.append("allocatedAmt=[").append(allocatedAmt).append("] ");
		buffer.append("adjustedAmt=[").append(adjustedAmt).append("] ");
		buffer.append("adjustedReason=[").append(adjustedReason).append("] ");
		buffer.append("approvedAmt=[").append(approvedAmt).append("] ");
		buffer.append("paymentStatus=[").append(paymentStatus).append("] ");
		buffer.append("payeeType=[").append(payeeType).append("] ");
		buffer.append("coPaymentPercent=[").append(coPaymentPercent).append("] ");
		buffer.append("coPaymentAmt=[").append(coPaymentAmt).append("] ");
		buffer.append("suppressChequeInd=[").append(suppressChequeInd).append("] ");
		buffer.append("shortFallAmt=[").append(shortFallAmt).append("] ");
		buffer.append("noOfDaysAllocated=[").append(noOfDaysAllocated).append("] ");
		buffer.append("percentageAllocated=[").append(percentageAllocated).append("] ");
		buffer.append("reimbursedDay=[").append(reimbursedDay).append("] ");
		buffer.append("lastModifiedUserDept=[").append(lastModifiedUserDept).append("] ");
		buffer.append("lastModifiedUserDesk=[").append(lastModifiedUserDesk).append("] ");
		buffer.append("settlementDate=[").append(settlementDate).append("] ");
		buffer.append("markingInd=[").append(markingInd).append("] ");
		buffer.append("markingReason=[").append(markingReason).append("] ");
		buffer.append("markingPerson=[").append(markingPerson).append("] ");
		buffer.append("markingDate=[").append(markingDate).append("] ");
		buffer.append("paymentTransferDt=[").append(paymentTransferDt).append("] ");
		buffer.append("paymentTransferRemark=[").append(paymentTransferRemark).append("] ");
		buffer.append("paymentTransferStatus=[").append(paymentTransferStatus).append("] ");
		buffer.append("paymentChannel=[").append(paymentChannel).append("] ");
		buffer.append("planCode=[").append(planCode).append("] ");
		buffer.append("payNonCoverItemInd=[").append(payNonCoverItemInd).append("] ");
		buffer.append("paymentDate=[").append(paymentDate).append("] ");
		buffer.append("deductAmt=[").append(deductAmt).append("] ");
		buffer.append("aiEligibility=[").append(aiEligibility).append("] ");
		buffer.append("aiScore=[").append(aiScore).append("] ");
		buffer.append("aiInd=[").append(aiInd).append("] ");
		
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPaymentId == null) ? 0 : claimPaymentId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPayment))
			return false;
		ClaimPayment equalCheck = (ClaimPayment) obj;
		if ((claimPaymentId == null && equalCheck.claimPaymentId != null) || (claimPaymentId != null && equalCheck.claimPaymentId == null))
			return false;
		if (claimPaymentId != null && !claimPaymentId.equals(equalCheck.claimPaymentId))
			return false;
		return true;
	}

	public void copyProperties(ClaimPaymentDetail claimPaymentDetail) {

		setCompanyId(claimPaymentDetail.getCompanyId());
		setClaimNo(claimPaymentDetail.getClaimNo());
		setOccurrence(claimPaymentDetail.getOccurrence());
		setPolicyNo(claimPaymentDetail.getPolicyNo());
		setPlanId(claimPaymentDetail.getPlanId());
		setPlanCoverageNo(claimPaymentDetail.getPlanCoverageNo());
		setProductType(claimPaymentDetail.getProductType());
		//		setProductCode(claimPaymentDetail.getProductCode());
		setEligibleAmt(claimPaymentDetail.getEligibleAmt());
		setAllocatedAmt(claimPaymentDetail.getAllocatedAmt());
		setShortFallAmt(claimPaymentDetail.getShortFallAmt());
		setNoOfDaysAllocated(claimPaymentDetail.getNoOfDaysAllocated());
		//		setPercentageAllocated(claimPaymentDetail.getPercentageAllocated());
		setReimbursedDay(claimPaymentDetail.getReimbursedDay());
		setShortFallAmt(claimPaymentDetail.getShortFallAmt());
		setPresentedAmt(claimPaymentDetail.getPresentedAmt());
		setDeductAmt(claimPaymentDetail.getDeductAmt());

	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the paymentChannel
	 */
	public String getPaymentChannel() {
		return paymentChannel;
	}

	/**
	 * @param paymentChannel the paymentChannel to set
	 */
	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

	public String getPayNonCoverItemInd() {
		return payNonCoverItemInd;
	}

	public void setPayNonCoverItemInd(String payNonCoverItemInd) {
		this.payNonCoverItemInd = payNonCoverItemInd;
	}

	/**
	 * @return the paymentDate
	 */
	public Date getPaymentDate() {
		return paymentDate;
	}

	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	

	public String getAiEligibility() {
		return aiEligibility;
	}

	public void setAiEligibility(String aiEligibility) {
		this.aiEligibility = aiEligibility;
	}

	public String getAiScore() {
		return aiScore;
	}

	public void setAiScore(String aiScore) {
		this.aiScore = aiScore;
	}

	public String getAiInd() {
		return aiInd;
	}
	
	public void setAiInd(String aiInd) {
		this.aiInd = aiInd;
	}

	
}
