package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@NamedQueries({
		@NamedQuery(name = "findClaimPaidWorkingByPrimaryKey", query = "select myClaimPaidWorking from ClaimPaidWorking myClaimPaidWorking where myClaimPaidWorking.claimPaidWorkingId = ?1"),
		@NamedQuery(name = "findClaimPaidWorkingByClaimNo", query = "select myClaimPaidWorking from ClaimPaidWorking myClaimPaidWorking where myClaimPaidWorking.claimNo = ?1"),
		@NamedQuery(name = "findClaimPaidByClaimNoOccurrencePolicyNoSubofficeProductCodeAndPaymentStatus", query = "select myClaimPaidWorking from ClaimPaidWorking myClaimPaidWorking where myClaimPaidWorking.claimNo = ?1 and myClaimPaidWorking.occurrence = ?2 and myClaimPaidWorking.policyNo = ?3 and myClaimPaidWorking.subOfficeCode = ?4 and (myClaimPaidWorking.productCode = ?5 or (?5 is null and myClaimPaidWorking.productCode is null)) and myClaimPaidWorking.paymentStatus = ?6"),
		@NamedQuery(name = "findClaimPaidByClaimNoOccurrencePolicyNoProductCodeAndPaymentStatus", query = "select myClaimPaidWorking from ClaimPaidWorking myClaimPaidWorking where myClaimPaidWorking.claimNo = ?1 and myClaimPaidWorking.occurrence = ?2 and myClaimPaidWorking.policyNo = ?3 and (myClaimPaidWorking.productCode = ?4 or (?4 is null and myClaimPaidWorking.productCode is null)) and myClaimPaidWorking.paymentStatus = ?5")})
@Table(name = "CLAIMPAIDWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPaidWorking")
public class ClaimPaidWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	//	@Value("${privateKey}")
	//	private final String PRIVATE_KEY = "1234567812345678";

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaidWorkingSequence")
	@SequenceGenerator(name = "claimPaidWorkingSequence", sequenceName = "s_claimpaidworking")
	@Column(name = "CLAIMPAIDWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPaidWorkingId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "MEMBERSHIPNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String membershipNo;
	/**
	 */

	@Column(name = "DIAGNOSISCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String diagnosiscode;
	/**
	 */

	@Column(name = "PROCEDURECODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String procedureCode;
	/**
	 */

	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "CLAIMINCURREDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date claimInCurredDate;
	/**
	 */

	@Column(name = "PAYMENTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentStatus;
	/**
	 */

	@Column(name = "CLAIMPAIDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date claimPaidDate;
	/**
	 */

	@Column(name = "CLAIMBILLEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal claimBilledAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "CLAIMRESERVEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal claimReservedAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "DECLINEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal declinedAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "CLAIMPAIDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal claimPaidAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "MEMBERSHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal memberShortFallAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "PROVIDERSHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal providerShortFallAmt = BigDecimal.ZERO;
	/**
	 */

	@Column(name = "CYCLEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date cycleDate;

	/**
	 */

	@Column(name = "SUSPENSECODE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspenseCode;

	/**
	 */

	@Column(name = "OCCURRENCE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	/**
	 */

	public Long getClaimPaidWorkingId() {
		return claimPaidWorkingId;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getSuspenseCode() {
		return suspenseCode;
	}

	public void setSuspenseCode(String suspenseCode) {
		this.suspenseCode = suspenseCode;
	}

	public void setClaimPaidWorkingId(Long claimPaidWorkingId) {
		this.claimPaidWorkingId = claimPaidWorkingId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getMembershipNo() {
		return membershipNo;
	}

	public void setMembershipNo(String membershipNo) {
		this.membershipNo = membershipNo;
	}

	public String getDiagnosiscode() {
		return diagnosiscode;
	}

	public void setDiagnosiscode(String diagnosiscode) {
		this.diagnosiscode = diagnosiscode;
	}

	public String getProcedureCode() {
		return procedureCode;
	}

	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Date getClaimInCurredDate() {
		return claimInCurredDate;
	}

	public void setClaimInCurredDate(Date claimInCurredDate) {
		this.claimInCurredDate = claimInCurredDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Date getClaimPaidDate() {
		return claimPaidDate;
	}

	public void setClaimPaidDate(Date claimPaidDate) {
		this.claimPaidDate = claimPaidDate;
	}

	public BigDecimal getClaimBilledAmt() {
		return claimBilledAmt;
	}

	public void setClaimBilledAmt(BigDecimal claimBilledAmt) {
		this.claimBilledAmt = claimBilledAmt;
	}

	public BigDecimal getClaimReservedAmt() {
		return claimReservedAmt;
	}

	public void setClaimReservedAmt(BigDecimal claimReservedAmt) {
		this.claimReservedAmt = claimReservedAmt;
	}

	public BigDecimal getDeclinedAmt() {
		return declinedAmt;
	}

	public void setDeclinedAmt(BigDecimal declinedAmt) {
		this.declinedAmt = declinedAmt;
	}

	public BigDecimal getClaimPaidAmt() {
		return claimPaidAmt;
	}

	public void setClaimPaidAmt(BigDecimal claimPaidAmt) {
		this.claimPaidAmt = claimPaidAmt;
	}

	public BigDecimal getMemberShortFallAmt() {
		return memberShortFallAmt;
	}

	public void setMemberShortFallAmt(BigDecimal memberShortFallAmt) {
		this.memberShortFallAmt = memberShortFallAmt;
	}

	public BigDecimal getProviderShortFallAmt() {
		return providerShortFallAmt;
	}

	public void setProviderShortFallAmt(BigDecimal providerShortFallAmt) {
		this.providerShortFallAmt = providerShortFallAmt;
	}

	public Date getCycleDate() {
		return cycleDate;
	}

	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPaidWorkingId=[").append(claimPaidWorkingId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("membershipNo=[").append(membershipNo).append("] ");
		buffer.append("diagnosiscode=[").append(diagnosiscode).append("] ");
		buffer.append("procedureCode=[").append(procedureCode).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("subOfficeCode=[").append(subOfficeCode).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("claimInCurredDate=[").append(claimInCurredDate).append("] ");
		buffer.append("paymentStatus=[").append(paymentStatus).append("] ");
		buffer.append("claimPaidDate=[").append(claimPaidDate).append("] ");
		buffer.append("claimBilledAmt=[").append(claimBilledAmt).append("] ");
		buffer.append("claimReservedAmt=[").append(claimReservedAmt).append("] ");
		buffer.append("declinedAmt=[").append(declinedAmt).append("] ");
		buffer.append("claimPaidAmt=[").append(claimPaidAmt).append("] ");
		buffer.append("memberShortFallAmt=[").append(memberShortFallAmt).append("] ");
		buffer.append("providerShortFallAmt=[").append(providerShortFallAmt).append("] ");
		buffer.append("cycleDate=[").append(cycleDate).append("] ");
		buffer.append("suspenseCode=[").append(suspenseCode).append("] ");

		return buffer.toString();
	}
}
