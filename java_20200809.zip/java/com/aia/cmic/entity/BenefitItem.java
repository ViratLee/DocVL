package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
//@formatter:off
@NamedQueries({
		@NamedQuery(name = "findBenefitItemByBenefitItemCode", query = "select myBenefitItem from BenefitItem myBenefitItem where myBenefitItem.benefitItemCode = ?1"),
		@NamedQuery(name = "findBenefitItemByPrimaryKey", query = "select myBenefitItem from BenefitItem myBenefitItem where myBenefitItem.benefitItemCode = ?1"),
		@NamedQuery(name = "findBenefitDescThaiByBenefitItemCode", query = "select myBenefitItem.benefitDescThai from BenefitItem myBenefitItem where myBenefitItem.benefitItemCode = ?1 and myBenefitItem.businessLine = ?2"),
		@NamedQuery(name = "findBenefitItemByFieldContaining", query = "select myBenefitItem from BenefitItem myBenefitItem where myBenefitItem.benefitItemCode like ?1 or myBenefitItem.benefitItemDesc like ?2"),
		@NamedQuery(name = "findBenefitCodeForCashBenefit", query = "select distinct a.benefitItemCode from BenefitItem a,PlanBenefit b where a.benefitItemCode=b.benefitItemCode and b.planId=?1 and a.hsBenefitInd='N'"),
		@NamedQuery(name = "findBenefitCodeForCS_GECashBenefit", query = "select distinct a.benefitItemCode from BenefitItem a,ClaimPolicyCoverage b where a.benefitItemCode=b.benefitCode and a.hsBenefitInd='N' and a.benefitItemCode in( select benefitCode from ClaimPolicyCoverage where claimNo=?1 and occurrence=?2 and policyNo=?3 and planId=?4 and productCode=?5) and claimNo=?1 and occurrence=?2 and a.businessLine=?6 and upper(b.enableInd) <> 'N' "),
		@NamedQuery(name = "findBenefitItemByBenefitItemCodeAndBusinessLine", query = "select myBenefitItem from BenefitItem myBenefitItem where myBenefitItem.benefitItemCode = ?1 and myBenefitItem.businessLine = ?2"),
		@NamedQuery(name = "findBenefitCodesByBusinessLine", query = "select myBenefitItem.benefitItemCode from BenefitItem myBenefitItem where myBenefitItem.businessLine = ?1"),
		@NamedQuery(name = "findBenefitItemByFieldContainingAndBusinessLine", query = "select myBenefitItem from BenefitItem myBenefitItem where (myBenefitItem.benefitItemCode like ?1 or myBenefitItem.benefitItemDesc like ?2) and myBenefitItem.businessLine = ?3 "),
		@NamedQuery(name = "findBenefitItemByFieldContainingAndBusinessLineOLPA", query = "select myBenefitItem from BenefitItem myBenefitItem where (myBenefitItem.benefitItemCode like ?1 or myBenefitItem.benefitItemDesc like ?2) and myBenefitItem.businessLine in ('OL','PA') ")})
//@formatter:on
@Table(name = "BENEFITITEM")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "BenefitItem")
public class BenefitItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "benefitItemSequence")
	@SequenceGenerator(name = "benefitItemSequence", sequenceName = "s_benefitItem")
	@Column(name = "BENEFITITEMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long benefitItemId;

	/**
	 */

	@Column(name = "BENEFITITEMCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitItemCode;
	/**
	 */

	@Column(name = "BENEFITITEMDESC", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitItemDesc;
	/**
	 */

	@Column(name = "BENEFITDESCTHAI", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitDescThai;
	/**
	 */

	@Column(name = "BUSINESSLINE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	/**
	 */

	@Column(name = "HSBENEFITIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	char hsBenefitInd;

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;

	/**
	 */

	/**
	 * @return the benefitItemCode
	 */
	public String getBenefitItemCode() {
		return benefitItemCode;
	}

	public Long getBenefitItemId() {
		return benefitItemId;
	}

	public void setBenefitItemId(Long benefitItemId) {
		this.benefitItemId = benefitItemId;
	}

	/**
	 * @param benefitItemCode the benefitItemCode to set
	 */
	public void setBenefitItemCode(String benefitItemCode) {
		this.benefitItemCode = benefitItemCode;
	}

	/**
	 * @return the benefitItemDesc
	 */
	public String getBenefitItemDesc() {
		return benefitItemDesc;
	}

	/**
	 * @param benefitItemDesc the benefitItemDesc to set
	 */
	public void setBenefitItemDesc(String benefitItemDesc) {
		this.benefitItemDesc = benefitItemDesc;
	}

	/**
	 * @return the benefitDescThai
	 */
	public String getBenefitDescThai() {
		return benefitDescThai;
	}

	/**
	 * @param benefitDescThai the benefitDescThai to set
	 */
	public void setBenefitDescThai(String benefitDescThai) {
		this.benefitDescThai = benefitDescThai;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public char getHsBenefitInd() {
		return hsBenefitInd;
	}

	public void setHsBenefitInd(char hsBenefitInd) {
		this.hsBenefitInd = hsBenefitInd;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public BenefitItem() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(BenefitItem that) {
		setBenefitItemCode(that.getBenefitItemCode());
		setBenefitItemDesc(that.getBenefitItemDesc());
		setBenefitDescThai(that.getBenefitDescThai());
		setBusinessLine(that.getBusinessLine());
		setHsBenefitInd(that.getHsBenefitInd());
		setCompanyId(that.getCompanyId());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("benefitItemCode=[").append(benefitItemCode).append("] ");
		buffer.append("benefitItemDesc=[").append(benefitItemDesc).append("] ");
		buffer.append("benefitDescThai=[").append(benefitDescThai).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("hsBenefitInd=[").append(hsBenefitInd).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((benefitItemCode == null) ? 0 : benefitItemCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof BenefitItem))
			return false;
		BenefitItem equalCheck = (BenefitItem) obj;
		if ((benefitItemCode == null && equalCheck.benefitItemCode != null) || (benefitItemCode != null && equalCheck.benefitItemCode == null))
			return false;
		if (benefitItemCode != null && !benefitItemCode.equals(equalCheck.benefitItemCode))
			return false;
		return true;
	}
}
