package com.aia.cmic.entity;

import java.math.BigDecimal;
import java.util.Date;

public class ClaimPaymentTransfer {
	Long claimPaymentId;
	String providerCode;
	String providerNameThai;
	String treatmentType;
	BigDecimal presentedAmt;
	Date invoiceDate;
	Date paymentTransferDt;
	Date settlementDate;
	Date incidentDt;
	String paymentTransferRemark;
	String remark;
	String name;
	String invoiceNum;
	Date claimstatusdt;
	String ediInd;
	String stpInd;
	String businessLine;
	
	public ClaimPaymentTransfer() {
	}

	public ClaimPaymentTransfer(Long claimPaymentId, String providerCode, String providerNameThai, String treatmentType, BigDecimal presentedAmt, Date paymentTransferDt, String paymentTransferRemark) {
		this.claimPaymentId = claimPaymentId;
		this.providerCode = providerCode;
		this.providerNameThai = providerNameThai;
		this.treatmentType = treatmentType;
		this.presentedAmt = presentedAmt;
		this.paymentTransferDt = paymentTransferDt;
		this.paymentTransferRemark = paymentTransferRemark;
	}

	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Date getPaymentTransferDt() {
		return paymentTransferDt;
	}

	public void setPaymentTransferDt(Date paymentTransferDt) {
		this.paymentTransferDt = paymentTransferDt;
	}

	public String getPaymentTransferRemark() {
		return paymentTransferRemark;
	}

	public void setPaymentTransferRemark(String paymentTransferRemark) {
		this.paymentTransferRemark = paymentTransferRemark;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getIncidentDt() {
		return incidentDt;
	}

	public void setIncidentDt(Date incidentDt) {
		this.incidentDt = incidentDt;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInvoiceNum() {
		return invoiceNum;
	}

	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public Date getClaimstatusdt() {
		return claimstatusdt;
	}

	public void setClaimstatusdt(Date claimstatusdt) {
		this.claimstatusdt = claimstatusdt;
	}

	public String getEdiInd() {
		return ediInd;
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	

}
