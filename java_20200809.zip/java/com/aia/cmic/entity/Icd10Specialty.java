package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.springframework.data.annotation.CreatedDate;


@Entity
@Table(name = "ICD10SPECIALTY")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ICD10SPECIALTY")
public class Icd10Specialty extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "icd10SpecialtySequence")
	@SequenceGenerator(name = "icd10SpecialtySequence", sequenceName = "s_icd10Specialty")
	@Column(name = "ICD10SPECIALTYID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long icd10SpecialtyId;
	/**
	 */

	@Column(name = "ICD10CODE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10Code;
	/**
	 */

	@Column(name = "CODETYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeType;

	@Column(name = "STRVALUE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String strValue;

	@Column(name = "INTVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal intValue;

	@Column(name = "DATEVALUE")
	@CreatedDate
	Date dateValue;

	public Long getIcd10SpecialtyId() {
		return icd10SpecialtyId;
	}

	public void setIcd10SpecialtyId(Long icd10SpecialtyId) {
		this.icd10SpecialtyId = icd10SpecialtyId;
	}

	public String getIcd10Code() {
		return icd10Code;
	}

	public void setIcd10Code(String icd10Code) {
		this.icd10Code = icd10Code;
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getStrValue() {
		return strValue;
	}

	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	public BigDecimal getIntValue() {
		return intValue;
	}

	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}

	public Date getDateValue() {
		return dateValue;
	}

	public void setDateValue(Date dateValue) {
		this.dateValue = dateValue;
	}

	public void copy(Icd10Specialty that) {
		setIcd10SpecialtyId(that.getIcd10SpecialtyId());
		setIcd10Code(that.getIcd10Code());
		setCodeType(that.getCodeType());
		setStrValue(that.getStrValue());
		setIntValue(that.getIntValue());
		setDateValue(that.getDateValue());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	public String toString() {

		StringBuilder buffer = new StringBuilder();
		buffer.append("icd10SpecialtyId=[").append(icd10SpecialtyId).append("] ");
		buffer.append("icd10Code=[").append(icd10Code).append("] ");
		buffer.append("codeType=[").append(codeType).append("] ");
		buffer.append("strValue=[").append(strValue).append("] ");
		buffer.append("intValue=[").append(intValue).append("] ");
		buffer.append("dateValue=[").append(dateValue).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((icd10SpecialtyId == null) ? 0 : icd10SpecialtyId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Icd10Specialty))
			return false;
		Icd10Specialty equalCheck = (Icd10Specialty) obj;
		if ((icd10SpecialtyId == null && equalCheck.icd10SpecialtyId != null) || (icd10SpecialtyId != null && equalCheck.icd10SpecialtyId == null))
			return false;
		if (icd10SpecialtyId != null && !icd10SpecialtyId.equals(equalCheck.icd10SpecialtyId))
			return false;
		return true;
	}
}
