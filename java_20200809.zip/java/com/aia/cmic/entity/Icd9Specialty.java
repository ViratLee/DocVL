package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@Table(name = "Icd9Specialty")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Icd9Specialty")
public class Icd9Specialty extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "Icd9SpecialtySequence")
	@SequenceGenerator(name = "Icd9SpecialtySequence", sequenceName = "s_Icd9Specialty")
	@Column(name = "Icd9SpecialtyID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long Icd9SpecialtyId;
	/**
	 */

	@Column(name = "ICD9CODE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd9Code;
	/**
	 */
	
	@Column(name = "CODETYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeType;	
	/**
	 */
	
	@Column(name = "STRVALUE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String strValue;
	/**
	 */
	@Column(name = "INTVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal intValue;	
	/**
	 */
	
	@Column(name = "DATEVALUE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dateValue;	

	public Long getIcd9SpecialtyId() {
		return Icd9SpecialtyId;
	}

	public void setIcd9SpecialtyId(Long Icd9SpecialtyId) {
		this.Icd9SpecialtyId = Icd9SpecialtyId;
	}

	public String getIcd9Code() {
		return icd9Code;
	}

	public void setIcd9Code(String icd9Code) {
		this.icd9Code = icd9Code;
	}

	/**
	 * @return the codeType
	 */
	public String getCodeType() {
		return codeType;
	}

	/**
	 * @param codeType the codeType to set
	 */
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	/**
	 * @return the strValue
	 */
	public String getStrValue() {
		return strValue;
	}

	/**
	 * @param strValue the strValue to set
	 */
	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	/**
	 * @return the intValue
	 */
	public BigDecimal getIntValue() {
		return intValue;
	}

	/**
	 * @param intValue the intValue to set
	 */
	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}

	/**
	 * @return the dateValue
	 */
	public Date getDateValue() {
		return dateValue;
	}

	/**
	 * @param dateValue the dateValue to set
	 */
	public void setDateValue(Date dateValue) {
		this.dateValue = dateValue;
	}

	public void copy(Icd9Specialty that) {
		setIcd9SpecialtyId(that.getIcd9SpecialtyId());
		setIcd9Code(that.getIcd9Code());
		setCodeType(that.getCodeType());
		setIntValue(that.getIntValue());
		setStrValue(that.getStrValue());
		setDateValue(that.getDateValue());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	public String toString() {

		StringBuilder buffer = new StringBuilder();
		buffer.append("Icd9SpecialtyId=[").append(Icd9SpecialtyId).append("] ");
		buffer.append("icd9Code=[").append(icd9Code).append("] ");
		buffer.append("codeType=[").append(codeType).append("] ");
		buffer.append("intValue=[").append(intValue).append("] ");
		buffer.append("strValue=[").append(strValue).append("] ");
		buffer.append("dateValue=[").append(dateValue).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((Icd9SpecialtyId == null) ? 0 : Icd9SpecialtyId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Icd9Specialty))
			return false;
		Icd9Specialty equalCheck = (Icd9Specialty) obj;
		if ((Icd9SpecialtyId == null && equalCheck.Icd9SpecialtyId != null) || (Icd9SpecialtyId != null && equalCheck.Icd9SpecialtyId == null))
			return false;
		if (Icd9SpecialtyId != null && !Icd9SpecialtyId.equals(equalCheck.Icd9SpecialtyId))
			return false;
		return true;
	}
}
