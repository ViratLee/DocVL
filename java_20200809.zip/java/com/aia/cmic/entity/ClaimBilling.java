package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;

/**
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimBilling")
public class ClaimBilling extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	//	@Value("${privateKey}")
	//	private final String PRIVATE_KEY = "1234567812345678";

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimSequence")
	@SequenceGenerator(name = "claimSequence", sequenceName = "s_claim")
	@Column(name = "CLAIMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "PREVIOUSCLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String previousClaimNo;
	/**
	 */

	@Column(name = "PREVIOUSOCCURRENCE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer previousOccurrence;
	/**
	 */
	@Column(name = "RECEIVEDDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date receivedDate;
	/**
	 */

	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CERTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String certNo;
	/**
	 */

	@Column(name = "MEMBERID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberId;
	/**
	 */

	@Column(name = "DEPENDENTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dependentNo;
	/**
	 */

	@Column(name = "DEPENDENTTYPE", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dependentType;
	/**
	 */

	@Column(name = "RELATIONSHIP", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String relationship;
	/**
	 */

	@Column(name = "VIP", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String vip;
	/**
	 */

	@Column(name = "CLIENTID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String clientId;
	/**
	 */

	@Column(name = "PARTYID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long partyId;
	/**
	 */

	@Column(name = "MEMBERLASTNAME", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MEMBERLASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberLastName;
	/**
	 */

	@Column(name = "MEMBERFIRSTNAME", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MEMBERFIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberFirstName;
	/**
	 */

	@Column(name = "LASTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(LASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	/**
	 */

	@Column(name = "FIRSTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(FIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	/**
	 */

	@Column(name = "GENDER", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String gender;
	/**
	 */

	@Column(name = "DOB", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(DOB, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dob;
	/**
	 */

	@Column(name = "NATIONALID", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(NATIONALID, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String nationalId;
	/**
	 */

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;
	/**
	 */

	@Column(name = "SUBOFFICESTATUS", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeStatus;
	/**
	 */

	@Column(name = "POLICYHOLDER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyHolder;
	/**
	 */

	@Column(name = "POLICYOWNER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyOwner;
	/**
	 */

	@Column(name = "CHANNEL", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String channel;
	/**
	 */

	@Column(name = "SUBMISSIONTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionType;
	/**
	 */

	@Column(name = "PAYMENTSEQ", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentSeq;
	/**
	 */

	@Column(name = "NOORIGINALBILLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String noOriginalBillInd;

	/**
	 */

	@Column(name = "ORIGINALBILLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String originalBillInd;
	/**
	 */

	@Column(name = "BILLNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billNo;
	/**
	 */
	@Column(name = "BILLDTFROM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date billDtFrom;
	/**
	 */
	@Column(name = "BILLDTTO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date billDtTo;
	/**
	 */

	@Column(name = "AGENCYCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyCodeServicing;
	/**
	 */

	@Column(name = "AGENTCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentCodeServicing;
	/**
	 */

	@Column(name = "AGENCYOFFICECODESERVICING", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyOfficeCodeServicing;
	/**
	 */

	@Column(name = "FASTTRACKAGENCY", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fastTrackAgency;
	/**
	 */

	@Column(name = "BROKERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brokerCode;
	/**
	 */

	@Column(name = "BROKERNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brokerName;
	/**
	 */

	@Column(name = "PAYEEISCOMPANYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeIsCompanyInd;
	/**
	 */

	@Column(name = "PAYMENTMETHOD", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentMethod;
	/**
	 */

	@Column(name = "BILLINGSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingStatus;
	/**
	 */

	/**
	 */
	@Column(name = "BILLINGDECLINEREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingDeclineReason;

	/**
	 */

	@Column(name = "CLASSOFBED", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String classOfBed;
	/**
	 */

	@Column(name = "ROOMTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String roomType;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 13)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "REFERRALDOCTORCODE", length = 13)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorCode;
	/**
	 */

	@Column(name = "REFERRALDOCTORNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorName;
	/**
	 */

	@Column(name = "REFERRALDOCTOREMAIL", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorEmail;
	/**
	 */

	@Column(name = "REFERRALDOCTORPHONE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorPhone;
	/**
	 */

	@Column(name = "REFERRALDOCTORFAX", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorFax;
	/**
	 */

	@Column(name = "PREVDOCTORNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorName;
	/**
	 */

	@Column(name = "PREVDOCTOREMAIL", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorEmail;
	/**
	 */

	@Column(name = "PREVDOCTORPHONE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorPhone;
	/**
	 */

	@Column(name = "PREVDOCTORFAX", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorFax;
	/**
	 */
	@Column(name = "FIRSTCONSULTATIONDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date firstConsultationDt;
	/**
	 */
	@Column(name = "CONSULTATIONDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date consultationDt;
	/**
	 */
	@Column(name = "SYMPTOMDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date symptomDate;
	/**
	 */

	@Column(name = "PHYSICALFINDING", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String physicalFinding;
	/**
	 */

	@Column(name = "CHIEFCOMPLAINT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String chiefComplaint;
	/**
	 */

	@Column(name = "UNDERLYINGCAUSE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String underlyingCause;
	/**
	 */

	@Column(name = "ILLNESSSPECIALCONDITION", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String illnessSpecialCondition;
	/**
	 */

	@Column(name = "DIAGNOSISRESULT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String diagnosisResult;
	/**
	 */

	@Column(name = "PROVISIONALDIAGNOSIS", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String provisionalDiagnosis;
	/**
	 */

	@Column(name = "CONDITIONREQUIREDTREATMENT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String conditionRequiredTreatment;
	/**
	 */

	@Column(name = "PRESENTILLNESS", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String presentIllness;
	/**
	 */

	@Column(name = "TEMPERATURE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal temperature;
	/**
	 */

	@Column(name = "PULSE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal pulse;
	/**
	 */

	@Column(name = "RESPIRATORYRATE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal respiratoryRate;
	/**
	 */

	@Column(name = "SYSTOLIC", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal systolic;
	/**
	 */

	@Column(name = "DIASTOLIC", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal diastolic;
	/**
	 */

	@Column(name = "PAINSCORE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer painScore;
	/**
	 */

	@Column(name = "COMASCORE", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer comaScore;
	/**
	 */

	@Column(name = "WEIGHT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal weight;
	/**
	 */

	@Column(name = "HEIGHT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal height;
	/**
	 */

	@Column(name = "BMI", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal bmi;
	/**
	 */
	@Column(name = "ACCIDENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date accidentDt;
	/**
	 */

	@Column(name = "ACCIDENTPLACE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accidentPlace;
	/**
	 */

	@Column(name = "LEVELOFCONSCIOUSNESS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String levelOfConsciousness;
	/**
	 */

	@Column(name = "CAUSEOFINJURY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfInjury;
	/**
	 */

	@Column(name = "INJURYTYPE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String injuryType;
	/**
	 */

	@Column(name = "ESTIMATEDTIMEOFDISCOVERY", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer estimatedTimeOfDiscovery;
	/**
	 */

	@Column(name = "ESTIMATEDMONTHOFDISCOVERY", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer estimatedMonthOfDiscovery;
	/**
	 */
	@Column(name = "PREVTREATMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date prevTreatmentDate;
	/**
	 */
	@Column(name = "TREATMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date treatmentDate;
	/**
	 */

	@Column(name = "TREATMENTTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String treatmentType;
	/**
	 */

	@Column(name = "CAUSEOFTREATMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfTreatment;
	/**
	 */
	@Column(name = "HOSPITALIZATIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date hospitalizationDate;
	/**
	 */

	@Column(name = "HOSPITALIZATIONREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hospitalizationReason;
	/**
	 */
	@Column(name = "DISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dischargeDate;
	/**
	 */

	@Column(name = "LENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer lengthOfStay;
	/**
	 */
	@Column(name = "ICUADMISSIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuAdmissionDate;
	/**
	 */
	@Column(name = "ICUDISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuDischargeDate;
	/**
	 */

	@Column(name = "ICULENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer icuLengthOfStay;
	/**
	 */

	@Column(name = "ICUREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icuReason;
	/**
	 */

	@Column(name = "OTHERINSURER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String otherInsurer;
	/**
	 */
	@Column(name = "HOMELEAVEFROMDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date homeLeaveFromDate;
	/**
	 */
	@Column(name = "HOMELEAVETODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date homeLeaveToDt;
	/**
	 */

	@Column(name = "HOMELEAVEREASON", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String homeLeaveReason;
	/**
	 */

	@Column(name = "RECONSIDERCASE", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String reconsiderCase;
	/**
	 */

	@Column(name = "DELETEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deleteInd;
	/**
	 */

	@Column(name = "AUTOCLAIMIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String autoClaimInd;
	/**
	 */

	@Column(name = "CPTCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cptCode;
	/**
	 */

	@Column(name = "ASSESSORCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String assessorCode;
	/**
	 */

	@Column(name = "APPROVALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String approvalCode;
	/**
	 */

	@Column(name = "PAYMENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentInd;
	/**
	 */

	@Column(name = "HEALTHCARDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String healthCardInd;
	/**
	 */

	@Column(name = "CARECARDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String careCardInd;
	/**
	 */

	@Column(name = "ONECARDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String oneCardInd;
	/**
	 */

	@Column(name = "CLAIMSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimStatus;

	/**
	 */
	@Column(name = "PROCESSSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String processStatus;

	/**
	 */
	@Column(name = "CLAIMSTATUSDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date claimStatusDt;
	/**
	 */

	@Column(name = "RECEIPTOFREFERRAL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String receiptOfReferral;
	/**
	 */

	@Column(name = "APPEALIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String appealInd;
	/**
	 */

	@Column(name = "EMERGENCYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String emergencyInd;
	/**
	 */

	@Column(name = "DAYOFADMITROOM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfAdmitRoom;
	/**
	 */

	@Column(name = "DAYOFADMITICU")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfAdmitIcu;
	/**
	 */

	@Column(name = "DAYOFCALL")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfCall;

	/**
	 */

	@Column(name = "TOTALDISABILITY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer totalDisability;
	/**
	 */

	@Column(name = "PARTIALDISABILITY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer partialDisability;
	/**
	 */
	@Column(name = "DISABILITYSTARTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date disabilityStartDt;

	/**
	 */
	@Column(name = "DISABILITYENDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date disabilityEndDt;

	/** 
	 */

	@Column(name = "AICODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiCode;

	/**
	 */

	@Column(name = "SURGICALPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgicalPercentage;
	/**
	 */

	@Column(name = "DOUBLEINDEMNITY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doubleIndemnity;
	/**
	 */

	@Column(name = "HOMEMEDICALIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String homeMedicalInd;
	/**
	 */

	@Column(name = "HBPTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hbpType;
	/**
	 */

	@Column(name = "ATTAINEDAGEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String attainedAgeInd;
	/**
	 */

	@Column(name = "ANESTHESIAIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String anesthesiaInd;
	/**
	 */

	@Column(name = "SURGERYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String surgeryInd;
	/**
	 */

	@Column(name = "DISEASEIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String diseaseInd;
	/**
	 */

	@Column(name = "DAYOFADMITJUNIOR")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfAdmitJunior;
	/**
	 */

	@Column(name = "MAJORACCID", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String majorAccId;
	/**
	 */

	@Column(name = "MAJORINJURYDETAIL", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String majorInjuryDetail;
	/**
	 */

	@Column(name = "HBJSURGERYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hbjSurgeryInd;

	/**
	 */

	@Column(name = "SHORTFALLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shortFallInd;

	/**
	 */

	@Column(name = "ORIGCURRENCY", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String origCurrency;
	/**
	 */

	@Column(name = "CONVCURRENCY", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String convCurrency;
	/**
	 */

	@Column(name = "EXCHANGERATEDESC", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exchangeRateDesc;
	/**
	 */

	@Column(name = "TOTALESTIMATEDCOST", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalEstimatedCost;
	/**
	 */

	@Column(name = "TOTALBILLEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalBilledAmt;
	/**
	 */

	@Column(name = "HOLDPAYMENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String holdPaymentInd;
	/**
	 */

	@Column(name = "HOLDPAYMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date holdPaymentDate;
	/**
	 */

	@Column(name = "RELEASEHOLDPAYMENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String releaseHoldPaymentInd;
	/**
	 */

	@Column(name = "RELEASEHOLDPAYMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date releaseHoldPaymentDate;
	/**
	 */

	@Column(name = "PHASE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String phase;
	/**
	 */

	@Column(name = "CASEID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long caseId;
	/**
	 */

	@Column(name = "BATCHNO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String batchNo;

	@Column(name = "EDIIND")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ediInd;
	
	@Column(name = "STPIND")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String stpInd;
	
	@Column(name = "BILLINGSTATUSDESC", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingStatusDesc;

	@Column(name = "BILLINGDELINCEREASONDESC", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingDeclineReasonDesc;

	@Column(name = "ICD10", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10;

	@Column(name = "SETTLEMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date settlementDate;
	
	@Column(name = "AIIND")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiInd;

	@Column(name = "AIBILLINGSTATUS", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiBillingStatus;
	
	@Column(name = "AIBILLINGSTATUSDESC", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiBillingStatusDesc;
	
	@Column(name = "AIBILLINGDECLINEREASON", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiBillingDeclineReason;
	
	@Column(name = "AIBILLINGDELINCEREASONDESC", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiBillingDeclineReasonDesc;
	/**
	 */

	/**
	 */
	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	/**
	 */
	public Long getClaimId() {
		return this.claimId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPreviousClaimNo(String previousClaimNo) {
		this.previousClaimNo = previousClaimNo;
	}

	/**
	 */
	public String getPreviousClaimNo() {
		return this.previousClaimNo;
	}

	/**
	 */
	public void setPreviousOccurrence(Integer previousOccurrence) {
		this.previousOccurrence = previousOccurrence;
	}

	/**
	 */
	public Integer getPreviousOccurrence() {
		return this.previousOccurrence;
	}

	/**
	 */
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	/**
	 */
	public Date getReceivedDate() {
		return this.receivedDate;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	/**
	 */
	public String getCertNo() {
		return this.certNo;
	}

	/**
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 */
	public String getMemberId() {
		return this.memberId;
	}

	/**
	 */
	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	/**
	 */
	public String getDependentNo() {
		return this.dependentNo;
	}

	/**
	 * @return the dependentType
	 */
	public String getDependentType() {
		return dependentType;
	}

	/**
	 * @param dependentType the dependentType to set
	 */
	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	/**
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 */
	public String getRelationship() {
		return this.relationship;
	}

	/**
	 */
	public void setVip(String vip) {
		this.vip = vip;
	}

	/**
	 */
	public String getVip() {
		return this.vip;
	}

	/**
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 */
	public String getClientId() {
		return this.clientId;
	}

	/**
	 */
	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	/**
	 */
	public Long getPartyId() {
		return this.partyId;
	}

	/**
	 * @return the memberLastName
	 */
	public String getMemberLastName() {
		return memberLastName;
	}

	/**
	 * @param memberLastName the memberLastName to set
	 */
	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	/**
	 * @return the memberFirstName
	 */
	public String getMemberFirstName() {
		return memberFirstName;
	}

	/**
	 * @param memberFirstName the memberFirstName to set
	 */
	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	/**
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 */
	public String getGender() {
		return this.gender;
	}

	/**
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 */
	public String getDob() {
		return this.dob;
	}

	/**
	 */
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	/**
	 */
	public String getNationalId() {
		return this.nationalId;
	}

	/**
	 */
	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	/**
	 */
	public String getSubOfficeCode() {
		return this.subOfficeCode;
	}

	/**
	 * @return the subOfficeStatus
	 */
	public String getSubOfficeStatus() {
		return subOfficeStatus;
	}

	/**
	 * @param subOfficeStatus the subOfficeStatus to set
	 */
	public void setSubOfficeStatus(String subOfficeStatus) {
		this.subOfficeStatus = subOfficeStatus;
	}

	/**
	 */
	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	/**
	 */
	public String getPolicyHolder() {
		return this.policyHolder;
	}

	/**
	 */
	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	/**
	 */
	public String getPolicyOwner() {
		return this.policyOwner;
	}

	/**
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 */
	public String getChannel() {
		return this.channel;
	}

	/**
	 */
	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	/**
	 */
	public String getSubmissionType() {
		return this.submissionType;
	}

	/**
	 */
	public void setPaymentSeq(String paymentSeq) {
		this.paymentSeq = paymentSeq;
	}

	/**
	 */
	public String getPaymentSeq() {
		return this.paymentSeq;
	}

	/**
	 * @return the noOriginalBillInd
	 */
	public String getNoOriginalBillInd() {
		return noOriginalBillInd;
	}

	/**
	 * @param noOriginalBillInd the noOriginalBillInd to set
	 */
	public void setNoOriginalBillInd(String noOriginalBillInd) {
		this.noOriginalBillInd = noOriginalBillInd;
	}

	/**
	 */
	public void setOriginalBillInd(String originalBillInd) {
		this.originalBillInd = originalBillInd;
	}

	/**
	 */
	public String getOriginalBillInd() {
		return this.originalBillInd;
	}

	/**
	 * @return the billNo
	 */
	public String getBillNo() {
		return billNo;
	}

	/**
	 * @param billNo the billNo to set
	 */
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	/**
	 */
	public void setBillDtFrom(Date billDtFrom) {
		this.billDtFrom = billDtFrom;
	}

	/**
	 */
	public Date getBillDtFrom() {
		return this.billDtFrom;
	}

	/**
	 */
	public void setBillDtTo(Date billDtTo) {
		this.billDtTo = billDtTo;
	}

	/**
	 */
	public Date getBillDtTo() {
		return this.billDtTo;
	}

	/**
	 */
	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	/**
	 */
	public String getAgencyCodeServicing() {
		return this.agencyCodeServicing;
	}

	/**
	 */
	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	/**
	 */
	public String getAgentCodeServicing() {
		return this.agentCodeServicing;
	}

	public String getAgencyOfficeCodeServicing() {
		return agencyOfficeCodeServicing;
	}

	public void setAgencyOfficeCodeServicing(String agencyOfficeCodeServicing) {
		this.agencyOfficeCodeServicing = agencyOfficeCodeServicing;
	}

	/**
	 * @return the fastTrackAgency
	 */
	public String getFastTrackAgency() {
		return fastTrackAgency;
	}

	/**
	 * @param fastTrackAgency the fastTrackAgency to set
	 */
	public void setFastTrackAgency(String fastTrackAgency) {
		this.fastTrackAgency = fastTrackAgency;
	}

	/**
	 */
	public void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}

	/**
	 */
	public String getBrokerCode() {
		return this.brokerCode;
	}

	/**
	 * @return the brokerName
	 */
	public String getBrokerName() {
		return brokerName;
	}

	/**
	 * @param brokerName the brokerName to set
	 */
	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	/**
	 * @return the payeeIsCompanyInd
	 */
	public String getPayeeIsCompanyInd() {
		return payeeIsCompanyInd;
	}

	/**
	 * @param payeeIsCompanyInd the payeeIsCompanyInd to set
	 */
	public void setPayeeIsCompanyInd(String payeeIsCompanyInd) {
		this.payeeIsCompanyInd = payeeIsCompanyInd;
	}

	/**
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	/**
	 */
	public String getPaymentMethod() {
		return this.paymentMethod;
	}

	/**
	 */
	public void setBillingStatus(String billingStatus) {
		this.billingStatus = billingStatus;
	}

	/**
	 */
	public String getBillingStatus() {
		return this.billingStatus;
	}

	public String getBillingDeclineReason() {
		return billingDeclineReason;
	}

	public void setBillingDeclineReason(String billingDeclineReason) {
		this.billingDeclineReason = billingDeclineReason;
	}

	/**
	 */
	public void setClassOfBed(String classOfBed) {
		this.classOfBed = classOfBed;
	}

	/**
	 */
	public String getClassOfBed() {
		return this.classOfBed;
	}

	/**
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	 */
	public String getRoomType() {
		return this.roomType;
	}

	/**
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 */
	public String getProviderCode() {
		return this.providerCode;
	}

	/**
	 */
	public void setReferralDoctorCode(String referralDoctorCode) {
		this.referralDoctorCode = referralDoctorCode;
	}

	/**
	 */
	public String getReferralDoctorCode() {
		return this.referralDoctorCode;
	}

	/**
	 */
	public void setReferralDoctorName(String referralDoctorName) {
		this.referralDoctorName = referralDoctorName;
	}

	/**
	 */
	public String getReferralDoctorName() {
		return this.referralDoctorName;
	}

	/**
	 */
	public void setReferralDoctorEmail(String referralDoctorEmail) {
		this.referralDoctorEmail = referralDoctorEmail;
	}

	/**
	 */
	public String getReferralDoctorEmail() {
		return this.referralDoctorEmail;
	}

	/**
	 */
	public void setReferralDoctorPhone(String referralDoctorPhone) {
		this.referralDoctorPhone = referralDoctorPhone;
	}

	/**
	 */
	public String getReferralDoctorPhone() {
		return this.referralDoctorPhone;
	}

	/**
	 */
	public void setReferralDoctorFax(String referralDoctorFax) {
		this.referralDoctorFax = referralDoctorFax;
	}

	/**
	 */
	public String getReferralDoctorFax() {
		return this.referralDoctorFax;
	}

	/**
	 */
	public void setPrevDoctorName(String prevDoctorName) {
		this.prevDoctorName = prevDoctorName;
	}

	/**
	 */
	public String getPrevDoctorName() {
		return this.prevDoctorName;
	}

	/**
	 */
	public void setPrevDoctorEmail(String prevDoctorEmail) {
		this.prevDoctorEmail = prevDoctorEmail;
	}

	/**
	 */
	public String getPrevDoctorEmail() {
		return this.prevDoctorEmail;
	}

	/**
	 */
	public void setPrevDoctorPhone(String prevDoctorPhone) {
		this.prevDoctorPhone = prevDoctorPhone;
	}

	/**
	 */
	public String getPrevDoctorPhone() {
		return this.prevDoctorPhone;
	}

	/**
	 */
	public void setPrevDoctorFax(String prevDoctorFax) {
		this.prevDoctorFax = prevDoctorFax;
	}

	/**
	 */
	public String getPrevDoctorFax() {
		return this.prevDoctorFax;
	}

	/**
	 */
	public void setFirstConsultationDt(Date firstConsultationDt) {
		this.firstConsultationDt = firstConsultationDt;
	}

	/**
	 */
	public Date getFirstConsultationDt() {
		return this.firstConsultationDt;
	}

	/**
	 */
	public void setConsultationDt(Date consultationDt) {
		this.consultationDt = consultationDt;
	}

	/**
	 */
	public Date getConsultationDt() {
		return this.consultationDt;
	}

	/**
	 */
	public void setSymptomDate(Date symptomDate) {
		this.symptomDate = symptomDate;
	}

	/**
	 */
	public Date getSymptomDate() {
		return this.symptomDate;
	}

	/**
	 */
	public void setPhysicalFinding(String physicalFinding) {
		this.physicalFinding = physicalFinding;
	}

	/**
	 */
	public String getPhysicalFinding() {
		return this.physicalFinding;
	}

	/**
	 */
	public void setChiefComplaint(String chiefComplaint) {
		this.chiefComplaint = chiefComplaint;
	}

	/**
	 */
	public String getChiefComplaint() {
		return this.chiefComplaint;
	}

	/**
	 */
	public void setUnderlyingCause(String underlyingCause) {
		this.underlyingCause = underlyingCause;
	}

	/**
	 */
	public String getUnderlyingCause() {
		return this.underlyingCause;
	}

	/**
	 */
	public void setIllnessSpecialCondition(String illnessSpecialCondition) {
		this.illnessSpecialCondition = illnessSpecialCondition;
	}

	/**
	 */
	public String getIllnessSpecialCondition() {
		return this.illnessSpecialCondition;
	}

	/**
	 */
	public void setDiagnosisResult(String diagnosisResult) {
		this.diagnosisResult = diagnosisResult;
	}

	/**
	 */
	public String getDiagnosisResult() {
		return this.diagnosisResult;
	}

	/**
	 */
	public void setProvisionalDiagnosis(String provisionalDiagnosis) {
		this.provisionalDiagnosis = provisionalDiagnosis;
	}

	/**
	 */
	public String getProvisionalDiagnosis() {
		return this.provisionalDiagnosis;
	}

	/**
	 */
	public void setConditionRequiredTreatment(String conditionRequiredTreatment) {
		this.conditionRequiredTreatment = conditionRequiredTreatment;
	}

	/**
	 */
	public String getConditionRequiredTreatment() {
		return this.conditionRequiredTreatment;
	}

	/**
	 * @return the presentIllness
	 */
	public String getPresentIllness() {
		return presentIllness;
	}

	/**
	 * @param presentIllness the presentIllness to set
	 */
	public void setPresentIllness(String presentIllness) {
		this.presentIllness = presentIllness;
	}

	/**
	 */
	public void setTemperature(BigDecimal temperature) {
		this.temperature = temperature;
	}

	/**
	 */
	public BigDecimal getTemperature() {
		return this.temperature;
	}

	/**
	 */
	public void setPulse(BigDecimal pulse) {
		this.pulse = pulse;
	}

	/**
	 */
	public BigDecimal getPulse() {
		return this.pulse;
	}

	/**
	 */
	public void setRespiratoryRate(BigDecimal respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}

	/**
	 */
	public BigDecimal getRespiratoryRate() {
		return this.respiratoryRate;
	}

	/**
	 */
	public void setSystolic(BigDecimal systolic) {
		this.systolic = systolic;
	}

	/**
	 */
	public BigDecimal getSystolic() {
		return this.systolic;
	}

	/**
	 */
	public void setDiastolic(BigDecimal diastolic) {
		this.diastolic = diastolic;
	}

	/**
	 */
	public BigDecimal getDiastolic() {
		return this.diastolic;
	}

	/**
	 */
	public void setPainScore(Integer painScore) {
		this.painScore = painScore;
	}

	/**
	 */
	public Integer getPainScore() {
		return this.painScore;
	}

	/**
	 */
	public void setComaScore(Integer comaScore) {
		this.comaScore = comaScore;
	}

	/**
	 */
	public Integer getComaScore() {
		return this.comaScore;
	}

	/**
	 */
	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	/**
	 */
	public BigDecimal getWeight() {
		return this.weight;
	}

	/**
	 */
	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	/**
	 */
	public BigDecimal getHeight() {
		return this.height;
	}

	/**
	 */
	public void setBmi(BigDecimal bmi) {
		this.bmi = bmi;
	}

	/**
	 */
	public BigDecimal getBmi() {
		return this.bmi;
	}

	/**
	 */
	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	/**
	 */
	public Date getAccidentDt() {
		return this.accidentDt;
	}

	/**
	 */
	public void setAccidentPlace(String accidentPlace) {
		this.accidentPlace = accidentPlace;
	}

	/**
	 */
	public String getAccidentPlace() {
		return this.accidentPlace;
	}

	/**
	 */
	public void setLevelOfConsciousness(String levelOfConsciousness) {
		this.levelOfConsciousness = levelOfConsciousness;
	}

	/**
	 */
	public String getLevelOfConsciousness() {
		return this.levelOfConsciousness;
	}

	/**
	 */
	public void setCauseOfInjury(String causeOfInjury) {
		this.causeOfInjury = causeOfInjury;
	}

	/**
	 */
	public String getCauseOfInjury() {
		return this.causeOfInjury;
	}

	/**
	 */
	public void setInjuryType(String injuryType) {
		this.injuryType = injuryType;
	}

	/**
	 */
	public String getInjuryType() {
		return this.injuryType;
	}

	/**
	 */
	public void setEstimatedTimeOfDiscovery(Integer estimatedTimeOfDiscovery) {
		this.estimatedTimeOfDiscovery = estimatedTimeOfDiscovery;
	}

	/**
	 */
	public Integer getEstimatedTimeOfDiscovery() {
		return this.estimatedTimeOfDiscovery;
	}

	/**
	 * @return the estimatedMonthOfDiscovery
	 */
	public Integer getEstimatedMonthOfDiscovery() {
		return estimatedMonthOfDiscovery;
	}

	/**
	 * @param estimatedMonthOfDiscovery the estimatedMonthOfDiscovery to set
	 */
	public void setEstimatedMonthOfDiscovery(Integer estimatedMonthOfDiscovery) {
		this.estimatedMonthOfDiscovery = estimatedMonthOfDiscovery;
	}

	/**
	 */
	public void setPrevTreatmentDate(Date prevTreatmentDate) {
		this.prevTreatmentDate = prevTreatmentDate;
	}

	/**
	 */
	public Date getPrevTreatmentDate() {
		return this.prevTreatmentDate;
	}

	/**
	 */
	public void setTreatmentDate(Date treatmentDate) {
		this.treatmentDate = treatmentDate;
	}

	/**
	 */
	public Date getTreatmentDate() {
		return this.treatmentDate;
	}

	/**
	 */
	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	/**
	 */
	public String getTreatmentType() {
		return this.treatmentType;
	}

	/**
	 */
	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	/**
	 */
	public String getCauseOfTreatment() {
		return this.causeOfTreatment;
	}

	/**
	 */
	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	/**
	 */
	public Date getHospitalizationDate() {
		return this.hospitalizationDate;
	}

	/**
	 */
	public void setHospitalizationReason(String hospitalizationReason) {
		this.hospitalizationReason = hospitalizationReason;
	}

	/**
	 */
	public String getHospitalizationReason() {
		return this.hospitalizationReason;
	}

	/**
	 */
	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	/**
	 */
	public Date getDischargeDate() {
		return this.dischargeDate;
	}

	/**
	 */
	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	/**
	 */
	public Integer getLengthOfStay() {
		return this.lengthOfStay;
	}

	/**
	 */
	public void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}

	/**
	 */
	public Date getIcuAdmissionDate() {
		return this.icuAdmissionDate;
	}

	/**
	 */
	public void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}

	/**
	 */
	public Date getIcuDischargeDate() {
		return this.icuDischargeDate;
	}

	/**
	 */
	public void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}

	/**
	 */
	public Integer getIcuLengthOfStay() {
		return this.icuLengthOfStay;
	}

	/**
	 */
	public void setIcuReason(String icuReason) {
		this.icuReason = icuReason;
	}

	/**
	 */
	public String getIcuReason() {
		return this.icuReason;
	}

	/**
	 */
	public void setOtherInsurer(String otherInsurer) {
		this.otherInsurer = otherInsurer;
	}

	/**
	 */
	public String getOtherInsurer() {
		return this.otherInsurer;
	}

	/**
	 */
	public void setHomeLeaveFromDate(Date homeLeaveFromDate) {
		this.homeLeaveFromDate = homeLeaveFromDate;
	}

	/**
	 */
	public Date getHomeLeaveFromDate() {
		return this.homeLeaveFromDate;
	}

	/**
	 */
	public void setHomeLeaveToDt(Date homeLeaveToDt) {
		this.homeLeaveToDt = homeLeaveToDt;
	}

	/**
	 */
	public Date getHomeLeaveToDt() {
		return this.homeLeaveToDt;
	}

	/**
	 */
	public void setHomeLeaveReason(String homeLeaveReason) {
		this.homeLeaveReason = homeLeaveReason;
	}

	/**
	 */
	public String getHomeLeaveReason() {
		return this.homeLeaveReason;
	}

	/**
	 */
	public void setReconsiderCase(String reconsiderCase) {
		this.reconsiderCase = reconsiderCase;
	}

	/**
	 */
	public String getReconsiderCase() {
		return this.reconsiderCase;
	}

	/**
	 */
	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}

	/**
	 */
	public String getDeleteInd() {
		return this.deleteInd;
	}

	/**
	 */
	public void setAutoClaimInd(String autoClaimInd) {
		this.autoClaimInd = autoClaimInd;
	}

	/**
	 */
	public String getAutoClaimInd() {
		return this.autoClaimInd;
	}

	/**
	 */
	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	/**
	 */
	public String getCptCode() {
		return this.cptCode;
	}

	/**
	 */
	public void setAssessorCode(String assessorCode) {
		this.assessorCode = assessorCode;
	}

	/**
	 */
	public String getAssessorCode() {
		return this.assessorCode;
	}

	/**
	 * @return the approvalCode
	 */
	public String getApprovalCode() {
		return approvalCode;
	}

	/**
	 * @param approvalCode the approvalCode to set
	 */
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	/**
	 */
	public void setPaymentInd(String paymentInd) {
		this.paymentInd = paymentInd;
	}

	/**
	 */
	public String getPaymentInd() {
		return this.paymentInd;
	}

	/**
	 */
	public void setHealthCardInd(String healthCardInd) {
		this.healthCardInd = healthCardInd;
	}

	/**
	 */
	public String getHealthCardInd() {
		return this.healthCardInd;
	}

	/**
	 */
	public void setCareCardInd(String careCardInd) {
		this.careCardInd = careCardInd;
	}

	/**
	 */
	public String getCareCardInd() {
		return this.careCardInd;
	}

	/**
	 */
	public void setOneCardInd(String oneCardInd) {
		this.oneCardInd = oneCardInd;
	}

	/**
	 */
	public String getOneCardInd() {
		return this.oneCardInd;
	}

	/**
	 */
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	/**
	 */
	public String getClaimStatus() {
		return this.claimStatus;
	}

	/**
	 * @return the processStatus
	 */
	public String getProcessStatus() {
		return processStatus;
	}

	/**
	 * @param processStatus the processStatus to set
	 */
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	/**
	 */
	public void setClaimStatusDt(Date claimStatusDt) {
		this.claimStatusDt = claimStatusDt;
	}

	/**
	 */
	public Date getClaimStatusDt() {
		return this.claimStatusDt;
	}

	/**
	 */
	public void setReceiptOfReferral(String receiptOfReferral) {
		this.receiptOfReferral = receiptOfReferral;
	}

	/**
	 */
	public String getReceiptOfReferral() {
		return this.receiptOfReferral;
	}

	/**
	 */
	public void setAppealInd(String appealInd) {
		this.appealInd = appealInd;
	}

	/**
	 */
	public String getAppealInd() {
		return this.appealInd;
	}

	/**
	 */
	public void setEmergencyInd(String emergencyInd) {
		this.emergencyInd = emergencyInd;
	}

	/**
	 */
	public String getEmergencyInd() {
		return this.emergencyInd;
	}

	/**
	 */
	public void setDayOfAdmitRoom(Integer dayOfAdmitRoom) {
		this.dayOfAdmitRoom = dayOfAdmitRoom;
	}

	/**
	 */
	public Integer getDayOfAdmitRoom() {
		return this.dayOfAdmitRoom;
	}

	/**
	 */
	public void setDayOfAdmitIcu(Integer dayOfAdmitIcu) {
		this.dayOfAdmitIcu = dayOfAdmitIcu;
	}

	/**
	 */
	public Integer getDayOfAdmitIcu() {
		return this.dayOfAdmitIcu;
	}

	/**
	 */
	public void setDayOfCall(Integer dayOfCall) {
		this.dayOfCall = dayOfCall;
	}

	/**
	 */
	public Integer getDayOfCall() {
		return this.dayOfCall;
	}

	/**
	 */
	public void setTotalDisability(Integer totalDisability) {
		this.totalDisability = totalDisability;
	}

	/**
	 */
	public Integer getTotalDisability() {
		return this.totalDisability;
	}

	/**
	 */
	public void setPartialDisability(Integer partialDisability) {
		this.partialDisability = partialDisability;
	}

	/**
	 */
	public Integer getPartialDisability() {
		return this.partialDisability;
	}

	/**
	 */
	public void setDisabilityStartDt(Date disabilityStartDt) {
		this.disabilityStartDt = disabilityStartDt;
	}

	/**
	 */
	public Date getDisabilityStartDt() {
		return this.disabilityStartDt;
	}

	/**
	 */
	public void setDisabilityEndDt(Date disabilityEndDt) {
		this.disabilityEndDt = disabilityEndDt;
	}

	/**
	 */
	public Date getDisabilityEndDt() {
		return this.disabilityEndDt;
	}

	/**
	 */
	public String getAiCode() {
		return aiCode;
	}

	/**
	 */
	public void setAiCode(String aiCode) {
		this.aiCode = aiCode;
	}

	/**
	 */
	public void setSurgicalPercentage(BigDecimal surgicalPercentage) {
		this.surgicalPercentage = surgicalPercentage;
	}

	/**
	 */
	public BigDecimal getSurgicalPercentage() {
		return this.surgicalPercentage;
	}

	/**
	 */
	public void setDoubleIndemnity(String doubleIndemnity) {
		this.doubleIndemnity = doubleIndemnity;
	}

	/**
	 */
	public String getDoubleIndemnity() {
		return this.doubleIndemnity;
	}

	/**
	 */
	public void setHomeMedicalInd(String homeMedicalInd) {
		this.homeMedicalInd = homeMedicalInd;
	}

	/**
	 */
	public String getHomeMedicalInd() {
		return this.homeMedicalInd;
	}

	/**
	 */
	public void setHbpType(String hbpType) {
		this.hbpType = hbpType;
	}

	/**
	 */
	public String getHbpType() {
		return this.hbpType;
	}

	/**
	 */
	public void setAttainedAgeInd(String attainedAgeInd) {
		this.attainedAgeInd = attainedAgeInd;
	}

	/**
	 */
	public String getAttainedAgeInd() {
		return this.attainedAgeInd;
	}

	/**
	 */
	public void setAnesthesiaInd(String anesthesiaInd) {
		this.anesthesiaInd = anesthesiaInd;
	}

	/**
	 */
	public String getAnesthesiaInd() {
		return this.anesthesiaInd;
	}

	/**
	 */
	public void setSurgeryInd(String surgeryInd) {
		this.surgeryInd = surgeryInd;
	}

	/**
	 */
	public String getSurgeryInd() {
		return this.surgeryInd;
	}

	/**
	 */
	public void setDiseaseInd(String diseaseInd) {
		this.diseaseInd = diseaseInd;
	}

	/**
	 */
	public String getDiseaseInd() {
		return this.diseaseInd;
	}

	/**
	 */
	public void setDayOfAdmitJunior(Integer dayOfAdmitJunior) {
		this.dayOfAdmitJunior = dayOfAdmitJunior;
	}

	/**
	 */
	public Integer getDayOfAdmitJunior() {
		return this.dayOfAdmitJunior;
	}

	/**
	 */
	public void setMajorAccId(String majorAccId) {
		this.majorAccId = majorAccId;
	}

	/**
	 */
	public String getMajorAccId() {
		return this.majorAccId;
	}

	/**
	 */
	public void setMajorInjuryDetail(String majorInjuryDetail) {
		this.majorInjuryDetail = majorInjuryDetail;
	}

	/**
	 */
	public String getMajorInjuryDetail() {
		return this.majorInjuryDetail;
	}

	/**
	 */
	public void setHbjSurgeryInd(String hbjSurgeryInd) {
		this.hbjSurgeryInd = hbjSurgeryInd;
	}

	/**
	 */
	public String getHbjSurgeryInd() {
		return this.hbjSurgeryInd;
	}

	/**
	 */
	public void setShortFallInd(String shortFallInd) {
		this.shortFallInd = shortFallInd;
	}

	/**
	 */
	public String getShortFallInd() {
		return this.shortFallInd;
	}

	/**
	 */
	public void setOrigCurrency(String origCurrency) {
		this.origCurrency = origCurrency;
	}

	/**
	 */
	public String getOrigCurrency() {
		return this.origCurrency;
	}

	/**
	 * @return the convCurrency
	 */
	public String getConvCurrency() {
		return convCurrency;
	}

	/**
	 * @param convCurrency the convCurrency to set
	 */
	public void setConvCurrency(String convCurrency) {
		this.convCurrency = convCurrency;
	}

	/**
	 */
	public void setExchangeRateDesc(String exchangeRateDesc) {
		this.exchangeRateDesc = exchangeRateDesc;
	}

	/**
	 */
	public String getExchangeRateDesc() {
		return this.exchangeRateDesc;
	}

	/**
	 */
	public void setTotalEstimatedCost(BigDecimal totalEstimatedCost) {
		this.totalEstimatedCost = totalEstimatedCost;
	}

	/**
	 */
	public BigDecimal getTotalEstimatedCost() {
		return this.totalEstimatedCost;
	}

	/**
	 */
	public void setTotalBilledAmt(BigDecimal totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

	/**
	 */
	public BigDecimal getTotalBilledAmt() {
		return this.totalBilledAmt;
	}

	/**
	 */
	public void setHoldPaymentInd(String holdPaymentInd) {
		this.holdPaymentInd = holdPaymentInd;
	}

	/**
	 */
	public void setPhase(String phase) {
		this.phase = phase;
	}

	public Date getHoldPaymentDate() {
		return holdPaymentDate;
	}

	public void setHoldPaymentDate(Date holdPaymentDate) {
		this.holdPaymentDate = holdPaymentDate;
	}

	public String getReleaseHoldPaymentInd() {
		return releaseHoldPaymentInd;
	}

	public void setReleaseHoldPaymentInd(String releaseHoldPaymentInd) {
		this.releaseHoldPaymentInd = releaseHoldPaymentInd;
	}

	public Date getReleaseHoldPaymentDate() {
		return releaseHoldPaymentDate;
	}

	public void setReleaseHoldPaymentDate(Date releaseHoldPaymentDate) {
		this.releaseHoldPaymentDate = releaseHoldPaymentDate;
	}

	public String getHoldPaymentInd() {
		return holdPaymentInd;
	}

	/**
	 */
	public String getPhase() {
		return this.phase;
	}

	/**
	 */
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 */
	public Long getCaseId() {
		return this.caseId;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getBillingStatusDesc() {
		return billingStatusDesc;
	}

	public void setBillingStatusDesc(String billingStatusDesc) {
		this.billingStatusDesc = billingStatusDesc;
	}

	public String getBillingDeclineReasonDesc() {
		return billingDeclineReasonDesc;
	}

	public void setBillingDeclineReasonDesc(String billingDeclineReasonDesc) {
		this.billingDeclineReasonDesc = billingDeclineReasonDesc;
	}

	public String getIcd10() {
		return icd10;
	}

	public void setIcd10(String icd10) {
		this.icd10 = icd10;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	
	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}
		
	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}
	
	public String getAiInd() {
		return aiInd;
	}

	public void setAiInd(String aiInd) {
		this.aiInd = aiInd;
	}


	public String getAiBillingStatus() {
		return aiBillingStatus;
	}

	public String getAiBillingStatusDesc() {
		return aiBillingStatusDesc;
	}

	public String getAiBillingDeclineReason() {
		return aiBillingDeclineReason;
	}

	public String getAiBillingDeclineReasonDesc() {
		return aiBillingDeclineReasonDesc;
	}

	public void setAiBillingStatus(String aiBillingStatus) {
		this.aiBillingStatus = aiBillingStatus;
	}

	public void setAiBillingStatusDesc(String aiBillingStatusDesc) {
		this.aiBillingStatusDesc = aiBillingStatusDesc;
	}

	public void setAiBillingDeclineReason(String aiBillingDeclineReason) {
		this.aiBillingDeclineReason = aiBillingDeclineReason;
	}

	public void setAiBillingDeclineReasonDesc(String aiBillingDeclineReasonDesc) {
		this.aiBillingDeclineReasonDesc = aiBillingDeclineReasonDesc;
	}

	/**
	 */
	public ClaimBilling() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimBilling that) {
		setClaimId(that.getClaimId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPreviousClaimNo(that.getPreviousClaimNo());
		setPreviousOccurrence(that.getPreviousOccurrence());
		setReceivedDate(that.getReceivedDate());
		setPolicyNo(that.getPolicyNo());
		setCompanyId(that.getCompanyId());
		setCertNo(that.getCertNo());
		setMemberId(that.getMemberId());
		setDependentNo(that.getDependentNo());
		setDependentType(that.getDependentType());
		setRelationship(that.getRelationship());
		setVip(that.getVip());
		setClientId(that.getClientId());
		setPartyId(that.getPartyId());
		setMemberLastName(that.getMemberLastName());
		setMemberFirstName(that.getMemberFirstName());
		setLastName(that.getLastName());
		setFirstName(that.getFirstName());
		setGender(that.getGender());
		setDob(that.getDob());
		setNationalId(that.getNationalId());
		setSubOfficeCode(that.getSubOfficeCode());
		setSubOfficeStatus(that.getSubOfficeStatus());
		setPolicyHolder(that.getPolicyHolder());
		setPolicyOwner(that.getPolicyOwner());
		setChannel(that.getChannel());
		setSubmissionType(that.getSubmissionType());
		setPaymentSeq(that.getPaymentSeq());
		setOriginalBillInd(that.getOriginalBillInd());
		setBillNo(that.getBillNo());
		setBillDtFrom(that.getBillDtFrom());
		setBillDtTo(that.getBillDtTo());
		setAgencyCodeServicing(that.getAgencyCodeServicing());
		setAgentCodeServicing(that.getAgentCodeServicing());
		setFastTrackAgency(that.getFastTrackAgency());
		setBrokerCode(that.getBrokerCode());
		setBrokerName(that.getBrokerName());
		setPayeeIsCompanyInd(that.getPayeeIsCompanyInd());
		setPaymentMethod(that.getPaymentMethod());
		setBillingStatus(that.getBillingStatus());
		setBillingDeclineReason(that.getBillingDeclineReason());
		setClassOfBed(that.getClassOfBed());
		setRoomType(that.getRoomType());
		setProviderCode(that.getProviderCode());
		setReferralDoctorCode(that.getReferralDoctorCode());
		setReferralDoctorName(that.getReferralDoctorName());
		setReferralDoctorEmail(that.getReferralDoctorEmail());
		setReferralDoctorPhone(that.getReferralDoctorPhone());
		setReferralDoctorFax(that.getReferralDoctorFax());
		setPrevDoctorName(that.getPrevDoctorName());
		setPrevDoctorEmail(that.getPrevDoctorEmail());
		setPrevDoctorPhone(that.getPrevDoctorPhone());
		setPrevDoctorFax(that.getPrevDoctorFax());
		setFirstConsultationDt(that.getFirstConsultationDt());
		setConsultationDt(that.getConsultationDt());
		setSymptomDate(that.getSymptomDate());
		setPhysicalFinding(that.getPhysicalFinding());
		setChiefComplaint(that.getChiefComplaint());
		setUnderlyingCause(that.getUnderlyingCause());
		setIllnessSpecialCondition(that.getIllnessSpecialCondition());
		setDiagnosisResult(that.getDiagnosisResult());
		setProvisionalDiagnosis(that.getProvisionalDiagnosis());
		setConditionRequiredTreatment(that.getConditionRequiredTreatment());
		setPresentIllness(that.getPresentIllness());
		setTemperature(that.getTemperature());
		setPulse(that.getPulse());
		setRespiratoryRate(that.getRespiratoryRate());
		setSystolic(that.getSystolic());
		setDiastolic(that.getDiastolic());
		setPainScore(that.getPainScore());
		setComaScore(that.getComaScore());
		setWeight(that.getWeight());
		setHeight(that.getHeight());
		setBmi(that.getBmi());
		setAccidentDt(that.getAccidentDt());
		setAccidentPlace(that.getAccidentPlace());
		setLevelOfConsciousness(that.getLevelOfConsciousness());
		setCauseOfInjury(that.getCauseOfInjury());
		setInjuryType(that.getInjuryType());
		setEstimatedTimeOfDiscovery(that.getEstimatedTimeOfDiscovery());
		setEstimatedMonthOfDiscovery(that.getEstimatedMonthOfDiscovery());
		setPrevTreatmentDate(that.getPrevTreatmentDate());
		setTreatmentDate(that.getTreatmentDate());
		setTreatmentType(that.getTreatmentType());
		setCauseOfTreatment(that.getCauseOfTreatment());
		setHospitalizationDate(that.getHospitalizationDate());
		setHospitalizationReason(that.getHospitalizationReason());
		setDischargeDate(that.getDischargeDate());
		setLengthOfStay(that.getLengthOfStay());
		setIcuAdmissionDate(that.getIcuAdmissionDate());
		setIcuDischargeDate(that.getIcuDischargeDate());
		setIcuLengthOfStay(that.getIcuLengthOfStay());
		setIcuReason(that.getIcuReason());
		setOtherInsurer(that.getOtherInsurer());
		setHomeLeaveFromDate(that.getHomeLeaveFromDate());
		setHomeLeaveToDt(that.getHomeLeaveToDt());
		setHomeLeaveReason(that.getHomeLeaveReason());
		setReconsiderCase(that.getReconsiderCase());
		setDeleteInd(that.getDeleteInd());
		setAutoClaimInd(that.getAutoClaimInd());
		setCptCode(that.getCptCode());
		setAssessorCode(that.getAssessorCode());
		setApprovalCode(that.getApprovalCode());
		setPaymentInd(that.getPaymentInd());
		setHealthCardInd(that.getHealthCardInd());
		setCareCardInd(that.getCareCardInd());
		setOneCardInd(that.getOneCardInd());
		setClaimStatus(that.getClaimStatus());
		setProcessStatus(that.getProcessStatus());
		setClaimStatusDt(that.getClaimStatusDt());
		setReceiptOfReferral(that.getReceiptOfReferral());
		setAppealInd(that.getAppealInd());
		setEmergencyInd(that.getEmergencyInd());
		setDayOfAdmitRoom(that.getDayOfAdmitRoom());
		setDayOfAdmitIcu(that.getDayOfAdmitIcu());
		setTotalDisability(that.getTotalDisability());
		setPartialDisability(that.getPartialDisability());
		setAiCode(that.getAiCode());
		setSurgicalPercentage(that.getSurgicalPercentage());
		setDoubleIndemnity(that.getDoubleIndemnity());
		setHomeMedicalInd(that.getHomeMedicalInd());
		setHbpType(that.getHbpType());
		setAttainedAgeInd(that.getAttainedAgeInd());
		setAnesthesiaInd(that.getAnesthesiaInd());
		setSurgeryInd(that.getSurgeryInd());
		setDiseaseInd(that.getDiseaseInd());
		setDayOfAdmitJunior(that.getDayOfAdmitJunior());
		setMajorAccId(that.getMajorAccId());
		setMajorInjuryDetail(that.getMajorInjuryDetail());
		setOrigCurrency(that.getOrigCurrency());
		setAgencyOfficeCodeServicing(that.getAgencyOfficeCodeServicing());
		setExchangeRateDesc(that.getExchangeRateDesc());
		setTotalEstimatedCost(that.getTotalEstimatedCost());
		setTotalBilledAmt(that.getTotalBilledAmt());
		setHoldPaymentInd(that.getHoldPaymentInd());
		setHoldPaymentDate(that.getHoldPaymentDate());
		setReleaseHoldPaymentInd(that.getReleaseHoldPaymentInd());
		setReleaseHoldPaymentDate(that.getReleaseHoldPaymentDate());
		setPhase(that.getPhase());
		setCaseId(that.getCaseId());
		setBatchNo(that.getBatchNo());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setIcd10(that.getIcd10());
		setSettlementDate(that.getSettlementDate());
		setEdiInd(that.getEdiInd());
		setStpInd(that.getStpInd());
		setAiInd(that.getAiInd());
		setAiBillingStatus(that.getAiBillingStatus());
		setAiBillingStatusDesc(that.getAiBillingStatusDesc());
		setAiBillingDeclineReason(that.getBillingDeclineReasonDesc());
		setAiBillingDeclineReasonDesc(that.getAiBillingDeclineReasonDesc());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimId=[").append(claimId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("previousClaimNo=[").append(previousClaimNo).append("] ");
		buffer.append("previousOccurrence=[").append(previousOccurrence).append("] ");
		buffer.append("receivedDate=[").append(receivedDate).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("certNo=[").append(certNo).append("] ");
		buffer.append("memberId=[").append(memberId).append("] ");
		buffer.append("dependentNo=[").append(dependentNo).append("] ");
		buffer.append("dependentType=[").append(dependentType).append("] ");
		buffer.append("relationship=[").append(relationship).append("] ");
		buffer.append("vip=[").append(vip).append("] ");
		buffer.append("clientId=[").append(clientId).append("] ");
		buffer.append("partyId=[").append(partyId).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("gender=[").append(gender).append("] ");
		buffer.append("dob=[").append(dob).append("] ");
		buffer.append("nationalId=[").append(nationalId).append("] ");
		buffer.append("subOfficeCode=[").append(subOfficeCode).append("] ");
		buffer.append("subOfficeStatus=[").append(subOfficeStatus).append("] ");
		buffer.append("policyHolder=[").append(policyHolder).append("] ");
		buffer.append("policyOwner=[").append(policyOwner).append("] ");
		buffer.append("channel=[").append(channel).append("] ");
		buffer.append("submissionType=[").append(submissionType).append("] ");
		buffer.append("paymentSeq=[").append(paymentSeq).append("] ");
		buffer.append("originalBillInd=[").append(originalBillInd).append("] ");
		buffer.append("billNo=[").append(billNo).append("] ");
		buffer.append("billDtFrom=[").append(billDtFrom).append("] ");
		buffer.append("billDtTo=[").append(billDtTo).append("] ");
		buffer.append("agencyCodeServicing=[").append(agencyCodeServicing).append("] ");
		buffer.append("agentCodeServicing=[").append(agentCodeServicing).append("] ");
		buffer.append("fastTrackAgency=[").append(fastTrackAgency).append("] ");
		buffer.append("brokerCode=[").append(brokerCode).append("] ");
		buffer.append("brokerName=[").append(brokerName).append("] ");
		buffer.append("payeeIsCompanyInd=[").append(payeeIsCompanyInd).append("] ");
		buffer.append("paymentMethod=[").append(paymentMethod).append("] ");
		buffer.append("billingStatus=[").append(billingStatus).append("] ");
		buffer.append("billingDeclineReason=[").append(billingDeclineReason).append("] ");
		buffer.append("classOfBed=[").append(classOfBed).append("] ");
		buffer.append("roomType=[").append(roomType).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("referralDoctorCode=[").append(referralDoctorCode).append("] ");
		buffer.append("referralDoctorName=[").append(referralDoctorName).append("] ");
		buffer.append("referralDoctorEmail=[").append(referralDoctorEmail).append("] ");
		buffer.append("referralDoctorPhone=[").append(referralDoctorPhone).append("] ");
		buffer.append("referralDoctorFax=[").append(referralDoctorFax).append("] ");
		buffer.append("prevDoctorName=[").append(prevDoctorName).append("] ");
		buffer.append("prevDoctorEmail=[").append(prevDoctorEmail).append("] ");
		buffer.append("prevDoctorPhone=[").append(prevDoctorPhone).append("] ");
		buffer.append("prevDoctorFax=[").append(prevDoctorFax).append("] ");
		buffer.append("firstConsultationDt=[").append(firstConsultationDt).append("] ");
		buffer.append("consultationDt=[").append(consultationDt).append("] ");
		buffer.append("symptomDate=[").append(symptomDate).append("] ");
		buffer.append("physicalFinding=[").append(physicalFinding).append("] ");
		buffer.append("chiefComplaint=[").append(chiefComplaint).append("] ");
		buffer.append("underlyingCause=[").append(underlyingCause).append("] ");
		buffer.append("illnessSpecialCondition=[").append(illnessSpecialCondition).append("] ");
		buffer.append("diagnosisResult=[").append(diagnosisResult).append("] ");
		buffer.append("provisionalDiagnosis=[").append(provisionalDiagnosis).append("] ");
		buffer.append("conditionRequiredTreatment=[").append(conditionRequiredTreatment).append("] ");
		buffer.append("presentIllness=[").append(presentIllness).append("] ");
		buffer.append("temperature=[").append(temperature).append("] ");
		buffer.append("pulse=[").append(pulse).append("] ");
		buffer.append("respiratoryRate=[").append(respiratoryRate).append("] ");
		buffer.append("systolic=[").append(systolic).append("] ");
		buffer.append("diastolic=[").append(diastolic).append("] ");
		buffer.append("painScore=[").append(painScore).append("] ");
		buffer.append("comaScore=[").append(comaScore).append("] ");
		buffer.append("weight=[").append(weight).append("] ");
		buffer.append("height=[").append(height).append("] ");
		buffer.append("bmi=[").append(bmi).append("] ");
		buffer.append("accidentDt=[").append(accidentDt).append("] ");
		buffer.append("accidentPlace=[").append(accidentPlace).append("] ");
		buffer.append("levelOfConsciousness=[").append(levelOfConsciousness).append("] ");
		buffer.append("causeOfInjury=[").append(causeOfInjury).append("] ");
		buffer.append("injuryType=[").append(injuryType).append("] ");
		buffer.append("estimatedMonthOfDiscovery=[").append(estimatedMonthOfDiscovery).append("] ");
		buffer.append("estimatedTimeOfDiscovery=[").append(estimatedTimeOfDiscovery).append("] ");
		buffer.append("prevTreatmentDate=[").append(prevTreatmentDate).append("] ");
		buffer.append("treatmentDate=[").append(treatmentDate).append("] ");
		buffer.append("treatmentType=[").append(treatmentType).append("] ");
		buffer.append("causeOfTreatment=[").append(causeOfTreatment).append("] ");
		buffer.append("hospitalizationDate=[").append(hospitalizationDate).append("] ");
		buffer.append("hospitalizationReason=[").append(hospitalizationReason).append("] ");
		buffer.append("dischargeDate=[").append(dischargeDate).append("] ");
		buffer.append("lengthOfStay=[").append(lengthOfStay).append("] ");
		buffer.append("icuAdmissionDate=[").append(icuAdmissionDate).append("] ");
		buffer.append("icuDischargeDate=[").append(icuDischargeDate).append("] ");
		buffer.append("icuLengthOfStay=[").append(icuLengthOfStay).append("] ");
		buffer.append("icuReason=[").append(icuReason).append("] ");
		buffer.append("otherInsurer=[").append(otherInsurer).append("] ");
		buffer.append("homeLeaveFromDate=[").append(homeLeaveFromDate).append("] ");
		buffer.append("homeLeaveToDt=[").append(homeLeaveToDt).append("] ");
		buffer.append("homeLeaveReason=[").append(homeLeaveReason).append("] ");
		buffer.append("reconsiderCase=[").append(reconsiderCase).append("] ");
		buffer.append("deleteInd=[").append(deleteInd).append("] ");
		buffer.append("autoClaimInd=[").append(autoClaimInd).append("] ");
		buffer.append("cptCode=[").append(cptCode).append("] ");
		buffer.append("assessorCode=[").append(assessorCode).append("] ");
		buffer.append("paymentInd=[").append(paymentInd).append("] ");
		buffer.append("healthCardInd=[").append(healthCardInd).append("] ");
		buffer.append("careCardInd=[").append(careCardInd).append("] ");
		buffer.append("oneCardInd=[").append(oneCardInd).append("] ");
		buffer.append("claimStatus=[").append(claimStatus).append("] ");
		buffer.append("processStatus=[").append(processStatus).append("] ");
		buffer.append("claimStatusDt=[").append(claimStatusDt).append("] ");
		buffer.append("receiptOfReferral=[").append(receiptOfReferral).append("] ");
		buffer.append("appealInd=[").append(appealInd).append("] ");
		buffer.append("emergencyInd=[").append(emergencyInd).append("] ");
		buffer.append("dayOfAdmitRoom=[").append(dayOfAdmitRoom).append("] ");
		buffer.append("dayOfAdmitIcu=[").append(dayOfAdmitIcu).append("] ");
		buffer.append("totalDisability=[").append(totalDisability).append("] ");
		buffer.append("partialDisability=[").append(partialDisability).append("] ");
		buffer.append("surgicalPercentage=[").append(surgicalPercentage).append("] ");
		buffer.append("doubleIndemnity=[").append(doubleIndemnity).append("] ");
		buffer.append("homeMedicalInd=[").append(homeMedicalInd).append("] ");
		buffer.append("hbpType=[").append(hbpType).append("] ");
		buffer.append("attainedAgeInd=[").append(attainedAgeInd).append("] ");
		buffer.append("anesthesiaInd=[").append(anesthesiaInd).append("] ");
		buffer.append("surgeryInd=[").append(surgeryInd).append("] ");
		buffer.append("diseaseInd=[").append(diseaseInd).append("] ");
		buffer.append("dayOfAdmitJunior=[").append(dayOfAdmitJunior).append("] ");
		buffer.append("majorAccId=[").append(majorAccId).append("] ");
		buffer.append("majorInjuryDetail=[").append(majorInjuryDetail).append("] ");
		buffer.append("origCurrency=[").append(origCurrency).append("] ");
		buffer.append("agencyOfficeCodeServicing=[").append(agencyOfficeCodeServicing).append("] ");
		buffer.append("exchangeRateDesc=[").append(exchangeRateDesc).append("] ");
		buffer.append("totalEstimatedCost=[").append(totalEstimatedCost).append("] ");
		buffer.append("totalBilledAmt=[").append(totalBilledAmt).append("] ");
		buffer.append("holdPaymentInd=[").append(holdPaymentInd).append("] ");
		buffer.append("holdPaymentDate=[").append(holdPaymentDate).append("] ");
		buffer.append("releaseHoldPaymentInd=[").append(releaseHoldPaymentInd).append("] ");
		buffer.append("releaseHoldPaymentDate=[").append(releaseHoldPaymentDate).append("] ");
		buffer.append("phase=[").append(phase).append("] ");
		buffer.append("caseId=[").append(caseId).append("] ");
		buffer.append("batchNo=[").append(batchNo).append("] ");
		buffer.append("icd10=[").append(icd10).append("] ");
		buffer.append("ediInd=[").append(ediInd).append("] ");
		buffer.append("stpInd=[").append(stpInd).append("] ");
		buffer.append("aiInd=[").append(aiInd).append("] ");
		buffer.append("aiBillingStatus=[").append(aiBillingStatus).append("] ");
		buffer.append("aiBillingStatusDesc=[").append(aiBillingStatusDesc).append("] ");
		buffer.append("aiBillingDeclineReason=[").append(aiBillingDeclineReason).append("] ");
		buffer.append("aiBillingDeclineReasonDesc=[").append(aiBillingDeclineReasonDesc).append("] ");
		
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimId == null) ? 0 : claimId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimBilling))
			return false;
		ClaimBilling equalCheck = (ClaimBilling) obj;
		if ((claimId == null && equalCheck.claimId != null) || (claimId != null && equalCheck.claimId == null))
			return false;
		if (claimId != null && !claimId.equals(equalCheck.claimId))
			return false;
		return true;
	}
}
