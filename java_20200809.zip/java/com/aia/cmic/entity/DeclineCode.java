package com.aia.cmic.entity;

import java.util.Date;

public class DeclineCode {
	private String declineCode;
	private String declineDescLong;
	private String declineDescLongThai;
	private String declineDescShort;
	private String declineInd;
	private String createdBy;
	private Date createdDt;
	private String lastModifiedBy;
	private Date lastModifiedDt;

}
