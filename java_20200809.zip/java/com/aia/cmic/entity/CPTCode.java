
package com.aia.cmic.entity;

import java.io.Serializable;

import java.lang.StringBuilder;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllCPTCodes", query = "select myCPTCode from CPTCode myCPTCode"),
		@NamedQuery(name = "findCPTCodeByCptCodeField", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptCode = ?1"),
		@NamedQuery(name = "findCPTCodeByCptCodeFieldContaining", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptCode like ?1"),
		@NamedQuery(name = "findCPTCodeByCptDesc", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptDesc = ?1"),
		@NamedQuery(name = "findCPTCodeByCptDescContaining", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptDesc like ?1"),
		@NamedQuery(name = "findCPTCodeByCptDescThai", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptDescThai = ?1"),
		@NamedQuery(name = "findCPTCodeByCptDescThaiContaining", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptDescThai like ?1"),
		@NamedQuery(name = "findCPTCodeByPrimaryKey", query = "select myCPTCode from CPTCode myCPTCode where myCPTCode.cptCode = ?1") })

@Table(name = "CPTCODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "CPTCode")

public class CPTCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "CPTCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String cptCode;
	/**
	 */

	@Column(name = "CPTDESC")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cptDesc;
	/**
	 */

	@Column(name = "CPTDESCTHAI", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cptDescThai;
	/**
	 */

	@Column(name = "SORTING", length = 3, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sorting;


	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	/**
	 * @return the cptDesc
	 */
	public String getCptDesc() {
		return cptDesc;
	}

	/**
	 * @param cptDesc the cptDesc to set
	 */
	public void setCptDesc(String cptDesc) {
		this.cptDesc = cptDesc;
	}

	/**
	 * @return the cptDescThai
	 */
	public String getCptDescThai() {
		return cptDescThai;
	}

	/**
	 * @param cptDescThai the cptDescThai to set
	 */
	public void setCptDescThai(String cptDescThai) {
		this.cptDescThai = cptDescThai;
	}

	public Integer getSorting() {
		return sorting;
	}

	public void setSorting(Integer sorting) {
		this.sorting = sorting;
	}

	/**
	 */
	public CPTCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CPTCode that) {
		setCptCode(that.getCptCode());
		setCptDesc(that.getCptDesc());
		setCptDescThai(that.getCptDescThai());
		setSorting(that.getSorting());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("cptCode=[").append(cptCode).append("] ");
		buffer.append("cptDesc=[").append(cptDesc).append("] ");
		buffer.append("cptDescThai=[").append(cptDescThai).append("] ");
		buffer.append("sorting=[").append(sorting).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((cptCode == null) ? 0 : cptCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CPTCode))
			return false;
		CPTCode equalCheck = (CPTCode) obj;
		if ((cptCode == null && equalCheck.cptCode != null) || (cptCode != null && equalCheck.cptCode == null))
			return false;
		if (cptCode != null && !cptCode.equals(equalCheck.cptCode))
			return false;
		return true;
	}
}
