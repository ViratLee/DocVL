package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllServiceItems", query = "select myServiceItem from ServiceItem myServiceItem"),
		@NamedQuery(name = "findServiceItemByDefaultInd", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.defaultInd = ?1"),
		//		@NamedQuery(name = "findServiceItemByParentServiceItemId", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.parentServiceItemiId = ?1"),
		//		@NamedQuery(name = "findServiceItemByParentServiceItemIdContaining", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.parentServiceItemiId like ?1"),
		@NamedQuery(name = "findServiceItemByPrimaryKey", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemId = ?1"),
		@NamedQuery(name = "findServiceItemByServiceCatId", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceCatId = ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceCatIdContaining", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceCatId like ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceItemDesc", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemDesc = ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceItemDescContaining", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemDesc like ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceItemDescThai", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemDescThai = ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceItemDescThaiContaining", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemDescThai like ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceItemId", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemId = ?1"),
		//		@NamedQuery(name = "findServiceItemByServiceItemIdContaining", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceItemId like ?1"),
		@NamedQuery(name = "findServiceItemByFieldContaining", query = "select myServiceItem from ServiceItem myServiceItem where UPPER(myServiceItem.serviceCatId) like ?1 or UPPER(myServiceItem.serviceItemDesc) like ?2 or UPPER(myServiceItem.serviceItemDescThai) like ?3"),
		@NamedQuery(name = "findServiceItemByDefaultContractInd", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.defaultContractInd = ?1"),
		@NamedQuery(name = "findServiceItemByHSBillInd", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.serviceCatId = ?1 and ( myServiceItem.hsBillInd='Y' or myServiceItem.hsBillInd='y' ) "),
		@NamedQuery(name = "findServiceItemByHcBillInd", query = "select myServiceItem from ServiceItem myServiceItem where myServiceItem.hcBillInd='Y' ") })
@Table(name = "SERVICEITEM")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ServiceItem")
public class ServiceItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "serviceItemSequence")
	@SequenceGenerator(name = "serviceItemSequence", sequenceName = "s_serviceItemSequence")
	@Column(name = "SERVICEITEMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long serviceItemId;

	/**
	 */

	@Column(name = "SERVICECATID", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceCatId;
	/**
	 */

	@Column(name = "SERVICEITEMDESC", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceItemDesc;
	/**
	 */

	@Column(name = "SERVICEITEMDESCTHAI")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceItemDescThai;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "PARENTSERVICEITEMID", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String parentServiceItemiId;

	@Column(name = "DEFAULTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String defaultInd;

	@Column(name = "DEFAULTCONTRACTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String defaultContractInd;

	@Column(name = "HSBILLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hsBillInd;

	@Column(name = "HCBILLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hcBillInd;

	@Column(name = "SEQNO", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer seqNo;
	/**
	 */

	/**
	 * @return the serviceItemId
	 */
	public Long getServiceItemId() {
		return serviceItemId;
	}

	/**
	 * @param serviceItemId the serviceItemId to set
	 */
	public void setServiceItemId(Long serviceItemId) {
		this.serviceItemId = serviceItemId;
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return serviceCatId;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the serviceItemDesc
	 */
	public String getServiceItemDesc() {
		return serviceItemDesc;
	}

	/**
	 * @param serviceItemDesc the serviceItemDesc to set
	 */
	public void setServiceItemDesc(String serviceItemDesc) {
		this.serviceItemDesc = serviceItemDesc;
	}

	/**
	 * @return the serviceItemDescThai
	 */
	public String getServiceItemDescThai() {
		return serviceItemDescThai;
	}

	/**
	 * @param serviceItemDescThai the serviceItemDescThai to set
	 */
	public void setServiceItemDescThai(String serviceItemDescThai) {
		this.serviceItemDescThai = serviceItemDescThai;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the parentServiceItemiId
	 */
	public String getParentServiceItemiId() {
		return parentServiceItemiId;
	}

	/**
	 * @param parentServiceItemiId the parentServiceItemiId to set
	 */
	public void setParentServiceItemiId(String parentServiceItemiId) {
		this.parentServiceItemiId = parentServiceItemiId;
	}

	public String getDefaultInd() {
		return defaultInd;
	}

	public void setDefaultInd(String defaultInd) {
		this.defaultInd = defaultInd;
	}

	public String getDefaultContractInd() {
		return defaultContractInd;
	}

	public void setDefaultContractInd(String defaultContractInd) {
		this.defaultContractInd = defaultContractInd;
	}

	public String getHsBillInd() {
		return hsBillInd;
	}

	public void setHsBillInd(String hsBillInd) {
		this.hsBillInd = hsBillInd;
	}

	public String getHcBillInd() {
		return hcBillInd;
	}

	public void setHcBillInd(String hcBillInd) {
		this.hcBillInd = hcBillInd;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 */
	public ServiceItem() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ServiceItem that) {
		setServiceItemId(that.getServiceItemId());
		setServiceCatId(that.getServiceCatId());
		setSeqNo(that.getSeqNo());
		setServiceItemDesc(that.getServiceItemDesc());
		setServiceItemDescThai(that.getServiceItemDescThai());
		setCompanyId(that.getCompanyId());
		setParentServiceItemiId(that.getParentServiceItemiId());
		setDefaultInd(that.getDefaultInd());
		setDefaultContractInd(that.getDefaultContractInd());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("serviceItemId=[").append(serviceItemId).append("] ");
		buffer.append("serviceCatId=[").append(serviceCatId).append("] ");
		buffer.append("serviceItemDesc=[").append(serviceItemDesc).append("] ");
		buffer.append("serviceItemDescThai=[").append(serviceItemDescThai).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("parentServiceItemiId=[").append(parentServiceItemiId).append("] ");
		buffer.append("defaultInd=[").append(defaultInd).append("] ");
		buffer.append("defaultContractInd=[").append(defaultContractInd).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((serviceItemId == null) ? 0 : serviceItemId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ServiceItem))
			return false;
		ServiceItem equalCheck = (ServiceItem) obj;
		if ((serviceItemId == null && equalCheck.serviceItemId != null) || (serviceItemId != null && equalCheck.serviceItemId == null))
			return false;
		if (serviceItemId != null && !serviceItemId.equals(equalCheck.serviceItemId))
			return false;
		return true;
	}
}
