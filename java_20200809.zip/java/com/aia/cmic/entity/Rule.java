package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * The persistent class for the "RULE" database table.
 * 
 */
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@Table(name = "RULE")
public class Rule extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ruleSequence")
	@SequenceGenerator(name = "ruleSequence", sequenceName = "s_rule")
	@Column(name = "RULEID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	private long ruleid;
	/**
	 */

	@Column(name = "RULENO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruleno;
	/**
	 */

	@Column(name = "RULETOPIC", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruletopic;
	/**
	 */

	@Column(name = "RULESUBJECT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String rulesubject;
	/**
	 */

	@Column(name = "DECISION", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String decision;
	/**
	 */

	@Column(name = "RULEDESC", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruledesc;
	/**
	 */

	@Column(name = "RULEDESCTHAI", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruledescthai;
	/**
	 */

	@Column(name = "RULEDESCLONG", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruledesclong;
	/**
	 */

	@Column(name = "RULEDESCLONGTHAI", length = 500, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruledesclongthai;
	/**
	 */

	@Column(name = "RISKLEVEL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String risklevel;

	public long getRuleid() {
		return ruleid;
	}

	public void setRuleid(long ruleid) {
		this.ruleid = ruleid;
	}

	public String getRuleno() {
		return ruleno;
	}

	public void setRuleno(String ruleno) {
		this.ruleno = ruleno;
	}

	public String getRuletopic() {
		return ruletopic;
	}

	public void setRuletopic(String ruletopic) {
		this.ruletopic = ruletopic;
	}

	public String getRulesubject() {
		return rulesubject;
	}

	public void setRulesubject(String rulesubject) {
		this.rulesubject = rulesubject;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getRuledesc() {
		return ruledesc;
	}

	public void setRuledesc(String ruledesc) {
		this.ruledesc = ruledesc;
	}

	public String getRuledescthai() {
		return ruledescthai;
	}

	public void setRuledescthai(String ruledescthai) {
		this.ruledescthai = ruledescthai;
	}

	public String getRuledesclong() {
		return ruledesclong;
	}

	public void setRuledesclong(String ruledesclong) {
		this.ruledesclong = ruledesclong;
	}

	public String getRuledesclongthai() {
		return ruledesclongthai;
	}

	public void setRuledesclongthai(String ruledesclongthai) {
		this.ruledesclongthai = ruledesclongthai;
	}

	public String getRisklevel() {
		return risklevel;
	}

	public void setRisklevel(String risklevel) {
		this.risklevel = risklevel;
	}

}