package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllNetworks", query = "select myNetwork from Network myNetwork"),
		@NamedQuery(name = "findNetworkByEffectiveFromDt", query = "select myNetwork from Network myNetwork where myNetwork.effectiveFromDt = ?1"),
		@NamedQuery(name = "findNetworkByEffectiveToDt", query = "select myNetwork from Network myNetwork where myNetwork.effectiveToDt = ?1"),
		@NamedQuery(name = "findNetworkByNetworkId", query = "select myNetwork from Network myNetwork where myNetwork.networkId = ?1"),
		@NamedQuery(name = "findNetworkByNetworkName", query = "select myNetwork from Network myNetwork where myNetwork.networkName = ?1"),
		@NamedQuery(name = "findNetworkByNetworkNameContaining", query = "select myNetwork from Network myNetwork where UPPER(myNetwork.networkName) like ?1"),
		@NamedQuery(name = "findNetworkByPrimaryKey", query = "select myNetwork from Network myNetwork where myNetwork.networkId = ?1") })
@Table(name = "NETWORK")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Network")
public class Network extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "networkSequence")
	@SequenceGenerator(name = "networkSequence", sequenceName = "s_network")
	@Column(name = "NETWORKID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long networkId;
	/**
	 */

	@Column(name = "NETWORKNAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String networkName;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */
	@Column(name = "EFFECTIVEFROMDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveFromDt;
	/**
	 */

	@Column(name = "EFFECTIVETODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveToDt;

	/**
	 */

	/**
	 * @return the networkId
	 */
	public Long getNetworkId() {
		return networkId;
	}

	/**
	 * @param networkId the networkId to set
	 */
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	/**
	 * @return the networkName
	 */
	public String getNetworkName() {
		return networkName;
	}

	/**
	 * @param networkName the networkName to set
	 */
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 * @return the effectiveFromDt
	 */
	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	/**
	 * @param effectiveFromDt the effectiveFromDt to set
	 */
	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	/**
	 * @return the effectiveToDt
	 */
	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	/**
	 * @param effectiveToDt the effectiveToDt to set
	 */
	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	/**
	 */
	public Network() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Network that) {
		setNetworkId(that.getNetworkId());
		setNetworkName(that.getNetworkName());
		setCompanyId(that.getCompanyId());
		setEffectiveFromDt(that.getEffectiveFromDt());
		setEffectiveToDt(that.getEffectiveToDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("networkId=[").append(networkId).append("] ");
		buffer.append("networkName=[").append(networkName).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("effectiveFromDt=[").append(effectiveFromDt).append("] ");
		buffer.append("effectiveToDt=[").append(effectiveToDt).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((networkId == null) ? 0 : networkId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Network))
			return false;
		Network equalCheck = (Network) obj;
		if ((networkId == null && equalCheck.networkId != null) || (networkId != null && equalCheck.networkId == null))
			return false;
		if (networkId != null && !networkId.equals(equalCheck.networkId))
			return false;
		return true;
	}
}
