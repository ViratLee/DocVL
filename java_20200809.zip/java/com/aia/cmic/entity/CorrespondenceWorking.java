package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCorrespondenceWorkings", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine1", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine1 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine1Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine1 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine2", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine2 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine2Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine2 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine3", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine3 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine3Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine3 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine4", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine4 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByAddressLine4Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.addressLine4 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByBranchName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.branchName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByBranchNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.branchName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByChequeAmt", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.chequeAmt = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByChequeDate", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.chequeDate = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByClaimArea", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.claimArea = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByClaimAreaContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.claimArea like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByClaimId", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.claimId = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByClaimIdContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.claimId like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByCorrType", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.corrType = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByCorrTypeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.corrType like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByCorrWorkingId", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.corrWorkingId = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByCoverageNameThai", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.coverageNameThai = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByCoverageNameThaiContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.coverageNameThai like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine1", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine1 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine1Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine1 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine2", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine2 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine2Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine2 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine3", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine3 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine3Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine3 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine4", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine4 = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamaddressLine4Containing", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famaddressLine4 like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamFirstName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famFirstName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamFirstNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famFirstName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamLastName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famLastName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamLastNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famLastName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamTitle", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famTitle = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFamTitleContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.famTitle like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFormId", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.formId = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByFormIdContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.formId like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByInsuredFirstName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.insuredFirstName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByInsuredFirstNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.insuredFirstName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByInsuredLastName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.insuredLastName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByInsuredLastNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.insuredLastName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByInsuredtitle", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.insuredtitle = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByInsuredtitleContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.insuredtitle like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPayeeFirstName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.payeeFirstName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPayeeFirstNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.payeeFirstName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPayeeLastName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.payeeLastName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPayeeLastNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.payeeLastName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPayeeTitle", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.payeeTitle = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPayeeTitleContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.payeeTitle like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPolicyNo", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.policyNo = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPolicyNoContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.policyNo like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPolicyNoList", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.policyNoList = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPolicyNoListContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.policyNoList like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByPrimaryKey", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.corrWorkingId = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgencyCode", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgencyCode = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgencyCodeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgencyCode like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgencyName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgencyName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgencyNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgencyName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgentCode", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgentCode = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgentCodeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgentCode like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgentName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgentName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingAgentNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingAgentName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingGaOfficeCode", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingGaOfficeCode = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingGaOfficeCodeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingGaOfficeCode like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingGaOfficeName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingGaOfficeName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByServicingGaOfficeNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.servicingGaOfficeName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgencyCode", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgencyCode = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgencyCodeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgencyCode like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgencyName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgencyName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgencyNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgencyName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgentCode", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgentCode = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgentCodeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgentCode like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgentName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgentName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionAgentNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionAgentName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionGaOfficeCode", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionGaOfficeCode = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionGaOfficeCodeContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionGaOfficeCode like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionGaOfficeName", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionGaOfficeName = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingBySubmissionGaOfficeNameContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.submissionGaOfficeName like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByTotalClaimPaidAmt", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.totalClaimPaidAmt = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByUserDept", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.userDept = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByUserDeptContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.userDept like ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByUserId", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.userId = ?1"),
		@NamedQuery(name = "findCorrespondenceWorkingByUserIdContaining", query = "select myCorrespondenceWorking from CorrespondenceWorking myCorrespondenceWorking where myCorrespondenceWorking.userId like ?1") })
@Table(name = "CORRESPONDENCEWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "CorrespondenceWorking")
public class CorrespondenceWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "correspondenceWorkingSequence")
	@SequenceGenerator(name = "correspondenceWorkingSequence", sequenceName = "s_correspondenceworking")
	@Column(name = "CORRWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long corrWorkingId;
	/**
	 */

	@Column(name = "CLAIMID", length = 8, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long claimId;
	/**
	 */

	@Column(name = "COMPANYID", length = 3, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "FORMID", length = 8, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String formId;
	/**
	 */

	@Column(name = "CLAIMAREA", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimArea;
	/**
	 */

	@Column(name = "CORRTYPE", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String corrType;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	
	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	
	/**
	 */
	
	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "USERID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String userId;
	/**
	 */

	@Column(name = "USERDEPT", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String userDept;
	/**
	 */

	@Column(name = "PAYEETITLE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTitle;
	/**
	 */

	@Column(name = "PAYEELASTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeLastName;
	/**
	 */

	@Column(name = "PAYEEFIRSTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeFirstName;
	/**
	 */

	@Column(name = "ADDRESSLINE1")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;
	/**
	 */

	@Column(name = "ADDRESSLINE2")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;
	/**
	 */

	@Column(name = "ADDRESSLINE3")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;
	/**
	 */

	@Column(name = "ADDRESSLINE4")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;
	/**
	 */

	@Column(name = "FAMTITLE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famTitle;
	/**
	 */

	@Column(name = "FAMLASTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famLastName;
	/**
	 */

	@Column(name = "FAMFIRSTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famFirstName;
	/**
	 */

	@Column(name = "FAMADDRESSLINE1")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famaddressLine1;
	/**
	 */

	@Column(name = "FAMADDRESSLINE2")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famaddressLine2;
	/**
	 */

	@Column(name = "FAMADDRESSLINE3")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famaddressLine3;
	/**
	 */

	@Column(name = "FAMADDRESSLINE4")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String famaddressLine4;
	/**
	 */

	@Column(name = "POLICYNOLIST")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNoList;
	/**
	 */

	@Column(name = "INSUREDTITLE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredtitle;
	/**
	 */

	@Column(name = "INSUREDLASTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredLastName;
	/**
	 */

	@Column(name = "INSUREDFIRSTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredFirstName;
	/**
	 */

	@Column(name = "COVERAGENAMETHAI", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String coverageNameThai;
	/**
	 */

	@Column(name = "TOTALCLAIMPAIDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalClaimPaidAmt;
	/**
	 */

	@Column(name = "BRANCHNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String branchName;
	/**
	 */
	@Column(name = "CHEQUEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date chequeDate;
	/**
	 */

	@Column(name = "CHEQUEAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal chequeAmt;
	/**
	 */

	@Column(name = "SUBMISSIONAGENTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionAgentCode;
	/**
	 */

	@Column(name = "SUBMISSIONAGENTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionAgentName;
	/**
	 */

	@Column(name = "SUBMISSIONAGENCYCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionAgencyCode;
	/**
	 */

	@Column(name = "SUBMISSIONAGENCYNAME", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionAgencyName;
	/**
	 */

	@Column(name = "SUBMISSIONGAOFFICECODE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionGaOfficeCode;
	/**
	 */

	@Column(name = "SUBMISSIONGAOFFICENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionGaOfficeName;
	/**
	 */

	@Column(name = "SERVICINGAGENTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgentCode;
	/**
	 */

	@Column(name = "SERVICINGAGENTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgentName;
	/**
	 */

	@Column(name = "SERVICINGAGENCYCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyCode;
	/**
	 */

	@Column(name = "SERVICINGAGENCYNAME", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyName;
	/**
	 */

	@Column(name = "SERVICINGGAOFFICECODE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaOfficeCode;
	/**
	 */

	@Column(name = "SERVICINGGAOFFICENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaOfficeName;

	/**
	 */
	public void setCorrWorkingId(Long corrWorkingId) {
		this.corrWorkingId = corrWorkingId;
	}

	/**
	 */
	public Long getCorrWorkingId() {
		return this.corrWorkingId;
	}

	/**
	 */
	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	/**
	 */
	public Long getClaimId() {
		return this.claimId;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setFormId(String formId) {
		this.formId = formId;
	}

	/**
	 */
	public String getFormId() {
		return this.formId;
	}

	/**
	 */
	public void setClaimArea(String claimArea) {
		this.claimArea = claimArea;
	}

	/**
	 */
	public String getClaimArea() {
		return this.claimArea;
	}

	/**
	 */
	public void setCorrType(String corrType) {
		this.corrType = corrType;
	}

	/**
	 */
	public String getCorrType() {
		return this.corrType;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	
	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 */
	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}

	/**
	 */
	public String getUserDept() {
		return this.userDept;
	}

	/**
	 */
	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	/**
	 */
	public String getPayeeTitle() {
		return this.payeeTitle;
	}

	/**
	 */
	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	/**
	 */
	public String getPayeeLastName() {
		return this.payeeLastName;
	}

	/**
	 */
	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	/**
	 */
	public String getPayeeFirstName() {
		return this.payeeFirstName;
	}

	/**
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 */
	public String getAddressLine1() {
		return this.addressLine1;
	}

	/**
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 */
	public String getAddressLine2() {
		return this.addressLine2;
	}

	/**
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 */
	public String getAddressLine3() {
		return this.addressLine3;
	}

	/**
	 */
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	/**
	 */
	public String getAddressLine4() {
		return this.addressLine4;
	}

	/**
	 */
	public void setFamTitle(String famTitle) {
		this.famTitle = famTitle;
	}

	/**
	 */
	public String getFamTitle() {
		return this.famTitle;
	}

	/**
	 */
	public void setFamLastName(String famLastName) {
		this.famLastName = famLastName;
	}

	/**
	 */
	public String getFamLastName() {
		return this.famLastName;
	}

	/**
	 */
	public void setFamFirstName(String famFirstName) {
		this.famFirstName = famFirstName;
	}

	/**
	 */
	public String getFamFirstName() {
		return this.famFirstName;
	}

	/**
	 */
	public void setFamaddressLine1(String famaddressLine1) {
		this.famaddressLine1 = famaddressLine1;
	}

	/**
	 */
	public String getFamaddressLine1() {
		return this.famaddressLine1;
	}

	/**
	 */
	public void setFamaddressLine2(String famaddressLine2) {
		this.famaddressLine2 = famaddressLine2;
	}

	/**
	 */
	public String getFamaddressLine2() {
		return this.famaddressLine2;
	}

	/**
	 */
	public void setFamaddressLine3(String famaddressLine3) {
		this.famaddressLine3 = famaddressLine3;
	}

	/**
	 */
	public String getFamaddressLine3() {
		return this.famaddressLine3;
	}

	/**
	 */
	public void setFamaddressLine4(String famaddressLine4) {
		this.famaddressLine4 = famaddressLine4;
	}

	/**
	 */
	public String getFamaddressLine4() {
		return this.famaddressLine4;
	}

	/**
	 */
	public void setPolicyNoList(String policyNoList) {
		this.policyNoList = policyNoList;
	}

	/**
	 */
	public String getPolicyNoList() {
		return this.policyNoList;
	}

	/**
	 */
	public void setInsuredtitle(String insuredtitle) {
		this.insuredtitle = insuredtitle;
	}

	/**
	 */
	public String getInsuredtitle() {
		return this.insuredtitle;
	}

	/**
	 */
	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	/**
	 */
	public String getInsuredLastName() {
		return this.insuredLastName;
	}

	/**
	 */
	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	/**
	 */
	public String getInsuredFirstName() {
		return this.insuredFirstName;
	}

	/**
	 */
	public void setCoverageNameThai(String coverageNameThai) {
		this.coverageNameThai = coverageNameThai;
	}

	/**
	 */
	public String getCoverageNameThai() {
		return this.coverageNameThai;
	}

	/**
	 */
	public void setTotalClaimPaidAmt(BigDecimal totalClaimPaidAmt) {
		this.totalClaimPaidAmt = totalClaimPaidAmt;
	}

	/**
	 */
	public BigDecimal getTotalClaimPaidAmt() {
		return this.totalClaimPaidAmt;
	}

	/**
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	/**
	 */
	public String getBranchName() {
		return this.branchName;
	}

	/**
	 */
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}

	/**
	 */
	public Date getChequeDate() {
		return this.chequeDate;
	}

	/**
	 */
	public void setChequeAmt(BigDecimal chequeAmt) {
		this.chequeAmt = chequeAmt;
	}

	/**
	 */
	public BigDecimal getChequeAmt() {
		return this.chequeAmt;
	}

	/**
	 */
	public void setSubmissionAgentCode(String submissionAgentCode) {
		this.submissionAgentCode = submissionAgentCode;
	}

	/**
	 */
	public String getSubmissionAgentCode() {
		return this.submissionAgentCode;
	}

	/**
	 */
	public void setSubmissionAgentName(String submissionAgentName) {
		this.submissionAgentName = submissionAgentName;
	}

	/**
	 */
	public String getSubmissionAgentName() {
		return this.submissionAgentName;
	}

	/**
	 */
	public void setSubmissionAgencyCode(String submissionAgencyCode) {
		this.submissionAgencyCode = submissionAgencyCode;
	}

	/**
	 */
	public String getSubmissionAgencyCode() {
		return this.submissionAgencyCode;
	}

	/**
	 */
	public void setSubmissionAgencyName(String submissionAgencyName) {
		this.submissionAgencyName = submissionAgencyName;
	}

	/**
	 */
	public String getSubmissionAgencyName() {
		return this.submissionAgencyName;
	}

	/**
	 */
	public void setSubmissionGaOfficeCode(String submissionGaOfficeCode) {
		this.submissionGaOfficeCode = submissionGaOfficeCode;
	}

	/**
	 */
	public String getSubmissionGaOfficeCode() {
		return this.submissionGaOfficeCode;
	}

	/**
	 */
	public void setSubmissionGaOfficeName(String submissionGaOfficeName) {
		this.submissionGaOfficeName = submissionGaOfficeName;
	}

	/**
	 */
	public String getSubmissionGaOfficeName() {
		return this.submissionGaOfficeName;
	}

	/**
	 */
	public void setServicingAgentCode(String servicingAgentCode) {
		this.servicingAgentCode = servicingAgentCode;
	}

	/**
	 */
	public String getServicingAgentCode() {
		return this.servicingAgentCode;
	}

	/**
	 */
	public void setServicingAgentName(String servicingAgentName) {
		this.servicingAgentName = servicingAgentName;
	}

	/**
	 */
	public String getServicingAgentName() {
		return this.servicingAgentName;
	}

	/**
	 */
	public void setServicingAgencyCode(String servicingAgencyCode) {
		this.servicingAgencyCode = servicingAgencyCode;
	}

	/**
	 */
	public String getServicingAgencyCode() {
		return this.servicingAgencyCode;
	}

	/**
	 */
	public void setServicingAgencyName(String servicingAgencyName) {
		this.servicingAgencyName = servicingAgencyName;
	}

	/**
	 */
	public String getServicingAgencyName() {
		return this.servicingAgencyName;
	}

	/**
	 */
	public void setServicingGaOfficeCode(String servicingGaOfficeCode) {
		this.servicingGaOfficeCode = servicingGaOfficeCode;
	}

	/**
	 */
	public String getServicingGaOfficeCode() {
		return this.servicingGaOfficeCode;
	}

	/**
	 */
	public void setServicingGaOfficeName(String servicingGaOfficeName) {
		this.servicingGaOfficeName = servicingGaOfficeName;
	}

	/**
	 */
	public String getServicingGaOfficeName() {
		return this.servicingGaOfficeName;
	}

	/**
	 */
	public CorrespondenceWorking() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CorrespondenceWorking that) {
		setCorrWorkingId(that.getCorrWorkingId());
		setClaimId(that.getClaimId());
		setCompanyId(that.getCompanyId());
		setFormId(that.getFormId());
		setClaimArea(that.getClaimArea());
		setCorrType(that.getCorrType());
		setPolicyNo(that.getPolicyNo());
		setBusinessLine(that.getBusinessLine());
		setProductCode(that.getProductCode());
		setUserId(that.getUserId());
		setUserDept(that.getUserDept());
		setPayeeTitle(that.getPayeeTitle());
		setPayeeLastName(that.getPayeeLastName());
		setPayeeFirstName(that.getPayeeFirstName());
		setAddressLine1(that.getAddressLine1());
		setAddressLine2(that.getAddressLine2());
		setAddressLine3(that.getAddressLine3());
		setAddressLine4(that.getAddressLine4());
		setFamTitle(that.getFamTitle());
		setFamLastName(that.getFamLastName());
		setFamFirstName(that.getFamFirstName());
		setFamaddressLine1(that.getFamaddressLine1());
		setFamaddressLine2(that.getFamaddressLine2());
		setFamaddressLine3(that.getFamaddressLine3());
		setFamaddressLine4(that.getFamaddressLine4());
		setPolicyNoList(that.getPolicyNoList());
		setInsuredtitle(that.getInsuredtitle());
		setInsuredLastName(that.getInsuredLastName());
		setInsuredFirstName(that.getInsuredFirstName());
		setCoverageNameThai(that.getCoverageNameThai());
		setTotalClaimPaidAmt(that.getTotalClaimPaidAmt());
		setBranchName(that.getBranchName());
		setChequeDate(that.getChequeDate());
		setChequeAmt(that.getChequeAmt());
		setSubmissionAgentCode(that.getSubmissionAgentCode());
		setSubmissionAgentName(that.getSubmissionAgentName());
		setSubmissionAgencyCode(that.getSubmissionAgencyCode());
		setSubmissionAgencyName(that.getSubmissionAgencyName());
		setSubmissionGaOfficeCode(that.getSubmissionGaOfficeCode());
		setSubmissionGaOfficeName(that.getSubmissionGaOfficeName());
		setServicingAgentCode(that.getServicingAgentCode());
		setServicingAgentName(that.getServicingAgentName());
		setServicingAgencyCode(that.getServicingAgencyCode());
		setServicingAgencyName(that.getServicingAgencyName());
		setServicingGaOfficeCode(that.getServicingGaOfficeCode());
		setServicingGaOfficeName(that.getServicingGaOfficeName());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("corrWorkingId=[").append(corrWorkingId).append("] ");
		buffer.append("claimId=[").append(claimId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("formId=[").append(formId).append("] ");
		buffer.append("claimArea=[").append(claimArea).append("] ");
		buffer.append("corrType=[").append(corrType).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("userId=[").append(userId).append("] ");
		buffer.append("userDept=[").append(userDept).append("] ");
		buffer.append("payeeTitle=[").append(payeeTitle).append("] ");
		buffer.append("payeeLastName=[").append(payeeLastName).append("] ");
		buffer.append("payeeFirstName=[").append(payeeFirstName).append("] ");
		buffer.append("addressLine1=[").append(addressLine1).append("] ");
		buffer.append("addressLine2=[").append(addressLine2).append("] ");
		buffer.append("addressLine3=[").append(addressLine3).append("] ");
		buffer.append("addressLine4=[").append(addressLine4).append("] ");
		buffer.append("famTitle=[").append(famTitle).append("] ");
		buffer.append("famLastName=[").append(famLastName).append("] ");
		buffer.append("famFirstName=[").append(famFirstName).append("] ");
		buffer.append("famaddressLine1=[").append(famaddressLine1).append("] ");
		buffer.append("famaddressLine2=[").append(famaddressLine2).append("] ");
		buffer.append("famaddressLine3=[").append(famaddressLine3).append("] ");
		buffer.append("famaddressLine4=[").append(famaddressLine4).append("] ");
		buffer.append("policyNoList=[").append(policyNoList).append("] ");
		buffer.append("insuredtitle=[").append(insuredtitle).append("] ");
		buffer.append("insuredLastName=[").append(insuredLastName).append("] ");
		buffer.append("insuredFirstName=[").append(insuredFirstName).append("] ");
		buffer.append("coverageNameThai=[").append(coverageNameThai).append("] ");
		buffer.append("totalClaimPaidAmt=[").append(totalClaimPaidAmt).append("] ");
		buffer.append("branchName=[").append(branchName).append("] ");
		buffer.append("chequeDate=[").append(chequeDate).append("] ");
		buffer.append("chequeAmt=[").append(chequeAmt).append("] ");
		buffer.append("submissionAgentCode=[").append(submissionAgentCode).append("] ");
		buffer.append("submissionAgentName=[").append(submissionAgentName).append("] ");
		buffer.append("submissionAgencyCode=[").append(submissionAgencyCode).append("] ");
		buffer.append("submissionAgencyName=[").append(submissionAgencyName).append("] ");
		buffer.append("submissionGaOfficeCode=[").append(submissionGaOfficeCode).append("] ");
		buffer.append("submissionGaOfficeName=[").append(submissionGaOfficeName).append("] ");
		buffer.append("servicingAgentCode=[").append(servicingAgentCode).append("] ");
		buffer.append("servicingAgentName=[").append(servicingAgentName).append("] ");
		buffer.append("servicingAgencyCode=[").append(servicingAgencyCode).append("] ");
		buffer.append("servicingAgencyName=[").append(servicingAgencyName).append("] ");
		buffer.append("servicingGaOfficeCode=[").append(servicingGaOfficeCode).append("] ");
		buffer.append("servicingGaOfficeName=[").append(servicingGaOfficeName).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((corrWorkingId == null) ? 0 : corrWorkingId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CorrespondenceWorking))
			return false;
		CorrespondenceWorking equalCheck = (CorrespondenceWorking) obj;
		if ((corrWorkingId == null && equalCheck.corrWorkingId != null) || (corrWorkingId != null && equalCheck.corrWorkingId == null))
			return false;
		if (corrWorkingId != null && !corrWorkingId.equals(equalCheck.corrWorkingId))
			return false;
		return true;
	}
}
