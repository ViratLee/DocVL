package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 */

//@Entity
@SqlResultSetMapping(name = "ProviderJoinProviderContact", classes = { @ConstructorResult(targetClass = ProviderJoinProviderContact.class, columns = { @ColumnResult(name = "providerId")

}) })
//@Table(name = "PROVIDER")
//@SecondaryTables({ @SecondaryTable(name = "PROVIDERCONTACT", pkJoinColumns = @PrimaryKeyJoinColumn(name = "PROVIDERCODE", referencedColumnName = "PROVIDERCODE")) })
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderJoinProviderContact")
public class ProviderJoinProviderContact extends BaseEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 */
	@Id
	@Column(name = "PROVIDERID")
	BigDecimal providerId;
	/**
	 */

	@Column(name = "PROVIDERCODE")
	String providerCode;
	/**
	 */

	@Column(name = "PROVIDERNAME")
	String providerName;
	/**
	 */

	@Column(name = "PROVIDERNAMETHAI")
	String providerNameThai;
	/**
	 */

	@Column(name = "PROVIDERREGNAME")
	String providerRegName;
	/**
	 */

	@Column(name = "PROVIDERREGNAMETHAI")
	String providerRegNameThai;
	/**
	 */

	@Column(name = "PROVIDERSTATUS")
	String providerStatus;
	/**
	 */

	@Column(name = "PROVIDERTYPESECTOR")
	String providerTypeSector;
	/**
	 */

	@Column(name = "PROVIDERTYPE")
	String providerType;

	@Column(name = "PROVINCE")
	String province;

	@Column(name = "REGION")
	String region;

	@Column(name = "PHONENO1")
	String phoneNo1;

	@Column(name = "FAXNO1")
	String faxNo1;

	@Column(name = "EMAILADDRESS1")
	String emailAddress1;

	public BigDecimal getProviderId() {
		return providerId;
	}

	public void setProviderId(BigDecimal providerId) {
		this.providerId = providerId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getProviderRegName() {
		return providerRegName;
	}

	public void setProviderRegName(String providerRegName) {
		this.providerRegName = providerRegName;
	}

	public String getProviderRegNameThai() {
		return providerRegNameThai;
	}

	public void setProviderRegNameThai(String providerRegNameThai) {
		this.providerRegNameThai = providerRegNameThai;
	}

	public String getProviderStatus() {
		return providerStatus;
	}

	public void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	public String getProviderTypeSector() {
		return providerTypeSector;
	}

	public void setProviderTypeSector(String providerTypeSector) {
		this.providerTypeSector = providerTypeSector;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getPhoneNo1() {
		return phoneNo1;
	}

	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	public String getFaxNo1() {
		return faxNo1;
	}

	public void setFaxNo1(String faxNo1) {
		this.faxNo1 = faxNo1;
	}

	public String getEmailAddress1() {
		return emailAddress1;
	}

	public void setEmailAddress1(String emailAddress1) {
		this.emailAddress1 = emailAddress1;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public void copy(ProviderJoinProviderContact that) {

	}

	public ProviderJoinProviderContact(BigDecimal providerId, String providerCode, String providerName, String providerNameThai, String providerRegName, String providerRegNameThai,
			String providerStatus, String providerTypeSector, String providerType, String province, String region, String phoneNo1, String faxNo1, String emailAddress1) {
		super();
		this.providerId = providerId;
		this.providerCode = providerCode;
		this.providerName = providerName;
		this.providerNameThai = providerNameThai;
		this.providerRegName = providerRegName;
		this.providerRegNameThai = providerRegNameThai;
		this.providerStatus = providerStatus;
		this.providerTypeSector = providerTypeSector;
		this.providerType = providerType;
		this.province = province;
		this.region = region;
		this.phoneNo1 = phoneNo1;
		this.faxNo1 = faxNo1;
		this.emailAddress1 = emailAddress1;
	}

	public ProviderJoinProviderContact() {

	}
}
