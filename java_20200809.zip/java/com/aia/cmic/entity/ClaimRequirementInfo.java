package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllClaimRequirementInfos", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo"),
		@NamedQuery(name = "findClaimRequirementInfoByClaimNo", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.claimNo = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByClaimRequirementInfoId", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.claimRequirementInfoId = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByDocumentType", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.documentType = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByDocumentTypeContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.documentType like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByLetter", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.letter = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByLetterContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.letter like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByPendingCode", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.pendingCode = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByPendingCodeContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.pendingCode like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByPrimaryKey", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.claimRequirementInfoId = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByRemark", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.remark = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByRemarkContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.remark like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByRequirementDetail", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.requirementDetail = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByRequirementDetailContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.requirementDetail like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByResolveBy", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.resolveBy = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByResolveByContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.resolveBy like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByResolveDetail", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.resolveDetail = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByResolveDetailContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.resolveDetail like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByResolveInd", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.resolveInd = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByResolveIndContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.resolveInd like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoBySeqNo", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.seqNo = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoBySeqNoContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.seqNo like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByStatus", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.status = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByStatusContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.status like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByTarget", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.target = ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByTargetContaining", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.target like ?1"),
		@NamedQuery(name = "findClaimRequirementInfoByCompanyIdClaimNoAndOccurrence", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.claimNo=?1 and myClaimRequirementInfo.occurrence=?2"),
		@NamedQuery(name = "deleteClaimRequirementInfoByCompanyIdAndClaimNo", query = "delete from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.claimNo=?1"),
		@NamedQuery(name = "findClaimRequirementInfoByClaimNoOccurrenceAndStatus", query = "select myClaimRequirementInfo from ClaimRequirementInfo myClaimRequirementInfo where myClaimRequirementInfo.claimNo=?1 and myClaimRequirementInfo.occurrence=?2 and myClaimRequirementInfo.status=?3 "),
})
@Table(name = "CLAIMREQUIREMENTINFO")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimRequirementInfo")
public class ClaimRequirementInfo extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimRequirementInfoSequence")
	@SequenceGenerator(name = "claimRequirementInfoSequence", sequenceName = "s_claimrequirementinfo")
	@Column(name = "CLAIMREQUIREMENTINFOID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimRequirementInfoId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "TARGET", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String target;
	/**
	 */

	@Column(name = "DOCUMENTTYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String documentType;
	/**
	 */

	@Column(name = "PENDINGCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String pendingCode;
	/**
	 */

	@Column(name = "SEQNO", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String seqNo;
	/**
	 */

	@Column(name = "STATUS", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;
	/**
	 */

	@Column(name = "REQUIREMENTDETAIL", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String requirementDetail;
	/**
	 */

	@Column(name = "RESOLVEDETAIL", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String resolveDetail;
	/**
	 */

	@Column(name = "LETTER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String letter;
	/**
	 */

	@Column(name = "REQUESTEDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date requestedDt;
	/**
	 */

	@Column(name = "RECEIVEDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date receivedDt;
	/**
	 */

	@Column(name = "FULFILLEDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date fulfilledDt;
	/**
	 */

	@Column(name = "DUEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dueDt;
	/**
	 */

	@Column(name = "REMARK", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String remark;
	/**
	 */

	@Column(name = "RESOLVEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String resolveInd;
	/**
	 */

	@Column(name = "RESOLVEBY", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String resolveBy;
	/**
	 */

	@Column(name = "RESOLVEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date resolveDt;

	/**
	 */

	/**
	 * @return the claimRequirementInfoId
	 */
	public Long getClaimRequirementInfoId() {
		return claimRequirementInfoId;
	}

	/**
	 * @param claimRequirementInfoId the claimRequirementInfoId to set
	 */
	public void setClaimRequirementInfoId(Long claimRequirementInfoId) {
		this.claimRequirementInfoId = claimRequirementInfoId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 * @return the target
	 */
	public String getTarget() {
		return target;
	}

	/**
	 * @param target the target to set
	 */
	public void setTarget(String target) {
		this.target = target;
	}

	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * @return the pendingCode
	 */
	public String getPendingCode() {
		return pendingCode;
	}

	/**
	 * @param pendingCode the pendingCode to set
	 */
	public void setPendingCode(String pendingCode) {
		this.pendingCode = pendingCode;
	}

	/**
	 * @return the seqNo
	 */
	public String getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the requirementDetail
	 */
	public String getRequirementDetail() {
		return requirementDetail;
	}

	/**
	 * @param requirementDetail the requirementDetail to set
	 */
	public void setRequirementDetail(String requirementDetail) {
		this.requirementDetail = requirementDetail;
	}

	/**
	 * @return the resolveDetail
	 */
	public String getResolveDetail() {
		return resolveDetail;
	}

	/**
	 * @param resolveDetail the resolveDetail to set
	 */
	public void setResolveDetail(String resolveDetail) {
		this.resolveDetail = resolveDetail;
	}

	/**
	 * @return the letter
	 */
	public String getLetter() {
		return letter;
	}

	/**
	 * @param letter the letter to set
	 */
	public void setLetter(String letter) {
		this.letter = letter;
	}

	/**
	 * @return the requestedDt
	 */
	public Date getRequestedDt() {
		return requestedDt;
	}

	/**
	 * @param requestedDt the requestedDt to set
	 */
	public void setRequestedDt(Date requestedDt) {
		this.requestedDt = requestedDt;
	}

	/**
	 * @return the receivedDt
	 */
	public Date getReceivedDt() {
		return receivedDt;
	}

	/**
	 * @param receivedDt the receivedDt to set
	 */
	public void setReceivedDt(Date receivedDt) {
		this.receivedDt = receivedDt;
	}

	/**
	 * @return the fulfilledDt
	 */
	public Date getFulfilledDt() {
		return fulfilledDt;
	}

	/**
	 * @param fulfilledDt the fulfilledDt to set
	 */
	public void setFulfilledDt(Date fulfilledDt) {
		this.fulfilledDt = fulfilledDt;
	}

	/**
	 * @return the dueDt
	 */
	public Date getDueDt() {
		return dueDt;
	}

	/**
	 * @param dueDt the dueDt to set
	 */
	public void setDueDt(Date dueDt) {
		this.dueDt = dueDt;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the resolveInd
	 */
	public String getResolveInd() {
		return resolveInd;
	}

	/**
	 * @param resolveInd the resolveInd to set
	 */
	public void setResolveInd(String resolveInd) {
		this.resolveInd = resolveInd;
	}

	/**
	 * @return the resolveBy
	 */
	public String getResolveBy() {
		return resolveBy;
	}

	/**
	 * @param resolveBy the resolveBy to set
	 */
	public void setResolveBy(String resolveBy) {
		this.resolveBy = resolveBy;
	}

	/**
	 * @return the resolveDt
	 */
	public Date getResolveDt() {
		return resolveDt;
	}

	/**
	 * @param resolveDt the resolveDt to set
	 */
	public void setResolveDt(Date resolveDt) {
		this.resolveDt = resolveDt;
	}

	/**
	 */
	public ClaimRequirementInfo() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimRequirementInfo that) {
		setClaimRequirementInfoId(that.getClaimRequirementInfoId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setTarget(that.getTarget());
		setDocumentType(that.getDocumentType());
		setPendingCode(that.getPendingCode());
		setSeqNo(that.getSeqNo());
		setStatus(that.getStatus());
		setRequirementDetail(that.getRequirementDetail());
		setResolveDetail(that.getResolveDetail());
		setLetter(that.getLetter());
		setRequestedDt(that.getRequestedDt());
		setReceivedDt(that.getReceivedDt());
		setFulfilledDt(that.getFulfilledDt());
		setDueDt(that.getDueDt());
		setRemark(that.getRemark());
		setResolveInd(that.getResolveInd());
		setResolveBy(that.getResolveBy());
		setResolveDt(that.getResolveDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimRequirementInfoId=[").append(claimRequirementInfoId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("target=[").append(target).append("] ");
		buffer.append("documentType=[").append(documentType).append("] ");
		buffer.append("pendingCode=[").append(pendingCode).append("] ");
		buffer.append("seqNo=[").append(seqNo).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("requirementDetail=[").append(requirementDetail).append("] ");
		buffer.append("resolveDetail=[").append(resolveDetail).append("] ");
		buffer.append("letter=[").append(letter).append("] ");
		buffer.append("requestedDt=[").append(requestedDt).append("] ");
		buffer.append("receivedDt=[").append(receivedDt).append("] ");
		buffer.append("fulfilledDt=[").append(fulfilledDt).append("] ");
		buffer.append("dueDt=[").append(dueDt).append("] ");
		buffer.append("remark=[").append(remark).append("] ");
		buffer.append("resolveInd=[").append(resolveInd).append("] ");
		buffer.append("resolveBy=[").append(resolveBy).append("] ");
		buffer.append("resolveDt=[").append(resolveDt).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimRequirementInfoId == null) ? 0 : claimRequirementInfoId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimRequirementInfo))
			return false;
		ClaimRequirementInfo equalCheck = (ClaimRequirementInfo) obj;
		if ((claimRequirementInfoId == null && equalCheck.claimRequirementInfoId != null) || (claimRequirementInfoId != null && equalCheck.claimRequirementInfoId == null))
			return false;
		if (claimRequirementInfoId != null && !claimRequirementInfoId.equals(equalCheck.claimRequirementInfoId))
			return false;
		return true;
	}
}
