package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@NamedQueries({ @NamedQuery(name = "getMaxCoverageNo",
		query = "select max(claimPaymentHistory.planCoverageNo) from ClaimPaymentDetailHistory claimPaymentHistory where claimPaymentHistory.companyId = ?1 and claimPaymentHistory.claimNo = ?2 and claimPaymentHistory.occurrence = ?3 and claimPaymentHistory.policyNo = ?4 and claimPaymentHistory.planId = ?5"),
})
@Table(name = "CLAIMPAYMENTDETAILHISTORY")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPaymentDetailHistory")
public class ClaimPaymentDetailHistory extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaymentDetailHistorySequence")
	@SequenceGenerator(name = "claimPaymentDetailHistorySequence", sequenceName = "s_claimPaymentDetailHistory")
	@Column(name = "CLAIMPAYMENTDETAILIDHISTORYID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPaymentDetailIdHistoryId;

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", length = 3, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;

	@Column(name = "PLANID", length = 18, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;

	@Column(name = "PLANCOVERAGENO", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;

	@Column(name = "PRODUCTTYPE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productType;

	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;

	@Column(name = "PRESENTEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt;

	@Column(name = "ELIGIBLEAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal eligibleAmt;

	@Column(name = "ALLOCATEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal AllocatedAmt;

	@Column(name = "NOOFDAYSALLOCATED", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysAllocated;

	@Column(name = "PERCENTAGEALLOCATED", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal percentageAllocated;

	@Column(name = "HSREDUCTIONSEQ", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer hsReductionSeq;

	@Column(name = "SHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal shortfallAmt;

	@Column(name = "REIMBURSEDDAY", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer reimbursedDay;

	@Column(name = "PAYMENTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentStatus;

	public Long getClaimPaymentDetailIdHistoryId() {
		return claimPaymentDetailIdHistoryId;
	}

	public void setClaimPaymentDetailIdHistoryId(Long claimPaymentDetailIdHistoryId) {
		this.claimPaymentDetailIdHistoryId = claimPaymentDetailIdHistoryId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	public BigDecimal getAllocatedAmt() {
		return AllocatedAmt;
	}

	public void setAllocatedAmt(BigDecimal allocatedAmt) {
		AllocatedAmt = allocatedAmt;
	}

	public Integer getNoOfDaysAllocated() {
		return noOfDaysAllocated;
	}

	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	public BigDecimal getPercentageAllocated() {
		return percentageAllocated;
	}

	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	public Integer getHsReductionSeq() {
		return hsReductionSeq;
	}

	public void setHsReductionSeq(Integer hsReductionSeq) {
		this.hsReductionSeq = hsReductionSeq;
	}

	public BigDecimal getShortfallAmt() {
		return shortfallAmt;
	}

	public void setShortfallAmt(BigDecimal shortfallAmt) {
		this.shortfallAmt = shortfallAmt;
	}

	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public ClaimPaymentDetailHistory() {
	}

	public void copy(Claim that) {

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPaymentDetailIdHistoryId == null) ? 0 : claimPaymentDetailIdHistoryId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Claim))
			return false;
		ClaimPaymentDetailHistory equalCheck = (ClaimPaymentDetailHistory) obj;
		if ((claimPaymentDetailIdHistoryId == null && equalCheck.claimPaymentDetailIdHistoryId != null) || (claimPaymentDetailIdHistoryId != null && equalCheck.claimPaymentDetailIdHistoryId == null))
			return false;
		if (claimPaymentDetailIdHistoryId != null && !claimPaymentDetailIdHistoryId.equals(equalCheck.claimPaymentDetailIdHistoryId))
			return false;
		return true;
	}
}
