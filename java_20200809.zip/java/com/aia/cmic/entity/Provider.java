package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProviders", query = "select myProvider from Provider myProvider"),
		@NamedQuery(name = "findProviderByAiaQualityTier", query = "select myProvider from Provider myProvider where myProvider.aiaQualityTier = ?1"),
		@NamedQuery(name = "findProviderByAiaQualityTierContaining", query = "select myProvider from Provider myProvider where myProvider.aiaQualityTier like ?1"),
		@NamedQuery(name = "findProviderByBankAccountNo", query = "select myProvider from Provider myProvider where myProvider.bankAccountNo = ?1"),
		@NamedQuery(name = "findProviderByBankAccountNoContaining", query = "select myProvider from Provider myProvider where myProvider.bankAccountNo like ?1"),
		@NamedQuery(name = "findProviderByBankCode", query = "select myProvider from Provider myProvider where myProvider.bankCode = ?1"),
		@NamedQuery(name = "findProviderByBankCodeContaining", query = "select myProvider from Provider myProvider where myProvider.bankCode like ?1"),
		@NamedQuery(name = "findProviderByBlacklistInd", query = "select myProvider from Provider myProvider where myProvider.blacklistInd = ?1"),
		@NamedQuery(name = "findProviderByBlacklistIndContaining", query = "select myProvider from Provider myProvider where myProvider.blacklistInd like ?1"),
		@NamedQuery(name = "findProviderByExamRoom", query = "select myProvider from Provider myProvider where myProvider.examRoom = ?1"),
		@NamedQuery(name = "findProviderByFaxClaimScore", query = "select myProvider from Provider myProvider where myProvider.faxClaimScore = ?1"),
		@NamedQuery(name = "findProviderByFaxClaimScoreContaining", query = "select myProvider from Provider myProvider where myProvider.faxClaimScore like ?1"),
		@NamedQuery(name = "findProviderByIaScore", query = "select myProvider from Provider myProvider where myProvider.iaScore = ?1"),
		@NamedQuery(name = "findProviderByIcuBed", query = "select myProvider from Provider myProvider where myProvider.icuBed = ?1"),
		@NamedQuery(name = "findProviderByOperatedBed", query = "select myProvider from Provider myProvider where myProvider.operatedBed = ?1"),
		@NamedQuery(name = "findProviderByOrRoom", query = "select myProvider from Provider myProvider where myProvider.orRoom = ?1"),
		@NamedQuery(name = "findProviderByPayeeName", query = "select myProvider from Provider myProvider where myProvider.payeeName = ?1"),
		@NamedQuery(name = "findProviderByPayeeNameContaining", query = "select myProvider from Provider myProvider where myProvider.payeeName like ?1"),
		@NamedQuery(name = "findProviderByPaymentCycle", query = "select myProvider from Provider myProvider where myProvider.paymentCycle = ?1"),
		@NamedQuery(name = "findProviderByPaymentCycleContaining", query = "select myProvider from Provider myProvider where myProvider.paymentCycle like ?1"),
		@NamedQuery(name = "findProviderByPaymentMethod", query = "select myProvider from Provider myProvider where myProvider.paymentMethod = ?1"),
		@NamedQuery(name = "findProviderByPaymentMethodContaining", query = "select myProvider from Provider myProvider where myProvider.paymentMethod like ?1"),
		@NamedQuery(name = "findProviderByPrimaryKey", query = "select myProvider from Provider myProvider where myProvider.providerId = ?1"),
		@NamedQuery(name = "findProviderByProviderAffordabilityTier", query = "select myProvider from Provider myProvider where myProvider.providerAffordAbilityTier = ?1"),
		@NamedQuery(name = "findProviderByProviderAffordabilityTierContaining", query = "select myProvider from Provider myProvider where myProvider.providerAffordAbilityTier like ?1"),
		@NamedQuery(name = "findProviderByProviderCode", query = "select myProvider from Provider myProvider where myProvider.providerCode = ?1"),
		@NamedQuery(name = "findProviderByProviderCodeContaining", query = "select myProvider from Provider myProvider where myProvider.providerCode like ?1"),
		@NamedQuery(name = "findProviderByProviderGroup", query = "select myProvider from Provider myProvider where myProvider.providerGroup = ?1"),
		@NamedQuery(name = "findProviderByProviderGroupContaining", query = "select myProvider from Provider myProvider where myProvider.providerGroup like ?1"),
		@NamedQuery(name = "findProviderByProviderId", query = "select myProvider from Provider myProvider where myProvider.providerId = ?1"),
		@NamedQuery(name = "findProviderByProviderLicenseNum", query = "select myProvider from Provider myProvider where myProvider.providerLicenseNum = ?1"),
		@NamedQuery(name = "findProviderByProviderLicenseNumContaining", query = "select myProvider from Provider myProvider where myProvider.providerLicenseNum like ?1"),
		@NamedQuery(name = "findProviderByProviderName", query = "select myProvider from Provider myProvider where myProvider.providerName = ?1"),
		@NamedQuery(name = "findProviderByProviderNameContaining", query = "select myProvider from Provider myProvider where myProvider.providerName like ?1"),
		@NamedQuery(name = "findProviderByProviderNameThai", query = "select myProvider from Provider myProvider where myProvider.providerNameThai = ?1"),
		@NamedQuery(name = "findProviderByProviderNameThaiContaining", query = "select myProvider from Provider myProvider where myProvider.providerNameThai like ?1"),
		@NamedQuery(name = "findProviderByProviderRegName", query = "select myProvider from Provider myProvider where myProvider.providerRegName = ?1"),
		@NamedQuery(name = "findProviderByProviderRegNameContaining", query = "select myProvider from Provider myProvider where myProvider.providerRegName like ?1"),
		@NamedQuery(name = "findProviderByProviderRegNameThai", query = "select myProvider from Provider myProvider where myProvider.providerRegNameThai = ?1"),
		@NamedQuery(name = "findProviderByProviderRegNameThaiContaining", query = "select myProvider from Provider myProvider where myProvider.providerRegNameThai like ?1"),
		@NamedQuery(name = "findProviderByProviderStatus", query = "select myProvider from Provider myProvider where myProvider.providerStatus = ?1"),
		@NamedQuery(name = "findProviderByProviderStatusContaining", query = "select myProvider from Provider myProvider where myProvider.providerStatus like ?1"),
		@NamedQuery(name = "findProviderByProviderType", query = "select myProvider from Provider myProvider where myProvider.providerType = ?1"),
		@NamedQuery(name = "findProviderByProviderTypeContaining", query = "select myProvider from Provider myProvider where myProvider.providerType like ?1"),
		@NamedQuery(name = "findProviderByProviderTypeSector", query = "select myProvider from Provider myProvider where myProvider.providerTypeSector = ?1"),
		@NamedQuery(name = "findProviderByProviderTypeSectorContaining", query = "select myProvider from Provider myProvider where myProvider.providerTypeSector like ?1"),
		@NamedQuery(name = "findProviderByRegisteredBed", query = "select myProvider from Provider myProvider where myProvider.registeredBed = ?1"),
		@NamedQuery(name = "findProviderByServicePriority", query = "select myProvider from Provider myProvider where myProvider.servicePriority = ?1"),
		@NamedQuery(name = "findProviderByServicePriorityContaining", query = "select myProvider from Provider myProvider where myProvider.servicePriority like ?1"),
		@NamedQuery(name = "findProviderByFieldContaining", query = "select myProvider from Provider myProvider where myProvider.providerCode like ?1 or myProvider.providerNameThai like ?2"),
		@NamedQuery(name = "findActiveProviderByFieldContaining", query = "select myProvider from Provider myProvider where (myProvider.providerCode like ?1 or myProvider.providerNameThai like ?2) and myProvider.providerStatus = 'A' order by myProvider.providerNameThai"),
		@NamedQuery(name = "findProviderHCByFieldContaining", query = "select myProvider from Provider myProvider where (myProvider.hcCode like ?1 or myProvider.providerNameThai like ?2 or myProvider.hcCode ||' - ' || myProvider.providerNameThai like ?3) and myProvider.providerStatus = 'A' and myProvider.hcCode is not null and trim(myProvider.hcCode)<>' ' order by myProvider.hcCode"),
		@NamedQuery(name = "findOverseaProviderByFieldContaining", query = "select myProvider from Provider myProvider, ProviderContact myProviderContact  where (myProvider.providerCode = myProviderContact.providerCode and myProviderContact.contactType = 'Primary' and myProviderContact.region = '"
				+ CommonCode.REGION_OVERSEA
				+ "') and (UPPER(myProvider.providerCode) like ?1 or UPPER(myProvider.providerNameThai) like ?2) and myProvider.providerStatus = 'A' order by myProvider.providerNameThai"),
		@NamedQuery(name = "findProviderByCompanyIdAndProviderCode", query = "select myProvider from Provider myProvider where myProvider.companyId = ?1 and myProvider.providerCode=?2"),
		@NamedQuery(name = "findNonOverseaProviderByFieldContaining", query = "select myProvider from Provider myProvider, ProviderContact myProviderContact  where (myProvider.providerCode = myProviderContact.providerCode and myProviderContact.contactType = 'Primary' and (myProviderContact.region <> '"
				+ CommonCode.REGION_OVERSEA
				+ "' or myProviderContact.region is null)) and (UPPER(myProvider.providerCode) like ?1 or UPPER(myProvider.providerNameThai) like ?2) and myProvider.providerStatus = 'A' order by myProvider.providerNameThai"),
		@NamedQuery(name = "findProviderByCompassCode", query = "select myProvider from Provider myProvider where myProvider.prevCompassCode = ?1"),
		@NamedQuery(name = "findProviderByPrevHosCode", query = "select myProvider from Provider myProvider where myProvider.prevHospitalCode = ?1") })
@Table(name = "PROVIDER")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Provider")
public class Provider extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "providerSequence")
	@SequenceGenerator(name = "providerSequence", sequenceName = "s_provider")
	@Column(name = "PROVIDERID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long providerId;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "PROVIDERNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerName;
	/**
	 */

	@Column(name = "PROVIDERNAMETHAI", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerNameThai;
	/**
	 */

	@Column(name = "PROVIDERREGNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerRegName;
	/**
	 */

	@Column(name = "PROVIDERREGNAMETHAI", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerRegNameThai;
	/**
	 */

	@Column(name = "PROVIDERSTATUS", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerStatus;
	/**
	 */

	@Column(name = "PROVIDERGROUP", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerGroup;
	/**
	 */

	@Column(name = "PROVIDERTYPESECTOR", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerTypeSector;
	/**
	 */

	@Column(name = "PROVIDERTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerType;
	/**
	 */

	@Column(name = "OPERATIONFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date operationFromDt;
	/**
	 */

	@Column(name = "EFFECTIVEFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveFromDt;
	/**
	 */

	@Column(name = "EFFECTIVETODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveToDt;
	/**
	 */

	@Column(name = "REGISTEREDBED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer registeredBed;
	/**
	 */

	@Column(name = "OPERATEDBED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer operatedBed;
	/**
	 */

	@Column(name = "ICUBED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer icuBed;
	/**
	 */

	@Column(name = "ORROOM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer orRoom;
	/**
	 */

	@Column(name = "EXAMROOM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer examRoom;
	/**
	 */

	@Column(name = "BLACKLISTIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistInd;
	/**
	 */

	@Column(name = "BLACKLISTSTARTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date blacklistStartDate;
	/**
	 */

	@Column(name = "BLACKLISTENDDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date blacklistEndDate;
	/**
	 */

	@Column(name = "AIAQUALITYTIER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiaQualityTier;
	/**
	 */

	@Column(name = "PROVIDERAFFORDABILITYTIER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerAffordAbilityTier;
	/**
	 */

	@Column(name = "IASCORE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal iaScore;
	/**
	 */

	@Column(name = "SERVICEPRIORITY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicePriority;
	/**
	 */

	@Column(name = "FAXCLAIMSCORE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String faxClaimScore;
	/**
	 */

	@Column(name = "PAYEENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeName;
	/**
	 */

	@Column(name = "BANKCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankCode;
	/**
	 */

	@Column(name = "BANKACCOUNTNO", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankAccountNo;
	/**
	 */

	@Column(name = "PROVIDERLICENSENUM", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerLicenseNum;
	/**
	 */

	@Column(name = "PAYMENTCYCLE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentCycle;
	/**
	 */

	@Column(name = "PAYMENTMETHOD", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentMethod;

	@Column(name = "PREVHOSPITALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevHospitalCode;

	@Column(name = "BLACKLISTREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistReason;

	@Column(name = "HCCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String hcCode;

	@Column(name = "PREVCOMPASSCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String prevCompassCode;

	/**
	 */

	/**
	 * @return the providerId
	 */
	public Long getProviderId() {
		return providerId;
	}

	/**
	 * @param providerId the providerId to set
	 */
	public void setProviderId(Long providerId) {
		this.providerId = providerId;
	}

	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}

	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 * @return the providerName
	 */
	public String getProviderName() {
		return providerName;
	}

	/**
	 * @param providerName the providerName to set
	 */
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	/**
	 * @return the providerNameThai
	 */
	public String getProviderNameThai() {
		return providerNameThai;
	}

	/**
	 * @param providerNameThai the providerNameThai to set
	 */
	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	/**
	 * @return the providerRegName
	 */
	public String getProviderRegName() {
		return providerRegName;
	}

	/**
	 * @param providerRegName the providerRegName to set
	 */
	public void setProviderRegName(String providerRegName) {
		this.providerRegName = providerRegName;
	}

	/**
	 * @return the providerRegNameThai
	 */
	public String getProviderRegNameThai() {
		return providerRegNameThai;
	}

	/**
	 * @param providerRegNameThai the providerRegNameThai to set
	 */
	public void setProviderRegNameThai(String providerRegNameThai) {
		this.providerRegNameThai = providerRegNameThai;
	}

	/**
	 * @return the providerStatus
	 */
	public String getProviderStatus() {
		return providerStatus;
	}

	/**
	 * @param providerStatus the providerStatus to set
	 */
	public void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	/**
	 * @return the providerGroup
	 */
	public String getProviderGroup() {
		return providerGroup;
	}

	/**
	 * @param providerGroup the providerGroup to set
	 */
	public void setProviderGroup(String providerGroup) {
		this.providerGroup = providerGroup;
	}

	/**
	 * @return the providerTypeSector
	 */
	public String getProviderTypeSector() {
		return providerTypeSector;
	}

	/**
	 * @param providerTypeSector the providerTypeSector to set
	 */
	public void setProviderTypeSector(String providerTypeSector) {
		this.providerTypeSector = providerTypeSector;
	}

	/**
	 * @return the providerType
	 */
	public String getProviderType() {
		return providerType;
	}

	/**
	 * @param providerType the providerType to set
	 */
	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	/**
	 * @return the operationFromDt
	 */
	public Date getOperationFromDt() {
		return operationFromDt;
	}

	/**
	 * @param operationFromDt the operationFromDt to set
	 */
	public void setOperationFromDt(Date operationFromDt) {
		this.operationFromDt = operationFromDt;
	}

	/**
	 * @return the effectiveFromDt
	 */
	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	/**
	 * @param effectiveFromDt the effectiveFromDt to set
	 */
	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	/**
	 * @return the effectiveToDt
	 */
	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	/**
	 * @param effectiveToDt the effectiveToDt to set
	 */
	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	/**
	 * @return the registeredBed
	 */
	public Integer getRegisteredBed() {
		return registeredBed;
	}

	/**
	 * @param registeredBed the registeredBed to set
	 */
	public void setRegisteredBed(Integer registeredBed) {
		this.registeredBed = registeredBed;
	}

	/**
	 * @return the operatedBed
	 */
	public Integer getOperatedBed() {
		return operatedBed;
	}

	/**
	 * @param operatedBed the operatedBed to set
	 */
	public void setOperatedBed(Integer operatedBed) {
		this.operatedBed = operatedBed;
	}

	/**
	 * @return the icuBed
	 */
	public Integer getIcuBed() {
		return icuBed;
	}

	/**
	 * @param icuBed the icuBed to set
	 */
	public void setIcuBed(Integer icuBed) {
		this.icuBed = icuBed;
	}

	/**
	 * @return the orRoom
	 */
	public Integer getOrRoom() {
		return orRoom;
	}

	/**
	 * @param orRoom the orRoom to set
	 */
	public void setOrRoom(Integer orRoom) {
		this.orRoom = orRoom;
	}

	/**
	 * @return the examRoom
	 */
	public Integer getExamRoom() {
		return examRoom;
	}

	/**
	 * @param examRoom the examRoom to set
	 */
	public void setExamRoom(Integer examRoom) {
		this.examRoom = examRoom;
	}

	/**
	 * @return the blacklistInd
	 */
	public String getBlacklistInd() {
		return blacklistInd;
	}

	/**
	 * @param blacklistInd the blacklistInd to set
	 */
	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	/**
	 * @return the blacklistStartDate
	 */
	public Date getBlacklistStartDate() {
		return blacklistStartDate;
	}

	/**
	 * @param blacklistStartDate the blacklistStartDate to set
	 */
	public void setBlacklistStartDate(Date blacklistStartDate) {
		this.blacklistStartDate = blacklistStartDate;
	}

	/**
	 * @return the blacklistEndDate
	 */
	public Date getBlacklistEndDate() {
		return blacklistEndDate;
	}

	/**
	 * @param blacklistEndDate the blacklistEndDate to set
	 */
	public void setBlacklistEndDate(Date blacklistEndDate) {
		this.blacklistEndDate = blacklistEndDate;
	}

	/**
	 * @return the aiaQualityTier
	 */
	public String getAiaQualityTier() {
		return aiaQualityTier;
	}

	/**
	 * @param aiaQualityTier the aiaQualityTier to set
	 */
	public void setAiaQualityTier(String aiaQualityTier) {
		this.aiaQualityTier = aiaQualityTier;
	}

	/**
	 * @return the providerAffordAbilityTier
	 */
	public String getProviderAffordAbilityTier() {
		return providerAffordAbilityTier;
	}

	/**
	 * @param providerAffordAbilityTier the providerAffordAbilityTier to set
	 */
	public void setProviderAffordAbilityTier(String providerAffordAbilityTier) {
		this.providerAffordAbilityTier = providerAffordAbilityTier;
	}

	/**
	 * @return the iaScore
	 */
	public BigDecimal getIaScore() {
		return iaScore;
	}

	/**
	 * @param iaScore the iaScore to set
	 */
	public void setIaScore(BigDecimal iaScore) {
		this.iaScore = iaScore;
	}

	/**
	 * @return the servicePriority
	 */
	public String getServicePriority() {
		return servicePriority;
	}

	/**
	 * @param servicePriority the servicePriority to set
	 */
	public void setServicePriority(String servicePriority) {
		this.servicePriority = servicePriority;
	}

	/**
	 * @return the faxClaimScore
	 */
	public String getFaxClaimScore() {
		return faxClaimScore;
	}

	/**
	 * @param faxClaimScore the faxClaimScore to set
	 */
	public void setFaxClaimScore(String faxClaimScore) {
		this.faxClaimScore = faxClaimScore;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the bankAccountNo
	 */
	public String getBankAccountNo() {
		return bankAccountNo;
	}

	/**
	 * @param bankAccountNo the bankAccountNo to set
	 */
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	/**
	 * @return the providerLicenseNum
	 */
	public String getProviderLicenseNum() {
		return providerLicenseNum;
	}

	/**
	 * @param providerLicenseNum the providerLicenseNum to set
	 */
	public void setProviderLicenseNum(String providerLicenseNum) {
		this.providerLicenseNum = providerLicenseNum;
	}

	/**
	 * @return the paymentCycle
	 */
	public String getPaymentCycle() {
		return paymentCycle;
	}

	/**
	 * @param paymentCycle the paymentCycle to set
	 */
	public void setPaymentCycle(String paymentCycle) {
		this.paymentCycle = paymentCycle;
	}

	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPrevHospitalCode() {
		return prevHospitalCode;
	}

	public void setPrevHospitalCode(String prevHospitalCode) {
		this.prevHospitalCode = prevHospitalCode;
	}

	public String getBlacklistReason() {
		return blacklistReason;
	}

	public void setBlacklistReason(String blacklistReason) {
		this.blacklistReason = blacklistReason;
	}

	/**
	 * @return the hcCode
	 */
	public String getHcCode() {
		return hcCode;
	}

	/**
	 * @param hcCode the hcCode to set
	 */
	public void setHcCode(String hcCode) {
		this.hcCode = hcCode;
	}

	public String getPrevCompassCode() {
		return prevCompassCode;
	}

	public void setPrevCompassCode(String prevCompassCode) {
		this.prevCompassCode = prevCompassCode;
	}

	/**
	 */
	public Provider() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Provider that) {
		setProviderId(that.getProviderId());
		setProviderCode(that.getProviderCode());
		setCompanyId(that.getCompanyId());
		setProviderName(that.getProviderName());
		setProviderNameThai(that.getProviderNameThai());
		setProviderRegName(that.getProviderRegName());
		setProviderRegNameThai(that.getProviderRegNameThai());
		setProviderStatus(that.getProviderStatus());
		setProviderGroup(that.getProviderGroup());
		setProviderTypeSector(that.getProviderTypeSector());
		setProviderType(that.getProviderType());
		setOperationFromDt(that.getOperationFromDt());
		setEffectiveFromDt(that.getEffectiveFromDt());
		setEffectiveToDt(that.getEffectiveToDt());
		setRegisteredBed(that.getRegisteredBed());
		setOperatedBed(that.getOperatedBed());
		setIcuBed(that.getIcuBed());
		setOrRoom(that.getOrRoom());
		setExamRoom(that.getExamRoom());
		setBlacklistInd(that.getBlacklistInd());
		setBlacklistStartDate(that.getBlacklistStartDate());
		setBlacklistEndDate(that.getBlacklistEndDate());
		setAiaQualityTier(that.getAiaQualityTier());
		setProviderAffordAbilityTier(that.getProviderAffordAbilityTier());
		setIaScore(that.getIaScore());
		setServicePriority(that.getServicePriority());
		setFaxClaimScore(that.getFaxClaimScore());
		setPayeeName(that.getPayeeName());
		setBankCode(that.getBankCode());
		setBankAccountNo(that.getBankAccountNo());
		setProviderLicenseNum(that.getProviderLicenseNum());
		setPaymentCycle(that.getPaymentCycle());
		setPaymentMethod(that.getPaymentMethod());
		setPrevHospitalCode(that.getPrevHospitalCode());
		setPrevCompassCode(that.getPrevCompassCode());
		setHcCode(that.getHcCode());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setBlacklistReason(that.getBlacklistReason());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("providerId=[").append(providerId).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("providerName=[").append(providerName).append("] ");
		buffer.append("providerNameThai=[").append(providerNameThai).append("] ");
		buffer.append("providerRegName=[").append(providerRegName).append("] ");
		buffer.append("providerRegNameThai=[").append(providerRegNameThai).append("] ");
		buffer.append("providerStatus=[").append(providerStatus).append("] ");
		buffer.append("providerGroup=[").append(providerGroup).append("] ");
		buffer.append("providerTypeSector=[").append(providerTypeSector).append("] ");
		buffer.append("providerType=[").append(providerType).append("] ");
		buffer.append("operationFromDt=[").append(operationFromDt).append("] ");
		buffer.append("effectiveFromDt=[").append(effectiveFromDt).append("] ");
		buffer.append("effectiveToDt=[").append(effectiveToDt).append("] ");
		buffer.append("registeredBed=[").append(registeredBed).append("] ");
		buffer.append("operatedBed=[").append(operatedBed).append("] ");
		buffer.append("icuBed=[").append(icuBed).append("] ");
		buffer.append("orRoom=[").append(orRoom).append("] ");
		buffer.append("examRoom=[").append(examRoom).append("] ");
		buffer.append("blacklistInd=[").append(blacklistInd).append("] ");
		buffer.append("blacklistStartDate=[").append(blacklistStartDate).append("] ");
		buffer.append("blacklistEndDate=[").append(blacklistEndDate).append("] ");
		buffer.append("aiaQualityTier=[").append(aiaQualityTier).append("] ");
		buffer.append("providerAffordAbilityTier=[").append(providerAffordAbilityTier).append("] ");
		buffer.append("iaScore=[").append(iaScore).append("] ");
		buffer.append("servicePriority=[").append(servicePriority).append("] ");
		buffer.append("faxClaimScore=[").append(faxClaimScore).append("] ");
		buffer.append("payeeName=[").append(payeeName).append("] ");
		buffer.append("bankCode=[").append(bankCode).append("] ");
		buffer.append("bankAccountNo=[").append(bankAccountNo).append("] ");
		buffer.append("providerLicenseNum=[").append(providerLicenseNum).append("] ");
		buffer.append("paymentCycle=[").append(paymentCycle).append("] ");
		buffer.append("paymentMethod=[").append(paymentMethod).append("] ");
		buffer.append("prevHospitalCode=[").append(prevHospitalCode).append("] ");
		buffer.append("prevCompassCode=[").append(prevCompassCode).append("] ");
		buffer.append("hcCode=[").append(hcCode).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");
		buffer.append("blackListReason=[").append(getBlacklistReason()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((providerId == null) ? 0 : providerId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Provider))
			return false;
		Provider equalCheck = (Provider) obj;
		if ((providerId == null && equalCheck.providerId != null) || (providerId != null && equalCheck.providerId == null))
			return false;
		if (providerId != null && !providerId.equals(equalCheck.providerId))
			return false;
		return true;
	}
}
