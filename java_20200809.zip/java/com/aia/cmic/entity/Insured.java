package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllInsureds", query = "select myInsured from Insured myInsured"),
		@NamedQuery(name = "findInsuredByAddressLine1", query = "select myInsured from Insured myInsured where myInsured.addressLine1 = ?1"),
		@NamedQuery(name = "findInsuredByAddressLine1Containing", query = "select myInsured from Insured myInsured where myInsured.addressLine1 like ?1"),
		@NamedQuery(name = "findInsuredByAddressLine2", query = "select myInsured from Insured myInsured where myInsured.addressLine2 = ?1"),
		@NamedQuery(name = "findInsuredByAddressLine2Containing", query = "select myInsured from Insured myInsured where myInsured.addressLine2 like ?1"),
		@NamedQuery(name = "findInsuredByAddressLine3", query = "select myInsured from Insured myInsured where myInsured.addressLine3 = ?1"),
		@NamedQuery(name = "findInsuredByAddressLine3Containing", query = "select myInsured from Insured myInsured where myInsured.addressLine3 like ?1"),
		@NamedQuery(name = "findInsuredByAddressLine4", query = "select myInsured from Insured myInsured where myInsured.addressLine4 = ?1"),
		@NamedQuery(name = "findInsuredByAddressLine4Containing", query = "select myInsured from Insured myInsured where myInsured.addressLine4 like ?1"),
		@NamedQuery(name = "findInsuredByAmloInd", query = "select myInsured from Insured myInsured where myInsured.amloInd = ?1"),
		@NamedQuery(name = "findInsuredByAmloIndContaining", query = "select myInsured from Insured myInsured where myInsured.amloInd like ?1"),
		@NamedQuery(name = "findInsuredByBankruptcyInd", query = "select myInsured from Insured myInsured where myInsured.bankruptcyInd = ?1"),
		@NamedQuery(name = "findInsuredByBankruptcyIndContaining", query = "select myInsured from Insured myInsured where myInsured.bankruptcyInd like ?1"),
		@NamedQuery(name = "findInsuredByBlacklistInd", query = "select myInsured from Insured myInsured where myInsured.blacklistInd = ?1"),
		@NamedQuery(name = "findInsuredByBlacklistIndContaining", query = "select myInsured from Insured myInsured where myInsured.blacklistInd like ?1"),
		@NamedQuery(name = "findInsuredByCity", query = "select myInsured from Insured myInsured where myInsured.city = ?1"),
		@NamedQuery(name = "findInsuredByCityContaining", query = "select myInsured from Insured myInsured where myInsured.city like ?1"),
		@NamedQuery(name = "findInsuredByCountry", query = "select myInsured from Insured myInsured where myInsured.country = ?1"),
		@NamedQuery(name = "findInsuredByCountryContaining", query = "select myInsured from Insured myInsured where myInsured.country like ?1"),
		@NamedQuery(name = "findInsuredByEmailAddress", query = "select myInsured from Insured myInsured where myInsured.emailAddress = ?1"),
		@NamedQuery(name = "findInsuredByEmailAddressContaining", query = "select myInsured from Insured myInsured where myInsured.emailAddress like ?1"),
		@NamedQuery(name = "findInsuredByFatcaInd", query = "select myInsured from Insured myInsured where myInsured.fatcaInd = ?1"),
		@NamedQuery(name = "findInsuredByFatcaIndContaining", query = "select myInsured from Insured myInsured where myInsured.fatcaInd like ?1"),
		@NamedQuery(name = "findInsuredByFirstName", query = "select myInsured from Insured myInsured where myInsured.firstName = ?1"),
		@NamedQuery(name = "findInsuredByFirstNameContaining", query = "select myInsured from Insured myInsured where myInsured.firstName like ?1"),
		@NamedQuery(name = "findInsuredByGender", query = "select myInsured from Insured myInsured where myInsured.gender = ?1"),
		@NamedQuery(name = "findInsuredByGenderContaining", query = "select myInsured from Insured myInsured where myInsured.gender like ?1"),
		@NamedQuery(name = "findInsuredByInitialEffectiveDt", query = "select myInsured from Insured myInsured where myInsured.initialEffectiveDt = ?1"),
		@NamedQuery(name = "findInsuredByInsuredId", query = "select myInsured from Insured myInsured where myInsured.insuredId = ?1"),
		@NamedQuery(name = "findInsuredByLastName", query = "select myInsured from Insured myInsured where myInsured.lastName = ?1"),
		@NamedQuery(name = "findInsuredByLastNameContaining", query = "select myInsured from Insured myInsured where myInsured.lastName like ?1"),
		@NamedQuery(name = "findInsuredByMobile", query = "select myInsured from Insured myInsured where myInsured.mobile = ?1"),
		@NamedQuery(name = "findInsuredByMobileContaining", query = "select myInsured from Insured myInsured where myInsured.mobile like ?1"),
		@NamedQuery(name = "findInsuredByNationalId", query = "select myInsured from Insured myInsured where myInsured.nationalId = ?1"),
		@NamedQuery(name = "findInsuredByNationalIdContaining", query = "select myInsured from Insured myInsured where myInsured.nationalId like ?1"),
		@NamedQuery(name = "findInsuredByOfacInd", query = "select myInsured from Insured myInsured where myInsured.ofacInd = ?1"),
		@NamedQuery(name = "findInsuredByOfacIndContaining", query = "select myInsured from Insured myInsured where myInsured.ofacInd like ?1"),
		@NamedQuery(name = "findInsuredByPostalCode", query = "select myInsured from Insured myInsured where myInsured.postalCode = ?1"),
		@NamedQuery(name = "findInsuredByPostalCodeContaining", query = "select myInsured from Insured myInsured where myInsured.postalCode like ?1"),
		@NamedQuery(name = "findInsuredByPrimaryKey", query = "select myInsured from Insured myInsured where myInsured.insuredId = ?1"),
		@NamedQuery(name = "findInsuredByState", query = "select myInsured from Insured myInsured where myInsured.state = ?1"),
		@NamedQuery(name = "findInsuredByStateContaining", query = "select myInsured from Insured myInsured where myInsured.state like ?1"),
		@NamedQuery(name = "findInsuredByStatus", query = "select myInsured from Insured myInsured where myInsured.status = ?1"),
		@NamedQuery(name = "findInsuredByStatusContaining", query = "select myInsured from Insured myInsured where myInsured.status like ?1"),
		@NamedQuery(name = "findInsuredByTelephone", query = "select myInsured from Insured myInsured where myInsured.telephone = ?1"),
		@NamedQuery(name = "findInsuredByTelephoneContaining", query = "select myInsured from Insured myInsured where myInsured.telephone like ?1"),
		@NamedQuery(name = "findInsuredByTitle", query = "select myInsured from Insured myInsured where myInsured.title = ?1"),
		@NamedQuery(name = "findInsuredByTitleContaining", query = "select myInsured from Insured myInsured where myInsured.title like ?1"),
		@NamedQuery(name = "findInsuredByClaimNoAndOccurrence", query = "select myInsured from Insured myInsured where myInsured.claimNo = ?1 and myInsured.occurrence = ?2"),
		@NamedQuery(name = "findInsuredByCompanyClaimNoOccurencePolicyNo", query = "select myInsured from Insured myInsured where myInsured.claimNo = ?1 and myInsured.occurrence = ?2 and myInsured.policyNo=?3") })
@Table(name = "INSURED")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "Insured")
public class Insured extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "insuredSequence")
	@SequenceGenerator(name = "insuredSequence", sequenceName = "s_insured")
	@Column(name = "INSUREDID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long insuredId;
	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "TITLE", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String title;
	/**
	 */

	@Column(name = "FIRSTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(FIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	/**
	 */

	@Column(name = "LASTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(LASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	/**
	 */

	@Column(name = "GENDER", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String gender;
	/**
	 */

	@Column(name = "DOB", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(DOB, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dob;
	/**
	 */

	@Column(name = "NATIONALID", length = 15, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(NATIONALID, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String nationalId;
	/**
	 */

	@Column(name = "STATUS", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;
	/**
	 */

	@Column(name = "BANKRUPTCYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankruptcyInd;
	
	@Column(name = "BANKRUPTCYDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Date bankruptcyDt;
	

	@Column(name = "BLACKLISTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistInd;
	/**
	 */

	@Column(name = "AMLOIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String amloInd;
	/**
	 */

	@Column(name = "OFACIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String ofacInd;
	/**
	 */

	@Column(name = "FATCAIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fatcaInd;
	/**
	 */

	@Column(name = "SECIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String secInd;
	/**
	 */

	@Column(name = "ONCBIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String oncbInd;
	/**
	 */

	@Column(name = "POLITICALIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String politicalInd;
	/**
	 */

	@Column(name = "SUSPENSEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspenseInd;
	/**
	 */

	@Column(name = "WATCHLISTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String watchlistInd;
	/**
	 */

	@Column(name = "ADDRESSLINE1", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE1, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;
	/**
	 */

	@Column(name = "ADDRESSLINE2", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE2, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;
	/**
	 */

	@Column(name = "ADDRESSLINE3", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE3, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;
	/**
	 */

	@Column(name = "ADDRESSLINE4", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE4, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;
	/**
	 */

	@Column(name = "CITY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String city;
	/**
	 */

	@Column(name = "STATE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String state;
	/**
	 */

	@Column(name = "POSTALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postalCode;
	/**
	 */

	@Column(name = "COUNTRY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String country;
	/**
	 */

	@Column(name = "EMAILADDRESS", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String emailAddress;
	/**
	 */

	@Column(name = "MOBILE", length = 20, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MOBILE, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String mobile;
	/**
	 */

	@Column(name = "TELEPHONE", length = 20, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(TELEPHONE, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String telephone;
	/**
	 */
	@Column(name = "INITIALEFFECTIVEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date initialEffectiveDt;
	/**
	 */
	@Column(name = "EFFECTIVEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveDt;

	/**
	 * @return the insuredId
	 */
	public Long getInsuredId() {
		return insuredId;
	}

	/**
	 * @param insuredId the insuredId to set
	 */
	public void setInsuredId(Long insuredId) {
		this.insuredId = insuredId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the nationalId
	 */
	public String getNationalId() {
		return nationalId;
	}

	/**
	 * @param status the nationalId to set
	 */
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	/**
	 * @param nationalId the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * @return the bankruptcyInd
	 */
	public String getBankruptcyInd() {
		return bankruptcyInd;
	}

	/**
	 * @param bankruptcyInd the bankruptcyInd to set
	 */
	public void setBankruptcyInd(String bankruptcyInd) {
		this.bankruptcyInd = bankruptcyInd;
	}

	
	public Date getBankruptcyDt() {
		return bankruptcyDt;
	}

	public void setBankruptcyDt(Date bankruptcyDt) {
		this.bankruptcyDt = bankruptcyDt;
	}

	/**
	 * @return the blacklistInd
	 */
	public String getBlacklistInd() {
		return blacklistInd;
	}

	/**
	 * @param blacklistInd the blacklistInd to set
	 */
	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	/**
	 * @return the amloInd
	 */
	public String getAmloInd() {
		return amloInd;
	}

	/**
	 * @param amloInd the amloInd to set
	 */
	public void setAmloInd(String amloInd) {
		this.amloInd = amloInd;
	}

	/**
	 * @return the ofacInd
	 */
	public String getOfacInd() {
		return ofacInd;
	}

	/**
	 * @param ofacInd the ofacInd to set
	 */
	public void setOfacInd(String ofacInd) {
		this.ofacInd = ofacInd;
	}

	/**
	 * @return the fatcaInd
	 */
	public String getFatcaInd() {
		return fatcaInd;
	}

	/**
	 * @param fatcaInd the fatcaInd to set
	 */
	public void setFatcaInd(String fatcaInd) {
		this.fatcaInd = fatcaInd;
	}

	/**
	 * @return the secInd
	 */
	public String getSecInd() {
		return secInd;
	}

	/**
	 * @param secInd the secInd to set
	 */
	public void setSecInd(String secInd) {
		this.secInd = secInd;
	}

	public String getOncbInd() {
		return oncbInd;
	}

	public void setOncbInd(String oncbInd) {
		this.oncbInd = oncbInd;
	}

	/**
	 * @return the politicalInd
	 */
	public String getPoliticalInd() {
		return politicalInd;
	}

	/**
	 * @param politicalInd the politicalInd to set
	 */
	public void setPoliticalInd(String politicalInd) {
		this.politicalInd = politicalInd;
	}

	/**
	 * @return the suspenseInd
	 */
	public String getSuspenseInd() {
		return suspenseInd;
	}

	/**
	 * @param suspenseInd the suspenseInd to set
	 */
	public void setSuspenseInd(String suspenseInd) {
		this.suspenseInd = suspenseInd;
	}

	/**
	 * @return the watchlistInd
	 */
	public String getWatchlistInd() {
		return watchlistInd;
	}

	/**
	 * @param watchlistInd the watchlistInd to set
	 */
	public void setWatchlistInd(String watchlistInd) {
		this.watchlistInd = watchlistInd;
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 * @return the addressLine4
	 */
	public String getAddressLine4() {
		return addressLine4;
	}

	/**
	 * @param addressLine4 the addressLine4 to set
	 */
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @param initialEffectiveDt the initialEffectiveDt to set
	 */
	public void setInitialEffectiveDt(Date initialEffectiveDt) {
		this.initialEffectiveDt = initialEffectiveDt;
	}

	/**
	 * @return the initialEffectiveDt
	 */
	public Date getInitialEffectiveDt() {
		return this.initialEffectiveDt;
	}

	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 * @return the effectiveDt
	 */
	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	/**
	 */
	public Insured() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Insured that) {
		setInsuredId(that.getInsuredId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setTitle(that.getTitle());
		setFirstName(that.getFirstName());
		setLastName(that.getLastName());
		setGender(that.getGender());
		setDob(that.getDob());
		setNationalId(that.getNationalId());
		setBankruptcyInd(that.getBankruptcyInd());
		setBankruptcyDt(that.getBankruptcyDt());
		setBlacklistInd(that.getBlacklistInd());
		setAmloInd(that.getAmloInd());
		setOfacInd(that.getOfacInd());
		setFatcaInd(that.getFatcaInd());
		setAddressLine1(that.getAddressLine1());
		setAddressLine2(that.getAddressLine2());
		setAddressLine3(that.getAddressLine3());
		setAddressLine4(that.getAddressLine4());
		setCity(that.getCity());
		setState(that.getState());
		setPostalCode(that.getPostalCode());
		setCountry(that.getCountry());
		setEmailAddress(that.getEmailAddress());
		setMobile(that.getMobile());
		setTelephone(that.getTelephone());
		setInitialEffectiveDt(that.getInitialEffectiveDt());
		setEffectiveDt(that.getEffectiveDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("insuredId=[").append(insuredId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("title=[").append(title).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("gender=[").append(gender).append("] ");
		buffer.append("dob=[").append(dob).append("] ");
		buffer.append("nationalId=[").append(nationalId).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("bankruptcyInd=[").append(bankruptcyInd).append("] ");
		buffer.append("bankruptcyDt=[").append(bankruptcyDt).append("] ");
		buffer.append("blacklistInd=[").append(blacklistInd).append("] ");
		buffer.append("amloInd=[").append(amloInd).append("] ");
		buffer.append("ofacInd=[").append(ofacInd).append("] ");
		buffer.append("fatcaInd=[").append(fatcaInd).append("] ");
		buffer.append("addressLine1=[").append(addressLine1).append("] ");
		buffer.append("addressLine2=[").append(addressLine2).append("] ");
		buffer.append("addressLine3=[").append(addressLine3).append("] ");
		buffer.append("addressLine4=[").append(addressLine4).append("] ");
		buffer.append("city=[").append(city).append("] ");
		buffer.append("state=[").append(state).append("] ");
		buffer.append("postalCode=[").append(postalCode).append("] ");
		buffer.append("country=[").append(country).append("] ");
		buffer.append("emailAddress=[").append(emailAddress).append("] ");
		buffer.append("mobile=[").append(mobile).append("] ");
		buffer.append("telephone=[").append(telephone).append("] ");
		buffer.append("initialEffectiveDt=[").append(initialEffectiveDt).append("] ");
		buffer.append("effectiveDt=[").append(effectiveDt).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((insuredId == null) ? 0 : insuredId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Insured))
			return false;
		Insured equalCheck = (Insured) obj;
		if ((insuredId == null && equalCheck.insuredId != null) || (insuredId != null && equalCheck.insuredId == null))
			return false;
		if (insuredId != null && !insuredId.equals(equalCheck.insuredId))
			return false;
		return true;
	}
}
