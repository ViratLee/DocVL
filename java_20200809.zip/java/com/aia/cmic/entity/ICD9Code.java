package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllICD9Codes", query = "select myICD9Code from ICD9Code myICD9Code"),
		@NamedQuery(name = "findICD9CodeByICD9Code", query = "select myICD9Code from ICD9Code myICD9Code where myICD9Code.icd9Code = ?1 "),
		@NamedQuery(name = "findICD9CodeByFieldContaining", query = "select myICD9Code from ICD9Code myICD9Code where UPPER(myICD9Code.icd9Code || '.' || myICD9Code.icdSubCode) like ?1 or UPPER(myICD9Code.subCodeLongDesc) like ?2"),
		@NamedQuery(name = "findICD9CodeByProcedureCode", query = "select myICD9Code from ICD9Code myICD9Code where myICD9Code.icd9Code =?1 and ( myICD9Code.icdSubCode = ?2 or  ?2 is null or ?2='')  order by createdDt desc "),
		@NamedQuery(name = "findICD9CodeByICD9CodeAndICDSubCode", query = "select myICD9Code from ICD9Code myICD9Code where myICD9Code.icd9Code = ?1 and myICD9Code.icdSubCode = ?2 ") })
@Table(name = "ICD9CODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ICD9Code")
public class ICD9Code extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "icd9CodeSequence")
	@SequenceGenerator(name = "icd9CodeSequence", sequenceName = "s_icd9code")
	@Column(name = "ICD9ID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long icd9Id;
	/**
	 */

	@Column(name = "ICD9CODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd9Code;
	/**
	 */

	@Column(name = "ICDSUBCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icdSubCode;
	/**
	 */

	@Column(name = "SUBCODEDESC", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subCodeDesc;
	/**
	 */

	@Column(name = "SUBCODELONGDESC", length = 255, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subCodeLongDesc;
	/**
	 */

	@Column(name = "ICD9CATEGORY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd9Category;

	@Column(name = "WAITINGPERIOD")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer waitingPeriod;
	/**
	 */

	@Column(name = "EXCLUSIONIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusionInd;
	/**
	 */

	@Column(name = "ICUIND", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icuInd;
	/**
	 */

	@Column(name = "AGEFROM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer ageFrom;
	/**
	 */

	@Column(name = "AGETO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer ageTo;
	/**
	 */

	@Column(name = "GENDER", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String gender;
	/**
	 */

	@Column(name = "LIFETIMEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lifetimeInd;
	/**
	 */

	@Column(name = "ASSISTSURGEONIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String assistSurgeonInd;
	/**
	 */

	@Column(name = "ANAESTHETISTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String anaesthetistInd;
	/**
	 */

	@Column(name = "SUSPECTPREEXISTCONDITION", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspectPreExistCondition;
	/**
	 */

	@Column(name = "SURGICALPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgicalPercentage;
	/**
	 */

	@Column(name = "SURGICAL1946PERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgical1946Percentage;
	/**
	 */

	@Column(name = "SURGICAL1960OPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgical1960OPercentage;
	/**
	 */

	@Column(name = "SURGICAL1960NPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgical1960NPercentage;
	/**
	 */

	@Column(name = "SURGICAL7000PERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgical7000Percentage;
	
	@Column(name = "SURGICAL30100PERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal surgical30100Percentage;

	/**
	 * @return the icd9Id
	 */
	public Long getIcd9Id() {
		return icd9Id;
	}

	/**
	 * @param icd9Id the icd9Id to set
	 */
	public void setIcd9Id(Long icd9Id) {
		this.icd9Id = icd9Id;
	}

	/**
	 * @return the icd9Code
	 */
	public String getIcd9Code() {
		return icd9Code;
	}

	/**
	 * @param icd9Code the icd9Code to set
	 */
	public void setIcd9Code(String icd9Code) {
		this.icd9Code = icd9Code;
	}

	/**
	 * @return the icdSubCode
	 */
	public String getIcdSubCode() {
		return icdSubCode;
	}

	/**
	 * @param icdSubCode the icdSubCode to set
	 */
	public void setIcdSubCode(String icdSubCode) {
		this.icdSubCode = icdSubCode;
	}

	/**
	 * @return the subCodeDesc
	 */
	public String getSubCodeDesc() {
		return subCodeDesc;
	}

	/**
	 * @param subCodeDesc the subCodeDesc to set
	 */
	public void setSubCodeDesc(String subCodeDesc) {
		this.subCodeDesc = subCodeDesc;
	}

	public String getSubCodeLongDesc() {
		return subCodeLongDesc;
	}

	public void setSubCodeLongDesc(String subCodeLongDesc) {
		this.subCodeLongDesc = subCodeLongDesc;
	}

	public String getIcd9Category() {
		return icd9Category;
	}

	public void setIcd9Category(String icd9Category) {
		this.icd9Category = icd9Category;
	}

	/**
	 * @return the waitingPeriod
	 */
	public Integer getWaitingPeriod() {
		return waitingPeriod;
	}

	/**
	 * @param waitingPeriod the waitingPeriod to set
	 */
	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	/**
	 * @return the exclusionInd
	 */
	public String getExclusionInd() {
		return exclusionInd;
	}

	/**
	 * @param exclusionInd the exclusionInd to set
	 */
	public void setExclusionInd(String exclusionInd) {
		this.exclusionInd = exclusionInd;
	}

	/**
	 * @return the icuInd
	 */
	public String getIcuInd() {
		return icuInd;
	}

	/**
	 * @param icuInd the icuInd to set
	 */
	public void setIcuInd(String icuInd) {
		this.icuInd = icuInd;
	}

	/**
	 * @return the ageFrom
	 */
	public Integer getAgeFrom() {
		return ageFrom;
	}

	/**
	 * @param ageFrom the ageFrom to set
	 */
	public void setAgeFrom(Integer ageFrom) {
		this.ageFrom = ageFrom;
	}

	/**
	 * @return the ageTo
	 */
	public Integer getAgeTo() {
		return ageTo;
	}

	/**
	 * @param ageTo the ageTo to set
	 */
	public void setAgeTo(Integer ageTo) {
		this.ageTo = ageTo;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the lifetimeInd
	 */
	public String getLifetimeInd() {
		return lifetimeInd;
	}

	/**
	 * @param lifetimeInd the lifetimeInd to set
	 */
	public void setLifetimeInd(String lifetimeInd) {
		this.lifetimeInd = lifetimeInd;
	}

	/**
	 * @return the assistSurgeonInd
	 */
	public String getAssistSurgeonInd() {
		return assistSurgeonInd;
	}

	/**
	 * @param assistSurgeonInd the assistSurgeonInd to set
	 */
	public void setAssistSurgeonInd(String assistSurgeonInd) {
		this.assistSurgeonInd = assistSurgeonInd;
	}

	/**
	 * @return the anaesthetistInd
	 */
	public String getAnaesthetistInd() {
		return anaesthetistInd;
	}

	/**
	 * @param anaesthetistInd the anaesthetistInd to set
	 */
	public void setAnaesthetistInd(String anaesthetistInd) {
		this.anaesthetistInd = anaesthetistInd;
	}

	/**
	 * @return the suspectPreExistCondition
	 */
	public String getSuspectPreExistCondition() {
		return suspectPreExistCondition;
	}

	/**
	 * @param suspectPreExistCondition the suspectPreExistCondition to set
	 */
	public void setSuspectPreExistCondition(String suspectPreExistCondition) {
		this.suspectPreExistCondition = suspectPreExistCondition;
	}

	/**
	 * @return the surgicalPercentage
	 */
	public BigDecimal getSurgicalPercentage() {
		return surgicalPercentage;
	}

	/**
	 * @param surgicalPercentage the surgicalPercentage to set
	 */
	public void setSurgicalPercentage(BigDecimal surgicalPercentage) {
		this.surgicalPercentage = surgicalPercentage;
	}

	/**
	 * @return the surgical1946Percentage
	 */
	public BigDecimal getSurgical1946Percentage() {
		return surgical1946Percentage;
	}

	/**
	 * @param surgical1946Percentage the surgical1946Percentage to set
	 */
	public void setSurgical1946Percentage(BigDecimal surgical1946Percentage) {
		this.surgical1946Percentage = surgical1946Percentage;
	}

	/**
	 * @return the surgical1960OPercentage
	 */
	public BigDecimal getSurgical1960OPercentage() {
		return surgical1960OPercentage;
	}

	/**
	 * @param surgical1960oPercentage the surgical1960OPercentage to set
	 */
	public void setSurgical1960OPercentage(BigDecimal surgical1960oPercentage) {
		surgical1960OPercentage = surgical1960oPercentage;
	}

	/**
	 * @return the surgical1960NPercentage
	 */
	public BigDecimal getSurgical1960NPercentage() {
		return surgical1960NPercentage;
	}

	/**
	 * @param surgical1960nPercentage the surgical1960NPercentage to set
	 */
	public void setSurgical1960NPercentage(BigDecimal surgical1960nPercentage) {
		surgical1960NPercentage = surgical1960nPercentage;
	}

	/**
	 * @return the surgical7000Percentage
	 */
	public BigDecimal getSurgical7000Percentage() {
		return surgical7000Percentage;
	}

	/**
	 * @param surgical7000Percentage the surgical7000Percentage to set
	 */
	public void setSurgical7000Percentage(BigDecimal surgical7000Percentage) {
		this.surgical7000Percentage = surgical7000Percentage;
	}
	
	/**
	 * @return the surgical30100Percentage
	 */
	public BigDecimal getSurgical30100Percentage() {
		return surgical30100Percentage;
	}

	/**
	 * @param surgical30100Percentage the surgical30100Percentage to set
	 */
	public void setSurgical30100Percentage(BigDecimal surgical30100Percentage) {
		this.surgical30100Percentage = surgical30100Percentage;
	}

	/**
	 */
	public ICD9Code() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ICD9Code that) {
		setIcd9Id(that.getIcd9Id());
		setIcd9Code(that.getIcd9Code());
		setIcdSubCode(that.getIcdSubCode());
		setSubCodeDesc(that.getSubCodeDesc());
		setSubCodeLongDesc(that.getSubCodeLongDesc());
		setIcd9Category(that.getIcd9Category());
		setWaitingPeriod(that.getWaitingPeriod());
		setExclusionInd(that.getExclusionInd());
		setIcuInd(that.getIcuInd());
		setAgeFrom(that.getAgeFrom());
		setAgeTo(that.getAgeTo());
		setGender(that.getGender());
		setLifetimeInd(that.getLifetimeInd());
		setAssistSurgeonInd(that.getAssistSurgeonInd());
		setAnaesthetistInd(that.getAnaesthetistInd());
		setSuspectPreExistCondition(that.getSuspectPreExistCondition());
		setSurgicalPercentage(that.getSurgicalPercentage());
		setSurgical1946Percentage(that.getSurgical1946Percentage());
		setSurgical1960OPercentage(that.getSurgical1960OPercentage());
		setSurgical1960NPercentage(that.getSurgical1960NPercentage());
		setSurgical7000Percentage(that.getSurgical7000Percentage());
		setSurgical30100Percentage(that.getSurgical30100Percentage());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("icd9Id=[").append(icd9Id).append("] ");
		buffer.append("icd9Code=[").append(icd9Code).append("] ");
		buffer.append("icdSubCode=[").append(icdSubCode).append("] ");
		buffer.append("subCodeDesc=[").append(subCodeDesc).append("] ");
		buffer.append("subCodeLongDesc=[").append(subCodeLongDesc).append("] ");
		buffer.append("icd9Category=[").append(icd9Category).append("] ");
		buffer.append("waitingPeriod=[").append(waitingPeriod).append("] ");
		buffer.append("exclusionInd=[").append(exclusionInd).append("] ");
		buffer.append("icuInd=[").append(icuInd).append("] ");
		buffer.append("ageFrom=[").append(ageFrom).append("] ");
		buffer.append("ageTo=[").append(ageTo).append("] ");
		buffer.append("gender=[").append(gender).append("] ");
		buffer.append("lifetimeInd=[").append(lifetimeInd).append("] ");
		buffer.append("assistSurgeonInd=[").append(assistSurgeonInd).append("] ");
		buffer.append("anaesthetistInd=[").append(anaesthetistInd).append("] ");
		buffer.append("suspectPreExistCondition=[").append(suspectPreExistCondition).append("] ");
		buffer.append("surgicalPercentage=[").append(surgicalPercentage).append("] ");
		buffer.append("surgical1946Percentage=[").append(surgical1946Percentage).append("] ");
		buffer.append("surgical1960OPercentage=[").append(surgical1960OPercentage).append("] ");
		buffer.append("surgical1960NPercentage=[").append(surgical1960NPercentage).append("] ");
		buffer.append("surgical7000Percentage=[").append(surgical7000Percentage).append("] ");
		buffer.append("surgical30100Percentage=[").append(surgical30100Percentage).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((icd9Id == null) ? 0 : icd9Id.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ICD9Code))
			return false;
		ICD9Code equalCheck = (ICD9Code) obj;
		if ((icd9Id == null && equalCheck.icd9Id != null) || (icd9Id != null && equalCheck.icd9Id == null))
			return false;
		if (icd9Id != null && !icd9Id.equals(equalCheck.icd9Id))
			return false;
		return true;
	}

}
