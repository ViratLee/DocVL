package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "EDIBILLINGITEM")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "EdiBillingItem")
public class EdiBillingItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ediBillingItemSequence")
	@SequenceGenerator(name = "ediBillingItemSequence", sequenceName = "s_edibillingitem")
	@Column(name = "EDIBILLINGITEMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long ediBillingItemId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "LOCALBILLINGCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String localBillingCode;

	@Column(name = "SIMBBILLINGCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String simbBillingCode;

	@Column(name = "AIABILLINGCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String aiaBillingCode;

	@Column(name = "BILLINGINITIAL", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal billingInitial;

	@Column(name = "BILLINGDISCOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal billingDiscount;

	@Column(name = "BILLINGNETAMOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal billingNetAmount;

	@Column(name = "LOCALBILLINGNAME", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String localBillingName;

	/**
	 */
	public EdiBillingItem() {
	}

	public Long getEdiBillingItemId() {
		return ediBillingItemId;
	}

	public void setEdiBillingItemId(Long ediBillingItemId) {
		this.ediBillingItemId = ediBillingItemId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getLocalBillingCode() {
		return localBillingCode;
	}

	public void setLocalBillingCode(String localBillingCode) {
		this.localBillingCode = setMaxLength("localBillingCode", localBillingCode);
	}

	public String getSimbBillingCode() {
		return simbBillingCode;
	}

	public void setSimbBillingCode(String simbBillingCode) {
		this.simbBillingCode = setMaxLength("simbBillingCode", simbBillingCode);
	}

	public String getAiaBillingCode() {
		return aiaBillingCode;
	}

	public void setAiaBillingCode(String aiaBillingCode) {
		this.aiaBillingCode = setMaxLength("aiaBillingCode", aiaBillingCode);
	}

	public BigDecimal getBillingInitial() {
		return billingInitial;
	}

	public void setBillingInitial(BigDecimal billingInitial) {
		this.billingInitial = billingInitial;
	}

	public BigDecimal getBillingDiscount() {
		return billingDiscount;
	}

	public void setBillingDiscount(BigDecimal billingDiscount) {
		this.billingDiscount = billingDiscount;
	}

	public BigDecimal getBillingNetAmount() {
		return billingNetAmount;
	}

	public void setBillingNetAmount(BigDecimal billingNetAmount) {
		this.billingNetAmount = billingNetAmount;
	}

	public String getLocalBillingName() {
		return localBillingName;
	}

	public void setLocalBillingName(String localBillingName) {
		this.localBillingName = setMaxLength("localBillingName", localBillingName);
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(EdiBillingItem that) {

		setEdiBillingItemId(that.getEdiBillingItemId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setLocalBillingCode(that.getLocalBillingCode());
		setSimbBillingCode(that.getSimbBillingCode());
		setAiaBillingCode(that.getAiaBillingCode());
		setBillingInitial(that.getBillingInitial());
		setBillingDiscount(that.getBillingDiscount());
		setBillingNetAmount(that.getBillingNetAmount());
		setLocalBillingName(that.getLocalBillingName());

	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("ediBillingItemId=[").append(ediBillingItemId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("localBillingCode=[").append(localBillingCode).append("] ");
		buffer.append("simbBillingCode=[").append(simbBillingCode).append("] ");
		buffer.append("aiaBillingCode=[").append(aiaBillingCode).append("] ");
		buffer.append("billingInitial=[").append(billingInitial).append("] ");
		buffer.append("billingDiscount=[").append(billingDiscount).append("] ");
		buffer.append("billingNetAmount=[").append(billingNetAmount).append("] ");
		buffer.append("localBillingName=[").append(localBillingName).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((ediBillingItemId == null) ? 0 : ediBillingItemId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof EdiBillingItem))
			return false;
		EdiBillingItem equalCheck = (EdiBillingItem) obj;
		if ((ediBillingItemId == null && equalCheck.ediBillingItemId != null) || (ediBillingItemId != null && equalCheck.ediBillingItemId == null))
			return false;
		if (ediBillingItemId != null && !ediBillingItemId.equals(equalCheck.ediBillingItemId))
			return false;
		return true;
	}

	private String setMaxLength(String columnName, String data) {
		if (data == null) {
			return data;
		}
		try {
			int size = getClass().getDeclaredField(columnName).getAnnotation(Column.class).length();
			int inLength = data.length();
			if (inLength > size) {
				data = data.substring(0, size);
			}
		} catch (NoSuchFieldException ex) {
		} catch (SecurityException ex) {
		}
		return data;
	}
}
