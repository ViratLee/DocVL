package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllPendingCodes", query = "select myPendingCode from PendingCode myPendingCode"),
		@NamedQuery(name = "findPendingCodeByFormNo", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.formNo = ?1"),
		@NamedQuery(name = "findPendingCodeByFormNoContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.formNo like ?1"),
		@NamedQuery(name = "findPendingCodeByInterval", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.interval = ?1"),
		@NamedQuery(name = "findPendingCodeByIntervalContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.interval like ?1"),
		@NamedQuery(name = "findPendingCodeByMemoId", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.memoId = ?1"),
		@NamedQuery(name = "findPendingCodeByMemoIdContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.memoId like ?1"),
		@NamedQuery(name = "findPendingCodeByMemoText", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.memoText = ?1"),
		@NamedQuery(name = "findPendingCodeByMemoTextContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.memoText like ?1"),
		@NamedQuery(name = "findPendingCodeByNoOfReminder", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.noOfReminder = ?1"),
		@NamedQuery(name = "findPendingCodeByNoOfReminderContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.noOfReminder like ?1"),
		@NamedQuery(name = "findPendingCodeByOpt", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.opt = ?1"),
		@NamedQuery(name = "findPendingCodeByOptContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.opt like ?1"),
		@NamedQuery(name = "findPendingCodeByPendingCodeField", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingCodeField = ?1"),
		@NamedQuery(name = "findPendingCodeByPendingCodeFieldContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingCodeField like ?1"),
		@NamedQuery(name = "findPendingCodeByPendingDesc", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingDesc = ?1"),
		@NamedQuery(name = "findPendingCodeByPendingDescContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingDesc like ?1"),
		@NamedQuery(name = "findPendingCodeByPendingDescThai", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingDescThai = ?1"),
		@NamedQuery(name = "findPendingCodeByPendingDescThaiContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingDescThai like ?1"),
		@NamedQuery(name = "findPendingCodeByPrimaryKey", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.pendingCodeField = ?1"),
		@NamedQuery(name = "findPendingCodeByReminderId", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.reminderId = ?1"),
		@NamedQuery(name = "findPendingCodeByReminderIdContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.reminderId like ?1"),
		@NamedQuery(name = "findPendingCodeByText", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.text = ?1"),
		@NamedQuery(name = "findPendingCodeByTextContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.text like ?1"),
		@NamedQuery(name = "findPendingCodeByVersInd", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.versInd = ?1"),
		@NamedQuery(name = "findPendingCodeByVersIndContaining", query = "select myPendingCode from PendingCode myPendingCode where myPendingCode.versInd like ?1") })
@Table(name = "PENDINGCODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "PendingCode")
public class PendingCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "PENDINGCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String pendingCodeField;
	/**
	 */

	@Column(name = "PENDINGDESC", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String pendingDesc;
	/**
	 */

	@Column(name = "PENDINGDESCTHAI")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String pendingDescThai;
	/**
	 */

	@Column(name = "NOOFREMINDER", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String noOfReminder;
	/**
	 */

	@Column(name = "INTERVAL", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String interval;
	/**
	 */

	@Column(name = "MEMOID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memoId;
	/**
	 */

	@Column(name = "REMINDERID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String reminderId;
	/**
	 */

	@Column(name = "OPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String opt;
	/**
	 */

	@Column(name = "TEXT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String text;
	/**
	 */

	@Column(name = "FORMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String formNo;
	/**
	 */

	@Column(name = "MEMOTEXT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memoText;
	/**
	 */

	@Column(name = "VERSIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String versInd;
	/**
	 */



	/**
	 * @return the pendingCodeField
	 */
	public String getPendingCodeField() {
		return pendingCodeField;
	}

	/**
	 * @param pendingCodeField the pendingCodeField to set
	 */
	public void setPendingCodeField(String pendingCodeField) {
		this.pendingCodeField = pendingCodeField;
	}

	/**
	 * @return the pendingDesc
	 */
	public String getPendingDesc() {
		return pendingDesc;
	}

	/**
	 * @param pendingDesc the pendingDesc to set
	 */
	public void setPendingDesc(String pendingDesc) {
		this.pendingDesc = pendingDesc;
	}

	/**
	 * @return the pendingDescThai
	 */
	public String getPendingDescThai() {
		return pendingDescThai;
	}

	/**
	 * @param pendingDescThai the pendingDescThai to set
	 */
	public void setPendingDescThai(String pendingDescThai) {
		this.pendingDescThai = pendingDescThai;
	}

	/**
	 * @return the noOfReminder
	 */
	public String getNoOfReminder() {
		return noOfReminder;
	}

	/**
	 * @param noOfReminder the noOfReminder to set
	 */
	public void setNoOfReminder(String noOfReminder) {
		this.noOfReminder = noOfReminder;
	}

	/**
	 * @return the interval
	 */
	public String getInterval() {
		return interval;
	}

	/**
	 * @param interval the interval to set
	 */
	public void setInterval(String interval) {
		this.interval = interval;
	}

	/**
	 * @return the memoId
	 */
	public String getMemoId() {
		return memoId;
	}

	/**
	 * @param memoId the memoId to set
	 */
	public void setMemoId(String memoId) {
		this.memoId = memoId;
	}

	/**
	 * @return the reminderId
	 */
	public String getReminderId() {
		return reminderId;
	}

	/**
	 * @param reminderId the reminderId to set
	 */
	public void setReminderId(String reminderId) {
		this.reminderId = reminderId;
	}

	/**
	 * @return the opt
	 */
	public String getOpt() {
		return opt;
	}

	/**
	 * @param opt the opt to set
	 */
	public void setOpt(String opt) {
		this.opt = opt;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @return the formNo
	 */
	public String getFormNo() {
		return formNo;
	}

	/**
	 * @param formNo the formNo to set
	 */
	public void setFormNo(String formNo) {
		this.formNo = formNo;
	}

	/**
	 * @return the memoText
	 */
	public String getMemoText() {
		return memoText;
	}

	/**
	 * @param memoText the memoText to set
	 */
	public void setMemoText(String memoText) {
		this.memoText = memoText;
	}

	/**
	 * @return the versInd
	 */
	public String getVersInd() {
		return versInd;
	}

	/**
	 * @param versInd the versInd to set
	 */
	public void setVersInd(String versInd) {
		this.versInd = versInd;
	}

	
	/**
	 */
	public PendingCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(PendingCode that) {
		setPendingCodeField(that.getPendingCodeField());
		setPendingDesc(that.getPendingDesc());
		setPendingDescThai(that.getPendingDescThai());
		setNoOfReminder(that.getNoOfReminder());
		setInterval(that.getInterval());
		setMemoId(that.getMemoId());
		setReminderId(that.getReminderId());
		setOpt(that.getOpt());
		setText(that.getText());
		setFormNo(that.getFormNo());
		setMemoText(that.getMemoText());
		setVersInd(that.getVersInd());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("pendingCodeField=[").append(pendingCodeField).append("] ");
		buffer.append("pendingDesc=[").append(pendingDesc).append("] ");
		buffer.append("pendingDescThai=[").append(pendingDescThai).append("] ");
		buffer.append("noOfReminder=[").append(noOfReminder).append("] ");
		buffer.append("interval=[").append(interval).append("] ");
		buffer.append("memoId=[").append(memoId).append("] ");
		buffer.append("reminderId=[").append(reminderId).append("] ");
		buffer.append("opt=[").append(opt).append("] ");
		buffer.append("text=[").append(text).append("] ");
		buffer.append("formNo=[").append(formNo).append("] ");
		buffer.append("memoText=[").append(memoText).append("] ");
		buffer.append("versInd=[").append(versInd).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((pendingCodeField == null) ? 0 : pendingCodeField.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof PendingCode))
			return false;
		PendingCode equalCheck = (PendingCode) obj;
		if ((pendingCodeField == null && equalCheck.pendingCodeField != null) || (pendingCodeField != null && equalCheck.pendingCodeField == null))
			return false;
		if (pendingCodeField != null && !pendingCodeField.equals(equalCheck.pendingCodeField))
			return false;
		return true;
	}
}
