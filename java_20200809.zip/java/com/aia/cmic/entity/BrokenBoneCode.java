package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllBrokenBoneCodes", query = "select myBrokenBoneCode from BrokenBoneCode myBrokenBoneCode"),
		@NamedQuery(name = "findBrokenBoneCodeByPrimaryKey", query = "select myBrokenBoneCode from BrokenBoneCode myBrokenBoneCode where myBrokenBoneCode.brokenBoneCode = ?1"),
		@NamedQuery(name = "findBrokenBoneCodeByFieldContaining", query = "select myBrokenBoneCode from BrokenBoneCode myBrokenBoneCode where myBrokenBoneCode.codeDesc like ?1 or myBrokenBoneCode.codeDescThai like ?2") })
@Table(name = "BROKENBONECODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "BrokenBoneCode")
public class BrokenBoneCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "BROKENBONECODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String brokenBoneCode;
	/**
	 */

	@Column(name = "CODEDESC", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeDesc;
	/**
	 */

	@Column(name = "CODEDESCTHAI", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeDescThai;
	/**
	 */

	@Column(name = "BBPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal bbPercentage;

	/**
	 */
	public void setBrokenBoneCode(String brokenBoneCode) {
		this.brokenBoneCode = brokenBoneCode;
	}

	/**
	 */
	public String getBrokenBoneCode() {
		return this.brokenBoneCode;
	}

	/**
	 */
	public void setCodeDesc(String codeDesc) {
		this.codeDesc = codeDesc;
	}

	/**
	 */
	public String getCodeDesc() {
		return this.codeDesc;
	}

	/**
	 */
	public void setCodeDescThai(String codeDescThai) {
		this.codeDescThai = codeDescThai;
	}

	/**
	 */
	public String getCodeDescThai() {
		return this.codeDescThai;
	}

	/**
	 */
	public void setBbPercentage(BigDecimal bbPercentage) {
		this.bbPercentage = bbPercentage;
	}

	/**
	 */
	public BigDecimal getBbPercentage() {
		return this.bbPercentage;
	}

	/**
	 */
	public BrokenBoneCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(BrokenBoneCode that) {
		setBrokenBoneCode(that.getBrokenBoneCode());
		setCodeDesc(that.getCodeDesc());
		setCodeDescThai(that.getCodeDescThai());
		setBbPercentage(that.getBbPercentage());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("brokenBoneCode=[").append(brokenBoneCode).append("] ");
		buffer.append("codeDesc=[").append(codeDesc).append("] ");
		buffer.append("codeDescThai=[").append(codeDescThai).append("] ");
		buffer.append("bbPercentage=[").append(bbPercentage).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((brokenBoneCode == null) ? 0 : brokenBoneCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof BrokenBoneCode))
			return false;
		BrokenBoneCode equalCheck = (BrokenBoneCode) obj;
		if ((brokenBoneCode == null && equalCheck.brokenBoneCode != null) || (brokenBoneCode != null && equalCheck.brokenBoneCode == null))
			return false;
		if (brokenBoneCode != null && !brokenBoneCode.equals(equalCheck.brokenBoneCode))
			return false;
		return true;
	}
}
