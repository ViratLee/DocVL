package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllMclWorkings", query = "select myMclWorking from MclWorking myMclWorking"),
		@NamedQuery(name = "findMclWorkingByAccountNo", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.accountNo = ?1"),
		@NamedQuery(name = "findMclWorkingByAccountNoContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.accountNo like ?1"),
		@NamedQuery(name = "findMclWorkingByBankCode", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.bankCode = ?1"),
		@NamedQuery(name = "findMclWorkingByBankCodeContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.bankCode like ?1"),
		@NamedQuery(name = "findMclWorkingByInsuredFirstName", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.insuredFirstName = ?1"),
		@NamedQuery(name = "findMclWorkingByInsuredFirstNameContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.insuredFirstName like ?1"),
		@NamedQuery(name = "findMclWorkingByInsuredLastName", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.insuredLastName = ?1"),
		@NamedQuery(name = "findMclWorkingByInsuredLastNameContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.insuredLastName like ?1"),
		@NamedQuery(name = "findMclWorkingByMclWorkingId", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.mclWorkingId = ?1"),
		@NamedQuery(name = "findMclWorkingByPayeeFirstName", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.payeeFirstName = ?1"),
		@NamedQuery(name = "findMclWorkingByPayeeFirstNameContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.payeeFirstName like ?1"),
		@NamedQuery(name = "findMclWorkingByPayeeLastName", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.payeeLastName = ?1"),
		@NamedQuery(name = "findMclWorkingByPayeeLastNameContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.payeeLastName like ?1"),
		@NamedQuery(name = "findMclWorkingByPolicyIssueDt", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.policyIssueDt = ?1"),
		@NamedQuery(name = "findMclWorkingByPolicyNo", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.policyNo = ?1"),
		@NamedQuery(name = "findMclWorkingByPolicyNoContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.policyNo like ?1"),
		@NamedQuery(name = "findMclWorkingByPrimaryKey", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.mclWorkingId = ?1"),
		@NamedQuery(name = "findMclWorkingByProviderId", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.providerCode = ?1"),
		@NamedQuery(name = "findMclWorkingByProviderIdContaining", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.providerCode like ?1"),
		@NamedQuery(name = "findMclWorkingByTransactionAmt", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.transactionAmt = ?1"),
		@NamedQuery(name = "findMclWorkingByTransactionDt", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.transactionDt = ?1"),
		@NamedQuery(name = "findMclWorkingWhenPostInvoiceFlagIsFalse", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.companyId= ?1 and myMclWorking.claimNo= ?2 and myMclWorking.occurrence = ?3 and myMclWorking.policyNo= ?4 and myMclWorking.bankCode=?5 and myMclWorking.accountNo=?6 and myMclWorking.lastModifiedUserDept=?7 and myMclWorking.lastModifiedUserDesk=?8 "),
		@NamedQuery(name = "findMclWorkingWhenPostInvoiceFlagIsFalse2", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.companyId= ?1 and myMclWorking.cycleDate =?2 and ( myMclWorking.payeeTitle =?3 or ?3 is null) and myMclWorking.payeeFirstName =?4 and myMclWorking.payeeLastName =?5 and ( myMclWorking.insuredTitle =?6 or ?6 is null ) and myMclWorking.insuredFirstName =?7 and myMclWorking.insuredLastName =?8 and myMclWorking.lastModifiedUserDept=?9 and myMclWorking.lastModifiedUserDesk=?10 "),
		@NamedQuery(name = "findMclWorkingWhenPostInvoiceFlagIsTrue", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.companyId= ?1 and myMclWorking.claimNo= ?2 and myMclWorking.occurrence = ?3 and myMclWorking.policyNo= ?4 and myMclWorking.mclTarget=?5 and  myMclWorking.cycleDate =?6"),
		@NamedQuery(name = "checkTransactionAmt", query = "select sum(myMclWorking.transactionAmt) as sumTransactionAmt,myMclWorking.companyId,myMclWorking.claimNo,myMclWorking.occurrence,myMclWorking.policyNo,myMclWorking.cycleDate,myMclWorking.payeeTitle,myMclWorking.payeeFirstName,myMclWorking.payeeLastName,myMclWorking.insuredTitle,myMclWorking.insuredFirstName,myMclWorking.insuredLastName from MclWorking myMclWorking where myMclWorking.companyId = ?1 and (myMclWorking.cycleDate between ?2 and ?3) group by myMclWorking.companyId,myMclWorking.claimNo,myMclWorking.occurrence,myMclWorking.policyNo,myMclWorking.cycleDate,myMclWorking.payeeTitle,myMclWorking.payeeFirstName,myMclWorking.payeeLastName,myMclWorking.insuredTitle,myMclWorking.insuredFirstName,myMclWorking.insuredLastName"),
		@NamedQuery(name = "checkTransactionAmtV2", query = "select sum(myMclWorking.transactionAmt) as sumTransactionAmt,myMclWorking.companyId,myMclWorking.claimNo,myMclWorking.occurrence,myMclWorking.policyNo,myMclWorking.cycleDate,myMclWorking.payeeTitle,myMclWorking.payeeFirstName,myMclWorking.payeeLastName,myMclWorking.insuredTitle,myMclWorking.insuredFirstName,myMclWorking.insuredLastName from MclWorking myMclWorking where myMclWorking.companyId = ?1 and (myMclWorking.cycleDate between ?2 and ?3) and ( myMclWorking.insuredTitle =?4 or ?4 is null ) and myMclWorking.insuredLastName =?5 and myMclWorking.insuredFirstName =?6 group by myMclWorking.companyId,myMclWorking.claimNo,myMclWorking.occurrence,myMclWorking.policyNo,myMclWorking.cycleDate,myMclWorking.payeeTitle,myMclWorking.payeeFirstName,myMclWorking.payeeLastName,myMclWorking.insuredTitle,myMclWorking.insuredFirstName,myMclWorking.insuredLastName"),
		@NamedQuery(name = "findMCLWorkingByFirstNameAndLastName", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.payeeTitle= ?1 and myMclWorking.payeeFirstName= ?2 and myMclWorking.payeeLastName = ?3 and myMclWorking.insuredTitle=?4 and myMclWorking.insuredFirstName=?5 and myMclWorking.insuredLastName=?6 and myMclWorking.cycleDate=?7"),
		@NamedQuery(name = "findMCLWorkingByFSURelated", query = "select myMclWorking from MclWorking myMclWorking where myMclWorking.fsuRelated like ?1"),
		@NamedQuery(name = "clearMCLWorking", query = "delete from MclWorking myMclWorking where myMclWorking.mclWorkingId= ?1"),
})
@Table(name = "MCLWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "MclWorking")
public class MclWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "mclWorkingSequence")
	@SequenceGenerator(name = "mclWorkingSequence", sequenceName = "s_mclworking")
	@Column(name = "MCLWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long mclWorkingId;
	/**
	 */
	@Column(name = "CYCLEDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date cycleDate;

	@Column(name = "MCLTARGET", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String mclTarget;

	/**
	 */

	@Column(name = "COMPANYID", length = 3, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */
	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	/**
	 */
	@Column(name = "TRANSACTIONDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date transactionDt;
	/**
	 */

	@Column(name = "PAYEETITLE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTitle;
	/**
	 */

	@Column(name = "PAYEELASTNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeLastName;
	/**
	 */

	@Column(name = "PAYEEFIRSTNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeFirstName;
	/**
	 */

	@Column(name = "INSUREDTITLE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredTitle;

	@Column(name = "INSUREDLASTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredLastName;
	/**
	 */

	@Column(name = "INSUREDFIRSTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredFirstName;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "TRANSACTIONAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal transactionAmt;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */
	@Column(name = "POLICYISSUEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyIssueDt;
	/**
	 */

	@Column(name = "BANKCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankCode;
	/**
	 */

	@Column(name = "ACCOUNTNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountNo;

	@Column(name = "LASTMODIFIEDUSERDEPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDept;

	@Column(name = "LASTMODIFIEDUSERDESK", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDesk;

	/**
	 */
	@Column(name = "CSFORMATPOLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csFormatPolicyNo;

	@Column(name = "SUSPENDCODE", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspendCode;

	@Column(name = "FSURELATED", length = 2000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fsuRelated;

	@Column(name = "CSIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csInd;

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;

	@Column(name = "CERTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String certNo;

	@Column(name = "AGENCYWRITINGCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String agencyWritingCode;

	/**
	 */
	public void setMclWorkingId(Long mclWorkingId) {
		this.mclWorkingId = mclWorkingId;
	}

	/**
	 */
	public Long getMclWorkingId() {
		return this.mclWorkingId;
	}

	public String getMclTarget() {
		return mclTarget;
	}

	public void setMclTarget(String mclTarget) {
		this.mclTarget = mclTarget;
	}

	/**
	 */
	public Date getCycleDate() {
		return cycleDate;
	}

	/**
	 */
	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	/**
	 */
	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public void setTransactionDt(Date transactionDt) {
		this.transactionDt = transactionDt;
	}

	/**
	 */
	public Date getTransactionDt() {
		return this.transactionDt;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	/**
	 */
	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	/**
	 */
	public String getPayeeLastName() {
		return this.payeeLastName;
	}

	/**
	 */
	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	/**
	 */
	public String getPayeeFirstName() {
		return this.payeeFirstName;
	}

	/**
	 */
	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	/**
	 */
	public String getInsuredLastName() {
		return this.insuredLastName;
	}

	/**
	 */
	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	/**
	 */
	public String getInsuredFirstName() {
		return this.insuredFirstName;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 */
	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	/**
	 */
	public BigDecimal getTransactionAmt() {
		return this.transactionAmt;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPolicyIssueDt(Date policyIssueDt) {
		this.policyIssueDt = policyIssueDt;
	}

	/**
	 */
	public Date getPolicyIssueDt() {
		return this.policyIssueDt;
	}

	/**
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 */
	public String getBankCode() {
		return this.bankCode;
	}

	/**
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 */
	public String getAccountNo() {
		return this.accountNo;
	}

	public String getInsuredTitle() {
		return insuredTitle;
	}

	public void setInsuredTitle(String insuredTitle) {
		this.insuredTitle = insuredTitle;
	}

	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	public String getCsFormatPolicyNo() {
		return csFormatPolicyNo;
	}

	public void setCsFormatPolicyNo(String csFormatPolicyNo) {
		this.csFormatPolicyNo = csFormatPolicyNo;
	}

	public String getSuspendCode() {
		return suspendCode;
	}

	public void setSuspendCode(String suspendCode) {
		this.suspendCode = suspendCode;
	}

	public String getFsuRelated() {
		return fsuRelated;
	}

	public void setFsuRelated(String fsuRelated) {
		this.fsuRelated = fsuRelated;
	}

	/**
	 * @return the csInd
	 */
	public String getCsInd() {
		return csInd;
	}

	/**
	 * @param csInd the csInd to set
	 */
	public void setCsInd(String csInd) {
		this.csInd = csInd;
	}

	/**
	 * @return the subOfficeCode
	 */
	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	/**
	 * @param subOfficeCode the subOfficeCode to set
	 */
	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	/**
	 * @return the certNo
	 */
	public String getCertNo() {
		return certNo;
	}

	/**
	 * @param certNo the certNo to set
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getAgencyWritingCode() {
		return agencyWritingCode;
	}

	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	/**
	 */
	public MclWorking() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(MclWorking that) {
		setMclWorkingId(that.getMclWorkingId());
		setMclTarget(that.getMclTarget());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setCompanyId(that.getCompanyId());
		setTransactionDt(that.getTransactionDt());
		setPayeeTitle(that.getPayeeTitle());
		setPayeeLastName(that.getPayeeLastName());
		setPayeeFirstName(that.getPayeeFirstName());
		setInsuredTitle(that.getInsuredTitle());
		setInsuredLastName(that.getInsuredLastName());
		setInsuredFirstName(that.getInsuredFirstName());
		setProviderCode(that.getProviderCode());
		setTransactionAmt(that.getTransactionAmt());
		setPolicyNo(that.getPolicyNo());
		setPolicyIssueDt(that.getPolicyIssueDt());
		setBankCode(that.getBankCode());
		setAccountNo(that.getAccountNo());
		setCsFormatPolicyNo(that.getCsFormatPolicyNo());
		setLastModifiedUserDept(that.getLastModifiedUserDept());
		setLastModifiedUserDesk(that.getLastModifiedUserDesk());
		setCertNo(that.getCertNo());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setAgencyWritingCode(that.getAgencyWritingCode());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("mclWorkingId=[").append(mclWorkingId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("mclTarget=[").append(mclTarget).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("transactionDt=[").append(transactionDt).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("payeeTitle=[").append(payeeTitle).append("] ");
		buffer.append("payeeLastName=[").append(payeeLastName).append("] ");
		buffer.append("payeeFirstName=[").append(payeeFirstName).append("] ");
		buffer.append("insuredTitle=[").append(insuredTitle).append("] ");
		buffer.append("insuredLastName=[").append(insuredLastName).append("] ");
		buffer.append("insuredFirstName=[").append(insuredFirstName).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("transactionAmt=[").append(transactionAmt).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("policyIssueDt=[").append(policyIssueDt).append("] ");
		buffer.append("bankCode=[").append(bankCode).append("] ");
		buffer.append("accountNo=[").append(accountNo).append("] ");
		buffer.append("certNo=[").append(certNo).append("] ");
		buffer.append("lastModifiedUserDept=[").append(lastModifiedUserDept).append("] ");
		buffer.append("lastModifiedUserDesk=[").append(lastModifiedUserDesk).append("] ");
		buffer.append("csFormatPolicyNo=[").append(csFormatPolicyNo).append("] ");
		buffer.append("agencyWritingCode=[").append(agencyWritingCode).append("] ");
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((mclWorkingId == null) ? 0 : mclWorkingId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof MclWorking))
			return false;
		MclWorking equalCheck = (MclWorking) obj;
		if ((mclWorkingId == null && equalCheck.mclWorkingId != null) || (mclWorkingId != null && equalCheck.mclWorkingId == null))
			return false;
		if (mclWorkingId != null && !mclWorkingId.equals(equalCheck.mclWorkingId))
			return false;
		return true;
	}
}
