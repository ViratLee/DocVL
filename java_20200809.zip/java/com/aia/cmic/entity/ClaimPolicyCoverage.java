package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findClaimPolicyCoverageByClaimNoAndOccurrence", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2"),//
		@NamedQuery(name = "findClaimPolicyCoverageBySpecificSumCategory", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.policyNo=?3 and myClaimPolicyCoverage.benefitCode=?4 and myClaimPolicyCoverage.sumCategory =?5"),//
		@NamedQuery(name = "findClaimPolicyCoverageBySpecifiedSumCategory", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.policyNo=?3 and myClaimPolicyCoverage.benefitCode=?4 and myClaimPolicyCoverage.sumCategory in ('A','C','X')"),//
		@NamedQuery(name = "findClaimPolicyCoverageByCompanyIdAndClaimNoOccurrenceAndPolicyNo", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.policyNo=?3"),//
		@NamedQuery(name = "findClaimPolicyCoverageByCompanyIdAndClaimNoOccurrenceAndProductCode", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.productCode=?3"),//
		@NamedQuery(name = "findClaimPolicyCoverageByCompanyIdAndClaimNoOccurrenceAndProductCodeAndPolicyNo", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.productCode=?3 and myClaimPolicyCoverage.policyNo=?4"),//
		@NamedQuery(name = "findClaimPolicyCoverageByClaimNoAndOccurrenceAndPlanIdAndBenefitCode", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.policyNo=?3 and myClaimPolicyCoverage.planId=?4 and myClaimPolicyCoverage.benefitCode=?5"),//
		@NamedQuery(name = "deleteClaimPolicyCoverageByCompanyIdAndClaimNo", query = "delete from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2"),//
		@NamedQuery(name = "findClaimPolicyCoverageByClaimNoAndOccurrenceByEnableAndSumCategory", query = "select myClaimPolicyCoverage from ClaimPolicyCoverage myClaimPolicyCoverage where myClaimPolicyCoverage.claimNo=?1 and myClaimPolicyCoverage.occurrence=?2 and myClaimPolicyCoverage.enableInd = 'Y' and myClaimPolicyCoverage.sumCategory in ('A','C') ")		
})

@SqlResultSetMapping(name="updateResult", columns = { @ColumnResult(name = "count")})
@NamedNativeQueries({@NamedNativeQuery(name = "mergeClaimpolicycoverageByClaimNo", query = "merge INTO claimpolicycoverage c USING ( SELECT t1.claimpolicycoverageid, t2.outnetworksumvalue, t2.fullcreditind, t2.enableind, t2.BENEFITAMOUNT FROM  claimpolicycoverage t1 INNER JOIN claimpolicycoverage t2 ON t1.occurrence = t2.occurrence AND t1.policyno = t2.policyno AND t1.productcode = t2.productcode AND t1.benefitcode = t2.benefitcode AND t1.sumcategory = t2.sumcategory AND t1.sumsequenceno = t2.sumsequenceno AND (t1.sumtimeframe = t2.sumtimeframe OR (t1.sumtimeframe IS NULL AND t2.sumtimeframe IS NULL)) AND t1.shareind = t2.shareind AND (t1.accumulatorno = t2.accumulatorno OR (t1.accumulatorno IS NULL AND t2.accumulatorno IS NULL)) AND t1.claimpolicycoverageid <> t2.claimpolicycoverageid WHERE t1.claimno = ?1 AND t2.claimno = ?2 ) q ON ( c.claimpolicycoverageid = q.claimpolicycoverageid ) WHEN matched THEN UPDATE SET c.outnetworksumvalue = q.outnetworksumvalue, c.fullcreditind = q.fullcreditind, c.enableind = q.enableind, c.BENEFITAMOUNT = q.BENEFITAMOUNT" , resultSetMapping = "updateResult" ) })
		

@Table(name = "CLAIMPOLICYCOVERAGE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPolicyCoverage")
public class ClaimPolicyCoverage extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPolicyCoverageSequence")
	@SequenceGenerator(name = "claimPolicyCoverageSequence", sequenceName = "s_claimpolicycoverage")
	@Column(name = "CLAIMPOLICYCOVERAGEID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPolicyCoverageId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	/**
	 */

	@Column(name = "SACALCULATETYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String saCalculateType;
	/**
	 */

	@Column(name = "SUMDUPLICATECHECKIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sumDuplicateCheckInd;
	/**
	 */

	@Column(name = "OOPIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String oopInd;
	/**
	 */

	@Column(name = "FULLCREDITIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fullCreditInd;
	/**
	 */

	@Column(name = "MEMBERSHIPTYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String membershipType;
	/**
	 */
	@Column(name = "EFFECTIVEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveDt;
	/**
	 */

	@Column(name = "MAXSAAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxSaAmt;
	/**
	 */

	@Column(name = "MINSAAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal minSaAmt;
	/**
	 */

	@Column(name = "FLATAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal flatAmt;
	/**
	 */

	@Column(name = "MULTIPLEFACTOR", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal multipleFactor;
	/**
	 */

	@Column(name = "BENEFITUNIT", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitUnit;
	/**
	 */

	@Column(name = "BENEFITAMOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal benefitAmount;
	/**
	 */

	@Column(name = "SUMSEQUENCENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sumSequenceNo;
	/**
	 */

	@Column(name = "ACCUMULATORNO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer accumulatorNo;
	/**
	 */

	@Column(name = "UNITNO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer unitNo;
	/**
	 */

	@Column(name = "SUMCATEGORY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sumCategory;
	/**
	 */

	@Column(name = "SUMTIMEFRAME", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sumTimeFrame;
	/**
	 */

	@Column(name = "FAMILYSHAREIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String familyShareInd;
	/**
	 */

	@Column(name = "OUTNETWORKSUMVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal outNetworkSumValue;
	/**
	 */

	@Column(name = "INNETWORKSUMVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal inNetworkSumValue;
	/**
	 */
	@Column(name = "PRORATEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String proRateInd;

	@Column(name = "SHAREIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shareInd;

	@Column(name = "SHAREDESC", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shareDesc;

	@Column(name = "SHARELEVEL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shareLevel;

	@Column(name = "BENEFITDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal benefitDeductAmt;
	/**
	 */

	@Column(name = "WAITINGPERIOD")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer waitingPeriod;

	@Column(name = "ENABLEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String enableInd;

	/**
	 */
	public void setClaimPolicyCoverageId(Long claimPolicyCoverageId) {
		this.claimPolicyCoverageId = claimPolicyCoverageId;
	}

	/**
	 */
	public Long getClaimPolicyCoverageId() {
		return this.claimPolicyCoverageId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 */
	public String getBenefitCode() {
		return this.benefitCode;
	}

	/**
	 */
	public void setSaCalculateType(String saCalculateType) {
		this.saCalculateType = saCalculateType;
	}

	/**
	 */
	public String getSaCalculateType() {
		return this.saCalculateType;
	}

	/**
	 */
	public void setSumDuplicateCheckInd(String sumDuplicateCheckInd) {
		this.sumDuplicateCheckInd = sumDuplicateCheckInd;
	}

	/**
	 */
	public String getSumDuplicateCheckInd() {
		return this.sumDuplicateCheckInd;
	}

	/**
	 */
	public void setOopInd(String oopInd) {
		this.oopInd = oopInd;
	}

	/**
	 */
	public String getOopInd() {
		return this.oopInd;
	}

	/**
	 * @return the fullCreditInd
	 */
	public String getFullCreditInd() {
		return fullCreditInd;
	}

	/**
	 * @param fullCreditInd the fullCreditInd to set
	 */
	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	/**
	 */
	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}

	/**
	 */
	public String getMembershipType() {
		return this.membershipType;
	}

	/**
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 */
	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	/**
	 */
	public void setMaxSaAmt(BigDecimal maxSaAmt) {
		this.maxSaAmt = maxSaAmt;
	}

	/**
	 */
	public BigDecimal getMaxSaAmt() {
		return this.maxSaAmt;
	}

	/**
	 */
	public void setMinSaAmt(BigDecimal minSaAmt) {
		this.minSaAmt = minSaAmt;
	}

	/**
	 */
	public BigDecimal getMinSaAmt() {
		return this.minSaAmt;
	}

	/**
	 */
	public void setFlatAmt(BigDecimal flatAmt) {
		this.flatAmt = flatAmt;
	}

	/**
	 */
	public BigDecimal getFlatAmt() {
		return this.flatAmt;
	}

	/**
	 */
	public void setMultipleFactor(BigDecimal multipleFactor) {
		this.multipleFactor = multipleFactor;
	}

	/**
	 */
	public BigDecimal getMultipleFactor() {
		return this.multipleFactor;
	}

	/**
	 */
	public void setBenefitUnit(String benefitUnit) {
		this.benefitUnit = benefitUnit;
	}

	/**
	 */
	public String getBenefitUnit() {
		return this.benefitUnit;
	}

	/**
	 */
	public void setBenefitAmount(BigDecimal benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	/**
	 */
	public BigDecimal getBenefitAmount() {
		return this.benefitAmount;
	}

	/**
	 */
	public void setSumSequenceNo(Integer sumSequenceNo) {
		this.sumSequenceNo = sumSequenceNo;
	}

	/**
	 */
	public Integer getSumSequenceNo() {
		return this.sumSequenceNo;
	}

	/**
	 */
	public void setAccumulatorNo(Integer accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	/**
	 */
	public Integer getAccumulatorNo() {
		return this.accumulatorNo;
	}

	/**
	 */
	public void setUnitNo(Integer unitNo) {
		this.unitNo = unitNo;
	}

	/**
	 */
	public Integer getUnitNo() {
		return this.unitNo;
	}

	/**
	 */
	public void setSumCategory(String sumCategory) {
		this.sumCategory = sumCategory;
	}

	/**
	 */
	public String getSumCategory() {
		return this.sumCategory;
	}

	/**
	 */
	public void setSumTimeFrame(String sumTimeFrame) {
		this.sumTimeFrame = sumTimeFrame;
	}

	/**
	 */
	public String getSumTimeFrame() {
		return this.sumTimeFrame;
	}

	/**
	 */
	public void setFamilyShareInd(String familyShareInd) {
		this.familyShareInd = familyShareInd;
	}

	/**
	 */
	public String getFamilyShareInd() {
		return this.familyShareInd;
	}

	/**
	 */
	public void setOutNetworkSumValue(BigDecimal outNetworkSumValue) {
		this.outNetworkSumValue = outNetworkSumValue;
	}

	/**
	 */
	public BigDecimal getOutNetworkSumValue() {
		return this.outNetworkSumValue;
	}

	/**
	 */
	public void setInNetworkSumValue(BigDecimal inNetworkSumValue) {
		this.inNetworkSumValue = inNetworkSumValue;
	}

	/**
	 */
	public BigDecimal getInNetworkSumValue() {
		return this.inNetworkSumValue;
	}

	public String getProRateInd() {
		return proRateInd;
	}

	public void setProRateInd(String proRateInd) {
		this.proRateInd = proRateInd;
	}

	public String getShareInd() {
		return shareInd;
	}

	public void setShareInd(String shareInd) {
		this.shareInd = shareInd;
	}

	public String getShareDesc() {
		return shareDesc;
	}

	public void setShareDesc(String shareDesc) {
		this.shareDesc = shareDesc;
	}

	public String getShareLevel() {
		return shareLevel;
	}

	public void setShareLevel(String shareLevel) {
		this.shareLevel = shareLevel;
	}

	/**
	 */
	public void setBenefitDeductAmt(BigDecimal benefitDeductAmt) {
		this.benefitDeductAmt = benefitDeductAmt;
	}

	/**
	 */
	public BigDecimal getBenefitDeductAmt() {
		return this.benefitDeductAmt;
	}

	/**
	 */
	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	/**
	 */
	public Integer getWaitingPeriod() {
		return this.waitingPeriod;
	}

	public String getEnableInd() {
		return enableInd;
	}

	public void setEnableInd(String enableInd) {
		this.enableInd = enableInd;
	}

	/**
	 */
	public ClaimPolicyCoverage() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPolicyCoverage that) {
		setClaimPolicyCoverageId(that.getClaimPolicyCoverageId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setProductCode(that.getProductCode());
		setBenefitCode(that.getBenefitCode());
		setSaCalculateType(that.getSaCalculateType());
		setSumDuplicateCheckInd(that.getSumDuplicateCheckInd());
		setOopInd(that.getOopInd());
		setMembershipType(that.getMembershipType());
		setEffectiveDt(that.getEffectiveDt());
		setMaxSaAmt(that.getMaxSaAmt());
		setMinSaAmt(that.getMinSaAmt());
		setFlatAmt(that.getFlatAmt());
		setMultipleFactor(that.getMultipleFactor());
		setBenefitUnit(that.getBenefitUnit());
		setBenefitAmount(that.getBenefitAmount());
		setSumSequenceNo(that.getSumSequenceNo());
		setAccumulatorNo(that.getAccumulatorNo());
		setUnitNo(that.getUnitNo());
		setSumCategory(that.getSumCategory());
		setSumTimeFrame(that.getSumTimeFrame());
		setFamilyShareInd(that.getFamilyShareInd());
		setOutNetworkSumValue(that.getOutNetworkSumValue());
		setInNetworkSumValue(that.getInNetworkSumValue());
		setProRateInd(that.getProRateInd());
		setShareInd(that.getShareInd());
		setShareDesc(that.getShareDesc());
		setShareLevel(that.getShareLevel());
		setBenefitDeductAmt(that.getBenefitDeductAmt());
		setWaitingPeriod(that.getWaitingPeriod());
		setEnableInd(that.getEnableInd());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPolicyCoverageId=[").append(claimPolicyCoverageId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("benefitCode=[").append(benefitCode).append("] ");
		buffer.append("saCalculateType=[").append(saCalculateType).append("] ");
		buffer.append("sumDuplicateCheckInd=[").append(sumDuplicateCheckInd).append("] ");
		buffer.append("oopInd=[").append(oopInd).append("] ");
		buffer.append("membershipType=[").append(membershipType).append("] ");
		buffer.append("effectiveDt=[").append(effectiveDt).append("] ");
		buffer.append("maxSaAmt=[").append(maxSaAmt).append("] ");
		buffer.append("minSaAmt=[").append(minSaAmt).append("] ");
		buffer.append("flatAmt=[").append(flatAmt).append("] ");
		buffer.append("multipleFactor=[").append(multipleFactor).append("] ");
		buffer.append("benefitUnit=[").append(benefitUnit).append("] ");
		buffer.append("benefitAmount=[").append(benefitAmount).append("] ");
		buffer.append("sumSequenceNo=[").append(sumSequenceNo).append("] ");
		buffer.append("accumulatorNo=[").append(accumulatorNo).append("] ");
		buffer.append("unitNo=[").append(unitNo).append("] ");
		buffer.append("sumCategory=[").append(sumCategory).append("] ");
		buffer.append("sumTimeFrame=[").append(sumTimeFrame).append("] ");
		buffer.append("familyShareInd=[").append(familyShareInd).append("] ");
		buffer.append("outNetworkSumValue=[").append(outNetworkSumValue).append("] ");
		buffer.append("inNetworkSumValue=[").append(inNetworkSumValue).append("] ");
		buffer.append("proRateInd=[").append(proRateInd).append("] ");
		buffer.append("shareInd=[").append(shareInd).append("] ");
		buffer.append("shareDesc=[").append(shareDesc).append("] ");
		buffer.append("shareLevel=[").append(shareLevel).append("] ");
		buffer.append("benefitDeductAmt=[").append(benefitDeductAmt).append("] ");
		buffer.append("waitingPeriod=[").append(waitingPeriod).append("] ");
		buffer.append("enableInd=[").append(enableInd).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPolicyCoverageId == null) ? 0 : claimPolicyCoverageId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPolicyCoverage))
			return false;
		ClaimPolicyCoverage equalCheck = (ClaimPolicyCoverage) obj;
		if ((claimPolicyCoverageId == null && equalCheck.claimPolicyCoverageId != null) || (claimPolicyCoverageId != null && equalCheck.claimPolicyCoverageId == null))
			return false;
		if (claimPolicyCoverageId != null && !claimPolicyCoverageId.equals(equalCheck.claimPolicyCoverageId))
			return false;
		return true;
	}
}
