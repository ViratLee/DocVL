package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.aia.cmic.model.PaymentAllocationTemp;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllClaimPaymentAccumulators", query = "select myClaimPaymentAccumulator from ClaimPaymentAccumulator myClaimPaymentAccumulator"),
		@NamedQuery(name = "findClaimPaymentAccumulatorByPrimaryKey", query = "select myClaimPaymentAccumulator from ClaimPaymentAccumulator myClaimPaymentAccumulator where myClaimPaymentAccumulator.claimPaymentAccumulatorId = ?1"),
		@NamedQuery(name = "findClaimPaymentAccumulatorByReimbursedDay", query = "select myClaimPaymentAccumulator from ClaimPaymentAccumulator myClaimPaymentAccumulator where myClaimPaymentAccumulator.reimbursedDay = ?1"),
		@NamedQuery(name = "findClaimPaymentAccumulatorByKeyCombination", query = "select myClaimPaymentAccumulator from ClaimPaymentAccumulator myClaimPaymentAccumulator where myClaimPaymentAccumulator.companyId=?1 and myClaimPaymentAccumulator.claimNo=?2 and myClaimPaymentAccumulator.occurrence=?3 and myClaimPaymentAccumulator.policyNo=?4 and myClaimPaymentAccumulator.planId=?5 and ( myClaimPaymentAccumulator.planCoverageNo = ?6 or ?6 is null or ?6='' ) and myClaimPaymentAccumulator.benefitCode=?7 and myClaimPaymentAccumulator.accumulatorNo = ?8 and myClaimPaymentAccumulator.productCode = ?9"),
		@NamedQuery(name = "findClaimPaymentAccumulatorByCompanyIdClaimNoAndOccurrence", query = "select myClaimPaymentAccumulator from ClaimPaymentAccumulator myClaimPaymentAccumulator where myClaimPaymentAccumulator.companyId = ?1 and myClaimPaymentAccumulator.claimNo=?2 and myClaimPaymentAccumulator.occurrence =?3"), })
@Table(name = "CLAIMPAYMENTACCUMULATOR")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPaymentAccumulator")
public class ClaimPaymentAccumulator extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaymentAccumulatorSequence")
	@SequenceGenerator(name = "claimPaymentAccumulatorSequence", sequenceName = "s_claimpamentaccumulator")
	@Column(name = "CLAIMPAYMENTACCUMULATORID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPaymentAccumulatorId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productCode;
	/**
	 */

	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	/**
	 */

	@Column(name = "ACCUMULATORNO", precision = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal accumulatorNo;
	/**
	 */

	@Column(name = "ELIGIBLEAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal eligibleAmt;
	/**
	 */

	@Column(name = "REIMBURSEDDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer reimbursedDay;

	/**
	 */
	public void setClaimPaymentAccumulatorId(Long claimPaymentAccumulatorId) {
		this.claimPaymentAccumulatorId = claimPaymentAccumulatorId;
	}

	/**
	 */
	public Long getClaimPaymentAccumulatorId() {
		return this.claimPaymentAccumulatorId;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the benefitCode
	 */
	public String getBenefitCode() {
		return benefitCode;
	}

	/**
	 * @param benefitCode the benefitCode to set
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 */
	public void setAccumulatorNo(BigDecimal accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	/**
	 */
	public BigDecimal getAccumulatorNo() {
		return this.accumulatorNo;
	}

	/**
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 */
	public BigDecimal getEligibleAmt() {
		return this.eligibleAmt;
	}

	/**
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	/**
	 */
	public Integer getReimbursedDay() {
		return this.reimbursedDay;
	}

	/**
	 */
	public ClaimPaymentAccumulator() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPaymentAccumulator that) {
		setClaimPaymentAccumulatorId(that.getClaimPaymentAccumulatorId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setBenefitCode(that.getBenefitCode());
		setAccumulatorNo(that.getAccumulatorNo());
		setEligibleAmt(that.getEligibleAmt());
		setReimbursedDay(that.getReimbursedDay());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPaymentAccumulatorId=[").append(claimPaymentAccumulatorId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("benefitCode=[").append(benefitCode).append("] ");
		buffer.append("accumulatorNo=[").append(accumulatorNo).append("] ");
		buffer.append("eligibleAmt=[").append(eligibleAmt).append("] ");
		buffer.append("reimbursedDay=[").append(reimbursedDay).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPaymentAccumulatorId == null) ? 0 : claimPaymentAccumulatorId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPaymentAccumulator))
			return false;
		ClaimPaymentAccumulator equalCheck = (ClaimPaymentAccumulator) obj;
		if ((claimPaymentAccumulatorId == null && equalCheck.claimPaymentAccumulatorId != null) || (claimPaymentAccumulatorId != null && equalCheck.claimPaymentAccumulatorId == null))
			return false;
		if (claimPaymentAccumulatorId != null && !claimPaymentAccumulatorId.equals(equalCheck.claimPaymentAccumulatorId))
			return false;
		return true;
	}

	public void copyProperties(PaymentAllocationTemp allocationTemp, BigDecimal accumulatorNo) {
		setCompanyId(allocationTemp.getCompanyId());
		setClaimNo(allocationTemp.getClaimNo());
		setOccurrence(allocationTemp.getOccurence());
		setPolicyNo(allocationTemp.getPolicyNo());
		setProductCode(allocationTemp.getProductCode());
		setPlanId(allocationTemp.getPlanId());
		setPlanCoverageNo(allocationTemp.getPlanCoverageNo());
		setBenefitCode(allocationTemp.getBenefitCode());
		setAccumulatorNo(accumulatorNo);
		setEligibleAmt(allocationTemp.getEligibleAmt());
		setReimbursedDay(allocationTemp.getReimbursedDay());
	}
}
