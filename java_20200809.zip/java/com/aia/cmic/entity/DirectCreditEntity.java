package com.aia.cmic.entity;

import java.util.Date;

public class DirectCreditEntity {

	private Long claimPaymentId;
	private String name;
	private String providerCode;
	private String providerName;
	private String treatmentType;
	private Double amount;
	private Date paymentTransferDt;
	private Date invoiceDate;
	private Date settlementDate;
	private Date incidentDt;
	private String paymentTransferRemark;
	private String billno;

	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Date getPaymentTransferDt() {
		return paymentTransferDt;
	}

	public void setPaymentTransferDt(Date paymentTransferDt) {
		this.paymentTransferDt = paymentTransferDt;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getPaymentTransferRemark() {
		return paymentTransferRemark;
	}

	public void setPaymentTransferRemark(String paymentTransferRemark) {
		this.paymentTransferRemark = paymentTransferRemark;
	}

	public String getBillno() {
		return billno;
	}

	public void setBillno(String billno) {
		this.billno = billno;
	}

	public Date getIncidentDt() {
		return incidentDt;
	}

	public void setIncidentDt(Date incidentDt) {
		this.incidentDt = incidentDt;
	}

}
