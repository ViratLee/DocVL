package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findClaimPolicyByPrimaryKey", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.claimPolicyId = ?1"),
		@NamedQuery(name = "findClaimPolicyByCompanyIdClaimNoAndOccurrence", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo = ?2 and myClaimPolicy.occurrence = ?3"),
		@NamedQuery(name = "findClaimPolicyByPolicyNoClaimNoAndOccurrence", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.policyNo = ?1 and myClaimPolicy.claimNo = ?2 and myClaimPolicy.occurrence = ?3"),
		@NamedQuery(name = "findClaimPolicyByCompanyIdClaimNoOccurrencePolicyNoAndProductCode", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo = ?2 and myClaimPolicy.occurrence = ?3 and myClaimPolicy.policyNo = ?4  and ( (myClaimPolicy.productCode = ?5 and ( myClaimPolicy.businessLine='CS' or myClaimPolicy.businessLine='GE')) or (myClaimPolicy.productCode is null and myClaimPolicy.businessLine in ('OL','PA') ) ) order by myClaimPolicy.policyIssueDt desc"),
		@NamedQuery(name = "deleteClaimPolicyByCompanyIdAndClaimNo", query = "delete from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo=?2"),
		@NamedQuery(name = "unholdClaimPolicy", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy,Claim myClaim where myClaimPolicy.companyId=myClaim.companyId and myClaimPolicy.claimNo=myClaim.claimNo and myClaimPolicy.occurrence=myClaim.occurrence and myClaim.companyId=?1 and myClaim.memberId=?2 and myClaimPolicy.policyNo =?3 and myClaimPolicy.holdClaimInd='Y' and (myClaimPolicy.releaseHoldClaimInd='' or myClaimPolicy.releaseHoldClaimInd is null) and myClaim.hospitalizationDate < ?4 and myClaim.accidentDt < ?4"),
		@NamedQuery(name = "findPrevPABonusClaimed", query = "select sum(cp.paBonusDeductAmt) from ClaimPolicy cp,Claim cl where cp.claimNo=cl.claimNo and cp.occurrence=cl.occurrence and cp.policyNo=cl.policyNo and cp.policyNo=?1 and cp.paBonusAmt=?2 and cp.paBonusDt=?3 and cl.claimStatus in ('65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null) group by cp.policyNo"),
		@NamedQuery(name = "checkReleaseClaimPolicy", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1  and myClaimPolicy.claimNo=?2 and myClaimPolicy.occurrence = ?3 and myClaimPolicy.holdClaimInd = ?4 and (myClaimPolicy.releaseHoldClaimInd != ?5 or myClaimPolicy.releaseHoldClaimInd is null)"),
		@NamedQuery(name = "updateSuppressInd", query = "update ClaimPolicy myClaimPolicy set myClaimPolicy.suppressInd=?1 where myClaimPolicy.companyId = ?2 and myClaimPolicy.claimNo = ?3 and myClaimPolicy.occurrence = ?4"),
		@NamedQuery(name = "updateSuppressIndByPolicy", query = "update ClaimPolicy myClaimPolicy set myClaimPolicy.suppressInd=?1 where myClaimPolicy.companyId = ?2 and myClaimPolicy.claimNo = ?3 and myClaimPolicy.occurrence = ?4 and myClaimPolicy.policyNo=?5"),
		@NamedQuery(name = "findClaimPolicyByCompanyIdClaimNoOccurrenceAndPolicyNo", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo=?2 and myClaimPolicy.occurrence = ?3 and myClaimPolicy.policyNo=?4 "),
		@NamedQuery(name = "findClaimPolicyStatusDeath", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo=?2 and myClaimPolicy.occurrence = ?3 and myClaimPolicy.policyNo=?4 and myClaimPolicy.policyStatus in ('10','11','216') "), //
		@NamedQuery(name = "findClaimPolicyStatusDeathByClaim", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo=?2 and myClaimPolicy.occurrence = ?3 and myClaimPolicy.policyStatus in ('10','11','216') "),//
		@NamedQuery(name = "findClaimPolicySuppressIndByClaim", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.claimNo=?2 and myClaimPolicy.occurrence = ?3 and myClaimPolicy.suppressInd = ?4 "),//
		@NamedQuery(name = "findClaimPolicyByPolicyNoCertNoClaimNoAndOccurrence", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where  myClaimPolicy.companyId = ?1 and myClaimPolicy.policyNo = ?2 and myClaimPolicy.certNo = ?3 and myClaimPolicy.claimNo = ?4 and myClaimPolicy.occurrence = ?5"),//
		@NamedQuery(name = "getMinPolicyYearFromDt", query = "select min(myClaimPolicy.policyYearFromDt) from ClaimPolicy myClaimPolicy where  myClaimPolicy.companyId = ?1 and myClaimPolicy.policyNo = ?2 and myClaimPolicy.certNo = ?3 and myClaimPolicy.claimNo = ?4"),//
		@NamedQuery(name = "findClaimPolicyByPolicyNoCertNoClaimNoAscPolicyYearFromDt", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where  myClaimPolicy.companyId = ?1 and myClaimPolicy.policyNo = ?2 and myClaimPolicy.certNo = ?3 and myClaimPolicy.claimNo = ?4 order by myClaimPolicy.policyYearFromDt"),//
		@NamedQuery(name = "findHNWPolicyByCompanyIdAndPolicyNo", query = "select myClaimPolicy from ClaimPolicy myClaimPolicy where myClaimPolicy.companyId = ?1 and myClaimPolicy.policyNo = ?2 and myClaimPolicy.productCode in ('990E07', '990D07') and myClaimPolicy.policyStatus in ('1') ")
})
@Table(name = "CLAIMPOLICY")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPolicy")
public class ClaimPolicy extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPolicySequence")
	@SequenceGenerator(name = "claimPolicySequence", sequenceName = "s_claimpolicy")
	@Column(name = "CLAIMPOLICYID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPolicyId;
	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;
	/**
	 */

	@Column(name = "SUBOFFICESTATUS", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeStatus;
	/**
	 */

	@Column(name = "CERTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String certNo;
	/**
	 */

	@Column(name = "MEMBERID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberId;
	/**
	 */

	@Column(name = "DEPENDENTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dependentNo;
	/**
	 */

	@Column(name = "DEPENDENTTYPE", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dependentType;
	/**
	 */

	@Column(name = "MEMBERLASTNAME", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MEMBERLASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberLastName;
	/**
	 */

	@Column(name = "MEMBERFIRSTNAME", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MEMBERFIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberFirstName;

	/**
	 */
	@Column(name = "POLICYSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyStatus;
	/**
	 */

	@Column(name = "POLICYSTATUSREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyStatusReason;
	/**
	 */

	@Column(name = "POLICYSTATUSPREMIUMHOLIDAY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyStatusPremiumHoliday;
	/**
	 */
	@Column(name = "POLICYISSUEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyIssueDt;
	/**
	 */
	@Column(name = "POLICYLAPSEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyLapseDt;
	/**
	 */
	@Column(name = "POLICYYEARFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearFromDt;
	/**
	 */
	@Column(name = "POLICYYEARTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearToDt;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	/**
	 */

	@Column(name = "POLICYHOLDER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyHolder;
	/**
	 */

	@Column(name = "SUBOFFICENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeName;
	/**
	 */

	@Column(name = "POLICYOWNER", length = 60)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyOwner;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;
	/**
	 */

	@Column(name = "CSPRODUCTCATEGORY", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csProductCategory;
	/**
	 */

	@Column(name = "HOLDCLAIMIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String holdClaimInd;
	/**
	 */

	@Column(name = "HOLDCLAIMDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date holdClaimDate;
	/**
	 */

	@Column(name = "CLAIMHOLDBYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimHoldByInd;

	@Column(name = "RELEASEHOLDCLAIMIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String releaseHoldClaimInd;
	/**
	 */
	@Column(name = "RELEASEHOLDCLAIMDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date releaseHoldClaimDate;
	/**
	 */

	@Column(name = "FULLCREDITIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fullCreditInd;
	/**
	 */

	@Column(name = "POLICYSHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal policyShortFallAmt;
	/**
	 */

	@Column(name = "MEMBERSHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal memberShortFallAmt;
	/**
	 */

	@Column(name = "SUMASSURED", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal sumAssured;
	/**
	 */
	@Column(name = "PAIDTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date paidToDt;
	/**
	 */
	@Column(name = "PAIDTOCURRDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date paidToCurrDt;
	/**
	 */
	@Column(name = "APPLICATIONDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date applicationDt;
	/**
	 */
	@Column(name = "CONTRACTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date contractDt;
	/**
	 */
	@Column(name = "ETIDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date etiDt;
	/**
	 */

	@Column(name = "CHGDAYSBEFORE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer chgDaysBefore;
	/**
	 */

	@Column(name = "CHGDAYSAFTER")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer chgDaysAfter;
	/**
	 */
	@Column(name = "PACOVERDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date paCoverDt;
	/**
	 */

	@Column(name = "PABONUSAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal paBonusAmt;
	/**
	 */
	@Column(name = "PABONUSDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date paBonusDt;
	/**
	 */

	@Column(name = "PABONUSDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal paBonusDeductAmt;
	/**
	 */
	@Column(name = "PAIDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date paidDt;
	/**
	 */
	@Column(name = "REINSTATEMENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date reinstatementDt;
	/**
	 */
	@Column(name = "NEXTANNIVERSARYDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date nextAnniversaryDt;
	/**
	 */
	@Column(name = "TAKEOVERDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date takeOverDt;
	/**
	 */

	@Column(name = "TAKEOVERSTATUS", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String takeOverStatus;
	/**
	 */

	@Column(name = "PAYMENTMODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentMode;
	/**
	 */

	@Column(name = "MODALPREMIUM", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal modalPremium;

	/**
	 */

	@Column(name = "RELATIONSHIP", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String relationship;
	/**
	 */

	@Column(name = "OCCUPATIONCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String occupationCode;
	/**
	 */

	@Column(name = "AGENTPOLICYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentPolicyInd;
	/**
	 */

	@Column(name = "AGENTWRITINGCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentWritingCode;
	/**
	 */

	@Column(name = "AGENCYWRITINGCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyWritingCode;
	/**
	 */

	@Column(name = "BROKER", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String broker;
	/**
	 */

	@Column(name = "SUPPRESSIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suppressInd;
	/**
	 */

	@Column(name = "MARKETINGChannel", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String marketingChannel;
	/**
	 */

	@Column(name = "MARKETINGCAMPAIGN", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String marketingCampaign;
	/**
	 */

	@Column(name = "ABSOLUTEASSIGNIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String absoluteAssignInd;
	/**
	 */

	@Column(name = "EGP", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String egp;
	/**
	 */

	@Column(name = "PLANBASICCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planBasicCode;
	/**
	 */

	@Column(name = "PLANBASICSUMASSURED", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal planBasicSumAssured;
	/**
	 */

	@Column(name = "IMPAIRMENTCODE1", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String impairmentCode1;
	/**
	 */

	@Column(name = "IMPAIRMENTCODE2", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String impairmentCode2;
	/**
	 */

	@Column(name = "IMPAIRMENTCODE3", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String impairmentCode3;
	/**
	 */

	@Column(name = "EXCLUSION1", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusion1;
	/**
	 */

	@Column(name = "EXCLUSION2", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusion2;
	/**
	 */

	@Column(name = "EXCLUSION3", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exclusion3;
	/**
	 */

	@Column(name = "CHEQUENO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String chequeNo;
	/**
	 */

	@Column(name = "BANKCHEQUE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankCheque;

	@Column(name = "WRITINGGAOFFICECODE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String writingGaOfficeCode;

	@Column(name = "WRITINGAGENTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String writingAgentName;

	@Column(name = "WRITINGAGENCYNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String writingAgencyName;

	@Column(name = "WRITINGGAOFFICENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String writingGaOfficeName;

	@Column(name = "WRITINGAGENCYLEADERNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String writingAgencyLeaderName;

	@Column(name = "DISTRIBUTIONIND", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String distributionInd;

	@Column(name = "SENDTO", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sendTo;

	@Column(name = "SHORTFALLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shortfallInd;

	@Column(name = "FCSIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fcsInd;

	@Column(name = "LETTERENGIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String letterengInd;

	@Column(name = "CONTACTPERSONNAME", length = 400)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String contactPersonName;

	@Column(name = "POLICYENGLISHIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyEnglishInd;

	@Column(name = "DEPARTMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String departmentCd;

	@Column(name = "SERVICINGAGENTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgentCode;

	@Column(name = "SERVICINGAGENCYCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyCode;

	@Column(name = "SERVICINGGAOFFICECODE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaOfficeCode;

	@Column(name = "SERVICINGGAOFFICENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaofficeName;

	@Column(name = "SERVICINGGAAGENTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaAgentName;

	@Column(name = "SERVICINGGAAGENCYNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaAgencyName;

	@Column(name = "SERVICINGAGENCYLEADERNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyLeaderName;

	@Column(name = "CORRNORMAL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String corrNormal;

	@Column(name = "CORRSHORTFALL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String corrShortfall;
	
	@Column(name = "CONSENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String consentInd;

	@Column(name = "CONSENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date consentDt;
	
	/**
	 */

	/**
	 * @return the claimPolicyId
	 */
	public Long getClaimPolicyId() {
		return claimPolicyId;
	}

	/**
	 * @param claimPolicyId the claimPolicyId to set
	 */
	public void setClaimPolicyId(Long claimPolicyId) {
		this.claimPolicyId = claimPolicyId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	/**
	 */
	public String getSubOfficeCode() {
		return this.subOfficeCode;
	}

	/**
	 */
	public void setSubOfficeStatus(String subOfficeStatus) {
		this.subOfficeStatus = subOfficeStatus;
	}

	/**
	 */
	public String getSubOfficeStatus() {
		return this.subOfficeStatus;
	}

	/**
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	/**
	 */
	public String getCertNo() {
		return this.certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getDependentType() {
		return dependentType;
	}

	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	/**
	 */
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	/**
	 */
	public String getPolicyStatus() {
		return this.policyStatus;
	}

	/**
	 */
	public void setPolicyStatusReason(String policyStatusReason) {
		this.policyStatusReason = policyStatusReason;
	}

	/**
	 */
	public String getPolicyStatusReason() {
		return this.policyStatusReason;
	}

	/**
	 */
	public void setPolicyStatusPremiumHoliday(String policyStatusPremiumHoliday) {
		this.policyStatusPremiumHoliday = policyStatusPremiumHoliday;
	}

	/**
	 */
	public String getPolicyStatusPremiumHoliday() {
		return this.policyStatusPremiumHoliday;
	}

	/**
	 */
	public void setPolicyIssueDt(Date policyIssueDt) {
		this.policyIssueDt = policyIssueDt;
	}

	/**
	 */
	public Date getPolicyIssueDt() {
		return this.policyIssueDt;
	}

	/**
	 */
	public void setPolicyLapseDt(Date policyLapseDt) {
		this.policyLapseDt = policyLapseDt;
	}

	/**
	 */
	public Date getPolicyLapseDt() {
		return this.policyLapseDt;
	}

	/**
	 */
	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	/**
	 */
	public Date getPolicyYearFromDt() {
		return this.policyYearFromDt;
	}

	/**
	 */
	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	/**
	 */
	public Date getPolicyYearToDt() {
		return this.policyYearToDt;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 */
	public String getBusinessLine() {
		return this.businessLine;
	}

	/**
	 */
	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	/**
	 */
	public String getPolicyHolder() {
		return this.policyHolder;
	}

	/**
	 */
	public void setSubOfficeName(String subOfficeName) {
		this.subOfficeName = subOfficeName;
	}

	/**
	 */
	public String getSubOfficeName() {
		return this.subOfficeName;
	}

	/**
	 */
	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	/**
	 */
	public String getPolicyOwner() {
		return this.policyOwner;
	}

	/**
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public String getProductCode() {
		return this.productCode;
	}

	/**
	 */
	public void setCsProductCategory(String csProductCategory) {
		this.csProductCategory = csProductCategory;
	}

	/**
	 */
	public String getCsProductCategory() {
		return this.csProductCategory;
	}

	/**
	 */
	public void setHoldClaimInd(String holdClaimInd) {
		this.holdClaimInd = holdClaimInd;
	}

	/**
	 */
	public String getHoldClaimInd() {
		return this.holdClaimInd;
	}

	/**
	 */
	public void setHoldClaimDate(Date holdClaimDate) {
		this.holdClaimDate = holdClaimDate;
	}

	/**
	 */
	public Date getHoldClaimDate() {
		return this.holdClaimDate;
	}

	public String getClaimHoldByInd() {
		return claimHoldByInd;
	}

	public void setClaimHoldByInd(String claimHoldByInd) {
		this.claimHoldByInd = claimHoldByInd;
	}

	/**
	 */
	public void setReleaseHoldClaimInd(String releaseHoldClaimInd) {
		this.releaseHoldClaimInd = releaseHoldClaimInd;
	}

	/**
	 */
	public String getReleaseHoldClaimInd() {
		return this.releaseHoldClaimInd;
	}

	/**
	 */
	public void setReleaseHoldClaimDate(Date releaseHoldClaimDate) {
		this.releaseHoldClaimDate = releaseHoldClaimDate;
	}

	/**
	 */
	public Date getReleaseHoldClaimDate() {
		return this.releaseHoldClaimDate;
	}

	/**
	 */
	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	/**
	 */
	public String getFullCreditInd() {
		return this.fullCreditInd;
	}

	/**
	 */
	public void setPolicyShortFallAmt(BigDecimal policyShortFallAmt) {
		this.policyShortFallAmt = policyShortFallAmt;
	}

	/**
	 */
	public BigDecimal getPolicyShortFallAmt() {
		return this.policyShortFallAmt;
	}

	/**
	 */
	public void setMemberShortFallAmt(BigDecimal memberShortFallAmt) {
		this.memberShortFallAmt = memberShortFallAmt;
	}

	/**
	 */
	public BigDecimal getMemberShortFallAmt() {
		return this.memberShortFallAmt;
	}

	/**
	 */
	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	/**
	 */
	public BigDecimal getSumAssured() {
		return this.sumAssured;
	}

	/**
	 */
	public void setPaidToDt(Date paidToDt) {
		this.paidToDt = paidToDt;
	}

	/**
	 */
	public Date getPaidToDt() {
		return this.paidToDt;
	}

	/**
	 */
	public void setPaidToCurrDt(Date paidToCurrDt) {
		this.paidToCurrDt = paidToCurrDt;
	}

	/**
	 */
	public Date getPaidToCurrDt() {
		return this.paidToCurrDt;
	}

	/**
	 */
	public void setApplicationDt(Date applicationDt) {
		this.applicationDt = applicationDt;
	}

	/**
	 */
	public Date getApplicationDt() {
		return this.applicationDt;
	}

	/**
	 */
	public void setContractDt(Date contractDt) {
		this.contractDt = contractDt;
	}

	/**
	 */
	public Date getContractDt() {
		return this.contractDt;
	}

	/**
	 */
	public void setEtiDt(Date etiDt) {
		this.etiDt = etiDt;
	}

	/**
	 */
	public Date getEtiDt() {
		return this.etiDt;
	}

	/**
	 */
	public void setChgDaysBefore(Integer chgDaysBefore) {
		this.chgDaysBefore = chgDaysBefore;
	}

	/**
	 */
	public Integer getChgDaysBefore() {
		return this.chgDaysBefore;
	}

	/**
	 */
	public void setChgDaysAfter(Integer chgDaysAfter) {
		this.chgDaysAfter = chgDaysAfter;
	}

	/**
	 */
	public Integer getChgDaysAfter() {
		return this.chgDaysAfter;
	}

	/**
	 */
	public void setPaCoverDt(Date paCoverDt) {
		this.paCoverDt = paCoverDt;
	}

	/**
	 */
	public Date getPaCoverDt() {
		return this.paCoverDt;
	}

	/**
	 */
	public void setPaBonusAmt(BigDecimal paBonusAmt) {
		this.paBonusAmt = paBonusAmt;
	}

	/**
	 */
	public BigDecimal getPaBonusAmt() {
		return this.paBonusAmt;
	}

	/**
	 */
	public void setPaBonusDt(Date paBonusDt) {
		this.paBonusDt = paBonusDt;
	}

	/**
	 */
	public Date getPaBonusDt() {
		return this.paBonusDt;
	}

	/**
	 */
	public void setPaBonusDeductAmt(BigDecimal paBonusDeductAmt) {
		this.paBonusDeductAmt = paBonusDeductAmt;
	}

	/**
	 */
	public BigDecimal getPaBonusDeductAmt() {
		return this.paBonusDeductAmt;
	}

	/**
	 */
	public void setPaidDt(Date paidDt) {
		this.paidDt = paidDt;
	}

	/**
	 */
	public Date getPaidDt() {
		return this.paidDt;
	}

	/**
	 */
	public void setReinstatementDt(Date reinstatementDt) {
		this.reinstatementDt = reinstatementDt;
	}

	/**
	 */
	public Date getReinstatementDt() {
		return this.reinstatementDt;
	}

	/**
	 */
	public void setNextAnniversaryDt(Date nextAnniversaryDt) {
		this.nextAnniversaryDt = nextAnniversaryDt;
	}

	/**
	 */
	public Date getNextAnniversaryDt() {
		return this.nextAnniversaryDt;
	}

	/**
	 */
	public void setTakeOverDt(Date takeOverDt) {
		this.takeOverDt = takeOverDt;
	}

	/**
	 */
	public Date getTakeOverDt() {
		return this.takeOverDt;
	}

	/**
	 */
	public void setTakeOverStatus(String takeOverStatus) {
		this.takeOverStatus = takeOverStatus;
	}

	/**
	 */
	public String getTakeOverStatus() {
		return this.takeOverStatus;
	}

	/**
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	/**
	 */
	public String getPaymentMode() {
		return this.paymentMode;
	}

	/**
	 * @return the modalPremium
	 */
	public BigDecimal getModalPremium() {
		return modalPremium;
	}

	/**
	 * @param modalPremium the modalPremium to set
	 */
	public void setModalPremium(BigDecimal modalPremium) {
		this.modalPremium = modalPremium;
	}

	/**
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 */
	public String getRelationship() {
		return this.relationship;
	}

	/**
	 */
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	/**
	 */
	public String getOccupationCode() {
		return this.occupationCode;
	}

	/**
	 */
	public void setAgentPolicyInd(String agentPolicyInd) {
		this.agentPolicyInd = agentPolicyInd;
	}

	/**
	 */
	public String getAgentPolicyInd() {
		return this.agentPolicyInd;
	}

	/**
	 */
	public void setAgentWritingCode(String agentWritingCode) {
		this.agentWritingCode = agentWritingCode;
	}

	/**
	 */
	public String getAgentWritingCode() {
		return this.agentWritingCode;
	}

	/**
	 */
	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	/**
	 */
	public String getAgencyWritingCode() {
		return this.agencyWritingCode;
	}

	/**
	 */
	public void setBroker(String broker) {
		this.broker = broker;
	}

	/**
	 */
	public String getBroker() {
		return this.broker;
	}

	/**
	 */
	public void setSuppressInd(String suppressInd) {
		this.suppressInd = suppressInd;
	}

	/**
	 */
	public String getSuppressInd() {
		return this.suppressInd;
	}

	/**
	 */
	public void setMarketingChannel(String marketingChannel) {
		this.marketingChannel = marketingChannel;
	}

	/**
	 */
	public String getMarketingChannel() {
		return this.marketingChannel;
	}

	/**
	 */
	public void setMarketingCampaign(String marketingCampaign) {
		this.marketingCampaign = marketingCampaign;
	}

	/**
	 */
	public String getMarketingCampaign() {
		return this.marketingCampaign;
	}

	/**
	 * @return the absoluteAssignInd
	 */
	public String getAbsoluteAssignInd() {
		return absoluteAssignInd;
	}

	/**
	 * @param absoluteAssignInd the absoluteAssignInd to set
	 */
	public void setAbsoluteAssignInd(String absoluteAssignInd) {
		this.absoluteAssignInd = absoluteAssignInd;
	}

	/**
	 * @return the egp
	 */
	public String getEgp() {
		return egp;
	}

	/**
	 * @param egp the egp to set
	 */
	public void setEgp(String egp) {
		this.egp = egp;
	}

	/**
	 */
	public void setPlanBasicCode(String planBasicCode) {
		this.planBasicCode = planBasicCode;
	}

	/**
	 */
	public String getPlanBasicCode() {
		return this.planBasicCode;
	}

	/**
	 */
	public void setPlanBasicSumAssured(BigDecimal planBasicSumAssured) {
		this.planBasicSumAssured = planBasicSumAssured;
	}

	/**
	 */
	public BigDecimal getPlanBasicSumAssured() {
		return this.planBasicSumAssured;
	}

	/**
	 */
	public void setImpairmentCode1(String impairmentCode1) {
		this.impairmentCode1 = impairmentCode1;
	}

	/**
	 */
	public String getImpairmentCode1() {
		return this.impairmentCode1;
	}

	/**
	 */
	public void setImpairmentCode2(String impairmentCode2) {
		this.impairmentCode2 = impairmentCode2;
	}

	/**
	 */
	public String getImpairmentCode2() {
		return this.impairmentCode2;
	}

	/**
	 */
	public void setImpairmentCode3(String impairmentCode3) {
		this.impairmentCode3 = impairmentCode3;
	}

	/**
	 */
	public String getImpairmentCode3() {
		return this.impairmentCode3;
	}

	/**
	 */
	public void setExclusion1(String exclusion1) {
		this.exclusion1 = exclusion1;
	}

	/**
	 */
	public String getExclusion1() {
		return this.exclusion1;
	}

	/**
	 */
	public void setExclusion2(String exclusion2) {
		this.exclusion2 = exclusion2;
	}

	/**
	 */
	public String getExclusion2() {
		return this.exclusion2;
	}

	/**
	 */
	public void setExclusion3(String exclusion3) {
		this.exclusion3 = exclusion3;
	}

	/**
	 * @return the chequeNo
	 */
	public String getChequeNo() {
		return chequeNo;
	}

	/**
	 * @param chequeNo the chequeNo to set
	 */
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	/**
	 * @return the bankCheque
	 */
	public String getBankCheque() {
		return bankCheque;
	}

	/**
	 * @param bankCheque the bankCheque to set
	 */
	public void setBankCheque(String bankCheque) {
		this.bankCheque = bankCheque;
	}

	/**
	 */
	public String getExclusion3() {
		return this.exclusion3;
	}

	public String getWritingGaOfficeCode() {
		return writingGaOfficeCode;
	}

	public void setWritingGaOfficeCode(String writingGaOfficeCode) {
		this.writingGaOfficeCode = writingGaOfficeCode;
	}

	public String getWritingAgentName() {
		return writingAgentName;
	}

	public void setWritingAgentName(String writingAgentName) {
		this.writingAgentName = writingAgentName;
	}

	public String getWritingAgencyName() {
		return writingAgencyName;
	}

	public void setWritingAgencyName(String writingAgencyName) {
		this.writingAgencyName = writingAgencyName;
	}

	public String getWritingGaOfficeName() {
		return writingGaOfficeName;
	}

	public void setWritingGaOfficeName(String writingGaOfficeName) {
		this.writingGaOfficeName = writingGaOfficeName;
	}

	public String getWritingAgencyLeaderName() {
		return writingAgencyLeaderName;
	}

	public void setWritingAgencyLeaderName(String writingAgencyLeaderName) {
		this.writingAgencyLeaderName = writingAgencyLeaderName;
	}

	/**
	 * @return the distributionInd
	 */
	public String getDistributionInd() {
		return distributionInd;
	}

	/**
	 * @param distributionInd the distributionInd to set
	 */
	public void setDistributionInd(String distributionInd) {
		this.distributionInd = distributionInd;
	}

	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}

	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	/**
	 * @return the shortfallInd
	 */
	public String getShortfallInd() {
		return shortfallInd;
	}

	/**
	 * @param shortfallInd the shortfallInd to set
	 */
	public void setShortfallInd(String shortfallInd) {
		this.shortfallInd = shortfallInd;
	}

	/**
	 * @return the fcsInd
	 */
	public String getFcsInd() {
		return fcsInd;
	}

	/**
	 * @param fcsInd the fcsInd to set
	 */
	public void setFcsInd(String fcsInd) {
		this.fcsInd = fcsInd;
	}

	/**
	 * @return the letterengInd
	 */
	public String getLetterengInd() {
		return letterengInd;
	}

	/**
	 * @param letterengInd the letterengInd to set
	 */
	public void setLetterengInd(String letterengInd) {
		this.letterengInd = letterengInd;
	}

	/**
	 * @return the contactPersonName
	 */
	public String getContactPersonName() {
		return contactPersonName;
	}

	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getPolicyEnglishInd() {
		return policyEnglishInd;
	}

	public void setPolicyEnglishInd(String policyEnglishInd) {
		this.policyEnglishInd = policyEnglishInd;
	}

	public String getServicingAgentCode() {
		return servicingAgentCode;
	}

	public String getServicingAgencyCode() {
		return servicingAgencyCode;
	}

	public String getServicingGaOfficeCode() {
		return servicingGaOfficeCode;
	}

	public String getServicingGaofficeName() {
		return servicingGaofficeName;
	}

	public String getServicingGaAgentName() {
		return servicingGaAgentName;
	}

	public String getServicingGaAgencyName() {
		return servicingGaAgencyName;
	}

	public String getServicingAgencyLeaderName() {
		return servicingAgencyLeaderName;
	}

	public void setServicingAgentCode(String servicingAgentCode) {
		this.servicingAgentCode = servicingAgentCode;
	}

	public void setServicingAgencyCode(String servicingAgencyCode) {
		this.servicingAgencyCode = servicingAgencyCode;
	}

	public void setServicingGaOfficeCode(String servicingGaOfficeCode) {
		this.servicingGaOfficeCode = servicingGaOfficeCode;
	}

	public void setServicingGaofficeName(String servicingGaofficeName) {
		this.servicingGaofficeName = servicingGaofficeName;
	}

	public void setServicingGaAgentName(String servicingGaAgentName) {
		this.servicingGaAgentName = servicingGaAgentName;
	}

	public void setServicingGaAgencyName(String servicingGaAgencyName) {
		this.servicingGaAgencyName = servicingGaAgencyName;
	}

	public void setServicingAgencyLeaderName(String servicingAgencyLeaderName) {
		this.servicingAgencyLeaderName = servicingAgencyLeaderName;
	}

	public String getCorrNormal() {
		return corrNormal;
	}

	public void setCorrNormal(String corrNormal) {
		this.corrNormal = corrNormal;
	}

	public String getCorrShortfall() {
		return corrShortfall;
	}

	public void setCorrShortfall(String corrShortfall) {
		this.corrShortfall = corrShortfall;
	}

	/**
	 */
	public ClaimPolicy() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPolicy that) {
		setClaimPolicyId(that.getClaimPolicyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setSubOfficeCode(that.getSubOfficeCode());
		setSubOfficeName(that.getSubOfficeName());
		setSubOfficeStatus(that.getSubOfficeStatus());
		setCertNo(that.getCertNo());
		setPolicyStatus(that.getPolicyStatus());
		setPolicyStatusReason(that.getPolicyStatusReason());
		setPolicyStatusPremiumHoliday(that.getPolicyStatusPremiumHoliday());
		setPolicyIssueDt(that.getPolicyIssueDt());
		setPolicyLapseDt(that.getPolicyLapseDt());
		setPolicyYearFromDt(that.getPolicyYearFromDt());
		setPolicyYearToDt(that.getPolicyYearToDt());
		setCompanyId(that.getCompanyId());
		setBusinessLine(that.getBusinessLine());
		setPolicyHolder(that.getPolicyHolder());
		setPolicyOwner(that.getPolicyOwner());
		setProductCode(that.getProductCode());
		setCsProductCategory(that.getCsProductCategory());
		setHoldClaimInd(that.getHoldClaimInd());
		setHoldClaimDate(that.getHoldClaimDate());
		setClaimHoldByInd(that.getClaimHoldByInd());
		setReleaseHoldClaimInd(that.getReleaseHoldClaimInd());
		setReleaseHoldClaimDate(that.getReleaseHoldClaimDate());
		setFullCreditInd(that.getFullCreditInd());
		setPolicyShortFallAmt(that.getPolicyShortFallAmt());
		setMemberShortFallAmt(that.getMemberShortFallAmt());
		setSumAssured(that.getSumAssured());
		setPaidToDt(that.getPaidToDt());
		setPaidToCurrDt(that.getPaidToCurrDt());
		setApplicationDt(that.getApplicationDt());
		setContractDt(that.getContractDt());
		setEtiDt(that.getEtiDt());
		setChgDaysBefore(that.getChgDaysBefore());
		setChgDaysAfter(that.getChgDaysAfter());
		setPaCoverDt(that.getPaCoverDt());
		setPaBonusAmt(that.getPaBonusAmt());
		setPaBonusDt(that.getPaBonusDt());
		setPaBonusDeductAmt(that.getPaBonusDeductAmt());
		setPaidDt(that.getPaidDt());
		setReinstatementDt(that.getReinstatementDt());
		setNextAnniversaryDt(that.getNextAnniversaryDt());
		setTakeOverDt(that.getTakeOverDt());
		setTakeOverStatus(that.getTakeOverStatus());
		setPaymentMode(that.getPaymentMode());
		setRelationship(that.getRelationship());
		setOccupationCode(that.getOccupationCode());
		setAgentPolicyInd(that.getAgentPolicyInd());
		setAgentWritingCode(that.getAgentWritingCode());
		setAgencyWritingCode(that.getAgencyWritingCode());
		setBroker(that.getBroker());
		setSuppressInd(that.getSuppressInd());
		setMarketingChannel(that.getMarketingChannel());
		setMarketingCampaign(that.getMarketingCampaign());
		setAbsoluteAssignInd(that.getAbsoluteAssignInd());
		setEgp(that.getEgp());
		setPlanBasicCode(that.getPlanBasicCode());
		setPlanBasicSumAssured(that.getPlanBasicSumAssured());
		setImpairmentCode1(that.getImpairmentCode1());
		setImpairmentCode2(that.getImpairmentCode2());
		setImpairmentCode3(that.getImpairmentCode3());
		setExclusion1(that.getExclusion1());
		setExclusion2(that.getExclusion2());
		setExclusion3(that.getExclusion3());
		setChequeNo(that.getChequeNo());
		setBankCheque(that.getBankCheque());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());

		setPolicyEnglishInd(that.getPolicyEnglishInd());
		setDistributionInd(that.getDistributionInd());
		setSendTo(that.getSendTo());
		setShortfallInd(that.getShortfallInd());
		setFcsInd(that.getFcsInd());
		setLetterengInd(that.getLetterengInd());
		setContactPersonName(that.getContactPersonName());
		setDepartmentCd(that.getDepartmentCd());

		setCorrNormal(that.getCorrNormal());
		setCorrShortfall(that.getCorrShortfall());
		
		setConsentInd(that.getConsentInd());
		setConsentDt(that.getConsentDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPolicyId=[").append(claimPolicyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("subOfficeCode=[").append(subOfficeCode).append("] ");
		buffer.append("subOfficeStatus=[").append(subOfficeStatus).append("] ");
		buffer.append("certNo=[").append(certNo).append("] ");
		buffer.append("memberId=[").append(memberId).append("] ");
		buffer.append("dependentNo=[").append(dependentNo).append("] ");
		buffer.append("dependentType=[").append(dependentType).append("] ");
		buffer.append("memberLastName=[").append(memberLastName).append("] ");
		buffer.append("memberFirstName=[").append(memberFirstName).append("] ");
		buffer.append("policyStatus=[").append(policyStatus).append("] ");
		buffer.append("policyStatusReason=[").append(policyStatusReason).append("] ");
		buffer.append("policyStatusPremiumHoliday=[").append(policyStatusPremiumHoliday).append("] ");
		buffer.append("policyIssueDt=[").append(policyIssueDt).append("] ");
		buffer.append("policyLapseDt=[").append(policyLapseDt).append("] ");
		buffer.append("policyYearFromDt=[").append(policyYearFromDt).append("] ");
		buffer.append("policyYearToDt=[").append(policyYearToDt).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("policyHolder=[").append(policyHolder).append("] ");
		buffer.append("subOfficeName=[").append(subOfficeName).append("] ");
		buffer.append("policyOwner=[").append(policyOwner).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("csProductCategory=[").append(csProductCategory).append("] ");
		buffer.append("holdClaimInd=[").append(holdClaimInd).append("] ");
		buffer.append("holdClaimDate=[").append(holdClaimDate).append("] ");
		buffer.append("claimHoldByInd=[").append(claimHoldByInd).append("] ");
		buffer.append("releaseHoldClaimInd=[").append(releaseHoldClaimInd).append("] ");
		buffer.append("releaseHoldClaimDate=[").append(releaseHoldClaimDate).append("] ");
		buffer.append("fullCreditInd=[").append(fullCreditInd).append("] ");
		buffer.append("policyShortFallAmt=[").append(policyShortFallAmt).append("] ");
		buffer.append("memberShortFallAmt=[").append(memberShortFallAmt).append("] ");
		buffer.append("sumAssured=[").append(sumAssured).append("] ");
		buffer.append("paidToDt=[").append(paidToDt).append("] ");
		buffer.append("paidToCurrDt=[").append(paidToCurrDt).append("] ");
		buffer.append("applicationDt=[").append(applicationDt).append("] ");
		buffer.append("contractDt=[").append(contractDt).append("] ");
		buffer.append("etiDt=[").append(etiDt).append("] ");
		buffer.append("chgDaysBefore=[").append(chgDaysBefore).append("] ");
		buffer.append("chgDaysAfter=[").append(chgDaysAfter).append("] ");
		buffer.append("paCoverDt=[").append(paCoverDt).append("] ");
		buffer.append("paBonusAmt=[").append(paBonusAmt).append("] ");
		buffer.append("paBonusDt=[").append(paBonusDt).append("] ");
		buffer.append("paBonusDeductAmt=[").append(paBonusDeductAmt).append("] ");
		buffer.append("paidDt=[").append(paidDt).append("] ");
		buffer.append("reinstatementDt=[").append(reinstatementDt).append("] ");
		buffer.append("nextAnniversaryDt=[").append(nextAnniversaryDt).append("] ");
		buffer.append("takeOverDt=[").append(takeOverDt).append("] ");
		buffer.append("takeOverStatus=[").append(takeOverStatus).append("] ");
		buffer.append("paymentMode=[").append(paymentMode).append("] ");
		buffer.append("relationship=[").append(relationship).append("] ");
		buffer.append("occupationCode=[").append(occupationCode).append("] ");
		buffer.append("agentPolicyInd=[").append(agentPolicyInd).append("] ");
		buffer.append("agentWritingCode=[").append(agentWritingCode).append("] ");
		buffer.append("agencyWritingCode=[").append(agencyWritingCode).append("] ");
		buffer.append("broker=[").append(broker).append("] ");
		buffer.append("suppressInd=[").append(suppressInd).append("] ");
		buffer.append("marketingChannel=[").append(marketingChannel).append("] ");
		buffer.append("marketingCampaign=[").append(marketingCampaign).append("] ");
		buffer.append("absoluteAssignInd=[").append(absoluteAssignInd).append("] ");
		buffer.append("egp=[").append(egp).append("] ");
		buffer.append("planBasicCode=[").append(planBasicCode).append("] ");
		buffer.append("planBasicSumAssured=[").append(planBasicSumAssured).append("] ");
		buffer.append("impairmentCode1=[").append(impairmentCode1).append("] ");
		buffer.append("impairmentCode2=[").append(impairmentCode2).append("] ");
		buffer.append("impairmentCode3=[").append(impairmentCode3).append("] ");
		buffer.append("exclusion1=[").append(exclusion1).append("] ");
		buffer.append("exclusion2=[").append(exclusion2).append("] ");
		buffer.append("exclusion3=[").append(exclusion3).append("] ");
		buffer.append("chequeNo=[").append(chequeNo).append("] ");
		buffer.append("bankCheque=[").append(bankCheque).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		buffer.append("policyEnglishInd=[").append(policyEnglishInd).append("] ");
		buffer.append("distributionInd=[").append(distributionInd).append("] ");
		buffer.append("sendTo=[").append(sendTo).append("] ");
		buffer.append("shortfallInd=[").append(shortfallInd).append("] ");
		buffer.append("fcsInd=[").append(fcsInd).append("] ");
		buffer.append("letterengInd=[").append(letterengInd).append("] ");
		buffer.append("contactPersonName=[").append(contactPersonName).append("] ");
		buffer.append("departmentCd=[").append(departmentCd).append("] ");
		buffer.append("writingGaOfficeCode=[").append(writingGaOfficeCode).append("] ");
		buffer.append("writingAgentName=[").append(writingAgentName).append("] ");
		buffer.append("writingAgencyName=[").append(writingAgencyName).append("] ");
		buffer.append("writingGaOfficeName=[").append(writingGaOfficeName).append("] ");
		buffer.append("writingAgencyLeaderName=[").append(writingAgencyLeaderName).append("] ");

		buffer.append("corrNormal=[").append(corrNormal).append("] ");
		buffer.append("corrShortfall=[").append(corrShortfall).append("] ");
		
		buffer.append("consentInd=[").append(consentInd).append("] ");
		buffer.append("consentDt=[").append(consentDt).append("] ");
		
		
		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPolicyId == null) ? 0 : claimPolicyId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPolicy))
			return false;
		ClaimPolicy equalCheck = (ClaimPolicy) obj;
		if ((claimPolicyId == null && equalCheck.claimPolicyId != null) || (claimPolicyId != null && equalCheck.claimPolicyId == null))
			return false;
		if (claimPolicyId != null && !claimPolicyId.equals(equalCheck.claimPolicyId))
			return false;
		return true;
	}

	public String getDepartmentCd() {
		return departmentCd;
	}

	public void setDepartmentCd(String departmentCd) {
		this.departmentCd = departmentCd;
	}

	public String getConsentInd() {
		return consentInd;
	}

	public void setConsentInd(String consentInd) {
		this.consentInd = consentInd;
	}

	public Date getConsentDt() {
		return consentDt;
	}

	public void setConsentDt(Date consentDt) {
		this.consentDt = consentDt;
	}

}
