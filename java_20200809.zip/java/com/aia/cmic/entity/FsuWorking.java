package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllFsuWorkings", query = "select myFsuWorking from FsuWorking myFsuWorking"),
		@NamedQuery(name = "findFsuWorkingByAccountCode", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.accountCode = ?1"),
		@NamedQuery(name = "findFsuWorkingByAccountCodeContaining", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.accountCode like ?1"),
		@NamedQuery(name = "findFsuWorkingByBasicPlanCode", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.basicPlanCode = ?1"),
		@NamedQuery(name = "findFsuWorkingByBasicPlanCodeContaining", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.basicPlanCode like ?1"),
		@NamedQuery(name = "findFsuWorkingByClaimNo", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1"),
		@NamedQuery(name = "findFsuWorkingByClaimNoOccurrence", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2"),
		@NamedQuery(name = "findFsuWorkingByCoveragePlanCode", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.coveragePlanCode = ?1"),
		@NamedQuery(name = "findFsuWorkingByCoveragePlanCodeContaining", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.coveragePlanCode like ?1"),
		@NamedQuery(name = "findFsuWorkingByFsuWorkingId", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.fsuWorkingId = ?1"),
		@NamedQuery(name = "findFsuWorkingByPolicyNo", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.policyNo = ?1"),
		@NamedQuery(name = "findFsuWorkingByPolicyNoContaining", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.policyNo like ?1"),
		@NamedQuery(name = "findFsuWorkingByPrimaryKey", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.fsuWorkingId = ?1"),
		@NamedQuery(name = "findFsuWorkingByProviderCode", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.providerCode = ?1"),
		@NamedQuery(name = "findFsuWorkingByAgencyCodeServicing", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.agencyCodeServicing = ?1"),
		@NamedQuery(name = "findFsuWorkingByAgentCodeServicing", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.agentCodeServicing = ?1"),
		@NamedQuery(name = "findFsuWorkingByTransactionAmt", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.transactionAmt = ?1"),
		@NamedQuery(name = "findFsuWorkingByTransactionDt", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.transactionDt = ?1"),
		@NamedQuery(name = "findFsuWorkingByPolicyNoAccountCode", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo=?2 and myFsuWorking.occurrence=?3 and myFsuWorking.policyNo=?4 and myFsuWorking.accountCode=?5"),
		@NamedQuery(name = "findFsuWorkingIfExists", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.companyId =?1 and myFsuWorking.claimNo=?2 and myFsuWorking.occurrence=?3"),
		@NamedQuery(name = "findFsuWorkingByDistinctProductTypePackage", query = "select distinct myFsuWorking.companyId,myFsuWorking.claimNo,myFsuWorking.occurrence,myFsuWorking.policyNo,myFsuWorking.productType,myFsuWorking.paPackageName from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo=?2 and myFsuWorking.occurrence=?3 and myFsuWorking.accountCode not in ?4"),
		@NamedQuery(name = "findFsuWorkingByProductTypePackageName", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo=?2 and myFsuWorking.occurrence=?3 and myFsuWorking.policyNo=?4 and myFsuWorking.productType=?5 and (myFsuWorking.paPackageName=?6 or ?6 is null or ?6='' )"),
		@NamedQuery(name = "findFsuWorkingById", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.fsuWorkingId = ?1"),
		@NamedQuery(name = "findFsuWorkingToCancel", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2 and myFsuWorking.policyNo = ?3 and ( myFsuWorking.basicPlanCode = ?4  or (?4 is null and myFsuWorking.basicPlanCode is null) ) and (myFsuWorking.postingDesc like '3.2%' or myFsuWorking.postingDesc like '3.5%') and ( upper(myFsuWorking.status) <> 'C' or myFsuWorking.status is null ) "),
		@NamedQuery(name = "findFsuWorkingIfPosted", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2 and (myFsuWorking.productType like 'HS%' or myFsuWorking.productType ='PA-ME') and (myFsuWorking.postingDesc like '2.2%' or myFsuWorking.postingDesc like '2.5%') "),
		@NamedQuery(name = "findFsuWorkingIfPostedByClaim", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2 and (myFsuWorking.postingDesc like '2.2%' or myFsuWorking.postingDesc like '2.5%') and ( myFsuWorking.status <> 'C' or  myFsuWorking.status is null )"),
		@NamedQuery(name = "findFsuWorkingIfPostedByClaimPaymentId", query = "select myFsuWorking from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2 and ( myFsuWorking.claimPaymentId = ?3 or (myFsuWorking.claimPaymentId is null and myFsuWorking.policyNo = ?4 and myFsuWorking.productType = ?5 ) ) and (myFsuWorking.postingDesc like '2.2%' or myFsuWorking.postingDesc like '2.5%') and ( myFsuWorking.status <> 'C' or  myFsuWorking.status is null )"),
		@NamedQuery(name = "findFsuWorkingIfReserved", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo = ?2 and myFsuWorking.occurrence = ?3 and (myFsuWorking.postingDesc like '1.1%' or myFsuWorking.postingDesc like '1.3%') "),
		@NamedQuery(name = "findFsuWorkingIfReversedReserve", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo = ?2 and myFsuWorking.occurrence = ?3 and (myFsuWorking.postingDesc like '1.2%' or myFsuWorking.postingDesc like '1.4%' or myFsuWorking.postingDesc like '2.1%' or myFsuWorking.postingDesc like '2.4%') "),
		@NamedQuery(name = "findFsuWorkingIfReversedExpense", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo = ?2 and myFsuWorking.occurrence = ?3 and (myFsuWorking.postingDesc like '2.3%' or myFsuWorking.postingDesc like '2.6%') "),
		@NamedQuery(name = "findFsuWorkingIfPostedAndReversed", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.companyId = ?1 and myFsuWorking.claimNo = ?2 and myFsuWorking.occurrence = ?3 and (myFsuWorking.postingDesc like '2.3%' or myFsuWorking.postingDesc like '2.6%' or myFsuWorking.postingDesc like '3.2%' or myFsuWorking.postingDesc like '3.5%' or myFsuWorking.postingDesc like '3.3%' or myFsuWorking.postingDesc like '3.6%' ) "),
		@NamedQuery(name = "findFsuWorkingTransactionAmtToDeduct", query = "select sum(myFsuWorking.transactionAmt) from FsuWorking myFsuWorking where myFsuWorking.fsuWorkingId in  ?1 and myFsuWorking.claimNo = ?2 and myFsuWorking.occurrence = ?3 and  myFsuWorking.transactionAmt > 0"),
		@NamedQuery(name = "updateFSUWorkingToCancel", query = "update FsuWorking myFsuWorking set myFsuWorking.status='C' where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2"),
		@NamedQuery(name = "cancelledFSUWorkingCount", query = "select count(myFsuWorking) from FsuWorking myFsuWorking where myFsuWorking.claimNo = ?1 and myFsuWorking.occurrence = ?2 and myFsuWorking.fsuWorkingId in ?3 and upper(myFsuWorking.status) ='C'"),
		@NamedQuery(name = "findLatestSuspendCode", query = "select distinct myFsuWorking.suspendCode from FsuWorking myFsuWorking where myFsuWorking.companyId =?1 and  myFsuWorking.claimNo = ?2 and myFsuWorking.occurrence = ?3 and myFsuWorking.policyNo=?4 and (myFsuWorking.postingDesc like '3.2%' or myFsuWorking.postingDesc like '3.5%') and  myFsuWorking.claimNo <> myFsuWorking.suspendCode ")

})
@Table(name = "FSUWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "FsuWorking")
public class FsuWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "fsuWorkingSequence")
	@SequenceGenerator(name = "fsuWorkingSequence", sequenceName = "s_fsuworking")
	@Column(name = "FSUWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long fsuWorkingId;

	/**
	 */
	@Column(name = "CYCLEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date cycleDate;

	/**
	 */
	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;

	/**
	 */
	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	/**
	 */
	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	/**
	 */
	@Column(name = "TRANSACTIONDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date transactionDt;

	/**
	 */
	@Column(name = "PAYEETYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeType;

	/**
	 */
	@Column(name = "PROVIDERCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "ACCOUNTCODE", length = 14, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accountCode;

	/**
	 */
	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;

	/**
	 */
	@Column(name = "TRANSACTIONAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal transactionAmt;

	/**
	 */
	@Column(name = "PABONUSDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal paBonusDeductAmt;

	/**
	 */
	@Column(name = "BASICPLANCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String basicPlanCode;

	/**
	 */
	@Column(name = "COVERAGEPLANCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String coveragePlanCode;

	/**
	 */
	@Column(name = "PRODUCTTYPE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productType;

	/**
	 */
	@Column(name = "PAPACKAGENAME", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paPackageName;

	/**
	 */
	@Column(name = "PAYMENTMETHOD", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentMethod;

	/**
	 */
	@Column(name = "BANKIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankInd;

	@Column(name = "STATUS", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String status;

	@Column(name = "CLAIMPAYMENTID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Long claimPaymentId;
	/**
	 */

	/**
	 */
	@Column(name = "SUPPRESSCHEQUEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suppressChequeInd;

	/**
	 */
	@Column(name = "MARKETINGCHANNELCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String marketingChannelCode;

	/**
	 */
	@Column(name = "LASTMODIFIEDUSERDEPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDept;

	/**
	 */
	@Column(name = "LASTMODIFIEDUSERDESK", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDesk;

	/**
	 */
	@Column(name = "AGENCYCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyCodeServicing;

	/**
	 */
	@Column(name = "AGENTCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentCodeServicing;

	/**
	 */
	@Column(name = "CSFORMATPOLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csFormatPolicyNo;

	@Column(name = "POSTINGDESC", length = 60)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postingDesc;

	/**
	   */
	@Column(name = "SUSPENDCODE", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspendCode;
	
	/**
	   */
	@Column(name = "RCCPLANCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String rccPlanCode;
	
	/**
	 */
	@Column(name = "RCCCOVNUM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String rccCovNum;
	
	/**
	   */
	@Column(name = "CUKPLANCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cukPlanCode;
	
	/**
	 */
	@Column(name = "CUKCOVNUM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cukCovNum;
	
	/**
	   */
	@Column(name = "PAR", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String par;
	
	/**
	   */
	@Column(name = "PLANCOVERAGENO", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	
	

	/**
	 * @return the fsuWorkingId
	 */
	public Long getFsuWorkingId() {
		return fsuWorkingId;
	}

	/**
	 * @param fsuWorkingId the fsuWorkingId to set
	 */
	public void setFsuWorkingId(Long fsuWorkingId) {
		this.fsuWorkingId = fsuWorkingId;
	}

	/**
	 * @return the cycleDate
	 */
	public Date getCycleDate() {
		return cycleDate;
	}

	/**
	 * @param cycleDate the cycleDate to set
	 */
	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the transactionDt
	 */
	public Date getTransactionDt() {
		return transactionDt;
	}

	/**
	 * @param transactionDt the transactionDt to set
	 */
	public void setTransactionDt(Date transactionDt) {
		this.transactionDt = transactionDt;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}

	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}

	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the transactionAmt
	 */
	public BigDecimal getTransactionAmt() {
		return transactionAmt;
	}

	/**
	 * @param transactionAmt the transactionAmt to set
	 */
	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	/**
	 * @return the paBonusDeductAmt
	 */
	public BigDecimal getPaBonusDeductAmt() {
		return paBonusDeductAmt;
	}

	/**
	 * @param paBonusDeductAmt the paBonusDeductAmt to set
	 */
	public void setPaBonusDeductAmt(BigDecimal paBonusDeductAmt) {
		this.paBonusDeductAmt = paBonusDeductAmt;
	}

	/**
	 * @return the basicPlanCode
	 */
	public String getBasicPlanCode() {
		return basicPlanCode;
	}

	/**
	 * @param basicPlanCode the basicPlanCode to set
	 */
	public void setBasicPlanCode(String basicPlanCode) {
		this.basicPlanCode = basicPlanCode;
	}

	/**
	 * @return the coveragePlanCode
	 */
	public String getCoveragePlanCode() {
		return coveragePlanCode;
	}

	/**
	 * @param coveragePlanCode the coveragePlanCode to set
	 */
	public void setCoveragePlanCode(String coveragePlanCode) {
		this.coveragePlanCode = coveragePlanCode;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the paPackageName
	 */
	public String getPaPackageName() {
		return paPackageName;
	}

	/**
	 * @param paPackageName the paPackageName to set
	 */
	public void setPaPackageName(String paPackageName) {
		this.paPackageName = paPackageName;
	}

	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	/**
	 * @return the bankInd
	 */
	public String getBankInd() {
		return bankInd;
	}

	/**
	 * @param bankInd the bankInd to set
	 */
	public void setBankInd(String bankInd) {
		this.bankInd = bankInd;
	}

	/**
	 * @return the suppressChequeInd
	 */
	public String getSuppressChequeInd() {
		return suppressChequeInd;
	}

	/**
	 * @param suppressChequeInd the suppressChequeInd to set
	 */
	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	/**
	 * @return the marketingChannelCode
	 */
	public String getMarketingChannelCode() {
		return marketingChannelCode;
	}

	/**
	 * @param marketingChannelCode the marketingChannelCode to set
	 */
	public void setMarketingChannelCode(String marketingChannelCode) {
		this.marketingChannelCode = marketingChannelCode;
	}

	/**
	 * @return the lastModifiedUserDept
	 */
	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	/**
	 * @param lastModifiedUserDept the lastModifiedUserDept to set
	 */
	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	/**
	 * @return the lastModifiedUserDesk
	 */
	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	/**
	 * @param lastModifiedUserDesk the lastModifiedUserDesk to set
	 */
	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	/**
	 * @return the agencyCodeServicing
	 */
	public String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	/**
	 * @param agencyCodeServicing the agencyCodeServicing to set
	 */
	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	/**
	 * @return the agentCodeServicing
	 */
	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	/**
	 * @param agentCodeServicing the agentCodeServicing to set
	 */
	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	/**
	 * @return the csFormatPolicyNo
	 */
	public String getCsFormatPolicyNo() {
		return csFormatPolicyNo;
	}

	/**
	 * @param csFormatPolicyNo the csFormatPolicyNo to set
	 */
	public void setCsFormatPolicyNo(String csFormatPolicyNo) {
		this.csFormatPolicyNo = csFormatPolicyNo;
	}

	public String getPostingDesc() {
		return postingDesc;
	}

	public void setPostingDesc(String postingDesc) {
		this.postingDesc = postingDesc;
	}

	public String getSuspendCode() {
		return suspendCode;
	}

	public void setSuspendCode(String suspendCode) {
		this.suspendCode = suspendCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the rccPlanCode
	 */
	public String getRccPlanCode() {
		return rccPlanCode;
	}

	/**
	 * @param rccPlanCode the rccPlanCode to set
	 */
	public void setRccPlanCode(String rccPlanCode) {
		this.rccPlanCode = rccPlanCode;
	}

	public String getRccCovNum() {
		return rccCovNum;
	}

	public void setRccCovNum(String rccCovNum) {
		this.rccCovNum = rccCovNum;
	}

	/**
	 * @return the cukPlanCode
	 */
	public String getCukPlanCode() {
		return cukPlanCode;
	}

	/**
	 * @param cukPlanCode the cukPlanCode to set
	 */
	public void setCukPlanCode(String cukPlanCode) {
		this.cukPlanCode = cukPlanCode;
	}

	public String getCukCovNum() {
		return cukCovNum;
	}

	public void setCukCovNum(String cukCovNum) {
		this.cukCovNum = cukCovNum;
	}

	/**
	 * @return the par
	 */
	public String getPar() {
		return par;
	}

	/**
	 * @param par the par to set
	 */
	public void setPar(String par) {
		this.par = par;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the claimPaymentId
	 */
	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	/**
	 * @param claimPaymentId the claimPaymentId to set
	 */
	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	/**
	 */
	public FsuWorking() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(FsuWorking that) {
		setFsuWorkingId(that.getFsuWorkingId());
		setCycleDate(that.getCycleDate());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setTransactionDt(that.getTransactionDt());
		setPayeeType(that.getPayeeType());
		setProviderCode(that.getProviderCode());
		setAccountCode(that.getAccountCode());
		setPolicyNo(that.getPolicyNo());
		setTransactionAmt(that.getTransactionAmt());
		setPaBonusDeductAmt(that.getPaBonusDeductAmt());
		setBasicPlanCode(that.getBasicPlanCode());
		setCoveragePlanCode(that.getCoveragePlanCode());
		setProductType(that.getProductType());
		setPaPackageName(that.getPaPackageName());
		setPaymentMethod(that.getPaymentMethod());
		setBankInd(that.getBankInd());
		setSuppressChequeInd(that.getSuppressChequeInd());
		setMarketingChannelCode(that.getMarketingChannelCode());
		setLastModifiedUserDept(that.getLastModifiedUserDept());
		setLastModifiedUserDesk(that.getLastModifiedUserDesk());
		setAgentCodeServicing(that.getAgentCodeServicing());
		setAgencyCodeServicing(that.getAgencyCodeServicing());
		setCsFormatPolicyNo(that.getCsFormatPolicyNo());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setStatus(that.getStatus());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {
		StringBuilder buffer = new StringBuilder();

		buffer.append("fsuWorkingId=[").append(fsuWorkingId).append("] ");
		buffer.append("cycleDate=[").append(cycleDate).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("transactionDt=[").append(transactionDt).append("] ");
		buffer.append("payeeType=[").append(payeeType).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("accountCode=[").append(accountCode).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("transactionAmt=[").append(transactionAmt).append("] ");
		buffer.append("paBonusDeductAmt=[").append(paBonusDeductAmt).append("] ");
		buffer.append("basicPlanCode=[").append(basicPlanCode).append("] ");
		buffer.append("coveragePlanCode=[").append(coveragePlanCode).append("] ");
		buffer.append("productType=[").append(productType).append("] ");
		buffer.append("paPackageName=[").append(paPackageName).append("] ");
		buffer.append("paymentMethod=[").append(paymentMethod).append("] ");
		buffer.append("bankInd=[").append(bankInd).append("] ");
		buffer.append("suppressChequeInd=[").append(suppressChequeInd).append("] ");
		buffer.append("marketingChannelCode=[").append(marketingChannelCode).append("] ");
		buffer.append("postingDesc=[").append(postingDesc).append("] ");
		buffer.append("lastModifiedUserDept=[").append(lastModifiedUserDept).append("] ");
		buffer.append("lastModifiedUserDesk=[").append(lastModifiedUserDesk).append("] ");
		buffer.append("agentCodeServicing=[").append(agentCodeServicing).append("] ");
		buffer.append("agencyCodeServicing=[").append(agencyCodeServicing).append("] ");
		buffer.append("csFormatPolicyNo=[").append(csFormatPolicyNo).append("] ");
		buffer.append("status=[").append(status).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((fsuWorkingId == null) ? 0 : fsuWorkingId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof FsuWorking))
			return false;
		FsuWorking equalCheck = (FsuWorking) obj;
		if ((fsuWorkingId == null && equalCheck.fsuWorkingId != null) || (fsuWorkingId != null && equalCheck.fsuWorkingId == null))
			return false;
		if (fsuWorkingId != null && !fsuWorkingId.equals(equalCheck.fsuWorkingId))
			return false;
		return true;
	}

}
