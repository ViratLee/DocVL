package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 */

@SqlResultSetMapping(name = "NetworkJoinNetworkDetail", classes = { @ConstructorResult(targetClass = NetworkJoinNetworkDetail.class, columns = { @ColumnResult(name = "networkId")

}) })
//@Table(name = "PROVIDER")
//@SecondaryTables({ @SecondaryTable(name = "PROVIDERCONTACT", pkJoinColumns = @PrimaryKeyJoinColumn(name = "PROVIDERCODE", referencedColumnName = "PROVIDERCODE")) })
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "NetworkJoinNetworkDetail")
public class NetworkJoinNetworkDetail extends BaseEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 */
	@Id
	@Column(name = "NETWORKID")
	Long networkId;
	/**
	 */

	@Column(name = "NETWORKNAME")
	String networkName;
	/**
	 */

	@Column(name = "EFFECTIVETODT")
	Date effectiveToDt;
	/**
	 */

	@Column(name = "BUSINESSLINE")
	String businessLine;
	/**
	 */

	@Column(name = "NETWORKTYPE")
	String networkType;
	/**
	 */

	@Column(name = "NETWORKSPECIFICPRODUCT")
	String networkSpecificProduct;

	@Column(name = "BUSINESSLINEID")
	String businessLineId;
	/**
	 */

	@Column(name = "NETWORKTYPEID")
	String networkTypeId;
	/**
	 */

	@Column(name = "NETWORKSPECIFICPRODUCTID")
	String networkSpecificProductId;

	public Long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getNetworkSpecificProduct() {
		return networkSpecificProduct;
	}

	public void setNetworkSpecificProduct(String networkSpecificProduct) {
		this.networkSpecificProduct = networkSpecificProduct;
	}

	public String getBusinessLineId() {
		return businessLineId;
	}

	public void setBusinessLineId(String businessLineId) {
		this.businessLineId = businessLineId;
	}

	public String getNetworkTypeId() {
		return networkTypeId;
	}

	public void setNetworkTypeId(String networkTypeId) {
		this.networkTypeId = networkTypeId;
	}

	public String getNetworkSpecificProductId() {
		return networkSpecificProductId;
	}

	public void setNetworkSpecificProductId(String networkSpecificProductId) {
		this.networkSpecificProductId = networkSpecificProductId;
	}

	public void copy(NetworkJoinNetworkDetail that) {

	}

	public NetworkJoinNetworkDetail(Long networkId, String networkName, Date effectiveToDt, String businessLine, String networkType, String networkSpecificProduct) {
		super();
		this.networkId = networkId;
		this.networkName = networkName;
		this.effectiveToDt = effectiveToDt;
		this.businessLine = businessLine;
		this.networkType = networkType;
		this.networkSpecificProduct = networkSpecificProduct;
	}

	public NetworkJoinNetworkDetail() {

	}

	@Override
	public String toString() {
		return "NetworkJoinNetworkDetail [networkId=" + networkId + ", networkName=" + networkName + ", effectiveToDt=" + effectiveToDt + ", businessLine=" + businessLine + ", networkType="
				+ networkType + ", networkSpecificProduct=" + networkSpecificProduct + ", businessLineId=" + businessLineId + ", networkTypeId=" + networkTypeId + ", networkSpecificProductId="
				+ networkSpecificProductId + "]";
	}

}
