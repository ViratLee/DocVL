package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "EDIDOCTORS")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "EdiDoctors")
public class EdiDoctors extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ediDoctorsSequence")
	@SequenceGenerator(name = "ediDoctorsSequence", sequenceName = "s_edidoctors")
	@Column(name = "EDIDOCTORSID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long ediDoctorsId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "DOCTORLICENSE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doctorLicense;

	@Column(name = "DOCTORROLE", length = 400)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doctorRole;

	public Long getEdiDoctorsId() {
		return ediDoctorsId;
	}

	public void setEdiDoctorsId(Long ediDoctorsId) {
		this.ediDoctorsId = ediDoctorsId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getDoctorLicense() {
		return doctorLicense;
	}

	public void setDoctorLicense(String doctorLicense) {
		this.doctorLicense = setMaxLength("doctorLicense", doctorLicense);
	}

	public String getDoctorRole() {
		return doctorRole;
	}

	public void setDoctorRole(String doctorRole) {
		this.doctorRole = setMaxLength("doctorRole", doctorRole);
	}

	public EdiDoctors() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(EdiDoctors that) {

		setEdiDoctorsId(that.getEdiDoctorsId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setDoctorLicense(that.getDoctorLicense());
		setDoctorRole(that.getDoctorRole());

	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("ediDoctorsId=[").append(ediDoctorsId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("doctorLicense=[").append(doctorLicense).append("] ");
		buffer.append("doctorRole=[").append(doctorRole).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((ediDoctorsId == null) ? 0 : ediDoctorsId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof EdiDoctors))
			return false;
		EdiDoctors equalCheck = (EdiDoctors) obj;
		if ((ediDoctorsId == null && equalCheck.ediDoctorsId != null) || (ediDoctorsId != null && equalCheck.ediDoctorsId == null))
			return false;
		if (ediDoctorsId != null && !ediDoctorsId.equals(equalCheck.ediDoctorsId))
			return false;
		return true;
	}

	private String setMaxLength(String columnName, String data) {
		if (data == null) {
			return data;
		}
		try {
			int size = getClass().getDeclaredField(columnName).getAnnotation(Column.class).length();
			int inLength = data.length();
			if (inLength > size) {
				data = data.substring(0, size);
			}
		} catch (NoSuchFieldException ex) {
		} catch (SecurityException ex) {
		}
		return data;
	}
}
