package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@NamedQueries({ @NamedQuery(name = "findAllCwsWorking", query = "select myCwsWorking from CwsWorking myCwsWorking"),
		@NamedQuery(name = "findCwsWorkingById", query = "select myCwsWorking from CwsWorking myCwsWorking where myCwsWorking.cwsWorkingId = ?1"),
		@NamedQuery(name = "findCwsWorkingWhenPostInvoiceFlagIsFalse", query = "select myCwsWorking from CwsWorking myCwsWorking where (myCwsWorking.cycleDate between ?1 and ?2) and myCwsWorking.collectionMethod= ?3 and myCwsWorking.payeeTitle= ?4 and myCwsWorking.payeeFirstName = ?5 and myCwsWorking.payeeLastName= ?6 and myCwsWorking.insuredTitle=?7 and myCwsWorking.insuredFirstName=?8 and myCwsWorking.insuredLastName=?9 and ( myCwsWorking.businessLine in ('OL','PA')) order by myCwsWorking.aggregationCounts desc"),
		@NamedQuery(name = "findCwsWorkingWhenPostInvoiceFlagIsTrue", query = "select myCwsWorking from CwsWorking myCwsWorking where (myCwsWorking.cycleDate between ?1 and ?2) and myCwsWorking.collectionMethod =?3 and myCwsWorking.providerCode=?4 and myCwsWorking.payeeTitle = ?5 and myCwsWorking.payeeFirstName= ?6 and myCwsWorking.payeeLastName= ?7 and ( myCwsWorking.businessLine in ('OL','PA')) order by myCwsWorking.aggregationCounts desc"),
		@NamedQuery(name = "findCwsWorkingForCSAggregationOwner", query = "select myCwsWorking from CwsWorking myCwsWorking where (myCwsWorking.cycleDate between ?1 and ?2) and myCwsWorking.collectionMethod =?3 and myCwsWorking.policyNo =?4 and myCwsWorking.certNo =?5 and myCwsWorking.subOfficeCode =?6 and myCwsWorking.payeeType =?7 and myCwsWorking.businessLine=?8 order by myCwsWorking.aggregationCounts desc"),
		@NamedQuery(name = "findCwsWorkingForCSAggregationCompany", query = "select myCwsWorking from CwsWorking myCwsWorking where (myCwsWorking.cycleDate between ?1 and ?2) and myCwsWorking.collectionMethod =?3 and myCwsWorking.policyNo =?4 and myCwsWorking.subOfficeCode =?5 and myCwsWorking.payeeType =?6 and myCwsWorking.businessLine=?7 order by myCwsWorking.aggregationCounts desc"),
		@NamedQuery(name = "findCwsWorkingForCSAggregationProvider", query = "select myCwsWorking from CwsWorking myCwsWorking where (myCwsWorking.cycleDate between ?1 and ?2) and myCwsWorking.payeeType =?3 and myCwsWorking.businessLine=?4 and myCwsWorking.providerCode=?5 order by myCwsWorking.aggregationCounts desc"),
		@NamedQuery(name = "checkAggregation", query = "select myCwsWorking from CwsWorking myCwsWorking where (myCwsWorking.cycleDate between ?1 and ?2) and myCwsWorking.collectionMethod= ?3 and myCwsWorking.payeeTitle= ?4 and myCwsWorking.payeeFirstName = ?5 and myCwsWorking.payeeLastName= ?6 and myCwsWorking.insuredTitle=?7 and myCwsWorking.insuredFirstName=?8 and myCwsWorking.insuredLastName=?9 and myCwsWorking.claimNo=?10"),
		@NamedQuery(name = "findCWSWorkingByFSURelated", query = "select myCwsWorking from CwsWorking myCwsWorking where myCwsWorking.fsuRelated like ?1"),
		@NamedQuery(name = "clearCWSWorking", query = "delete from CwsWorking myCwsWorking where myCwsWorking.cwsWorkingId= ?1"),

})
@Table(name = "CWSWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "CwsWorking")
public class CwsWorking extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "cwsWorkingSequence")
	@SequenceGenerator(name = "cwsWorkingSequence", sequenceName = "s_cwsworking")
	@Column(name = "CWSWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long cwsWorkingId;

	@Column(name = "CYCLEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date cycleDate;

	@Column(name = "COMPANYID", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "TRANSACTIONDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date transactionDt;

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;

	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String productCode;

	@Column(name = "KEYPOLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String keyPolicyNo;

	@Column(name = "TRANSACTIONAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal transactionAmt;

	@Column(name = "COLLECTIONMETHOD", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String collectionMethod;

	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;

	@Column(name = "PAYEETITLE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTitle;

	@Column(name = "PAYEELASTNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeLastName;

	@Column(name = "PAYEEFIRSTNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeFirstName;

	@Column(name = "ADDRESSLINE1", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;

	@Column(name = "ADDRESSLINE2", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;

	@Column(name = "ADDRESSLINE3", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;

	@Column(name = "ADDRESSLINE4", length = 255)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;

	@Column(name = "CITY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String city;

	@Column(name = "STATE", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String state;

	@Column(name = "POSTALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String postalCode;

	@Column(name = "COUNTRY", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String country;

	@Column(name = "INSUREDTITLE", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredTitle;

	@Column(name = "INSUREDLASTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredLastName;

	@Column(name = "INSUREDFIRSTNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String insuredFirstName;

	@Column(name = "MEDIACLEARINGIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String mediaClearingInd;

	@Column(name = "BANKRUPTCYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String bankruptcyInd;

	@Column(name = "AMLOIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String amloInd;

	@Column(name = "BLACKLISTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String blacklistInd;

	@Column(name = "ABSOLUTEASSIGNIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String absoluteAssignInd;

	@Column(name = "SUPPRESSCHEQUEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suppressChequeInd;

	@Column(name = "SERVICINGAGENCYOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyOfficeCode;

	@Column(name = "AGENCYCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyCodeServicing;

	@Column(name = "AGENCYWRITINGCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyWritingCode;

	@Column(name = "AGENTCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentCodeServicing;

	@Column(name = "AGENTWRITINGCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentWritingCode;

	@Column(name = "PICKUPCHQIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String pickUpChqInd;

	@Column(name = "AGGREGATIONCOUNTS")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer aggregationCounts;

	@Column(name = "LASTMODIFIEDUSERDEPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDept;

	@Column(name = "LASTMODIFIEDUSERDESK", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDesk;

	/**
	 */
	@Column(name = "CSFORMATPOLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String csFormatPolicyNo;

	@Column(name = "SUSPENDCODE", length = 15)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String suspendCode;

	@Column(name = "FSURELATED", length = 2000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fsuRelated;

	@Column(name = "DEATHIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deathInd;

	@Column(name = "CERTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String certNo;

	@Column(name = "PAYEETYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeType;

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;

	@Column(name = "DISTRIBUTIONIND", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String distributionInd;

	public Long getCwsWorkingId() {
		return cwsWorkingId;
	}

	public void setCwsWorkingId(Long cwsWorkingId) {
		this.cwsWorkingId = cwsWorkingId;
	}

	public Date getCycleDate() {
		return cycleDate;
	}

	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public Date getTransactionDt() {
		return transactionDt;
	}

	public void setTransactionDt(Date transactionDt) {
		this.transactionDt = transactionDt;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getKeyPolicyNo() {
		return keyPolicyNo;
	}

	public void setKeyPolicyNo(String keyPolicyNo) {
		this.keyPolicyNo = keyPolicyNo;
	}

	public BigDecimal getTransactionAmt() {
		return transactionAmt;
	}

	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	public String getCollectionMethod() {
		return collectionMethod;
	}

	public void setCollectionMethod(String collectionMethod) {
		this.collectionMethod = collectionMethod;
	}

	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}

	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeLastName() {
		return payeeLastName;
	}

	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	public String getPayeeFirstName() {
		return payeeFirstName;
	}

	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getInsuredTitle() {
		return insuredTitle;
	}

	public void setInsuredTitle(String insuredTitle) {
		this.insuredTitle = insuredTitle;
	}

	public String getInsuredLastName() {
		return insuredLastName;
	}

	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String getInsuredFirstName() {
		return insuredFirstName;
	}

	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	public String getMediaClearingInd() {
		return mediaClearingInd;
	}

	public void setMediaClearingInd(String mediaClearingInd) {
		this.mediaClearingInd = mediaClearingInd;
	}

	public String getBankruptcyInd() {
		return bankruptcyInd;
	}

	public void setBankruptcyInd(String bankruptcyInd) {
		this.bankruptcyInd = bankruptcyInd;
	}

	public String getAmloInd() {
		return amloInd;
	}

	public void setAmloInd(String amloInd) {
		this.amloInd = amloInd;
	}

	public String getBlacklistInd() {
		return blacklistInd;
	}

	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	public String getAbsoluteAssignInd() {
		return absoluteAssignInd;
	}

	public void setAbsoluteAssignInd(String absoluteAssignInd) {
		this.absoluteAssignInd = absoluteAssignInd;
	}

	public String getSuppressChequeInd() {
		return suppressChequeInd;
	}

	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	public String getServicingAgencyOfficeCode() {
		return servicingAgencyOfficeCode;
	}

	public void setServicingAgencyOfficeCode(String servicingAgencyOfficeCode) {
		this.servicingAgencyOfficeCode = servicingAgencyOfficeCode;
	}

	public String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	public String getAgencyWritingCode() {
		return agencyWritingCode;
	}

	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	public String getAgentWritingCode() {
		return agentWritingCode;
	}

	public void setAgentWritingCode(String agentWritingCode) {
		this.agentWritingCode = agentWritingCode;
	}

	public String getPickUpChqInd() {
		return pickUpChqInd;
	}

	public void setPickUpChqInd(String pickUpChqInd) {
		this.pickUpChqInd = pickUpChqInd;
	}

	public Integer getAggregationCounts() {
		return aggregationCounts;
	}

	public void setAggregationCounts(Integer aggregationCounts) {
		this.aggregationCounts = aggregationCounts;
	}

	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	/**
	 * @return the csFormatPolicyNo
	 */
	public String getCsFormatPolicyNo() {
		return csFormatPolicyNo;
	}

	/**
	 * @param csFormatPolicyNo the csFormatPolicyNo to set
	 */
	public void setCsFormatPolicyNo(String csFormatPolicyNo) {
		this.csFormatPolicyNo = csFormatPolicyNo;
	}

	public String getSuspendCode() {
		return suspendCode;
	}

	public void setSuspendCode(String suspendCode) {
		this.suspendCode = suspendCode;
	}

	/**
	 * @return the deathInd
	 */
	public String getDeathInd() {
		return deathInd;
	}

	/**
	 * @param deathInd the deathInd to set
	 */
	public void setDeathInd(String deathInd) {
		this.deathInd = deathInd;
	}

	/**
	 * @return the certNo
	 */
	public String getCertNo() {
		return certNo;
	}

	/**
	 * @param certNo the certNo to set
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getFsuRelated() {
		return fsuRelated;
	}

	public void setFsuRelated(String fsuRelated) {
		this.fsuRelated = fsuRelated;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the subOfficeCode
	 */
	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	/**
	 * @param subOfficeCode the subOfficeCode to set
	 */
	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	/**
	 * @return the distributionInd
	 */
	public String getDistributionInd() {
		return distributionInd;
	}

	/**
	 * @param distributionInd the distributionInd to set
	 */
	public void setDistributionInd(String distributionInd) {
		this.distributionInd = distributionInd;
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CwsWorking that) {
		setCwsWorkingId(that.getCwsWorkingId());
		setCycleDate(that.getCycleDate());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setTransactionDt(that.getTransactionDt());
		setBusinessLine(that.getBusinessLine());
		setProductCode(that.getProductCode());
		setPolicyNo(that.getPolicyNo());
		setKeyPolicyNo(that.getKeyPolicyNo());
		setTransactionAmt(that.getTransactionAmt());
		setCollectionMethod(that.getCollectionMethod());
		setProviderCode(that.getProviderCode());
		setPayeeTitle(that.getPayeeTitle());
		setPayeeLastName(that.getPayeeLastName());
		setPayeeFirstName(that.getPayeeFirstName());
		setAddressLine1(that.getAddressLine1());
		setAddressLine2(that.getAddressLine2());
		setAddressLine3(that.getAddressLine3());
		setAddressLine4(that.getAddressLine4());
		setCity(that.getCity());
		setState(that.getState());
		setPostalCode(that.getPostalCode());
		setCountry(that.getCountry());
		setInsuredTitle(that.getInsuredTitle());
		setInsuredLastName(that.getInsuredLastName());
		setInsuredFirstName(that.getInsuredFirstName());
		setMediaClearingInd(that.getMediaClearingInd());
		setBankruptcyInd(that.getBankruptcyInd());
		setAmloInd(that.getAmloInd());
		setBlacklistInd(that.getBlacklistInd());
		setAbsoluteAssignInd(that.getAbsoluteAssignInd());
		setSuppressChequeInd(that.getSuppressChequeInd());
		setServicingAgencyOfficeCode(that.getServicingAgencyOfficeCode());
		setAgencyCodeServicing(that.getAgencyCodeServicing());
		setAgencyWritingCode(that.getAgencyWritingCode());
		setAgentCodeServicing(that.getAgentCodeServicing());
		setAgentWritingCode(that.getAgentWritingCode());
		setPickUpChqInd(that.getPickUpChqInd());
		setAggregationCounts(that.getAggregationCounts());
		setLastModifiedUserDept(that.getLastModifiedUserDept());
		setLastModifiedUserDesk(that.getLastModifiedUserDesk());
		setCsFormatPolicyNo(that.getCsFormatPolicyNo());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("cwsWorkingId=[").append(cwsWorkingId).append("] ");
		buffer.append("cycleDate=[").append(cycleDate).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("transactionDt=[").append(transactionDt).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("keyPolicyNo=[").append(keyPolicyNo).append("] ");
		buffer.append("transactionAmt=[").append(transactionAmt).append("] ");
		buffer.append("collectionMethod=[").append(collectionMethod).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("payeeTitle=[").append(payeeTitle).append("] ");
		buffer.append("payeeLastName=[").append(payeeLastName).append("] ");
		buffer.append("payeeFirstName=[").append(payeeFirstName).append("] ");
		buffer.append("addressLine1=[").append(addressLine1).append("] ");
		buffer.append("addressLine2=[").append(addressLine2).append("] ");
		buffer.append("addressLine3=[").append(addressLine3).append("] ");
		buffer.append("addressLine4=[").append(addressLine4).append("] ");
		buffer.append("city=[").append(city).append("] ");
		buffer.append("state=[").append(state).append("] ");
		buffer.append("postalCode=[").append(postalCode).append("] ");
		buffer.append("country=[").append(country).append("] ");
		buffer.append("insuredTitle=[").append(insuredTitle).append("] ");
		buffer.append("insuredLastName=[").append(insuredLastName).append("] ");
		buffer.append("insuredFirstName=[").append(insuredFirstName).append("] ");
		buffer.append("mediaClearingInd=[").append(mediaClearingInd).append("] ");
		buffer.append("bankruptcyInd=[").append(bankruptcyInd).append("] ");
		buffer.append("amloInd=[").append(amloInd).append("] ");
		buffer.append("blacklistInd=[").append(blacklistInd).append("] ");
		buffer.append("absoluteAssignInd=[").append(absoluteAssignInd).append("] ");
		buffer.append("suppressChequeInd=[").append(suppressChequeInd).append("] ");
		buffer.append("servicingAgencyOfficeCode=[").append(servicingAgencyOfficeCode).append("] ");
		buffer.append("agencyCodeServicing=[").append(agencyCodeServicing).append("] ");
		buffer.append("agencyWritingCode=[").append(agencyWritingCode).append("] ");
		buffer.append("agentCodeServicing=[").append(agentCodeServicing).append("] ");
		buffer.append("agentWritingCode=[").append(agentWritingCode).append("] ");
		buffer.append("pickUpChqInd=[").append(pickUpChqInd).append("] ");
		buffer.append("aggregationCounts=[").append(aggregationCounts).append("] ");
		buffer.append("lastModifiedUserDept=[").append(lastModifiedUserDept).append("] ");
		buffer.append("lastModifiedUserDesk=[").append(lastModifiedUserDesk).append("] ");
		buffer.append("csFormatPolicyNo=[").append(csFormatPolicyNo).append("] ");

		return buffer.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((cwsWorkingId == null) ? 0 : cwsWorkingId.hashCode()));
		return result;
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CwsWorking))
			return false;
		CwsWorking equalCheck = (CwsWorking) obj;
		if ((cwsWorkingId == null && equalCheck.cwsWorkingId != null) || (cwsWorkingId != null && equalCheck.cwsWorkingId == null))
			return false;
		if (cwsWorkingId != null && !cwsWorkingId.equals(equalCheck.cwsWorkingId))
			return false;
		return true;
	}
}
