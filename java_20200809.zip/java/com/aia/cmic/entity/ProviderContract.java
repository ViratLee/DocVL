package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllProviderContracts", query = "select myProviderContract from ProviderContract myProviderContract"),
		@NamedQuery(name = "findProviderContractByApprovedBy", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.approvedBy = ?1"),
		@NamedQuery(name = "findProviderContractByApprovedByContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.approvedBy like ?1"),
		@NamedQuery(name = "findProviderContractByContractId", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.contractId = ?1"),
		@NamedQuery(name = "findProviderContractByContractStatus", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.contractStatus = ?1"),
		@NamedQuery(name = "findProviderContractByContractStatusContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.contractStatus like ?1"),
		@NamedQuery(name = "findProviderContractByNetworkName", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.networkName = ?1"),
		@NamedQuery(name = "findProviderContractByNetworkNameContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.networkName like ?1"),
		@NamedQuery(name = "findProviderContractByPaymentTerm", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.paymentTerm = ?1"),
		@NamedQuery(name = "findProviderContractByPaymentTermContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.paymentTerm like ?1"),
		@NamedQuery(name = "findProviderContractByPreparedBy", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.preparedBy = ?1"),
		@NamedQuery(name = "findProviderContractByPreparedByContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.preparedBy like ?1"),
		@NamedQuery(name = "findProviderContractByPrimaryKey", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.providerContractId = ?1"),
		@NamedQuery(name = "findProviderContractByProviderContractId", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.providerContractId = ?1"),
		@NamedQuery(name = "findProviderContractByProviderCode", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.providerCode = ?1"),
		@NamedQuery(name = "findProviderContractByServiceCoverage", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.serviceCoverage = ?1"),
		@NamedQuery(name = "findProviderContractByServiceCoverageContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.serviceCoverage like ?1"),
		@NamedQuery(name = "findProviderContractByVolumeDiscount", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.volumeDiscount = ?1"),
		@NamedQuery(name = "findProviderCtPaymentTermByProviderCodeAndContractStatus", query = "select myProviderContract.paymentTerm from ProviderContract myProviderContract where myProviderContract.providerCode = ?1 and myProviderContract.contractStatus=?2"),
		@NamedQuery(name = "findProviderContractByVolumeDiscountContaining", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.volumeDiscount like ?1"),
		@NamedQuery(name = "findProviderContractByCriteria", query = "select myProviderContract from ProviderContract myProviderContract where myProviderContract.providerCode = ?1 and myProviderContract.effectiveFromDt <= ?2 and (myProviderContract.effectiveToDt >= ?3 or myProviderContract.effectiveToDt is null) and myProviderContract.contractStatus = ?4") })
@Table(name = "PROVIDERCONTRACT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderContract")
public class ProviderContract extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "providerContractSequence")
	@SequenceGenerator(name = "providerContractSequence", sequenceName = "s_providercontract")
	@Column(name = "PROVIDERCONTRACTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long providerContractId;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "CONTRACTID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer contractId;
	/**
	 */

	@Column(name = "CONTRACTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String contractStatus;
	/**
	 */

	@Column(name = "SERVICECOVERAGE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceCoverage;
	/**
	 */

	@Column(name = "EFFECTIVEFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveFromDt;
	/**
	 */

	@Column(name = "EFFECTIVETODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveToDt;
	/**
	 */

	@Column(name = "NETWORKNAME", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String networkName;
	/**
	 */

	@Column(name = "PAYMENTTERM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer paymentTerm;
	/**
	 */

	@Column(name = "VOLUMEDISCOUNT", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String volumeDiscount;
	/**
	 */

	@Column(name = "PREPAREDBY", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String preparedBy;
	/**
	 */

	@Column(name = "APPROVEDBY", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String approvedBy;

	/**
	 */

	@Column(name = "CONTRACTPROCESSSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String contractProcessStatus;

	/**
	 * @return the providerContractId
	 */
	public Long getProviderContractId() {
		return providerContractId;
	}

	/**
	 * @param providerContractId the providerContractId to set
	 */
	public void setProviderContractId(Long providerContractId) {
		this.providerContractId = providerContractId;
	}

	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}

	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 * @return the contractId
	 */
	public Integer getContractId() {
		return contractId;
	}

	/**
	 * @param contractId the contractId to set
	 */
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	/**
	 * @return the contractStatus
	 */
	public String getContractStatus() {
		return contractStatus;
	}

	/**
	 * @param contractStatus the contractStatus to set
	 */
	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	/**
	 * @return the serviceCoverage
	 */
	public String getServiceCoverage() {
		return serviceCoverage;
	}

	/**
	 * @param serviceCoverage the serviceCoverage to set
	 */
	public void setServiceCoverage(String serviceCoverage) {
		this.serviceCoverage = serviceCoverage;
	}

	/**
	 * @return the effectiveFromDt
	 */
	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	/**
	 * @param effectiveFromDt the effectiveFromDt to set
	 */
	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	/**
	 * @return the effectiveToDt
	 */
	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	/**
	 * @param effectiveToDt the effectiveToDt to set
	 */
	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	/**
	 * @return the network
	 */
	public String getNetworkName() {
		return networkName;
	}

	/**
	 * @param network the network to set
	 */
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	/**
	 * @return the paymentTerm
	 */
	public Integer getPaymentTerm() {
		return paymentTerm;
	}

	/**
	 * @param paymentTerm the paymentTerm to set
	 */
	public void setPaymentTerm(Integer paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	/**
	 * @return the volumeDiscount
	 */
	public String getVolumeDiscount() {
		return volumeDiscount;
	}

	/**
	 * @param volumeDiscount the volumeDiscount to set
	 */
	public void setVolumeDiscount(String volumeDiscount) {
		this.volumeDiscount = volumeDiscount;
	}

	/**
	 * @return the preparedBy
	 */
	public String getPreparedBy() {
		return preparedBy;
	}

	/**
	 * @param preparedBy the preparedBy to set
	 */
	public void setPreparedBy(String preparedBy) {
		this.preparedBy = preparedBy;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the contractProcessStatus
	 */
	public String getContractProcessStatus() {
		return contractProcessStatus;
	}

	/**
	 * @param contractProcessStatus the contractProcessStatus to set
	 */
	public void setContractProcessStatus(String contractProcessStatus) {
		this.contractProcessStatus = contractProcessStatus;
	}

	/**
	 */
	public ProviderContract() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProviderContract that) {
		setProviderContractId(that.getProviderContractId());
		setProviderCode(that.getProviderCode());
		setContractId(that.getContractId());
		setContractStatus(that.getContractStatus());
		setServiceCoverage(that.getServiceCoverage());
		setEffectiveFromDt(that.getEffectiveFromDt());
		setEffectiveToDt(that.getEffectiveToDt());
		setNetworkName(that.getNetworkName());
		setPaymentTerm(that.getPaymentTerm());
		setVolumeDiscount(that.getVolumeDiscount());
		setPreparedBy(that.getPreparedBy());
		setApprovedBy(that.getApprovedBy());
		setContractProcessStatus(that.getContractProcessStatus());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("providerContractId=[").append(providerContractId).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("contractId=[").append(contractId).append("] ");
		buffer.append("contractStatus=[").append(contractStatus).append("] ");
		buffer.append("serviceCoverage=[").append(serviceCoverage).append("] ");
		buffer.append("effectiveFromDt=[").append(effectiveFromDt).append("] ");
		buffer.append("effectiveToDt=[").append(effectiveToDt).append("] ");
		buffer.append("networkName=[").append(networkName).append("] ");
		buffer.append("paymentTerm=[").append(paymentTerm).append("] ");
		buffer.append("volumeDiscount=[").append(volumeDiscount).append("] ");
		buffer.append("preparedBy=[").append(preparedBy).append("] ");
		buffer.append("approvedBy=[").append(approvedBy).append("] ");
		buffer.append("contractProcessStatus=[").append(contractProcessStatus).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((providerContractId == null) ? 0 : providerContractId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProviderContract))
			return false;
		ProviderContract equalCheck = (ProviderContract) obj;
		if ((providerContractId == null && equalCheck.providerContractId != null) || (providerContractId != null && equalCheck.providerContractId == null))
			return false;
		if (providerContractId != null && !providerContractId.equals(equalCheck.providerContractId))
			return false;
		return true;
	}
}
