package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findAllCycleDates", query = "select myCycleDate from CycleDate myCycleDate"),
		@NamedQuery(name = "findCycleDateByApplicationName", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.applicationName = ?1"),
		@NamedQuery(name = "findCycleDateByApplicationNameContaining", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.applicationName like ?1"),
		@NamedQuery(name = "findCycleDateByBeforePreviousCycleDt", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.beforePreviousCycleDt = ?1"),
		@NamedQuery(name = "findCycleDateByCurrentCycleDt", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.currentCycleDt = ?1"),
		@NamedQuery(name = "findCycleDateByNextCycleDt", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.nextCycleDt = ?1"),
		@NamedQuery(name = "findCycleDateByPreviousCycleDt", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.previousCycleDt = ?1"),
		@NamedQuery(name = "findCycleDateByPrimaryKey", query = "select myCycleDate from CycleDate myCycleDate where myCycleDate.applicationName = ?1"),
		@NamedQuery(name = "findcurrentCycleDateByApplicationName", query = "select myCycleDate.currentCycleDt from CycleDate myCycleDate where trim(upper(myCycleDate.applicationName)) = ?1") })
@Table(name = "CYCLEDATE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "CycleDate")
public class CycleDate extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final String APPNAME_BCLAIMS = "bclaims";
	public static final String APPNAME_DCLAIMS = "batch-d";
	/**
	 */

	@Column(name = "APPLICATIONNAME", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String applicationName;
	/**
	 */
	@Column(name = "BEFOREPREVIOUSCYCLEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date beforePreviousCycleDt;
	/**
	 */
	@Column(name = "PREVIOUSCYCLEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date previousCycleDt;
	/**
	 */
	@Column(name = "CURRENTCYCLEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date currentCycleDt;
	/**
	 */
	@Column(name = "NEXTCYCLEDT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date nextCycleDt;

	/**
	 * @return the applicationName
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * @param applicationName the applicationName to set
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * @return the beforePreviousCycleDt
	 */
	public Date getBeforePreviousCycleDt() {
		return beforePreviousCycleDt;
	}

	/**
	 * @param beforePreviousCycleDt the beforePreviousCycleDt to set
	 */
	public void setBeforePreviousCycleDt(Date beforePreviousCycleDt) {
		this.beforePreviousCycleDt = beforePreviousCycleDt;
	}

	/**
	 * @return the previousCycleDt
	 */
	public Date getPreviousCycleDt() {
		return previousCycleDt;
	}

	/**
	 * @param previousCycleDt the previousCycleDt to set
	 */
	public void setPreviousCycleDt(Date previousCycleDt) {
		this.previousCycleDt = previousCycleDt;
	}

	/**
	 * @return the currentCycleDt
	 */
	public Date getCurrentCycleDt() {
		return currentCycleDt;
	}

	/**
	 * @param currentCycleDt the currentCycleDt to set
	 */
	public void setCurrentCycleDt(Date currentCycleDt) {
		this.currentCycleDt = currentCycleDt;
	}

	/**
	 * @return the nextCycleDt
	 */
	public Date getNextCycleDt() {
		return nextCycleDt;
	}

	/**
	 * @param nextCycleDt the nextCycleDt to set
	 */
	public void setNextCycleDt(Date nextCycleDt) {
		this.nextCycleDt = nextCycleDt;
	}

	/**
	 */
	public CycleDate() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CycleDate that) {
		setApplicationName(that.getApplicationName());
		setBeforePreviousCycleDt(that.getBeforePreviousCycleDt());
		setPreviousCycleDt(that.getPreviousCycleDt());
		setCurrentCycleDt(that.getCurrentCycleDt());
		setNextCycleDt(that.getNextCycleDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("applicationName=[").append(applicationName).append("] ");
		buffer.append("beforePreviousCycleDt=[").append(beforePreviousCycleDt).append("] ");
		buffer.append("previousCycleDt=[").append(previousCycleDt).append("] ");
		buffer.append("currentCycleDt=[").append(currentCycleDt).append("] ");
		buffer.append("nextCycleDt=[").append(nextCycleDt).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((applicationName == null) ? 0 : applicationName.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CycleDate))
			return false;
		CycleDate equalCheck = (CycleDate) obj;
		if ((applicationName == null && equalCheck.applicationName != null) || (applicationName != null && equalCheck.applicationName == null))
			return false;
		if (applicationName != null && !applicationName.equals(equalCheck.applicationName))
			return false;
		return true;
	}
}
