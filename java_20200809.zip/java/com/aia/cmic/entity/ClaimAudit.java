package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findClaimsAuditByClaimNoAndOccurrence", query = "select claimAudit from ClaimAudit claimAudit where claimAudit.claimNo = ?1 and claimAudit.occurrence = ?2 order by claimAudit.modifideDt desc") })
@Table(name = "CLAIM_AUDIT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimAudit")
public class ClaimAudit implements Serializable {
	private static final long serialVersionUID = 1L;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Long getClaimAuditId() {
		return claimAuditId;
	}

	public void setClaimAuditId(Long claimAuditId) {
		this.claimAuditId = claimAuditId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public Date getModifideDt() {
		return modifideDt;
	}

	public void setModifideDt(Date modifideDt) {
		this.modifideDt = modifideDt;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrance(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getValueAfter() {
		return valueAfter;
	}

	public void setValueAfter(String valueAfter) {
		this.valueAfter = valueAfter;
	}

	public String getValueBefore() {
		return valueBefore;
	}

	public void setValueBefore(String valueBefore) {
		this.valueBefore = valueBefore;
	}

	/**
	 */

	@Column(name = "ACTION", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String action;

	/**
	 */

	@Column(name = "CLAIMAUDITID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	@Id
	Long claimAuditId;

	@Column(name = "CLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "COLUMNNAME", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String columnName;
	/**
	 */

	@Column(name = "MODIFIEDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date modifideDt;
	/**
	 */

	@Column(name = "OCCURRENCE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "RECORDID", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String recordId;
	/**
	 */

	@Column(name = "TABLENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String tableName;
	/**
	 */

	@Column(name = "USERID", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String userId;
	/**
	 */

	@Column(name = "VALUEAFTER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String valueAfter;

	/**
	 */

	@Column(name = "VALUEBEFORE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String valueBefore;

	/**
	 */

	public ClaimAudit() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */

}
