package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findClaimDeductWorking", query = "select myClaimDeductWorking from ClaimDeductWorking myClaimDeductWorking"),
		@NamedQuery(name = "findClaimDeductWorkingByPlan", query = "select nvl(sum(nvl(myClaimDeductWorking.deductAmt,0)),0) from ClaimDeductWorking myClaimDeductWorking where myClaimDeductWorking.companyId=?1 and (myClaimDeductWorking.incidentDate between ?2 and ?3)  and myClaimDeductWorking.policyNo=?4 and myClaimDeductWorking.planId=?5 and (myClaimDeductWorking.planCoverageNo=?6 or myClaimDeductWorking.planCoverageNo is null or trim(myClaimDeductWorking.planCoverageNo)='') "),
		@NamedQuery(name = "removeClaimDeductWorkingByClaimNoPlanPolicy", query = "delete from ClaimDeductWorking myClaimDeductWorking where myClaimDeductWorking.claimNo = ?1 and myClaimDeductWorking.occurrence = ?2 and myClaimDeductWorking.policyNo=?3 and myClaimDeductWorking.planId=?4 and (myClaimDeductWorking.planCoverageNo= ?5 or ?5 is null or ?5='') and (myClaimDeductWorking.productCode= ?6 or ?6 is null or ?6='') "),
		
		 })
@Table(name = "CLAIMDEDUCTWORKING")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimDeductWorking")
public class ClaimDeductWorking extends BaseEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimDeductWorkingSequence")
	@SequenceGenerator(name = "claimDeductWorkingSequence", sequenceName = "s_claimdeductworking")
	@Column(name = "CLAIMDEDUCTWORKINGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimDeductWorkingId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */
	

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productCode;
	/**
	 */

	@Column(name = "PRODUCTTYPE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productType;
	
	/**
	 */
	@Column(name = "INCIDENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Date incidentDate;
	
	/**
	 */
	@Column(name = "DEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal deductAmt;
	
	/**
	 */
	@Column(name = "ORIGBILLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal origBillAmt;
	
	/**
	 */
	@Column(name = "PRESENTEDAMT_AIAIC", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt_AIAIC;
	
	/**
	 */
	@Column(name = "REIMBURSED_AIAIC", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal reimbursed_AIAIC;
	
	/**
	 */
	@Column(name = "BENEFITLIMIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal benefitLimit;
	
	/**
	 */
	@Column(name = "DEDUCTLIMIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal deductLimit;
	
	public void setClaimDeductWorkingId(Long claimDeductWorkingId) {
		this.claimDeductWorkingId = claimDeductWorkingId;
	}

	/**
	 */
	public Long getClaimDeductWorkingId() {
		return this.claimDeductWorkingId;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	/**
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 */
	public String getBenefitCode() {
		return this.benefitCode;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the deductAmt
	 */
	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	/**
	 * @param deductAmt the deductAmt to set
	 */
	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	/**
	 * @return the origBillAmt
	 */
	public BigDecimal getOrigBillAmt() {
		return origBillAmt;
	}

	/**
	 * @param origBillAmt the origBillAmt to set
	 */
	public void setOrigBillAmt(BigDecimal origBillAmt) {
		this.origBillAmt = origBillAmt;
	}

	/**
	 * @return the presentedAmt_AIAIC
	 */
	public BigDecimal getPresentedAmt_AIAIC() {
		return presentedAmt_AIAIC;
	}

	/**
	 * @param presentedAmt_AIAIC the presentedAmt_AIAIC to set
	 */
	public void setPresentedAmt_AIAIC(BigDecimal presentedAmt_AIAIC) {
		this.presentedAmt_AIAIC = presentedAmt_AIAIC;
	}

	/**
	 * @return the reimbursed_AIAIC
	 */
	public BigDecimal getReimbursed_AIAIC() {
		return reimbursed_AIAIC;
	}

	/**
	 * @param reimbursed_AIAIC the reimbursed_AIAIC to set
	 */
	public void setReimbursed_AIAIC(BigDecimal reimbursed_AIAIC) {
		this.reimbursed_AIAIC = reimbursed_AIAIC;
	}

	/**
	 * @return the benefitLimit
	 */
	public BigDecimal getBenefitLimit() {
		return benefitLimit;
	}

	/**
	 * @param benefitLimit the benefitLimit to set
	 */
	public void setBenefitLimit(BigDecimal benefitLimit) {
		this.benefitLimit = benefitLimit;
	}

	/**
	 * @return the deductLimit
	 */
	public BigDecimal getDeductLimit() {
		return deductLimit;
	}

	/**
	 * @param deductLimit the deductLimit to set
	 */
	public void setDeductLimit(BigDecimal deductLimit) {
		this.deductLimit = deductLimit;
	}

	/**
	 */
	public ClaimDeductWorking() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimDeductWorking that) {
		setClaimDeductWorkingId(that.getClaimDeductWorkingId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setBenefitCode(that.getBenefitCode());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimDeductWorkingId=[").append(claimDeductWorkingId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("benefitCode=[").append(benefitCode).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimDeductWorkingId == null) ? 0 : claimDeductWorkingId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimDeductWorking))
			return false;
		ClaimDeductWorking equalCheck = (ClaimDeductWorking) obj;
		if ((claimDeductWorkingId == null && equalCheck.claimDeductWorkingId != null) || (claimDeductWorkingId != null && equalCheck.claimDeductWorkingId == null))
			return false;
		if (claimDeductWorkingId != null && !claimDeductWorkingId.equals(equalCheck.claimDeductWorkingId))
			return false;
		return true;
	}

	public void copyProperties(PaymentAllocationTemp allocationTemp) {

		setCompanyId(allocationTemp.getCompanyId());
		setClaimNo(allocationTemp.getClaimNo());
		setOccurrence(allocationTemp.getOccurence());
		setPolicyNo(allocationTemp.getPolicyNo());
		setPlanId(allocationTemp.getPlanId());
		setPlanCoverageNo(allocationTemp.getPlanCoverageNo());
		setBenefitCode(allocationTemp.getBenefitCode());
		setProductType(allocationTemp.getProductType());
		setProductCode(allocationTemp.getProductCode());
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the incidentDate
	 */
	public Date getIncidentDate() {
		return incidentDate;
	}

	/**
	 * @param incidentDate the incidentDate to set
	 */
	public void setIncidentDate(Date incidentDate) {
		this.incidentDate = incidentDate;
	}

}
