package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(
				name = "findClaimBenefitItemByCompanyIdClaimNoAndOccurrence",
				query = "select myClaimBenefitItem from ClaimBenefitItem myClaimBenefitItem where myClaimBenefitItem.companyId = ?1 and myClaimBenefitItem.claimNo=?2 and myClaimBenefitItem.occurrence=?3"),
		@NamedQuery(name = "deleteClaimBenefitItemByCompanyIdAndClaimNo",
				query = "delete from ClaimBenefitItem myClaimBenefitItem where myClaimBenefitItem.companyId = ?1 and myClaimBenefitItem.claimNo=?2"),
		@NamedQuery(
				name = "findClaimBenefitItemByCompayIdClaimNoOccurrenceAndServiceCatId",
				query = "select myClaimBenefitItem from ClaimBenefitItem myClaimBenefitItem where myClaimBenefitItem.companyId = ?1 and myClaimBenefitItem.claimNo=?2 and myClaimBenefitItem.occurrence=?3 and myClaimBenefitItem.serviceCatId=?4"),
		@NamedQuery(
				name = "sumTotalBillAmount",
				query = "select SUM(myClaimBenefitItem.presentedAmt)- sum(nvl(myClaimBenefitItem.presentedDiscountAmt,0)) from ClaimBenefitItem myClaimBenefitItem where myClaimBenefitItem.companyId = ?1 and myClaimBenefitItem.claimNo= ?2 and myClaimBenefitItem.occurrence= ?3 ")
})
@Table(name = "CLAIMBENEFITITEM")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimBenefitItem")
public class ClaimBenefitItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimBenefitItemSequence")
	@SequenceGenerator(name = "claimBenefitItemSequence", sequenceName = "s_claimbenefititem")
	@Column(name = "CLAIMBENEFITITEMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimBenefitItemId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "SERVICECATID", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceCatId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "PRESENTEDAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt;
	/**
	 */

	@Column(name = "PRESENTEDDISCOUNTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedDiscountAmt;
	/**
	 */

	@Column(name = "PRESENTEDPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedPercentage;
	/**
	 */

	@Column(name = "NOOFDAYSPRESENTED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysPresented;
	/**
	 */

	@Column(name = "NOOFUNIT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfUnit;
	/**
	 */

	@Column(name = "VALUEPERUNIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal valuePerUnit;

	/**
	 */

	/**
	 * @return the claimBenefitItemId
	 */
	public Long getClaimBenefitItemId() {
		return claimBenefitItemId;
	}

	/**
	 * @param claimBenefitItemId the claimBenefitItemId to set
	 */
	public void setClaimBenefitItemId(Long claimBenefitItemId) {
		this.claimBenefitItemId = claimBenefitItemId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return serviceCatId;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the presentedAmt
	 */
	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	/**
	 * @param presentedAmt the presentedAmt to set
	 */
	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 * @return the presentedDiscountAmt
	 */
	public BigDecimal getPresentedDiscountAmt() {
		return presentedDiscountAmt;
	}

	/**
	 * @param presentedDiscountAmt the presentedDiscountAmt to set
	 */
	public void setPresentedDiscountAmt(BigDecimal presentedDiscountAmt) {
		this.presentedDiscountAmt = presentedDiscountAmt;
	}

	/**
	 * @return the presentedPercentage
	 */
	public BigDecimal getPresentedPercentage() {
		return presentedPercentage;
	}

	/**
	 * @param presentedPercentage the presentedPercentage to set
	 */
	public void setPresentedPercentage(BigDecimal presentedPercentage) {
		this.presentedPercentage = presentedPercentage;
	}

	/**
	 * @return the noOfDaysPresented
	 */
	public Integer getNoOfDaysPresented() {
		return noOfDaysPresented;
	}

	/**
	 * @param noOfDaysPresented the noOfDaysPresented to set
	 */
	public void setNoOfDaysPresented(Integer noOfDaysPresented) {
		this.noOfDaysPresented = noOfDaysPresented;
	}

	/**
	 * @return the noOfUnit
	 */
	public Integer getNoOfUnit() {
		return noOfUnit;
	}

	/**
	 * @param noOfUnit the noOfUnit to set
	 */
	public void setNoOfUnit(Integer noOfUnit) {
		this.noOfUnit = noOfUnit;
	}

	/**
	 * @return the valuePerUnit
	 */
	public BigDecimal getValuePerUnit() {
		return valuePerUnit;
	}

	/**
	 * @param valuePerUnit the valuePerUnit to set
	 */
	public void setValuePerUnit(BigDecimal valuePerUnit) {
		this.valuePerUnit = valuePerUnit;
	}

	/**
	 */
	public ClaimBenefitItem() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimBenefitItem that) {
		setClaimBenefitItemId(that.getClaimBenefitItemId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setServiceCatId(that.getServiceCatId());
		setCompanyId(that.getCompanyId());
		setPresentedAmt(that.getPresentedAmt());
		setPresentedDiscountAmt(that.getPresentedDiscountAmt());
		setPresentedPercentage(that.getPresentedPercentage());
		setNoOfDaysPresented(that.getNoOfDaysPresented());
		setNoOfUnit(that.getNoOfUnit());
		setValuePerUnit(that.getValuePerUnit());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimBenefitItemId=[").append(claimBenefitItemId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("serviceCatId=[").append(serviceCatId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("presentedAmt=[").append(presentedAmt).append("] ");
		buffer.append("presentedDiscountAmt=[").append(presentedDiscountAmt).append("] ");
		buffer.append("presentedPercentage=[").append(presentedPercentage).append("] ");
		buffer.append("noOfDaysPresented=[").append(noOfDaysPresented).append("] ");
		buffer.append("noOfUnit=[").append(noOfUnit).append("] ");
		buffer.append("valuePerUnit=[").append(valuePerUnit).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimBenefitItemId == null) ? 0 : claimBenefitItemId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimBenefitItem))
			return false;
		ClaimBenefitItem equalCheck = (ClaimBenefitItem) obj;
		if ((claimBenefitItemId == null && equalCheck.claimBenefitItemId != null) || (claimBenefitItemId != null && equalCheck.claimBenefitItemId == null))
			return false;
		if (claimBenefitItemId != null && !claimBenefitItemId.equals(equalCheck.claimBenefitItemId))
			return false;
		return true;
	}
}
