package com.aia.cmic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Table(name = "EDILABORATORY")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "EdiLaboratory")
public class EdiLaboratory extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "ediLaboratorySequence")
	@SequenceGenerator(name = "ediLaboratorySequence", sequenceName = "s_edilaboratory")
	@Column(name = "EDILABORATORYID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long ediLaboratoryId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "LABCODE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String labCode;

	@Column(name = "LOINC", length = 1000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String loinc;

	@Column(name = "LABGROUP", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String labGroup;

	@Column(name = "LABNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String labName;

	@Column(name = "LABRESULT", length = 4000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String labResult;

	@Column(name = "LABUNIT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String labUnit;

	@Column(name = "RESULTDATETIME")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date resultDateTime;

	public Long getEdiLaboratoryId() {
		return ediLaboratoryId;
	}

	public void setEdiLaboratoryId(Long ediLaboratoryId) {
		this.ediLaboratoryId = ediLaboratoryId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getLabCode() {
		return labCode;
	}

	public void setLabCode(String labCode) {
		this.labCode = setMaxLength("labCode", labCode);
	}

	public String getLoinc() {
		return loinc;
	}

	public void setLoinc(String loinc) {
		this.loinc = setMaxLength("loinc", loinc);
	}

	public String getLabGroup() {
		return labGroup;
	}

	public void setLabGroup(String labGroup) {
		this.labGroup = setMaxLength("labGroup", labGroup);
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = setMaxLength("labName", labName);
	}

	public String getLabResult() {
		return labResult;
	}

	public void setLabResult(String labResult) {
		this.labResult = setMaxLength("labResult", labResult);
	}

	public String getLabUnit() {
		return labUnit;
	}

	public void setLabUnit(String labUnit) {
		this.labUnit = setMaxLength("labUnit", labUnit);
	}

	public Date getResultDateTime() {
		return resultDateTime;
	}

	public void setResultDateTime(Date resultDateTime) {
		this.resultDateTime = resultDateTime;
	}

	public EdiLaboratory() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(EdiLaboratory that) {

		setEdiLaboratoryId(that.getEdiLaboratoryId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setLabCode(that.getLabCode());
		setLoinc(that.getLoinc());
		setLabGroup(that.getLabGroup());
		setLabName(that.getLabName());
		setLabResult(that.getLabResult());
		setLabUnit(that.getLabUnit());
		setResultDateTime(that.getResultDateTime());

	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("ediLaboratoryId=[").append(ediLaboratoryId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("labCode=[").append(labCode).append("] ");
		buffer.append("loinc=[").append(loinc).append("] ");
		buffer.append("labGroup=[").append(labGroup).append("] ");
		buffer.append("labName=[").append(labName).append("] ");
		buffer.append("labResult=[").append(labResult).append("] ");
		buffer.append("labUnit=[").append(labUnit).append("] ");
		buffer.append("resultDateTime=[").append(resultDateTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((ediLaboratoryId == null) ? 0 : ediLaboratoryId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof EdiLaboratory))
			return false;
		EdiLaboratory equalCheck = (EdiLaboratory) obj;
		if ((ediLaboratoryId == null && equalCheck.ediLaboratoryId != null) || (ediLaboratoryId != null && equalCheck.ediLaboratoryId == null))
			return false;
		if (ediLaboratoryId != null && !ediLaboratoryId.equals(equalCheck.ediLaboratoryId))
			return false;
		return true;
	}

	private String setMaxLength(String columnName, String data) {
		if (data == null) {
			return data;
		}
		try {
			int size = getClass().getDeclaredField(columnName).getAnnotation(Column.class).length();
			int inLength = data.length();
			if (inLength > size) {
				data = data.substring(0, size);
			}
		} catch (NoSuchFieldException ex) {
		} catch (SecurityException ex) {
		}
		return data;
	}
}
