package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;

/**
 */

@Entity
@SqlResultSetMappings({ @SqlResultSetMapping(name = "findPreviousAmountAllocationMapping", classes = @ConstructorResult(targetClass = PreviousClaimPaymentAllocation.class, columns = { @ColumnResult(name = "planId", type = Long.class), @ColumnResult(name = "planCoverageNo", type = String.class), @ColumnResult(name = "productType", type = String.class),
		@ColumnResult(name = "policyNo", type = String.class), @ColumnResult(name = "benefitCode", type = String.class), @ColumnResult(name = "amountAllocated", type = BigDecimal.class), @ColumnResult(name = "daysAllocated", type = Integer.class), @ColumnResult(name = "percentageAllocated", type = BigDecimal.class) })) })
@NamedNativeQueries({
		@NamedNativeQuery(name = "findPreviousAmountAllocation", query = "select c.planId as planId,a.planCoverageNo as planCoverageNo,a.productType as productType, a.policyNo as policyNo,a.benefitCode as benefitCode,sum(nvl(a.eligibleAmt,0)) AS amountAllocated, sum(nvl(a.noOfDaysAllocated,0)) AS daysAllocated, sum(nvl(a.percentageAllocated,0)) AS percentageAllocated from ClaimPaymentDetail a inner join Claim b ON a.claimNo=b.claimNo and a.occurrence = b.occurrence inner join ClaimPolicyPlan c ON a.policyNo = c.policyNo and a.claimNo=c.claimNo and a.occurrence=c.occurrence and a.planId=c.planId and a.planCoverageNo=c.planCoverageNo inner join ClaimPayment d ON a.policyNo = d.policyNo and a.claimNo=d.claimNo and a.occurrence=d.occurrence and a.planId=d.planId and a.planCoverageNo=d.planCoverageNo  where d.paymentStatus IN ('50', '70') and b.claimStatus IN ('40', '50','65', '70') and ( b.deleteInd = 'N' or b.deleteInd is null)  and a.companyId = ?1 and a.claimNo = ?2 group by a.benefitCode,c.planId,a.productType,a.planCoverageNo, a.policyNo", resultSetMapping = "findPreviousAmountAllocationMapping"),
		@NamedNativeQuery(name = "findOldSystemPreviousAmountAllocation", query = "select cpdh.planId as planId, cpdh.planCoverageNo as planCoverageNo, cpdh.productType as productType, cpdh.policyNo as policyNo, cpdh.benefitCode as benefitCode, sum(nvl(cpdh.eligibleAmt,0)) AS amountAllocated, sum(nvl(cpdh.noOfDaysAllocated,0)) AS daysAllocated, sum(nvl(cpdh.percentageAllocated,0)) AS percentageAllocated from ClaimPaymentDetailHistory  cpdh inner join ClaimHistory ch on cpdh.claimno=ch.claimno and ch.occurrence=cpdh.occurrence where ch.claimStatus IN ('40', '50','65', '70') and ( ch.deleteInd = 'N' or ch.deleteInd is null) and cpdh.companyId = ?1 and cpdh.claimNo = ?2  and cpdh.claimno||'|'||cpdh.occurrence not in (select claimno||'|'||occurrence from claim where claimno=?2 and companyId = ?3) group by cpdh.benefitCode,cpdh.planId,cpdh.productType,cpdh.planCoverageNo,cpdh.policyNo", resultSetMapping = "findPreviousAmountAllocationMapping") })
@NamedQueries({
		@NamedQuery(name = "findClaimPaymentDetailForHSReduction", query = "select distinct myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail , ClaimPolicy claimPolicy where  myClaimPaymentDetail.claimNo=claimPolicy.claimNo and myClaimPaymentDetail.occurrence=claimPolicy.occurrence and myClaimPaymentDetail.claimNo = ?1 and myClaimPaymentDetail.occurrence = ?2 and myClaimPaymentDetail.companyId = ?3 and claimPolicy.businessLine=?4 and myClaimPaymentDetail.productType IN ('HS','HSJR','HSNEW','HSOLD','HSPG','HSUD')  and myClaimPaymentDetail.benefitCode in ?5"),
		@NamedQuery(name = "findClaimPaymentDetailForHSReductionSorted", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail , ClaimPolicy claimPolicy where  myClaimPaymentDetail.claimNo=claimPolicy.claimNo and myClaimPaymentDetail.occurrence=claimPolicy.occurrence  and myClaimPaymentDetail.claimNo = ?1 and myClaimPaymentDetail.occurrence = ?2 and myClaimPaymentDetail.companyId = ?3 and claimPolicy.businessLine=?4 and myClaimPaymentDetail.productType=?5 and myClaimPaymentDetail.hsReductionSeq > 0  order by myClaimPaymentDetail.hsReductionSeq,claimPolicy.policyIssueDt,claimPolicy.policyNo"),
		@NamedQuery(name = "removeClaimPaymentDetailByClaimNoOccurence", query = "delete from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.claimNo = ?1 and myClaimPaymentDetail.occurrence = ?2 and myClaimPaymentDetail.policyNo=?3 and myClaimPaymentDetail.planId=?4 and (myClaimPaymentDetail.planCoverageNo= ?5 or ?5 is null or ?5='') and (myClaimPaymentDetail.productCode= ?6 or ?6 is null or ?6='') "),
		@NamedQuery(name = "findPAMEClaimPaymentDetail", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.claimNo = ?1 and myClaimPaymentDetail.occurrence = ?2 and myClaimPaymentDetail.companyId = ?3  and myClaimPaymentDetail.policyNo = ?4 and ( myClaimPaymentDetail.productCode = ?5 or ?5 is null or ?5='' ) and myClaimPaymentDetail.planId = ?6 and ( myClaimPaymentDetail.planCoverageNo = ?7 or ?7 is null or ?7='' ) and myClaimPaymentDetail.benefitCode = ?8 and myClaimPaymentDetail.productType='PA' "),
		@NamedQuery(name = "findPreviousMEReimbursement", query = "select sum(myClaimPaymentDetail.eligibleAmt) from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.policyNo = ?2 and myClaimPaymentDetail.productCode = ?3 and myClaimPaymentDetail.planId = ?4  and ( myClaimPaymentDetail.planCoverageNo = ?5 or ?5 is null or ?5='' ) and myClaimPaymentDetail.paymentStatus = ?6 and myClaimPaymentDetail.benefitCode='A09'"),
		@NamedQuery(name = "findClaimPaymentDetailByCompanyIdClaimNoAndOccurrence", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3"),
		@NamedQuery(name = "findClaimPaymentDetailWithMajorAcc", query = "select count(cpd.claimNo)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cpd.policyNo = cl.policyNo  and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cl.policyNo=cpp.policyNo and cpd.planCoverageNo = cpp.planCoverageNo  and cl.claimStatus in ('50','65', '70') and ( cl.deleteInd = 'N' or cl.deleteInd is null)  and cpd.benefitCode IN ('H00','H01', 'H02','H03','H04','H07','H08','H09','H10','H13','H14','H15') and cpd.planId = ?1 and ( cpd.planCoverageNo = ?2 or ?2 is null or ?2='' ) and cl.claimNo = ?3 and cpd.policyNo = ?4  and (cl.majorAccId <> '' OR cl.majorAccId <> NULL) group by cpd.policyNo, cpd.planId, cpd.planCoverageNo"),
		@NamedQuery(name = "findTotalEligbleAmtByPlanCoveragePerYear", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cpd.policyNo = cl.policyNo  and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cl.policyNo=cpp.policyNo and cl.claimStatus in ('50','65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and cpd.benefitCode IN ('H00','H01', 'H02','H03','H04','H07','H08','H09','H10','H13','H14','H15','H16') and ( (cl.accidentDt >= ?1 and cl.accidentDt <= ?2) or  (cl.hospitalizationDate >= ?1 and cl.hospitalizationDate <=?2 ) ) and cpd.planId = ?3 and cl.claimNo = ?4 and cpd.policyNo = ?5  and ( cpp.planCoverageNo = ?6 or ?6 is null or ?6='' ) group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),		
		@NamedQuery(name = "findTotalHSXEligbleAmtByPlanCoveragePerYear", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cpd.policyNo=cpp.policyNo and cl.claimStatus in ('50','65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and cpd.benefitCode = ?1 and ( (cl.accidentDt >= ?2 and cl.accidentDt < ?3) or  (cl.hospitalizationDate >= ?2 and cl.hospitalizationDate <?3 ) ) and cpd.planId = ?4 and cpd.policyNo = ?5 and ( cpp.planCoverageNo = ?6 or ?6 is null or ?6='' ) group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),
		@NamedQuery(name = "findTotalEligbleAmtByPlanCoveragePerYearAllBenefit", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cpd.policyNo=cpp.policyNo and cl.claimStatus in ('50','65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and ( (cl.accidentDt >= ?1 and cl.accidentDt <= ?2) or  (cl.hospitalizationDate >= ?1 and cl.hospitalizationDate <=?2 ) ) and cpd.planId = ?3 and cpd.policyNo = ?4  and ( cpp.planCoverageNo = ?5 or ?5 is null or ?5='' ) group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),		
		@NamedQuery(name = "findTotalEligbleAmtByPlanCoveragePerYearByBenefit", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cpd.policyNo=cpp.policyNo and cl.claimStatus in ('50','65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and ( (cl.accidentDt >= ?1 and cl.accidentDt <= ?2) or  (cl.hospitalizationDate >= ?1 and cl.hospitalizationDate <=?2 ) ) and cpd.planId = ?3 and cpd.policyNo = ?4  and ( cpp.planCoverageNo = ?5 or ?5 is null or ?5='' ) and cpd.benefitCode in (?6) group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),
		@NamedQuery(name = "findTotalVisitByPlanCoveragePerYearByBenefit", query = "select sum(nvl(cpd.noOfDaysAllocated,0))  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cpd.policyNo=cpp.policyNo and cl.claimStatus in ('50','65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and ( (cl.accidentDt >= ?1 and cl.accidentDt <= ?2) or  (cl.hospitalizationDate >= ?1 and cl.hospitalizationDate <=?2 ) ) and cpd.planId = ?3 and cpd.policyNo = ?4  and ( cpp.planCoverageNo = ?5 or ?5 is null or ?5='' ) and cpd.benefitCode in (?6) and cl.ptcall is not null group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),
		@NamedQuery(name = "findTotalEligbleAmtForChemoPerYear", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cpd.policyNo = cl.policyNo  and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cl.policyNo=cpp.policyNo and cl.claimStatus in ('50','65','70') and (cl.deleteInd = 'N' or cl.deleteInd is null ) and cpd.benefitCode IN ('H16') and ( (cl.accidentDt >= ?1 and cl.accidentDt <= ?2) or  (cl.hospitalizationDate >= ?1 and cl.hospitalizationDate <=?2 ) ) and cpd.planId = ?3 and cl.claimNo = ?4 and cpd.policyNo = ?5  and ( cpp.planCoverageNo = ?6 or ?6 is null or ?6='' ) group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),
		@NamedQuery(name = "findTotalEligbleAmtByPlanPolicyPerYear", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cpd.claimNo = cpp.claimNo  and cpd.occurrence = cpp.occurrence  and cpd.policyNo=cpp.policyNo and cpd.planId=cpp.planId and cl.claimStatus in ('50','65','70') and ( cl.deleteInd = 'N' or cl.deleteInd is null) and ( (cl.accidentDt >= ?1 and cl.accidentDt <= ?2) or  (cl.hospitalizationDate >= ?1 and cl.hospitalizationDate <=?2 ) ) and cpd.planId = ?3  and cpd.policyNo = ?4  and cpd.benefitCode=?5 group by cpd.policyNo, cpd.planId"),
		@NamedQuery(name = "findTotalEligbleAmtByBenefitCode", query = "select sum(cpd.eligibleAmt) from ClaimPaymentDetail cpd  where cpd.claimNo = ?1 and cpd.occurrence <= ?2  and cpd.policyNo = ?3  and cpd.planId = ?4 and cpd.benefitCode=?5"),
		@NamedQuery(name = "findTotalEligbleAmtByCareCardIndBenefitCode", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPayment cp,Plan pl  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cpd.claimNo = cp.claimNo  and cpd.occurrence = cp.occurrence and cpd.policyNo=cp.policyNo and cpd.planId=cp.planId and cpd.planCoverageNo = cp.planCoverageNo and cpd.planId=pl.planId and cl.claimStatus in ('40','50','65','70') and cp.paymentStatus IN ('50', '70') and ( cl.deleteInd = 'N' or cl.deleteInd is null) and cl.careCardInd='Y' and cl.claimNo = ?1  and cpd.occurrence=?2 and pl.planName = ?3  and cpd.policyNo = ?4  and cpd.benefitCode=?5 group by cpd.policyNo, pl.planName"),
		@NamedQuery(name = "findClaimH17H11BenefitCode", query = "select distinct cl from ClaimPaymentDetail cpd, Claim cl where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence    and ( cl.deleteInd = 'N' or cl.deleteInd is null) and cl.claimNo = ?1  and cpd.occurrence=?2  and cpd.policyNo = ?3   and (cpd.benefitCode='H11' or cpd.benefitCode='H17')"),
		@NamedQuery(name = "findPreviousHBAllocatedDays", query = "select sum(cpd.noOfDaysAllocated) from ClaimPaymentDetail cpd, Claim cl where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence    and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and cl.claimNo = ?1  and cpd.occurrence=?2  and cpd.policyNo = ?3   and (cpd.benefitCode='H11' or cpd.benefitCode='H17') and cl.claimId in (?4)"),
		@NamedQuery(name = "findPreviousHB3xAllocatedDays", query = "select sum(cpd.noOfDaysAllocated) from ClaimPaymentDetail cpd, Claim cl where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence    and ( cl.deleteInd = 'N' or cl.deleteInd is null ) and cl.claimNo = ?1  and cpd.occurrence=?2  and cpd.policyNo = ?3   and (( cpd.benefitCode='H11' and cl.hbpType='1') or cpd.benefitCode='H17') and cl.claimId in (?4)"),
		@NamedQuery(name = "findTotalEligibleAmtByPlanPolicyCoverageNo", query = "select sum(cpd.eligibleAmt)  from ClaimPaymentDetail cpd, Claim cl,ClaimPolicyPlan cpp  where cpd.claimNo = cl.claimNo  and cpd.occurrence = cl.occurrence  and cpd.policyNo = cl.policyNo  and cl.claimNo = cpp.claimNo  and cl.occurrence = cpp.occurrence  and cl.policyNo=cpp.policyNo  and cpd.companyId=?1 and cpd.policyNo = ?2  and cpd.planId=?3 and ( cpp.planCoverageNo = ?4 or ?4 is null or ?4='' ) group by cpd.policyNo, cpd.planId,cpd.planCoverageNo"),
		@NamedQuery(name = "findClaimPaymentDetailForUpdate", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo= ?2 and myClaimPaymentDetail.occurrence= ?3 and myClaimPaymentDetail.policyNo= ?4 and ( myClaimPaymentDetail.productCode= ?5 or ?5 is null or ?5='' ) and myClaimPaymentDetail.planId= ?6 and ( myClaimPaymentDetail.planCoverageNo = ?7 or ?7 is null or ?7='' )"),
		@NamedQuery(name = "findClaimPaymentDetailByCompanyIdClaimNoOccurrencePolicyNoAndProductCode", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo= ?2 and myClaimPaymentDetail.occurrence= ?3 and myClaimPaymentDetail.policyNo= ?4 and myClaimPaymentDetail.productCode=?5"),
		@NamedQuery(name = "findClaimPaymentDetailByCompanyIdClaimNoOccurrencePolicyNoAndProductCodeAndPlan", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo= ?2 and myClaimPaymentDetail.occurrence= ?3 and myClaimPaymentDetail.policyNo= ?4 and myClaimPaymentDetail.productCode=?5 and myClaimPaymentDetail.planId=?6 and ( myClaimPaymentDetail.planCoverageNo=?7 or ?7 is null ) and myClaimPaymentDetail.benefitCode =?8"),
		@NamedQuery(name = "findClaimPaymentDetailForReverse", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.claimNo=?1 and myClaimPaymentDetail.occurrence=?2"),
		@NamedQuery(name = "reverseClaimPaymentDetail", query = "update ClaimPaymentDetail myClaimPaymentDetail set myClaimPaymentDetail.paymentStatus=?1 where myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3"),
		@NamedQuery(name = "findClaimPaymentDetailForWriteSettlement", query = "select myClaimPaymentDetail,myClaimPayment from ClaimPaymentDetail myClaimPaymentDetail,ClaimPayment myClaimPayment where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3 and myClaimPaymentDetail.policyNo=?4 and (myClaimPaymentDetail.productCode=?5 or ?5 is null or ?5='') and myClaimPaymentDetail.planId=?6 and myClaimPayment.companyId = ?1 and myClaimPayment.claimNo=?2 and myClaimPayment.occurrence=?3 and myClaimPayment.policyNo=?4 and (myClaimPayment.productCode=?5 or ?5 is null or ?5='') and myClaimPayment.planId=?6 and (myClaimPaymentDetail.planCoverageNo= ?7 or ?7 is null or ?7='') and ( myClaimPayment.planCoverageNo= ?7 or ?7 is null or ?7='') and myClaimPayment.paymentStatus=?8 and myClaimPaymentDetail.eligibleAmt>0"),
		@NamedQuery(name = "findClaimPaymentDetailNoRelateToClaimPayment", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3 and not exists(select myClaimPayment from ClaimPayment myClaimPayment where myClaimPayment.companyId = ?4 and myClaimPayment.claimNo = ?5 and myClaimPayment.occurrence = ?6 and myClaimPayment.planId = myClaimPaymentDetail.planId )"),
		@NamedQuery(name = "removeClaimPaymentDetailByClaimPaymentDetailIdandPlanId", query = "delete from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.claimPaymentDetailId = ?1 and myClaimPaymentDetail.planId = ?2"),
		@NamedQuery(name = "findH29TotalNoOfDaysAllocatedByPolicyNoPlanId", query =  "select sum(nvl(cpd.noOfDaysAllocated,0))  from ClaimPaymentDetail cpd where cpd.companyId = ?1 and cpd.policyNo = ?2 and cpd.planId = ?3 and cpd.paymentStatus in ('65','70') and  cpd.benefitCode = 'H29' "),
		@NamedQuery(name = "findClaimPaymentDetailForCSMEFax", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.claimNo = ?1 and myClaimPaymentDetail.occurrence = ?2 and myClaimPaymentDetail.policyNo = ?3 and myClaimPaymentDetail.planId = ?4 and myClaimPaymentDetail.productType = 'CSME' and myClaimPaymentDetail.planCoverageNo = ?5 and myClaimPaymentDetail.benefitCode in ('H04','H05','H07','H08') and myClaimPaymentDetail.eligibleAmt > 0 ") , //
		@NamedQuery(name = "findEligibleAmtByClaimNoOccurrenceBenefitCode", query = "select sum(nvl(cpd.eligibleAmt,0))  from ClaimPaymentDetail cpd  where cpd.claimNo = ?1 and cpd.occurrence = ?2 and cpd.benefitCode = ?3 "),//
		@NamedQuery(name = "findEligibleAmtByClaimNoOccurrenceBenefitCodeIn", query = "select sum(nvl(cpd.eligibleAmt,0))  from ClaimPaymentDetail cpd  where cpd.claimNo = ?1 and cpd.occurrence = ?2 and cpd.benefitCode in (?3) "),
		@NamedQuery(name = "findDeductAmtByClaimNoOccurrence", query = "select sum(nvl(cpd.deductAmt,0))  from ClaimPaymentDetail cpd  where cpd.companyId = ?1 and cpd.claimNo = ?2 and cpd.occurrence = ?3 ) "), //
		@NamedQuery(name = "findShortFallAmtAmtByClaimNoOccurrenceBenefitCode", query = "select sum(nvl(cpd.shortFallAmt,0))  from ClaimPaymentDetail cpd  where cpd.claimNo = ?1 and cpd.occurrence = ?2 and cpd.benefitCode = ?3 "), //
		@NamedQuery(name = "findShortFallAmtAmtByClaimNoOccurrenceBenefitCodeIn", query = "select sum(nvl(cpd.shortFallAmt,0))  from ClaimPaymentDetail cpd  where cpd.claimNo = ?1 and cpd.occurrence = ?2 and cpd.benefitCode in (?3) "),
		@NamedQuery(name = "findClaimPaymentDetailByCompanyIdClaimNoAndOccurrenceAndPolicyNo", query = "select myClaimPaymentDetail from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3 and myClaimPaymentDetail.policyNo=?3"),
		@NamedQuery(name = "findSumDaysAllocateByCompanyIdClaimNoAndOccurrenceAndPolicyNoBenefitCode", query = "select sum(nvl(myClaimPaymentDetail.noOfDaysAllocated,0))  from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3 and myClaimPaymentDetail.policyNo=?4 and myClaimPaymentDetail.benefitCode = ?5 "),
		@NamedQuery(name = "findSumReimbursedDaysAllocateByCompanyIdClaimNoAndOccurrenceAndPolicyNoBenefitCodeIn", query = "select sum(nvl(myClaimPaymentDetail.reimbursedDay,0))  from ClaimPaymentDetail myClaimPaymentDetail where myClaimPaymentDetail.companyId = ?1 and myClaimPaymentDetail.claimNo=?2 and myClaimPaymentDetail.occurrence=?3 and myClaimPaymentDetail.policyNo=?4 and myClaimPaymentDetail.benefitCode in (?5) ")
        }) //") })
@Table(name = "CLAIMPAYMENTDETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPaymentDetail")
public class ClaimPaymentDetail extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaymentDetailSequence")
	@SequenceGenerator(name = "claimPaymentDetailSequence", sequenceName = "s_claimpaymentdetail")
	@Column(name = "CLAIMPAYMENTDETAILID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimPaymentDetailId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "POLICYNO", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String planCoverageNo;
	/**
	 */

	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productCode;
	/**
	 */

	@Column(name = "PRODUCTTYPE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productType;
	/**
	 */
	@Column(name = "PRESENTEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal presentedAmt;

	@Column(name = "ELIGIBLEAMT", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal eligibleAmt;
	/**
	 */
	@Column(name = "DEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal deductAmt;
	
	@Column(name = "ALLOCATEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal allocatedAmt;
	/**
	 */

	@Column(name = "NOOFDAYSALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysAllocated;
	/**
	 */

	@Column(name = "PERCENTAGEALLOCATED", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal percentageAllocated;
	/**
	 */

	@Column(name = "HSREDUCTIONSEQ")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer hsReductionSeq;
	/**
	 */

	@Column(name = "SHORTFALLAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal shortFallAmt;
	/**
	 */

	@Column(name = "REIMBURSEDDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer reimbursedDay;
	/**
	 */

	@Column(name = "PAYMENTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentStatus;

	/**
	 */
	public void setClaimPaymentDetailId(Long claimPaymentDetailId) {
		this.claimPaymentDetailId = claimPaymentDetailId;
	}

	/**
	 */
	public Long getClaimPaymentDetailId() {
		return this.claimPaymentDetailId;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 */
	public String getPlanCoverageNo() {
		return this.planCoverageNo;
	}

	/**
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 */
	public String getBenefitCode() {
		return this.benefitCode;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 */
	public BigDecimal getEligibleAmt() {
		return this.eligibleAmt;
	}

	/**
	 */
	public void setAllocatedAmt(BigDecimal allocatedAmt) {
		this.allocatedAmt = allocatedAmt;
	}

	/**
	 */
	public BigDecimal getAllocatedAmt() {
		return this.allocatedAmt;
	}

	/**
	 */
	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	/**
	 */
	public Integer getNoOfDaysAllocated() {
		return this.noOfDaysAllocated;
	}

	/**
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 */
	public BigDecimal getPercentageAllocated() {
		return this.percentageAllocated;
	}

	/**
	 */
	public void setHsReductionSeq(Integer hsReductionSeq) {
		this.hsReductionSeq = hsReductionSeq;
	}

	/**
	 */
	public Integer getHsReductionSeq() {
		return this.hsReductionSeq;
	}

	/**
	 */
	public void setShortFallAmt(BigDecimal shortFallAmt) {
		this.shortFallAmt = shortFallAmt;
	}

	/**
	 */
	public BigDecimal getShortFallAmt() {
		return this.shortFallAmt;
	}

	/**
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	/**
	 */
	public Integer getReimbursedDay() {
		return this.reimbursedDay;
	}

	/**
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 */
	public String getPaymentStatus() {
		return this.paymentStatus;
	}

	/**
	 */
	public ClaimPaymentDetail() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimPaymentDetail that) {
		setClaimPaymentDetailId(that.getClaimPaymentDetailId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setBenefitCode(that.getBenefitCode());
		setEligibleAmt(that.getEligibleAmt());
		setPresentedAmt(that.getPresentedAmt());
		setEligibleAmt(that.getEligibleAmt());
		setAllocatedAmt(that.getAllocatedAmt());
		setNoOfDaysAllocated(that.getNoOfDaysAllocated());
		setPercentageAllocated(that.getPercentageAllocated());
		setHsReductionSeq(that.getHsReductionSeq());
		setShortFallAmt(that.getShortFallAmt());
		setReimbursedDay(that.getReimbursedDay());
		setPaymentStatus(that.getPaymentStatus());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimPaymentDetailId=[").append(claimPaymentDetailId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("benefitCode=[").append(benefitCode).append("] ");
		buffer.append("presentedAmt=[").append(presentedAmt).append("] ");
		buffer.append("eligibleAmt=[").append(eligibleAmt).append("] ");
		buffer.append("allocatedAmt=[").append(allocatedAmt).append("] ");
		buffer.append("noOfDaysAllocated=[").append(noOfDaysAllocated).append("] ");
		buffer.append("percentageAllocated=[").append(percentageAllocated).append("] ");
		buffer.append("hsReductionSeq=[").append(hsReductionSeq).append("] ");
		buffer.append("shortFallAmt=[").append(shortFallAmt).append("] ");
		buffer.append("reimbursedDay=[").append(reimbursedDay).append("] ");
		buffer.append("paymentStatus=[").append(paymentStatus).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPaymentDetailId == null) ? 0 : claimPaymentDetailId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPaymentDetail))
			return false;
		ClaimPaymentDetail equalCheck = (ClaimPaymentDetail) obj;
		if ((claimPaymentDetailId == null && equalCheck.claimPaymentDetailId != null) || (claimPaymentDetailId != null && equalCheck.claimPaymentDetailId == null))
			return false;
		if (claimPaymentDetailId != null && !claimPaymentDetailId.equals(equalCheck.claimPaymentDetailId))
			return false;
		return true;
	}

	public void copyProperties(PaymentAllocationTemp allocationTemp) {

		setCompanyId(allocationTemp.getCompanyId());
		setClaimNo(allocationTemp.getClaimNo());
		setOccurrence(allocationTemp.getOccurence());
		setPolicyNo(allocationTemp.getPolicyNo());
		setPlanId(allocationTemp.getPlanId());
		setPlanCoverageNo(allocationTemp.getPlanCoverageNo());
		setBenefitCode(allocationTemp.getBenefitCode());
		setPresentedAmt(allocationTemp.getPresentedAmt());
		setEligibleAmt(allocationTemp.getEligibleAmt());
		setNoOfDaysAllocated(allocationTemp.getAllocatedDay() == null ? 0 : allocationTemp.getAllocatedDay());
		setPercentageAllocated(allocationTemp.getPercentageAllocated());
		setReimbursedDay(allocationTemp.getReimbursedDay() == null ? 0 : allocationTemp.getReimbursedDay());

		// shortFallAmt
		setShortFallAmt(allocationTemp.getShortFallAmount());
		setProductType(allocationTemp.getProductType());
		setProductCode(allocationTemp.getProductCode());

		//		setHsReductionSeq(allocationTemp.get);

	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the deductAmt
	 */
	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	/**
	 * @param deductAmt the deductAmt to set
	 */
	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

}
