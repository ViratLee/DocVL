package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@Entity
@NamedQueries({ @NamedQuery(name = "removeClaimPaymentTempByClaimNoOccurence",
		query = "delete from ClaimPaymentTemp myClaimPaymentTemp where myClaimPaymentTemp.claimNo = ?1 and myClaimPaymentTemp.occurrence = ?2") })
@Table(name = "CLAIMPAYMENTTEMP")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimPaymentTemp")
public class ClaimPaymentTemp implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimPaymentTempSequence")
	@SequenceGenerator(name = "claimPaymentTempSequence", sequenceName = "s_claimpaymenttemp")
	@Column(name = "CLAIMPAYMENTTEMPID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	private Long claimPaymentTempId;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String companyId;
	/**
	 */
	@Column(name = "CLAIMID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Long claimId;

	@Column(name = "CLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Integer occurrence;
	/**
	 */

	@Column(name = "BUSINESSLINE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String businessLine;

	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String policyNo;
	/**
	 */

	@Column(name = "PLANID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Long planId;
	/**
	 */

	@Column(name = "PLANCOVERAGEID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String planCoverageId;
	/**
	 */

	@Column(name = "PLANNAME", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String planName;

	@Column(name = "PRODUCTTYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productType;
	/**
	 */

	@Column(name = "PRODUCTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String productCode;
	/**
	 */

	@Column(name = "LIFEPRODUCTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String lifeProductCode;
	/**
	 */

	@Column(name = "BENEFITCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String benefitCode;

	@Column(name = "PROCEDURECATEGORY", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String procedureCategory;

	@Column(name = "FULLCREDITIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String fullCreditInd;

	@Column(name = "SEQID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Long seqId;

	@Column(name = "ALLOCATESEQID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Long allocateSeqId;

	@Column(name = "SERVICECATID", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String serviceCatId;
	/**
	 */

	@Column(name = "TREATMENTTYPE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String treatmentType;
	/**
	 */

	@Column(name = "PRESENTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal presentAmt = BigDecimal.ZERO;

	@Column(name = "PRESENTEDDISCOUNTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal presentedDiscountAmt = BigDecimal.ZERO;

	@Column(name = "PRESENTEDDAYS")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Integer presentedDays;
	/**
	 */

	@Column(name = "PRESENTEDPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal presentedPercentage = BigDecimal.ZERO;

	@Column(name = "PRESENTEDUNIT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Integer presentedUnit;
	/**
	 */

	@Column(name = "LENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Integer LengthOfStay;
	/**
	 */

	@Column(name = "ELIGIBLEAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal eligibleAmt;

	@Column(name = "REIMBURSEDDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Integer reimbursedDay;
	/**
	 */

	@Column(name = "REIMBURSEDCALL")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Integer reimbursedCall;
	/**
	 */

	@Column(name = "PERCENTAGEALLOCATED", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal percentageAllocated;
	/**
	 */

	@Column(name = "EXCESSAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal excessAmt;

	@Column(name = "ACCUMULATORNO", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String accumulatorNo;

	@Column(name = "BUSINEELINEALLOCSEQ", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String busineeLineAllocSeq;

	@Column(name = "PLANPRODUCTALLOCSEQ", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String planProductAllocSeq;

	@Column(name = "ROLLOVERGROUPNO", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String rolloverGroupNo;

	@Column(name = "BENCODEALLOCSEQUENCE", length = 4)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String benCodeAllocSequence;

	public Long getClaimPaymentTempId() {
		return claimPaymentTempId;
	}

	public void setClaimPaymentTempId(Long claimPaymentTempId) {
		this.claimPaymentTempId = claimPaymentTempId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPlanCoverageId() {
		return planCoverageId;
	}

	public void setPlanCoverageId(String planCoverageId) {
		this.planCoverageId = planCoverageId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getLifeProductCode() {
		return lifeProductCode;
	}

	public void setLifeProductCode(String lifeProductCode) {
		this.lifeProductCode = lifeProductCode;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public String getProcedureCategory() {
		return procedureCategory;
	}

	public void setProcedureCategory(String procedureCategory) {
		this.procedureCategory = procedureCategory;
	}

	public String getFullCreditInd() {
		return fullCreditInd;
	}

	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	public Long getSeqId() {
		return seqId;
	}

	public void setSeqId(Long seqId) {
		this.seqId = seqId;
	}

	public Long getAllocateSeqId() {
		return allocateSeqId;
	}

	public void setAllocateSeqId(Long allocateSeqId) {
		this.allocateSeqId = allocateSeqId;
	}

	public String getServiceCatId() {
		return serviceCatId;
	}

	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public BigDecimal getPresentAmt() {
		return presentAmt;
	}

	public void setPresentAmt(BigDecimal presentAmt) {
		this.presentAmt = presentAmt;
	}

	public BigDecimal getPresentedDiscountAmt() {
		return presentedDiscountAmt;
	}

	public void setPresentedDiscountAmt(BigDecimal presentedDiscountAmt) {
		this.presentedDiscountAmt = presentedDiscountAmt;
	}

	public Integer getPresentedDays() {
		return presentedDays;
	}

	public void setPresentedDays(Integer presentedDays) {
		this.presentedDays = presentedDays;
	}

	public BigDecimal getPresentedPercentage() {
		return presentedPercentage;
	}

	public void setPresentedPercentage(BigDecimal presentedPercentage) {
		this.presentedPercentage = presentedPercentage;
	}

	public Integer getPresentedUnit() {
		return presentedUnit;
	}

	public void setPresentedUnit(Integer presentedUnit) {
		this.presentedUnit = presentedUnit;
	}

	public Integer getLengthOfStay() {
		return LengthOfStay;
	}

	public void setLengthOfStay(Integer lengthOfStay) {
		LengthOfStay = lengthOfStay;
	}

	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	public Integer getReimbursedCall() {
		return reimbursedCall;
	}

	public void setReimbursedCall(Integer reimbursedCall) {
		this.reimbursedCall = reimbursedCall;
	}

	public BigDecimal getPercentageAllocated() {
		return percentageAllocated;
	}

	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	public BigDecimal getExcessAmt() {
		return excessAmt;
	}

	public void setExcessAmt(BigDecimal excessAmt) {
		this.excessAmt = excessAmt;
	}

	public String getAccumulatorNo() {
		return accumulatorNo;
	}

	public void setAccumulatorNo(String accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	public String getBusineeLineAllocSeq() {
		return busineeLineAllocSeq;
	}

	public void setBusineeLineAllocSeq(String busineeLineAllocSeq) {
		this.busineeLineAllocSeq = busineeLineAllocSeq;
	}

	public String getPlanProductAllocSeq() {
		return planProductAllocSeq;
	}

	public void setPlanProductAllocSeq(String planProductAllocSeq) {
		this.planProductAllocSeq = planProductAllocSeq;
	}

	public String getRolloverGroupNo() {
		return rolloverGroupNo;
	}

	public void setRolloverGroupNo(String rolloverGroupNo) {
		this.rolloverGroupNo = rolloverGroupNo;
	}

	public String getBenCodeAllocSequence() {
		return benCodeAllocSequence;
	}

	public void setBenCodeAllocSequence(String benCodeAllocSequence) {
		this.benCodeAllocSequence = benCodeAllocSequence;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimPaymentTempId == null) ? 0 : claimPaymentTempId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimPolicy))
			return false;
		ClaimPaymentTemp equalCheck = (ClaimPaymentTemp) obj;
		if ((claimPaymentTempId == null && equalCheck.claimPaymentTempId != null) || (claimPaymentTempId != null && equalCheck.claimPaymentTempId == null))
			return false;
		if (claimPaymentTempId != null && !claimPaymentTempId.equals(equalCheck.claimPaymentTempId))
			return false;
		return true;
	}

}
