package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@NamedQueries({ @NamedQuery(name = "findAgencyDistributeByPrimaryKey", query = "select myAgencyDistribute from AgencyDistribute myAgencyDistribute where myAgencyDistribute.agencyCode = ?1") })
@Table(name = "AGENCYDISTRIBUTE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "AgencyDistribute")
public class AgencyDistribute extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "AGENCYCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String agencyCode;
	/**
	 */

	@Column(name = "PAYMENTCODE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String paymentCode;
	/**
	 */

	@Column(name = "DISTRIBUTECODE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String distributeCode;

	/**
	 */
	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	/**
	 */
	public String getAgencyCode() {
		return this.agencyCode;
	}

	/**
	 */
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}

	/**
	 */
	public String getPaymentCode() {
		return this.paymentCode;
	}

	/**
	 */
	public void setDistributeCode(String distributeCode) {
		this.distributeCode = distributeCode;
	}

	/**
	 */
	public String getDistributeCode() {
		return this.distributeCode;
	}

	/**
	 */
	public AgencyDistribute() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(AgencyDistribute that) {
		setAgencyCode(that.getAgencyCode());
		setDistributeCode(that.getDistributeCode());
		setPaymentCode(that.getPaymentCode());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("agencyCode=[").append(agencyCode).append("] ");
		buffer.append("distributeCode=[").append(distributeCode).append("] ");
		buffer.append("paymentCode=[").append(paymentCode).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((agencyCode == null) ? 0 : agencyCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof AgencyDistribute))
			return false;
		AgencyDistribute equalCheck = (AgencyDistribute) obj;
		if ((agencyCode == null && equalCheck.agencyCode != null) || (agencyCode != null && equalCheck.agencyCode == null))
			return false;
		if (agencyCode != null && !agencyCode.equals(equalCheck.agencyCode))
			return false;
		return true;
	}
}
