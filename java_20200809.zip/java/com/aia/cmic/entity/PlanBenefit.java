package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllPlanBenefits", query = "select myPlanBenefit from PlanBenefit myPlanBenefit"),
		@NamedQuery(name = "findPlanBenefitByAccumulatorNo", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.accumulatorNo = ?1"),
		@NamedQuery(name = "findPlanBenefitByBenefitAmount", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.benefitAmount = ?1"),
		@NamedQuery(name = "findPlanBenefitByBenefitItemCode", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.benefitItemCode = ?1"),
		@NamedQuery(name = "findPlanBenefitByBenefitItemCodeContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.benefitItemCode like ?1"),
		@NamedQuery(name = "findPlanBenefitByBenefitUnit", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.benefitUnit = ?1"),
		@NamedQuery(name = "findPlanBenefitByChangeDate", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.changeDate = ?1"),
		@NamedQuery(name = "findPlanBenefitByConfinementDay", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.confinementDay = ?1"),
		@NamedQuery(name = "findPlanBenefitByFamilyShareInd", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.familyShareInd = ?1"),
		@NamedQuery(name = "findPlanBenefitByFamilyShareIndContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.familyShareInd like ?1"),
		@NamedQuery(name = "findPlanBenefitByFlatAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.flatAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByGeographicCoverage", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.geographicCoverage = ?1"),
		@NamedQuery(name = "findPlanBenefitByGeographicCoverageContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.geographicCoverage like ?1"),
		@NamedQuery(name = "findPlanBenefitByIndemnityPercentage", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.indemnityPercentage = ?1"),
		@NamedQuery(name = "findPlanBenefitByInNetworkSumValue", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.inNetworkSumValue = ?1"),
		@NamedQuery(name = "findPlanBenefitByIpdSurgeryAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.ipdSurgeryAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxBenefitAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxBenefitAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxConfinementAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxConfinementAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxMajorConfinement", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxMajorConfinement = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxNoOfDay", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxNoOfDay = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxNoOfDaysHist", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxNoOfDaysHist = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxSaamt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxSaamt = ?1"),
		@NamedQuery(name = "findPlanBenefitByMaxYearAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.maxYearAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByMembershipType", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.membershipType = ?1"),
		@NamedQuery(name = "findPlanBenefitByMembershipTypeContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.membershipType like ?1"),
		@NamedQuery(name = "findPlanBenefitByMinSaamt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.minSaamt = ?1"),
		@NamedQuery(name = "findPlanBenefitByMultipleFactor", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.multipleFactor = ?1"),
		@NamedQuery(name = "findPlanBenefitByNonIpdSurgeryAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.nonIpdSurgeryAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByNoOfDays", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.noOfDays = ?1"),
		@NamedQuery(name = "findPlanBenefitByOopInd", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.oopInd = ?1"),
		@NamedQuery(name = "findPlanBenefitByOopIndContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.oopInd like ?1"),
		@NamedQuery(name = "findPlanBenefitByOutNetworkSumValue", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.outNetworkSumValue = ?1"),
		@NamedQuery(name = "findPlanBenefitByPlanBenefitId", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.planBenefitId = ?1"),
		@NamedQuery(name = "findPlanBenefitByPlanId", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.planId = ?1"),
		@NamedQuery(name = "findPlanBenefitByPrimaryKey", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.planBenefitId = ?1"),
		@NamedQuery(name = "findPlanBenefitBySaCalculateType", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.saCalculateType = ?1"),
		@NamedQuery(name = "findPlanBenefitBySaCalculateTypeContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.saCalculateType like ?1"),
		@NamedQuery(name = "findPlanBenefitBySpecialIPDAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.specialIPDAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitBySumCategory", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumCategory = ?1"),
		@NamedQuery(name = "findPlanBenefitBySumCategoryContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumCategory like ?1"),
		@NamedQuery(name = "findPlanBenefitBySumDuplicateCheckInd", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumDuplicateCheckInd = ?1"),
		@NamedQuery(name = "findPlanBenefitBySumDuplicateCheckIndContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumDuplicateCheckInd like ?1"),
		@NamedQuery(name = "findPlanBenefitBySumSequenceNo", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumSequenceNo = ?1"),
		@NamedQuery(name = "findPlanBenefitBySumTimeFrame", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumTimeFrame = ?1"),
		@NamedQuery(name = "findPlanBenefitBySumTimeFrameContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.sumTimeFrame like ?1"),
		@NamedQuery(name = "findPlanBenefitByTotalBenefitAmt", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.totalBenefitAmt = ?1"),
		@NamedQuery(name = "findPlanBenefitByUnitNo", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.unitNo = ?1"),
		@NamedQuery(name = "findPlanBenefitByWaitingPeriod", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.waitingPeriod = ?1"),
		@NamedQuery(name = "findPlanBenefitByFieldContaining", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.planId = ?1 and myPlanBenefit.benefitItemCode like ?2"),
		@NamedQuery(name = "findPlanBenefitByPlanIdBenefitCode", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.planId = ?1 and myPlanBenefit.benefitItemCode = ?2"),
		@NamedQuery(name = "findMaxBenefitAmt", query = "select myPlanBenefit.maxBenefitAmt from PlanBenefit myPlanBenefit where myPlanBenefit.companyId = ?1 and myPlanBenefit.planId= ?2 and myPlanBenefit.benefitItemCode = ?3"),
		@NamedQuery(name = "findMEPlanIds", query = "select myPlanBenefit.planId from PlanBenefit myPlanBenefit where myPlanBenefit.benefitItemCode = ?1"),
		@NamedQuery(name = "deletePlanBenefitByPlanId", query = "delete from PlanBenefit myPlanBenefit where myPlanBenefit.planId = ?1"),
		@NamedQuery(name = "findPlanBenefitByBenefitShare", query = "select myPlanBenefit.benefitItemCode from PlanBenefit myPlanBenefit where myPlanBenefit.planId = ?1 and myPlanBenefit.benefitShare = ?2"),
		
/*,
		@NamedQuery(name = "findPlanBenefitForME", query = "select myPlanBenefit from PlanBenefit myPlanBenefit where myPlanBenefit.planId = plan.planId and myPlanBenefit.policyNo=plan.policyNo and myPlanBenefit.companyId=plan.companyId and myPlanBenefit.benefitItemCode ='A09' and myPlanBenefit.policyNo=?1")
		*/

})
@Table(name = "PLANBENEFIT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "PlanBenefit")
public class PlanBenefit extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "planBenefitSequence")
	@SequenceGenerator(name = "planBenefitSequence", sequenceName = "s_planbenefit")
	@Column(name = "PLANBENEFITID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long planBenefitId;
	/**
	 */

	@Column(name = "PLANID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long planId;
	/**
	 */

	@Column(name = "BENEFITITEMCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitItemCode;
	/**
	 */

	@Column(name = "COMPANYID", length = 8)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "INDEMNITYPERCENTAGE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal indemnityPercentage;
	/**
	 */

	@Column(name = "NOOFDAYS")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDays;
	/**
	 */

	@Column(name = "MAXNOOFDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer maxNoOfDay;
	/**
	 */

	@Column(name = "CONFINEMENTDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer confinementDay;
	/**
	 */

	@Column(name = "MAXCONFINEMENTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxConfinementAmt;
	/**
	 */

	@Column(name = "MAXMAJORCONFINEMENT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxMajorConfinement;
	/**
	 */

	@Column(name = "MAXBENEFITAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxBenefitAmt;
	/**
	 */

	@Column(name = "MAXYEARAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxYearAmt;
	/**
	 */

	@Column(name = "NONIPDSURGERYAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal nonIpdSurgeryAmt;
	/**
	 */

	@Column(name = "IPDSURGERYAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal ipdSurgeryAmt;
	/**
	 */

	@Column(name = "SPECIALIPDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal specialIPDAmt;
	/**
	 */

	@Column(name = "CHANGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date changeDate;
	/**
	 */

	@Column(name = "MAXNOOFDAYSHIST")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer maxNoOfDaysHist;
	/**
	 */

	@Column(name = "TOTALBENEFITAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalBenefitAmt;
	/**
	 */

	@Column(name = "SACALCULATETYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String saCalculateType;
	/**
	 */

	@Column(name = "SUMDUPLICATECHECKIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sumDuplicateCheckInd;
	/**
	 */

	@Column(name = "OOPIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String oopInd;
	/**
	 */

	@Column(name = "MEMBERSHIPTYPE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String membershipType;
	/**
	 */

	@Column(name = "MAXSAAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxSaamt;
	/**
	 */

	@Column(name = "MINSAAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal minSaamt;
	/**
	 */

	@Column(name = "FLATAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal flatAmt;
	/**
	 */

	@Column(name = "MULTIPLEFACTOR", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal multipleFactor;
	/**
	 */

	@Column(name = "BENEFITUNIT", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitUnit;
	/**
	 */

	@Column(name = "BENEFITAMOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal benefitAmount;
	/**
	 */

	@Column(name = "SUMSEQUENCENO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer sumSequenceNo;
	/**
	 */

	@Column(name = "ACCUMULATORNO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer accumulatorNo;
	/**
	 */

	@Column(name = "UNITNO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer unitNo;
	/**
	 */

	@Column(name = "SUMCATEGORY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sumCategory;
	/**
	 */

	@Column(name = "SUMTIMEFRAME", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sumTimeFrame;
	/**
	 */

	@Column(name = "FAMILYSHAREIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String familyShareInd;
	/**
	 */

	@Column(name = "OUTNETWORKSUMVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal outNetworkSumValue;
	/**
	 */

	@Column(name = "INNETWORKSUMVALUE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal inNetworkSumValue;
	/**
	 */
	@Column(name = "EFFECTIVEDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date effectiveDt;
	/**
	 */

	@Column(name = "GEOGRAPHICCOVERAGE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String geographicCoverage;
	/**
	 */
	/**
	 */
	@Column(name = "PRORATEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String proRateInd;

	@Column(name = "SHAREIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shareInd;

	@Column(name = "SHAREDESC", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shareDesc;

	@Column(name = "SHARELEVEL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shareLevel;

	@Column(name = "WAITINGPERIOD")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer waitingPeriod;
	
	@Column(name = "MAXSUMDAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private
	Integer maxSumDay;
	
	@Column(name = "BENEFITSHARE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitShare;
	
	@Column(name = "NOOFCALL")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfCall;
	
	@Column(name = "MAXYEARAMTHNW", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal maxYearAmtHNW;
	
	public BigDecimal getMaxYearAmtHNW() {
		return maxYearAmtHNW;
	}

	public void setMaxYearAmtHNW(BigDecimal maxYearAmtHNW) {
		this.maxYearAmtHNW = maxYearAmtHNW;
	}

	public Integer getNoOfCall() {
		return noOfCall;
	}

	public void setNoOfCall(Integer noOfCall) {
		this.noOfCall = noOfCall;
	}

	public String getBenefitShare() {
		return benefitShare;
	}

	public void setBenefitShare(String benefitShare) {
		this.benefitShare = benefitShare;
	}

	/**
	 * @return the planBenefitId
	 */
	public Long getPlanBenefitId() {
		return planBenefitId;
	}

	/**
	 * @param planBenefitId the planBenefitId to set
	 */
	public void setPlanBenefitId(Long planBenefitId) {
		this.planBenefitId = planBenefitId;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the benefitItemCode
	 */
	public String getBenefitItemCode() {
		return benefitItemCode;
	}

	/**
	 * @param benefitItemCode the benefitItemCode to set
	 */
	public void setBenefitItemCode(String benefitItemCode) {
		this.benefitItemCode = benefitItemCode;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the indemnityPercentage
	 */
	public BigDecimal getIndemnityPercentage() {
		return indemnityPercentage;
	}

	/**
	 * @param indemnityPercentage the indemnityPercentage to set
	 */
	public void setIndemnityPercentage(BigDecimal indemnityPercentage) {
		this.indemnityPercentage = indemnityPercentage;
	}

	/**
	 * @return the noOfDays
	 */
	public Integer getNoOfDays() {
		return noOfDays;
	}

	/**
	 * @param noOfDays the noOfDays to set
	 */
	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}

	/**
	 * @return the maxNoOfDay
	 */
	public Integer getMaxNoOfDay() {
		return maxNoOfDay;
	}

	/**
	 * @param maxNoOfDay the maxNoOfDay to set
	 */
	public void setMaxNoOfDay(Integer maxNoOfDay) {
		this.maxNoOfDay = maxNoOfDay;
	}

	/**
	 * @return the confinementDay
	 */
	public Integer getConfinementDay() {
		return confinementDay;
	}

	/**
	 * @param confinementDay the confinementDay to set
	 */
	public void setConfinementDay(Integer confinementDay) {
		this.confinementDay = confinementDay;
	}

	/**
	 * @return the maxConfinementAmt
	 */
	public BigDecimal getMaxConfinementAmt() {
		return maxConfinementAmt;
	}

	/**
	 * @param maxConfinementAmt the maxConfinementAmt to set
	 */
	public void setMaxConfinementAmt(BigDecimal maxConfinementAmt) {
		this.maxConfinementAmt = maxConfinementAmt;
	}

	/**
	 * @return the maxMajorConfinement
	 */
	public BigDecimal getMaxMajorConfinement() {
		return maxMajorConfinement;
	}

	/**
	 * @param maxMajorConfinement the maxMajorConfinement to set
	 */
	public void setMaxMajorConfinement(BigDecimal maxMajorConfinement) {
		this.maxMajorConfinement = maxMajorConfinement;
	}

	/**
	 * @param maxBenefitAmt the maxBenefitAmt to set
	 */
	public void setMaxBenefitAmt(BigDecimal maxBenefitAmt) {
		this.maxBenefitAmt = maxBenefitAmt;
	}

	/**
	 * @return the maxBenefitAmt
	 */
	public BigDecimal getMaxBenefitAmt() {
		return this.maxBenefitAmt;
	}

	/**
	 * @param maxYearAmt the maxYearAmt to set
	 */
	public void setMaxYearAmt(BigDecimal maxYearAmt) {
		this.maxYearAmt = maxYearAmt;
	}

	/**
	 * @return the maxYearAmt
	 */
	public BigDecimal getMaxYearAmt() {
		return this.maxYearAmt;
	}

	/**
	 * @return the nonIpdSurgeryAmt
	 */
	public BigDecimal getNonIpdSurgeryAmt() {
		return nonIpdSurgeryAmt;
	}

	/**
	 * @param nonIpdSurgeryAmt the nonIpdSurgeryAmt to set
	 */
	public void setNonIpdSurgeryAmt(BigDecimal nonIpdSurgeryAmt) {
		this.nonIpdSurgeryAmt = nonIpdSurgeryAmt;
	}

	/**
	 * @return the ipdSurgeryAmt
	 */
	public BigDecimal getIpdSurgeryAmt() {
		return ipdSurgeryAmt;
	}

	/**
	 * @param ipdSurgeryAmt the ipdSurgeryAmt to set
	 */
	public void setIpdSurgeryAmt(BigDecimal ipdSurgeryAmt) {
		this.ipdSurgeryAmt = ipdSurgeryAmt;
	}

	/**
	 * @return the specialIPDAmt
	 */
	public BigDecimal getSpecialIPDAmt() {
		return specialIPDAmt;
	}

	/**
	 * @param specialIPDAmt the specialIPDAmt to set
	 */
	public void setSpecialIPDAmt(BigDecimal specialIPDAmt) {
		this.specialIPDAmt = specialIPDAmt;
	}

	/**
	 * @return the changeDate
	 */
	public Date getChangeDate() {
		return changeDate;
	}

	/**
	 * @param changeDate the changeDate to set
	 */
	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}

	/**
	 * @return the maxNoOfDaysHist
	 */
	public Integer getMaxNoOfDaysHist() {
		return maxNoOfDaysHist;
	}

	/**
	 * @param maxNoOfDaysHist the maxNoOfDaysHist to set
	 */
	public void setMaxNoOfDaysHist(Integer maxNoOfDaysHist) {
		this.maxNoOfDaysHist = maxNoOfDaysHist;
	}

	/**
	 * @return the totalBenefitAmt
	 */
	public BigDecimal getTotalBenefitAmt() {
		return totalBenefitAmt;
	}

	/**
	 * @param totalBenefitAmt the totalBenefitAmt to set
	 */
	public void setTotalBenefitAmt(BigDecimal totalBenefitAmt) {
		this.totalBenefitAmt = totalBenefitAmt;
	}

	/**
	 * @param saCalculateType the saCalculateType to set
	 */
	public void setSaCalculateType(String saCalculateType) {
		this.saCalculateType = saCalculateType;
	}

	/**
	 * @return the saCalculateType
	 */
	public String getSaCalculateType() {
		return this.saCalculateType;
	}

	/**
	 * @param sumDuplicateCheckInd the sumDuplicateCheckInd to set
	 */
	public void setSumDuplicateCheckInd(String sumDuplicateCheckInd) {
		this.sumDuplicateCheckInd = sumDuplicateCheckInd;
	}

	/**
	 * @return the sumDuplicateCheckInd
	 */
	public String getSumDuplicateCheckInd() {
		return this.sumDuplicateCheckInd;
	}

	/**
	 * @param oopInd the oopInd to set
	 */
	public void setOopInd(String oopInd) {
		this.oopInd = oopInd;
	}

	/**
	 * @return the oopInd
	 */
	public String getOopInd() {
		return this.oopInd;
	}

	/**
	 * @param membershipType the membershipType to set
	 */
	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}

	/**
	 * @return the membershipType
	 */
	public String getMembershipType() {
		return this.membershipType;
	}

	/**
	 * @param maxSaamt the maxSaamt to set
	 */
	public void setMaxSaamt(BigDecimal maxSaamt) {
		this.maxSaamt = maxSaamt;
	}

	/**
	 * @return the maxSaamt
	 */
	public BigDecimal getMaxSaamt() {
		return this.maxSaamt;
	}

	/**
	 * @param minSaamt the minSaamt to set
	 */
	public void setMinSaamt(BigDecimal minSaamt) {
		this.minSaamt = minSaamt;
	}

	/**
	 * @return the minSaamt
	 */
	public BigDecimal getMinSaamt() {
		return this.minSaamt;
	}

	/**
	 * @param flatAmt the flatAmt to set
	 */
	public void setFlatAmt(BigDecimal flatAmt) {
		this.flatAmt = flatAmt;
	}

	/**
	 * @return the flatAmt
	 */
	public BigDecimal getFlatAmt() {
		return this.flatAmt;
	}

	/**
	 * @param multipleFactor the multipleFactor to set
	 */
	public void setMultipleFactor(BigDecimal multipleFactor) {
		this.multipleFactor = multipleFactor;
	}

	/**
	 * @return the multipleFactor
	 */
	public BigDecimal getMultipleFactor() {
		return this.multipleFactor;
	}

	/**
	 * @param benefitUnit the benefitUnit to set
	 */
	public void setBenefitUnit(String benefitUnit) {
		this.benefitUnit = benefitUnit;
	}

	/**
	 * @return the benefitUnit
	 */
	public String getBenefitUnit() {
		return this.benefitUnit;
	}

	/**
	 * @param benefitAmount the benefitAmount to set
	 */
	public void setBenefitAmount(BigDecimal benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	/**
	 * @return the benefitAmount
	 */
	public BigDecimal getBenefitAmount() {
		return this.benefitAmount;
	}

	/**
	 * @param totalBenefitAmt the totalBenefitAmt to set
	 */
	public void setSumSequenceNo(Integer sumSequenceNo) {
		this.sumSequenceNo = sumSequenceNo;
	}

	/**
	 * @return the sumSequenceNo
	 */
	public Integer getSumSequenceNo() {
		return this.sumSequenceNo;
	}

	/**
	 * @param accumulatorNo the accumulatorNo to set
	 */
	public void setAccumulatorNo(Integer accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	/**
	 * @return the accumulatorNo
	 */
	public Integer getAccumulatorNo() {
		return this.accumulatorNo;
	}

	/**
	 * @param unitNo the unitNo to set
	 */
	public void setUnitNo(Integer unitNo) {
		this.unitNo = unitNo;
	}

	/**
	 * @return the unitNo
	 */
	public Integer getUnitNo() {
		return this.unitNo;
	}

	/**
	 * @param sumCategory the sumCategory to set
	 */
	public void setSumCategory(String sumCategory) {
		this.sumCategory = sumCategory;
	}

	/**
	 * @return the sumCategory
	 */
	public String getSumCategory() {
		return this.sumCategory;
	}

	/**
	 * @param sumTimeFrame the sumTimeFrame to set
	 */
	public void setSumTimeFrame(String sumTimeFrame) {
		this.sumTimeFrame = sumTimeFrame;
	}

	/**
	 * @return the sumTimeFrame
	 */
	public String getSumTimeFrame() {
		return this.sumTimeFrame;
	}

	/**
	 * @param familyShareInd the familyShareInd to set
	 */
	public void setFamilyShareInd(String familyShareInd) {
		this.familyShareInd = familyShareInd;
	}

	/**
	 * @return the familyShareInd
	 */
	public String getFamilyShareInd() {
		return this.familyShareInd;
	}

	/**
	 * @param outNetworkSumValue the outNetworkSumValue to set
	 */
	public void setOutNetworkSumValue(BigDecimal outNetworkSumValue) {
		this.outNetworkSumValue = outNetworkSumValue;
	}

	/**
	 * @return the outNetworkSumValue
	 */
	public BigDecimal getOutNetworkSumValue() {
		return this.outNetworkSumValue;
	}

	/**
	 * @param inNetworkSumValue the inNetworkSumValue to set
	 */
	public void setInNetworkSumValue(BigDecimal inNetworkSumValue) {
		this.inNetworkSumValue = inNetworkSumValue;
	}

	/**
	 * @return the inNetworkSumValue
	 */
	public BigDecimal getInNetworkSumValue() {
		return this.inNetworkSumValue;
	}

	/**
	 * @return the effectivedt
	 */
	public Date getEffectiveDt() {
		return effectiveDt;
	}

	/**
	 * @param effectivedt the effectivedt to set
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 * @return the geographicCoverage
	 */
	public String getGeographicCoverage() {
		return geographicCoverage;
	}

	/**
	 * @param geographicCoverage the geographicCoverage to set
	 */
	public void setGeographicCoverage(String geographicCoverage) {
		this.geographicCoverage = geographicCoverage;
	}

	public String getProRateInd() {
		return proRateInd;
	}

	public void setProRateInd(String proRateInd) {
		this.proRateInd = proRateInd;
	}

	public String getShareInd() {
		return shareInd;
	}

	public void setShareInd(String shareInd) {
		this.shareInd = shareInd;
	}

	public String getShareDesc() {
		return shareDesc;
	}

	public void setShareDesc(String shareDesc) {
		this.shareDesc = shareDesc;
	}

	public String getShareLevel() {
		return shareLevel;
	}

	public void setShareLevel(String shareLevel) {
		this.shareLevel = shareLevel;
	}

	/**
	 * @param waitingPeriod the waitingPeriod to set
	 */
	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	/**
	 * @return the waitingPeriod
	 */
	public Integer getWaitingPeriod() {
		return this.waitingPeriod;
	}

	/**
	 * @return the maxSumDay
	 */
	public Integer getMaxSumDay() {
		return maxSumDay;
	}

	/**
	 * @param maxSumDay the maxSumDay to set
	 */
	public void setMaxSumDay(Integer maxSumDay) {
		this.maxSumDay = maxSumDay;
	}

	/**
	 */
	public PlanBenefit() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(PlanBenefit that) {
		setPlanBenefitId(that.getPlanBenefitId());
		setPlanId(that.getPlanId());
		setBenefitItemCode(that.getBenefitItemCode());
		setCompanyId(that.getCompanyId());
		setIndemnityPercentage(that.getIndemnityPercentage());
		setNoOfDays(that.getNoOfDays());
		setMaxNoOfDay(that.getMaxNoOfDay());
		setConfinementDay(that.getConfinementDay());
		setMaxConfinementAmt(that.getMaxConfinementAmt());
		setMaxMajorConfinement(that.getMaxMajorConfinement());
		setMaxBenefitAmt(that.getMaxBenefitAmt());
		setMaxYearAmt(that.getMaxYearAmt());
		setNonIpdSurgeryAmt(that.getNonIpdSurgeryAmt());
		setIpdSurgeryAmt(that.getIpdSurgeryAmt());
		setSpecialIPDAmt(that.getSpecialIPDAmt());
		setChangeDate(that.getChangeDate());
		setMaxNoOfDaysHist(that.getMaxNoOfDaysHist());
		setTotalBenefitAmt(that.getTotalBenefitAmt());
		setSaCalculateType(that.getSaCalculateType());
		setSumDuplicateCheckInd(that.getSumDuplicateCheckInd());
		setOopInd(that.getOopInd());
		setMembershipType(that.getMembershipType());
		setMaxSaamt(that.getMaxSaamt());
		setMinSaamt(that.getMinSaamt());
		setFlatAmt(that.getFlatAmt());
		setMultipleFactor(that.getMultipleFactor());
		setBenefitUnit(that.getBenefitUnit());
		setBenefitAmount(that.getBenefitAmount());
		setSumSequenceNo(that.getSumSequenceNo());
		setAccumulatorNo(that.getAccumulatorNo());
		setUnitNo(that.getUnitNo());
		setSumCategory(that.getSumCategory());
		setSumTimeFrame(that.getSumTimeFrame());
		setFamilyShareInd(that.getFamilyShareInd());
		setOutNetworkSumValue(that.getOutNetworkSumValue());
		setInNetworkSumValue(that.getInNetworkSumValue());
		setEffectiveDt(that.getEffectiveDt());
		setGeographicCoverage(that.getGeographicCoverage());
		setProRateInd(that.getProRateInd());
		setShareInd(that.getShareInd());
		setShareDesc(that.getShareDesc());
		setShareLevel(that.getShareLevel());
		setWaitingPeriod(that.getWaitingPeriod());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("planBenefitId=[").append(planBenefitId).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("benefitItemCode=[").append(benefitItemCode).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("indemnityPercentage=[").append(indemnityPercentage).append("] ");
		buffer.append("noOfDays=[").append(noOfDays).append("] ");
		buffer.append("maxNoOfDay=[").append(maxNoOfDay).append("] ");
		buffer.append("confinementDay=[").append(confinementDay).append("] ");
		buffer.append("maxConfinementAmt=[").append(maxConfinementAmt).append("] ");
		buffer.append("maxMajorConfinement=[").append(maxMajorConfinement).append("] ");
		buffer.append("maxBenefitAmt=[").append(maxBenefitAmt).append("] ");
		buffer.append("nonIpdSurgeryAmt=[").append(nonIpdSurgeryAmt).append("] ");
		buffer.append("ipdSurgeryAmt=[").append(ipdSurgeryAmt).append("] ");
		buffer.append("specialIPDAmt=[").append(specialIPDAmt).append("] ");
		buffer.append("changeDate=[").append(changeDate).append("] ");
		buffer.append("maxNoOfDaysHist=[").append(maxNoOfDaysHist).append("] ");
		buffer.append("totalBenefitAmt=[").append(totalBenefitAmt).append("] ");
		buffer.append("saCalculateType=[").append(saCalculateType).append("] ");
		buffer.append("sumDuplicateCheckInd=[").append(sumDuplicateCheckInd).append("] ");
		buffer.append("oopInd=[").append(oopInd).append("] ");
		buffer.append("membershipType=[").append(membershipType).append("] ");
		buffer.append("maxSaamt=[").append(maxSaamt).append("] ");
		buffer.append("minSaamt=[").append(minSaamt).append("] ");
		buffer.append("flatAmt=[").append(flatAmt).append("] ");
		buffer.append("multipleFactor=[").append(multipleFactor).append("] ");
		buffer.append("benefitUnit=[").append(benefitUnit).append("] ");
		buffer.append("benefitAmount=[").append(benefitAmount).append("] ");
		buffer.append("sumSequenceNo=[").append(sumSequenceNo).append("] ");
		buffer.append("accumulatorNo=[").append(accumulatorNo).append("] ");
		buffer.append("unitNo=[").append(unitNo).append("] ");
		buffer.append("sumCategory=[").append(sumCategory).append("] ");
		buffer.append("sumTimeFrame=[").append(sumTimeFrame).append("] ");
		buffer.append("familyShareInd=[").append(familyShareInd).append("] ");
		buffer.append("outNetworkSumValue=[").append(outNetworkSumValue).append("] ");
		buffer.append("inNetworkSumValue=[").append(inNetworkSumValue).append("] ");
		buffer.append("effectiveDt=[").append(effectiveDt).append("] ");
		buffer.append("geographicCoverage=[").append(geographicCoverage).append("] ");
		buffer.append("proRateInd=[").append(proRateInd).append("] ");
		buffer.append("shareInd=[").append(shareInd).append("] ");
		buffer.append("shareDesc=[").append(shareDesc).append("] ");
		buffer.append("shareLevel=[").append(shareLevel).append("] ");
		buffer.append("waitingPeriod=[").append(waitingPeriod).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((planBenefitId == null) ? 0 : planBenefitId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof PlanBenefit))
			return false;
		PlanBenefit equalCheck = (PlanBenefit) obj;
		if ((planBenefitId == null && equalCheck.planBenefitId != null) || (planBenefitId != null && equalCheck.planBenefitId == null))
			return false;
		if (planBenefitId != null && !planBenefitId.equals(equalCheck.planBenefitId))
			return false;
		return true;
	}
}