package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;
@Entity
@NamedQueries(
		{ //
			@NamedQuery(name = "findClaimDeductTempByclaimDeductId", query = "select claimDeductTemp from ClaimDeductTemp claimDeductTemp where claimDeductTemp.claimDeductId = ?1"),//
			@NamedQuery(name = "findClaimDeductTempByclaimNoOccurrencePolicyNo", query = "select claimDeductTemp from ClaimDeductTemp claimDeductTemp where claimDeductTemp.claimNo = ?1 and claimDeductTemp.occurrence = ?2 and claimDeductTemp.policyNo = ?3"),//
			@NamedQuery(name = "deleteClaimDeductTempByClaimNoOccurrence", query = "delete from ClaimDeductTemp claimDeductTemp where claimDeductTemp.claimNo = ?1 and claimDeductTemp.occurrence = ?2"),//
			@NamedQuery(name = "findClaimDeductTempByRefclaimNoOccurrence", query = "select claimDeductTemp from ClaimDeductTemp claimDeductTemp where claimDeductTemp.refClaimNo = ?1 and claimDeductTemp.refOccurrence = ?2 ")
		})//
@Table(name = "CLAIMDEDUCT_TEMP")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimDeductTemp")
public class ClaimDeductTemp extends BaseEntity implements Serializable{

	@Column(name = "CLAIMDEDUCTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimDeductId;
	
	@Column(name = "CLAIMDEDUCTNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimDeductNo;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	
	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	
	@Column(name = "REFCLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String refClaimNo;
	
	@Column(name = "REFOCCURRENCE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer refOccurrence;
	
	@Column(name = "RECEIVEDDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date receivedDate;
	
	@Column(name = "SUBMISSIONSOURCE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionSource;
	
	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	
	@Column(name = "BUSINESSLINE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String businessLine;
	
	@Column(name = "LASTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(LASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	
	@Column(name = "FIRSTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(FIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	
	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	
	@Column(name = "TREATMENTTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String treatmentType;
	
	@Column(name = "ACCIDENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date accidentDt;
	
	@Column(name = "HOSPITALIZATIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date hospitalizationDate;
	
	@Column(name = "DISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dischargeDate;
	
	@Column(name = "ICUADMISSIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuAdmissionDate;
	
	@Column(name = "ICUDISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuDischargeDate;
	
	@Column(name = "LENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer lengthOfStay;
	
	@Column(name = "ICULENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer icuLengthOfStay;
	
	@Column(name = "DEDUCTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deductStatus;
	
	@Column(name = "POLICYYEARFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearFromDt;
	
	@Column(name = "POLICYYEARTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearToDt;
	
	@Column(name = "CASEID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long caseId;
	
	@Column(name = "PARTYID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long partyId;

	
	@Column(name = "CAUSEOFTREATMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfTreatment;
	
	@Column(name = "TOTALDEDUCTAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalDeductAmt;

	@Column(name = "LASTMODIFIEDUSERDEPT", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDept;

	@Column(name = "LASTMODIFIEDUSERDESK", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastModifiedUserDesk;
	
	@Column(name = "SERVICINGAGENTCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgentCode;

	@Column(name = "SERVICINGAGENCYCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingAgencyCode;

	@Column(name = "SERVICINGGAOFFICECODE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String servicingGaOfficeCode;
	
	@Column(name = "PAYEETITLE", length = 30)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeTitle;
	
	@Column(name = "PAYEEFIRSTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(PAYEEFIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeFirstName;
	

	@Column(name = "PAYEELASTNAME", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(PAYEELASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeLastName;
	
	@Column(name = "ADDRESSLINE1", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE1, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine1;
	
	@Column(name = "ADDRESSLINE2", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE2, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine2;
	
	@Column(name = "ADDRESSLINE3", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE3, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine3;

	@Column(name = "ADDRESSLINE4", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(ADDRESSLINE4, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String addressLine4;
	
	@Column(name = "ZIPCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String zipCode;

	public Long getClaimDeductId() {
		return claimDeductId;
	}

	public String getClaimDeductNo() {
		return claimDeductNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public String getSubmissionSource() {
		return submissionSource;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public Date getIcuAdmissionDate() {
		return icuAdmissionDate;
	}

	public Date getIcuDischargeDate() {
		return icuDischargeDate;
	}

	public Integer getLengthOfStay() {
		return lengthOfStay;
	}

	public Integer getIcuLengthOfStay() {
		return icuLengthOfStay;
	}

	public String getDeductStatus() {
		return deductStatus;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public Long getCaseId() {
		return caseId;
	}

	public Long getPartyId() {
		return partyId;
	}

	public String getCauseOfTreatment() {
		return causeOfTreatment;
	}

	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	public String getServicingAgentCode() {
		return servicingAgentCode;
	}

	public String getServicingAgencyCode() {
		return servicingAgencyCode;
	}

	public String getServicingGaOfficeCode() {
		return servicingGaOfficeCode;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public String getPayeeFirstName() {
		return payeeFirstName;
	}

	public String getPayeeLastName() {
		return payeeLastName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setClaimDeductId(Long claimDeductId) {
		this.claimDeductId = claimDeductId;
	}

	public void setClaimDeductNo(String claimDeductNo) {
		this.claimDeductNo = claimDeductNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public void setSubmissionSource(String submissionSource) {
		this.submissionSource = submissionSource;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}

	public void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}

	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}

	public void setDeductStatus(String deductStatus) {
		this.deductStatus = deductStatus;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	public void setServicingAgentCode(String servicingAgentCode) {
		this.servicingAgentCode = servicingAgentCode;
	}

	public void setServicingAgencyCode(String servicingAgencyCode) {
		this.servicingAgencyCode = servicingAgencyCode;
	}

	public void setServicingGaOfficeCode(String servicingGaOfficeCode) {
		this.servicingGaOfficeCode = servicingGaOfficeCode;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public BigDecimal getTotalDeductAmt() {
		return totalDeductAmt;
	}

	public void setTotalDeductAmt(BigDecimal totalDeductAmt) {
		this.totalDeductAmt = totalDeductAmt;
	}

	public String getRefClaimNo() {
		return refClaimNo;
	}

	public Integer getRefOccurrence() {
		return refOccurrence;
	}

	public void setRefClaimNo(String refClaimNo) {
		this.refClaimNo = refClaimNo;
	}

	public void setRefOccurrence(Integer refOccurrence) {
		this.refOccurrence = refOccurrence;
	}
	
	
}
