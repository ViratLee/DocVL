package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findTransactionLogByServiceNameClaimNo", query = "select myTransactionLog from TransactionLog myTransactionLog where myTransactionLog.claimNo = ?1 and myTransactionLog.occurrence = ?2 and myTransactionLog.serviceName = ?3 "),
		@NamedQuery(name = "findTransactionLogMessageByCompanyIdServiceNameClaimNo", query = "select myTransactionLog.transactionLogId, myTransactionLog.respCode, myTransactionLog.respMsg from TransactionLog myTransactionLog where myTransactionLog.companyId = ?1 and myTransactionLog.claimNo = ?2 and myTransactionLog.occurrence = ?3 and myTransactionLog.serviceName = ?4 order by myTransactionLog.transactionLogId "),
		@NamedQuery(name = "removeTransactionLogClaimNoOccurence", query = "delete from TransactionLog myTransactionLog where myTransactionLog.claimNo = ?1 and myTransactionLog.occurrence = ?2 and myTransactionLog.serviceName='Calculation'"),
		@NamedQuery(name = "findTransactionLogByClaimnoServiceNameRespCode", query = "select myTransactionLog from TransactionLog myTransactionLog where myTransactionLog.claimNo = ?1 and myTransactionLog.occurrence = ?2 and myTransactionLog.serviceName = ?3 and myTransactionLog.respCode = ?4") })
@Table(name = "TRANSACTIONLOG")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "TransactionLog")
public class TransactionLog extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "transactionLogSequence")
	@SequenceGenerator(name = "transactionLogSequence", sequenceName = "s_transactionlog")
	@Column(name = "TRANSACTIONLOGID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long transactionLogId;
	/**
	 */
	@Column(name = "CLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "USERID", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String userId;
	/**
	 */

	@Column(name = "SESSIONID", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String sessionId;
	/**
	 */

	@Column(name = "LOGLEVEL", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String logLevel;
	/**
	 */

	@Column(name = "SERVERNAME", length = 50, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serverName;
	/**
	 */

	@Column(name = "SERVICENAME", length = 200, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceName;
	/**
	 */

	@Column(name = "STATUS", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;
	/**
	 */

	@Column(name = "RESPCODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String respCode;
	/**
	 */

	@Column(name = "RESPMSG", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String respMsg;

	/**
	 */

	/**
	 */
	public TransactionLog() {
	}

	public Long getTransactionLogId() {
		return transactionLogId;
	}

	public void setTransactionLogId(Long transactionLogId) {
		this.transactionLogId = transactionLogId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getRespMsg() {
		return respMsg;
	}

	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(TransactionLog that) {
		setTransactionLogId(that.getTransactionLogId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setUserId(that.getUserId());
		setStatus(that.getStatus());
		setSessionId(that.getSessionId());
		setCompanyId(that.getCompanyId());
		setServiceName(that.getServiceName());
		setServerName(that.getServerName());
		setRespCode(that.getRespCode());
		setRespMsg(that.getRespMsg());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("transactionErrorLogId=[").append(transactionLogId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("userId=[").append(userId).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("sessionId=[").append(sessionId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("logLevel=[").append(logLevel).append("] ");
		buffer.append("serviceName=[").append(serviceName).append("] ");
		buffer.append("serverName=[").append(serverName).append("] ");
		buffer.append("respCode=[").append(respCode).append("] ");
		buffer.append("respMsg=[").append(respMsg).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((transactionLogId == null) ? 0 : transactionLogId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof TransactionLog))
			return false;
		TransactionLog equalCheck = (TransactionLog) obj;
		if ((transactionLogId == null && equalCheck.transactionLogId != null) || (transactionLogId != null && equalCheck.transactionLogId == null))
			return false;
		if (transactionLogId != null && !transactionLogId.equals(equalCheck.transactionLogId))
			return false;
		return true;
	}
}
