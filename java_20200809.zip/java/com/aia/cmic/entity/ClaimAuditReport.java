package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 */

@SqlResultSetMapping(name = "ClaimAuditReport", classes = { @ConstructorResult(targetClass = ClaimAuditReport.class, columns = { @ColumnResult(name = "claimNo")

}) })
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimAuditReport")
public class ClaimAuditReport extends BaseEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CLAIMNO")
	String claimNo;

	@Column(name = "OCCURRENCE")
	int occurrence;

	@Column(name = "POLICYNO")
	String policyNo;

	@Column(name = "PLANID")
	int planId;

	@Column(name = "PLANNAME")
	String planName;

	@Column(name = "RULENO")
	String ruleNo;

	@Column(name = "SETTLEMENTDATE")
	Date settlementDate;

	@Column(name = "MARKINGIND")
	String markingId;

	@Column(name = "MARKINGDESC")
	String markingDesc;

	@Column(name = "MARKINGREASON")
	String markingReason;

	@Column(name = "MARKINGREASONDESC")
	String markingReasonDesc;

	@Column(name = "APPROVEDAMT")
	BigDecimal approvedAmt;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public int getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(int occurrence) {
		this.occurrence = occurrence;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getRuleNo() {
		return ruleNo;
	}

	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getMarkingId() {
		return markingId;
	}

	public void setMarkingId(String markingId) {
		this.markingId = markingId;
	}

	public String getMarkingDesc() {
		return markingDesc;
	}

	public void setMarkingDesc(String markingDesc) {
		this.markingDesc = markingDesc;
	}

	public String getMarkingReason() {
		return markingReason;
	}

	public void setMarkingReason(String markingReason) {
		this.markingReason = markingReason;
	}

	public String getMarkingReasonDesc() {
		return markingReasonDesc;
	}

	public void setMarkingReasonDesc(String markingReasonDesc) {
		this.markingReasonDesc = markingReasonDesc;
	}

	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}

	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

}
