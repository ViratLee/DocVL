package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
@Entity
@NamedQueries(//
		{//
		  @NamedQuery(name = "findClaimDeductDetailTempByclaimDeductNo", query = "select claimDeductDetailTemp from ClaimDeductDetailTemp claimDeductDetailTemp where claimDeductDetailTemp.claimDeductNo = ?1")//
          
        })//
@Table(name = "CLAIMDEDUCTDETAIL_TEMP")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimDeductDetailTemp")
public class ClaimDeductDetailTemp extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1023944165127089378L;

	/**
	 * 
	 */

	@Column(name = "CLAIMDEDUCTDETAILID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimDeductDetailId;
	
	@Column(name = "CLAIMDEDUCTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String claimDeductNo;
	
	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	
	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	
	@Column(name = "NOOFDAYSALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysAllocated;
	
	@Column(name = "NOOFCALLALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer noOfCallAllocated;
	
	@Column(name = "APPROVEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal approvedAmt;
	
	@Column(name = "DEDUCTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deductStatus;
	
	@Column(name = "POLICYYEARFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearFromDt;
	
	@Column(name = "POLICYYEARTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearToDt;

	public Long getClaimDeductDetailId() {
		return claimDeductDetailId;
	}

	public String getClaimDeductNo() {
		return claimDeductNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public Integer getNoOfDaysAllocated() {
		return noOfDaysAllocated;
	}

	public Integer getNoOfCallAllocated() {
		return noOfCallAllocated;
	}

	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}

	public String getDeductStatus() {
		return deductStatus;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setClaimDeductDetailId(Long claimDeductDetailId) {
		this.claimDeductDetailId = claimDeductDetailId;
	}

	public void setClaimDeductNo(String claimDeductNo) {
		this.claimDeductNo = claimDeductNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	public void setNoOfCallAllocated(Integer noOfCallAllocated) {
		this.noOfCallAllocated = noOfCallAllocated;
	}

	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

	public void setDeductStatus(String deductStatus) {
		this.deductStatus = deductStatus;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

}
