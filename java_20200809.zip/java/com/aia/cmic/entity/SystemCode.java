package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
//	@NamedQuery(name = "findAllSystemCodes", query = "select mySystemCode from SystemCode mySystemCode"),
//		@NamedQuery(name = "findSystemCodeByPrimaryKey", query = "select mySystemCode from SystemCode mySystemCode where mySystemCode.sysCodeId = ?1"),
@NamedQuery(name = "findSystemCodeBySystemCodeField", query = "select mySystemCode from SystemCode mySystemCode where mySystemCode.systemCodeField = ?1")
//		@NamedQuery(name = "findSystemCodeByStatus", query = "select mySystemCode from SystemCode mySystemCode where mySystemCode.status = ?1"),
//		@NamedQuery(name = "findSystemCodeBySysCodeId", query = "select mySystemCode from SystemCode mySystemCode where mySystemCode.sysCodeId = ?1")
})
@Table(name = "SYSTEMCODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "SystemCode")
public class SystemCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "systemCodeSequence")
	@SequenceGenerator(name = "systemCodeSequence", sequenceName = "s_systemcode")
	@Column(name = "SYSCODEID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long sysCodeId;
	/**
	 */

	@Column(name = "SYSTEMCODE", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String systemCodeField;
	/**
	 */

	@Column(name = "INCREMENTCOUNT", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer incrementCount;
	/**
	 */

	@Column(name = "LASTNUMBER", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer lastNumber;
	/**
	 */

	@Column(name = "STATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String status;
	/**
	 */

	@Column(name = "REMARK", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String remark;

	/**
	 * @return the sysCodeId
	 */
	public Long getSysCodeId() {
		return sysCodeId;
	}

	/**
	 * @param sysCodeId the sysCodeId to set
	 */
	public void setSysCodeId(Long sysCodeId) {
		this.sysCodeId = sysCodeId;
	}

	/**
	 * @return the systemCodeField
	 */
	public String getSystemCodeField() {
		return systemCodeField;
	}

	/**
	 * @param systemCodeField the systemCodeField to set
	 */
	public void setSystemCodeField(String systemCodeField) {
		this.systemCodeField = systemCodeField;
	}

	/**
	 * @return the incrementCount
	 */
	public Integer getIncrementCount() {
		return incrementCount;
	}

	/**
	 * @param incrementCount the incrementCount to set
	 */
	public void setIncrementCount(Integer incrementCount) {
		this.incrementCount = incrementCount;
	}

	/**
	 * @return the lastNumber
	 */
	public Integer getLastNumber() {
		return lastNumber;
	}

	/**
	 * @param lastNumber the lastNumber to set
	 */
	public void setLastNumber(Integer lastNumber) {
		this.lastNumber = lastNumber;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 */
	public SystemCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(SystemCode that) {
		setSysCodeId(that.getSysCodeId());
		setSystemCodeField(that.getSystemCodeField());
		setIncrementCount(that.getIncrementCount());
		setLastNumber(that.getLastNumber());
		setStatus(that.getStatus());
		setRemark(that.getRemark());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("sysCodeId=[").append(sysCodeId).append("] ");
		buffer.append("systemCodeField=[").append(systemCodeField).append("] ");
		buffer.append("incrementCount=[").append(incrementCount).append("] ");
		buffer.append("lastNumber=[").append(lastNumber).append("] ");
		buffer.append("status=[").append(status).append("] ");
		buffer.append("remark=[").append(remark).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((sysCodeId == null) ? 0 : sysCodeId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof SystemCode))
			return false;
		SystemCode equalCheck = (SystemCode) obj;
		if ((sysCodeId == null && equalCheck.sysCodeId != null) || (sysCodeId != null && equalCheck.sysCodeId == null))
			return false;
		if (sysCodeId != null && !sysCodeId.equals(equalCheck.sysCodeId))
			return false;
		return true;
	}
}
