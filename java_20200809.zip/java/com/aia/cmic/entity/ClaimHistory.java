package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.annotations.ColumnTransformer;

@Entity
@NamedQueries({ @NamedQuery(name = "findClaimHistoryByClaimId", query = "select myClaimHistory from ClaimHistory myClaimHistory where myClaimHistory.claimId = ?1"), })
@Table(name = "CLAIMHISTORY")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimHistory")
public class ClaimHistory extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "CLAIMID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimId;

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;

	@Column(name = "OCCURRENCE", length = 3, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;

	@Column(name = "PREVIOUSCLAIMNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String previousClaimNo;

	@Column(name = "PREVIOUSOCCURRENCE", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer previousOccurence;

	@Column(name = "RECEIVEDDATE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date receivedDate;

	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "CERTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String certNo;

	@Column(name = "MEMBERID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberId;
	/**
	 */

	@Column(name = "DEPENDENTNO", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dependentNo;
	/**
	 */

	@Column(name = "DEPENDENTTYPE", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dependentType;
	/**
	 */

	@Column(name = "RELATIONSHIP", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String relationship;

	@Column(name = "RELATIONSHIPNAME", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String relationshipName;
	/**
	 */

	@Column(name = "VIP", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String vip;
	/**
	 */

	@Column(name = "CLIENTID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String clientId;

	@Column(name = "PARTYID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long partyId;

	/** 
	 */

	@Column(name = "POLICYOWNERPARTYID")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long policyOwnerPartyId;

	/**
	 */

	@Column(name = "MEMBERLASTNAME", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MEMBERLASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberLastName;
	/**
	 */

	@Column(name = "MEMBERFIRSTNAME", columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(MEMBERFIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String memberFirstName;
	/**
	 */

	@Column(name = "LASTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(LASTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastName;
	/**
	 */

	@Column(name = "FIRSTNAME", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(FIRSTNAME, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String firstName;
	/**
	 */

	@Column(name = "GENDER", length = 1, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String gender;
	/**
	 */

	@Column(name = "DOB", nullable = false, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(DOB, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String dob;
	/**
	 */

	@Column(name = "NATIONALID", length = 100, columnDefinition = "raw")
	@ColumnTransformer(read = "TOOLKIT.decrypt(NATIONALID, '" + "1234567812345678" + "')", write = "TOOLKIT.encrypt(?, '" + "1234567812345678" + "')")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String nationalId;

	@Column(name = "SUBOFFICECODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeCode;
	/**
	 */

	@Column(name = "SUBOFFICESTATUS", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String subOfficeStatus;
	/**
	 */

	@Column(name = "POLICYHOLDER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyHolder;
	/**
	 */

	@Column(name = "POLICYOWNER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyOwner;
	/**
	 */

	@Column(name = "CHANNEL", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String channel;
	/**
	 */

	@Column(name = "SUBMISSIONTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String submissionType;
	/**
	 */

	@Column(name = "PAYMENTSEQ", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentSeq;
	/**
	 */

	@Column(name = "NOORIGINALBILLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String noOriginalBillInd;

	/**
	 */

	@Column(name = "ORIGINALBILLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String originalBillInd;
	/**
	 */

	@Column(name = "BILLNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billNo;
	/**
	 */
	@Column(name = "BILLDTFROM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date billDtFrom;
	/**
	 */
	@Column(name = "BILLDTTO")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date billDtTo;
	/**
	 */

	@Column(name = "AGENCYCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyCodeServicing;
	/**
	 */

	@Column(name = "AGENTCODESERVICING", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agentCodeServicing;
	/**
	 */

	@Column(name = "AGENCYOFFICECODESERVICING", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String agencyOfficeCodeServicing;
	/**
	 */
	@Column(name = "FASTTRACKAGENCY", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String fastTrackAgency;
	/**
	 */

	@Column(name = "BROKERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brokerCode;
	/**
	 */

	@Column(name = "BROKERNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brokerName;
	/**
	 */

	@Column(name = "PAYEEISCOMPANYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String payeeIsCompanyInd;
	/**
	 */

	@Column(name = "PAYMENTMETHOD", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentMethod;
	/**
	 */

	@Column(name = "BILLINGSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingStatus;
	/**
	 */

	/**
	 */
	@Column(name = "BILLINGDECLINEREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String billingDeclineReason;

	/**
	 */

	@Column(name = "CLASSOFBED", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String classOfBed;
	/**
	 */

	@Column(name = "ROOMTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String roomType;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "REFERRALDOCTORCODE", length = 13)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorCode;
	/**
	 */

	@Column(name = "REFERRALDOCTORNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorName;
	/**
	 */

	@Column(name = "REFERRALDOCTOREMAIL", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorEmail;
	/**
	 */

	@Column(name = "REFERRALDOCTORPHONE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorPhone;
	/**
	 */

	@Column(name = "REFERRALDOCTORFAX", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String referralDoctorFax;
	/**
	 */

	@Column(name = "PREVDOCTORNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorName;
	/**
	 */

	@Column(name = "PREVDOCTOREMAIL", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorEmail;
	/**
	 */

	@Column(name = "PREVDOCTORPHONE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorPhone;
	/**
	 */

	@Column(name = "PREVDOCTORFAX", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String prevDoctorFax;
	/**
	 */
	@Column(name = "FIRSTCONSULTATIONDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date firstConsultationDt;
	/**
	 */
	@Column(name = "CONSULTATIONDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date consultationDt;
	/**
	 */
	@Column(name = "SYMPTOMDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date symptomDate;

	@Column(name = "PHYSICALFINDING", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String physicalFinding;
	/**
	 */

	@Column(name = "CHIEFCOMPLAINT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String chiefComplaint;
	/**
	 */

	@Column(name = "UNDERLYINGCAUSE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String underlyingCause;
	/**
	 */

	@Column(name = "ILLNESSSPECIALCONDITION", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String illnessSpecialCondition;
	/**
	 */

	@Column(name = "DIAGNOSISRESULT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String diagnosisResult;
	/**
	 */

	@Column(name = "PROVISIONALDIAGNOSIS", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String provisionalDiagnosis;
	/**
	 */

	@Column(name = "CONDITIONREQUIREDTREATMENT", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String conditionRequiredTreatment;
	/**
	 */

	@Column(name = "PRESENTILLNESS", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String presentIllness;
	/**
	 */

	@Column(name = "TEMPERATURE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal temperature;
	/**
	 */

	@Column(name = "PULSE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal pulse;
	/**
	 */

	@Column(name = "RESPIRATORYRATE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal respiratoryRate;
	/**
	 */

	@Column(name = "SYSTOLIC", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal systolic;
	/**
	 */

	@Column(name = "DIASTOLIC", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal diastolic;
	/**
	 */

	@Column(name = "PAINSCORE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer painScore;
	/**
	 */

	@Column(name = "COMASCORE", length = 2)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer comaScore;
	/**
	 */

	@Column(name = "WEIGHT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal weight;
	/**
	 */

	@Column(name = "HEIGHT", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal height;
	/**
	 */

	@Column(name = "BMI", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal bmi;
	/**
	 */
	@Column(name = "ACCIDENTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date accidentDt;
	/**
	 */

	@Column(name = "ACCIDENTPLACE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String accidentPlace;
	/**
	 */

	@Column(name = "LEVELOFCONSCIOUSNESS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String levelOfConsciousness;
	/**
	 */

	@Column(name = "CAUSEOFINJURY", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfInjury;
	/**
	 */

	@Column(name = "INJURYTYPE", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String injuryType;
	/**
	 */

	@Column(name = "ESTIMATEDTIMEOFDISCOVERY", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer estimatedTimeOfDiscovery;
	/**
	 */

	@Column(name = "ESTIMATEDMONTHOFDISCOVERY", length = 3)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer estimatedMonthOfDiscovery;
	/**
	 */
	@Column(name = "PREVTREATMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date prevTreatmentDate;
	/**
	 */
	@Column(name = "TREATMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date treatmentDate;
	/**
	 */

	@Column(name = "TREATMENTTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String treatmentType;
	/**
	 */

	@Column(name = "CAUSEOFTREATMENT", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String causeOfTreatment;
	/**
	 */
	@Column(name = "HOSPITALIZATIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date hospitalizationDate;
	/**
	 */

	@Column(name = "HOSPITALIZATIONREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hospitalizationReason;
	/**
	 */
	@Column(name = "DISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dischargeDate;
	/**
	 */

	@Column(name = "LENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer lengthOfStay;
	/**
	 */
	@Column(name = "ICUADMISSIONDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuAdmissionDate;
	/**
	 */
	@Column(name = "ICUDISCHARGEDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date icuDischargeDate;
	/**
	 */

	@Column(name = "ICULENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer icuLengthOfStay;
	/**
	 */

	@Column(name = "ICUREASON", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icuReason;
	/**
	 */

	@Column(name = "OTHERINSURER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String otherInsurer;
	/**
	 */
	@Column(name = "HOMELEAVEFROMDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date homeLeaveFromDate;
	/**
	 */
	@Column(name = "HOMELEAVETODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date homeLeaveToDt;
	/**
	 */

	@Column(name = "HOMELEAVEREASON", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String homeLeaveReason;
	/**
	 */

	@Column(name = "RECONSIDERCASE", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String reconsiderCase;
	/**
	 */

	@Column(name = "DELETEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deleteInd;
	/**
	 */

	@Column(name = "AUTOCLAIMIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String autoClaimInd;
	/**
	 */

	@Column(name = "CPTCODE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String cptCode;
	/**
	 */

	@Column(name = "ASSESSORCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String assessorCode;
	/**
	 */

	@Column(name = "APPROVALCODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String approvalCode;
	/**
	 */

	@Column(name = "PAYMENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String paymentInd;
	/**
	 */

	@Column(name = "HEALTHCARDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String healthCardInd;
	/**
	 */

	@Column(name = "CARECARDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String careCardInd;
	/**
	 */

	@Column(name = "ONECARDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String oneCardInd;
	/**
	 */

	@Column(name = "CLAIMSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimStatus;

	/**
	 */
	@Column(name = "PROCESSSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String processStatus;

	/**
	 */
	@Column(name = "CLAIMSTATUSDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date claimStatusDt;
	/**
	 */

	@Column(name = "RECEIPTOFREFERRAL", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String receiptOfReferral;
	/**
	 */

	@Column(name = "APPEALIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String appealInd;
	/**
	 */

	@Column(name = "EMERGENCYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String emergencyInd;
	/**
	 */

	@Column(name = "DAYOFADMITROOM")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfAdmitRoom;
	/**
	 */

	@Column(name = "DAYOFADMITICU")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfAdmitIcu;
	/**
	 */

	@Column(name = "DAYOFCALL")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfCall;

	/**
	 */

	@Column(name = "TOTALDISABILITY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer totalDisability;
	/**
	 */

	@Column(name = "PARTIALDISABILITY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer partialDisability;
	/**
	 */
	@Column(name = "DISABILITYSTARTDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date disabilityStartDt;

	/**
	 */
	@Column(name = "DISABILITYENDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date disabilityEndDt;

	/**
	 */

	@Column(name = "SURGICALPERCENTAGE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String surgicalPercentage;
	/**
	 */

	@Column(name = "DOUBLEINDEMNITY", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String doubleIndemnity;
	/**
	 */

	@Column(name = "HOMEMEDICALIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String homeMedicalInd;
	/**
	 */

	@Column(name = "HBPTYPE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hbpType;
	/**
	 */

	@Column(name = "ATTAINEDAGEIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String attainedAgeInd;
	/**
	 */

	@Column(name = "ANESTHESIAIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String anesthesiaInd;
	/**
	 */

	@Column(name = "SURGERYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String surgeryInd;
	/**
	 */

	@Column(name = "DISEASEIND", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String diseaseInd;
	/**
	 */

	@Column(name = "DAYOFADMITJUNIOR")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer dayOfAdmitJunior;
	/**
	 */

	@Column(name = "MAJORACCID", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String majorAccId;
	/**
	 */

	@Column(name = "MAJORINJURYDETAIL", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String majorInjuryDetail;
	/**
	 */

	@Column(name = "HBJSURGERYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String hbjSurgeryInd;

	/**
	 */

	@Column(name = "SHORTFALLIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String shortFallInd;

	/**
	 */

	@Column(name = "ORIGCURRENCY", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String origCurrency;
	/**
	 */

	@Column(name = "CONVCURRENCY", length = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String convCurrency;
	/**
	 */

	@Column(name = "EXCHANGERATEDESC", length = 50)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String exchangeRateDesc;
	/**
	 */

	@Column(name = "TOTALESTIMATEDCOST", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalEstimatedCost;
	/**
	 */

	@Column(name = "TOTALBILLEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal totalBilledAmt;
	/**
	 */

	@Column(name = "HOLDPAYMENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String holdPaymentInd;
	/**
	 */

	@Column(name = "HOLDPAYMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date holdPaymentDate;
	/**
	 */

	@Column(name = "RELEASEHOLDPAYMENTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String releaseHoldPaymentInd;
	/**
	 */

	@Column(name = "RELEASEHOLDPAYMENTDATE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date releaseHoldPaymentDate;
	/**
	 */

	@Column(name = "PHASE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String phase;
	/**
	 */

	@Column(name = "CASEID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long caseId;
	/**
	 */
	@Column(name = "INITIALPHASE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String initialPhase;
	/**
	 */

	@Column(name = "BATCHNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String batchNo;

	@Column(name = "ICD10CODE", length = 4000)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10Code;

	public String getIcd10Code() {
		return icd10Code;
	}

	public void setIcd10Code(String icd10Code) {
		this.icd10Code = icd10Code;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getPreviousClaimNo() {
		return previousClaimNo;
	}

	public void setPreviousClaimNo(String previousClaimNo) {
		this.previousClaimNo = previousClaimNo;
	}

	public Integer getPreviousOccurence() {
		return previousOccurence;
	}

	public void setPreviousOccurence(Integer previousOccurence) {
		this.previousOccurence = previousOccurence;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getDependentType() {
		return dependentType;
	}

	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getRelationshipName() {
		return relationshipName;
	}

	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}

	public String getVip() {
		return vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public Long getPolicyOwnerPartyId() {
		return policyOwnerPartyId;
	}

	public void setPolicyOwnerPartyId(Long policyOwnerPartyId) {
		this.policyOwnerPartyId = policyOwnerPartyId;
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	public String getSubOfficeStatus() {
		return subOfficeStatus;
	}

	public void setSubOfficeStatus(String subOfficeStatus) {
		this.subOfficeStatus = subOfficeStatus;
	}

	public String getPolicyHolder() {
		return policyHolder;
	}

	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	public String getPolicyOwner() {
		return policyOwner;
	}

	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getPaymentSeq() {
		return paymentSeq;
	}

	public void setPaymentSeq(String paymentSeq) {
		this.paymentSeq = paymentSeq;
	}

	public String getNoOriginalBillInd() {
		return noOriginalBillInd;
	}

	public void setNoOriginalBillInd(String noOriginalBillInd) {
		this.noOriginalBillInd = noOriginalBillInd;
	}

	public String getOriginalBillInd() {
		return originalBillInd;
	}

	public void setOriginalBillInd(String originalBillInd) {
		this.originalBillInd = originalBillInd;
	}

	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	public Date getBillDtFrom() {
		return billDtFrom;
	}

	public void setBillDtFrom(Date billDtFrom) {
		this.billDtFrom = billDtFrom;
	}

	public Date getBillDtTo() {
		return billDtTo;
	}

	public void setBillDtTo(Date billDtTo) {
		this.billDtTo = billDtTo;
	}

	public String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	public String getAgencyOfficeCodeServicing() {
		return agencyOfficeCodeServicing;
	}

	public void setAgencyOfficeCodeServicing(String agencyOfficeCodeServicing) {
		this.agencyOfficeCodeServicing = agencyOfficeCodeServicing;
	}

	public String getFastTrackAgency() {
		return fastTrackAgency;
	}

	public void setFastTrackAgency(String fastTrackAgency) {
		this.fastTrackAgency = fastTrackAgency;
	}

	public String getBrokerCode() {
		return brokerCode;
	}

	public void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public String getPayeeIsCompanyInd() {
		return payeeIsCompanyInd;
	}

	public void setPayeeIsCompanyInd(String payeeIsCompanyInd) {
		this.payeeIsCompanyInd = payeeIsCompanyInd;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getBillingStatus() {
		return billingStatus;
	}

	public void setBillingStatus(String billingStatus) {
		this.billingStatus = billingStatus;
	}

	public String getBillingDeclineReason() {
		return billingDeclineReason;
	}

	public void setBillingDeclineReason(String billingDeclineReason) {
		this.billingDeclineReason = billingDeclineReason;
	}

	public String getClassOfBed() {
		return classOfBed;
	}

	public void setClassOfBed(String classOfBed) {
		this.classOfBed = classOfBed;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getReferralDoctorCode() {
		return referralDoctorCode;
	}

	public void setReferralDoctorCode(String referralDoctorCode) {
		this.referralDoctorCode = referralDoctorCode;
	}

	public String getReferralDoctorName() {
		return referralDoctorName;
	}

	public void setReferralDoctorName(String referralDoctorName) {
		this.referralDoctorName = referralDoctorName;
	}

	public String getReferralDoctorEmail() {
		return referralDoctorEmail;
	}

	public void setReferralDoctorEmail(String referralDoctorEmail) {
		this.referralDoctorEmail = referralDoctorEmail;
	}

	public String getReferralDoctorPhone() {
		return referralDoctorPhone;
	}

	public void setReferralDoctorPhone(String referralDoctorPhone) {
		this.referralDoctorPhone = referralDoctorPhone;
	}

	public String getReferralDoctorFax() {
		return referralDoctorFax;
	}

	public void setReferralDoctorFax(String referralDoctorFax) {
		this.referralDoctorFax = referralDoctorFax;
	}

	public String getPrevDoctorName() {
		return prevDoctorName;
	}

	public void setPrevDoctorName(String prevDoctorName) {
		this.prevDoctorName = prevDoctorName;
	}

	public String getPrevDoctorEmail() {
		return prevDoctorEmail;
	}

	public void setPrevDoctorEmail(String prevDoctorEmail) {
		this.prevDoctorEmail = prevDoctorEmail;
	}

	public String getPrevDoctorPhone() {
		return prevDoctorPhone;
	}

	public void setPrevDoctorPhone(String prevDoctorPhone) {
		this.prevDoctorPhone = prevDoctorPhone;
	}

	public String getPrevDoctorFax() {
		return prevDoctorFax;
	}

	public void setPrevDoctorFax(String prevDoctorFax) {
		this.prevDoctorFax = prevDoctorFax;
	}

	public Date getFirstConsultationDt() {
		return firstConsultationDt;
	}

	public void setFirstConsultationDt(Date firstConsultationDt) {
		this.firstConsultationDt = firstConsultationDt;
	}

	public Date getConsultationDt() {
		return consultationDt;
	}

	public void setConsultationDt(Date consultationDt) {
		this.consultationDt = consultationDt;
	}

	public Date getSymptomDate() {
		return symptomDate;
	}

	public void setSymptomDate(Date symptomDate) {
		this.symptomDate = symptomDate;
	}

	public String getPhysicalFinding() {
		return physicalFinding;
	}

	public void setPhysicalFinding(String physicalFinding) {
		this.physicalFinding = physicalFinding;
	}

	public String getChiefComplaint() {
		return chiefComplaint;
	}

	public void setChiefComplaint(String chiefComplaint) {
		this.chiefComplaint = chiefComplaint;
	}

	public String getUnderlyingCause() {
		return underlyingCause;
	}

	public void setUnderlyingCause(String underlyingCause) {
		this.underlyingCause = underlyingCause;
	}

	public String getIllnessSpecialCondition() {
		return illnessSpecialCondition;
	}

	public void setIllnessSpecialCondition(String illnessSpecialCondition) {
		this.illnessSpecialCondition = illnessSpecialCondition;
	}

	public String getDiagnosisResult() {
		return diagnosisResult;
	}

	public void setDiagnosisResult(String diagnosisResult) {
		this.diagnosisResult = diagnosisResult;
	}

	public String getProvisionalDiagnosis() {
		return provisionalDiagnosis;
	}

	public void setProvisionalDiagnosis(String provisionalDiagnosis) {
		this.provisionalDiagnosis = provisionalDiagnosis;
	}

	public String getConditionRequiredTreatment() {
		return conditionRequiredTreatment;
	}

	public void setConditionRequiredTreatment(String conditionRequiredTreatment) {
		this.conditionRequiredTreatment = conditionRequiredTreatment;
	}

	public String getPresentIllness() {
		return presentIllness;
	}

	public void setPresentIllness(String presentIllness) {
		this.presentIllness = presentIllness;
	}

	public BigDecimal getTemperature() {
		return temperature;
	}

	public void setTemperature(BigDecimal temperature) {
		this.temperature = temperature;
	}

	public BigDecimal getPulse() {
		return pulse;
	}

	public void setPulse(BigDecimal pulse) {
		this.pulse = pulse;
	}

	public BigDecimal getRespiratoryRate() {
		return respiratoryRate;
	}

	public void setRespiratoryRate(BigDecimal respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}

	public BigDecimal getSystolic() {
		return systolic;
	}

	public void setSystolic(BigDecimal systolic) {
		this.systolic = systolic;
	}

	public BigDecimal getDiastolic() {
		return diastolic;
	}

	public void setDiastolic(BigDecimal diastolic) {
		this.diastolic = diastolic;
	}

	public Integer getPainScore() {
		return painScore;
	}

	public void setPainScore(Integer painScore) {
		this.painScore = painScore;
	}

	public Integer getComaScore() {
		return comaScore;
	}

	public void setComaScore(Integer comaScore) {
		this.comaScore = comaScore;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getHeight() {
		return height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public BigDecimal getBmi() {
		return bmi;
	}

	public void setBmi(BigDecimal bmi) {
		this.bmi = bmi;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public String getAccidentPlace() {
		return accidentPlace;
	}

	public void setAccidentPlace(String accidentPlace) {
		this.accidentPlace = accidentPlace;
	}

	public String getLevelOfConsciousness() {
		return levelOfConsciousness;
	}

	public void setLevelOfConsciousness(String levelOfConsciousness) {
		this.levelOfConsciousness = levelOfConsciousness;
	}

	public String getCauseOfInjury() {
		return causeOfInjury;
	}

	public void setCauseOfInjury(String causeOfInjury) {
		this.causeOfInjury = causeOfInjury;
	}

	public String getInjuryType() {
		return injuryType;
	}

	public void setInjuryType(String injuryType) {
		this.injuryType = injuryType;
	}

	public Integer getEstimatedTimeOfDiscovery() {
		return estimatedTimeOfDiscovery;
	}

	public void setEstimatedTimeOfDiscovery(Integer estimatedTimeOfDiscovery) {
		this.estimatedTimeOfDiscovery = estimatedTimeOfDiscovery;
	}

	public Integer getEstimatedMonthOfDiscovery() {
		return estimatedMonthOfDiscovery;
	}

	public void setEstimatedMonthOfDiscovery(Integer estimatedMonthOfDiscovery) {
		this.estimatedMonthOfDiscovery = estimatedMonthOfDiscovery;
	}

	public Date getPrevTreatmentDate() {
		return prevTreatmentDate;
	}

	public void setPrevTreatmentDate(Date prevTreatmentDate) {
		this.prevTreatmentDate = prevTreatmentDate;
	}

	public Date getTreatmentDate() {
		return treatmentDate;
	}

	public void setTreatmentDate(Date treatmentDate) {
		this.treatmentDate = treatmentDate;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public String getCauseOfTreatment() {
		return causeOfTreatment;
	}

	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public String getHospitalizationReason() {
		return hospitalizationReason;
	}

	public void setHospitalizationReason(String hospitalizationReason) {
		this.hospitalizationReason = hospitalizationReason;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public Integer getLengthOfStay() {
		return lengthOfStay;
	}

	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public Date getIcuAdmissionDate() {
		return icuAdmissionDate;
	}

	public void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}

	public Date getIcuDischargeDate() {
		return icuDischargeDate;
	}

	public void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}

	public Integer getIcuLengthOfStay() {
		return icuLengthOfStay;
	}

	public void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}

	public String getIcuReason() {
		return icuReason;
	}

	public void setIcuReason(String icuReason) {
		this.icuReason = icuReason;
	}

	public String getOtherInsurer() {
		return otherInsurer;
	}

	public void setOtherInsurer(String otherInsurer) {
		this.otherInsurer = otherInsurer;
	}

	public Date getHomeLeaveFromDate() {
		return homeLeaveFromDate;
	}

	public void setHomeLeaveFromDate(Date homeLeaveFromDate) {
		this.homeLeaveFromDate = homeLeaveFromDate;
	}

	public Date getHomeLeaveToDt() {
		return homeLeaveToDt;
	}

	public void setHomeLeaveToDt(Date homeLeaveToDt) {
		this.homeLeaveToDt = homeLeaveToDt;
	}

	public String getHomeLeaveReason() {
		return homeLeaveReason;
	}

	public void setHomeLeaveReason(String homeLeaveReason) {
		this.homeLeaveReason = homeLeaveReason;
	}

	public String getReconsiderCase() {
		return reconsiderCase;
	}

	public void setReconsiderCase(String reconsiderCase) {
		this.reconsiderCase = reconsiderCase;
	}

	public String getDeleteInd() {
		return deleteInd;
	}

	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}

	public String getAutoClaimInd() {
		return autoClaimInd;
	}

	public void setAutoClaimInd(String autoClaimInd) {
		this.autoClaimInd = autoClaimInd;
	}

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public String getAssessorCode() {
		return assessorCode;
	}

	public void setAssessorCode(String assessorCode) {
		this.assessorCode = assessorCode;
	}

	public String getApprovalCode() {
		return approvalCode;
	}

	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	public String getPaymentInd() {
		return paymentInd;
	}

	public void setPaymentInd(String paymentInd) {
		this.paymentInd = paymentInd;
	}

	public String getHealthCardInd() {
		return healthCardInd;
	}

	public void setHealthCardInd(String healthCardInd) {
		this.healthCardInd = healthCardInd;
	}

	public String getCareCardInd() {
		return careCardInd;
	}

	public void setCareCardInd(String careCardInd) {
		this.careCardInd = careCardInd;
	}

	public String getOneCardInd() {
		return oneCardInd;
	}

	public void setOneCardInd(String oneCardInd) {
		this.oneCardInd = oneCardInd;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public Date getClaimStatusDt() {
		return claimStatusDt;
	}

	public void setClaimStatusDt(Date claimStatusDt) {
		this.claimStatusDt = claimStatusDt;
	}

	public String getReceiptOfReferral() {
		return receiptOfReferral;
	}

	public void setReceiptOfReferral(String receiptOfReferral) {
		this.receiptOfReferral = receiptOfReferral;
	}

	public String getAppealInd() {
		return appealInd;
	}

	public void setAppealInd(String appealInd) {
		this.appealInd = appealInd;
	}

	public String getEmergencyInd() {
		return emergencyInd;
	}

	public void setEmergencyInd(String emergencyInd) {
		this.emergencyInd = emergencyInd;
	}

	public Integer getDayOfAdmitRoom() {
		return dayOfAdmitRoom;
	}

	public void setDayOfAdmitRoom(Integer dayOfAdmitRoom) {
		this.dayOfAdmitRoom = dayOfAdmitRoom;
	}

	public Integer getDayOfAdmitIcu() {
		return dayOfAdmitIcu;
	}

	public void setDayOfAdmitIcu(Integer dayOfAdmitIcu) {
		this.dayOfAdmitIcu = dayOfAdmitIcu;
	}

	public Integer getDayOfCall() {
		return dayOfCall;
	}

	public void setDayOfCall(Integer dayOfCall) {
		this.dayOfCall = dayOfCall;
	}

	public Integer getTotalDisability() {
		return totalDisability;
	}

	public void setTotalDisability(Integer totalDisability) {
		this.totalDisability = totalDisability;
	}

	public Integer getPartialDisability() {
		return partialDisability;
	}

	public void setPartialDisability(Integer partialDisability) {
		this.partialDisability = partialDisability;
	}

	public Date getDisabilityStartDt() {
		return disabilityStartDt;
	}

	public void setDisabilityStartDt(Date disabilityStartDt) {
		this.disabilityStartDt = disabilityStartDt;
	}

	public Date getDisabilityEndDt() {
		return disabilityEndDt;
	}

	public void setDisabilityEndDt(Date disabilityEndDt) {
		this.disabilityEndDt = disabilityEndDt;
	}

	public String getSurgicalPercentage() {
		return surgicalPercentage;
	}

	public void setSurgicalPercentage(String surgicalPercentage) {
		this.surgicalPercentage = surgicalPercentage;
	}

	public String getDoubleIndemnity() {
		return doubleIndemnity;
	}

	public void setDoubleIndemnity(String doubleIndemnity) {
		this.doubleIndemnity = doubleIndemnity;
	}

	public String getHomeMedicalInd() {
		return homeMedicalInd;
	}

	public void setHomeMedicalInd(String homeMedicalInd) {
		this.homeMedicalInd = homeMedicalInd;
	}

	public String getHbpType() {
		return hbpType;
	}

	public void setHbpType(String hbpType) {
		this.hbpType = hbpType;
	}

	public String getAttainedAgeInd() {
		return attainedAgeInd;
	}

	public void setAttainedAgeInd(String attainedAgeInd) {
		this.attainedAgeInd = attainedAgeInd;
	}

	public String getAnesthesiaInd() {
		return anesthesiaInd;
	}

	public void setAnesthesiaInd(String anesthesiaInd) {
		this.anesthesiaInd = anesthesiaInd;
	}

	public String getSurgeryInd() {
		return surgeryInd;
	}

	public void setSurgeryInd(String surgeryInd) {
		this.surgeryInd = surgeryInd;
	}

	public String getDiseaseInd() {
		return diseaseInd;
	}

	public void setDiseaseInd(String diseaseInd) {
		this.diseaseInd = diseaseInd;
	}

	public Integer getDayOfAdmitJunior() {
		return dayOfAdmitJunior;
	}

	public void setDayOfAdmitJunior(Integer dayOfAdmitJunior) {
		this.dayOfAdmitJunior = dayOfAdmitJunior;
	}

	public String getMajorAccId() {
		return majorAccId;
	}

	public void setMajorAccId(String majorAccId) {
		this.majorAccId = majorAccId;
	}

	public String getMajorInjuryDetail() {
		return majorInjuryDetail;
	}

	public void setMajorInjuryDetail(String majorInjuryDetail) {
		this.majorInjuryDetail = majorInjuryDetail;
	}

	public String getHbjSurgeryInd() {
		return hbjSurgeryInd;
	}

	public void setHbjSurgeryInd(String hbjSurgeryInd) {
		this.hbjSurgeryInd = hbjSurgeryInd;
	}

	public String getShortFallInd() {
		return shortFallInd;
	}

	public void setShortFallInd(String shortFallInd) {
		this.shortFallInd = shortFallInd;
	}

	public String getOrigCurrency() {
		return origCurrency;
	}

	public void setOrigCurrency(String origCurrency) {
		this.origCurrency = origCurrency;
	}

	public String getConvCurrency() {
		return convCurrency;
	}

	public void setConvCurrency(String convCurrency) {
		this.convCurrency = convCurrency;
	}

	public String getExchangeRateDesc() {
		return exchangeRateDesc;
	}

	public void setExchangeRateDesc(String exchangeRateDesc) {
		this.exchangeRateDesc = exchangeRateDesc;
	}

	public BigDecimal getTotalEstimatedCost() {
		return totalEstimatedCost;
	}

	public void setTotalEstimatedCost(BigDecimal totalEstimatedCost) {
		this.totalEstimatedCost = totalEstimatedCost;
	}

	public BigDecimal getTotalBilledAmt() {
		return totalBilledAmt;
	}

	public void setTotalBilledAmt(BigDecimal totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

	public String getHoldPaymentInd() {
		return holdPaymentInd;
	}

	public void setHoldPaymentInd(String holdPaymentInd) {
		this.holdPaymentInd = holdPaymentInd;
	}

	public Date getHoldPaymentDate() {
		return holdPaymentDate;
	}

	public void setHoldPaymentDate(Date holdPaymentDate) {
		this.holdPaymentDate = holdPaymentDate;
	}

	public String getReleaseHoldPaymentInd() {
		return releaseHoldPaymentInd;
	}

	public void setReleaseHoldPaymentInd(String releaseHoldPaymentInd) {
		this.releaseHoldPaymentInd = releaseHoldPaymentInd;
	}

	public Date getReleaseHoldPaymentDate() {
		return releaseHoldPaymentDate;
	}

	public void setReleaseHoldPaymentDate(Date releaseHoldPaymentDate) {
		this.releaseHoldPaymentDate = releaseHoldPaymentDate;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getInitialPhase() {
		return initialPhase;
	}

	public void setInitialPhase(String initialPhase) {
		this.initialPhase = initialPhase;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public ClaimHistory() {
	}

	public void copy(ClaimHistory that) {
		setClaimId(that.getClaimId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setPreviousClaimNo(that.getPreviousClaimNo());
		setPreviousOccurence(that.getPreviousOccurence());
		setReceivedDate(that.getReceivedDate());
		setPolicyNo(that.getPolicyNo());
		setCompanyId(that.getCompanyId());
		setCertNo(that.getCertNo());
		setMemberId(that.getMemberId());
		setDependentNo(that.getDependentNo());
		setDependentType(that.getDependentType());
		setRelationship(that.getRelationship());
		setVip(that.getVip());
		setClientId(that.getClientId());
		setPartyId(that.getPartyId());
		setMemberLastName(that.getMemberLastName());
		setMemberFirstName(that.getMemberFirstName());
		setLastName(that.getLastName());
		setFirstName(that.getFirstName());
		setGender(that.getGender());
		setDob(that.getDob());
		setNationalId(that.getNationalId());
		setSubOfficeCode(that.getSubOfficeCode());
		setSubOfficeStatus(that.getSubOfficeStatus());
		setPolicyHolder(that.getPolicyHolder());
		setPolicyOwner(that.getPolicyOwner());
		setChannel(that.getChannel());
		setSubmissionType(that.getSubmissionType());
		setPaymentSeq(that.getPaymentSeq());
		setOriginalBillInd(that.getOriginalBillInd());
		setBillNo(that.getBillNo());
		setBillDtFrom(that.getBillDtFrom());
		setBillDtTo(that.getBillDtTo());
		setAgencyCodeServicing(that.getAgencyCodeServicing());
		setAgentCodeServicing(that.getAgentCodeServicing());
		setFastTrackAgency(that.getFastTrackAgency());
		setBrokerCode(that.getBrokerCode());
		setBrokerName(that.getBrokerName());
		setPayeeIsCompanyInd(that.getPayeeIsCompanyInd());
		setPaymentMethod(that.getPaymentMethod());
		setBillingStatus(that.getBillingStatus());
		setBillingDeclineReason(that.getBillingDeclineReason());
		setClassOfBed(that.getClassOfBed());
		setRoomType(that.getRoomType());
		setProviderCode(that.getProviderCode());
		setReferralDoctorCode(that.getReferralDoctorCode());
		setReferralDoctorName(that.getReferralDoctorName());
		setReferralDoctorEmail(that.getReferralDoctorEmail());
		setReferralDoctorPhone(that.getReferralDoctorPhone());
		setReferralDoctorFax(that.getReferralDoctorFax());
		setPrevDoctorName(that.getPrevDoctorName());
		setPrevDoctorEmail(that.getPrevDoctorEmail());
		setPrevDoctorPhone(that.getPrevDoctorPhone());
		setPrevDoctorFax(that.getPrevDoctorFax());
		setFirstConsultationDt(that.getFirstConsultationDt());
		setConsultationDt(that.getConsultationDt());
		setSymptomDate(that.getSymptomDate());
		setPhysicalFinding(that.getPhysicalFinding());
		setChiefComplaint(that.getChiefComplaint());
		setUnderlyingCause(that.getUnderlyingCause());
		setIllnessSpecialCondition(that.getIllnessSpecialCondition());
		setDiagnosisResult(that.getDiagnosisResult());
		setProvisionalDiagnosis(that.getProvisionalDiagnosis());
		setConditionRequiredTreatment(that.getConditionRequiredTreatment());
		setPresentIllness(that.getPresentIllness());
		setTemperature(that.getTemperature());
		setPulse(that.getPulse());
		setRespiratoryRate(that.getRespiratoryRate());
		setSystolic(that.getSystolic());
		setDiastolic(that.getDiastolic());
		setPainScore(that.getPainScore());
		setComaScore(that.getComaScore());
		setWeight(that.getWeight());
		setHeight(that.getHeight());
		setBmi(that.getBmi());
		setPolicyOwnerPartyId(that.getPolicyOwnerPartyId());
		setAccidentDt(that.getAccidentDt());
		setAccidentPlace(that.getAccidentPlace());
		setLevelOfConsciousness(that.getLevelOfConsciousness());
		setCauseOfInjury(that.getCauseOfInjury());
		setInjuryType(that.getInjuryType());
		setEstimatedTimeOfDiscovery(that.getEstimatedTimeOfDiscovery());
		setEstimatedMonthOfDiscovery(that.getEstimatedMonthOfDiscovery());
		setPrevTreatmentDate(that.getPrevTreatmentDate());
		setTreatmentDate(that.getTreatmentDate());
		setTreatmentType(that.getTreatmentType());
		setCauseOfTreatment(that.getCauseOfTreatment());
		setHospitalizationDate(that.getHospitalizationDate());
		setHospitalizationReason(that.getHospitalizationReason());
		setDischargeDate(that.getDischargeDate());
		setLengthOfStay(that.getLengthOfStay());
		setIcuAdmissionDate(that.getIcuAdmissionDate());
		setIcuDischargeDate(that.getIcuDischargeDate());
		setIcuLengthOfStay(that.getIcuLengthOfStay());
		setIcuReason(that.getIcuReason());
		setOtherInsurer(that.getOtherInsurer());
		setHomeLeaveFromDate(that.getHomeLeaveFromDate());
		setHomeLeaveToDt(that.getHomeLeaveToDt());
		setHomeLeaveReason(that.getHomeLeaveReason());
		setReconsiderCase(that.getReconsiderCase());
		setDeleteInd(that.getDeleteInd());
		setAutoClaimInd(that.getAutoClaimInd());
		setCptCode(that.getCptCode());
		setAssessorCode(that.getAssessorCode());
		setApprovalCode(that.getApprovalCode());
		setPaymentInd(that.getPaymentInd());
		setHealthCardInd(that.getHealthCardInd());
		setCareCardInd(that.getCareCardInd());
		setOneCardInd(that.getOneCardInd());
		setClaimStatus(that.getClaimStatus());
		setProcessStatus(that.getProcessStatus());
		setClaimStatusDt(that.getClaimStatusDt());
		setReceiptOfReferral(that.getReceiptOfReferral());
		setAppealInd(that.getAppealInd());
		setEmergencyInd(that.getEmergencyInd());
		setDayOfAdmitRoom(that.getDayOfAdmitRoom());
		setDayOfAdmitIcu(that.getDayOfAdmitIcu());
		setTotalDisability(that.getTotalDisability());
		setPartialDisability(that.getPartialDisability());
		setSurgicalPercentage(that.getSurgicalPercentage());
		setDoubleIndemnity(that.getDoubleIndemnity());
		setHomeMedicalInd(that.getHomeMedicalInd());
		setHbpType(that.getHbpType());
		setAttainedAgeInd(that.getAttainedAgeInd());
		setAnesthesiaInd(that.getAnesthesiaInd());
		setSurgeryInd(that.getSurgeryInd());
		setDiseaseInd(that.getDiseaseInd());
		setDayOfAdmitJunior(that.getDayOfAdmitJunior());
		setMajorAccId(that.getMajorAccId());
		setMajorInjuryDetail(that.getMajorInjuryDetail());
		setOrigCurrency(that.getOrigCurrency());
		setAgencyOfficeCodeServicing(that.getAgencyOfficeCodeServicing());
		setExchangeRateDesc(that.getExchangeRateDesc());
		setTotalEstimatedCost(that.getTotalEstimatedCost());
		setTotalBilledAmt(that.getTotalBilledAmt());
		setHoldPaymentInd(that.getHoldPaymentInd());
		setHoldPaymentDate(that.getHoldPaymentDate());
		setReleaseHoldPaymentInd(that.getReleaseHoldPaymentInd());
		setReleaseHoldPaymentDate(that.getReleaseHoldPaymentDate());
		setPhase(that.getPhase());
		setCaseId(that.getCaseId());
		setBatchNo(that.getBatchNo());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setIcd10Code(that.getIcd10Code());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimId=[").append(claimId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("previousClaimNo=[").append(previousClaimNo).append("] ");
		buffer.append("previousOccurrence=[").append(previousOccurence).append("] ");
		buffer.append("receivedDate=[").append(receivedDate).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("certNo=[").append(certNo).append("] ");
		buffer.append("memberId=[").append(memberId).append("] ");
		buffer.append("dependentNo=[").append(dependentNo).append("] ");
		buffer.append("dependentType=[").append(dependentType).append("] ");
		buffer.append("relationship=[").append(relationship).append("] ");
		buffer.append("vip=[").append(vip).append("] ");
		buffer.append("clientId=[").append(clientId).append("] ");
		buffer.append("partyId=[").append(partyId).append("] ");
		buffer.append("policyOwnerPartyId=[").append(policyOwnerPartyId).append("] ");
		buffer.append("lastName=[").append(lastName).append("] ");
		buffer.append("firstName=[").append(firstName).append("] ");
		buffer.append("gender=[").append(gender).append("] ");
		buffer.append("dob=[").append(dob).append("] ");
		buffer.append("nationalId=[").append(nationalId).append("] ");
		buffer.append("subOfficeCode=[").append(subOfficeCode).append("] ");
		buffer.append("subOfficeStatus=[").append(subOfficeStatus).append("] ");
		buffer.append("policyHolder=[").append(policyHolder).append("] ");
		buffer.append("policyOwner=[").append(policyOwner).append("] ");
		buffer.append("channel=[").append(channel).append("] ");
		buffer.append("submissionType=[").append(submissionType).append("] ");
		buffer.append("paymentSeq=[").append(paymentSeq).append("] ");
		buffer.append("originalBillInd=[").append(originalBillInd).append("] ");
		buffer.append("billNo=[").append(billNo).append("] ");
		buffer.append("billDtFrom=[").append(billDtFrom).append("] ");
		buffer.append("billDtTo=[").append(billDtTo).append("] ");
		buffer.append("agencyCodeServicing=[").append(agencyCodeServicing).append("] ");
		buffer.append("agentCodeServicing=[").append(agentCodeServicing).append("] ");
		buffer.append("fastTrackAgency=[").append(fastTrackAgency).append("] ");
		buffer.append("brokerCode=[").append(brokerCode).append("] ");
		buffer.append("brokerName=[").append(brokerName).append("] ");
		buffer.append("payeeIsCompanyInd=[").append(payeeIsCompanyInd).append("] ");
		buffer.append("paymentMethod=[").append(paymentMethod).append("] ");
		buffer.append("billingStatus=[").append(billingStatus).append("] ");
		buffer.append("billingDeclineReason=[").append(billingDeclineReason).append("] ");
		buffer.append("classOfBed=[").append(classOfBed).append("] ");
		buffer.append("roomType=[").append(roomType).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("referralDoctorCode=[").append(referralDoctorCode).append("] ");
		buffer.append("referralDoctorName=[").append(referralDoctorName).append("] ");
		buffer.append("referralDoctorEmail=[").append(referralDoctorEmail).append("] ");
		buffer.append("referralDoctorPhone=[").append(referralDoctorPhone).append("] ");
		buffer.append("referralDoctorFax=[").append(referralDoctorFax).append("] ");
		buffer.append("prevDoctorName=[").append(prevDoctorName).append("] ");
		buffer.append("prevDoctorEmail=[").append(prevDoctorEmail).append("] ");
		buffer.append("prevDoctorPhone=[").append(prevDoctorPhone).append("] ");
		buffer.append("prevDoctorFax=[").append(prevDoctorFax).append("] ");
		buffer.append("firstConsultationDt=[").append(firstConsultationDt).append("] ");
		buffer.append("consultationDt=[").append(consultationDt).append("] ");
		buffer.append("symptomDate=[").append(symptomDate).append("] ");
		buffer.append("physicalFinding=[").append(physicalFinding).append("] ");
		buffer.append("chiefComplaint=[").append(chiefComplaint).append("] ");
		buffer.append("underlyingCause=[").append(underlyingCause).append("] ");
		buffer.append("illnessSpecialCondition=[").append(illnessSpecialCondition).append("] ");
		buffer.append("diagnosisResult=[").append(diagnosisResult).append("] ");
		buffer.append("provisionalDiagnosis=[").append(provisionalDiagnosis).append("] ");
		buffer.append("conditionRequiredTreatment=[").append(conditionRequiredTreatment).append("] ");
		buffer.append("presentIllness=[").append(presentIllness).append("] ");
		buffer.append("temperature=[").append(temperature).append("] ");
		buffer.append("pulse=[").append(pulse).append("] ");
		buffer.append("respiratoryRate=[").append(respiratoryRate).append("] ");
		buffer.append("systolic=[").append(systolic).append("] ");
		buffer.append("diastolic=[").append(diastolic).append("] ");
		buffer.append("painScore=[").append(painScore).append("] ");
		buffer.append("comaScore=[").append(comaScore).append("] ");
		buffer.append("weight=[").append(weight).append("] ");
		buffer.append("height=[").append(height).append("] ");
		buffer.append("bmi=[").append(bmi).append("] ");
		buffer.append("accidentDt=[").append(accidentDt).append("] ");
		buffer.append("accidentPlace=[").append(accidentPlace).append("] ");
		buffer.append("levelOfConsciousness=[").append(levelOfConsciousness).append("] ");
		buffer.append("causeOfInjury=[").append(causeOfInjury).append("] ");
		buffer.append("injuryType=[").append(injuryType).append("] ");
		buffer.append("estimatedMonthOfDiscovery=[").append(estimatedMonthOfDiscovery).append("] ");
		buffer.append("estimatedTimeOfDiscovery=[").append(estimatedTimeOfDiscovery).append("] ");
		buffer.append("prevTreatmentDate=[").append(prevTreatmentDate).append("] ");
		buffer.append("treatmentDate=[").append(treatmentDate).append("] ");
		buffer.append("treatmentType=[").append(treatmentType).append("] ");
		buffer.append("causeOfTreatment=[").append(causeOfTreatment).append("] ");
		buffer.append("hospitalizationDate=[").append(hospitalizationDate).append("] ");
		buffer.append("hospitalizationReason=[").append(hospitalizationReason).append("] ");
		buffer.append("dischargeDate=[").append(dischargeDate).append("] ");
		buffer.append("lengthOfStay=[").append(lengthOfStay).append("] ");
		buffer.append("icuAdmissionDate=[").append(icuAdmissionDate).append("] ");
		buffer.append("icuDischargeDate=[").append(icuDischargeDate).append("] ");
		buffer.append("icuLengthOfStay=[").append(icuLengthOfStay).append("] ");
		buffer.append("icuReason=[").append(icuReason).append("] ");
		buffer.append("otherInsurer=[").append(otherInsurer).append("] ");
		buffer.append("homeLeaveFromDate=[").append(homeLeaveFromDate).append("] ");
		buffer.append("homeLeaveToDt=[").append(homeLeaveToDt).append("] ");
		buffer.append("homeLeaveReason=[").append(homeLeaveReason).append("] ");
		buffer.append("reconsiderCase=[").append(reconsiderCase).append("] ");
		buffer.append("deleteInd=[").append(deleteInd).append("] ");
		buffer.append("autoClaimInd=[").append(autoClaimInd).append("] ");
		buffer.append("cptCode=[").append(cptCode).append("] ");
		buffer.append("assessorCode=[").append(assessorCode).append("] ");
		buffer.append("paymentInd=[").append(paymentInd).append("] ");
		buffer.append("healthCardInd=[").append(healthCardInd).append("] ");
		buffer.append("careCardInd=[").append(careCardInd).append("] ");
		buffer.append("oneCardInd=[").append(oneCardInd).append("] ");
		buffer.append("claimStatus=[").append(claimStatus).append("] ");
		buffer.append("processStatus=[").append(processStatus).append("] ");
		buffer.append("claimStatusDt=[").append(claimStatusDt).append("] ");
		buffer.append("receiptOfReferral=[").append(receiptOfReferral).append("] ");
		buffer.append("appealInd=[").append(appealInd).append("] ");
		buffer.append("emergencyInd=[").append(emergencyInd).append("] ");
		buffer.append("dayOfAdmitRoom=[").append(dayOfAdmitRoom).append("] ");
		buffer.append("dayOfAdmitIcu=[").append(dayOfAdmitIcu).append("] ");
		buffer.append("totalDisability=[").append(totalDisability).append("] ");
		buffer.append("partialDisability=[").append(partialDisability).append("] ");
		buffer.append("surgicalPercentage=[").append(surgicalPercentage).append("] ");
		buffer.append("doubleIndemnity=[").append(doubleIndemnity).append("] ");
		buffer.append("homeMedicalInd=[").append(homeMedicalInd).append("] ");
		buffer.append("hbpType=[").append(hbpType).append("] ");
		buffer.append("attainedAgeInd=[").append(attainedAgeInd).append("] ");
		buffer.append("anesthesiaInd=[").append(anesthesiaInd).append("] ");
		buffer.append("surgeryInd=[").append(surgeryInd).append("] ");
		buffer.append("diseaseInd=[").append(diseaseInd).append("] ");
		buffer.append("dayOfAdmitJunior=[").append(dayOfAdmitJunior).append("] ");
		buffer.append("majorAccId=[").append(majorAccId).append("] ");
		buffer.append("majorInjuryDetail=[").append(majorInjuryDetail).append("] ");
		buffer.append("origCurrency=[").append(origCurrency).append("] ");
		buffer.append("agencyOfficeCodeServicing=[").append(agencyOfficeCodeServicing).append("] ");
		buffer.append("exchangeRateDesc=[").append(exchangeRateDesc).append("] ");
		buffer.append("totalEstimatedCost=[").append(totalEstimatedCost).append("] ");
		buffer.append("totalBilledAmt=[").append(totalBilledAmt).append("] ");
		buffer.append("holdPaymentInd=[").append(holdPaymentInd).append("] ");
		buffer.append("holdPaymentDate=[").append(holdPaymentDate).append("] ");
		buffer.append("releaseHoldPaymentInd=[").append(releaseHoldPaymentInd).append("] ");
		buffer.append("releaseHoldPaymentDate=[").append(releaseHoldPaymentDate).append("] ");
		buffer.append("initialPhase=[").append(initialPhase).append("] ");
		buffer.append("phase=[").append(phase).append("] ");
		buffer.append("caseId=[").append(caseId).append("] ");
		buffer.append("batchNo=[").append(batchNo).append("] ");
		buffer.append("icd10Code=[").append(icd10Code).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimId == null) ? 0 : claimId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimHistory))
			return false;
		ClaimHistory equalCheck = (ClaimHistory) obj;
		if ((claimId == null && equalCheck.claimId != null) || (claimId != null && equalCheck.claimId == null))
			return false;
		if (claimId != null && !claimId.equals(equalCheck.claimId))
			return false;
		return true;
	}

}
