
package com.aia.cmic.entity;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.math.BigDecimal;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllExchangeRates", query = "select myExchangeRate from ExchangeRate myExchangeRate"),
		@NamedQuery(name = "findExchangeRateByCurrencyCode", query = "select myExchangeRate from ExchangeRate myExchangeRate where myExchangeRate.currencyCode = ?1"),
		@NamedQuery(name = "findExchangeRateByCurrencyCodeContaining", query = "select myExchangeRate from ExchangeRate myExchangeRate where myExchangeRate.currencyCode like ?1"),
		@NamedQuery(name = "findExchangeRateByExchangerateField", query = "select myExchangeRate from ExchangeRate myExchangeRate where myExchangeRate.exchangeRateField = ?1"),
		@NamedQuery(name = "findExchangeRateByPrimaryKey", query = "select myExchangeRate from ExchangeRate myExchangeRate where myExchangeRate.currencyCode = ?1") })

@Table(name = "EXCHANGERATE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ExchangeRate")

public class ExchangeRate extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "CURRENCYCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@XmlElement
	String currencyCode;
	/**
	 */

	@Column(name = "EXCHANGERATE", scale = 2, precision = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@XmlElement
	BigDecimal exchangeRateField;
	/**
	 */


	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the exchangeRateField
	 */
	public BigDecimal getExchangeRateField() {
		return exchangeRateField;
	}

	/**
	 * @param exchangeRateField the exchangeRateField to set
	 */
	public void setExchangeRateField(BigDecimal exchangeRateField) {
		this.exchangeRateField = exchangeRateField;
	}


	/**
	 */
	public ExchangeRate() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ExchangeRate that) {
		setCurrencyCode(that.getCurrencyCode());
		setExchangeRateField(that.getExchangeRateField());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("currencyCode=[").append(currencyCode).append("] ");
		buffer.append("exchangeRateField=[").append(exchangeRateField).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((currencyCode == null) ? 0 : currencyCode.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ExchangeRate))
			return false;
		ExchangeRate equalCheck = (ExchangeRate) obj;
		if ((currencyCode == null && equalCheck.currencyCode != null) || (currencyCode != null && equalCheck.currencyCode == null))
			return false;
		if (currencyCode != null && !currencyCode.equals(equalCheck.currencyCode))
			return false;
		return true;
	}
}
