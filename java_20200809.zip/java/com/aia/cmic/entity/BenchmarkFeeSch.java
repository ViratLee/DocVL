package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({ @NamedQuery(name = "findBenchmarkFeeSchByPrimaryKey", query = "select myBenchmarkFeeSch from BenchmarkFeeSch myBenchmarkFeeSch where myBenchmarkFeeSch.benchmarkFeeSchId = ?1"),
		@NamedQuery(name = "findBenchmarkFeeSchByServiceCatId", query = "select myBenchmarkFeeSch from BenchmarkFeeSch myBenchmarkFeeSch where myBenchmarkFeeSch.serviceCatId = ?1") })
@Table(name = "BENCHMARKFEESCH")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "BenchmarkFeeSch")
public class BenchmarkFeeSch extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "benchMarkFeeSchSequence")
	@SequenceGenerator(name = "benchMarkFeeSchSequence", sequenceName = "s_benchmarkfeesch")
	@Column(name = "BENCHMARKFEESCHID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long benchmarkFeeSchId;
	/**
	 */

	@Column(name = "ICD10CODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10Code;
	/**
	 */

	@Column(name = "SERVICECATID", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceCatId;
	/**
	 */

	@Column(name = "PROVIDERTYPE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerType;
	/**
	 */

	@Column(name = "COMPANYID", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String companyId;
	/**
	 */

	@Column(name = "LENGTHOFSTAY")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer lengthOfStay;
	/**
	 */

	@Column(name = "PERBENCHMARKFEE", scale = 2, precision = 12, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal perBenchmarkFee;
	/**
	 */

	@Column(name = "PERUPPERLIMIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal perUpperLimit;
	/**
	 */

	@Column(name = "EPISODEBENCHMARKFEE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal episodeBenchmarkFee;
	/**
	 */

	@Column(name = "EPISODEUPPERLIMIT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal episodeUpperLimit;

	/**
	 */

	/**
	 * @return the benchmarkFeeSchId
	 */
	public Long getBenchmarkFeeSchId() {
		return benchmarkFeeSchId;
	}

	/**
	 * @param benchmarkFeeSchId the benchmarkFeeSchId to set
	 */
	public void setBenchmarkFeeSchId(Long benchmarkFeeSchId) {
		this.benchmarkFeeSchId = benchmarkFeeSchId;
	}

	/**
	 * @return the icd10Code
	 */
	public String getIcd10Code() {
		return icd10Code;
	}

	/**
	 * @param icd10Code the icd10Code to set
	 */
	public void setIcd10Code(String icd10Code) {
		this.icd10Code = icd10Code;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return this.serviceCatId;
	}

	/**
	 * @return the providerType
	 */
	public String getProviderType() {
		return providerType;
	}

	/**
	 * @param providerType the providerType to set
	 */
	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 * @return the lengthOfStay
	 */
	public Integer getLengthOfStay() {
		return lengthOfStay;
	}

	/**
	 * @param lengthOfStay the lengthOfStay to set
	 */
	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	/**
	 * @return the perBenchmarkFee
	 */
	public BigDecimal getPerBenchmarkFee() {
		return perBenchmarkFee;
	}

	/**
	 * @param perBenchmarkFee the perBenchmarkFee to set
	 */
	public void setPerBenchmarkFee(BigDecimal perBenchmarkFee) {
		this.perBenchmarkFee = perBenchmarkFee;
	}

	/**
	 * @return the perUpperLimit
	 */
	public BigDecimal getPerUpperLimit() {
		return perUpperLimit;
	}

	/**
	 * @param perUpperLimit the perUpperLimit to set
	 */
	public void setPerUpperLimit(BigDecimal perUpperLimit) {
		this.perUpperLimit = perUpperLimit;
	}

	/**
	 * @return the episodeBenchmarkFee
	 */
	public BigDecimal getEpisodeBenchmarkFee() {
		return episodeBenchmarkFee;
	}

	/**
	 * @param episodeBenchmarkFee the episodeBenchmarkFee to set
	 */
	public void setEpisodeBenchmarkFee(BigDecimal episodeBenchmarkFee) {
		this.episodeBenchmarkFee = episodeBenchmarkFee;
	}

	/**
	 * @return the episodeUpperLimit
	 */
	public BigDecimal getEpisodeUpperLimit() {
		return episodeUpperLimit;
	}

	/**
	 * @param episodeUpperLimit the episodeUpperLimit to set
	 */
	public void setEpisodeUpperLimit(BigDecimal episodeUpperLimit) {
		this.episodeUpperLimit = episodeUpperLimit;
	}

	/**
	 */
	public BenchmarkFeeSch() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(BenchmarkFeeSch that) {
		setBenchmarkFeeSchId(that.getBenchmarkFeeSchId());
		setIcd10Code(that.getIcd10Code());
		setServiceCatId(that.getServiceCatId());
		setProviderType(that.getProviderType());
		setCompanyId(that.getCompanyId());
		setLengthOfStay(that.getLengthOfStay());
		setPerBenchmarkFee(that.getPerBenchmarkFee());
		setPerUpperLimit(that.getPerUpperLimit());
		setEpisodeBenchmarkFee(that.getEpisodeBenchmarkFee());
		setEpisodeUpperLimit(that.getEpisodeUpperLimit());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("benchmarkFeeSchId=[").append(benchmarkFeeSchId).append("] ");
		buffer.append("icd10Code=[").append(icd10Code).append("] ");
		buffer.append("serviceCatId=[").append(serviceCatId).append("] ");
		buffer.append("providerType=[").append(providerType).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("lengthOfStay=[").append(lengthOfStay).append("] ");
		buffer.append("perBenchmarkFee=[").append(perBenchmarkFee).append("] ");
		buffer.append("perUpperLimit=[").append(perUpperLimit).append("] ");
		buffer.append("episodeBenchmarkFee=[").append(episodeBenchmarkFee).append("] ");
		buffer.append("episodeUpperLimit=[").append(episodeUpperLimit).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((benchmarkFeeSchId == null) ? 0 : benchmarkFeeSchId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof BenchmarkFeeSch))
			return false;
		BenchmarkFeeSch equalCheck = (BenchmarkFeeSch) obj;
		if ((benchmarkFeeSchId == null && equalCheck.benchmarkFeeSchId != null) || (benchmarkFeeSchId != null && equalCheck.benchmarkFeeSchId == null))
			return false;
		if (benchmarkFeeSchId != null && !benchmarkFeeSchId.equals(equalCheck.benchmarkFeeSchId))
			return false;
		return true;
	}
}
