package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * The persistent class for the RULESUPPLEMENT database table.
 * 
 */
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@Table(name = "RULESUPPLEMENT")
public class Rulesupplement extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "rulesupplementSequence")
	@SequenceGenerator(name = "rulesupplementSequence", sequenceName = "s_rulesupplement")
	@Column(name = "CLAIMSUPPLEMENTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	private String claimsupplementid;
	/**
	 */

	@Column(name = "RULENO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String ruleno;
	/**
	 */

	@Column(name = "CATEGORY", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String category;
	/**
	 */

	@Column(name = "STRVALUE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private String strvalue;
	/**
	 */

	@Column(name = "INTVALUE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private BigDecimal intvalue;
	/**
	 */

	@Column(name = "DATEVALUE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	private Date datevalue;

	public String getClaimsupplementid() {
		return claimsupplementid;
	}

	public void setClaimsupplementid(String claimsupplementid) {
		this.claimsupplementid = claimsupplementid;
	}

	public String getRuleno() {
		return ruleno;
	}

	public void setRuleno(String ruleno) {
		this.ruleno = ruleno;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStrvalue() {
		return strvalue;
	}

	public void setStrvalue(String strvalue) {
		this.strvalue = strvalue;
	}

	public BigDecimal getIntvalue() {
		return intvalue;
	}

	public void setIntvalue(BigDecimal intvalue) {
		this.intvalue = intvalue;
	}

	public Date getDatevalue() {
		return datevalue;
	}

	public void setDatevalue(Date datevalue) {
		this.datevalue = datevalue;
	}

}