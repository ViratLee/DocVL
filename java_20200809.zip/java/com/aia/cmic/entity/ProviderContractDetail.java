package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		//		@NamedQuery(name = "findAllProviderContractDetails", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail"),
		//		@NamedQuery(name = "findProviderContractDetailByAgreedFee", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.agreedFee = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByCapitatedService", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.capitatedService = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByCapitatedServiceContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.capitatedService like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByDiscountInd", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.discountInd = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByDiscountIndContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.discountInd like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByDiscountonListPrice", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.discountOnListPrice = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByIcd10Code", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.icd10Code = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByIcd10CodeContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.icd10Code like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByListPrice", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.listPrice = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByNotPaidInd", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.notPaidInd = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByNotPaidIndContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.notPaidInd like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByPackageName", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.packageName = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByPackageNameContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.packageName like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByPrimaryKey", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.providerContractDetailId = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByProviderContractDetailId", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.providerContractDetailId = ?1"),
		@NamedQuery(name = "findProviderContractDetailByProviderContractId", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.providerContractId = ?1"),
		@NamedQuery(name = "findProviderContractDetailByServiceCatId", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.providerContractId = ?1 and myProviderContractDetail.serviceCatId = ?2"),
		//		@NamedQuery(name = "findProviderContractDetailByServiceCatIdContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.serviceCatId like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByServiceName", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.serviceName = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByServiceNameContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.serviceName like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByTierPricing", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.tierPricing = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByType", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.contractType = ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByTypeContaining", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.contractType like ?1"),
		//		@NamedQuery(name = "findProviderContractDetailByVolumeDiscount", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.volumeDiscount = ?1"),
		@NamedQuery(name = "findProviderContractDetailDisplayOnlyByProviderContractId", query = "select myProviderContractDetail from ProviderContractDetail myProviderContractDetail where myProviderContractDetail.providerContractId = ?1 and myProviderContractDetail.serviceName = ?2 ") })
@Table(name = "PROVIDERCONTRACTDETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderContractDetail")
public class ProviderContractDetail extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "providerContractDetailSequence")
	@SequenceGenerator(name = "providerContractDetailSequence", sequenceName = "s_providercontractdetail")
	@Column(name = "PROVIDERCONTRACTDETAILID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long providerContractDetailId;
	/**
	 */

	@Column(name = "PROVIDERCONTRACTID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long providerContractId;
	/**
	 */

	@Column(name = "CONTRACTTYPE", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String contractType;
	/**
	 */

	@Column(name = "SERVICECATID", length = 20, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceCatId;
	/**
	 */

	@Column(name = "SERVICENAME", length = 60)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String serviceName;
	/**
	 */

	@Column(name = "LISTPRICE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal listPrice;
	/**
	 */

	@Column(name = "DISCOUNTONLISTPRICE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal discountOnListPrice;
	/**
	 */

	@Column(name = "AGREEDFEE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal agreedFee;
	/**
	 */

	@Column(name = "DISCOUNTIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String discountInd;
	/**
	 */

	@Column(name = "NOTPAIDIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String notPaidInd;
	/**
	 */

	@Column(name = "PACKAGENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String packageName;
	/**
	 */

	@Column(name = "ICD10CODE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd10Code;
	/**
	 */

	@Column(name = "ICD9CODE", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String icd9Code;
	/**
	 */

	@Column(name = "PACKAGEPRICE", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal packagePrice;
	/**
	 */

	@Column(name = "VOLUMEDISCOUNT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal volumeDiscount;
	/**
	 */

	@Column(name = "TIERPRICING", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal tierPricing;
	/**
	 */

	@Column(name = "CAPITATEDSERVICE", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String capitatedService;

	@Column(name = "NETWORKID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Long networkId;

	/**
	 * @return the providerContractDetailId
	 */
	public Long getProviderContractDetailId() {
		return providerContractDetailId;
	}

	/**
	 * @param providerContractDetailId the providerContractDetailId to set
	 */
	public void setProviderContractDetailId(Long providerContractDetailId) {
		this.providerContractDetailId = providerContractDetailId;
	}

	/**
	 * @return the providerContractId
	 */
	public Long getProviderContractId() {
		return providerContractId;
	}

	/**
	 * @param providerContractId the providerContractId to set
	 */
	public void setProviderContractId(Long providerContractId) {
		this.providerContractId = providerContractId;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return this.serviceCatId;
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * @return the listPrice
	 */
	public BigDecimal getListPrice() {
		return listPrice;
	}

	/**
	 * @param listPrice the listPrice to set
	 */
	public void setListPrice(BigDecimal listPrice) {
		this.listPrice = listPrice;
	}

	/**
	 * @return the discountOnListPrice
	 */
	public BigDecimal getDiscountOnListPrice() {
		return discountOnListPrice;
	}

	/**
	 * @param discountOnListPrice the discountOnListPrice to set
	 */
	public void setDiscountOnListPrice(BigDecimal discountOnListPrice) {
		this.discountOnListPrice = discountOnListPrice;
	}

	/**
	 * @return the agreedFee
	 */
	public BigDecimal getAgreedFee() {
		return agreedFee;
	}

	/**
	 * @param agreedFee the agreedFee to set
	 */
	public void setAgreedFee(BigDecimal agreedFee) {
		this.agreedFee = agreedFee;
	}

	/**
	 * @return the discountInd
	 */
	public String getDiscountInd() {
		return discountInd;
	}

	/**
	 * @param discountInd the discountInd to set
	 */
	public void setDiscountInd(String discountInd) {
		this.discountInd = discountInd;
	}

	/**
	 * @return the notPaidInd
	 */
	public String getNotPaidInd() {
		return notPaidInd;
	}

	/**
	 * @param notPaidInd the notPaidInd to set
	 */
	public void setNotPaidInd(String notPaidInd) {
		this.notPaidInd = notPaidInd;
	}

	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}

	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/**
	 * @return the icd10Code
	 */
	public String getIcd10Code() {
		return icd10Code;
	}

	/**
	 * @param icd10Code the icd10Code to set
	 */
	public void setIcd10Code(String icd10Code) {
		this.icd10Code = icd10Code;
	}

	public String getIcd9Code() {
		return icd9Code;
	}

	public void setIcd9Code(String icd9Code) {
		this.icd9Code = icd9Code;
	}

	public BigDecimal getPackagePrice() {
		return packagePrice;
	}

	public void setPackagePrice(BigDecimal packagePrice) {
		this.packagePrice = packagePrice;
	}

	/**
	 * @return the volumeDiscount
	 */
	public BigDecimal getVolumeDiscount() {
		return volumeDiscount;
	}

	/**
	 * @param volumeDiscount the volumeDiscount to set
	 */
	public void setVolumeDiscount(BigDecimal volumeDiscount) {
		this.volumeDiscount = volumeDiscount;
	}

	/**
	 * @return the tierPricing
	 */
	public BigDecimal getTierPricing() {
		return tierPricing;
	}

	/**
	 * @param tierPricing the tierPricing to set
	 */
	public void setTierPricing(BigDecimal tierPricing) {
		this.tierPricing = tierPricing;
	}

	/**
	 * @return the capitatedService
	 */
	public String getCapitatedService() {
		return capitatedService;
	}

	/**
	 * @param capitatedService the capitatedService to set
	 */
	public void setCapitatedService(String capitatedService) {
		this.capitatedService = capitatedService;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	/**
	 */
	public ProviderContractDetail() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProviderContractDetail that) {
		setProviderContractDetailId(that.getProviderContractDetailId());
		setProviderContractId(that.getProviderContractId());
		setContractType(that.getContractType());
		setServiceCatId(that.getServiceCatId());
		setServiceName(that.getServiceName());
		setListPrice(that.getListPrice());
		setDiscountOnListPrice(that.getDiscountOnListPrice());
		setAgreedFee(that.getAgreedFee());
		setDiscountInd(that.getDiscountInd());
		setNotPaidInd(that.getNotPaidInd());
		setPackageName(that.getPackageName());
		setIcd10Code(that.getIcd10Code());
		setIcd9Code(that.getIcd9Code());
		setPackagePrice(that.getPackagePrice());
		setVolumeDiscount(that.getVolumeDiscount());
		setTierPricing(that.getTierPricing());
		setCapitatedService(that.getCapitatedService());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
		setNetworkId(that.getNetworkId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {
		StringBuilder buffer = new StringBuilder();

		buffer.append("providerContractDetailId=[").append(providerContractDetailId).append("] ");
		buffer.append("providerContractId=[").append(providerContractId).append("] ");
		buffer.append("contractType=[").append(contractType).append("] ");
		buffer.append("serviceCatId=[").append(serviceCatId).append("] ");
		buffer.append("serviceName=[").append(serviceName).append("] ");
		buffer.append("listPrice=[").append(listPrice).append("] ");
		buffer.append("discountOnListPrice=[").append(discountOnListPrice).append("] ");
		buffer.append("agreedFee=[").append(agreedFee).append("] ");
		buffer.append("discountInd=[").append(discountInd).append("] ");
		buffer.append("notPaidInd=[").append(notPaidInd).append("] ");
		buffer.append("packageName=[").append(packageName).append("] ");
		buffer.append("icd10Code=[").append(icd10Code).append("] ");
		buffer.append("icd9Code=[").append(icd9Code).append("] ");
		buffer.append("packagePrice=[").append(packagePrice).append("] ");
		buffer.append("volumeDiscount=[").append(volumeDiscount).append("] ");
		buffer.append("tierPricing=[").append(tierPricing).append("] ");
		buffer.append("capitatedService=[").append(capitatedService).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");
		buffer.append("networkId=[").append(getNetworkId()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((providerContractDetailId == null) ? 0 : providerContractDetailId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ProviderContractDetail))
			return false;
		ProviderContractDetail equalCheck = (ProviderContractDetail) obj;
		if ((providerContractDetailId == null && equalCheck.providerContractDetailId != null) || (providerContractDetailId != null && equalCheck.providerContractDetailId == null))
			return false;
		if (providerContractDetailId != null && !providerContractDetailId.equals(equalCheck.providerContractDetailId))
			return false;
		return true;
	}
}
