package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
@Entity

//@formatter:off
@NamedQueries({
		@NamedQuery(name = "findClaimDeductDetailByClaimDeductNo", query = "select myClaimDeductDetail from ClaimDeductDetail myClaimDeductDetail where myClaimDeductDetail.claimDeductNo = ?1 "),
		@NamedQuery(name = "findClaimDeductDetailByClaimDeductNoBenefit", query = "select myClaimDeductDetail from ClaimDeductDetail myClaimDeductDetail where myClaimDeductDetail.claimDeductNo in (select myClaimDeduct.claimDeductNo from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?1 and myClaimDeduct.occurrence = ?2 and myClaimDeduct.policyNo = ?3 and myClaimDeduct.submissionSource in ?4 and myClaimDeduct.deductStatus = ?5 ) and myClaimDeductDetail.deductStatus = ?5  and myClaimDeductDetail.benefitCode =?6"),
		@NamedQuery(name = "findClaimDeductDetailByPolicyNo", query = "select myClaimDeductDetail from ClaimDeductDetail myClaimDeductDetail where myClaimDeductDetail.policyNo = ?1 "),
		@NamedQuery(name = "findClaimDeductDetail", query = "select myClaimDeductDetail from ClaimDeductDetail myClaimDeductDetail"),
		@NamedQuery(name = "findAmtDeductByPolicy", query = "select nvl(sum(nvl(deduct.totalDeductAmt,0)),0) from ClaimDeduct deduct where ( (deduct.hospitalizationDate between ?1 and ?2 ) or (deduct.accidentDt between ?1 and ?2)) and deduct.policyNo=?3 and deduct.deductStatus='10' "),
		@NamedQuery(name = "findAmtDeductFromPartneronClaimOccur", query = "select nvl(sum(nvl(deductDetail.approvedAmt,0)),0) from ClaimDeductDetail deductDetail,ClaimDeduct deduct where deductDetail.claimDeductNo=deduct.claimDeductNo and deduct.claimNo=?1 and deduct.occurrence=?2 and deduct.policyNo=?3 and deductDetail.benefitCode in ?6 and deduct.deductStatus=?5 and deduct.submissionSource in ?4"),
		@NamedQuery(name = "findH01DeductDays", query = "select nvl(sum(nvl(deductDetail.noOfDaysAllocated,0)),0) from ClaimDeductDetail deductDetail,ClaimDeduct deduct where deductDetail.claimDeductNo=deduct.claimDeductNo  and deductDetail.policyNo=deduct.policyNo and deduct.policyNo=?1 and deduct.policyYearFromDt=?2 and deduct.policyYearToDt=?3 and deductDetail.benefitCode='H01' and ( (deduct.deductStatus='10') or (deduct.deductStatus='40' and deduct.claimNo=?4 and deduct.occurrence=?5 and deduct.submissionSource in ('OT','CS')) )"),
		@NamedQuery(name = "findH01DeductAmtByPolicy", query = "select nvl(sum(nvl(deductDetail.noOfDaysAllocated,0) * nvl(deductDetail.approvedAmt,0)),0) from ClaimDeductDetail deductDetail,ClaimDeduct deduct where deductDetail.claimDeductNo=deduct.claimDeductNo  and deductDetail.policyNo=deduct.policyNo and deduct.policyNo=?1 and deduct.policyYearFromDt=?2 and deduct.policyYearToDt=?3 and deductDetail.benefitCode=?6 and ( (deduct.deductStatus='10') or (deduct.deductStatus='40' and deduct.claimNo=?4 and deduct.occurrence=?5 and deduct.submissionSource in ('OT','CS') ) ) "),
		@NamedQuery(name = "findDeductAmtByPolicyBenefit", query = "select nvl(sum(nvl(deductDetail.approvedAmt,0)),0) from ClaimDeductDetail deductDetail,ClaimDeduct deduct where deductDetail.claimDeductNo=deduct.claimDeductNo  and deductDetail.policyNo=deduct.policyNo and deduct.policyNo=?1 and deduct.policyYearFromDt=?2 and deduct.policyYearToDt=?3 and deductDetail.benefitCode=?6 and ( (deduct.deductStatus='10') or (deduct.deductStatus='40' and deduct.claimNo=?4 and deduct.occurrence=?5 and deduct.submissionSource in ('OT','CS') ) ) "),		
		@NamedQuery(name = "removeClaimDeductDetailByClaimNoPolicy", query = "delete from ClaimDeductDetail myClaimDeductDetail where myClaimDeductDetail.policyNo=?1 and  myClaimDeductDetail.policyYearFromDt=?2 and myClaimDeductDetail.policyYearToDt=?3 and myClaimDeductDetail.deductStatus <> '10'"),
		@NamedQuery(name = "removeClaimDeductDetailByClaimNoPolicyCD", query = "delete from ClaimDeductDetail myClaimDeductDetail where myClaimDeductDetail.policyNo=?3 and myClaimDeductDetail.claimDeductNo in (select myClaimDeduct.claimDeductNo from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?1 and myClaimDeduct.occurrence = ?2 and myClaimDeduct.submissionSource = 'CD') and myClaimDeductDetail.deductStatus = '40'  "),
		@NamedQuery(name = "removeClaimDeductDetailByClaimNoPolicyDeductNo", query = "delete from ClaimDeductDetail myClaimDeductDetail where myClaimDeductDetail.policyNo=?3 and myClaimDeductDetail.claimDeductNo in (select myClaimDeduct.claimDeductNo from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?1 and myClaimDeduct.occurrence = ?2 and myClaimDeduct.submissionSource = 'CD') and myClaimDeductDetail.claimDeductNo =?4 and myClaimDeductDetail.deductStatus = '40' "),
		@NamedQuery(name = "updateClaimDeductDetailByClaimNoPolicy", query = "update ClaimDeductDetail myClaimDeductDetail set myClaimDeductDetail.deductStatus=?1 where myClaimDeductDetail.claimDeductNo in (select myClaimDeduct.claimDeductNo from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?2 and myClaimDeduct.occurrence = ?3 and myClaimDeduct.submissionSource = 'CD') and myClaimDeductDetail.policyNo=?4 and myClaimDeductDetail.deductStatus = '40' "),//
		@NamedQuery(name = "updateClaimDeductDetailStatusByClaimNoOccurrenceOnSettle", query = "update ClaimDeductDetail myClaimDeductDetail set myClaimDeductDetail.deductStatus = ?1 where myClaimDeductDetail.claimDeductNo in (select myClaimDeduct.claimDeductNo from ClaimDeduct myClaimDeduct where myClaimDeduct.claimNo = ?2 and myClaimDeduct.occurrence = ?3 and myClaimDeduct.submissionSource in ('OT','CS') and myClaimDeduct.deductStatus in ('10','40') ) ")
})
		
//@formatter:on

@Table(name = "CLAIMDEDUCTDETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimDeductDetail")
public class ClaimDeductDetail extends BaseEntity implements Serializable{

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimdeductdetailSequence")
	@SequenceGenerator(name = "claimdeductdetailSequence", sequenceName = "s_claimdeductdetail")
	@Column(name = "CLAIMDEDUCTDETAILID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimDeductDetailId;
	
	@Column(name = "CLAIMDEDUCTNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String claimDeductNo;
	
	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	
	@Column(name = "BENEFITCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String benefitCode;
	
	@Column(name = "NOOFDAYSALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer noOfDaysAllocated;
	
	@Column(name = "NOOFCALLALLOCATED")
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer noOfCallAllocated;
	
	@Column(name = "APPROVEDAMT", scale = 2, precision = 12)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal approvedAmt;
	
	@Column(name = "DEDUCTSTATUS", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String deductStatus;
	
	@Column(name = "POLICYYEARFROMDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearFromDt;
	
	@Column(name = "POLICYYEARTODT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date policyYearToDt;

	public Long getClaimDeductDetailId() {
		return claimDeductDetailId;
	}

	public String getClaimDeductNo() {
		return claimDeductNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public Integer getNoOfDaysAllocated() {
		return noOfDaysAllocated;
	}

	public Integer getNoOfCallAllocated() {
		return noOfCallAllocated;
	}

	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}

	public String getDeductStatus() {
		return deductStatus;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setClaimDeductDetailId(Long claimDeductDetailId) {
		this.claimDeductDetailId = claimDeductDetailId;
	}

	public void setClaimDeductNo(String claimDeductNo) {
		this.claimDeductNo = claimDeductNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	public void setNoOfCallAllocated(Integer noOfCallAllocated) {
		this.noOfCallAllocated = noOfCallAllocated;
	}

	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

	public void setDeductStatus(String deductStatus) {
		this.deductStatus = deductStatus;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimDeductDetail that) {
		setClaimDeductDetailId(that.getClaimDeductDetailId());
		setPolicyNo(that.getPolicyNo());
		setBenefitCode(that.getBenefitCode());
		setNoOfDaysAllocated(that.getNoOfDaysAllocated());
		setNoOfCallAllocated(that.getNoOfCallAllocated());
		setApprovedAmt(that.getApprovedAmt());
		setDeductStatus(that.getDeductStatus());
		setPolicyYearFromDt(that.getPolicyYearFromDt());
		setPolicyYearToDt(that.getPolicyYearToDt());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}
	
	
}
