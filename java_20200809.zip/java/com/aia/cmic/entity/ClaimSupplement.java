package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllClaimSupplements", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement"),
		@NamedQuery(name = "findClaimSupplementByClaimNo", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.claimNo=?1"),
		@NamedQuery(name = "findClaimSupplementByClaimNoOccurence", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.claimNo=?1 and myClaimSupplement.occurrence=?2"),
		@NamedQuery(name = "findClaimSupplementByClaimSupplementId", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.claimSupplementId = ?1"),
		@NamedQuery(name = "findClaimSupplementByClaimSupplementIdContaining", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.claimSupplementId like ?1"),
		@NamedQuery(name = "findClaimSupplementByCodeType", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.codeType = ?1"),
		@NamedQuery(name = "findClaimSupplementByCodeTypeContaining", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.codeType like ?1"),
		@NamedQuery(name = "findClaimSupplementByIntValue", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.intValue = ?1"),
		@NamedQuery(name = "findClaimSupplementByPrimaryKey", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.claimSupplementId = ?1"),
		@NamedQuery(name = "findClaimSupplementByPrimaryInd", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.primaryInd = ?1"),
		@NamedQuery(name = "findClaimSupplementByPrimaryIndContaining", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.primaryInd like ?1"),
		@NamedQuery(name = "findClaimSupplementByStrValue", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.strValue = ?1"),
		@NamedQuery(name = "findClaimSupplementByStrValueContaining", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.strValue like ?1"),
		@NamedQuery(name = "findClaimSupplementByCompanyIdAndClaimNoOccurrenceAndCodeType", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where myClaimSupplement.claimNo=?1 and myClaimSupplement.occurrence=?2 and myClaimSupplement.codeType=?3"),
		@NamedQuery(name = "deleteClaimSupplementByCompanyIdAndClaimNo", query = "delete from ClaimSupplement myClaimSupplement where myClaimSupplement.claimNo=?1"),
		@NamedQuery(name = "deleteClaimSupplementByClaimNoOccurrrencAndCodeType", query = "delete from ClaimSupplement myClaimSupplement where myClaimSupplement.claimNo=?1 and myClaimSupplement.occurrence=?2 and myClaimSupplement.codeType=?3"),
		@NamedQuery(name = "getDiagnosisCodeByCodeTypeAndPrimaryInd", query = "select myClaimSupplement.strValue from ClaimSupplement myClaimSupplement where myClaimSupplement.codeType=?1 and myClaimSupplement.primaryInd=?2"),
		@NamedQuery(name = "checkDiagnosisCodes", query = "select myClaimSupplement from ClaimSupplement myClaimSupplement where  myClaimSupplement.claimNo = ?1 and myClaimSupplement.occurrence=?2 and myClaimSupplement.codeType=?3 and myClaimSupplement.strValue in ?4"), })
@Table(name = "CLAIMSUPPLEMENT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ClaimSupplement")
public class ClaimSupplement extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "claimSupplementSequence")
	@SequenceGenerator(name = "claimSupplementSequence", sequenceName = "s_claimsupplement")
	@Column(name = "CLAIMSUPPLEMENTID", length = 8, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long claimSupplementId;
	/**
	 */

	@Column(name = "CLAIMNO", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String claimNo;
	/**
	 */

	@Column(name = "OCCURRENCE", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer occurrence;
	/**
	 */

	@Column(name = "CODETYPE", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeType;
	/**
	 */

	@Column(name = "STRVALUE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String strValue;
	/**
	 */

	@Column(name = "INTVALUE", scale = 2, precision = 5)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	BigDecimal intValue;
	/**
	 */
	@Column(name = "DATEVALUE")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date dateValue;
	/**
	 */

	@Column(name = "PRIMARYIND", length = 1)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String primaryInd;
	
	@Column(name = "POLICYNO", length = 20)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String policyNo;
	/**
	 */

	/**
	 */

	/**
	 * @return the claimSupplementId
	 */
	public Long getClaimSupplementId() {
		return claimSupplementId;
	}

	/**
	 * @param claimSupplementId the claimSupplementId to set
	 */
	public void setClaimSupplementId(Long claimSupplementId) {
		this.claimSupplementId = claimSupplementId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 * @return the codeType
	 */
	public String getCodeType() {
		return codeType;
	}

	/**
	 * @param codeType the codeType to set
	 */
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	/**
	 * @return the strValue
	 */
	public String getStrValue() {
		return strValue;
	}

	/**
	 * @param strValue the strValue to set
	 */
	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	/**
	 * @return the intValue
	 */
	public BigDecimal getIntValue() {
		return intValue;
	}

	/**
	 * @param intValue the intValue to set
	 */
	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}

	/**
	 * @return dateValue
	 */
	public Date getDateValue() {
		return dateValue;
	}

	/**
	 * 
	 * @param dateValue
	 */
	public void setDateValue(Date dateValue) {
		this.dateValue = dateValue;
	}

	/**
	 * @return the primaryInd
	 */
	public String getPrimaryInd() {
		return primaryInd;
	}

	/**
	 * @param primaryInd the primaryInd to set
	 */
	public void setPrimaryInd(String primaryInd) {
		this.primaryInd = primaryInd;
	}
	
	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public ClaimSupplement() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ClaimSupplement that) {
		setClaimSupplementId(that.getClaimSupplementId());
		setClaimNo(that.getClaimNo());
		setOccurrence(that.getOccurrence());
		setCodeType(that.getCodeType());
		setStrValue(that.getStrValue());
		setIntValue(that.getIntValue());
		setDateValue(that.getDateValue());
		setPrimaryInd(that.getPrimaryInd());
		setPolicyNo(that.getPolicyNo());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("claimSupplementId=[").append(claimSupplementId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("codeType=[").append(codeType).append("] ");
		buffer.append("strValue=[").append(strValue).append("] ");
		buffer.append("intValue=[").append(intValue).append("] ");
		buffer.append("dateValue=[").append(dateValue).append("] ");
		buffer.append("primaryInd=[").append(primaryInd).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((claimSupplementId == null) ? 0 : claimSupplementId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ClaimSupplement))
			return false;
		ClaimSupplement equalCheck = (ClaimSupplement) obj;
		if ((claimSupplementId == null && equalCheck.claimSupplementId != null) || (claimSupplementId != null && equalCheck.claimSupplementId == null))
			return false;
		if (claimSupplementId != null && !claimSupplementId.equals(equalCheck.claimSupplementId))
			return false;
		return true;
	}
}
