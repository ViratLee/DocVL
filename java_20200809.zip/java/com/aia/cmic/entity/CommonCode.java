package com.aia.cmic.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCommonCodes", query = "select myCommonCode from CommonCode myCommonCode"),
		@NamedQuery(name = "findCommonCodeByCategory", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1"),
		@NamedQuery(name = "findCommonCodeByCategoryContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category like ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDesc", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDesc = ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDesc like ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescLong", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDescLong = ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescLongContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDescLong like ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescLongThai", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDescLongThai = ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescLongThaiContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDescLongThai like ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescThai", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDescThai = ?1"),
		@NamedQuery(name = "findCommonCodeByCodeDescThaiContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeDescThai like ?1"),
		@NamedQuery(name = "findCommonCodeByCodeName", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeName = ?1"),
		@NamedQuery(name = "findCommonCodeByCodeNameContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeName like ?1"),
		@NamedQuery(name = "findCommonCodeByCodeValue", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeValue = ?1"),
		@NamedQuery(name = "findCommonCodeByCodeValueContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.codeValue like ?1"),
		@NamedQuery(name = "findCommonCodeByCommonCodeId", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.commonCodeId = ?1"),
		@NamedQuery(name = "findCommonCodeByPrimaryKey", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.commonCodeId = ?1"),
		@NamedQuery(name = "findCommonCodeByFieldContaining", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1 and (myCommonCode.codeName like ?2 or myCommonCode.codeValue like ?3)"),
		@NamedQuery(name = "findRootCommonCode", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1 and myCommonCode.referCommonCodeId is null"),
		@NamedQuery(name = "findChildCommonCode", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.referCommonCodeId = ?1"),
		@NamedQuery(name = "findChildCommonCodeWithOrderBy", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.referCommonCodeId = ?1 order by myCommonCode.codeDesc"),
		@NamedQuery(name = "findCommonCodeByCategoryAndCodeName", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1 and myCommonCode.codeName = ?2 "),
		@NamedQuery(name = "findCommonCodeByCategoryAndCodeNameAndCodeValue", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1 and myCommonCode.codeName = ?2 and myCommonCode.codeValue like ?3 "),
		@NamedQuery(name = "findCommonCodeByCategoryAndCodeNameAndCodeDesc", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1 and myCommonCode.codeName = ?2 and (myCommonCode.codeValue = ?3 or lower(myCommonCode.codeDesc) like ?4 )"),
		@NamedQuery(name = "findCommonCodeByCategoryCodeDescription", query = "select myCommonCode.codeValue from CommonCode myCommonCode where myCommonCode.category = ?1 and upper(substring(myCommonCode.codeDesc,1,3)) =?2"),
		@NamedQuery(name = "findLoggingDebugConfig", query = "select myCommonCode from CommonCode myCommonCode where myCommonCode.category = ?1 and myCommonCode.codeName = ?2 order by myCommonCode.lastModifiedDt desc") })
@Table(name = "COMMONCODE")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "CommonCode")
public class CommonCode extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String REGION_OVERSEA = "\u0e15\u0e48\u0e32\u0e07\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28";

	public static final String CATEGORY_PROVIDER = "Provider";
	public static final String CODENAME_ALPHABET_CODE = "Alphabet";
	public static final String CODENAME_REGION = "Region";

	/**
	 */

	@GeneratedValue(strategy = GenerationType.AUTO, generator = "commonCodeSequence")
	@SequenceGenerator(name = "commonCodeSequence", sequenceName = "s_commoncode")
	@Column(name = "COMMONCODEID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long commonCodeId;
	/**
	 */

	@Column(name = "CATEGORY", length = 30, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String category;
	/**
	 */

	@Column(name = "CODENAME", length = 100, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeName;
	/**
	 */

	@Column(name = "CODEVALUE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeValue;
	/**
	 */

	@Column(name = "CODEDESC", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeDesc;
	/**
	 */

	@Column(name = "CODEDESCTHAI", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeDescThai;
	/**
	 */

	@Column(name = "CODEDESCLONG", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeDescLong;
	/**
	 */

	@Column(name = "CODEDESCLONGTHAI", length = 500)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String codeDescLongThai;

	@Column(name = "REFERCOMMONCODEID", length = 18)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer referCommonCodeId;

	/**
	 */

	/**
	 * @return the commonCodeId
	 */
	public Long getCommonCodeId() {
		return commonCodeId;
	}

	/**
	 * @param commonCodeId the commonCodeId to set
	 */
	public void setCommonCodeId(Long commonCodeId) {
		this.commonCodeId = commonCodeId;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the codeName
	 */
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @param codeName the codeName to set
	 */
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}

	/**
	 * @return the codeValue
	 */
	public String getCodeValue() {
		return codeValue;
	}

	/**
	 * @param codeValue the codeValue to set
	 */
	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}

	/**
	 * @return the codeDesc
	 */
	public String getCodeDesc() {
		return codeDesc;
	}

	/**
	 * @param codeDesc the codeDesc to set
	 */
	public void setCodeDesc(String codeDesc) {
		this.codeDesc = codeDesc;
	}

	/**
	 * @return the codeDescThai
	 */
	public String getCodeDescThai() {
		return codeDescThai;
	}

	/**
	 * @param codeDescThai the codeDescThai to set
	 */
	public void setCodeDescThai(String codeDescThai) {
		this.codeDescThai = codeDescThai;
	}

	/**
	 * @return the codeDescLong
	 */
	public String getCodeDescLong() {
		return codeDescLong;
	}

	/**
	 * @param codeDescLong the codeDescLong to set
	 */
	public void setCodeDescLong(String codeDescLong) {
		this.codeDescLong = codeDescLong;
	}

	/**
	 * @return the codeDescLongThai
	 */
	public String getCodeDescLongThai() {
		return codeDescLongThai;
	}

	/**
	 * @param codeDescLongThai the codeDescLongThai to set
	 */
	public void setCodeDescLongThai(String codeDescLongThai) {
		this.codeDescLongThai = codeDescLongThai;
	}

	public Integer getReferCommonCodeId() {
		return referCommonCodeId;
	}

	public void setReferCommonCodeId(Integer referCommonCodeId) {
		this.referCommonCodeId = referCommonCodeId;
	}

	/**
	 */
	public CommonCode() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(CommonCode that) {
		setCommonCodeId(that.getCommonCodeId());
		setCategory(that.getCategory());
		setCodeName(that.getCodeName());
		setCodeValue(that.getCodeValue());
		setCodeDesc(that.getCodeDesc());
		setCodeDescThai(that.getCodeDescThai());
		setCodeDescLong(that.getCodeDescLong());
		setCodeDescLongThai(that.getCodeDescLongThai());
		setReferCommonCodeId(that.getReferCommonCodeId());
		setCreatedBy(that.getCreatedBy());
		setCreatedDt(that.getCreatedDt());
		setLastModifiedBy(that.getLastModifiedBy());
		setLastModifiedDt(that.getLastModifiedDt());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("commonCodeId=[").append(commonCodeId).append("] ");
		buffer.append("category=[").append(category).append("] ");
		buffer.append("codeName=[").append(codeName).append("] ");
		buffer.append("codeValue=[").append(codeValue).append("] ");
		buffer.append("codeDesc=[").append(codeDesc).append("] ");
		buffer.append("codeDescThai=[").append(codeDescThai).append("] ");
		buffer.append("codeDescLong=[").append(codeDescLong).append("] ");
		buffer.append("codeDescLongThai=[").append(codeDescLongThai).append("] ");
		buffer.append("referCommonCodeId=[").append(referCommonCodeId).append("] ");
		buffer.append("createdBy=[").append(getCreatedBy()).append("] ");
		buffer.append("createdDt=[").append(getCreatedDt()).append("] ");
		buffer.append("lastModifiedBy=[").append(getLastModifiedBy()).append("] ");
		buffer.append("lastModifiedDt=[").append(getLastModifiedDt()).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((commonCodeId == null) ? 0 : commonCodeId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof CommonCode))
			return false;
		CommonCode equalCheck = (CommonCode) obj;
		if ((commonCodeId == null && equalCheck.commonCodeId != null) || (commonCodeId != null && equalCheck.commonCodeId == null))
			return false;
		if (commonCodeId != null && !commonCodeId.equals(equalCheck.commonCodeId))
			return false;
		return true;
	}
}
