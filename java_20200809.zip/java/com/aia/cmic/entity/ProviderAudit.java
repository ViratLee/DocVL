package com.aia.cmic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */
@Entity
@NamedQueries({
		@NamedQuery(name = "getProviderAuditByProviderCode", query = "select providerAudit from ProviderAudit providerAudit where providerAudit.providerCode=?1"),
	 })
@Table(name = "PROVIDER_AUDIT")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "com/aia/cmic/entity", name = "ProviderAudit")
public class ProviderAudit implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "PROVIDERAUDITID", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Long providerAuditId;
	/**
	 */

	@Column(name = "PROVIDERCODE", length = 10, nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String providerCode;
	/**
	 */

	@Column(name = "TABLENAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String tableName;
	/**
	 */

	@Column(name = "COLUMNNAME", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String columnName;
	/**
	 */

	@Column(name = "ACTION", length = 10)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String action;
	/**
	 */

	@Column(name = "VALUEBEFORE", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String valueBefore;
	/**
	 */

	@Column(name = "VALUEAFTER", length = 100)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String valueAfter;

	/**
	 */

	@Column(name = "MODIFIEDDT")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Date modifiedDt;

	
	/**
	 */

	@Column(name = "RECORDID", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String recordId;
	
	/**
	 */

	@Column(name = "USERID", length = 200)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String userId;	

	/**
	 */

	

	/**
	 */
	public ProviderAudit() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(ProviderAudit that) {
		setProviderAuditId(that.getProviderAuditId());
		setProviderCode(that.getProviderCode());
		setTableName(that.getTableName());
		setAction(that.getAction());
		setValueBefore(that.getValueBefore());
		setValueAfter(that.getValueAfter());
		setModifiedDt(that.getModifiedDt());
		setRecordId(that.getRecordId());
		setUserId(that.getUserId());
	}

	public Long getProviderAuditId() {
		return providerAuditId;
	}

	public void setProviderAuditId(Long providerAuditId) {
		this.providerAuditId = providerAuditId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getValueBefore() {
		return valueBefore;
	}

	public void setValueBefore(String valueBefore) {
		this.valueBefore = valueBefore;
	}

	public String getValueAfter() {
		return valueAfter;
	}

	public void setValueAfter(String valueAfter) {
		this.valueAfter = valueAfter;
	}

	public Date getModifiedDt() {
		return modifiedDt;
	}

	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("providerAuditId=[").append(providerAuditId).append("] ");
		buffer.append("providerCode=[").append(providerCode).append("] ");
		buffer.append("tableName=[").append(tableName).append("] ");
		buffer.append("columnName=[").append(columnName).append("] ");
		buffer.append("action=[").append(action).append("] ");
		buffer.append("valueBefore=[").append(valueBefore).append("] ");
		buffer.append("valueAfter=[").append(valueAfter).append("] ");
		buffer.append("modifiedDt=[").append(modifiedDt).append("] ");
		buffer.append("recordId=[").append(recordId).append("] ");
		buffer.append("userId=[").append(userId).append("] ");


		return buffer.toString();
	}


}
