package com.aia.cmic.canonical;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.aia.cmic.model.Claim;
import com.aia.cmic.model.ClaimBenefitItem;
import com.aia.cmic.model.ClaimBrokenBone;
import com.aia.cmic.model.ClaimComment;
import com.aia.cmic.model.ClaimCriticalIllness;
import com.aia.cmic.model.ClaimDiagnosisCode;
import com.aia.cmic.model.ClaimDiagnosisTest;
import com.aia.cmic.model.ClaimInjuryArea;
import com.aia.cmic.model.ClaimPayment;
import com.aia.cmic.model.ClaimPhysician;
import com.aia.cmic.model.ClaimPlannedMedication;
import com.aia.cmic.model.ClaimPlannedSurgery;
import com.aia.cmic.model.ClaimPolicyAccountNo;
import com.aia.cmic.model.ClaimProcedureCode;
import com.aia.cmic.model.ClaimReferral;
import com.aia.cmic.model.ClaimRequirementInfo;
import com.aia.cmic.model.ClaimSpecialist;
import com.aia.cmic.model.DataPrivacyPolicy;
import com.aia.cmic.model.EdiData;

/**
 * Contains canonical information for specific claim
 * @author Ronald
 *
 */

public class ClaimCanonical {

	Claim claim;
	List<ClaimInjuryArea> injuryAreas = new ArrayList<>();
	List<ClaimDiagnosisTest> diagnosisTests = new ArrayList<>();
	List<ClaimDiagnosisCode> diagnosisCodes = new ArrayList<>();
	List<ClaimProcedureCode> procedureCodes = new ArrayList<>();
	List<ClaimBrokenBone> brokenBones = new ArrayList<>();
	List<ClaimPhysician> physicians = new ArrayList<>();
	List<ClaimSpecialist> specialists = new ArrayList<>();
	List<ClaimReferral> referrals = new ArrayList<>();
	List<ClaimBenefitItem> benefitItems = new ArrayList<>();
	List<ClaimRequirementInfo> claimRequirementInfos = new ArrayList<>();
	List<ClaimPolicyCanonical> claimPolicies = new ArrayList<>();
	List<ClaimPayment> claimPayments = new ArrayList<>();
	List<ClaimPlannedMedication> claimPlannedMedications = new ArrayList<>();
	List<ClaimPlannedSurgery> claimPlannedSurgerys = new ArrayList<>();
	List<ClaimComment> claimComments = new ArrayList<>();
	List<ClaimPolicyAccountNo> claimPolicyAccountNos = new ArrayList<>();
	List<ClaimCriticalIllness> claimCriticalIllnesss = new ArrayList<>();
	List<DataPrivacyPolicy> dataPrivacyPolicyList = new ArrayList<>();
	EdiData ediData = null;

	public ClaimCanonical() {
		this.claim = new Claim();

	}

	/**
	 * @return the claim
	 */
	public Claim getClaim() {
		return claim;
	}

	/**
	 * @param claim the claim to set
	 */
	public void setClaim(Claim claim) {
		this.claim = claim;
	}

	/**
	 * @return the injuries
	 */
	public List<ClaimInjuryArea> getInjuryAreas() {
		return injuryAreas;
	}

	/**
	 * @param injuries the injuries to set
	 */
	public void setInjuryAreas(List<ClaimInjuryArea> injuryAreas) {
		this.injuryAreas = injuryAreas;
	}

	/**
	 * @return the diagnosisCodes
	 */
	public List<ClaimDiagnosisCode> getDiagnosisCodes() {
		return diagnosisCodes;
	}

	/**
	 * @param diagnosisCodes the diagnosisCodes to set
	 */
	public void setDiagnosisCodes(List<ClaimDiagnosisCode> diagnosisCodes) {
		this.diagnosisCodes = diagnosisCodes;
	}

	/**
	 * @return the diagnosisTests
	 */
	public List<ClaimDiagnosisTest> getDiagnosisTests() {
		return diagnosisTests;
	}

	/**
	 * @param diagnosisTests the diagnosisTests to set
	 */
	public void setDiagnosisTests(List<ClaimDiagnosisTest> diagnosisTests) {
		this.diagnosisTests = diagnosisTests;
	}

	/**
	 * @return the procedureCodes
	 */
	public List<ClaimProcedureCode> getProcedureCodes() {
		return procedureCodes;
	}

	/**
	 * @param procedureCodes the procedureCodes to set
	 */
	public void setProcedureCodes(List<ClaimProcedureCode> procedureCodes) {
		this.procedureCodes = procedureCodes;
	}

	/**
	 * @return the brokenBones
	 */
	public List<ClaimBrokenBone> getBrokenBones() {
		return brokenBones;
	}

	/**
	 * @param brokenBones the brokenBones to set
	 */
	public void setBrokenBones(List<ClaimBrokenBone> brokenBones) {
		this.brokenBones = brokenBones;
	}

	/**
	 * @return the physicians
	 */
	public List<ClaimPhysician> getPhysicians() {
		return physicians;
	}

	/**
	 * @param physicians the physicians to set
	 */
	public void setPhysicians(List<ClaimPhysician> physicians) {
		this.physicians = physicians;
	}

	/**
	 * @return the specialists
	 */
	public List<ClaimSpecialist> getSpecialists() {
		return specialists;
	}

	/**
	 * @param specialists the specialists to set
	 */
	public void setSpecialists(List<ClaimSpecialist> specialists) {
		this.specialists = specialists;
	}

	public List<ClaimReferral> getReferrals() {
		return referrals;
	}

	public void setReferrals(List<ClaimReferral> referrals) {
		this.referrals = referrals;
	}

	/**
	 * @return the benefitItems
	 */
	public List<ClaimBenefitItem> getBenefitItems() {
		return benefitItems;
	}

	/**
	 * @param benefitItems the benefitItems to set
	 */
	public void setBenefitItems(List<ClaimBenefitItem> benefitItems) {
		this.benefitItems = benefitItems;
	}

	/**
	 * @return the claimRequirementInfo
	 */
	public List<ClaimRequirementInfo> getClaimRequirementInfo() {
		return claimRequirementInfos;
	}

	/**
	 * @param claimRequirementInfo
	 *            the claimRequirementInfo to set
	 */
	public void setClaimRequirementInfo(List<ClaimRequirementInfo> claimRequirementInfos) {
		this.claimRequirementInfos = claimRequirementInfos;
	}

	/**
	 * @return the claimPolicies
	 */
	public List<ClaimPolicyCanonical> getClaimPolicies() {
		return claimPolicies;
	}

	/**
	 * @param claimPolicies the claimPolicies to set
	 */
	public void setClaimPolicies(List<ClaimPolicyCanonical> claimPolicies) {
		this.claimPolicies = claimPolicies;
	}

	/**
	 * @return the claimPayments
	 */
	public List<ClaimPayment> getClaimPayments() {
		return claimPayments;
	}

	/**
	 * @param claimPayments the claimPayments to set
	 */
	public void setClaimPayments(List<ClaimPayment> claimPayments) {
		this.claimPayments = claimPayments;
	}

	public List<ClaimPlannedMedication> getClaimPlannedMedications() {
		return claimPlannedMedications;
	}

	public void setClaimPlannedMedications(List<ClaimPlannedMedication> claimPlannedMedications) {
		this.claimPlannedMedications = claimPlannedMedications;
	}

	public List<ClaimPlannedSurgery> getClaimPlannedSurgerys() {
		return claimPlannedSurgerys;
	}

	public void setClaimPlannedSurgerys(List<ClaimPlannedSurgery> claimPlannedSurgerys) {
		this.claimPlannedSurgerys = claimPlannedSurgerys;
	}

	public List<ClaimComment> getClaimComments() {
		return claimComments;
	}

	public void setClaimComments(List<ClaimComment> claimComments) {
		this.claimComments = claimComments;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public List<ClaimPolicyAccountNo> getClaimPolicyAccountNos() {
		return claimPolicyAccountNos;
	}

	public void setClaimPolicyAccountNos(List<ClaimPolicyAccountNo> claimPolicyAccountNos) {
		this.claimPolicyAccountNos = claimPolicyAccountNos;
	}

	public EdiData getEdiData() {
		return ediData;
	}

	public void setEdiData(EdiData ediData) {
		this.ediData = ediData;
	}

	public List<ClaimCriticalIllness> getClaimCriticalIllnesss() {
		return claimCriticalIllnesss;
	}

	public void setClaimCriticalIllnesss(List<ClaimCriticalIllness> claimCriticalIllnesss) {
		this.claimCriticalIllnesss = claimCriticalIllnesss;
	}

	public List<ClaimRequirementInfo> getClaimRequirementInfos() {
		return claimRequirementInfos;
	}

	public void setClaimRequirementInfos(List<ClaimRequirementInfo> claimRequirementInfos) {
		this.claimRequirementInfos = claimRequirementInfos;
	}

	public List<DataPrivacyPolicy> getDataPrivacyPolicyList() {
		return dataPrivacyPolicyList;
	}

	public void setDataPrivacyPolicyList(List<DataPrivacyPolicy> dataPrivacyPolicyList) {
		this.dataPrivacyPolicyList = dataPrivacyPolicyList;
	}
}
