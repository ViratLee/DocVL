package com.aia.cmic.canonical;

import java.util.ArrayList;
import java.util.List;

import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.Insured;
import com.aia.cmic.model.Payee;

public class ClaimPolicyCanonical {

	ClaimPolicy claimPolicy;
	Insured insured;
	Payee payee;
	Payee providerPayee;
	Payee payeeOrganization;
	List<ClaimPolicyPlanCanonical> claimPolicyPlans = new ArrayList<ClaimPolicyPlanCanonical>();

	/**
	 * @return the claimPolicy
	 */
	public ClaimPolicy getClaimPolicy() {
		return claimPolicy;
	}

	/**
	 * @param claimPolicy
	 *            the claimPolicy to set
	 */
	public void setClaimPolicy(ClaimPolicy claimPolicy) {
		this.claimPolicy = claimPolicy;
	}

	/**
	 * @return the insured
	 */
	public Insured getInsured() {
		return insured;
	}

	/**
	 * @param insured
	 *            the insured to set
	 */
	public void setInsured(Insured insured) {
		this.insured = insured;
	}

	/**
	 * 
	 * @return
	 */
	public Payee getPayee() {
		return payee;
	}

	/**
	 * 
	 * @param payee
	 */
	public void setPayee(Payee payee) {
		this.payee = payee;
	}

	public Payee getProviderPayee() {
		return providerPayee;
	}

	public void setProviderPayee(Payee providerPayee) {
		this.providerPayee = providerPayee;
	}

	public Payee getPayeeOrganization() {
		return payeeOrganization;
	}

	public void setPayeeOrganization(Payee payeeOrganization) {
		this.payeeOrganization = payeeOrganization;
	}

	/**
	 * @return the claimPolicyPlans
	 */
	public List<ClaimPolicyPlanCanonical> getClaimPolicyPlans() {
		return claimPolicyPlans;
	}

	/**
	 * @param claimPolicyPlans
	 *            the claimPolicyPlans to set
	 */
	public void setClaimPolicyPlans(List<ClaimPolicyPlanCanonical> claimPolicyPlans) {
		this.claimPolicyPlans = claimPolicyPlans;
	}

}
