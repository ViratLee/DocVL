package com.aia.cmic.canonical;

import java.util.Comparator;

import org.apache.commons.lang.builder.CompareToBuilder;

public class ClaimPaymentBenefitComparator implements Comparator<ClaimPaymentBenefit> {

	@Override
	public int compare(ClaimPaymentBenefit o1, ClaimPaymentBenefit o2) {
		return new CompareToBuilder().append(o1.getPolicyNo(), o2.getPolicyNo()).append(o1.getPolicyIssueDt(), o2.getPolicyIssueDt()).append(o1.getPlanIssueDt(), o2.getPlanIssueDt()).toComparison();
	}

}
