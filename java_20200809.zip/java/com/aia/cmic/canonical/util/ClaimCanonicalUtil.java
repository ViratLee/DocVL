package com.aia.cmic.canonical.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.ClaimPolicyCanonical;
import com.aia.cmic.canonical.ClaimPolicyPlanCanonical;
import com.aia.cmic.entity.ClaimPaymentDetail;
import com.aia.cmic.entity.CycleDate;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.Product;
import com.aia.cmic.entity.StandardBilling;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.model.Claim;
import com.aia.cmic.model.ClaimBenefitItem;
import com.aia.cmic.model.ClaimBrokenBone;
import com.aia.cmic.model.ClaimDiagnosisCode;
import com.aia.cmic.model.ClaimDiagnosisTest;
import com.aia.cmic.model.ClaimInjuryArea;
import com.aia.cmic.model.ClaimPayment;
import com.aia.cmic.model.ClaimPhysician;
import com.aia.cmic.model.ClaimPlannedMedication;
import com.aia.cmic.model.ClaimPlannedSurgery;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyCoverage;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.ClaimProcedureCode;
import com.aia.cmic.model.ClaimReferral;
import com.aia.cmic.model.ClaimSpecialist;
import com.aia.cmic.model.HSReduced;
import com.aia.cmic.model.HSXReduced;
import com.aia.cmic.model.Insured;
import com.aia.cmic.model.Payee;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.ClaimPolicyPlanRepository;
import com.aia.cmic.repository.CycleDateRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.repository.ProductRepository;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.BusinessLine;
import com.aia.cmic.util.ClaimCalculationEnum.CodeType;
import com.aia.cmic.util.ClaimCalculationEnum.Eligibility;
import com.aia.cmic.util.ClaimCalculationEnum.HSXBenefitDeductSequence;
import com.aia.cmic.util.ClaimCalculationEnum.IPD_HNWDeductSequence;
import com.aia.cmic.util.ClaimCalculationEnum.OPD_HNWDeductSequence;
import com.aia.cmic.util.ClaimCalculationEnum.PayeeType;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;
import com.aia.cmic.util.FormatUtil;

public class ClaimCanonicalUtil {

	private static Logger LOG = LoggerFactory.getLogger(ClaimCanonicalUtil.class);
	/**
	 * Search for specific ClaimPolicyCoverage for PlanId/benefit Code
	 * 
	 * @param claimId
	 * @param planId
	 * @param policyNo
	 * @param benefitCode
	 * @param claimCanonical
	 * @return
	 */
	public static ClaimPolicyCoverage findClaimPolicyCoverageByClaimIdPolicyNoBenefitCode(Long planId, String policyNo, String benefitCode, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {
				for (com.aia.cmic.model.ClaimPolicyCoverage cpc : cppc.getClaimPolicyCoverages()) {
					if (cpc.getPlanId().equals(planId) && cpc.getPolicyNo().equals(policyNo) && cpc.getBenefitCode().equals(benefitCode)) {
						return cpc;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Search for specific ClaimPolicyPlan
	 * 
	 * @param claimId
	 * @param planId
	 * @param policyNo
	 * @param planCoverageId
	 * @param claimCanonical
	 * @return
	 */
	public static ClaimPolicyPlan findClaimPolicyPlanByClaimNoPolicyNoPlanId(String claimNo, Integer occurence, Long planId, String policyNo, String planCoverageNo, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {

				if (isSameClaimNo(cppc.getClaimPolicyPlan().getClaimNo(), claimNo) && cppc.getClaimPolicyPlan().getOccurrence().equals(occurence) && cppc.getClaimPolicyPlan().getPlanId().equals(planId) && cppc.getClaimPolicyPlan().getPolicyNo().equals(policyNo) && qualifyPlanCoverageNo(cppc.getClaimPolicyPlan().getPlanCoverageNo(), planCoverageNo)) {
					return cppc.getClaimPolicyPlan();
				}
			}
		}
		return null;
	}

	public static ClaimPolicyPlan findClaimPolicyPlanByClaimNoPolicyNoPlanId(String claimNo, Integer occurrence, Long planId, String policyNo, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {

				if (isSameClaimNo(cppc.getClaimPolicyPlan().getClaimNo(), claimNo) && cppc.getClaimPolicyPlan().getOccurrence().equals(occurrence) && cppc.getClaimPolicyPlan().getPlanId().equals(planId) && cppc.getClaimPolicyPlan().getPolicyNo().equals(policyNo)) {
					return cppc.getClaimPolicyPlan();
				}
			}
		}
		return null;
	}

	public static Boolean qualifyPlanCoverageNo(String planCoverageNo1, String planCoverageNo2) {
		if (planCoverageNo1 == null && planCoverageNo2 == null) {
			return true;
		}
		if (planCoverageNo1 != null) {
			return planCoverageNo1.equals(planCoverageNo2);
		}
		if (planCoverageNo2 != null) {
			return planCoverageNo2.equals(planCoverageNo1);
		}
		return false;
	}

	/**
	 * Search for specific Claim Policy
	 * @param claimId
	 * @param policyNo
	 * @param businessLine
	 * @param claimCanonical
	 * @return
	 */

	public static ClaimPolicy findClaimPolicyByClaimNoOccurencePolicyNo(String claimNo, Integer occurenceNo, String policyNo, String businessLine, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			if (claimPolicyCanonical.getClaimPolicy().getBusinessLine().equals(businessLine) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo)) {
				return claimPolicyCanonical.getClaimPolicy();
			}
		}
		return null;
	}

	/**
	 * Search for specific Claim Policy
	 * @param string 
	*/

	public static ClaimPolicy findClaimPolicyByClaimNoPolicyNoCompanyId(String claimNo, Integer occurence, String policyNo, String productCode, String companyId, ClaimCanonical claimCanonical) {
		companyId = FormatUtil.convertNull(companyId);
		productCode = FormatUtil.convertNull(productCode);
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {

			if (isSameClaimNo(claimPolicyCanonical.getClaimPolicy().getClaimNo(), claimNo) && FormatUtil.convertNull(claimPolicyCanonical.getClaimPolicy().getCompanyId()).equals(companyId) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo) && FormatUtil.convertNull(claimPolicyCanonical.getClaimPolicy().getProductCode()).equals(productCode)) {
				return claimPolicyCanonical.getClaimPolicy();
			}
		}
		return null;
	}

	/**
	 * Search for specific Claim Policy
	 * @param string 
	*/

	public static ClaimPolicy findClaimPolicyByClaimNoPolicyNoCompanyId(String claimNo, Integer occurence, String policyNo, String companyId, ClaimCanonical claimCanonical) {
		companyId = FormatUtil.convertNull(companyId);
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {

			if (isSameClaimNo(claimPolicyCanonical.getClaimPolicy().getClaimNo(), claimNo) && FormatUtil.convertNull(claimPolicyCanonical.getClaimPolicy().getCompanyId()).equals(companyId) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo)) {
				return claimPolicyCanonical.getClaimPolicy();
			}
		}
		return null;
	}

	/**
	 * Search for specific Claim Policy By ProductCode
	 * @param string 
	*/

	public static ClaimPolicy findClaimPolicyByClaimNoPolicyNoProductCodeCompanyId(String claimNo, Integer occurence, String policyNo, String companyId, String productCode, ClaimCanonical claimCanonical) {
		companyId = FormatUtil.convertNull(companyId);
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {

			if (isSameClaimNo(claimPolicyCanonical.getClaimPolicy().getClaimNo(), claimNo) && FormatUtil.convertNull(claimPolicyCanonical.getClaimPolicy().getCompanyId()).equals(companyId) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo) && FormatUtil.convertNull(claimPolicyCanonical.getClaimPolicy().getProductCode()).equals(productCode)) {
				return claimPolicyCanonical.getClaimPolicy();
			}
		}
		return null;
	}

	/**
	 * return the claimSupplementId for specific injury/icd10/icd09/etc 
	 * @param value
	 * @param codeType
	 * @param claimCanonical
	 * @return
	 */
	public static Long findClaimSupplement(String value, ClaimCalculationEnum.CodeType codeType, ClaimCanonical claimCanonical) {

		if (CodeType.PROCEDURECODE.equals(codeType)) {
			for (ClaimProcedureCode cpc : claimCanonical.getProcedureCodes()) {
				if (cpc.getStrValue().equals(value)) {
					return cpc.getClaimSupplementId();
				}
			}
		}

		if (CodeType.BROKENBONE.equals(codeType)) {
			for (ClaimBrokenBone cbb : claimCanonical.getBrokenBones()) {
				if (cbb.getStrValue().equals(value)) {
					return cbb.getClaimSupplementId();
				}
			}
		}
		if (CodeType.DIAGNOSISCODE.equals(codeType)) {
			for (ClaimDiagnosisCode cdc : claimCanonical.getDiagnosisCodes()) {
				if (cdc.getStrValue().equals(value)) {
					return cdc.getClaimSupplementId();
				}
			}
		}

		if (CodeType.DIAGNOSISTEST.equals(codeType)) {
			for (ClaimDiagnosisTest cdt : claimCanonical.getDiagnosisTests()) {
				if (cdt.getStrValue().equals(value)) {
					return cdt.getClaimSupplementId();
				}
			}
		}

		if (CodeType.INJURYAREA.equals(codeType)) {
			for (ClaimInjuryArea cia : claimCanonical.getInjuryAreas()) {
				if (cia.getStrValue().equals(value)) {
					return cia.getClaimSupplementId();
				}
			}
		}

		if (CodeType.PHYSICIAN.equals(codeType)) {
			for (ClaimPhysician cp : claimCanonical.getPhysicians()) {
				if (cp.getStrValue().equals(value)) {
					return cp.getClaimSupplementId();
				}
			}
		}

		if (CodeType.SPECIALIST.equals(codeType)) {
			for (ClaimSpecialist cs : claimCanonical.getSpecialists()) {
				if (cs.getStrValue().equals(value)) {
					return cs.getClaimSupplementId();
				}
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T findClaimSupplement(Long claimSupplementId, ClaimCalculationEnum.CodeType codeType, ClaimCanonical claimCanonical) {
		if (CodeType.PROCEDURECODE.equals(codeType)) {
			for (ClaimProcedureCode cpc : claimCanonical.getProcedureCodes()) {
				if (cpc.getClaimSupplementId() != null && cpc.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cpc;
				}
			}
		}

		if (CodeType.BROKENBONE.equals(codeType)) {
			for (ClaimBrokenBone cbb : claimCanonical.getBrokenBones()) {
				if (cbb.getClaimSupplementId() != null && cbb.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cbb;
				}
			}
		}
		if (CodeType.DIAGNOSISCODE.equals(codeType)) {
			for (ClaimDiagnosisCode cdc : claimCanonical.getDiagnosisCodes()) {
				if (cdc.getClaimSupplementId() != null && cdc.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cdc;
				}
			}
		}

		if (CodeType.DIAGNOSISTEST.equals(codeType)) {
			for (ClaimDiagnosisTest cdt : claimCanonical.getDiagnosisTests()) {
				if (cdt.getClaimSupplementId() != null && cdt.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cdt;
				}
			}
		}

		if (CodeType.INJURYAREA.equals(codeType)) {
			for (ClaimInjuryArea cia : claimCanonical.getInjuryAreas()) {
				if (cia.getClaimSupplementId() != null && cia.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cia;
				}
			}
		}

		if (CodeType.PHYSICIAN.equals(codeType)) {
			for (ClaimPhysician cp : claimCanonical.getPhysicians()) {
				if (cp.getClaimSupplementId() != null && cp.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cp;
				}
			}
		}

		if (CodeType.SPECIALIST.equals(codeType)) {
			for (ClaimSpecialist cs : claimCanonical.getSpecialists()) {
				if (cs.getClaimSupplementId() != null && cs.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cs;
				}
			}
		}

		if (CodeType.REFERRAL.equals(codeType)) {
			for (ClaimReferral cr : claimCanonical.getReferrals()) {
				if (cr.getClaimSupplementId() != null && cr.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cr;
				}
			}
		}

		if (CodeType.PLANNEDMEDICATION.equals(codeType)) {
			for (ClaimPlannedMedication cpm : claimCanonical.getClaimPlannedMedications()) {
				if (cpm.getClaimSupplementId() != null && cpm.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cpm;
				}
			}
		}

		if (CodeType.PLANNEDSURGERY.equals(codeType)) {
			for (ClaimPlannedSurgery cps : claimCanonical.getClaimPlannedSurgerys()) {
				if (cps.getClaimSupplementId() != null && cps.getClaimSupplementId().equals(claimSupplementId)) {
					return (T) cps;
				}
			}
		}

		return null;
	}

	/**
	 *  Find ClaimPolicy by PolicyNo
	 * @param policyNo
	 * @param claimCanonical
	 * @return
	 */
	public static ClaimPolicy findClaimPolicyByPolicyNo(String policyNo, ClaimCanonical claimCanonical) {

		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {

			if (claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo)) {
				return claimPolicyCanonical.getClaimPolicy();
			}
		}
		return null;
	}

	/**
	 *  Find ClaimPolicy by PolicyNo and occurrence
	 * @param policyNo
	 * @param occurrence 
	 * @param claimCanonical
	 * @return ClaimPolicy
	 */
	public static ClaimPolicy findClaimPolicyByPolicyNoAndOccurrence(String policyNo, Integer occurrence, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			if (claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo)) {
				if (claimPolicyCanonical.getClaimPolicy().getOccurrence().intValue() == occurrence.intValue()) {
					return claimPolicyCanonical.getClaimPolicy();
				}
			}
		}
		return null;
	}

	public static ClaimPolicyPlan findClaimPolicyPlanWithPolicyNoOccurrencePlanIdPlanCoverageNO(String policyNo, Integer occurrence, Long planId, String planCoverageNo, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			List<ClaimPolicyPlanCanonical> claimPolicyPlans = claimPolicyCanonical.getClaimPolicyPlans();
			for (ClaimPolicyPlanCanonical cpp : claimPolicyPlans) {
				ClaimPolicyPlan claimPolicyPlan = cpp.getClaimPolicyPlan();
				if ((policyNo.equals(claimPolicyPlan.getPolicyNo())) && occurrence.equals(claimPolicyPlan.getOccurrence()) //
						&& (planId.equals(claimPolicyPlan.getPlanId())) && (planCoverageNo.equals(claimPolicyPlan.getPlanCoverageNo()))) {
					return claimPolicyPlan;
				}
			}
		}
		return null;
	}

	/**
	 * 
	 * @param claimNo
	 * @param occurrence
	 * @param policyNo
	 * @param businessLine
	 * @param claimCanonical
	 * @return
	 */
	public static ClaimPolicyCanonical findClaimPolicyCanonicalByClaimNoOccurencePolicyNo(String claimNo, Integer occurrence, String policyNo, String businessLine, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			if (isSameClaimNo(claimPolicyCanonical.getClaimPolicy().getClaimNo(), claimNo) && claimPolicyCanonical.getClaimPolicy().getOccurrence().equals(occurrence) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equals(policyNo) && claimPolicyCanonical.getClaimPolicy().getBusinessLine().equals(businessLine)) {
				return claimPolicyCanonical;
			}
		}

		return null;
	}

	public static Set<ClaimPolicyCanonical> findClaimPolicyCanonicalForPAReduction(String claimNo, Integer occurrence, ClaimCanonical claimCanonical) {
		Set<ClaimPolicyCanonical> uniquePAPolicies = new LinkedHashSet<ClaimPolicyCanonical>();
		for (ClaimPayment payment : claimCanonical.getClaimPayments()) {
			// check eligibility first
			if (Eligibility.ACCEPTED.getEligibility().equals(payment.getEligibility()) || (StringUtils.isEmpty(payment.getEligibility()) && Eligibility.ACCEPTED.getEligibility().equals(payment.getSystemEligibility()))) {
				if (isSameClaimNo(claimNo, payment.getClaimNo()) && occurrence.equals(payment.getOccurrence()) && ProductType.PA.toString().equalsIgnoreCase(payment.getProductType())) {
					for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
						if (isSameClaimNo(claimPolicyCanonical.getClaimPolicy().getClaimNo(), claimNo) && claimPolicyCanonical.getClaimPolicy().getOccurrence().equals(occurrence) && payment.getPolicyNo().equalsIgnoreCase(claimPolicyCanonical.getClaimPolicy().getPolicyNo())) {
							uniquePAPolicies.add(claimPolicyCanonical);
						}
					}
				}
			}
		}

		return uniquePAPolicies;
	}

	/**
	 * Get previous total amount by claimPolicy and payment status
	 * @param claimPolicy
	 * @param claimCanonical
	 * @return
	 */
	public static BigDecimal getPreviousTotalPaymentByClaimPolicyPaymentStatus(ClaimPolicy claimPolicy, ClaimPolicyPlan claimPolicyPlan, String paymentStatus, ClaimCanonical claimCanonical) {

		BigDecimal totalAmt = BigDecimal.ZERO;

		// get total amount in payment
		String claimNo = claimCanonical.getClaim().getClaimNo();
		String policyNo = claimPolicy.getPolicyNo();
		Long planId = claimPolicyPlan.getPlanId();
		String planCoverageNo = claimPolicyPlan.getPlanCoverageNo();
		String companyId = FormatUtil.convertNull(claimPolicy.getCompanyId());
		for (ClaimPayment payment : claimCanonical.getClaimPayments()) {
			if (isSameClaimNo(payment.getClaimNo(), claimNo) && payment.getPolicyNo().equals(policyNo) && payment.getPlanId().equals(planId) && qualifyPlanCoverageNo(payment.getPlanCoverageNo(), planCoverageNo) && payment.getPaymentStatus().equals(paymentStatus) && companyId.equals(FormatUtil.convertNull(payment.getCompanyId()))) {
				totalAmt = totalAmt.add(payment.getEligibleAmt());
			}
		}

		return totalAmt;
	}

	/**
	 * Get all ClaimPolicyCoverages under the same benefitcode,sumCategory
	 * @param claimNo
	 * @param occurence
	 * @param policyNo
	 * @param integer 
	 * @param long1 
	 * @param planId
	 * @param planCoverageNo
	 * @param benefitCode
	 * @param sumCategories
	 * @param claimCanonical
	 * @return
	 */
	public static List<ClaimPolicyCoverage> findClaimPolicyCoverageByBenefitCodeSumCategory(
			String claimNo,
			Integer occurence,
			String policyNo,
			String productCode,
			Long planId,
			String planCoverageNo,
			String benefitCode,
			String[] sumCategories,
			ClaimCanonical claimCanonical) {

		List<ClaimPolicyCoverage> coverages = new ArrayList<ClaimPolicyCoverage>();

		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {
				if (isSameClaimNo(cppc.getClaimPolicyPlan().getClaimNo(), claimNo) && cppc.getClaimPolicyPlan().getOccurrence().equals(occurence) && cppc.getClaimPolicyPlan().getPolicyNo().equals(policyNo) && cppc.getClaimPolicyPlan().getPlanId().equals(planId) && qualifyPlanCoverageNo(cppc.getClaimPolicyPlan().getPlanCoverageNo(), planCoverageNo)) {
					for (ClaimPolicyCoverage policyCoverage : cppc.getClaimPolicyCoverages()) {
						// check benefitcode,productCode,sumcategory
						if (benefitCode.equalsIgnoreCase(policyCoverage.getBenefitCode()) && productCode.equalsIgnoreCase(policyCoverage.getProductCode())
						// use  above condition again  if canonical doesn't filter policycoverage by planId/benefitcode
								&& policyCoverage.getPolicyNo().equals(policyNo) && policyCoverage.getPlanId().equals(planId) && qualifyPlanCoverageNo(policyCoverage.getPlanCoverageNo(), planCoverageNo) && ("Y".equalsIgnoreCase(policyCoverage.getEnableInd()) || StringUtils.isEmpty(policyCoverage.getEnableInd()))) {
							for (String sumCategory : sumCategories) {
								if (sumCategory.equalsIgnoreCase(policyCoverage.getSumCategory())) {
									coverages.add(policyCoverage);
									break;
								}
							}
						}
					}

					// don't loop again 
					if (!CollectionUtils.isEmpty(coverages)) {
						return coverages;
					}
				}
			}
		}

		return coverages;

	}

	/**
	 * Get all matching benefit with same accumulatorNo and sumCategory
	 * @param claimNo
	 * @param occurence
	 * @param accumulatorNo
	 * @param sumCategory
	 * @param claimCanonical
	 * @return
	 */
	public static List<ClaimPolicyCoverage> findClaimPolicyCoverageBySumCategoryAccumulatorNo(
			String claimNo,
			Integer occurence,
			Integer accumulatorNo,
			String sumCategory,
			ClaimCanonical claimCanonical) {

		List<ClaimPolicyCoverage> coverages = new ArrayList<ClaimPolicyCoverage>();

		Map<String, String> duplicateMap = new HashMap<String, String>();
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {

			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {
				if (isSameClaimNo(cppc.getClaimPolicyPlan().getClaimNo(), claimNo) && cppc.getClaimPolicyPlan().getOccurrence().equals(occurence)) {
					for (ClaimPolicyCoverage policyCoverage : cppc.getClaimPolicyCoverages()) {
						String key = FormatUtil.keyGen(claimNo, occurence, policyCoverage.getPolicyNo(), policyCoverage.getPlanId(), policyCoverage.getProductCode(), policyCoverage.getBenefitCode(), policyCoverage.getSumCategory(), policyCoverage.getSumTimeFrame(),
								policyCoverage.getAccumulatorNo());
						if (duplicateMap.containsKey(key)) {
							continue;
						}
						duplicateMap.put(key, key);
						if (accumulatorNo.equals(policyCoverage.getAccumulatorNo()) && sumCategory.equals(policyCoverage.getSumCategory())) {
							coverages.add(policyCoverage);
						}
					}
				}
				// don't loop again 
				if (!CollectionUtils.isEmpty(coverages)) {
					return coverages;
				}
			}
		}

		return coverages;
	}

	//	public static List<ClaimPolicyCoverage> filterClaimPolicyCoverageForHistorical(List<PaymentAllocationTemp> allocationTempList , List<ClaimPolicyCoverage> coverages) {
	//		List<ClaimPolicyCoverage> filteredCoverages = new ArrayList<ClaimPolicyCoverage>();
	//
	//		for(ClaimPolicyCoverage cpc: coverages) {
	//			
	//			for()
	//			
	//		}
	//		
	//		
	//		return filteredCoverages ;
	//	}

	/**
	 * Find Eligible BenefitCode for calculation
	 * @param claimNo
	 * @param occurence
	 * @param policyNo
	 * @param productCode
	 * @param planId
	 * @param planCoverageNo
	 * @param benefitCode
	 * @param claimCanonical
	 * @return
	 */
	public static List<ClaimPolicyCoverage> findClaimPolicyCoverageByBenefitCodeEnableInd(
			String claimNo,
			Integer occurence,
			String policyNo,
			String productCode,
			Long planId,
			String planCoverageNo,
			String benefitCode,
			ClaimCanonical claimCanonical,
			Boolean enableIndFlagCheck) {

		List<ClaimPolicyCoverage> coverages = new ArrayList<ClaimPolicyCoverage>();

		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {
				if (isSameClaimNo(cppc.getClaimPolicyPlan().getClaimNo(), claimNo) && cppc.getClaimPolicyPlan().getOccurrence().equals(occurence) && cppc.getClaimPolicyPlan().getPolicyNo().equals(policyNo) && cppc.getClaimPolicyPlan().getPlanId().equals(planId) && qualifyPlanCoverageNo(cppc.getClaimPolicyPlan().getPlanCoverageNo(), planCoverageNo)) {
					for (ClaimPolicyCoverage policyCoverage : cppc.getClaimPolicyCoverages()) {
						// check benefitcode,productCode,sumcategory
						if (benefitCode.equalsIgnoreCase(policyCoverage.getBenefitCode()) && productCode.equalsIgnoreCase(policyCoverage.getProductCode())
						// use  above condition again  if canonical doesn't filter policycoverage by planId/benefitcode
								&& policyCoverage.getPolicyNo().equals(policyNo) && policyCoverage.getPlanId().equals(planId) && qualifyPlanCoverageNo(policyCoverage.getPlanCoverageNo(), planCoverageNo)) {
							if (enableIndFlagCheck) {
								if ("Y".equalsIgnoreCase(policyCoverage.getEnableInd()) || StringUtils.isEmpty(policyCoverage.getEnableInd())) {
									coverages.add(policyCoverage);
									break;
								} else {
									continue;
								}
							}
							coverages.add(policyCoverage);
							break;
						}
					}
					// don't loop again 
					if (!CollectionUtils.isEmpty(coverages)) {
						return coverages;
					}
				}
			}
		}

		return coverages;
	}

	/**
	 * Get Insured object from supplied policyNo
	 * @param claimNo
	 * @param occurence
	 * @param policyNo
	 * @param claimCanonical
	 * @return
	 */

	public static Insured findInsuredByPolicyNo(String claimNo, Integer occurence, String policyNo, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			Insured insured = claimPolicyCanonical.getInsured();
			if (isSameClaimNo(claimNo, insured.getClaimNo()) && occurence.equals(insured.getOccurrence()) && policyNo.equalsIgnoreCase(insured.getPolicyNo())) {
				return insured;
			}
		}
		return null;
	}

	/**
	 * Get list of ClaimPayment from provided parameters
	 * @param claimNo
	 * @param occurrence
	 * @param policyNo
	 * @param companyId
	 * @param claimCanonical
	 * @return
	 */
	public static List<ClaimPayment> findClaimPaymentByPolicyNoCompanyId(String claimNo, Integer occurrence, String policyNo, String companyId, ClaimCanonical claimCanonical) {
		List<ClaimPayment> claimPaymentList = new ArrayList<ClaimPayment>();
		for (ClaimPayment claimPayment : claimCanonical.getClaimPayments()) {
			if (isSameClaimNo(claimNo, claimPayment.getClaimNo()) && occurrence.equals(claimPayment.getOccurrence()) && policyNo.equals(claimPayment.getPolicyNo()) && FormatUtil.convertNull(companyId).equals(FormatUtil.convertNull(claimPayment.getCompanyId()))) {
				claimPaymentList.add(claimPayment);
			}

		}
		return claimPaymentList;
	}

	public static ClaimPolicyPlan findClaimPolicyPlanByPolicyNoPlanIdPlanCoverageNo(String policyNo, Long planId, String planCoverageNo, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical cpc : claimCanonical.getClaimPolicies()) {
			List<ClaimPolicyPlanCanonical> cppcs = cpc.getClaimPolicyPlans();
			for (ClaimPolicyPlanCanonical cppc : cppcs) {
				ClaimPolicyPlan cpp = cppc.getClaimPolicyPlan();
				if (cpp.getPolicyNo().equalsIgnoreCase(policyNo) //
						&& cpp.getPlanId().equals(planId) //
						&& qualifyPlanCoverageNo(cpp.getPlanCoverageNo(), planCoverageNo)) {
					return cpp;
				}
			}
		}
		return null;
	}

	/**
	 * this is just method of mock data.
	 * 
	 * @param policyNo
	 * @param planId
	 * @param coverageNo
	 * @param sysEligibility
	 * @param eligibility
	 * @param declineReason
	 * @param eligibilityAmt
	 * @param payee
	 * @param coPaymentPercent
	 * @param adjustedAmt
	 * @param adjustedReason
	 * @param suppressChequeInd
	 * @param allocatedAmt
	 * @return
	 */
	public static ClaimPayment buildCliamPlayment(
			String claimNo,
			String policyNo,
			Long planId,
			String coverageNo,
			String sysEligibility,
			String eligibility,
			String declineReason,
			int eligibilityAmt,
			String payee,
			Integer coPaymentPercent,
			Integer adjustedAmt,
			String adjustedReason,
			String suppressChequeInd,
			Integer allocatedAmt,
			Long claimPaymentId) {

		ClaimPayment claimPayment = new ClaimPayment();
		claimPayment.setClaimPaymentId(claimPaymentId);
		//  
		claimPayment.setPolicyNo(policyNo);
		claimPayment.setPlanId(planId);
		claimPayment.setPlanCoverageNo(coverageNo);
		//
		claimPayment.setEligibility(eligibility);
		claimPayment.setDeclineCode(declineReason);
		//eligibility
		claimPayment.setPayeeType(payee);
		claimPayment.setCoPaymentPercent(new BigDecimal(Integer.toString(coPaymentPercent)));
		claimPayment.setAdjustedAmt(new BigDecimal(Integer.toString(adjustedAmt)));
		claimPayment.setSystemEligibility(sysEligibility);
		claimPayment.setEligibleAmt(new BigDecimal(Integer.toString(eligibilityAmt)));
		claimPayment.setAdjustedReason(adjustedReason);
		claimPayment.setSuppressChequeInd(suppressChequeInd);
		claimPayment.setAllocatedAmt(new BigDecimal(Integer.toString(allocatedAmt)));
		claimPayment.setClaimNo(claimNo);

		return claimPayment;
	}

	/**
	 * this is just method of mock data.
	 * 
	 * @param claimNo
	 * @param policyNo
	 * @param planId
	 * @param planCoverageNo
	 * @param paPackageName
	 * @param sumAssured
	 * @return
	 */
	public static ClaimPolicyPlan mockClaimPolicyPlan(
			String claimNo,
			String policyNo,
			Long planId,
			String planStatus,
			String planCoverageNo,
			String paPackageName,
			Integer sumAssured,
			Date planIssueDt,
			Date planPaidUpDt,
			Date planExpiryDt) {
		ClaimPolicyPlan cpp = new ClaimPolicyPlan();
		cpp.setClaimNo(claimNo);
		cpp.setPolicyNo(policyNo);
		cpp.setPlanId(planId);
		cpp.setPlanStatus(planStatus);
		cpp.setPlanCoverageNo(planCoverageNo);
		cpp.setPaPackageName(paPackageName);
		cpp.setSumAssured(new BigDecimal(Integer.toString(sumAssured)));
		cpp.setPlanPaidUpDt(planPaidUpDt);
		cpp.setPlanIssueDt(planIssueDt);
		cpp.setPlanExpiryDt(planExpiryDt);
		return cpp;
	}

	/**
	 * this is just method of mock data.
	 * 
	 * @param claimNo
	 * @param policyNo
	 * @param exclusion
	 * @param impairmentCode
	 * @return
	 */
	public static ClaimPolicy mockClaimPolicy(
			String claimNo,
			String policyNo,
			String policyStatus,
			String exclusion1,
			String exclusion2,
			String exclusion3,
			String impairmentCode1,
			String impairmentCode2,
			String impairmentCode3,
			Date contractDt,
			String holdClaimInd,
			String policyHolder,
			String fullCreditInd,
			Date reinstatementDt,
			Date paidToDt,
			Date paCoverDt,
			Date paidDt,
			String paymentMode,
			String businessLine,
			String productType,
			BigDecimal modalPremium) {
		ClaimPolicy cp = new ClaimPolicy();
		cp.setClaimNo(claimNo);
		cp.setPolicyNo(policyNo);
		cp.setPolicyStatus(policyStatus);
		cp.setContractDt(contractDt);
		cp.setExclusion1(exclusion1);
		cp.setExclusion2(exclusion2);
		cp.setExclusion3(exclusion3);
		cp.setImpairmentCode1(impairmentCode1);
		cp.setImpairmentCode2(impairmentCode2);
		cp.setImpairmentCode3(impairmentCode3);
		cp.setHoldClaimInd(holdClaimInd);
		cp.setFullCreditInd(fullCreditInd);
		cp.setPolicyHolder(policyHolder);
		cp.setReinstatementDt(reinstatementDt);
		cp.setPaidToDt(paidToDt);
		cp.setPaCoverDt(paCoverDt);
		cp.setPaidDt(paidDt);
		cp.setPaymentMode(paymentMode);
		cp.setBusinessLine(businessLine);
		cp.setProductType(productType);
		cp.setModalPremium(modalPremium);
		return cp;
	}

	/**
	 *  Get the first Payee matching the provided parameters
	 * @param claimNo
	 * @param occurrence
	 * @param policyNo
	 * @param payeeType
	 * @param claimCanonical
	 * @return
	 */
	public static Payee findPayeeByPolicyNoPayeeType(String claimNo, Integer occurrence, String policyNo, String payeeType, ClaimCanonical claimCanonical) {

		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			Payee payee = claimPolicyCanonical.getPayee();
			ClaimPolicy claimPolicy = claimPolicyCanonical.getClaimPolicy();
			if (payee != null && claimPolicy != null) {
				if (isSameClaimNo(claimNo, claimCanonical.getClaim().getClaimNo()) && occurrence.equals(claimCanonical.getClaim().getOccurrence()) && policyNo.equals(claimPolicy.getPolicyNo()) && FormatUtil.convertNull(payeeType).equals(FormatUtil.convertNull(payee.getPayeeType()))) {
					return payee;
				}
			}
		}
		return null;
	}

	/**
	 * Get ClaimPayment 
	 * @param companyId
	 * @param claimNo
	 * @param occurrence
	 * @param policyNo
	 * @param productCode
	 * @param planId
	 * @param planCoverageNo
	 * @param claimCanonical
	 */
	public static ClaimPayment findDistinctClaimPayment(String companyId, String claimNo, Integer occurrence, String policyNo, Long planId, String planCoverageNo, ClaimCanonical claimCanonical) {

		// 2017/11/13 : checking Eligibility field before returning ClaimPayment
		companyId = FormatUtil.convertNull(companyId);
		for (ClaimPayment claimPayment : claimCanonical.getClaimPayments()) {
			if (companyId.equalsIgnoreCase(FormatUtil.convertNull(claimPayment.getCompanyId())) && isSameClaimNo(claimNo, claimPayment.getClaimNo()) && occurrence.equals(claimPayment.getOccurrence()) && policyNo.equalsIgnoreCase(claimPayment.getPolicyNo()) && planId.equals(claimPayment.getPlanId()) && qualifyPlanCoverageNo(planCoverageNo, claimPayment
					.getPlanCoverageNo()) && (ClaimCalculationEnum.Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getEligibility()) || (StringUtils.isEmpty(claimPayment.getEligibility()) && ClaimCalculationEnum.Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getSystemEligibility())))) {
				return claimPayment;
			}

		}

		return null;
	}

	public static void checkCanonicalStructures(ClaimCanonical claimCanonical, Logger logger) throws ClaimPaymentValidationException {
		/**
		 * Format : Claim - ClaimId,ClaimNo,Occurrence,PolicyNo,CompanyId,LengthOfStay,symptomDt,accidentDt,consultationDt,CertNo,MemberId,DependentNo,hospitalizationDt,diseaseInd,ProviderCode,estimatedCost
					ClaimPolicy - ClaimPolicyId,ClaimNo,Occurrence,PolicyNo,BusinessLine, paBonusAmt,paBonusDt,PolicyIssueDt,policyYearFromDt,policyYearToDt,paBonusDeductAmt,PlanBasicSumAssured,ProductCode,FullCreditInd
					ClaimPolicyPlan - ClaimPolicyPlanId,ClaimNo,Occurrence,PolicyNo,PlanId,PlanCoverageNo,planIssueDate,ValuePerUnit,NosOfUnit,RateAge
		 *   		ClaimPolicyPlanCoverage - ClaimPolicyCoverageId,ClaimNo,Occurrence,PolicyNo,PlanId,PlanCoverageNo,BenefitCode,sumCategory,accumulatorNo,BenefitAmt,sumTimeFrame,sumProRateInd,effectiveDt,benefitUnit,ProductCode
		 * 			ClaimBenefitItem -	claimNo,occurrence,serviceCatId,companyId,presentedAmt,presentedDiscountAmt,presentedPercentage,noOfDaysPresented,noOfUnit,valuePerUnit;
		 * 			ClaimDiagnosisTest-	codeType,strValue,intValue;
		 * 			ClaimProcedureCode - codeType,strValue,intValue;
		 * 			Insured - insuredId,claimNo,occurrence,policyNo,InitialEffectiveDt
		 * 		    Payee - claimNo,occurence,policyNo,payeeType,firstName,lastName,bankAccountNo
		 * 			ClaimPayment - id,ClaimNo,Occurrence,PolicyNo,CompanyId,ProductCode,PlanId,PlanCoverageNo,ProductType,PayeeType
		 * 
		 */

		Claim claim = claimCanonical.getClaim();

		if (claim == null) {
			throw new ClaimPaymentValidationException("Claim not found. Please check Canonical.");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("------------------------------------");
			logger.debug("CLAIMCANONICAL Struture : ");
			logger.debug("------------------------------------");

			logger.debug("// Claim - ClaimId,ClaimNo,Occurrence,PolicyNo,CompanyId,LengthOfStay,symptomDt,accidentDt,consultationDt,CertNo,MemberId,DependentNo,hospitalizationDt,diseaseInd,ProviderCode,estimatedCost");
			logger.debug("Claim|{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}", claim.getClaimId(), claim.getClaimNo(), claim.getOccurrence(), claim.getPolicyNo(), claim.getCompanyId(),
					claim.getLengthOfStay(), FormatUtil.formatDate(claim.getSymptomDate()), FormatUtil.formatDate(claim.getAccidentDt()), FormatUtil.formatDate(claim.getConsultationDt()),
					claim.getCertNo(), claim.getMemberId(), claim.getDependentNo(), FormatUtil.formatDate(claim.getHospitalizationDate()), claim.getDiseaseInd(), claim.getProviderCode(),
					claim.getTotalEstimatedCost());

			printClaimPayment(claimCanonical.getClaimPayments(), logger);
		}
		if (claimCanonical.getClaimPolicies() == null || claimCanonical.getClaimPolicies().isEmpty()) {
			throw new ClaimPaymentValidationException("ClaimPolicy not found.Please check Canonical.");
		}

		Boolean printOnce = true;
		Map<String, Boolean> printOnceMap = new HashMap<String, Boolean>();
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			ClaimPolicy claimPolicy = claimPolicyCanonical.getClaimPolicy();
			if (claimPolicy == null) {
				throw new ClaimPaymentValidationException("ClaimPolicy not found.Please check Canonical.");
			}
			if (logger.isDebugEnabled()) {
				if (!printOnceMap.containsKey(claimPolicy.getPolicyNo())) {
					logger.debug("// ClaimPolicy - ClaimPolicyId,ClaimNo,Occurrence,PolicyNo,BusinessLine, paBonusAmt,paBonusDt,PolicyIssueDt,policyYearFromDt,policyYearToDt,paBonusDeductAmt,PlanBasicSumAssured,ProductCode,FullCreditInd");
					logger.debug("ClaimPolicy|{},{},{},{},{},{},{},{},{},{},{},{},{},{}", claimPolicy.getClaimPolicyId(), claimPolicy.getClaimNo(), claimPolicy.getOccurrence(),
							claimPolicy.getPolicyNo(), claimPolicy.getBusinessLine(), claimPolicy.getPaBonusAmt(), FormatUtil.formatDate(claimPolicy.getPaBonusDt()),
							FormatUtil.formatDate(claimPolicy.getPolicyIssueDt()), FormatUtil.formatDate(claimPolicy.getPolicyYearFromDt()), FormatUtil.formatDate(claimPolicy.getPolicyYearToDt()),
							claimPolicy.getPaBonusDeductAmt(), claimPolicy.getPlanBasicSumAssured(), claimPolicy.getProductCode(), claimPolicy.getFullCreditInd());
				}
			}

			// Diagnostics
			List<ClaimDiagnosisCode> claimdiagnosticsCode = claimCanonical.getDiagnosisCodes();
			if (CollectionUtils.isEmpty(claimdiagnosticsCode)) {
				throw new ClaimPaymentValidationException("No Diagnosis Code found.");
			}

			if (logger.isDebugEnabled()) {
				if (!printOnceMap.containsKey(claimPolicy.getPolicyNo())) {

					logger.debug("// ClaimDiagnosisCode-	codeType,strValue,intValue;");
					for (ClaimDiagnosisCode diagnosisCodes : claimdiagnosticsCode) {
						logger.debug("ClaimDiagnosisCode|{},{},{}", diagnosisCodes.getCodeType(), diagnosisCodes.getStrValue(), diagnosisCodes.getIntValue());

					}
				}
			}
			/** Procedure Code is now optional */
			/*
			// Procedure Code
			List<ClaimProcedureCode> claimProcedureCodes = claimCanonical.getProcedureCodes();
			if (CollectionUtils.isEmpty(claimProcedureCodes)) {
				throw new ClaimPaymentValidationException("No Procedure Code found..");
			}
			if (logger.isDebugEnabled()) {
				logger.debug("//ClaimProcedureCode - codeType,strValue,intValue;");
				for (ClaimProcedureCode procedureCode : claimProcedureCodes) {
			
					logger.debug("ClaimProcedureCode|{},{},{}", procedureCode.getCodeType(), procedureCode.getStrValue(), procedureCode.getIntValue());
				}
			}
			*/

			// Benefit Item
			List<ClaimBenefitItem> benefitItems = claimCanonical.getBenefitItems();
			if (!CollectionUtils.isEmpty(benefitItems)) {
				//				throw new ClaimPaymentValidationException("No Claim Benefit Item found.");
				//			}

				if (logger.isDebugEnabled()) {
					if (printOnce) {
						logger.debug("// ClaimBenefitItem -	claimNo,occurrence,serviceCatId,companyId,presentedAmt,presentedDiscountAmt,presentedPercentage,noOfDaysPresented,noOfUnit,valuePerUnit;");
						for (ClaimBenefitItem benefitItem : benefitItems) {
							logger.debug("ClaimBenefitItem|{},{},{},{},{},{},{},{},{},{}", benefitItem.getClaimNo(), benefitItem.getOccurrence(), benefitItem.getServiceCatId(),
									benefitItem.getCompanyId(), benefitItem.getPresentedAmt(), benefitItem.getPresentedDiscountAmt(), benefitItem.getPresentedPercentage(),
									benefitItem.getNoOfDaysPresented(), benefitItem.getNoOfUnit(), benefitItem.getValuePerUnit());

						}
						printOnce = Boolean.FALSE;
					}
				}
			}
			/* ClaimPolicyPlan is optional for some benefit code eg. H13,H14,H15 */
			//			if (claimPolicyCanonical.getClaimPolicyPlans() == null || claimPolicyCanonical.getClaimPolicyPlans().isEmpty()) {
			//				throw new Exception("ClaimPolicyPlan not found. Please check Canonical.");
			//			}
			for (ClaimPolicyPlanCanonical policyPlanCanonical : claimPolicyCanonical.getClaimPolicyPlans()) {
				// ClaimPolicyPlan

				ClaimPolicyPlan claimPolicyPlan = policyPlanCanonical.getClaimPolicyPlan();
				/* ClaimPolicyPlan is optional for some benefit code eg. H13,H14,H15 */

				//				if (claimPolicyPlan == null) {
				//					throw new Exception("ClaimPolicyPlan not found. Please check Canonical.");
				//				}

				if (claimPolicyPlan != null && logger.isDebugEnabled()) {
					if (!printOnceMap.containsKey(claimPolicy.getPolicyNo())) {

						logger.debug("// ClaimPolicyPlan - ClaimPolicyPlanId,ClaimNo,Occurrence,PolicyNo,PlanId,PlanCoverageNo,planIssueDate,ValuePerUnit,NosOfUnit,RateAge");
						logger.debug("ClaimPolicyPlan|{},{},{},{},{},{},{},{},{},{}", claimPolicyPlan.getClaimPolicyPlanId(), claimPolicyPlan.getClaimNo(), claimPolicyPlan.getOccurrence(),
								claimPolicyPlan.getPolicyNo(), claimPolicyPlan.getPlanId(), claimPolicyPlan.getPlanCoverageNo(), FormatUtil.formatDate(claimPolicyPlan.getPlanIssueDt()),
								claimPolicyPlan.getValuePerUnit(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getRateAge());
					}
				}
			}

			printOnceMap.put(claimPolicy.getPolicyNo(), Boolean.TRUE);
		}

	}

	public static void checkCanonicalStructureForCS(ClaimCanonical claimCanonical, Logger logger) throws ClaimPaymentValidationException {

		Map<String, Boolean> printOnceMap = new HashMap<String, Boolean>();
		Boolean printOnce = true;
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {

			// Insured

			ClaimPolicy policy = claimPolicyCanonical.getClaimPolicy();
			if (policy != null && BusinessLine.CS.toString().equalsIgnoreCase(policy.getBusinessLine())) {
				Insured insured = claimPolicyCanonical.getInsured();
				if (insured == null) {
					throw new ClaimPaymentValidationException("Insured is required from Canonical.");
				}
				if (logger.isDebugEnabled()) {
					if (printOnce) {
						logger.debug("// Insured - insuredId,claimNo,occurrence,policyNo,InitialEffectiveDt");
						logger.debug("Insured|{},{},{},{},{}", insured.getInsuredId(), insured.getClaimNo(), insured.getOccurrence(), insured.getPolicyNo(),
								(insured.getInitialEffectiveDt() != null ? FormatUtil.formatDate(insured.getInitialEffectiveDt()) : ""));
						printOnce = false;
					}
				}
			}

			//
			//			// Payee
			//			Payee payee = claimPolicyCanonical.getPayee();
			//			if (payee == null) {
			//				throw new Exception("Payee is required from Canonical.");
			//			}
			//			if (logger.isDebugEnabled()) {
			//				logger.debug("// Payee - claimNo,occurence,policyNo,payeeType,firstName,lastName,bankAccountNo");
			//				logger.debug("Payee|{},{},{},{},{},{},{}", payee.getClaimNo(), payee.getOccurrence(), payee.getPolicyNo(), payee.getPayeeType(), payee.getFirstName(), payee.getLastName(),
			//						payee.getBankAccountNo());
			//			}

			for (ClaimPolicyPlanCanonical policyPlanCanonical : claimPolicyCanonical.getClaimPolicyPlans()) {
				// ClaimPolicyPlan
				ClaimPolicyPlan claimPolicyPlan = policyPlanCanonical.getClaimPolicyPlan();
				//				if (claimPolicyPlan == null) {
				//					throw new Exception("ClaimPolicyPlan not found. Please check Canonical.");
				//				}
				//if (claimPolicyPlan != null && logger.isDebugEnabled()) {
				//	if(!printOnceMap.containsKey(claimPolicyPlan.getPolicyNo())) {
				//		logger.debug("// ClaimPolicyPlan - ClaimPolicyPlanId,ClaimNo,Occurrence,PolicyNo,PlanId,PlanCoverageNo,planIssueDate,ValuePerUnit,NosOfUnit,RateAge");
				//		logger.debug("ClaimPolicyPlan|{},{},{},{},{},{},{},{},{},{}", claimPolicyPlan.getClaimPolicyPlanId(), claimPolicyPlan.getClaimNo(), claimPolicyPlan.getOccurrence(),
				//				claimPolicyPlan.getPolicyNo(), claimPolicyPlan.getPlanId(), claimPolicyPlan.getPlanCoverageNo(), FormatUtil.formatDate(claimPolicyPlan.getPlanIssueDt()),
				//				claimPolicyPlan.getValuePerUnit(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getRateAge());
				//	}
				//}

				//	ClaimPolicyCoverage
				// Don't do checking for ClaimPolicyCoverage for now - Wittaya - 03/19/18
				//				if (policyPlanCanonical.getClaimPolicyCoverages() == null || policyPlanCanonical.getClaimPolicyCoverages().isEmpty()) {
				//					throw new ClaimPaymentValidationException("ClaimPolicyPlanCoverage not found.Please check Canonical.");
				//				}
				if (logger.isDebugEnabled()) {
					if (!printOnceMap.containsKey(claimPolicyPlan.getPolicyNo())) {

						logger.debug("// ClaimPolicyPlanCoverage - ClaimPolicyCoverageId,ClaimNo,Occurrence,PolicyNo,PlanId,PlanCoverageNo,BenefitCode,sumCategory,accumulatorNo,BenefitAmt,sumTimeFrame,sumProRateInd,effectiveDt,benefitUnit,ProductCode");
						for (ClaimPolicyCoverage policyCoverage : policyPlanCanonical.getClaimPolicyCoverages()) {
							logger.debug("ClaimPolicyPlanCoverage|{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}", policyCoverage.getClaimPolicyCoverageId(), policyCoverage.getClaimNo(),
									policyCoverage.getOccurrence(), policyCoverage.getPolicyNo(), policyCoverage.getPlanId(), policyCoverage.getPlanCoverageNo(), policyCoverage.getBenefitCode(),
									policyCoverage.getSumCategory(), policyCoverage.getAccumulatorNo(), policyCoverage.getBenefitAmount(), policyCoverage.getSumTimeFrame(),
									policyCoverage.getProRateInd(), FormatUtil.formatDate(policyCoverage.getEffectiveDt()), policyCoverage.getBenefitUnit(), policyCoverage.getProductCode());

							if (policyCoverage.getClaimPolicyCoverageId() == 282467) {
								logger.debug("aaaa");
							}
						}

					}
				}

				printOnceMap.put(claimPolicyPlan.getPolicyNo(), Boolean.TRUE);
			}

		}

	}

	public static void printStandardBilling(StandardBilling standardBilling, Logger logger) {
		//		StandardBilling -	companyId,serviceCatId,policyNo, productCode,planId, lengthOfStay, treatmentType,icd10Category,procedureCategory,businessLine,benefitCode,rolloverBenefitCode1,rolloverBenefitCode2,rolloverBenefitCode3,rolloverBenefitCode4,rolloverBenefitCode5		
		logger.debug("StandardBilling -	standardBillingId,companyId,serviceCatId,policyNo, productCode,planId, lengthOfStayCategory, treatmentType,icd10Category,procedureCategory,businessLine,benefitCode,rolloverBenefitCode1,rolloverBenefitCode2,rolloverBenefitCode3,rolloverBenefitCode4,rolloverBenefitCode5");
		logger.debug("StandardBilling|{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}", standardBilling.getStandardBillingId(), standardBilling.getCompanyId(), standardBilling.getServiceCatId(),
				standardBilling.getPolicyNo(), standardBilling.getProductCode(), standardBilling.getPlanId(), standardBilling.getLengthOfStayCategory(), standardBilling.getTreatmentType(),
				standardBilling.getIcd10Category(), standardBilling.getProcedureCategory(), standardBilling.getBusinessLine(), standardBilling.getBenefitCode(),
				standardBilling.getRolloverBenefitCode1(), standardBilling.getRolloverBenefitCode2(), standardBilling.getRolloverBenefitCode3(), standardBilling.getRolloverBenefitCode4(),
				standardBilling.getRolloverBenefitCode5());

	}

	public static void printClaimPayment(List<com.aia.cmic.model.ClaimPayment> claimPayments, Logger logger) {
		//ClaimPayment - id,ClaimNo,Occurrence,PolicyNo,CompanyId,ProductCode,PlanId,PlanCoverageNo,ProductType,PayeeType
		if (CollectionUtils.isNotEmpty(claimPayments)) {
			logger.debug("//ClaimPayment - id,ClaimNo,Occurrence,PolicyNo,CompanyId,ProductCode,PlanId,PlanCoverageNo,ProductType,PayeeType,Eligibility,SystemEligibility,PaymentStatus");
			for (com.aia.cmic.model.ClaimPayment claimPayment : claimPayments) {
				logger.debug("//ClaimPayment - {},{},{},{},{},{},{},{},{},{},{},{}", claimPayment.getClaimPaymentId(), claimPayment.getClaimNo(), claimPayment.getOccurrence(),
						claimPayment.getPolicyNo(), claimPayment.getCompanyId(), claimPayment.getProductCode(), claimPayment.getPlanId(), claimPayment.getPlanCoverageNo(),
						claimPayment.getProductType(), claimPayment.getPayeeType(), claimPayment.getEligibility(), claimPayment.getSystemEligibility(), claimPayment.getPaymentStatus());
			}
		}

	}

	public static com.aia.cmic.entity.ClaimPayment findDistinctClaimPayment(
			String companyId,
			String claimNo,
			Integer occurrence,
			String policyNo,
			Long planId,
			String planCoverageNo,
			List<com.aia.cmic.entity.ClaimPayment> claimPayments) {

		// 2017/11/13 changes , add checking for eligibility/systemEligibility
		//  a.eligibility = '10' or ( trim(a.eligibility) is null and a.systemEligibility='10'
		companyId = FormatUtil.convertNull(companyId);
		//		productCode = FormatUtil.convertNull(productCode);
		;
		for (com.aia.cmic.entity.ClaimPayment claimPayment : claimPayments) {
			if (companyId.equalsIgnoreCase(FormatUtil.convertNull(claimPayment.getCompanyId())) && isSameClaimNo(claimNo, claimPayment.getClaimNo()) && occurrence.equals(claimPayment.getOccurrence()) && policyNo.equalsIgnoreCase(claimPayment.getPolicyNo()) && planId.equals(claimPayment.getPlanId()) && qualifyPlanCoverageNo(planCoverageNo, claimPayment
					.getPlanCoverageNo()) && (ClaimCalculationEnum.Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getEligibility()) || (StringUtils.isEmpty(claimPayment.getEligibility()) && ClaimCalculationEnum.Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getSystemEligibility())))) {
				return claimPayment;
			}

		}
		return null;

	}

	public static void checkBenefitCodeCalculationRequiredParameters(List<Object> parameters, List<String> parameterNames, String message) throws RuntimeException {
		int index = 0;
		for (Object parameter : parameters) {
			if (parameter == null) {
				throw new ClaimPaymentValidationException(String.format(message, parameterNames.get(index)));
			}
			index++;
		}
	}

	public static void checkRequiredParameters(List<Object> parameters, List<String> parameterNames, String message) throws RuntimeException {
		// reuse benefitCodeChecking
		checkBenefitCodeCalculationRequiredParameters(parameters, parameterNames, message);
	}

	/**
	 * Generate required fields for  HS reduced sorting.
	 * @param hsForSortingList
	 * @param claimCanonical
	 * @return
	 */
	public static List<HSReduced> generateHSReducedForSorting(List<ClaimPaymentDetail> hsForSortingList, ClaimCanonical claimCanonical) {
		List<HSReduced> results = new ArrayList<HSReduced>();

		for (ClaimPaymentDetail cpd : hsForSortingList) {
			for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
				if (isSameClaimNo(cpd.getClaimNo(), claimPolicyCanonical.getClaimPolicy().getClaimNo()) && cpd.getOccurrence().equals(claimPolicyCanonical.getClaimPolicy().getOccurrence()) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equalsIgnoreCase(cpd.getPolicyNo())) {

					results.add(new HSReduced(cpd, claimPolicyCanonical.getClaimPolicy()));
					break;
				}
			}
		}
		return results;
	}

	/**
	 * Generate required fields for  HSX reduced sorting.
	 * @param hsForSortingList
	 * @param claimCanonical
	 * @return
	 */
	public static List<HSXReduced> generateHSXReducedForSorting(List<ClaimPaymentDetail> hsForSortingList, ClaimCanonical claimCanonical, Map<String,HSXBenefitDeductSequence> sequenceMap) {
		List<HSXReduced> results = new ArrayList<HSXReduced>();

		for (ClaimPaymentDetail cpd : hsForSortingList) {
			for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
				if (isSameClaimNo(cpd.getClaimNo(), claimPolicyCanonical.getClaimPolicy().getClaimNo()) && cpd.getOccurrence().equals(claimPolicyCanonical.getClaimPolicy().getOccurrence()) && claimPolicyCanonical.getClaimPolicy().getPolicyNo().equalsIgnoreCase(cpd.getPolicyNo())) {
					for(ClaimPolicyPlanCanonical claimPolicyPlanCanonical:  claimPolicyCanonical.getClaimPolicyPlans()) {
						if(claimPolicyPlanCanonical.getClaimPolicyPlan().getPlanId().equals(cpd.getPlanId()) ) {
							results.add(new HSXReduced(cpd, claimPolicyPlanCanonical.getClaimPolicyPlan(), sequenceMap.get(cpd.getBenefitCode()) ));
							break ;
						}
					}					
					break;
				}
			}
		}
		return results;
	}
	
	public static List<String> findAllPolicyInClaim(ClaimCanonical claimCononical) {
		List<ClaimPayment> claimPayments = claimCononical.getClaimPayments();
		List<String> policys = new ArrayList<String>();
		for (ClaimPayment cPayment : claimPayments) {
			policys.add(cPayment.getPolicyNo());
		}
		return policys;
	}

	public static Payee findPayeeByPolicyNo(String claimNo, Integer occurrence, String payeeType, String policyNo, ClaimCanonical claimCanonical) {
		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			Payee payee = claimPolicyCanonical.getPayee();
			if (PayeeType.PROVIDER.getPayeeType().equals(payeeType)) {
				payee = claimPolicyCanonical.getProviderPayee();
			} else if (PayeeType.COMPANY.getPayeeType().equals(payeeType)) {
				payee = claimPolicyCanonical.getPayeeOrganization();
			}
			ClaimPolicy claimPolicy = claimPolicyCanonical.getClaimPolicy();
			if (payee != null && claimPolicy != null) {
				if (isSameClaimNo(claimNo, claimCanonical.getClaim().getClaimNo()) && occurrence.equals(claimCanonical.getClaim().getOccurrence()) && policyNo.equals(claimPolicy.getPolicyNo())) {
					return payee;
				}
			}
		}
		return null;
	}

	public static ClaimPayment findClaimPaymentByPaymentId(Long claimPaymentId, ClaimCanonical claimCanonical) {
		ClaimPayment claimPayment = null;
		List<ClaimPayment> claimPayments = claimCanonical.getClaimPayments();
		for (ClaimPayment cPayment : claimPayments) {
			if (claimPaymentId.equals(cPayment.getClaimPaymentId())) {
				claimPayment = cPayment;
				break;
			}
		}
		return claimPayment;
	}

	private static Boolean isSameClaimNo(String claimNo1, String claimNo2) {
		if (StringUtils.isEmpty(claimNo1) || StringUtils.isEmpty(claimNo2)) {
			return false;
		}
		return org.apache.commons.lang.StringUtils.equals(claimNo1.substring(1), claimNo2.substring(1));

	}

	/**
	 * Check if RollOver benefit Code belongs to any product/policy under ClaimPolicyCoverage
	 * @param claimNo
	 * @param occurence
	 * @param rolloverBenefitCode1
	 * @param rollOver
	 * @param claimCanonical
	 * @return
	 */
	public static Boolean addBenefitCodeIfBelongToPolicyCoverage(String claimNo, Integer occurence, String rolloverBenefitCode, PaymentAllocationTemp rollOver, ClaimCanonical claimCanonical, ProductRepository productRepository) {

		for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
			for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {
				for (ClaimPolicyCoverage policyCoverage : cppc.getClaimPolicyCoverages()) {
					if (rolloverBenefitCode.equalsIgnoreCase(policyCoverage.getBenefitCode()) && ("Y".equalsIgnoreCase(policyCoverage.getEnableInd()) || StringUtils.isEmpty(policyCoverage.getEnableInd())) && checkIfProductIsEligible(policyCoverage.getPolicyNo(), policyCoverage.getProductCode(), policyCoverage.getPlanId(), policyCoverage.getPlanCoverageNo(), claimCanonical)) {

						rollOver.setPolicyNo(policyCoverage.getPolicyNo());
						rollOver.setProductCode(policyCoverage.getProductCode());
						rollOver.setCsProductCode(policyCoverage.getProductCode());
						rollOver.setPlanId(policyCoverage.getPlanId());
						rollOver.setPlanCoverageNo(policyCoverage.getPlanCoverageNo());

						ClaimPolicyPlan cpp = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(claimNo, occurence, rollOver.getPlanId(), rollOver.getPolicyNo(), rollOver.getPlanCoverageNo(), claimCanonical);
						if (cpp != null) {
							rollOver.setPlanIssueDt(cpp.getPlanIssueDt());
						}
						Product product = null;
						if (!StringUtils.isEmpty(rollOver.getProductCode())) {
							product = productRepository.findProductByPrimaryKey(rollOver.getProductCode());
						}
						if (product != null) {
							rollOver.setProductType(product.getProductType());
						}
						return Boolean.TRUE;
					}
				}
			}
		}

		return Boolean.FALSE;
	}

	public static Boolean checkIfProductIsEligible(String policyNo, String productCode, Long planId, String planCoverageNo, ClaimCanonical claimCanonical) {

		for (ClaimPayment claimPayment : claimCanonical.getClaimPayments()) {

			if ((Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getEligibility()) || (StringUtils.isEmpty(claimPayment.getEligibility()) && Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getSystemEligibility()))) && policyNo.equals(claimPayment.getPolicyNo()) && productCode.equals(claimPayment.getProductCode()) && planId.equals(claimPayment
					.getPlanId()) && qualifyPlanCoverageNo(claimPayment.getPlanCoverageNo(), planCoverageNo)) {
				return Boolean.TRUE;
			}

		}

		return Boolean.FALSE;
	}

	public static ClaimPayment findClaimPaymentByPolicyNoPlanPlanCoverage(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		for (ClaimPayment claimPayment : claimCanonical.getClaimPayments()) {
			if ((Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getEligibility()) || (StringUtils.isEmpty(claimPayment.getEligibility()) && Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getSystemEligibility()))) && working.getPolicyNo().equals(claimPayment.getPolicyNo()) && working.getProductCode().equals(claimPayment.getProductCode()) && working.getPlanId().equals(
					claimPayment.getPlanId()) && qualifyPlanCoverageNo(claimPayment.getPlanCoverageNo(), working.getPlanCoverageNo())) {
				return claimPayment;
			}

		}

		return null;
	}

	public static ClaimPayment findClaimPaymentByPolicyNoPlanPlanCoverage(ClaimCanonical claimCanonical, String policyNo, String productCode, Long planId, String planCoverageNo) {

		for (ClaimPayment claimPayment : claimCanonical.getClaimPayments()) {
			if ((Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getEligibility()) || (StringUtils.isEmpty(claimPayment.getEligibility()) && Eligibility.ACCEPTED.getEligibility().equals(claimPayment.getSystemEligibility()))) && policyNo.equals(claimPayment.getPolicyNo()) && productCode.equals(claimPayment.getProductCode()) && planId.equals(claimPayment
					.getPlanId()) && qualifyPlanCoverageNo(claimPayment.getPlanCoverageNo(), planCoverageNo)) {
				return claimPayment;
			}

		}

		return null;
	}
	
	public static void calculateInterest(com.aia.cmic.entity.ClaimPayment claimPayment, com.aia.cmic.model.Claim claim, CycleDateRepository cycleDateRepository, BigDecimal basedAmount) {
		claimPayment.setInterestAmt(null) ;
		if(org.apache.commons.lang.StringUtils.equals("Y", claim.getInterestInd()))  {
			if(basedAmount != null && basedAmount.compareTo(BigDecimal.ZERO) > 0) {
				claimPayment.setInterestAmt(BigDecimal.ZERO) ;
				Date startDate = claim.getDocumentInTime() != null ? claim.getDocumentInTime() : claim.getReceivedDate() ;
				Date cycleDate = cycleDateRepository.findcurrentCycleDateByApplicationName(CycleDate.APPNAME_BCLAIMS) ;
				if(cycleDate != null && startDate != null) {
					startDate = DateUtils.truncate(startDate, Calendar.DAY_OF_MONTH) ;
					cycleDate = DateUtils.truncate(cycleDate, Calendar.DAY_OF_MONTH) ;
					Long daysDiff = TimeUnit.DAYS.convert(cycleDate.getTime() - startDate.getTime()  , TimeUnit.MILLISECONDS) ;
					
					// deductions if any
					BigDecimal deductions = (BigDecimal) ObjectUtils.defaultIfNull(claimPayment.getDeductAmt(), BigDecimal.ZERO) ;
					basedAmount = basedAmount.subtract(deductions) ;
					// clean ind
					if(org.apache.commons.lang.StringUtils.equals("Y", claim.getCleanInd()) ) {
						if(daysDiff > 15) {
							BigDecimal interestAmt = basedAmount.multiply(BigDecimal.valueOf(daysDiff - 15)).multiply(BigDecimal.valueOf(0.15)).divide(
									BigDecimal.valueOf(365),32,RoundingMode.HALF_UP).setScale(2, RoundingMode.HALF_UP) ;
							claimPayment.setInterestAmt(interestAmt);
						}
						
					} else if(daysDiff > 90){
						BigDecimal interestAmt = basedAmount.multiply(BigDecimal.valueOf(daysDiff - 90)).multiply(BigDecimal.valueOf(0.15)).divide(
								BigDecimal.valueOf(365),32,RoundingMode.HALF_UP).setScale(2, RoundingMode.HALF_UP) ;
						claimPayment.setInterestAmt(interestAmt);
					}
					
					if (LOG.isDebugEnabled()) {
						LOG.debug("Days Diff = {}, CycleDate({}) - DocumentInTime/ReceivedDate({}), Claim.cleanInd={}, Interest Amt ={}, BasedAmt ={}, Deductions={}", daysDiff, cycleDate, startDate, claim.getCleanInd(), 
								claimPayment.getInterestAmt(), basedAmount, deductions); 
					}
				}
			}
		} 
	}

	public static List<ClaimPolicyPlan> getPlansForDeduction(ClaimCanonical claimCanonical, PlanRepository planRepository) {
		// get all possible hnw plan
		Map<String, Plan> hwnwPlanMap = new HashMap<String, Plan>() ;
	    for(ClaimPayment claimPayment: claimCanonical.getClaimPayments()) {
 	    	if(org.apache.commons.lang.StringUtils.equals("HNW",claimPayment.getProductType())) {
 		    	Boolean isEligible = ( BooleanUtils.isTrue("10".equals(claimPayment.getEligibility())) || (org.apache.commons.lang.StringUtils.isBlank(claimPayment.getEligibility()) && BooleanUtils.isTrue("10".equals(claimPayment.getSystemEligibility()))) ) 
 		    			&& Arrays.asList("10","40").contains(claimPayment.getPaymentStatus()) ;
 		    	if(isEligible) {
	 	    		Plan plan = planRepository.findPlanByPrimaryKey(claimPayment.getPlanId()) ;
		    		if(plan != null) {
		    			if(Arrays.asList("990D07","990E07").contains(plan.getPlanCode())) {
		    				String key =  FormatUtil.keyGen( claimPayment.getPolicyNo(), claimPayment.getPlanId(),claimPayment.getPlanCoverageNo()) ;
		    				hwnwPlanMap.put(key, plan) ;
		    			}
		    		}
 		    	}
	    	}
	    }
		
		LinkedHashSet<ClaimPolicyPlan> policyPlans = new LinkedHashSet<ClaimPolicyPlan>() ;
		if(!hwnwPlanMap.isEmpty()) {
			for (ClaimPolicyCanonical claimPolicyCanonical : claimCanonical.getClaimPolicies()) {
				for (ClaimPolicyPlanCanonical cppc : claimPolicyCanonical.getClaimPolicyPlans()) {
					String key =  FormatUtil.keyGen( cppc.getClaimPolicyPlan().getPolicyNo(), cppc.getClaimPolicyPlan().getPlanId(),cppc.getClaimPolicyPlan().getPlanCoverageNo()) ;
					if(hwnwPlanMap.containsKey(key)) {
						policyPlans.add(cppc.getClaimPolicyPlan()) ;
					}
				}
			}
		}
		
		return new ArrayList<ClaimPolicyPlan>(policyPlans) ;
	}

	public static List<ClaimPaymentDetail> getPaidToOtherHSPolicy(String policyNo, Long planId,String planCoverageNo,List<ClaimPaymentDetail> cpdList,ClaimCanonical claimCanonical, PlanRepository planRepository) {
		List<ClaimPaymentDetail> alreadyAddedList = new ArrayList<ClaimPaymentDetail>() ;
		Claim claim = claimCanonical.getClaim() ;
		
		Comparator<ClaimPaymentDetail> comparator = null ;
		if (Arrays.asList("1", "2", "11").contains(claim.getTreatmentType())) {
			// IPD
			comparator = new Comparator<ClaimPaymentDetail>() {
				@Override
				public int compare(ClaimPaymentDetail cpd1, ClaimPaymentDetail cpd2) {
					return IPD_HNWDeductSequence.getDeductSequence(cpd1.getBenefitCode())
							.compareTo(IPD_HNWDeductSequence.getDeductSequence(cpd2.getBenefitCode()));
				}
			};
		} else if (Arrays.asList("4", "5", "6", "7", "12", "13").contains(claim.getTreatmentType())) {
			// OPD
			comparator = new Comparator<ClaimPaymentDetail>() {
				@Override
				public int compare(ClaimPaymentDetail cpd1, ClaimPaymentDetail cpd2) {
					return OPD_HNWDeductSequence.getDeductSequence(cpd1.getBenefitCode())
							.compareTo(OPD_HNWDeductSequence.getDeductSequence(cpd2.getBenefitCode()));
				}
			};
		}
		
		Map<Long, Plan> planMap =new HashMap<Long, Plan>() ;
		for(ClaimPaymentDetail cpd: cpdList) {
			Boolean otherPolicy = BooleanUtils.isFalse(org.apache.commons.lang.StringUtils.equals(cpd.getPolicyNo(), policyNo)) ;
			Boolean otherPlanId = BooleanUtils.isFalse(planId.equals(cpd.getPlanId())) ;
			Boolean otherPlanCoverageNo = BooleanUtils.isFalse(org.apache.commons.lang.StringUtils.equals(planCoverageNo, cpd.getPlanCoverageNo())) ;			
//			Boolean isHSProduct = StringUtils.startsWithIgnoreCase((String) ObjectUtils.defaultIfNull(cpd.getProductType(), "") , "HS") ;
//			Boolean isFirstDollar = Boolean.FALSE ;
//			if(org.apache.commons.lang.StringUtils.equals(cpd.getProductType(), ProductType.HNW.toString())) {
//				for(ClaimPayment claimPayment: claimCanonical.getClaimPayments()) {
//					if(org.apache.commons.lang.StringUtils.equals(ProductType.HNW.toString(),claimPayment.getProductType())) {
// 		    			String key1 = FormatUtil.keyGen(cpd.getPolicyNo(),cpd.getPlanId(),cpd.getPlanCoverageNo(),cpd.getProductType()) ;
// 		    			String key2 = FormatUtil.keyGen(claimPayment.getPolicyNo(),claimPayment.getPlanId(),claimPayment.getPlanCoverageNo(),claimPayment.getProductType()) ;
//		    			if( org.apache.commons.lang.StringUtils.equals(key1, key2) && !Arrays.asList("990D07","990E07").contains(claimPayment.getPlanCode())) {
//		    				isFirstDollar = Boolean.TRUE ;
//		    				break ;
//			    		}
//			    	}
//			    }
//			}
//			// ME
//			Boolean isME = BooleanUtils.isTrue(org.apache.commons.lang.StringUtils.equals(cpd.getBenefitCode(), BenefitCode.A09.toString())) &&
//					BooleanUtils.isTrue(org.apache.commons.lang.StringUtils.equals(cpd.getProductType(), ProductType.PA.toString())) ;
			
			if( otherPolicy || otherPlanId || otherPlanCoverageNo  ) {
				// look in claipaymentdetail
				Plan plan = null ;
				if(!planMap.containsKey(cpd.getPlanId())) {
					plan = planRepository.findPlanByPlanId(cpd.getPlanId()) ;
					planMap.put(cpd.getPlanId(), plan) ;
				} else {
					plan = planMap.get(cpd.getPlanId()) ;
				}
				if(plan != null) {
					Boolean isHSorME = Arrays.asList("ME","HS").contains(plan.getBenefitType()) &&  !Arrays.asList("990D07","990E07").contains(plan.getPlanCode());
					if(isHSorME) {
						alreadyAddedList.add(cpd) ;
					}
				}
			}
		}
		if(CollectionUtils.isNotEmpty(alreadyAddedList)) {
			cpdList.removeAll(alreadyAddedList) ;
			Collections.sort(alreadyAddedList, comparator);
		}
		
		return alreadyAddedList ;
	}
	
	public static BigDecimal formatAmt( BigDecimal amt) {
		if(amt != null) {
//			BigDecimal fractionalPart = amt.remainder(BigDecimal.ONE) ;
//			if(fractionalPart.compareTo(BigDecimal.ONE) > 0) {
				return amt.setScale(2, RoundingMode.HALF_UP) ;
//			} else {
//				return amt.setScale(0) ;
//			}
		}
		
		return amt ;
	}
	
	public static Long findPlanIdFromPolicyPlan(ClaimPolicyCanonical cpc, String policyNo) {
		Long planId = null;
		if(cpc.getClaimPolicyPlans() != null && cpc.getClaimPolicyPlans().size() > 0){
			List<ClaimPolicyPlanCanonical> claimPolicyPlans = cpc.getClaimPolicyPlans();
			for(ClaimPolicyPlanCanonical cppc: claimPolicyPlans){
                ClaimPolicyPlan claimPolicyPlan = cppc.getClaimPolicyPlan();
    			if(FormatUtil.IsEmptyWithTrim(policyNo)){
    			    return claimPolicyPlan.getPlanId();
    			}else{
    			    if(!FormatUtil.IsEmptyWithTrim(claimPolicyPlan.getPolicyNo())){
    			        if(policyNo.equals(claimPolicyPlan.getPolicyNo())){ 
    				        return claimPolicyPlan.getPlanId();
    			        }
    			    }
    		   }
    	   }
    	}
		return planId;
	}

	public static void setupClaimPolicyPlanIssueExpiryDate(Claim claim, ClaimPolicyPlan claimPolicyPlan, ClaimPolicyPlanRepository claimPolicyPlanRepository ) {
		
		if (claimPolicyPlan != null && claimPolicyPlan.getPlanIssueDt() != null && ( claim.getFirstAdmitDt() != null  || claim.getHospitalizationDate() != null )) {
			Date incidentDt =  claim.getHospitalizationDate() ;
			Date firstAdmitDt  = claim.getFirstAdmitDt() ;
			
			if(firstAdmitDt != null) {
				incidentDt = firstAdmitDt ;
			}
			
			// Get month/day of policy issueDt
			Date planIssueDt = claimPolicyPlan.getPlanIssueDt() ;
			if(planIssueDt != null && incidentDt != null) {
				
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("MMdd") ;
					SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy") ;
					SimpleDateFormat sdf3 = new SimpleDateFormat("MMddyyyy") ;

					Date startDate = null ;
					if( Integer.parseInt(sdf.format(planIssueDt)) <= Integer.parseInt(sdf.format(incidentDt))) {
						// case 1/2
						startDate = sdf3.parse(sdf.format(planIssueDt) + sdf2.format(incidentDt) ) ;
					} else {
						// case 3
						Calendar cal = Calendar.getInstance();
						cal.setTime(incidentDt);
						startDate = cal.getTime() ;
						startDate = DateUtils.addYears(startDate,  - 1) ;
						startDate = sdf3.parse(sdf.format(planIssueDt) + sdf2.format(startDate) ) ;
					}
					
					Calendar cal = Calendar.getInstance();
					cal.setTime(startDate);
					Date endDate = cal.getTime();

					endDate = DateUtils.addYears(endDate, 1) ;
					endDate = DateUtils.addDays(endDate, -1) ;
					startDate = DateUtils.truncate(startDate, Calendar.DAY_OF_MONTH) ;
					endDate = DateUtils.truncate(endDate, Calendar.DAY_OF_MONTH) ;
					
					com.aia.cmic.entity.ClaimPolicyPlan updatePolicyYear=claimPolicyPlanRepository.findClaimPolicyPlanByClaimPolicyPlanId(claimPolicyPlan.getClaimPolicyPlanId());
					if (updatePolicyYear!=null) {
						updatePolicyYear.setPolicyYearFromDt(startDate);
						updatePolicyYear.setPolicyYearToDt(endDate);
						claimPolicyPlanRepository.updateClaimPolicyPlan(updatePolicyYear);
					}
				} catch (Exception e) {
				}
			}
		}
	}
	
}
