package com.aia.cmic.canonical;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.MultiMap;

import com.aia.cmic.model.Claim;
import com.aia.cmic.model.TransactionLogMessage;
import com.aia.cmic.util.ClaimCalculationEnum;

public class ClaimBenefitCanonical {

	public final static int SUCCESS = 0;
	public final static int FAIL_1 = 1;
	public final static int FAIL_2 = 2;
	Claim claim;
	Long claimId = null;
	Long caseId = null;
	String claimStatusDesc;
	String billingRejectReason;
	String faxNo;
	String emailAddress;
	String agentName;
	String suppressInd;
	List<ClaimPaymentBenefit> claimPaymentBenefits;
	MultiMap multiMap;
	int retureCode;
	String errorMsg;
	BigDecimal eligibleAmtSum;
	BigDecimal approvedAmtSum;
	BigDecimal sumShortfallAmount;
	List<TransactionLogMessage> transactionLogMessages;
    Boolean allowNotApplcable;
    
	public ClaimBenefitCanonical() {
		claim = new Claim();
		retureCode = SUCCESS;
		errorMsg = "";
		suppressInd = "";
		claimPaymentBenefits = new ArrayList<ClaimPaymentBenefit>();
		eligibleAmtSum = new BigDecimal(0);
		approvedAmtSum = new BigDecimal(0);
		sumShortfallAmount = new BigDecimal(0);
		allowNotApplcable = Boolean.FALSE;
	}

	public String getSuppressInd() {
		return suppressInd;
	}

	public void setSuppressInd(String suppressInd) {
		this.suppressInd = suppressInd;
	}

	public BigDecimal getEligibleAmtSum() {
		return eligibleAmtSum;
	}

	public void setEligibleAmtSum(BigDecimal eligibleAmtSum) {
		this.eligibleAmtSum = eligibleAmtSum;
	}

	public BigDecimal getApprovedAmtSum() {
		return approvedAmtSum;
	}

	public void setApprovedAmtSum(BigDecimal approvedAmtSum) {
		this.approvedAmtSum = approvedAmtSum;
	}

	public BigDecimal getSumShortfallAmount() {
		return sumShortfallAmount;
	}

	public void setSumShortfallAmount(BigDecimal sumShortfallAmount) {
		this.sumShortfallAmount = sumShortfallAmount;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getBillingRejectReason() {
		return billingRejectReason;
	}

	public void setBillingRejectReason(String billingRejectReason) {
		this.billingRejectReason = billingRejectReason;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public int getRetureCode() {
		return retureCode;
	}

	public void setRetureCode(int retureCode) {
		this.retureCode = retureCode;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public MultiMap getMultiMap() {
		return multiMap;
	}

	public void setMultiMap(MultiMap multiMap) {
		this.multiMap = multiMap;
		groupClaimPaymentBenefit();
	}

	public Claim getClaim() {
		return claim;
	}

	public void setClaim(Claim claim) {
		this.claim = claim;
	}

	public List<ClaimPaymentBenefit> getClaimPaymentBenefits() {
		return claimPaymentBenefits;
	}

	public void setClaimPaymentBenefits(List<ClaimPaymentBenefit> claimPaymentBenefits) {
		this.claimPaymentBenefits = claimPaymentBenefits;
	}

	public String getClaimStatusDesc() {
		return claimStatusDesc;
	}

	public void setClaimStatusDesc(String claimStatusDesc) {
		this.claimStatusDesc = claimStatusDesc;
	}

	public List<TransactionLogMessage> getTransactionLogMessages() {
		return transactionLogMessages;
	}

	public void setTransactionLogMessages(List<TransactionLogMessage> transactionLogMessages) {
		this.transactionLogMessages = transactionLogMessages;
	}
	
	
	public Boolean getAllowNotApplcable() {
		return allowNotApplcable;
	}

	public void setAllowNotApplcable(Boolean allowNotApplcable) {
		this.allowNotApplcable = allowNotApplcable;
	}

	@SuppressWarnings("unchecked")
	private void groupClaimPaymentBenefit() {
		claimPaymentBenefits = new ArrayList<ClaimPaymentBenefit>();
		List<ClaimPaymentBenefit> CSList = (List<ClaimPaymentBenefit>) multiMap.get(ClaimCalculationEnum.BusinessLine.CS.name().toString());
		if (CSList != null) {
			for (ClaimPaymentBenefit cb : CSList) {
				claimPaymentBenefits.add(cb);
			}
		}
		List<ClaimPaymentBenefit> GPAList = (List<ClaimPaymentBenefit>) multiMap.get(ClaimCalculationEnum.BusinessLine.GPA.name().toString());
		if (GPAList != null) {
			for (ClaimPaymentBenefit cb : GPAList) {
				claimPaymentBenefits.add(cb);
			}
		}
		List<ClaimPaymentBenefit> PAList = (List<ClaimPaymentBenefit>) multiMap.get(ClaimCalculationEnum.BusinessLine.PA.name().toString());
		if (PAList != null) {
			for (ClaimPaymentBenefit cb : PAList) {
				claimPaymentBenefits.add(cb);
			}
		}
		List<ClaimPaymentBenefit> OLList = (List<ClaimPaymentBenefit>) multiMap.get(ClaimCalculationEnum.BusinessLine.OL.name().toString());
		if (OLList != null) {
			for (ClaimPaymentBenefit cb : OLList) {
				claimPaymentBenefits.add(cb);
			}
		}
		List<ClaimPaymentBenefit> GPSEList = (List<ClaimPaymentBenefit>) multiMap.get(ClaimCalculationEnum.BusinessLine.GPSE.name().toString());
		if (GPSEList != null) {
			for (ClaimPaymentBenefit cb : GPSEList) {
				claimPaymentBenefits.add(cb);
			}
		}
	}

}
