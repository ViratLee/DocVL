package com.aia.cmic.canonical;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.model.BenefitDeterminationPaymentListForm;

/**
 * @author ASNPATD
 *
 */
public class ClaimPaymentBenefit {

	Long claimPaymentId;
	String businessLine;
	Date policyIssueDt;
	Date planIssueDt;

	String productType;
	String productCode;
	String productShortName;
	String companyId;
	String claimNo;
	Integer occurrence;
	//key find to pop up plan detail.
	String policyNo;
	Long planId;
	String planCoverageNo;
	String planName;
	String certNo;
	//////////////
	String systemEligibility;
	String eligibility;
	String declineCode;
	String declineReason;

	///
	String payeeType;
	BigDecimal eligibleAmt;
	BigDecimal coPaymentPercent;
	BigDecimal adjustedAmt;
	String adjustedReason;
	String suppressChequeInd;
	BigDecimal approvedAmt;

	String paymentStatus;
	//addition field
	String planShortName;
	String planStatus;
	BigDecimal sumAssured;
	Boolean isExclusion;
	Boolean isImpairment;

	// flag for rider and payment status flag
	Boolean isRider;
	Boolean isCalculated;
	Boolean isDeductAmt;

	// add short fall
	BigDecimal shortFallAmt;
	String payNonCoverItemInd;

	String dataPrivacyConsent;
	String dataPrivacyConsentDate;
	String aiDecision;
	
	public ClaimPaymentBenefit() {
		productType = "";
		productShortName = "";
		businessLine = "";
		companyId = "051";
		claimNo = "";
		occurrence = 1;
		//key find to pop up plan detail.
		policyNo = "";
		planId = null;
		planCoverageNo = null;
		planName = "";
		//////////////

		///
		payeeType = "N/A";
		eligibleAmt = BigDecimal.ZERO;
		coPaymentPercent = BigDecimal.ZERO;
		adjustedAmt = BigDecimal.ZERO;
		suppressChequeInd = "NO";
		approvedAmt = BigDecimal.ZERO;

		//addition field
		planShortName = "N/A";
		planStatus = "";
		sumAssured = BigDecimal.ZERO;
		isRider = Boolean.FALSE;
		isExclusion = Boolean.FALSE;
		isImpairment = Boolean.FALSE;
		isCalculated = Boolean.FALSE;
		isDeductAmt = Boolean.FALSE;

		shortFallAmt = BigDecimal.ZERO;
		payNonCoverItemInd = "";
		certNo = "";
		
		dataPrivacyConsent= "";
		dataPrivacyConsentDate = "";
	}

	public static ClaimPaymentBenefit newClaimPaymentBenefit(BenefitDeterminationPaymentListForm form) {
		ClaimPaymentBenefit claimPaymentBenefit = new ClaimPaymentBenefit();
		claimPaymentBenefit.setPolicyNo(form.getPolicyNo());
		claimPaymentBenefit.setPlanShortName(form.getPlanShortName());
		claimPaymentBenefit.setProductType(form.getProductType());
		claimPaymentBenefit.setEligibility(form.getClaimsDecision());
		claimPaymentBenefit.setDeclineCode(form.getDeclineReason());
		claimPaymentBenefit.setPayeeType(form.getPayee());
		claimPaymentBenefit.setAdjustedReason(form.getAdjustReason());
		claimPaymentBenefit.setDataPrivacyConsent(form.getDataPrivacyConsent());
		claimPaymentBenefit.setDataPrivacyConsentDate(form.getDataPrivacyConsentDate());
		claimPaymentBenefit.setAiDecision(form.getAiDecision());
		return claimPaymentBenefit;
	}

	public Boolean getIsRider() {
		return isRider;
	}

	public void setIsRider(Boolean isRider) {
		this.isRider = isRider;
	}

	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	public String getSystemEligibility() {
		return systemEligibility;
	}

	public void setSystemEligibility(String systemEligibility) {
		this.systemEligibility = systemEligibility;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getDeclineCode() {
		return declineCode;
	}

	public void setDeclineCode(String declineCode) {
		this.declineCode = declineCode;
	}

	public String getDeclineReason() {
		return declineReason;
	}

	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	public BigDecimal getCoPaymentPercent() {
		return coPaymentPercent;
	}

	public void setCoPaymentPercent(BigDecimal coPaymentPercent) {
		this.coPaymentPercent = coPaymentPercent;
	}

	public BigDecimal getAdjustedAmt() {
		return adjustedAmt;
	}

	public void setAdjustedAmt(BigDecimal adjustedAmt) {
		this.adjustedAmt = adjustedAmt;
	}

	public String getAdjustedReason() {
		return adjustedReason;
	}

	public void setAdjustedReason(String adjustedReason) {
		this.adjustedReason = adjustedReason;
	}

	public String getSuppressChequeInd() {
		return suppressChequeInd;
	}

	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}

	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

	public String getPlanShortName() {
		return planShortName;
	}

	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}

	public String getPlanStatus() {
		return planStatus;
	}

	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	public Boolean getIsExclusion() {
		return isExclusion;
	}

	public void setIsExclusion(Boolean isExclusion) {
		this.isExclusion = isExclusion;
	}

	public Boolean getIsImpairment() {
		return isImpairment;
	}

	public void setIsImpairment(Boolean isImpairment) {
		this.isImpairment = isImpairment;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductShortName() {
		return productShortName;
	}

	public void setProductShortName(String productShortName) {
		this.productShortName = productShortName;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public Date getPlanIssueDt() {
		return planIssueDt;
	}

	public void setPlanIssueDt(Date planIssueDt) {
		this.planIssueDt = planIssueDt;
	}

	public Date getPolicyIssueDt() {
		return policyIssueDt;
	}

	public void setPolicyIssueDt(Date policyIssueDt) {
		this.policyIssueDt = policyIssueDt;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Boolean getIsCalculated() {
		return isCalculated;
	}

	public void setIsCalculated(Boolean isCalculated) {
		this.isCalculated = isCalculated;
	}

	public Boolean getIsDeductAmt() {
		return isDeductAmt;
	}

	public void setIsDeductAmt(Boolean isDeductAmt) {
		this.isDeductAmt = isDeductAmt;
	}

	public BigDecimal getShortFallAmt() {
		return shortFallAmt;
	}

	public void setShortFallAmt(BigDecimal shortFallAmt) {
		this.shortFallAmt = shortFallAmt;
	}

	public String getPayNonCoverItemInd() {
		return payNonCoverItemInd;
	}

	public void setPayNonCoverItemInd(String payNonCoverItemInd) {
		this.payNonCoverItemInd = payNonCoverItemInd;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getDataPrivacyConsent() {
		return dataPrivacyConsent;
	}

	public void setDataPrivacyConsent(String dataPrivacyConsent) {
		this.dataPrivacyConsent = dataPrivacyConsent;
	}

	public String getDataPrivacyConsentDate() {
		return dataPrivacyConsentDate;
	}

	public void setDataPrivacyConsentDate(String dataPrivacyConsentDate) {
		this.dataPrivacyConsentDate = dataPrivacyConsentDate;
	}

	public String getAiDecision() {
		return aiDecision;
	}

	public void setAiDecision(String aiDecision) {
		this.aiDecision = aiDecision;
	}

}
