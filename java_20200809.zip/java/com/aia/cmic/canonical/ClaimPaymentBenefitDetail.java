package com.aia.cmic.canonical;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author ASNPATD
 *
 */
public class ClaimPaymentBenefitDetail {

	Long claimPaymentId;
	String companyId;
	String claimNo;
	Integer occurrence;
	//key find to pop up plan detail.
	String policyNo;
	Long planId;
	String planName;
	String planCoverageNo;
	//////////////
	String systemEligibility;
	String eligibility;
	String declineCode;
	///
	String payeeType;
	BigDecimal eligibleAmt;
	BigDecimal coPaymentPercent;
	BigDecimal adjustedAmt;
	String adjustedReason;
	String suppressChequeInd;
	BigDecimal allocatedAmt;
	String payNonCoverItemInd;

	//addition field
	String paPackageName;
	String claimPolicyPlanStatus;
	String coverageStatus;
	BigDecimal sumAssured;
	Boolean isExclusion;
	Boolean isImpairment;

	//more field for show policy detail dialog window.
	String exclusion1;
	String exclusion2;
	String exclusion3;
	String impairmentCode1;
	String impairmentCode2;
	String impairmentCode3;
	Date planIssueDt;
	Date planExpiryDt;
	Date callDate;
	String callTime;

	//more field for policy detail section 2
	Date contractDt;
	String policyStatus;
	String holdClaimInd;
	String policyHolder;
	String businessLine;

	//more field for policy detail section 3
	Date memEffectDt;
	String fullCreditInd;

	//more field for policy detail section 4 (ClaimPolicy)
	Date reinstatementDt;
	Date paidToDt;
	Date paCoverDt;
	Date paidDt;
	Date paidToCurrDt;
	String paymentMode;
	BigDecimal modalPremium;

	String certNo;
	String memberId;
	String dependentNo;
	String paymentInd;
	String riderConInd;

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public Date getMemEffectDt() {
		return memEffectDt;
	}

	public void setMemEffectDt(Date memEffectDt) {
		this.memEffectDt = memEffectDt;
	}

	public String getFullCreditInd() {
		return fullCreditInd;
	}

	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	public String getCoverageStatus() {
		return coverageStatus;
	}

	public void setCoverageStatus(String coverageStatus) {
		this.coverageStatus = coverageStatus;
	}

	public String getClaimPolicyPlanStatus() {
		return claimPolicyPlanStatus;
	}

	public void setClaimPolicyPlanStatus(String claimPolicyPlanStatus) {
		this.claimPolicyPlanStatus = claimPolicyPlanStatus;
	}

	public String getPolicyHolder() {
		return policyHolder;
	}

	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	public Date getReinstatementDt() {
		return reinstatementDt;
	}

	public void setReinstatementDt(Date reinstatementDt) {
		this.reinstatementDt = reinstatementDt;
	}

	public Date getPaidToDt() {
		return paidToDt;
	}

	public void setPaidToDt(Date paidToDt) {
		this.paidToDt = paidToDt;
	}

	public Date getPaCoverDt() {
		return paCoverDt;
	}

	public void setPaCoverDt(Date paCoverDt) {
		this.paCoverDt = paCoverDt;
	}

	public Date getPaidDt() {
		return paidDt;
	}

	public void setPaidDt(Date paidDt) {
		this.paidDt = paidDt;
	}

	public Date getPaidToCurrDt() {
		return paidToCurrDt;
	}

	public void setPaidToCurrDt(Date paidToCurrDt) {
		this.paidToCurrDt = paidToCurrDt;
	}

	public Date getCallDate() {
		return callDate;
	}

	public void setCallDate(Date callDate) {
		this.callDate = callDate;
	}

	public String getCallTime() {
		return callTime;
	}

	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Date getContractDt() {
		return contractDt;
	}

	public void setContractDt(Date contractDt) {
		this.contractDt = contractDt;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getHoldClaimInd() {
		return holdClaimInd;
	}

	public void setHoldClaimInd(String holdClaimInd) {
		this.holdClaimInd = holdClaimInd;
	}

	public Date getPlanIssueDt() {
		return planIssueDt;
	}

	public void setPlanIssueDt(Date planIssueDt) {
		this.planIssueDt = planIssueDt;
	}

	public Date getPlanExpiryDt() {
		return planExpiryDt;
	}

	public void setPlanExpiryDt(Date planExpiryDt) {
		this.planExpiryDt = planExpiryDt;
	}

	public Boolean getIsExclusion() {
		return isExclusion;
	}

	public void setIsExclusion(Boolean isExclusion) {
		this.isExclusion = isExclusion;
	}

	public Boolean getIsImpairment() {
		return isImpairment;
	}

	public void setIsImpairment(Boolean isImpairment) {
		this.isImpairment = isImpairment;
	}

	public String getImpairmentCode2() {
		return impairmentCode2;
	}

	public void setImpairmentCode2(String impairmentCode2) {
		this.impairmentCode2 = impairmentCode2;
	}

	public String getImpairmentCode3() {
		return impairmentCode3;
	}

	public void setImpairmentCode3(String impairmentCode3) {
		this.impairmentCode3 = impairmentCode3;
	}

	public String getExclusion2() {
		return exclusion2;
	}

	public void setExclusion2(String exclusion2) {
		this.exclusion2 = exclusion2;
	}

	public String getExclusion3() {
		return exclusion3;
	}

	public void setExclusion3(String exclusion3) {
		this.exclusion3 = exclusion3;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured2) {
		this.sumAssured = sumAssured2;
	}

	public String getImpairmentCode1() {
		return impairmentCode1;
	}

	public void setImpairmentCode1(String impairmentCode1) {
		this.impairmentCode1 = impairmentCode1;
	}

	public String getExclusion1() {
		return exclusion1;
	}

	public void setExclusion1(String exclusion1) {
		this.exclusion1 = exclusion1;
	}

	public String getPaPackageName() {
		return paPackageName;
	}

	public void setPaPackageName(String paPackageName) {
		this.paPackageName = paPackageName;
	}

	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	public String getSystemEligibility() {
		return systemEligibility;
	}

	public void setSystemEligibility(String systemEligibility) {
		this.systemEligibility = systemEligibility;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getDeclineCode() {
		return declineCode;
	}

	public void setDeclineCode(String declineCode) {
		this.declineCode = declineCode;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	public BigDecimal getCoPaymentPercent() {
		return coPaymentPercent;
	}

	public void setCoPaymentPercent(BigDecimal coPaymentPercent) {
		this.coPaymentPercent = coPaymentPercent;
	}

	public BigDecimal getAdjustedAmt() {
		return adjustedAmt;
	}

	public void setAdjustedAmt(BigDecimal adjustedAmt) {
		this.adjustedAmt = adjustedAmt;
	}

	public String getAdjustedReason() {
		return adjustedReason;
	}

	public void setAdjustedReason(String adjustedReason) {
		this.adjustedReason = adjustedReason;
	}

	public String getSuppressChequeInd() {
		return suppressChequeInd;
	}

	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	public BigDecimal getAllocatedAmt() {
		return allocatedAmt;
	}

	public void setAllocatedAmt(BigDecimal allocatedAmt) {
		this.allocatedAmt = allocatedAmt;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getPaymentInd() {
		return paymentInd;
	}

	public void setPaymentInd(String paymentInd) {
		this.paymentInd = paymentInd;
	}

	public BigDecimal getModalPremium() {
		return modalPremium;
	}

	public void setModalPremium(BigDecimal modalPremium) {
		this.modalPremium = modalPremium;
	}

	public String getPayNonCoverItemInd() {
		return payNonCoverItemInd;
	}

	public void setPayNonCoverItemInd(String payNonCoverItemInd) {
		this.payNonCoverItemInd = payNonCoverItemInd;
	}

	public String getRiderConInd() {
		return riderConInd;
	}

	public void setRiderConInd(String riderConInd) {
		this.riderConInd = riderConInd;
	}
	

}
