package com.aia.cmic.canonical;

import java.util.ArrayList;
import java.util.List;

import com.aia.cmic.model.ClaimPolicyCoverage;
import com.aia.cmic.model.ClaimPolicyPlan;

public class ClaimPolicyPlanCanonical {

	ClaimPolicyPlan claimPolicyPlan;
	List<ClaimPolicyCoverage> claimPolicyCoverages = new ArrayList<ClaimPolicyCoverage>();

	/**
	 * @return the claimPolicyPlan
	 */
	public ClaimPolicyPlan getClaimPolicyPlan() {
		return claimPolicyPlan;
	}

	/**
	 * @param claimPolicyPlan the claimPolicyPlan to set
	 */
	public void setClaimPolicyPlan(ClaimPolicyPlan claimPolicyPlan) {
		this.claimPolicyPlan = claimPolicyPlan;
	}

	/**
	 * @return the claimPolicyCoverages
	 */
	public List<ClaimPolicyCoverage> getClaimPolicyCoverages() {
		return claimPolicyCoverages;
	}

	/**
	 * @param claimPolicyCoverages the claimPolicyCoverages to set
	 */
	public void setClaimPolicyCoverages(List<ClaimPolicyCoverage> claimPolicyCoverages) {
		this.claimPolicyCoverages = claimPolicyCoverages;
	}
}
