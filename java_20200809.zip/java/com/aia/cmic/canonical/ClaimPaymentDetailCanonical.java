package com.aia.cmic.canonical;

import java.util.ArrayList;
import java.util.List;

import com.aia.cmic.model.ClaimPayment;
import com.aia.cmic.model.ClaimPaymentAccumulator;
import com.aia.cmic.model.ClaimPaymentDetail;
import com.aia.cmic.model.ClaimPaymentWorking;

public class ClaimPaymentDetailCanonical {

	private List<ClaimPayment> claimPayments = new ArrayList<ClaimPayment>();
	private List<ClaimPaymentAccumulator> claimPaymentAccumulators = new ArrayList<ClaimPaymentAccumulator>();
	private List<ClaimPaymentDetail> claimPaymentDetails = new ArrayList<ClaimPaymentDetail>();
	private List<ClaimPaymentWorking> claimPaymentWorkings = new ArrayList<ClaimPaymentWorking>();

	public List<ClaimPayment> getClaimPayments() {
		return claimPayments;
	}

	public void setClaimPayments(List<ClaimPayment> claimPayments) {
		this.claimPayments = claimPayments;
	}

	public List<ClaimPaymentAccumulator> getClaimPaymentAccumulators() {
		return claimPaymentAccumulators;
	}

	public void setClaimPaymentAccumulators(List<ClaimPaymentAccumulator> claimPaymentAccumulators) {
		this.claimPaymentAccumulators = claimPaymentAccumulators;
	}

	public List<ClaimPaymentDetail> getClaimPaymentDetails() {
		return claimPaymentDetails;
	}

	public void setClaimPaymentDetails(List<ClaimPaymentDetail> claimPaymentDetails) {
		this.claimPaymentDetails = claimPaymentDetails;
	}

	public List<ClaimPaymentWorking> getClaimPaymentWorkings() {
		return claimPaymentWorkings;
	}

	public void setClaimPaymentWorkings(List<ClaimPaymentWorking> claimPaymentWorkings) {
		this.claimPaymentWorkings = claimPaymentWorkings;
	}

}
