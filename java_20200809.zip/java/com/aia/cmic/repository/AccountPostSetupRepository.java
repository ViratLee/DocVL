package com.aia.cmic.repository;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.aia.cmic.entity.AccountPostSetup;

public interface AccountPostSetupRepository {
	
	public List<AccountPostSetup> getAccountPostSetupByPostStep(String postStep) throws DataAccessException;

}
