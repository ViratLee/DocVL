package com.aia.cmic.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/standardBilling")
public class StandardBillingController {

	@RequestMapping(value = "/query", method = RequestMethod.GET)
	public String openStandardBillingScreen(ModelMap model, HttpServletRequest httpServletRequest) {
		return "standardbilling/query";
	}

	@RequestMapping(value = "/upload", method = RequestMethod.GET)
	public String openUpload(ModelMap model, HttpServletRequest httpServletRequest) {
		return "standardbilling/upload";
	}

}
