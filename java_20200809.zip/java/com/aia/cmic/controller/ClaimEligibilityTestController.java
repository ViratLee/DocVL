package com.aia.cmic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.model.PartySnapshot;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimPaymentService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.PartyService;

@Controller
@RequestMapping("/claimEligibilityTest")
public class ClaimEligibilityTestController {

	@Autowired
	ClaimService claimService;

	@Autowired
	ClaimRepository claimRepository;

	@Autowired
	PartyService partyService;

	@Autowired
	@Qualifier("ClaimPaymentServiceImpl")
	ClaimPaymentService claimPaymentService;

	@RequestMapping(value = "/retrievePartyList", method = RequestMethod.GET)
	@ResponseBody
	public String retrievePartyListTest(
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(required = false) String partyId,
			@RequestParam(required = false) String firstName,
			@RequestParam(required = false) String lastName,
			@RequestParam(required = false) String nationalId,
			@RequestParam(required = false) String dob,
			@RequestParam(required = false) String gender,
			@RequestParam(required = false) String clientId,
			@RequestParam(required = false) String policyNo,
			@RequestParam(required = false) String certNo,
			@RequestParam(required = false) String memberId) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		// retrievePartyList
		try {

			List<PartySnapshot> partySnapshots = partyService.retrievePartyList(companyId, partyId, firstName, lastName, nationalId, dob, gender, clientId, policyNo, certNo, memberId);
			return ClaimAssessmentTestController.objectToJsonString(partySnapshots);
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}

	}
}
