package com.aia.cmic.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.ClaimPolicyCanonical;
import com.aia.cmic.entity.Claim;
import com.aia.cmic.model.ClaimBenefitItem;
import com.aia.cmic.model.ClaimBrokenBone;
import com.aia.cmic.model.ClaimPayment;
import com.aia.cmic.model.ClaimPhysician;
import com.aia.cmic.model.ClaimRequirementInfo;
import com.aia.cmic.model.ClaimRulesLog;
import com.aia.cmic.model.ClaimSnapshot;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimPaymentService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.PolicyService;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimStatus;
import com.aia.cmic.util.ClaimCalculationEnum.ProcessStatus;
import com.aia.cmic.util.FormatUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/claimMaintenanceTest")
public class ClaimMaintenanceTestController {

	@Autowired
	ClaimService claimService;

	@Autowired
	ClaimRepository claimRepository;

	@Autowired
	PolicyService policyService;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	@Qualifier("ClaimPaymentServiceImpl")
	ClaimPaymentService claimPaymentService;

	ObjectMapper mapper = new ObjectMapper();

	/* TODO
	 * 
	 */
	@RequestMapping(value = "/writeClaim", method = RequestMethod.POST)
	@ResponseBody
	public String writeClaimTest() {

		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		try {
			ClaimCanonical test = new ClaimCanonical();
			test.setClaim(createClaim());
			test.setClaimRequirementInfo(getClaimRequirementInfo());
			test.setBenefitItems(getClaimBenefitItems());
			test.setClaimPayments(getClaimPayments());
			test.setBrokenBones(getBrokenBones());
			test.setPhysicians(getPhysicians());
			claimService.writeClaim(test, "C", infoForm);
			return "OK";

		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	/**
	 * @
	 * 
	 */
	@RequestMapping(value = "/retrieveClaimDetail", method = RequestMethod.GET)
	@ResponseBody
	public String retrieveClaimDetailTest(@RequestParam(required = true) Long claimId, @RequestParam(defaultValue = "TH", required = false) String companyId) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		ClaimCanonical claimCanonical = null;
		try {
			claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);
			Claim claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());

			claim.setClaimStatus(ClaimStatus.SETTLEMENT_IN_PROGRESS.getValue());
			claim.setProcessStatus(ProcessStatus.ASSESSMENT_COMPLETE.getValue());
			claim.setLastModifiedBy("test");
			claim.setLastModifiedDt(new Date());
			claimRepository.updateClaim(claim);

			claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
			BeanUtils.copyProperties(claim, claimCanonical.getClaim());
			return ClaimAssessmentTestController.objectToJsonString(claimCanonical);

		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	@RequestMapping(value = "/retrieveClaimList", method = RequestMethod.GET)
	@ResponseBody
	public String retrieveClaimListTest(
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(required = false) Long partyId,
			@RequestParam(required = false) String nationalId,
			@RequestParam(required = false) String policyNo,
			@RequestParam(required = false) String memberId,
			@RequestParam(required = false) String certNo,
			@RequestParam(required = false) String accidentDt,
			@RequestParam(required = false) String hospitalizationDt,
			@RequestParam(required = false) String providerCode,
			@RequestParam(required = false) String claimStatus,
			@RequestParam(required = false) String treatmentType,
			@RequestParam(required = false) String hospitalizationDtFrom,
			@RequestParam(required = false) String hospitalizationDtTo) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		List<ClaimSnapshot> claimSnapshots;
		try {
			claimSnapshots = claimService.retrieveClaimList(companyId, partyId, nationalId, policyNo, memberId, certNo, FormatUtil.convertStringToDate(accidentDt),
					FormatUtil.convertStringToDate(hospitalizationDt), providerCode, claimStatus, treatmentType, FormatUtil.convertStringToDate(hospitalizationDtFrom),
					FormatUtil.convertStringToDate(hospitalizationDtTo));
			return ClaimAssessmentTestController.objectToJsonString(claimSnapshots);

		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}

	}

	//	@RequestMapping(value = "/retrievePolicyPlanDetail", method = RequestMethod.GET)
	//	@ResponseBody
	//	public String retrievePolicyPlanDetailTest(
	//			@RequestParam(defaultValue = "TH", required = false) String companyId,
	//			@RequestParam(required = false) String policyNo,
	//			@RequestParam(required = false) Long partyId) {
	//		UserInfoForm infoForm = new UserInfoForm();
	//		infoForm.setUserId("test");
	//		ClaimPolicyCanonical claimPolicyCanonical;
	//		try {
	//			if (partyId == null) {
	//				claimPolicyCanonical = policyService.retrievePolicyPlanDetail(companyId, policyNo);
	//				return ClaimAssessmentTestController.objectToJsonString(claimPolicyCanonical);
	//			}
	//			claimPolicyCanonical = policyService.retrievePolicyPlanDetail(companyId, policyNo, String.valueOf(partyId));
	//			return ClaimAssessmentTestController.objectToJsonString(claimPolicyCanonical);
	//
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//			return ("ERROR: " + e.getMessage());
	//		}
	//	}

	@RequestMapping(value = "/retrievePolicyPlanList1", method = RequestMethod.GET)
	@ResponseBody
	public String retrievePolicyPlanListTestCase1(
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(required = false) String nationalId,
			@RequestParam(required = false) String partyId,
			@RequestParam(required = false) String incidentDate) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");

		try {
			com.aia.cmic.model.Claim claim = new com.aia.cmic.model.Claim();
			claim.setCompanyId("1");
			claim.setPartyId(Long.valueOf(partyId));
			claim.setMemberId("");
			List<ClaimPolicyCanonical> claimPolicyCanonicals = policyService.retrievePolicyPlanList(claim, incidentDate, null);
			return ClaimAssessmentTestController.objectToJsonString(claimPolicyCanonicals);

		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	@RequestMapping(value = "/retrieveEligibilityInformation", method = RequestMethod.GET)
	@ResponseBody
	public String retrieveEligibilityInformationTest(
			@RequestParam(required = false) String claimNo,
			@RequestParam(required = false) Integer occurrence,
			@RequestParam(required = false) String policyNo,
			@RequestParam(required = false) Long planId) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		try {
			List<ClaimRulesLog> claimRulesLogs = claimService.retrieveEligibilityInformation(claimNo, occurrence, policyNo, planId);
			return ClaimAssessmentTestController.objectToJsonString(claimRulesLogs);
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	@RequestMapping(value = "/releaseClaimIndicator", method = RequestMethod.GET)
	@ResponseBody
	public String releaseClaimIndicatorTest(
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(required = false) String policyNo,
			@RequestParam(required = false) String subOffice,
			@RequestParam(required = false) String productCode,
			@RequestParam(required = false) String memberId,
			@RequestParam(required = false) String claimReleasedByInd,
			@RequestParam(required = false) String claimPaidToDate,
			@RequestParam(required = false) String businessLine
			) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		try {
			claimService.releaseClaimIndicator(companyId, policyNo, subOffice, productCode, memberId, claimReleasedByInd, claimPaidToDate,businessLine, infoForm);
			return "OK";
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	@RequestMapping(value = "/cancelClaimTest", method = RequestMethod.GET)
	@ResponseBody
	public String cancelClaimTest(@RequestParam(required = true) Long claimId, @RequestParam(defaultValue = "TH", required = false) String companyId) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		try {
			ClaimCanonical claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);

			Claim claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());

			claim.setClaimStatus(ClaimStatus.SETTLEMENT_IN_PROGRESS.getValue());
			claim.setProcessStatus(ProcessStatus.ASSESSMENT_COMPLETE.getValue());
			claim.setLastModifiedBy("test");
			claim.setLastModifiedDt(new Date());
			claimRepository.updateClaim(claim);

			BeanUtils.copyProperties(claim, claimCanonical.getClaim());
			claimPaymentService.cancelClaim(claimCanonical, infoForm , false);
			return "OK";
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	public com.aia.cmic.model.Claim createClaim() throws ParseException {
		com.aia.cmic.model.Claim testClaim = new com.aia.cmic.model.Claim();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
		String dateInString = "22-01-2015 10:20:56";
		try {
			Date date = sdf.parse(dateInString);
			testClaim.setReceivedDate(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String hospitalizationDate = "22-01-2015 10:20:56";
		String accidentDt = "22-01-2014 10:20:56";
		String dischargeDate = "23-02-2014 10:20:56";

		testClaim.setCompanyId("TH");
		testClaim.setFirstName("firstN");
		testClaim.setLastName("lastN");
		testClaim.setGender("1");
		testClaim.setDob(new Date());
		testClaim.setNationalId("test");
		testClaim.setCertNo("Cer111");
		testClaim.setCauseOfTreatment("cause");
		testClaim.setTreatmentType("1");
		testClaim.setHomeLeaveReason("NEW");
		testClaim.setMemberId("12");
		testClaim.setClaimStatus("8");
		testClaim.setPartyId(378978558l);
		//testClaim.setPolicyNo("41231");
		testClaim.setPolicyNo("41231");
		testClaim.setProviderCode("P0001");
		testClaim.setHospitalizationDate(sdf.parse(hospitalizationDate));
		testClaim.setAccidentDt(sdf.parse(accidentDt));
		testClaim.setDischargeDate(sdf.parse(dischargeDate));

		return testClaim;
	}

	private List<ClaimRequirementInfo> getClaimRequirementInfo() {
		ClaimRequirementInfo testClaimRequirementInfo1 = new ClaimRequirementInfo();

		testClaimRequirementInfo1.setDocumentType("claim form");
		testClaimRequirementInfo1.setDueDt(new Date());
		testClaimRequirementInfo1.setFulfilledDt(new Date());
		testClaimRequirementInfo1.setLetter("test");
		testClaimRequirementInfo1.setPendingCode("code");
		testClaimRequirementInfo1.setReceivedDt(new Date());
		testClaimRequirementInfo1.setRemark("remark");
		testClaimRequirementInfo1.setRequestedDt(new Date());
		testClaimRequirementInfo1.setRequirementDetail("detail");
		testClaimRequirementInfo1.setResolveBy("resolve by");
		testClaimRequirementInfo1.setResolveDetail("resolveDetail");
		testClaimRequirementInfo1.setResolveDt(new Date());
		testClaimRequirementInfo1.setResolveInd("N");
		testClaimRequirementInfo1.setSeqNo("1");
		testClaimRequirementInfo1.setStatus("statustest");
		testClaimRequirementInfo1.setTarget("abcx");

		ClaimRequirementInfo testClaimRequirementInfo2 = new ClaimRequirementInfo();

		testClaimRequirementInfo2.setDocumentType("claim form");
		testClaimRequirementInfo2.setDueDt(new Date());
		testClaimRequirementInfo2.setFulfilledDt(new Date());
		testClaimRequirementInfo2.setLetter("test");
		testClaimRequirementInfo2.setPendingCode("code");
		testClaimRequirementInfo2.setReceivedDt(new Date());
		testClaimRequirementInfo2.setRemark("remark");
		testClaimRequirementInfo2.setRequestedDt(new Date());
		testClaimRequirementInfo2.setRequirementDetail("detail");
		testClaimRequirementInfo2.setResolveBy("resolve by");
		testClaimRequirementInfo2.setResolveDetail("resolveDetail");
		testClaimRequirementInfo2.setResolveDt(new Date());
		testClaimRequirementInfo2.setResolveInd("N");
		testClaimRequirementInfo2.setSeqNo("1");
		testClaimRequirementInfo2.setStatus("statustest");
		testClaimRequirementInfo2.setTarget("abcx");

		List<ClaimRequirementInfo> listClaimRequirementInfo = new ArrayList<>();
		listClaimRequirementInfo.add(testClaimRequirementInfo1);
		listClaimRequirementInfo.add(testClaimRequirementInfo2);

		return listClaimRequirementInfo;
	}

	private List<ClaimBenefitItem> getClaimBenefitItems() {
		ClaimBenefitItem testClaimBenefitItem1 = new ClaimBenefitItem();

		testClaimBenefitItem1.setCompanyId("TH");
		testClaimBenefitItem1.setNoOfDaysPresented(2);
		testClaimBenefitItem1.setNoOfUnit(3);
		testClaimBenefitItem1.setPresentedAmt(new BigDecimal("11.21"));
		testClaimBenefitItem1.setPresentedDiscountAmt(new BigDecimal("31"));
		testClaimBenefitItem1.setPresentedPercentage(new BigDecimal("5"));
		testClaimBenefitItem1.setServiceCatId("10");
		testClaimBenefitItem1.setValuePerUnit(new BigDecimal("10"));

		ClaimBenefitItem testClaimBenefitItem2 = new ClaimBenefitItem();
		testClaimBenefitItem2.setCompanyId("TH");
		testClaimBenefitItem2.setNoOfDaysPresented(7);
		testClaimBenefitItem2.setNoOfUnit(4);
		testClaimBenefitItem2.setPresentedAmt(new BigDecimal("3.55"));
		testClaimBenefitItem2.setPresentedDiscountAmt(new BigDecimal("1"));
		testClaimBenefitItem2.setPresentedPercentage(new BigDecimal("7"));
		testClaimBenefitItem2.setServiceCatId("2");
		testClaimBenefitItem2.setValuePerUnit(new BigDecimal("9"));

		List<ClaimBenefitItem> listClaimBenefitItem = new ArrayList<>();
		listClaimBenefitItem.add(testClaimBenefitItem1);
		listClaimBenefitItem.add(testClaimBenefitItem2);

		return listClaimBenefitItem;
	}

	private List<ClaimPayment> getClaimPayments() {
		List<ClaimPayment> claimPayments = new ArrayList<>();

		ClaimPayment claimPayment1 = new ClaimPayment();
		claimPayment1.setAdjustedAmt(new BigDecimal("1"));
		claimPayment1.setAdjustedReason("reason");
		claimPayment1.setAllocatedAmt(new BigDecimal("1"));
		claimPayment1.setCompanyId("TH");
		claimPayment1.setCoPaymentPercent(new BigDecimal("2"));
		claimPayment1.setDeclineCode("code");
		claimPayment1.setDeclineReason("decline");
		claimPayment1.setEligibility("eligi");
		claimPayment1.setEligibleAmt(new BigDecimal("4"));
		claimPayment1.setNoOfDaysAllocated(3);
		claimPayment1.setPayeeType("type");
		claimPayment1.setPaymentStatus("status");
		claimPayment1.setPercentageAllocated(new BigDecimal("2"));
		claimPayment1.setPlanCoverageNo("01");
		claimPayment1.setPlanId(1l);
		claimPayment1.setPolicyNo("41231");
		claimPayment1.setPayeeType("test");
		claimPayment1.setReimbursedDay(2);
		claimPayment1.setReimbursedDay(1);
		claimPayment1.setShortFallAmt(new BigDecimal("3"));
		claimPayment1.setSuppressChequeInd("N");

		ClaimPayment claimPayment2 = new ClaimPayment();
		claimPayment2.setAdjustedAmt(new BigDecimal("2"));
		claimPayment2.setAdjustedReason("reason2");
		claimPayment2.setAllocatedAmt(new BigDecimal("2"));
		claimPayment2.setCompanyId("TH");
		claimPayment2.setCoPaymentPercent(new BigDecimal("22"));
		claimPayment2.setDeclineCode("code2");
		claimPayment2.setDeclineReason("decline2");
		claimPayment2.setEligibility("eligi2");
		claimPayment2.setEligibleAmt(new BigDecimal("42"));
		claimPayment2.setNoOfDaysAllocated(2);
		claimPayment2.setPayeeType("type2");
		claimPayment2.setPaymentStatus("status2");
		claimPayment2.setPercentageAllocated(new BigDecimal("22"));
		claimPayment2.setPlanCoverageNo("02");
		claimPayment2.setPlanId(2l);
		claimPayment2.setPolicyNo("41232");
		claimPayment2.setPayeeType("test2");
		claimPayment2.setReimbursedDay(24);
		claimPayment2.setReimbursedDay(2);
		claimPayment2.setShortFallAmt(new BigDecimal("4"));
		claimPayment2.setSuppressChequeInd("N");

		claimPayments.add(claimPayment1);
		claimPayments.add(claimPayment2);

		return claimPayments;
	}

	private List<ClaimBrokenBone> getBrokenBones() {
		ClaimBrokenBone testClaimBrokenBone1 = new ClaimBrokenBone();
		testClaimBrokenBone1.setCodeType(ClaimCalculationEnum.CodeType.BROKENBONE.getCodeType());
		testClaimBrokenBone1.setStrValue("Arm");
		ClaimBrokenBone testClaimBrokenBone2 = new ClaimBrokenBone();
		testClaimBrokenBone2.setCodeType(ClaimCalculationEnum.CodeType.BROKENBONE.getCodeType());
		testClaimBrokenBone2.setStrValue("Finger");

		List<ClaimBrokenBone> listBrokenBones = new ArrayList<>();
		listBrokenBones.add(testClaimBrokenBone1);
		listBrokenBones.add(testClaimBrokenBone2);

		return listBrokenBones;
	}

	private List<ClaimPhysician> getPhysicians() {
		ClaimPhysician testPhysician1 = new ClaimPhysician();
		testPhysician1.setCodeType(ClaimCalculationEnum.CodeType.PHYSICIAN.getCodeType());
		testPhysician1.setStrValue("Dr. Armstrong");

		ClaimPhysician testPhysician2 = new ClaimPhysician();
		testPhysician2.setCodeType(ClaimCalculationEnum.CodeType.PHYSICIAN.getCodeType());
		testPhysician2.setStrValue("Dr. Strange");

		List<ClaimPhysician> listPhysicians = new ArrayList<>();
		listPhysicians.add(testPhysician1);
		listPhysicians.add(testPhysician2);

		return listPhysicians;
	}

}
