package com.aia.cmic.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;

import org.apache.commons.collections.MultiMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.canonical.ClaimBenefitCanonical;
import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.BenefitDeterminationPaymentListForm;
import com.aia.cmic.model.BenefitDeterminationPaymentRefreshForm;
import com.aia.cmic.model.CMiCClaim;
import com.aia.cmic.model.Claim;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.rest.ClaimRest;
import com.aia.cmic.restservices.model.OutputTO;
import com.aia.cmic.services.CMiCMonitorService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.PartyService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.uam.Function;
import com.aia.cmic.util.SecurityUtil;

@Controller
@RequestMapping("/")
public class CMiCSimplyController {
	private static final Logger LOG = LoggerFactory.getLogger(CMiCSimplyController.class);
	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private ClaimService claimService;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private Case360Helper case360Helper;

	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;

	@Autowired
	private PartyService partyService;
	
	@Autowired
	private CMiCMonitorService cMiCMonitorService;

	private CommonDataService commonDataService;
	private CachingMasterDataHelper cachingHelper;

	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		this.commonDataService = commonDataService;
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}

	@RequestMapping(value = "/homeSimplify", method = RequestMethod.GET)
	public String openHomeDataEntry(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DATAENTRY_DATAENTRY_PRC)
				&& !SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DATAENTRY_MEDICAL_PRC)) {
			return "homeBlank";
		}
		//model.addAttribute("homeChartData", prepareChart(userInfoForm, CMiCUtil.retriveHomeDataEntryActvityList(userInfoForm)));
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeSimplify";
	}
	
}
