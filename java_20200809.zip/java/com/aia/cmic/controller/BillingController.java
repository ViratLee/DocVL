package com.aia.cmic.controller;

import static com.aia.cmic.util.CMiCUtil.transformToLookupList;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.entity.CommonCode;
import com.aia.cmic.model.BillingReconciliationSearchForm;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.NetworkService;
import com.aia.cmic.services.ProviderContactService;
import com.aia.cmic.services.ProviderDetailService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;

@Controller
@RequestMapping("/billing")
public class BillingController {
	private static final Logger LOG = LoggerFactory.getLogger(BillingController.class);
	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private ProviderDetailService providerDetailService;

	@Autowired
	private ProviderContactService providerContactService;

	@Autowired
	private CommonDataService commonDataService;

	@Autowired
	private NetworkService networkService;

	@RequestMapping(value = "/claimsBilling", method = RequestMethod.GET)
	public String init(ModelMap model) {
		LOG.debug("BillingController init");
		List<CommonCode> tmpLstMarkingId = commonDataService.getCommonCode("BillingStatus", "Claim");
		List<CommonCode> lstAiBillingStatus = commonDataService.getCommonCode("BillingStatus", "Claim");
		List<CommonCode> lstMarkingReason = commonDataService.getCommonCode("BillingDeclineReason", "Claim");
		Collections.sort(tmpLstMarkingId, new Comparator<CommonCode>() {
			@Override
			public int compare(CommonCode o1, CommonCode o2) {
				return o1.getCodeValue().compareTo(o2.getCodeValue());
			}
		});
		Collections.sort(lstMarkingReason, new Comparator<CommonCode>() {
			@Override
			public int compare(CommonCode o1, CommonCode o2) {
				return o1.getCodeValue().compareTo(o2.getCodeValue());
			}
		});
		Collections.sort(lstAiBillingStatus, new Comparator<CommonCode>() {
			@Override
			public int compare(CommonCode o1, CommonCode o2) {
				return o1.getCodeValue().compareTo(o2.getCodeValue());
			}
		});

		BillingReconciliationSearchForm form = new BillingReconciliationSearchForm();
		model.addAttribute("lstMarkingId", transformToLookupList(tmpLstMarkingId));
		model.addAttribute("lstAiBillingStatus", transformToLookupList(lstAiBillingStatus));
		model.addAttribute("lstMarkingReason", transformToLookupList(lstMarkingReason));
		model.addAttribute("form", form);

		return "claim/claimsBilling";
	}

	@RequestMapping(value = "/directCredit", method = RequestMethod.GET)
	public String openDirectCredit(ModelMap model) {
		return "payment/directCredit";
	}
	
	@RequestMapping(value = "/documentRecord", method = RequestMethod.GET)
	public String openDocumentRecord(ModelMap model) {
		return "payment/documentRecord";
	}

}
