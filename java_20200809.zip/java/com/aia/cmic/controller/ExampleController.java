package com.aia.cmic.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.entity.Provider;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.services.ProviderService;

@Controller
@RequestMapping("/policy")
public class ExampleController {

	private SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");

	@Autowired
	private ProviderService providerService;

	@RequestMapping(value = "/searchPolicy.html", method = RequestMethod.GET)
	public String getSearchPolicyPage(ModelMap model) {
		model.addAttribute("todayDate", df.format(new Date()));
		return "policy/searchPolicy";
	}

	@RequestMapping(value = "/index.html", method = RequestMethod.GET)
	public String getIndex(ModelMap model) {
		model.addAttribute(
				"someVariable",
				"[{text: \"DATA ENTRY\", imageUrl: \"image/dashboard-menu.png\", cssClass: \"active\", url: \"#\"}, {text: \"WORK QUE MONITOR\", imageUrl: \"image/myclaims-menu.png\", cssClass: \"active\", url: \"#\"}, text: \"CLAIM ENQUIRY\", imageUrl: \"image/search-2ndg.png\", cssClass: \"active\", url: \"#\"]");
		return "index";
	}

	@RequestMapping(value = "/home.html", method = RequestMethod.GET)
	public String openHome(ModelMap model) {
		List<Provider> data = new ArrayList<>(providerService.getProvider(""));
		List<Lookup> lstLookup = new ArrayList<>();
		for (Provider provider : data) {
			Lookup lookup = new Lookup();
			lookup.setKey(provider.getProviderId().toString());
			lookup.setValue(provider.getProviderCode() + " - " + provider.getProviderNameThai());
			lstLookup.add(lookup);
		}
		model.addAttribute("aaa", lstLookup);
		return "policy/home";
	}
}
