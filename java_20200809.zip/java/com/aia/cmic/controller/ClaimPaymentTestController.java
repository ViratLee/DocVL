package com.aia.cmic.controller;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Date;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.Claim;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.soap.uam.ArrayOfUserAuthForm;
import com.aia.cmic.repository.soap.uam.UserAuthForm;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimPaymentService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.SettlementService;
import com.aia.cmic.uam.SecurityLevel;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimStatus;
import com.aia.cmic.util.ClaimCalculationEnum.ProcessStatus;

@Controller
@RequestMapping("/claimPaymentTest")
public class ClaimPaymentTestController {

	@Autowired
	ClaimService claimService;

	@Autowired
	ClaimRepository claimRepository;

	@Autowired
	@Qualifier("ClaimPaymentServiceImpl")
	ClaimPaymentService claimPaymentService;
	
	@Autowired
	SettlementService settlementService;

	@RequestMapping(value = "/allocatePayment", method = RequestMethod.GET)
	@ResponseBody
	public String allocatePayment(ServletRequest request,
			@RequestParam(required = true) Long claimId,
			@RequestParam(defaultValue = "ALLOCATE_PAYMENT", required = false) String api,
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(defaultValue = "false" , required = false) Boolean rollbackFlag) {
		UserInfoForm userInfoForm = new UserInfoForm();
		//infoForm.setUserId("test");
		
		userInfoForm = new UserInfoForm();
		userInfoForm.setUserAuthForm(new ArrayOfUserAuthForm());
		UserAuthForm userAuthForm = new UserAuthForm();


		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DP");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DSK");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		
		//infoForm.setUserId("test");
		HttpServletRequest hsr = (HttpServletRequest) request;
		if(hsr.getUserPrincipal() != null ) {
			userInfoForm.setUserId(hsr.getUserPrincipal().getName());
		} else {
			userInfoForm.setUserId("asnpac0");
		}
		userInfoForm.setUserName("Bypass UAM");

		try {
			ClaimCanonical claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);
			if (!StringUtils.isEmpty(api) && api.equalsIgnoreCase("RESERVE_CLAIM")) {
				claimPaymentService.reserveClaim(claimCanonical, userInfoForm);

			} else if (!StringUtils.isEmpty(api) && api.equalsIgnoreCase("CANCEL_CLAIM")) {
				claimPaymentService.cancelClaim(claimCanonical, userInfoForm, rollbackFlag);
			} else {

				Claim claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
				claim.setClaimStatus(ClaimStatus.SETTLEMENT_IN_PROGRESS.getValue());
				claim.setProcessStatus(ProcessStatus.ASSESSMENT_COMPLETE.getValue());
				claim.setLastModifiedBy("test");
				claim.setLastModifiedDt(new Date());
				claimRepository.updateClaim(claim);

				claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
				BeanUtils.copyProperties(claim, claimCanonical.getClaim());

				// allocate
				claimPaymentService.allocateBenefitPayment(claimCanonical, userInfoForm);
				claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}

		return "OK";
	}
	
	

	@RequestMapping(value = "/allocatePaymentWithSettlement", method = RequestMethod.GET)
	@ResponseBody
	public String allocatePaymentWithSettlement(ServletRequest request,
			@RequestParam(required = true) Long claimId,
			@RequestParam(defaultValue = "ALLOCATE_PAYMENT", required = false) String api,
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(defaultValue = "false" , required = false) Boolean rollbackFlag) {
		
		UserInfoForm userInfoForm = new UserInfoForm();
		//infoForm.setUserId("test");
		
		userInfoForm = new UserInfoForm();
		userInfoForm.setUserAuthForm(new ArrayOfUserAuthForm());
		UserAuthForm userAuthForm = new UserAuthForm();


		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DP");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DSK");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		
		//infoForm.setUserId("test");
		HttpServletRequest hsr = (HttpServletRequest) request;
		if(hsr.getUserPrincipal() != null ) {
			userInfoForm.setUserId(hsr.getUserPrincipal().getName());
		} else {
			userInfoForm.setUserId("asnpac0");
		}
		userInfoForm.setUserName("Bypass UAM");

		try {
			ClaimCanonical claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);
			if (!StringUtils.isEmpty(api) && api.equalsIgnoreCase("RESERVE_CLAIM")) {
				claimPaymentService.reserveClaim(claimCanonical, userInfoForm);

			} else if (!StringUtils.isEmpty(api) && api.equalsIgnoreCase("CANCEL_CLAIM")) {
				claimPaymentService.cancelClaim(claimCanonical, userInfoForm, rollbackFlag);
			} else {

				Claim claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
				claim.setClaimStatus(ClaimStatus.SETTLEMENT_IN_PROGRESS.getValue());
				claim.setProcessStatus(ProcessStatus.ASSESSMENT_COMPLETE.getValue());
				claim.setLastModifiedBy("test");
				claim.setLastModifiedDt(new Date());
				claimRepository.updateClaim(claim);

				claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
				BeanUtils.copyProperties(claim, claimCanonical.getClaim());

				// allocate
				claimPaymentService.allocateBenefitPayment(claimCanonical, userInfoForm);
				claim = claimRepository.findClaimByPrimaryKey(claimCanonical.getClaim().getClaimId());
				
//				 claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);
		    	 settlementService.settleClaim(companyId, claimCanonical, userInfoForm);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}

		return "OK";
	      
	}

	public static void main(String args[]){
		
		System.out.println("Detecting network interfaces...") ;
		
		try {
			InetAddress loopback = InetAddress.getLoopbackAddress() ;
			dump("Loopback", loopback) ;
		} catch (Throwable t) {
			System.out.println("Unable to get loopback address") ;
			t.printStackTrace(); 
		}
		
		try {
			InetAddress loopback = InetAddress.getLocalHost() ;
			dump("Localhost", loopback) ;
		} catch (Throwable t) {
			System.out.println("Unable to get Locahost address") ;
			t.printStackTrace(); 
		}
		
		try {
			InetAddress loopback = InetAddress.getByName("0.0.0.0") ;
			dump("0.0.0.0", loopback) ;
		} catch (Throwable t) {
			System.out.println("Unable to get 0.0.0.0 address") ;
			t.printStackTrace(); 
		}
	}



	private static void dump(String type, InetAddress addr) {

		String header = String.format("[%s] InetAddress", type) ;
		try{
			System.out.println(header + " = " + addr) ;
			System.out.println(header + ".isAnyLocalAddress = " + addr.isAnyLocalAddress()) ;
			System.out.println(header + ".isLinkLocalAddress = " + addr.isLinkLocalAddress()) ;
			System.out.println(header + ".isLoopbackAddress = " + addr.isLoopbackAddress()) ;
		} catch (Throwable t) {
			System.out.printf("[%s] Failed to list InetAddress details", type);
		}
		
		header = String.format("[%s] InetSocketAddress", type) ;
		try{
			InetSocketAddress inetSocketAddr = new InetSocketAddress(addr, 8080) ;
			System.out.println(header + " = " + inetSocketAddr) ;
			System.out.println(header + ".isUnresolved = " + inetSocketAddr.isUnresolved() );
		} catch (Throwable t) {
			System.out.printf("[%s] Failed to list InetSocketAddress details", type);
		}
		
	}
	
}
