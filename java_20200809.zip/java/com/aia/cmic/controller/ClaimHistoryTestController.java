package com.aia.cmic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.ClaimHistoryService;

@Controller
@RequestMapping("/claimHistoryTest")
public class ClaimHistoryTestController {

	@Autowired
	ClaimService claimService;
	
	@Autowired
	ClaimHistoryService claimHistoryService;
	
	
	@RequestMapping(value = "/claimHistory", method = RequestMethod.GET)
	@ResponseBody
	public String claimHistory(@RequestParam(required = false) String companyId, 
			@RequestParam(required = false) String insuredPartyId){
		
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		
		try{
			claimHistoryService.getHistoricClaimData(companyId, insuredPartyId);
		}catch(Exception e){
			e.printStackTrace();
			return ("ERROR {} : "+ e.getMessage());
		}
		
		
		return "OK";
	}
}


