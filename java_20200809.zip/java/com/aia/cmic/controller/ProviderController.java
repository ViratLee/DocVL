package com.aia.cmic.controller;

import static com.aia.cmic.util.CMiCUtil.transformToLookupList;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.entity.Physician;
import com.aia.cmic.entity.Provider;
import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.entity.ProviderDetail;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.Checkbox;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.model.PhysicianForm;
import com.aia.cmic.model.ProviderContactDetailForm;
import com.aia.cmic.model.ProviderContactDetailListForm;
import com.aia.cmic.model.ProviderForm;
import com.aia.cmic.model.ProviderSearchForm;
import com.aia.cmic.restservices.model.ProviderParam;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.NetworkService;
import com.aia.cmic.services.ProviderContactService;
import com.aia.cmic.services.ProviderDetailService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.util.CMiCProviderConst;
import com.aia.cmic.util.FormatUtil;

@Controller
@RequestMapping("/provider")
public class ProviderController {
	private static final Logger LOG = LoggerFactory.getLogger(ProviderController.class);
	private final static String AWARD = "award";
	private final static String CODINGUSED = "codingUsed";
	private final static String HOLDSERVICE = "holdService";
	private final static String MEDICALSPECIALTY = "medicalSpecialty";
	private final static String PUBLIC_INSURANCE = "publicInsurance";
	private final static String PRIVATE_INSURANCE = "privateInsurance";
	private final static String SERVICEPROVIDED = "serviceProvided";
	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private ProviderDetailService providerDetailService;

	@Autowired
	private ProviderContactService providerContactService;

	private CachingMasterDataHelper cachingHelper;

	@Autowired
	private NetworkService networkService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}

	@RequestMapping(value = "/providerList", method = RequestMethod.GET)
	public String openProviderList(ModelMap model) {
		ProviderSearchForm providerSearchForm = new ProviderSearchForm();
		model.addAttribute("providerSearchForm", providerSearchForm);
		return "provider/providerList";
	}

	@RequestMapping(value = "/providerDetail", method = RequestMethod.GET)
	public String initialProvider(ModelMap model) {
		LOG.debug("### initialProvider ###");
		List<MasterLookup> lstProviderWarningCode = cachingHelper.getProviderWarningCode();
		model.addAttribute("lstProviderWarningCode", lstProviderWarningCode);

		initialCheckboxForProvider(model, "");
		ProviderForm form = new ProviderForm();
		form.setCountry("66");

		model.addAttribute("form", form);
		return "provider/providerDetail";
	}

	@RequestMapping(value = "/providerDetail/{providerId}", method = RequestMethod.GET)
	public String openProvider(@PathVariable Long providerId, ModelMap model, @Context HttpServletRequest httpServletRequest) {
		LOG.debug("### openProvider ### : {} ", providerId);
		ProviderForm form = new ProviderForm();
		String providerCode = "";
		List<ProviderContactDetailListForm> list = new ArrayList<>();
		if (providerId != null) {
			Provider provider = providerService.getExistingProvider(providerId);
			if (provider != null) { // if not exist, return to empty form
				providerCode = provider.getProviderCode();
				List<ProviderDetail> providerDetails = new ArrayList<>(providerService.getExistingProviderDetail(provider.getProviderCode()));
				LOG.debug("### providerDetails size : {} ", providerDetails.size());

				List<ProviderContact> providerContacts = providerContactService.findProviderContactByProviderCode(provider.getProviderCode());
				ProviderContact providerContact = new ProviderContact();
				ProviderContactDetailForm providerContactDetailForm = new ProviderContactDetailForm();
				List<Long> providerContactId = new ArrayList<>();
				List<String> contactPoint = new ArrayList<>();
				List<String> telephone = new ArrayList<>();
				List<String> email = new ArrayList<>();
				List<String> fax = new ArrayList<>();
				for (ProviderContact tmp : providerContacts) {
					if ("Other".equals(FormatUtil.convertNull(tmp.getContactType()))) {
						//listForm = ;

						list.add(new ProviderContactDetailListForm(tmp));
						providerContactId.add(tmp.getProviderContactId());
						contactPoint.add(tmp.getFirstName());
						telephone.add(tmp.getPhoneNo1());
						email.add(tmp.getEmailAddress1());
						fax.add(tmp.getFaxNo1());
					} else {
						providerContact = tmp;
					}
				}
				providerContactDetailForm.setProviderCode(providerContact.getProviderCode());
				providerContactDetailForm.setContactPoint(contactPoint);
				providerContactDetailForm.setTelephone(telephone);
				providerContactDetailForm.setFax(fax);
				providerContactDetailForm.setEmail(email);
				form = new ProviderForm(provider, providerDetails, providerContact);
				form.setProviderContactDetailForm(providerContactDetailForm);
			}
		}
		List<MasterLookup> lstProviderWarningCode = cachingHelper.getProviderWarningCode();
		ProviderParam param = new ProviderParam();
		param.setProviderCode(providerCode);

		//	DataSourceResponse documentList = new DataSourceResponse(documentProvider, documentProvider.size());

		model.addAttribute("lstProviderWarningCode", lstProviderWarningCode);
		initialCheckboxForProvider(model, providerCode);
		LOG.debug("medicalInstitution : {}", form);
		model.addAttribute("form", form);
		//model.addAttribute("documentList", documentList);
		model.addAttribute("providerContactDetailForm", list);
		return "provider/providerDetail";
	}

	@RequestMapping(value = "/doctorList", method = RequestMethod.GET)
	public String openDoctorList(ModelMap model) {
		List<MasterLookup> lstMedialSpecial = cachingHelper.getSpecialy();
		model.addAttribute("lstMedialSpecial", lstMedialSpecial);
		return "provider/doctorList";
	}

	@RequestMapping(value = "/doctorDetail", method = RequestMethod.GET)
	public String initialDoctor(ModelMap model) {
		initialCheckboxForDoctor(model, "");
		PhysicianForm form = new PhysicianForm();
		model.addAttribute("form", form);
		initialComboboxForDoctor(model);
		return "provider/doctorDetail";
	}

	@RequestMapping(value = "/doctorDetail/{physicianId}", method = RequestMethod.GET)
	public String openDoctor(@PathVariable Long physicianId, ModelMap model) {
		PhysicianForm form = new PhysicianForm();
		String doctorCode = "";
		if (physicianId != null) {
			Physician physician = providerService.getExistingPhysician(physicianId);
			doctorCode = physician.getDoctorCode();
			ProviderContact providerContact = providerContactService.findProviderContractByDoctorCodeAndContactType(doctorCode, "PRIMARY");
			form = new PhysicianForm(physician, providerContact);
		}
		initialCheckboxForDoctor(model, doctorCode);
		model.addAttribute("form", form);
		initialListView(form, doctorCode);
		initialComboboxForDoctor(model);
		return "provider/doctorDetail";
	}

	@RequestMapping(value = "/networkList", method = RequestMethod.GET)
	public String openNetworkManagement(ModelMap model) {
		LOG.debug("### openNetworkManagement ###");
		return "provider/network";
	}

	private void initialComboboxForDoctor(ModelMap model) {
		List<Lookup> lstPracticeHospital = transformToLookupList(providerService.getProvider(""));
		List<MasterLookup> lstawardAccredition = cachingHelper.getAward();
		List<MasterLookup> lstWarningCode = cachingHelper.getPhysicianWarningCode();
		model.addAttribute("lstPracticeHospital", lstPracticeHospital);
		model.addAttribute("lstawardAccredition", lstawardAccredition);
		model.addAttribute("lstWarningCode", lstWarningCode);
	}

	private void initialListView(PhysicianForm form, String doctorCode) {
		List<ProviderDetail> providerDetails = new ArrayList<>();
		providerDetails = providerDetailService.findByDoctorCodeAndCodeName(doctorCode, CMiCProviderConst.ACCREDITATION);
		form.setAwardAndAccreditation(buildValueStringList(providerDetails));
		providerDetails = providerDetailService.findByDoctorCodeAndCodeName(doctorCode, CMiCProviderConst.PRACTICALHOSPITAL);
		form.setPracticeHospital(buildValueStringList(providerDetails));
		providerDetails = providerDetailService.findByDoctorCodeAndCodeName(doctorCode, CMiCProviderConst.CMICDORTORWARNINGCODE);
		form.setCmacWarningCode(buildValueStringList(providerDetails));
	}

	private List<String> buildValueStringList(List<ProviderDetail> providerDetails) {
		List<String> list = new ArrayList<>();
		for (ProviderDetail p : providerDetails) {
			list.add(p.getStrValue());
		}
		return list;
	}

	private void initialCheckboxForProvider(ModelMap model, String providerCode) {
		setCheckboxFromMasterLookup("lstAward", cachingHelper.getAward(), providerDetailService.findByProviderCodeAndCodeName(providerCode, AWARD), model);
		setCheckboxFromMasterLookup("lstCodingUsed", cachingHelper.getCodingUsed(), providerDetailService.findByProviderCodeAndCodeName(providerCode, CODINGUSED), model);
		setCheckboxFromMasterLookup("lstServiceProvided", cachingHelper.getServiceProvidedOrderByDesc(), providerDetailService.findByProviderCodeAndCodeName(providerCode, SERVICEPROVIDED), model);
		setCheckboxFromMasterLookup("lstMedicalSpecialty", cachingHelper.getMedicalSpecialtyOrderByDesc(), providerDetailService.findByProviderCodeAndCodeName(providerCode, MEDICALSPECIALTY), model);
		setCheckboxFromMasterLookup("lstPublicInsurance", cachingHelper.getPublicInsurance(), providerDetailService.findByProviderCodeAndCodeName(providerCode, PUBLIC_INSURANCE), model);
		setCheckboxFromMasterLookup("lstPrivateInsurance", cachingHelper.getPrivateInsurance(), providerDetailService.findByProviderCodeAndCodeName(providerCode, PRIVATE_INSURANCE), model);
		setCheckboxFromMasterLookup("lstHoldService", cachingHelper.getHoldService(), providerDetailService.findByProviderCodeAndCodeName(providerCode, HOLDSERVICE), model);
	}

	private void initialCheckboxForDoctor(ModelMap model, String doctorCode) {
		setCheckboxFromMasterLookup("lstServiceProvided", cachingHelper.getServiceProvidedOrderByDesc(),
				providerDetailService.findByDoctorCodeAndCodeName(doctorCode, CMiCProviderConst.SERVICEPROVIDED), model);
		setCheckboxFromMasterLookup("lstMedicalSpecialty", cachingHelper.getSpecialyOrderByDesc(), providerDetailService.findByDoctorCodeAndCodeName(doctorCode, CMiCProviderConst.MEDICALSPECIALTY),
				model);
		setCheckboxFromMasterLookup("lstHoldService", cachingHelper.getHoldService(), providerDetailService.findByDoctorCodeAndCodeName(doctorCode, CMiCProviderConst.HOLDSERVICE), model);
	}

	private void setCheckboxFromMasterLookup(String mappedName, List<MasterLookup> lookups, List<ProviderDetail> providerDetails, ModelMap model) {
		//LOG.debug("Logging :  {} :<> size : {} ", mappedName, commonCodes.size());

		List<Checkbox> list = new ArrayList<>();
		for (MasterLookup l : lookups) {
			Checkbox lookup = new Checkbox();
			lookup.setCode(l.getKey());
			lookup.setCode(l.getKey());
			lookup.setValue(l.getValue());
			lookup.setSelected(false);
			if (providerDetails != null) {
				if (providerDetails.size() > 0) {
					for (ProviderDetail providerDetail : providerDetails) {
						//LOG.debug("Key :  {}  & Check : {} ", commonCode.getCodeValue(), providerDetail.getStrValue());
						if (l.getKey().equals(providerDetail.getStrValue())) {
							lookup.setSelected(true);
							//LOG.debug("checked");
							break;
						}
					}
				}
			}
			list.add(lookup);
		}
		//LOG.debug("final {}", list.toString());

		model.addAttribute(mappedName, list);
	}

}
