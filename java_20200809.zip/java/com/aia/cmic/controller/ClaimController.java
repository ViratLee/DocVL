package com.aia.cmic.controller;

import static com.aia.cmic.util.CMiCUtil.getCommonCodeDesc;
import static com.aia.cmic.util.CMiCUtil.transformToLookupList;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.aia.cmic.canonical.ClaimBenefitCanonical;
import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.ClaimPolicyCanonical;
import com.aia.cmic.canonical.ClaimPolicyPlanCanonical;
import com.aia.cmic.entity.Aicode;
import com.aia.cmic.entity.BrokenBoneCode;
import com.aia.cmic.entity.CommonCode;
import com.aia.cmic.entity.ICD10Code;
import com.aia.cmic.entity.ICD9Code;
import com.aia.cmic.entity.Insured;
import com.aia.cmic.entity.Physician;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.Provider;
import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.entity.ProviderContractDetail;
import com.aia.cmic.entity.ProviderJoinProviderContact;
import com.aia.cmic.entity.ServiceItem;
import com.aia.cmic.exception.CMiCException;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.AgentInfo;
import com.aia.cmic.model.BenefitDetail;
import com.aia.cmic.model.BenefitLimit;
import com.aia.cmic.model.BenefitReimbursement;
import com.aia.cmic.model.BenefitSettlement;
import com.aia.cmic.model.BillingItem;
import com.aia.cmic.model.CMiCClaim;
import com.aia.cmic.model.CMiCClaimBenefit;
import com.aia.cmic.model.CMiCPartySnapshot;
import com.aia.cmic.model.CaseStatus;
import com.aia.cmic.model.Claim;
import com.aia.cmic.model.ClaimBenefitItem;
import com.aia.cmic.model.ClaimBrokenBone;
import com.aia.cmic.model.ClaimComment;
import com.aia.cmic.model.ClaimDeduct;
import com.aia.cmic.model.ClaimDiagnosisCode;
import com.aia.cmic.model.ClaimDiagnosisTest;
import com.aia.cmic.model.ClaimDocumentType;
import com.aia.cmic.model.ClaimHistorySearchCriteria;
import com.aia.cmic.model.ClaimInjuryArea;
import com.aia.cmic.model.ClaimPayment;
import com.aia.cmic.model.ClaimPhysician;
import com.aia.cmic.model.ClaimPlannedMedication;
import com.aia.cmic.model.ClaimPlannedSurgery;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyAccountNo;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.ClaimProcedureCode;
import com.aia.cmic.model.ClaimReferral;
import com.aia.cmic.model.ClaimSpecialist;
import com.aia.cmic.model.CommonCodeMaster;
import com.aia.cmic.model.ConsentResponse;
import com.aia.cmic.model.DataEntryPageSecurity;
import com.aia.cmic.model.DataSourceResponse;
import com.aia.cmic.model.EdiBillingItem;
import com.aia.cmic.model.EdiDoctor;
import com.aia.cmic.model.EdiLaboratory;
import com.aia.cmic.model.EdiOrderItem;
import com.aia.cmic.model.EdiProcedure;
import com.aia.cmic.model.EdiVitalSigns;
import com.aia.cmic.model.LimitDetail;
import com.aia.cmic.model.LimitReport;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.model.PartySearchForm;
import com.aia.cmic.model.PartySnapshot;
import com.aia.cmic.model.PolicyProductBenefitCOAST;
import com.aia.cmic.model.PolicyProductBenefitDetailCOAST;
import com.aia.cmic.model.ProviderSearchForm;
import com.aia.cmic.repository.ClaimBenefitItemRepository;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPaymentRepository;
import com.aia.cmic.repository.ClaimPolicyRepository;
import com.aia.cmic.repository.CommonCodeRepository;
import com.aia.cmic.repository.InsuredRepository;
import com.aia.cmic.repository.PolicyRepository;
import com.aia.cmic.repository.SystemConfigRepository;
import com.aia.cmic.repository.rest.response.policy.PolicyPerLife;
import com.aia.cmic.repository.rest.response.policy.retrievepolicydetail.RetrievePolicyDetailResponse;
import com.aia.cmic.repository.rest.response.policy.searchpolicyperlifebypartyid.SearchPolicyPerLifeByPartyIdResponse;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.restservices.model.ClaimInfoTO;
import com.aia.cmic.restservices.model.ConsentOutputTO;
import com.aia.cmic.restservices.model.ConsentTO;
import com.aia.cmic.restservices.model.Document;
import com.aia.cmic.restservices.model.DocumentType;
import com.aia.cmic.services.ClaimPaymentService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.EdiService;
import com.aia.cmic.services.PartyService;
import com.aia.cmic.services.PlanService;
import com.aia.cmic.services.PolicyService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SettlementService;
import com.aia.cmic.services.SuppressChequeService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.services.helper.ClaimHelper;
import com.aia.cmic.uam.Function;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.ClaimCalculationEnum.BusinessLine;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimStatus;
import com.aia.cmic.util.ClaimCalculationEnum.Eligibility;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.SecurityUtil;
import com.aia.cmic.workflow.Activity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.aia.cmic.repository.rest.response.party.Individual;
import com.aia.cmic.repository.rest.response.party.Party;

@Controller
@RequestMapping("/claim")
@SessionAttributes("cmicClaimBenefit")
public class ClaimController {
	private static final Logger LOG = LoggerFactory.getLogger(ClaimController.class);

	private static final String MSG_OPEN_BENEFIT_DETERMINATION_FAIL = "Open benefit determination [Case Id %s]  failed. [%s]";

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private PolicyRepository policyRepository;
	
	@Autowired
	private ClaimPaymentRepository claimPaymentRepository;

	@Autowired
	private ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Autowired
	private ClaimPolicyRepository claimPolicyRepository;

	@Autowired
	private InsuredRepository insuredRepository;

	private CommonDataService commonDataService;

	private CachingMasterDataHelper cachingHelper;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private ClaimService claimService;

	@Autowired
	private PartyService partyService;

	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;

	@Autowired
	private PlanService planService;

	@Autowired
	private ClaimHelper claimHelper;

	@Autowired
	private PolicyService policyService;

	@Autowired
	private SettlementService settlementService;

	@Autowired
	@Qualifier("ClaimPaymentServiceImpl")
	ClaimPaymentService claimPaymentService;

	@Autowired
	private SuppressChequeService suppressChequeService;

	@Autowired
	private ClaimBenefitItemRepository claimBenefitItemRepository;

	@Autowired
	private EdiService ediService;
	
	@Autowired
	private Case360Helper case360Helper;
	
	@Autowired
	private SystemConfigRepository systemConfigRepository;
	
	@Autowired
	private CommonCodeRepository commonCodeRepository;
	
	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		this.commonDataService = commonDataService;
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}

	private String getICD9Desc(String strIn) {
		if (strIn != null && strIn.length() > 0) {
			ICD9Code icd9Code = commonDataService.findICD9CodeByICD9CodeAndICDSubCode(strIn);
			if (icd9Code == null) {
				LOG.info("icd9Code {} not found.", strIn);
				return "";
			} else {
				return icd9Code.getIcd9Code() + "." + icd9Code.getIcdSubCode() + " - " + icd9Code.getSubCodeLongDesc();
			}

		} else {
			return "";
		}
	}

	private String getICD10Desc(String strIn) {
		if (strIn != null && strIn.length() > 0) {
			ICD10Code icd10Code = commonDataService.findICD10CodeByICD10CodeAndICDSubCode(strIn);
			if (icd10Code == null) {
				LOG.info("icd10Code {} not found.", strIn);
				return "";
			} else {
				return FormatUtil.convertNull(icd10Code.getIcd10Code()) + "." + FormatUtil.convertNull(icd10Code.getIcdSubCode()) + " - " + FormatUtil.convertNull(icd10Code.getSubCodeDesc());
			}

		} else {
			return "";
		}
	}

	//	private String getActivedICD10Desc(String strIn) {
	//		if (strIn != null && strIn.length() > 0) {
	//			ICD10Code icd10Code = commonDataService.findActivedICD9CodeByICD9CodeAndICDSubCode(strIn);
	//			if (icd10Code == null) {
	//				LOG.info("icd10Code {} not found.", strIn);
	//				return "";
	//			} else {
	//				return FormatUtil.convertNull(icd10Code.getIcd10Code()) + "." + FormatUtil.convertNull(icd10Code.getIcdSubCode()) + " - " + FormatUtil.convertNull(icd10Code.getSubCodeDesc());
	//			}
	//
	//		} else {
	//			return "";
	//		}
	//	}

	private String getPhysicianAsString(Physician obj) {
		if (obj != null) {
			return FormatUtil.convertNull(obj.getLicenseNo()) + " - " + FormatUtil.convertNull(obj.getFirstName()) + " " + FormatUtil.convertNull(obj.getLastName()) + " (" + CMiCUtil
					.getCommonCodeDesc(cachingHelper.findBlacklistInd(obj.getBlacklistInd())) + ")";
		} else {
			return "";
		}

	}

	private String getAICodeDesc(String strIn) {
		if (strIn != null && strIn.length() > 0) {
			Aicode aicode = commonDataService.getAicodeByPrimaryKey(strIn);
			return FormatUtil.convertNull(aicode.getAiCodeField()) + " - " + FormatUtil.convertNull(aicode.getCodeDesc()) + "(" + aicode.getAiPercentage() + "%)";
		} else {
			return "";
		}
	}

	private String getBrokenBoneCodeDesc(String strIn) {
		if (strIn != null && strIn.length() > 0) {
			BrokenBoneCode brokenBoneCode = commonDataService.findBrokenBoneCodeByPrimaryKey(strIn);
			return brokenBoneCode.getCodeDescThai() + " - " + brokenBoneCode.getBbPercentage() + "%";
		} else {
			return "";
		}
	}

	private void configGeneralSection(ModelMap model, boolean generalWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstSubmissionType = generalWritable ? cachingHelper.getSubmissionType() : null;
		if (!generalWritable) {
			String submissionType = getCommonCodeDesc(cachingHelper.findSubmissionType(claim.getSubmissionType()));
			claim.setSubmissionType(submissionType);
		}
		String channel = getCommonCodeDesc(cachingHelper.findChannel(claim.getChannel()));
		claim.setChannel(channel);
		model.addAttribute("phaseDesc", getCommonCodeDesc(cachingHelper.findPhase(claim.getPhase())));
		if (ClaimCalculationEnum.BusinessLine.GE.toString().equals(cmicClaim.getClaimCanonical().getClaim().getBusinessLine())) {
			if (cmicClaim.getSubmissionDate() == null) {
				cmicClaim.setSubmissionDate(cmicClaim.getClaimCanonical().getClaim().getReceivedDate());
			}
		}
		model.addAttribute("lstSubmissionType", lstSubmissionType);
	}

	private void configClaimantSection(ModelMap model, boolean claimantWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		if (claim.getRelationship() == null) {
			claim.setRelationship("I");
		}
		List<MasterLookup> lstRelationship = claimantWritable ? cachingHelper.getRelationship() : null;
		if (!claimantWritable) {
			String relationship = getCommonCodeDesc(cachingHelper.findRelationship(claim.getRelationship()));
			claim.setRelationship(relationship);
		}
		model.addAttribute("lstRelationship", lstRelationship);
	}

	private void configSubmissionSection(ModelMap model, boolean submissionWritable, CMiCClaim cmicClaim) throws Exception {
		AgentInfo agentInfo = new AgentInfo();
		if (cmicClaim != null) {
			if (cmicClaim.getClaimCanonical() != null) {
				if (cmicClaim.getClaimCanonical().getClaim() != null) {
					if (StringUtils.isNotBlank(cmicClaim.getClaimCanonical().getClaim().getAgentCodeServicing())) {
						agentInfo = partyService.getAgentInfoByAgentCode(cmicClaim.getClaimCanonical().getClaim().getAgentCodeServicing());
					} else {
						com.aia.cmic.model.Claim claim = claimService.findClaimByCaseId(cmicClaim.getClaimCanonical().getClaim().getCaseId());
						if (claim == null) {
							// populate agent from policy number using ODS data for OL policy only
							//if (!ClaimHelper.isCSPolicy(cmicClaim.getClaimCanonical().getClaim().getPolicyNo())) {
							if (BusinessLine.OL.toString().equals(cmicClaim.getClaimCanonical().getClaim().getBusinessLine())) {//|| // 
								//BusinessLine.GE.toString().equals(cmicClaim.getClaimCanonical().getClaim().getBusinessLine())) {
								List<String> lstPartyId = partyService.getPartyListByPolicy("1", cmicClaim.getClaimCanonical().getClaim().getPolicyNo());
								if (!"".equals(FormatUtil.convertNull(lstPartyId.get(1)))) {
									// get From servicing first, if null get from writing
									agentInfo = partyService.getAgentInfoByPartyId(lstPartyId.get(1));
								} else {
									agentInfo = partyService.getAgentInfoByPartyId(lstPartyId.get(0));
								}
							}
						} else {
							agentInfo = new AgentInfo(claim);
						}
						if ("".equals(FormatUtil.convertNull(agentInfo.getAgentCode()))) {
							agentInfo = partyService.getAgentInfoByAgentCode(cmicClaim.getClaimCanonical().getClaim().getAgentCodeServicing());
						}
					}

					// Special logic to get agentInfo from COAST
					//if (agentInfo.empty() && ClaimHelper.isCSPolicy(cmicClaim.getClaimCanonical().getClaim().getPolicyNo())) {
					if (agentInfo.empty() && BusinessLine.CS.toString().equals(cmicClaim.getClaimCanonical().getClaim().getBusinessLine())) {
						agentInfo = claimService.populateAgentInfoFromCOAST(model, cmicClaim.getClaimCanonical().getClaim().getCompanyId(), cmicClaim.getClaimCanonical().getClaim(), agentInfo);
					}

					cmicClaim.getClaimCanonical().getClaim().setSubmissionAgencyLeaderName(agentInfo.getAgencyLeader());
					cmicClaim.getClaimCanonical().getClaim().setSubmissionAgencyName(agentInfo.getAgencyName());
					cmicClaim.getClaimCanonical().getClaim().setSubmissionAgentName(agentInfo.getAgentName());
					cmicClaim.getClaimCanonical().getClaim().setSubmissionOfficeName(agentInfo.getAgencyGaOfficeName());
					cmicClaim.getClaimCanonical().getClaim().setAgencyCodeServicing(agentInfo.getAgencyCode());
					cmicClaim.getClaimCanonical().getClaim().setAgencyOfficeCodeServicing(agentInfo.getAgencyGaOfficeCode());
					cmicClaim.getClaimCanonical().getClaim().setAgentCodeServicing(agentInfo.getAgentCode());

					if (!(BusinessLine.OL.toString().equals(cmicClaim.getClaimCanonical().getClaim().getBusinessLine()) || BusinessLine.PA.toString().equals(cmicClaim.getClaimCanonical().getClaim().getBusinessLine()))) {
						agentInfo.setBbl("N");
						agentInfo.setMdrt(null);
					}
				}
			}
		}
		LOG.debug("[caseDataEntry] : AgentInfo : {}", agentInfo.toString());
		model.addAttribute("agentInfo", agentInfo);

	}

	private void configPaymentSection(ModelMap model, boolean paymentWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstPaymentMethod = cachingHelper.getClaimPaymentMethod();
		List<MasterLookup> lstPaymentSequence = paymentWritable ? cachingHelper.getPaymentSeq() : null;
		if (!paymentWritable) {
			String paymentSeq = getCommonCodeDesc(cachingHelper.findPaymentSeq(claim.getPaymentSeq()));
			claim.setPaymentSeq(paymentSeq);
		}
		model.addAttribute("lstPaymentMethod", lstPaymentMethod);
		model.addAttribute("lstPaymentSequence", lstPaymentSequence);
	}

	private void configProviderSection(ModelMap model, boolean providerWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstClassOfBed = providerWritable ? cachingHelper.getClassOfBed() : null;

		Provider medicalInstitute = null, overseaMedicalInstitute = null;
		String providerType = "";
		String providerCode = cmicClaim.getClaimCanonical().getClaim().getProviderCode();

		Provider provider = null;
		if (FormatUtil.haveValue(providerCode)) {
			provider = providerService.getExistingProvider(providerCode);
		}

		if (provider != null) {
			providerType = getCommonCodeDesc(cachingHelper.findProviderType(provider.getProviderType()));
			List<ProviderContact> lstProviderContact = providerService.findProviderContactByProviderCode(provider.getProviderCode());
			if (lstProviderContact.size() > 0) {
				if (CommonCode.REGION_OVERSEA.equalsIgnoreCase(lstProviderContact.get(0).getRegion())) {
					overseaMedicalInstitute = provider;
				} else {
					medicalInstitute = provider;
				}
			}
		}

		if (providerWritable) {
			for (ClaimPhysician claimPhysician : cmicClaim.getClaimCanonical().getPhysicians()) {
				if (claimPhysician != null) {
					Physician physician = providerService.getExistingPhysician(claimPhysician.getStrValue());
					if (physician != null) {
						claimPhysician.setCodeType(physician.getLicenseNo());
					}
				}
			}

			for (ClaimSpecialist claimSpecialist : cmicClaim.getClaimCanonical().getSpecialists()) {
				if (claimSpecialist != null) {
					Physician specialist = providerService.getExistingPhysician(claimSpecialist.getStrValue());
					if (specialist != null) {
						claimSpecialist.setCodeType(specialist.getLicenseNo());
					}
				}
			}

			for (ClaimReferral claimReferral : cmicClaim.getClaimCanonical().getReferrals()) {
				if (claimReferral != null) {
					Physician referral = providerService.getExistingPhysician(claimReferral.getStrValue());
					if (referral != null) {
						claimReferral.setCodeType(referral.getLicenseNo());
					}
				}
			}
		} else {
			for (ClaimPhysician claimPhysician : cmicClaim.getClaimCanonical().getPhysicians()) {
				Physician physician = providerService.getExistingPhysician(claimPhysician.getStrValue());
				if (physician != null) {
					claimPhysician.setCodeType(getPhysicianAsString(physician));
				}
			}

			for (ClaimSpecialist claimSpecialist : cmicClaim.getClaimCanonical().getSpecialists()) {
				Physician physician = providerService.getExistingPhysician(claimSpecialist.getStrValue());
				if (physician != null) {
					claimSpecialist.setCodeType(getPhysicianAsString(physician));
				}
			}

			for (ClaimReferral claimReferral : cmicClaim.getClaimCanonical().getReferrals()) {
				Physician physician = providerService.getExistingPhysician(claimReferral.getStrValue());
				if (physician != null) {
					claimReferral.setCodeType(getPhysicianAsString(physician));
				}
			}

			String classOfBed = getCommonCodeDesc(cachingHelper.findClassOfBed(claim.getClassOfBed()));
			claim.setClassOfBed(classOfBed);
		}

		model.addAttribute("lstClassOfBed", lstClassOfBed);
		model.addAttribute("medicalInstitute", medicalInstitute);
		model.addAttribute("overseaMedicalInstitute", overseaMedicalInstitute);
		model.addAttribute("providerType", providerType);
		model.addAttribute("providerName", provider != null ? provider.getProviderNameThai() : "");
	}

	private void configServiceItemSection(ModelMap model, boolean serviceItemWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstCurrency = serviceItemWritable ? cachingHelper.getCurrencyCode() : null;
		if (!serviceItemWritable) {
			String origCurrency = getCommonCodeDesc(cachingHelper.findCurrencyCode(claim.getOrigCurrency()));
			claim.setOrigCurrency(origCurrency);
			String convCurrency = getCommonCodeDesc(cachingHelper.findCurrencyCode(claim.getConvCurrency()));
			claim.setConvCurrency(convCurrency);
		}

		// 1.1. Process on billing Item from ABBYY scan
		if (!FormatUtil.IsEmptyWithTrim(claim.getProviderCode()) && claimHelper.isEnableProviderCodeWithABBYY(claim.getProviderCode()) && cmicClaim.getClaimCanonical().getBenefitItems().size() == 0) {
			ArrayList<String[]> abbyyBillingItems = ExtractBillingItems(cmicClaim.getBillingItem());

			if (abbyyBillingItems.size() > 0) {
				for (String[] billingItem : abbyyBillingItems) {
					ClaimBenefitItem claimBenefitItem = new ClaimBenefitItem();
					claimBenefitItem.setServiceCatId(billingItem[0]);
					claimBenefitItem.setPresentedAmt(FormatUtil.convertBigDecimal(billingItem[1]));
					claimBenefitItem.setPresentedDiscountAmt(FormatUtil.convertBigDecimal(billingItem[2]));
					if (!BigDecimal.ZERO.equals(FormatUtil.convertBigDecimal(billingItem[1]))) {
						try {
							claimBenefitItem.setPresentedPercentage(FormatUtil.convertBigDecimal(billingItem[2]).divide(FormatUtil.convertBigDecimal(billingItem[1]), 2, RoundingMode.HALF_UP).multiply(new BigDecimal(100)));
						} catch (java.lang.ArithmeticException e) {
							claimBenefitItem.setPresentedPercentage(new BigDecimal(0));
						}

					}
					cmicClaim.getClaimCanonical().getBenefitItems().add(claimBenefitItem);
				}
			}
		}

		// 1.2. Default billing items
		if (cmicClaim.getClaimCanonical().getBenefitItems().size() == 0) {
			//in ODS case, if benefit has no billing, will default to 2.6
			if (!serviceItemWritable && cmicClaim.getClaimCanonical().getClaim().getBusinessLine().startsWith("ODS")) {
				ClaimBenefitItem claimBenefitItem = new ClaimBenefitItem();
				claimBenefitItem.setServiceCatId("2.6");
				claimBenefitItem.setPresentedAmt(new BigDecimal(1));
				claimBenefitItem.setPresentedDiscountAmt(new BigDecimal(0));
				claimBenefitItem.setPresentedPercentage(new BigDecimal(0));
				cmicClaim.getClaimCanonical().getBenefitItems().add(claimBenefitItem);
			} else {
				for (ServiceItem serviceItem : commonDataService.getDefaultServiceItem()) {
					ClaimBenefitItem claimBenefitItem = new ClaimBenefitItem();
					claimBenefitItem.setServiceCatId(serviceItem.getServiceCatId());
					claimBenefitItem.setPresentedAmt(new BigDecimal(0));
					claimBenefitItem.setPresentedDiscountAmt(new BigDecimal(0));
					claimBenefitItem.setPresentedPercentage(new BigDecimal(0));
					cmicClaim.getClaimCanonical().getBenefitItems().add(claimBenefitItem);
				}
			}
		}

		List<BillingItem> billingItems = new ArrayList<>();
		for (ClaimBenefitItem claimBenefitItem : cmicClaim.getClaimCanonical().getBenefitItems()) {
			BillingItem billingItem = new BillingItem();
			ServiceItem serviceItem = commonDataService.getServiceItem(claimBenefitItem.getServiceCatId());
			if (serviceItem == null) {
				LOG.info("serviceItem {} not found.", claimBenefitItem.getServiceCatId());
				continue;
			}
			billingItem.setClaimBenefitItemId(claimBenefitItem.getClaimBenefitItemId());
			Lookup serviceCatId = new Lookup();
			serviceCatId.setKey(serviceItem.getServiceCatId());
			serviceCatId.setValue(serviceItem.getServiceCatId() + " - " + serviceItem.getServiceItemDesc() + " " + serviceItem.getServiceItemDescThai());
			billingItem.setServiceCatId(serviceCatId);
			billingItem.setSeqNo(serviceItem.getSeqNo());
			billingItem.setPresentedAmt(claimBenefitItem.getPresentedAmt());
			billingItem.setPresentedDiscountAmt(claimBenefitItem.getPresentedDiscountAmt());
			billingItem.setPresentedPercentage(claimBenefitItem.getPresentedPercentage());
			billingItem.setNetAmt(claimBenefitItem.getPresentedAmt().subtract(FormatUtil.convertBigDecimal(claimBenefitItem.getPresentedDiscountAmt())));
			ProviderContractDetail providerContractDetail = providerService.getProviderContractDetail(cmicClaim.getClaimCanonical().getClaim().getProviderCode(), new Date(),
					serviceItem.getServiceCatId());
			if (providerContractDetail != null) {
				billingItem.setDiscountOnListPrice(providerContractDetail.getDiscountOnListPrice());
			}
			billingItems.add(billingItem);
		}
		Collections.sort(billingItems, new Comparator<BillingItem>() {
			@Override
			public int compare(BillingItem o1, BillingItem o2) {
				int result = 0;
				if (o1.getSeqNo() == null && o2.getSeqNo() == null) {
					result = 0;
				} else if (o1.getSeqNo() == null) {
					result = -1;
				} else if (o2.getSeqNo() == null) {
					result = 1;
				} else {
					result = o1.getSeqNo().compareTo(o2.getSeqNo());
				}
				return result;
			}
		});
		model.addAttribute("lstCurrency", lstCurrency);
		model.addAttribute("billingItems", billingItems);
	}

	public static ArrayList<String[]> ExtractBillingItems(String billingItems) {
		ArrayList<String[]> results = new ArrayList<String[]>();
		if (billingItems != null) {
			String[] billingItem = billingItems.split(";");
			for (String record : billingItem) {
				String[] result = record.split(",");
				results.add(result);
			}
		}
		return results;
	}

	private void configCauseOfTreatmentSection(ModelMap model, boolean causeOfTreatmentWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstTypeOfTreatment = causeOfTreatmentWritable ? cachingHelper.getTreatmentType() : null;
		List<MasterLookup> lstCauseOfTreatment = causeOfTreatmentWritable ? cachingHelper.getCauseOfTreatment() : null;
		if (!causeOfTreatmentWritable) {
			String treatmentType = getCommonCodeDesc(cachingHelper.findTreatmentType(claim.getTreatmentType()));
			claim.setTreatmentType(treatmentType);
			String causeOfTreatment = getCommonCodeDesc(cachingHelper.findCauseOfTreatment(claim.getCauseOfTreatment()));
			claim.setCauseOfTreatment(causeOfTreatment);
		}
		model.addAttribute("lstTypeOfTreatment", lstTypeOfTreatment);
		model.addAttribute("lstCauseOfTreatment", lstCauseOfTreatment);
	}

	private void configDetailOfAccidentSection(ModelMap model, boolean detailOfAccidentWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstPlace = detailOfAccidentWritable ? cachingHelper.getPlace() : null;
		List<MasterLookup> lstLevelOfConsciousness = detailOfAccidentWritable ? cachingHelper.getLevelOfConsciousness() : null;
		if (!detailOfAccidentWritable) {
			String accidentPlace = getCommonCodeDesc(cachingHelper.findPlace(claim.getAccidentPlace()));
			claim.setAccidentPlace(accidentPlace);
			String levelOfConsciousness = getCommonCodeDesc(cachingHelper.findLevelOfConsciousness(claim.getLevelOfConsciousness()));
			claim.setLevelOfConsciousness(levelOfConsciousness);
			String causeOfInjury = getICD10Desc(claim.getCauseOfInjury());
			claim.setCauseOfInjury(causeOfInjury);
			for (ClaimInjuryArea claimInjuryArea : cmicClaim.getClaimCanonical().getInjuryAreas()) {
				claimInjuryArea.setCodeType(getICD10Desc(claimInjuryArea.getStrValue()));
			}
		}

		model.addAttribute("lstPlace", lstPlace);
		model.addAttribute("lstLevelOfConsciousness", lstLevelOfConsciousness);
	}

	private void configMedicalConditionSection(ModelMap model, boolean medicalConditionWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		if (medicalConditionWritable) {
			if (claim.getPrevDoctorName() != null && claim.getPrevDoctorName().length() > 0) {
				model.addAttribute("prevDoctorLicenseNo", providerService.getExistingPhysician(claim.getPrevDoctorName()).getLicenseNo());
			}

			if (claim.getReferralDoctorCode() != null && claim.getReferralDoctorCode().length() > 0) {
				claim.setReferralDoctorName(claim.getReferralDoctorCode());
				model.addAttribute("referralDoctorLicenseNo", providerService.getExistingPhysician(claim.getReferralDoctorCode()).getLicenseNo());
			}
		} else {
			if (claim.getPrevDoctorName() != null && claim.getPrevDoctorName().length() > 0) {
				claim.setPrevDoctorName(getPhysicianAsString(providerService.getExistingPhysician(claim.getPrevDoctorName())));
			}

			if (claim.getReferralDoctorCode() != null && claim.getReferralDoctorCode().length() > 0) {
				claim.setReferralDoctorName(getPhysicianAsString(providerService.getExistingPhysician(claim.getReferralDoctorCode())));
			}
		}
	}

	private void configDiagnosisSection(ModelMap model, boolean diagnosisWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<MasterLookup> lstDiagnosticTest = diagnosisWritable ? cachingHelper.getDiagnosticTest() : null;
		List<MasterLookup> lstPlannedTreatmentDrugAndMedication = diagnosisWritable ? cachingHelper.getDrugAndMedication() : null;
		List<MasterLookup> lstRoomClass = diagnosisWritable ? cachingHelper.getRoomType() : null;
		List<MasterLookup> lstHospitalizationReason = diagnosisWritable ? cachingHelper.getHospitalizationReason() : null;
		List<MasterLookup> lstICUAdmissionReason = diagnosisWritable ? cachingHelper.getIcuReason() : null;
		if (!diagnosisWritable) {
			String roomType = getCommonCodeDesc(cachingHelper.findRoomType(claim.getRoomType()));
			claim.setRoomType(roomType);

			String hospitalizationReason = getCommonCodeDesc(cachingHelper.findHospitalizationReason(claim.getHospitalizationReason()));
			claim.setHospitalizationReason(hospitalizationReason);

			for (ClaimDiagnosisTest claimDiagnosisTest : cmicClaim.getClaimCanonical().getDiagnosisTests()) {
				if (claimDiagnosisTest == null) {
					continue;
				}
				claimDiagnosisTest.setCodeType(getCommonCodeDesc(cachingHelper.findDiagnosticTest(claimDiagnosisTest.getStrValue())));
			}

			for (ClaimDiagnosisCode claimDiagnosisCode : cmicClaim.getClaimCanonical().getDiagnosisCodes()) {
				if (claimDiagnosisCode == null) {
					continue;
				}
				claimDiagnosisCode.setCodeType(getICD10Desc(claimDiagnosisCode.getStrValue()));
			}
			if (CollectionUtils.isNotEmpty(cmicClaim.getClaimCanonical().getDiagnosisCodes())) {
				sortDignosisCodes(cmicClaim.getClaimCanonical().getDiagnosisCodes());
			}
			for (ClaimProcedureCode claimProcedureCode : cmicClaim.getClaimCanonical().getProcedureCodes()) {
				if (claimProcedureCode == null) {
					continue;
				}
				claimProcedureCode.setCodeType(getICD9Desc(claimProcedureCode.getStrValue()));
			}

			for (ClaimPlannedMedication claimPlannedMedication : cmicClaim.getClaimCanonical().getClaimPlannedMedications()) {
				if (claimPlannedMedication == null) {
					continue;
				}
				claimPlannedMedication.setCodeType(getCommonCodeDesc(cachingHelper.findDrugAndMedication(claimPlannedMedication.getStrValue())));
			}

			for (ClaimPlannedSurgery claimPlannedSurgery : cmicClaim.getClaimCanonical().getClaimPlannedSurgerys()) {
				if (claimPlannedSurgery == null) {
					continue;
				}
				claimPlannedSurgery.setCodeType(getICD9Desc(claimPlannedSurgery.getStrValue()));
			}

			String icuReason = getCommonCodeDesc(cachingHelper.findIcuReason(claim.getIcuReason()));
			claim.setIcuReason(icuReason);
		} else {
			// filter only active icd10
			filterActivedDiagnosisCodes(cmicClaim);
		}
		model.addAttribute("lstDiagnosticTest", lstDiagnosticTest);
		model.addAttribute("lstPlannedTreatmentDrugAndMedication", lstPlannedTreatmentDrugAndMedication);
		model.addAttribute("lstRoomClass", lstRoomClass);
		model.addAttribute("lstHospitalizationReason", lstHospitalizationReason);
		model.addAttribute("lstICUAdmissionReason", lstICUAdmissionReason);
	}

	private void filterActivedDiagnosisCodes(CMiCClaim cmicClaim) {
		List<ClaimDiagnosisCode> activedDiagnosisCodes = new ArrayList<ClaimDiagnosisCode>();
		for (ClaimDiagnosisCode claimDiagnosisCode : cmicClaim.getClaimCanonical().getDiagnosisCodes()) {
			if (claimDiagnosisCode == null) {
				continue;
			}
			if (!FormatUtil.IsEmptyWithTrim(claimDiagnosisCode.getStrValue())) {
				boolean actived = commonDataService.isActivedICD10Code(claimDiagnosisCode.getStrValue());
				if (actived) {
					claimDiagnosisCode.setCodeType(getICD10Desc(claimDiagnosisCode.getStrValue()));
					activedDiagnosisCodes.add(claimDiagnosisCode);
				}
			}
		}
		sortDignosisCodes(activedDiagnosisCodes);
		cmicClaim.getClaimCanonical().setDiagnosisCodes(activedDiagnosisCodes);
	}

	private void sortDignosisCodes(List<ClaimDiagnosisCode> activedDiagnosisCodes) {
		Collections.sort(activedDiagnosisCodes, new Comparator<ClaimDiagnosisCode>() {
			@Override
			public int compare(ClaimDiagnosisCode o1, ClaimDiagnosisCode o2) {
				int result = 0;
				if (o1.getClaimSupplementId() == null && o2.getClaimSupplementId() == null) {
					result = 0;
				} else if (o1.getClaimSupplementId() == null) {
					result = -1;
				} else if (o2.getClaimSupplementId() == null) {
					result = 1;
				} else {
					result = o1.getClaimSupplementId().compareTo(o2.getClaimSupplementId());
				}
				return result;
			}
		});
	}

	private void configBenefitSection(ModelMap model, boolean benefitWritable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<Lookup> lstSurgicalTableAI = benefitWritable ? transformToLookupList(commonDataService.findAllAicode()) : null;
		List<MasterLookup> lstHbpType = benefitWritable ? cachingHelper.getHbpType() : null;
		List<MasterLookup> lstHSJDisease = benefitWritable ? cachingHelper.getDiseaseInd() : null;
		List<MasterLookup> lstMajorAccId = benefitWritable ? cachingHelper.getMajorAccId() : null;
		List<MasterLookup> lstCriticalIllness = benefitWritable ? cachingHelper.getCriticalIllness() : null;
		List<MasterLookup> lstAnesthesiaInd = benefitWritable ? cachingHelper.getAnesthesiaInd() : null;
		List<MasterLookup> lstMajorInjuryDetail = benefitWritable ? cachingHelper.getMajorInjuryDetail() : null;
		List<Lookup> lstBrokenBoneCode = benefitWritable ? transformToLookupList(commonDataService.findAllBrokenBoneCodes()) : null;
		if (!benefitWritable) {
			claim.setSurgicalPercentage(getAICodeDesc(claim.getSurgicalPercentage()));
			claim.setHbpType(getCommonCodeDesc(cachingHelper.findHbpType(claim.getHbpType())));
			claim.setDiseaseInd(getCommonCodeDesc(cachingHelper.findDiseaseInd(claim.getDiseaseInd())));
			claim.setMajorAccId(getCommonCodeDesc(cachingHelper.findMajorAccId(claim.getMajorAccId())));
			claim.setAnesthesiaInd(getCommonCodeDesc(cachingHelper.findAnesthesiaInd(claim.getAnesthesiaInd())));
			claim.setMajorInjuryDetail(getCommonCodeDesc(cachingHelper.findMajorInjuryDetail(claim.getMajorInjuryDetail())));
			for (ClaimBrokenBone claimBrokenBone : cmicClaim.getClaimCanonical().getBrokenBones()) {
				claimBrokenBone.setCodeType(getBrokenBoneCodeDesc(claimBrokenBone.getStrValue()));
			}
			String criticalIllNess = "";
			if (CollectionUtils.isNotEmpty(cmicClaim.getClaimCanonical().getClaimCriticalIllnesss())) {
				criticalIllNess = getCommonCodeDesc(cachingHelper.findCriticalIllness(cmicClaim.getClaimCanonical().getClaimCriticalIllnesss().get(0).getStrValue()));
			}
			claim.setClaimCriticalIllnesss(criticalIllNess);

		}
		model.addAttribute("lstSurgicalTableAI", lstSurgicalTableAI);
		model.addAttribute("lstHbpType", lstHbpType);
		model.addAttribute("lstHSJDisease", lstHSJDisease);
		model.addAttribute("lstMajorAccId", lstMajorAccId);
		model.addAttribute("lstCriticalIllness", lstCriticalIllness);
		model.addAttribute("lstAnesthesiaInd", lstAnesthesiaInd);
		model.addAttribute("lstMajorInjuryDetail", lstMajorInjuryDetail);
		model.addAttribute("lstBrokenBoneCode", lstBrokenBoneCode);
	}

	private void configCustomerProfileSection(ModelMap model, boolean customerProfileAvaliable, CMiCClaim cmicClaim) {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		if (customerProfileAvaliable) {
			claim.setClaimStatus(getCommonCodeDesc(cachingHelper.findClaimStatus(claim.getClaimStatus())));
			claim.setBillingDeclineReason(getCommonCodeDesc(cachingHelper.findBillingDeclineReason(claim.getBillingDeclineReason())));
		}
		
		if(claim.getAiInd() != null)
		{
			if(claim.getAiInd().equals("Y"))
			{
				claim.setAiInd("Y");
			}
			else
			{
				claim.setAiInd("N");
			}
		}
		
	}

	@SuppressWarnings("static-access")
	private void configBenefitDetailSection(ModelMap model, boolean benefitDetailAvaliable, CMiCClaim cmicClaim) throws Exception {
		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		List<BenefitDetail> lstBenefitDetail = new ArrayList<>();
		if (benefitDetailAvaliable) {
			BigDecimal reimbursementAmt = BigDecimal.ZERO;

			if (!claim.getBusinessLine().startsWith("ODS")) {
				List<BenefitReimbursement> reimbursementList = claimPaymentRepository.retrieveClaimPaymentApproveAmountByclaimNoAndOccurrence(claim.getClaimNo(), claim.getOccurrence());

				for (BenefitReimbursement benefitReimbursemen : reimbursementList) {
					reimbursementAmt = reimbursementAmt.add(benefitReimbursemen.getAmount());
				}
			}

			Map<String, ClaimPolicy> mapClaimPolicy = new HashMap<>();
			Map<String, BigDecimal> mapClaimPolicyPlan = new HashMap<>();
			for (ClaimPolicyCanonical claimPolicyCanonical : cmicClaim.getClaimCanonical().getClaimPolicies()) {
				mapClaimPolicy.put(claimPolicyCanonical.getClaimPolicy().getPolicyNo(), claimPolicyCanonical.getClaimPolicy());
				for (ClaimPolicyPlanCanonical claimPolicyPlanCanonical : claimPolicyCanonical.getClaimPolicyPlans()) {
					ClaimPolicyPlan claimPolicyPlan = claimPolicyPlanCanonical.getClaimPolicyPlan();

					if (claim.getBusinessLine().startsWith("ODS-MCS")) {
						mapClaimPolicyPlan.put(claimPolicyCanonical.getClaimPolicy().getPolicyNo().concat(claimPolicyPlan.getPlanNum()), claimPolicyPlan.getSumAssured());
					} else {
						mapClaimPolicyPlan.put(
								claimPolicyCanonical.getClaimPolicy().getPolicyNo().concat(claimPolicyPlan.getPlanId().toString())
										.concat(claimPolicyPlan.getPlanCoverageNo() == null ? "" : claimPolicyPlan.getPlanCoverageNo()),
								claimPolicyPlan.getSumAssured());
					}

				}
			}
			for (ClaimPayment claimPayment : cmicClaim.getClaimCanonical().getClaimPayments()) {
				BenefitDetail benefitDetail = new BenefitDetail();
				benefitDetail.setClaimNo(claimPayment.getClaimNo());
				benefitDetail.setOccurrence(claimPayment.getOccurrence());
				benefitDetail.setProductCode(claimPayment.getProductCode());
				benefitDetail.setClaimPaymentId(claimPayment.getClaimPaymentId());
				benefitDetail.setPolicyNo(claimPayment.getPolicyNo());
				benefitDetail.setEligibilityPolicyNo(claimPayment.getPolicyNo());
				benefitDetail.setPlanId(claimPayment.getPlanId());
				benefitDetail.setPayNonCoverItemInd(claimPayment.getPayNonCoverItemInd());
				benefitDetail.setShortfallAmt(claimPayment.getShortFallAmt());
				if (claimPayment.getPlanId() != null) {
					CommonCodeMaster insertRider = cachingHelper.findInsertRider(claimPayment.getPlanId().toString());
					if (insertRider == null) {
						benefitDetail.setPlanShortName(FormatUtil.convertNull(planService.getPlanShortNameByPlanId(claimPayment.getPlanId())));
					} else {
						benefitDetail.setPlanShortName(insertRider.getCodeDesc());
					}
					benefitDetail.setPlanCoverageNo(claimPayment.getPlanCoverageNo());

					if (claim.getBusinessLine().startsWith("ODS-MCS")) {
						benefitDetail.setSumAssured(mapClaimPolicyPlan.get(claimPayment.getPolicyNo().concat(claimPayment.getPlanNum())));
						String key = claimPayment.getPolicyNo().concat(claimPayment.getPlanNum());

					} else {
						benefitDetail.setSumAssured(mapClaimPolicyPlan.get(claimPayment.getPolicyNo().concat(claimPayment.getPlanId().toString())
								.concat(claimPayment.getPlanCoverageNo() == null ? "" : claimPayment.getPlanCoverageNo())));
					}

				} else {
					LOG.info("plan id is null");
				}

				CommonCodeMaster systemEligibility = cachingHelper.findSystemEligibility(claimPayment.getSystemEligibility());
				benefitDetail.setEligibility("");
				if (systemEligibility != null) {
					benefitDetail.setEligibility(systemEligibility.getCodeDesc());
				}
				CommonCodeMaster declineReason = cachingHelper.findDeclineReason(claimPayment.getDeclineReason());
				String reason = (declineReason != null) ? declineReason.getCodeDesc() : claimPayment.getDeclineReason();
				benefitDetail.setDeclineReason(reason);
				CommonCodeMaster payeeType = cachingHelper.findPayeeType(claimPayment.getPayeeType());
				if (payeeType != null) {
					benefitDetail.setPayee(payeeType.getCodeDesc());
				}
				BigDecimal newEligibleAmt = claimHelper.calculatedNewEligibleAmt(claimPayment, claimPayment.getEligibleAmt());
				if (claim.getBusinessLine().startsWith("ODS")) {
					reimbursementAmt = reimbursementAmt.add(claimPayment.getApprovedAmt());
				}
				benefitDetail.setSystemQuotation(newEligibleAmt);

				BigDecimal total = FormatUtil.convertBigDecimal(claimPayment.getApprovedAmt());
				if (total.compareTo(BigDecimal.ZERO) <= 0) {
					total = FormatUtil.convertBigDecimal(claimPayment.getAdjustedAmt()).compareTo(BigDecimal.ZERO) > 0 ? claimPayment.getAdjustedAmt() : claimPayment.getEligibleAmt();
				}

				benefitDetail.setTotal(total);
				benefitDetail.setCoInsurance(claimPayment.getCoPaymentPercent());
				benefitDetail.setAdjusted(claimPayment.getAdjustedAmt());
				CommonCodeMaster adjustReason = cachingHelper.findAdjustReason(claimPayment.getAdjustedReason());
				if (adjustReason != null) {
					benefitDetail.setAdjustedReason(adjustReason.getCodeDesc());
				}

				String remarks = "";
				for (ClaimBenefitItem claimBenefitItem : cmicClaim.getClaimCanonical().getBenefitItems()) {
					if (!StringUtils.isEmpty(claimBenefitItem.getRemark())) {
						remarks = claimBenefitItem.getRemark();
					}
				}

				ClaimPolicy claimPolicy = mapClaimPolicy.get(claimPayment.getPolicyNo());
				benefitDetail.setIsCS(claimHelper.isCSPolicy(claimPayment.getPolicyNo()));
				CommonCodeMaster claimDecision = cachingHelper.findEligibility(claimPayment.getEligibility());
				if (claimDecision != null) {
					benefitDetail.setClaimDecision(claimDecision.getCodeDesc());
				} else {
					//1.Check if it is CS
					if (benefitDetail.getIsCS()) {
						//2.Determine Decision
						if (reimbursementAmt != null) {
							if (reimbursementAmt.compareTo(new BigDecimal(0)) == 0) {
								benefitDetail.setClaimDecision(Eligibility.DECLINED.name());
								benefitDetail.setDeclineReason(remarks);
							} else if (reimbursementAmt.compareTo(new BigDecimal(0)) > 0) {
								benefitDetail.setClaimDecision(Eligibility.ACCEPTED.name());
							} else if (reimbursementAmt.compareTo(new BigDecimal(0)) < 0) {
								benefitDetail.setClaimDecision(Eligibility.ACCEPTED.name());
							}
						}
					}
				}
				if (claimPolicy != null) {
					benefitDetail.setBusinessLine(claimPolicy.getBusinessLine());
					if (!StringUtils.isEmpty(claimPolicy.getExclusion1() == null ? null : claimPolicy.getExclusion1().trim()) || !StringUtils
							.isEmpty(claimPolicy.getExclusion2() == null ? null : claimPolicy.getExclusion2().trim()) || !StringUtils.isEmpty(claimPolicy.getExclusion3() == null ? null : claimPolicy
									.getExclusion3().trim())) {
						benefitDetail.setExc("Y");
					} else {
						benefitDetail.setExc("N");
					}
					if (!StringUtils.isEmpty(claimPolicy.getImpairmentCode1() == null ? null : claimPolicy.getImpairmentCode1().trim()) || !StringUtils
							.isEmpty(claimPolicy.getImpairmentCode2() == null ? null : claimPolicy.getImpairmentCode2().trim()) || !StringUtils
									.isEmpty(claimPolicy.getImpairmentCode3() == null ? null : claimPolicy.getImpairmentCode3().trim())) {
						benefitDetail.setImp("Y");
					} else {
						benefitDetail.setImp("N");
					}
					benefitDetail.setCertNo(claimPolicy.getCertNo());
				}

				if (claim.getBusinessLine().startsWith("ODS-MCS")) {
					benefitDetail.setSuppressCheque(claimPayment.getSuppressChequeInd());
				}

				String productShortName = claimHelper.findProductShortNameByProductCode(benefitDetail.getBusinessLine(), claimPayment.getProductCode(), benefitDetail.getPlanShortName());
				benefitDetail.setProductShortName(productShortName);
				benefitDetail.setSettlementDate(claimPayment.getSettlementDate());
				benefitDetail.setLastModifiedDt(claimPayment.getLastModifiedDt());
				benefitDetail.setLastModifiedBy(claimPayment.getLastModifiedBy());

				com.aia.cmic.entity.ClaimPolicy claimPolicyEntitiy = claimPolicyRepository.findClaimPolicyByPolicyNoClaimNoAndOccurrence(claimPayment.getPolicyNo(), claimPayment.getClaimNo(), claimPayment.getOccurrence());
				if(claimPolicyEntitiy != null)
				{
					if(claimPolicyEntitiy.getConsentInd() != null && !claimPolicyEntitiy.getConsentInd().equals(""))
					{
						String consentDec = commonCodeRepository.findCommonDescByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_DATA_PRIVACY_CATEGORY,CMiCUtil.COMMON_CODE_DATA_PRIVACY_CODE_NAME,claimPolicyEntitiy.getConsentInd());
						benefitDetail.setDataPrivacyConsent(consentDec);
					}
					else
					{
						benefitDetail.setDataPrivacyConsent("Allowed");
					}
					
					if(claimPolicyEntitiy.getConsentDt() != null)
					{
						DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
				        String dateStr 		 = formatter.format(claimPolicyEntitiy.getConsentDt());
				        benefitDetail.setDataPrivacyConsentDate(dateStr);
					}
				}
				
				if(claimPayment.getAiEligibility() != null)
				{
					String aiDecisionDec = commonCodeRepository.findCommonDescByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_AI_DECISION_CATEGORY,
							CMiCUtil.COMMON_CODE_AI_DECISION_CODE_NAME,claimPayment.getAiEligibility());
					benefitDetail.setAiDecision(aiDecisionDec);
				}
				else
				{
					benefitDetail.setAiDecision("");
				}
				
				lstBenefitDetail.add(benefitDetail);
			}
			model.addAttribute("reimbursementAmt", reimbursementAmt);
		}
		Collections.sort(lstBenefitDetail, new Comparator<BenefitDetail>() {
			@Override
			public int compare(BenefitDetail o1, BenefitDetail o2) {
				int result = 0;
				if (o1.getBusinessLine() == null && o2.getBusinessLine() == null) {
					result = 0;
				} else if (o1.getBusinessLine() == null) {
					result = -1;
				} else if (o2.getBusinessLine() == null) {
					result = 1;
				} else {
					result = o1.getBusinessLine().compareTo(o2.getBusinessLine());

				}
				return result == 0 ? o1.getPolicyNo().compareTo(o2.getPolicyNo()) : result;
			}
		});
		String businessLine = "", policyNo = "", suppressChequeInd = "N";
		for (BenefitDetail benefitDetail : lstBenefitDetail) {
			if (benefitDetail.getBusinessLine() == null || businessLine.equals(benefitDetail.getBusinessLine())) {
				benefitDetail.setBusinessLine("");
			} else {
				businessLine = benefitDetail.getBusinessLine();
			}
			if (policyNo.equals(benefitDetail.getPolicyNo())) {
				benefitDetail.setPolicyNo("");
				
				benefitDetail.setDataPrivacyConsent("");
				benefitDetail.setDataPrivacyConsentDate("");
				
			} else {
				policyNo = benefitDetail.getPolicyNo();
				suppressChequeInd = suppressChequeService.findSuppressChequeByClaimNoOccurrencePolicy(cmicEnvironmentHelper.getCmicCompanyId(), claim.getClaimNo(), claim.getOccurrence(), policyNo);
			}
			if (!claim.getBusinessLine().startsWith("ODS-MCS")) {
				benefitDetail.setSuppressCheque(suppressChequeInd);
			}
			if (benefitDetail.getEligibility() == null) {
				benefitDetail.setEligibility("");
			}
			if (benefitDetail.getSumAssured() == null) {
				benefitDetail.setSumAssured(BigDecimal.valueOf(0));
			}
			if (benefitDetail.getAdjusted() == null) {
				benefitDetail.setAdjusted(BigDecimal.valueOf(0));
			}
				
		}
		model.addAttribute("lstBenefitDetail", lstBenefitDetail);
	}

	private void configCommentSection(ModelMap model, boolean commentWritable, CMiCClaim cmicClaim, UserInfoForm userInfoForm) {
		List<MasterLookup> lstClaimComment = cachingHelper.getCommentType();
		Map<String, String> mapClaimComment = new HashMap<>();
		for (MasterLookup l : lstClaimComment) {
			mapClaimComment.put(l.getKey(), l.getValue());
		}

		if (CMiCUtil.CMC_CS_SALE.equalsIgnoreCase(userInfoForm.getGroupId())) {
			List<Integer> lstRemoveAssessorCommentIdx = new ArrayList<>();
			for (int i = 0; i < cmicClaim.getClaimCanonical().getClaimComments().size(); i++) {
				ClaimComment claimComment = cmicClaim.getClaimCanonical().getClaimComments().get(i);
				if (claimComment.getClaimCommentId() != null && CMiCUtil.COMMENTTYPE_ASSESSOR_COMMENT.equals(claimComment.getCommentType())) {
					lstRemoveAssessorCommentIdx.add(i);
				}
			}

			Collections.reverse(lstRemoveAssessorCommentIdx);
			for (Integer index : lstRemoveAssessorCommentIdx) {
				cmicClaim.getClaimCanonical().getClaimComments().remove(index.intValue());
			}
		}

		List<ClaimComment> lstClaimCommentHistory = new ArrayList<>();
		List<Integer> lstRemoveIdx = new ArrayList<>();
		for (int i = 0; i < cmicClaim.getClaimCanonical().getClaimComments().size(); i++) {
			ClaimComment claimComment = cmicClaim.getClaimCanonical().getClaimComments().get(i);
			if (claimComment.getClaimCommentId() != null) {
				String commentType = mapClaimComment.get(claimComment.getCommentType());
				String otherType = StringUtils.isEmpty(claimComment.getCommentType()) ? "" : claimComment.getCommentType();
				claimComment.setCommentType(StringUtils.isEmpty(commentType) ? otherType : commentType);
			} else {
				lstClaimCommentHistory.add(claimComment);
				lstRemoveIdx.add(i);
			}
		}
		Collections.reverse(lstRemoveIdx);
		for (Integer index : lstRemoveIdx) {
			cmicClaim.getClaimCanonical().getClaimComments().remove(index.intValue());
		}

		if (lstClaimCommentHistory.size() == 0) {
			lstClaimCommentHistory.add(new ClaimComment());
		}

		List<ClaimComment> claimComments = cmicClaim.getClaimCanonical().getClaimComments();
		if (claimComments != null && claimComments.size() > 0) {
			Collections.sort(claimComments, new Comparator<com.aia.cmic.model.ClaimComment>() {
				@Override
				public int compare(com.aia.cmic.model.ClaimComment o1, com.aia.cmic.model.ClaimComment o2) {
					if (o1.getSeqNo() == null || o2.getSeqNo() == null) {
						if (o1.getCreatedDt() == null && o2.getCreatedDt() == null) {
							return 0;
						} else if (o1.getCreatedDt() == null) {
							return -1;
						} else if (o2.getCreatedDt() == null) {
							return 1;
						} else {
							return o1.getCreatedDt().compareTo(o2.getCreatedDt());
						}
					} else {
						if (o1.getSeqNo() == null) {
							return -1;
						} else if (o2.getSeqNo() == null) {
							return 1;
						} else {
							return o1.getSeqNo().compareTo(o2.getSeqNo());
						}
					}
				}
			});
		}

		model.addAttribute("lstClaimComment", commentWritable ? lstClaimComment : null);
		model.addAttribute("lstClaimCommentHistory", lstClaimCommentHistory);
	}

	@RequestMapping(value = "/caseDataEntry/{caseId}", method = RequestMethod.GET)
	public String openDataEntry(
			@PathVariable Long caseId,
			@RequestParam(name = "fromCaseId", required = false) Long fromCaseId,
			@RequestParam(name = "copyType", required = false) String copyType,
			ModelMap model,
			HttpServletRequest httpServletRequest) throws Exception {
		LOG.debug("new caseId: {}, from caseId:{} ", caseId, fromCaseId);
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
		CMiCClaim cmicClaim = retriveCMiCClaim(caseId, userInfoForm);

		Activity a = Activity.parseActivity(cmicClaim.getActivity());
		CaseStatus status = workflowService.getCaseStatus(caseId, userInfoForm);
		LOG.debug("openDataEntry caseId {} status {}", caseId, status.getState());
		DataEntryPageSecurity pageSecurity = null;
		if ((status.getState().equals(200) || status.getState().equals(210)) && (Activity.DATAENTRY.equals(a) || Activity.MEDICAL.equals(a))) {
			pageSecurity = setPageSecurityDataEntry(cmicClaim, fnSet, userInfoForm);
			if (("copyRemain").equals(copyType)) {
				Claim oldClaim = claimService.findClaimByCaseId(fromCaseId);
				List<ClaimBenefitItem> claimBenefitItems = claimPaymentService.findClaimPaymentWorkingForCopyRemain(oldClaim.getCompanyId(), oldClaim.getClaimNo(), oldClaim.getOccurrence());
				cmicClaim.getClaimCanonical().setBenefitItems(claimBenefitItems);
			}
			model.addAttribute("EDI", ediService.findAnyEdiDataByClaimNoAndOccurrence(cmicClaim.getClaimCanonical().getClaim().getClaimNo(), cmicClaim.getClaimCanonical().getClaim().getOccurrence()));
			model.addAttribute("screenTitle", "DATA ENTRY");
			return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	@RequestMapping(value = "/simplifySubmission/{caseId}", method = RequestMethod.GET)
	public String simplifySubmission(
			@PathVariable Long caseId,
			@RequestParam(name = "fromCaseId", required = false) Long fromCaseId,
			@RequestParam(name = "copyType", required = false) String copyType,
			ModelMap model,
			HttpServletRequest httpServletRequest) throws Exception {
		LOG.debug("new caseId: {}, from caseId:{} ", caseId, fromCaseId);
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
		CMiCClaim cmicClaim = retriveCMiCClaim(caseId, userInfoForm);

		Activity a = Activity.parseActivity(cmicClaim.getActivity());
		CaseStatus status = workflowService.getCaseStatus(caseId, userInfoForm);
		LOG.debug("openDataEntry caseId {} status {}", caseId, status.getState());
		DataEntryPageSecurity pageSecurity = null;
		if ((status.getState().equals(200) || status.getState().equals(210)) && (Activity.DATAENTRY.equals(a) || Activity.MEDICAL.equals(a) || Activity.OPD.equals(a))) {
			pageSecurity = setPageSecurityDataEntry(cmicClaim, fnSet, userInfoForm);
			if (("copyRemain").equals(copyType)) {
				Claim oldClaim = claimService.findClaimByCaseId(fromCaseId);
				List<ClaimBenefitItem> claimBenefitItems = claimPaymentService.findClaimPaymentWorkingForCopyRemain(oldClaim.getCompanyId(), oldClaim.getClaimNo(), oldClaim.getOccurrence());
				cmicClaim.getClaimCanonical().setBenefitItems(claimBenefitItems);
			}

			List<MasterLookup> lstPayeeType = cachingHelper.getPayeeType();
			List<MasterLookup> lstAdjustReason = cachingHelper.getAdjustReason();
			List<MasterLookup> lstDeclineReasonType = cachingHelper.getDeclineReason();
			List<MasterLookup> lstClaimDecisionType = cachingHelper.getEligibility();

			model.addAttribute("lstClaimDecisionType", lstClaimDecisionType);
			model.addAttribute("lstDeclineReasonType", lstDeclineReasonType);
			model.addAttribute("lstPayeeType", lstPayeeType);
			model.addAttribute("lstAdjustReason", lstAdjustReason);
			model.addAttribute("screenTitle", "DATA ENTRY");
			// Retrieve SubOfficeCode and SubOfficeName
			/*
			if (cmicClaim != null && cmicClaim.getClaimCanonical() != null && cmicClaim.getClaimCanonical().getClaim() != null) {
				if (cmicClaim.getClaimCanonical().getClaim().getBusinessLine() != null && "CS".equalsIgnoreCase(cmicClaim.getClaimCanonical().getClaim().getBusinessLine())) {
					if (cmicClaim.getClaimCanonical().getClaim().getBillDtTo() == null) {
						cmicClaim.getClaimCanonical().getClaim().setBillDtTo(new Date());
					}
					ClaimPolicy claimPolicy = policyService.retrieveSubOfficeFromCOAST(cmicClaim.getClaimCanonical().getClaim().getPolicyNo(), cmicClaim.getClaimCanonical().getClaim().getCertNo(),
							cmicClaim.getClaimCanonical().getClaim().getMemberId(), cmicClaim.getClaimCanonical().getClaim().getBillDtTo());
					cmicClaim.getClaimCanonical().getClaim().setSubOfficeCode(claimPolicy.getSubOfficeCode());
					cmicClaim.getClaimCanonical().getClaim().setSubOfficeName(claimPolicy.getSubOfficeName());
				}
			}
			*/
			return configSimpyfy(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	private String configSimpyfy(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest, CMiCClaim cmicClaim, UserInfoForm userInfoForm, DataEntryPageSecurity pageSecurity)
			throws Exception {

		Claim claim = cmicClaim.getClaimCanonical().getClaim();
		claimHelper.initClaimByPartyIdAndPolicyNo(claim, claim.getPartyId(), claim.getPolicyNo(), claim.getCertNo(), claim.getMemberId());
		configGeneralSection(model, pageSecurity.isGeneralWritable(), cmicClaim);
		configClaimantSection(model, pageSecurity.isClaimantWritable(), cmicClaim);
		configSubmissionSection(model, pageSecurity.isSubmissionWritable(), cmicClaim);
		configPaymentSection(model, pageSecurity.isPaymentWritable(), cmicClaim);
		configProviderSection(model, pageSecurity.isProviderWritable(), cmicClaim);
		configServiceItemSection(model, pageSecurity.isServiceItemWritable(), cmicClaim);
		configCauseOfTreatmentSection(model, pageSecurity.isCauseOfTreatmentWritable(), cmicClaim);
		configDetailOfAccidentSection(model, pageSecurity.isDetailOfAccidentWritable(), cmicClaim);
		configMedicalConditionSection(model, pageSecurity.isMedicalConditionWritable(), cmicClaim);
		configDiagnosisSection(model, pageSecurity.isDiagnosisWritable(), cmicClaim);
		configBenefitSection(model, pageSecurity.isBenefitWritable(), cmicClaim);
		configCustomerProfileSection(model, pageSecurity.isCustomerProfileAvaliable(), cmicClaim);
		configBenefitDetailSection(model, pageSecurity.isBenefitDetailAvaliable(), cmicClaim);
		configCommentSection(model, pageSecurity.isCommentWritable(), cmicClaim, userInfoForm);
		String gender = "";
		if ("1".equals(FormatUtil.convertNull(claim.getGender())) || "M".equals(FormatUtil.convertNull(claim.getGender()))) {
			gender = "Male";
		} else if ("2".equals(FormatUtil.convertNull(claim.getGender())) || "F".equals(FormatUtil.convertNull(claim.getGender()))) {
			gender = "Female";
		}
		//claim.setGender(getCommonCodeDesc(cachingHelper.findGender(claim.getGender())));
		claim.setGender(gender); // To avoid multiple value for gender, I changed to manaul fix value for it. 
		
		
		ConsentTO consentTO = new ConsentTO();
		consentTO.setPolicyNo(claim.getPolicyNo());
		//consentTO.setPolicyNo("M502909162");
		if(claim.getBusinessLine().equals("CS") || claim.getBusinessLine().equals("GE"))
		{
			consentTO.setSubOfficeCd(claim.getSubOfficeCode());
			if(claim.getBusinessLine().equals("GE"))
			{
				consentTO.setPolicySys(CMiCUtil.POLICY_SYS_GE);
				consentTO.setCertNo(claim.getCertNo());
				consentTO.setDepCd(claim.getDependentNo());
				consentTO.setPolicyNo(claim.getPolicyNo().substring(5, claim.getPolicyNo().length()));
			}
			else if(claim.getBusinessLine().equals("CS"))
			{
				consentTO.setPolicySys(CMiCUtil.POLICY_SYS_CS);
				consentTO.setMembershipNo(claim.getMemberId());
			}
		}
		else // OL,PA
		{
			consentTO.setCertNo("");
			consentTO.setSubOfficeCd("");
			consentTO.setDepCd("");
			consentTO.setMembershipNo("");
			consentTO.setPolicySys("");
		}
		ConsentOutputTO t = claimService.getConsentOutputTOForClaim(consentTO);		
		setConsentValue(t, claim);
		
		
		if (caseId != null && claim.getCaseId() == null) {
			claim.setCaseId(caseId);
		}
		cmicClaim.getClaimCanonical().setClaim(claim);
		// Do not show document from request doc.
		List<Document> lstDocument = new ArrayList<>();
		List<Document> tmp = cmicClaim.getLstDocument();
		for (Document document : tmp) {
			if (!"Fax".equalsIgnoreCase(document.getDocTypeCode())) {
				lstDocument.add(document);
			}
		}

		List<Lookup> lstPaymentSeqStatus = reloadPendingFile();
		List<Lookup> lstEForm = reloadEFormFile();
		model.addAttribute("lstPaymentSeqStatus", lstPaymentSeqStatus);
		model.addAttribute("lstEForm", lstEForm);
		cmicClaim.setLstDocument(lstDocument);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("processingDt", commonDataService.getProcessingDate());
		List<DocumentType> data = workflowService.getAllDocumentType(userInfoForm);
		model.addAttribute("lstDocumentType", pageSecurity.isUnloadAvaliable() ? transformToLookupList(data) : new ArrayList<>());
		model.addAttribute("pageSecurity", pageSecurity);
		model.addAttribute("channel", CMiCUtil.getCommonCodeDesc(cachingHelper.findChannel(FormatUtil.convertNull(cmicClaim.getClaimCanonical().getClaim().getChannel()))));
		Boolean allowNA = claimHelper.isAllowNotApplicable(userInfoForm);
		model.addAttribute("allowNA", allowNA);
		return "claim/simplifySubmission";

	}

	private DataEntryPageSecurity setPageSecurityDataEntry(CMiCClaim cmicClaim, Set<Function> fnSet, UserInfoForm userInfoForm) {
		DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
		if (cmicClaim.getLockType() != 0 && userInfoForm.getUserId().equals(cmicClaim.getOwner())) {
			boolean dataEntry = fnSet.contains(Function.CMIC_DATAENTRY_DATAENTRY_PRC);
			pageSecurity.setGeneralWritable(dataEntry);
			pageSecurity.setClaimantWritable(dataEntry);
			pageSecurity.setSubmissionWritable(dataEntry);
			pageSecurity.setPaymentWritable(dataEntry);
			pageSecurity.setProviderWritable(dataEntry);
			pageSecurity.setServiceItemWritable(dataEntry);
			boolean medical = fnSet.contains(Function.CMIC_DATAENTRY_MEDICAL_PRC);
			pageSecurity.setCauseOfTreatmentWritable(medical);
			pageSecurity.setDetailOfAccidentWritable(medical);
			pageSecurity.setMedicalConditionWritable(medical);
			pageSecurity.setDiagnosisWritable(medical);
			pageSecurity.setBenefitWritable(medical);
			boolean comment = fnSet.contains(Function.CMIC_DATAENTRY_COMMENT_PRC);
			pageSecurity.setCommentWritable(comment);

			pageSecurity.setSaveAvaliable(true);
			pageSecurity.setTransferAvaliable(true);
			pageSecurity.setConfirmAndDuplicateAvaliable(true);
			pageSecurity.setConfirmAndCloseAvaliable(true);
			pageSecurity.setConfirmAndGetNextAvaliable(true);
			pageSecurity.setUnlockAvaliable(true);
			pageSecurity.setUnloadAvaliable(true);
		}
		return pageSecurity;

	}

	@RequestMapping(value = "/benefitDetermination/{caseId}", method = RequestMethod.GET)
	public String openBenefitDetermination(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
		LOG.debug("caseId: {} ", caseId);
		Long claimId = null;
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CaseStatus status = workflowService.getCaseStatus(caseId, userInfoForm);
		LOG.debug("open Benefitdetermination caseId {} state {} activity {} ", caseId, status.getState(), status.getActivity());
		if ((status.getState().equals(200) || status.getState().equals(210)) && (Activity.MANUALREVIEW.getActivity().equals(status.getActivity()))) {
			CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
			if (cmicClaim != null) {
				if (cmicClaim.getClaimCanonical().getClaim().getClaimId() != null) {
					claimId = cmicClaim.getClaimCanonical().getClaim().getClaimId();
					initClaimBenefitDetermination(cmicClaim, model, userInfoForm);
				} else {
					CMiCClaimBenefit cmicClaimBenefit = new CMiCClaimBenefit();
					ClaimBenefitCanonical claimBenefitCano = new ClaimBenefitCanonical();
					setErrorOpenbenefitDetermination(claimBenefitCano, ClaimBenefitCanonical.FAIL_1, " not found CMiCClaim.", caseId);
					cmicClaimBenefit.setClaimBenefitCanonical(claimBenefitCano);
					model.addAttribute(cmicEnvironmentHelper.getClaimBenefitAttributeName(), cmicClaimBenefit);
					model.addAttribute("channel", CMiCUtil.getCommonCodeDesc(cachingHelper.findChannel(FormatUtil.convertNull(cmicClaimBenefit.getClaimBenefitCanonical().getClaim().getChannel()))));
				}
			}
			DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
			pageSecurity.setUnloadAvaliable(true);
			model.addAttribute("pageSecurity", pageSecurity);
			model.addAttribute("caseId", caseId);
			model.addAttribute("claimId", claimId);
			return "claim/benefitDetermination";
		} else {
			return "homeBlank";
		}
	}

	public void initClaimBenefitDetermination(CMiCClaim cmicClaim, ModelMap model, UserInfoForm userInfoForm) {
		Long claimId = null;
		Long caseId = null;
		CMiCClaimBenefit cmicClaimBenefit = new CMiCClaimBenefit();
		ClaimBenefitCanonical claimBenefitCano = new ClaimBenefitCanonical();
		String cleanInd = cmicClaim.getClaimCanonical().getClaim().getCleanInd();
		if (cmicClaim != null) {
			claimId = cmicClaim.getClaimCanonical().getClaim().getClaimId();
			caseId = cmicClaim.getClaimCanonical().getClaim().getCaseId();
			String providerCode = cmicClaim.getClaimCanonical().getClaim().getProviderCode();
			ProviderJoinProviderContact providerContact = findProviderContact(providerCode);
			claimBenefitCano.setFaxNo(providerContact.getFaxNo1());
			claimBenefitCano.setEmailAddress(providerContact.getEmailAddress1());
			claimBenefitCano.setClaimId(claimId);
			claimBenefitCano.setCaseId(caseId);
			LOG.info("initClaimBenefitDetermination--> claimId:{}, caseId:{}", claimId, caseId);
			LOG.info("Email : {} , Fax : {}", claimBenefitCano.getEmailAddress(), claimBenefitCano.getFaxNo());
		}
		try {
			// call ClaimService for retrieve ClaimCanonical.
			ClaimCanonical claimCano = null;
			if (claimId != null) {
				try {
					claimCano = claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId);
				} catch (CMiCException e) {
					model.addAttribute("caseId", caseId);
				}

			}
			if (claimCano != null) {
				if (claimCano.getClaim() != null) {
					MultiMap multiMap = claimHelper.cloneClaimPaymentList(claimCano, claimBenefitCano, true);
					claimCano.getClaim().setCleanInd(cleanInd);
					claimBenefitCano.setClaim(claimCano.getClaim());
					String claimStatusDesc = getCommonCodeDesc(cachingHelper.findClaimStatus(claimCano.getClaim().getClaimStatus()));
					claimBenefitCano.setClaimStatusDesc(claimStatusDesc);
					claimBenefitCano.setMultiMap(multiMap);
					claimCano.getClaim().setBillingDeclineReason(getCommonCodeDesc(cachingHelper.findBillingDeclineReason(claimCano.getClaim().getBillingDeclineReason())));
					com.aia.cmic.entity.ClaimPolicy claimPolicy = null;
					if (claimCano.getClaim().getPolicyNo() != null) {
						claimPolicy = claimPolicyRepository.findClaimPolicyByPolicyNoClaimNoAndOccurrence(claimCano.getClaim().getPolicyNo(), claimCano.getClaim().getClaimNo(), claimCano.getClaim()
								.getOccurrence());
					}

					Provider provider = providerService.getExistingProvider(claimCano.getClaim().getProviderCode());
					List<ProviderContact> providerContacts = providerService.findProviderContactByProviderCode(claimCano.getClaim().getProviderCode());
					String providerAddress2 = "";
					String providerAddress3 = "";
					String providerAddress4 = "";
					if (CollectionUtils.isNotEmpty(providerContacts)) {
						boolean foundPrimary = false;
						for (ProviderContact providerContact : providerContacts) {
							if ("Primary".equals(providerContact.getContactType())) {
								providerAddress2 = FormatUtil.convertNull(providerContact.getAddressLine1());
								providerAddress3 = FormatUtil.convertNull(providerContact.getDistrict()) + " " + FormatUtil.convertNull(providerContact.getCity());
								providerAddress4 = FormatUtil.convertNull(providerContact.getProvince()) + " " + FormatUtil.convertNull(providerContact.getPostalCode());
								foundPrimary = true;
								break;
							}
						}
						if (!foundPrimary) {
							providerAddress2 = FormatUtil.convertNull(providerContacts.get(0).getAddressLine1());
							providerAddress3 = FormatUtil.convertNull(providerContacts.get(0).getDistrict()) + " " + FormatUtil.convertNull(providerContacts.get(0).getCity());
							providerAddress4 = FormatUtil.convertNull(providerContacts.get(0).getProvince()) + " " + FormatUtil.convertNull(providerContacts.get(0).getPostalCode());
						}
					}

					List<Lookup> lstPaymentSeqStatus = reloadPendingFile();
					List<Lookup> lstEForm = reloadEFormFile();
					List<Lookup> lstIE = reloadIEFile();
					List<MasterLookup> lstReqDoctorTypeStatus = cachingHelper.getClaimRequirementStatus();
					List<MasterLookup> lstClaimComment = cachingHelper.getCommentType();
					Insured insured = insuredRepository.findInsuredByCompanyClaimNoOccurencePolicyNo(claimCano.getClaim().getClaimNo(), claimCano.getClaim().getOccurrence(), claimCano.getClaim()
							.getPolicyNo());
					//AgentInfo agentInfo = partyService.getAgentInfoByAgentCode(claimCano.getClaim().getAgentCodeServicing());
					String partyId = partyService.getPartyIdByAgentCode(claimCano.getClaim().getAgentCodeServicing());
					String agentName = partyService.getAgentNameByPartyId(partyId);
					String suppressInd = claimService.getAllSuppressInd(cmicEnvironmentHelper.getCmicCompanyId(), claimCano.getClaim().getClaimNo(), claimCano.getClaim().getOccurrence());
					claimBenefitCano.setSuppressInd(suppressInd);
					claimBenefitCano.setAgentName(agentName);
					initiBenefitTableList(model);
					claimBenefitCano.setAllowNotApplcable(claimHelper.isAllowNotApplicable(userInfoForm));
					
					boolean showCsDeduct = false;
				
					if(claimCano.getClaimPayments() != null && claimCano.getClaimPayments().size() > 0)
					{
						for (int i = 0; i < claimCano.getClaimPayments().size(); i++) {
							if("HNW".equals(claimCano.getClaimPayments().get(i).getProductType())){
								showCsDeduct = true;
								break;
							}
						}
					}
					model.addAttribute("showCsDeduct",showCsDeduct);
					
					model.addAttribute("providerName", provider != null ? provider.getProviderNameThai() : null);
					model.addAttribute("providerAddress1", provider != null ? provider.getProviderRegNameThai() : null);
					model.addAttribute("providerAddress2", providerAddress2);
					model.addAttribute("providerAddress3", providerAddress3);
					model.addAttribute("providerAddress4", providerAddress4);
					model.addAttribute("lstPaymentSeqStatus", lstPaymentSeqStatus);
					model.addAttribute("lstEForm", lstEForm);
					model.addAttribute("lstIE", lstIE);
					model.addAttribute("lstReqDoctorTypeStatus", lstReqDoctorTypeStatus);
					model.addAttribute("claimPolicy", claimPolicy);
					model.addAttribute("lstClaimComment", lstClaimComment);
					model.addAttribute("initialEffectiveDt", insured != null ? insured.getInitialEffectiveDt() : null);
					CMiCClaim benefitCmicClaim = new CMiCClaim();
					benefitCmicClaim.setClaimCanonical(claimCano);
					Date prevDisabilityToDate = claimService.findPreviousDisabilityToDate(cmicEnvironmentHelper.getCmicCompanyId(), claimCano.getClaim());
					model.addAttribute("cmicClaim", benefitCmicClaim);
					model.addAttribute("prevDisabilityToDate", FormatUtil.convertCmicDateToString(prevDisabilityToDate));

					model.addAttribute("docHospital", reloadHospitalFile());
					
					model.addAttribute("docOther", reloadOtherFile());
					model.addAttribute("policyNo", claimCano.getClaim().getPolicyNo());
					model.addAttribute("insuredName", claimCano.getClaim().getFirstName()+" "+claimCano.getClaim().getLastName());

					configBenefitSection(model, true, benefitCmicClaim);
					setRequestDocumentTypeList(model);
					BigDecimal sumTotalBillAmount = claimBenefitItemRepository.sumTotalBillAmount(claimBenefitCano.getClaim()
							.getCompanyId(), claimBenefitCano.getClaim().getClaimNo(), claimBenefitCano.getClaim().getOccurrence());
					claimBenefitCano.getClaim().setTotalBilledAmt(sumTotalBillAmount);

					claimBenefitCano.setRetureCode(ClaimBenefitCanonical.SUCCESS);

				} else {
					setErrorOpenbenefitDetermination(claimBenefitCano, ClaimBenefitCanonical.FAIL_1, " not found claim.", caseId);
				}
			} else {
				setErrorOpenbenefitDetermination(claimBenefitCano, ClaimBenefitCanonical.FAIL_1, " Could not retrieve claim detail ", caseId);
			}

		} catch (Exception e) {
			LOG.error(" init cmicClaimBenefit in openBenefitDetermination error ", e);
			setErrorOpenbenefitDetermination(claimBenefitCano, ClaimBenefitCanonical.FAIL_2, " Init cmicClaimBenefit in openBenefitDetermination error <br> " + e.getMessage(), caseId);
		} finally {
			cmicClaimBenefit.setClaimBenefitCanonical(claimBenefitCano);
			model.addAttribute(cmicEnvironmentHelper.getClaimBenefitAttributeName(), cmicClaimBenefit);
			model.addAttribute("channel", CMiCUtil.getCommonCodeDesc(cachingHelper.findChannel(FormatUtil.convertNull(cmicClaimBenefit.getClaimBenefitCanonical().getClaim().getChannel()))));

		}
	}

	private void setErrorOpenbenefitDetermination(ClaimBenefitCanonical claimBenefitCano, int failId, String msg, Long caseId) {
		claimBenefitCano.setRetureCode(failId);
		String error = String.format(MSG_OPEN_BENEFIT_DETERMINATION_FAIL, caseId, msg);
		claimBenefitCano.setErrorMsg(error);
	}

	private void setClaimDocTypeList(List<ClaimDocumentType> lstAllPendingCode, String value, String desc) {
		ClaimDocumentType claimDocType = new ClaimDocumentType();
		claimDocType.setDocTypeItemsId(value);
		claimDocType.setDocTypeItemsName(desc);
		lstAllPendingCode.add(claimDocType);
	}

	private ProviderJoinProviderContact findProviderContact(String providerCode) {
		ProviderSearchForm form = new ProviderSearchForm();
		form.setProviderCode(providerCode);
		List<ProviderJoinProviderContact> data = new ArrayList<>();
		try {
			data = providerService.getProvider(form);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}

		return data.size() == 0 ? new ProviderJoinProviderContact() : data.get(0);
	}

	private List<Lookup> reloadPendingFile() throws CMiCException {
		CMiCUtil.clearPendingFile();
		List<MasterLookup> pendingListDescLong = cachingHelper.getPendingTypeMapByDescLong();
		List<MasterLookup> pendingListDesc = cachingHelper.getPendingTypeMapByDesc();

		List<Lookup> lstPending = new ArrayList<>();

		for (MasterLookup eForm : pendingListDesc) {
			String key = eForm.getKey();
			String value = eForm.getValue();

			if (!StringUtils.isBlank(key)) {
				key = key.trim();
				Lookup lookup = new Lookup();
				lookup.setKey(key);
				lookup.setValue(value);
				lstPending.add(lookup);
			}

		}

		for (MasterLookup eForm : pendingListDescLong) {
			String name = eForm.getValue();
			String key = eForm.getKey();
			if (!StringUtils.isBlank(key)) {
				CMiCUtil.addPendingFile(key, name);
			}
		}
		return lstPending;
	}

	private List<Lookup> reloadEFormFile() throws CMiCException {
		CMiCUtil.clearEFormFile();
		List<MasterLookup> eFormListDescLong = cachingHelper.getEFormTypeMapByDescLong();
		List<MasterLookup> eFormListDesc = cachingHelper.getEFormTypeMapByDesc();
		List<Lookup> lstEForm = new ArrayList<>();

		for (MasterLookup eForm : eFormListDesc) {
			String key = eForm.getKey();
			String value = eForm.getValue();

			if (!StringUtils.isBlank(key)) {
				key = key.trim();
				Lookup lookup = new Lookup();
				lookup.setKey(key);
				lookup.setValue(value);
				lstEForm.add(lookup);
			}

		}

		for (MasterLookup eForm : eFormListDescLong) {
			String name = eForm.getValue();
			String key = eForm.getKey();
			if (!StringUtils.isBlank(key)) {
				CMiCUtil.addEFormFile(key, name);
			}
		}

		return lstEForm;
	}

	private List<Lookup> reloadIEFile() throws CMiCException {
		CMiCUtil.clearIEFile();
		List<MasterLookup> ieListDescLong = cachingHelper.getIETypeMapByDescLong();
		List<MasterLookup> ieListDesc = cachingHelper.getIETypeMapByDesc();
		List<Lookup> lstIE = new ArrayList<>();

		for (MasterLookup ie : ieListDesc) {
			String key = ie.getKey();
			String value = ie.getValue();

			if (!StringUtils.isBlank(key)) {
				key = key.trim();
				Lookup lookup = new Lookup();
				lookup.setKey(key);
				lookup.setValue(value);
				lstIE.add(lookup);
			}

		}

		for (MasterLookup ie : ieListDescLong) {
			String name = ie.getValue();
			String key = ie.getKey();
			if (!StringUtils.isBlank(key)) {
				CMiCUtil.addIEFile(key, name);
			}
		}

		return lstIE;
	}

	private List<Lookup> reloadHospitalFile() throws CMiCException {
		CMiCUtil.clearHospitalFile();
		List<MasterLookup> hospitalListDescLong = cachingHelper.getDocHospitalTypeMapByDescLong();
		List<MasterLookup> hospitalListDesc = cachingHelper.getDocHospitalTypeMapByDesc();
		List<Lookup> lstHospital = new ArrayList<>();

		for (MasterLookup ie : hospitalListDesc) {
			String key = ie.getKey();
			String value = ie.getValue();

			if (!StringUtils.isBlank(key)) {
				key = key.trim();
				Lookup lookup = new Lookup();
				lookup.setKey(key);
				lookup.setValue(value);
				lstHospital.add(lookup);
			}

		}

		for (MasterLookup ie : hospitalListDescLong) {
			String name = ie.getValue();
			String key = ie.getKey();
			if (!StringUtils.isBlank(key)) {
				CMiCUtil.addHospitalFile(key, name);
			}
		}

		return lstHospital;
	}
	
	private List<Lookup> reloadOtherFile() throws CMiCException {
		CMiCUtil.clearOtherFile();
		List<MasterLookup> otherListDescLong = cachingHelper.getDocOtherMapByDescLong();
		List<MasterLookup> otherListDesc = cachingHelper.getDocOtherTypeMapByDesc();
		List<Lookup> lstOther = new ArrayList<>();

		for (MasterLookup ie : otherListDesc) {
			String key = ie.getKey();
			String value = ie.getValue();

			if (!StringUtils.isBlank(key)) {
				key = key.trim();
				Lookup lookup = new Lookup();
				lookup.setKey(key);
				lookup.setValue(value);
				lstOther.add(lookup);
			}

		}

		for (MasterLookup ie : otherListDescLong) {
			String name = ie.getValue();
			String key = ie.getKey();
			if (!StringUtils.isBlank(key)) {
				CMiCUtil.addOtherFile(key, name);
			}
		}

		return lstOther;
	}

	@RequestMapping(value = "/searchClaimsHistoryList", method = RequestMethod.GET)
	public String openSearchClaimsHistory(ModelMap model) {
		LOG.debug(" openSearchClaimsHistory ");
		ClaimHistorySearchCriteria form = new ClaimHistorySearchCriteria();
		List<Lookup> lstActivities = new ArrayList<Lookup>();

		Lookup empty = new Lookup();
		empty.setKey("");
		empty.setValue("");

		lstActivities.add(empty);

		for (Activity a : Activity.values()) {
			if (a.toString() != null) {
				Lookup lookup = new Lookup();
				lookup.setKey(a.toString());
				lookup.setValue(a.toString());
				lstActivities.add(lookup);
			}
		}
		model.addAttribute("lstActivities", lstActivities);
		model.addAttribute("form", form);
		return "claim/searchClaimsHistoryList";
	}

	@RequestMapping(value = "/viewDataEntry/{caseId}", method = RequestMethod.GET)
	public String viewDataEntry(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = retriveCMiCClaim(caseId, userInfoForm);
		DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
		//	Activity a = Activity.parseActivity(cmicClaim.getActivity());
		//	if (Activity.MANUALREVIEW.equals(a)) {
		model.addAttribute("screenTitle", "CLAIMS INQUIRY");
		return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		//	} else {
		//		return "homeBlank";
		//	}
	}

	@RequestMapping(value = "/caseMedicalReview/{caseId}", method = RequestMethod.GET)
	public String openCaseMedicalReview(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = retriveCMiCClaim(caseId, userInfoForm);
		Activity a = Activity.parseActivity(cmicClaim.getActivity());
		
		// Teerapat.C 24/03/2020
		Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
		if (Activity.MEDICALREVIEW.equals(a)) {
			DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
			if (cmicClaim.getLockType() != 0 && userInfoForm.getUserId().equals(cmicClaim.getOwner())) {
				pageSecurity.setCommentWritable(true);
				pageSecurity.setUnlockAvaliable(true);
				pageSecurity.setPendAvaliable(true);
				pageSecurity.setRejectAvaliable(true);
				pageSecurity.setDoctorAvaliable(true);
				pageSecurity.setConfirmAndCloseAvaliable(true);
				pageSecurity.setSaveMedicalAvaliable(true);
				
				//pageSecurity.setDeleteAvaliable2(true);
				if(fnSet.contains(Function.CMIC_CLAIM_DELETE)){
					pageSecurity.setDeleteAvaliable2(true);
				}
				
				//set medical review page could edit.
				pageSecurity.setGeneralWritable(true);
				pageSecurity.setClaimantWritable(true);
				pageSecurity.setSubmissionWritable(true);
				pageSecurity.setPaymentWritable(true);
				pageSecurity.setProviderWritable(true);
				pageSecurity.setServiceItemWritable(true);
				pageSecurity.setCauseOfTreatmentWritable(true);
				pageSecurity.setDetailOfAccidentWritable(true);
				pageSecurity.setMedicalConditionWritable(true);
				pageSecurity.setDiagnosisWritable(true);
				pageSecurity.setBenefitWritable(true);
			}
			model.addAttribute("lstPendReason", workflowService.getAllPendReason(userInfoForm));
			model.addAttribute("screenTitle", "MEDICAL REVIEW");
			model.addAttribute("EDI", ediService.findAnyEdiDataByClaimNoAndOccurrence(cmicClaim.getClaimCanonical().getClaim().getClaimNo(), cmicClaim.getClaimCanonical().getClaim().getOccurrence()));
			return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	@RequestMapping(value = "/ie/{caseId}", method = RequestMethod.GET)
	public String openIE(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = retriveCMiCClaim(caseId, userInfoForm);
		Activity a = Activity.parseActivity(cmicClaim.getActivity());
		if (Activity.IE.equals(a)) {
			DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
			if (cmicClaim.getLockType() != 0 && userInfoForm.getUserId().equals(cmicClaim.getOwner())) {
				pageSecurity.setCommentWritable(true);
				pageSecurity.setUnlockAvaliable(true);
				pageSecurity.setPendAvaliable(false);
				pageSecurity.setRejectAvaliable(false);
				pageSecurity.setDoctorAvaliable(false);
				pageSecurity.setConfirmAndCloseAvaliable(true);
				pageSecurity.setSaveMedicalAvaliable(true);
				pageSecurity.setDisabledRequestDoc(true);
				pageSecurity.setUnloadAvaliable(true);
			}
			model.addAttribute("lstPendReason", workflowService.getAllPendReason(userInfoForm));
			model.addAttribute("screenTitle", "INSURANCE EVALUATION");
			return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	@RequestMapping(value = "/doctorConsultant/{caseId}", method = RequestMethod.GET)
	public String openDoctorConsultant(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = retriveCMiCClaim(caseId, userInfoForm);
		Activity a = Activity.parseActivity(cmicClaim.getActivity());
		if (Activity.CONSULT.equals(a)) {
			DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
			if (cmicClaim.getLockType() != 0 && userInfoForm.getUserId().equals(cmicClaim.getOwner())) {
				pageSecurity.setCommentWritable(true);
				pageSecurity.setUnlockAvaliable(true);
				pageSecurity.setConfirmAndCloseAvaliable(true);
				pageSecurity.setSaveMedicalAvaliable(true);
				pageSecurity.setDisabledRequestDoc(true);
			}
			model.addAttribute("screenTitle", "DOCTOR CONSULTANT");
			return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	private String configDataEntryPage(
			@PathVariable Long caseId,
			ModelMap model,
			HttpServletRequest httpServletRequest,
			CMiCClaim cmicClaim,
			UserInfoForm userInfoForm,
			DataEntryPageSecurity pageSecurity) throws Exception {

		Claim claim = cmicClaim.getClaimCanonical().getClaim();

		configGeneralSection(model, pageSecurity.isGeneralWritable(), cmicClaim);
		configClaimantSection(model, pageSecurity.isClaimantWritable(), cmicClaim);
		if (!claim.getBusinessLine().startsWith("ODS-MCS")) {
			configSubmissionSection(model, pageSecurity.isSubmissionWritable(), cmicClaim);
		}
		configPaymentSection(model, pageSecurity.isPaymentWritable(), cmicClaim);
		configProviderSection(model, pageSecurity.isProviderWritable(), cmicClaim);
		configServiceItemSection(model, pageSecurity.isServiceItemWritable(), cmicClaim);
		configCauseOfTreatmentSection(model, pageSecurity.isCauseOfTreatmentWritable(), cmicClaim);
		configDetailOfAccidentSection(model, pageSecurity.isDetailOfAccidentWritable(), cmicClaim);
		configMedicalConditionSection(model, pageSecurity.isMedicalConditionWritable(), cmicClaim);
		configDiagnosisSection(model, pageSecurity.isDiagnosisWritable(), cmicClaim);
		configBenefitSection(model, pageSecurity.isBenefitWritable(), cmicClaim);
		configCustomerProfileSection(model, pageSecurity.isCustomerProfileAvaliable(), cmicClaim);
		configBenefitDetailSection(model, pageSecurity.isBenefitDetailAvaliable(), cmicClaim);
		configCommentSection(model, pageSecurity.isCommentWritable(), cmicClaim, userInfoForm);
		String gender = "";
		if ("1".equals(FormatUtil.convertNull(claim.getGender())) || "M".equals(FormatUtil.convertNull(claim.getGender()))) {
			gender = "Male";
		} else if ("2".equals(FormatUtil.convertNull(claim.getGender())) || "F".equals(FormatUtil.convertNull(claim.getGender()))) {
			gender = "Female";
		}
		//claim.setGender(getCommonCodeDesc(cachingHelper.findGender(claim.getGender())));
		claim.setGender(gender); // To avoid multiple value for gender, I changed to manaul fix value for it. 
		
		
		ConsentTO consentTO = new ConsentTO();
		consentTO.setPolicyNo(claim.getPolicyNo());
		//consentTO.setPolicyNo("M502909162");
		if(claim.getBusinessLine().equals("CS") || claim.getBusinessLine().equals("GE"))
		{
			consentTO.setSubOfficeCd(claim.getSubOfficeCode());
			if(claim.getBusinessLine().equals("GE"))
			{
				consentTO.setPolicySys(CMiCUtil.POLICY_SYS_GE);
				consentTO.setCertNo(claim.getCertNo());
				consentTO.setDepCd(claim.getDependentNo());
				consentTO.setPolicyNo(claim.getPolicyNo().substring(5, claim.getPolicyNo().length()));
			}
			else if(claim.getBusinessLine().equals("CS"))
			{
				consentTO.setPolicySys(CMiCUtil.POLICY_SYS_CS);
				consentTO.setMembershipNo(claim.getMemberId());
			}
		}
		else // OL,PA
		{
			consentTO.setCertNo("");
			consentTO.setSubOfficeCd("");
			consentTO.setDepCd("");
			consentTO.setMembershipNo("");
			consentTO.setPolicySys("");
		}
		ConsentOutputTO t = claimService.getConsentOutputTOForClaim(consentTO);		
		setConsentValue(t, claim);
		
		
		if (caseId != null && claim.getCaseId() == null) {
			claim.setCaseId(caseId);
		}
		cmicClaim.getClaimCanonical().setClaim(claim);
		// Do not show document from request doc.
		List<Document> lstDocument = new ArrayList<>();
		List<Document> tmp = cmicClaim.getLstDocument();
		for (Document document : tmp) {
			if (!"Fax".equalsIgnoreCase(document.getDocTypeCode())) {
				lstDocument.add(document);
			}
		}
		
		// Get PlanCode
		boolean foundAiaic       = false;
		boolean foundAiaicDeduct = false;
		
		if(cmicClaim != null){
			if(cmicClaim.getClaimCanonical() != null){
				if(cmicClaim.getClaimCanonical().getClaim() != null) {
					Long partyId = cmicClaim.getClaimCanonical().getClaim().getPartyId();
					if(partyId != null)
					{
						List<String> policyListTmp = new ArrayList<String>();
						List<PolicyPerLife> lstPolicyPerLife = new ArrayList<PolicyPerLife>();
						SearchPolicyPerLifeByPartyIdResponse response = policyRepository.searchPolicyPerLifeByPartyId(cmicEnvironmentHelper.getCmicCompanyId(),partyId.toString());
						if (response.getReturnCode().equals("S") && !CollectionUtils.isEmpty(response.getPolicyList())) {
							lstPolicyPerLife = response.getPolicyList();
						}
						
						for (PolicyPerLife ppl :lstPolicyPerLife) 
						{
							if(!policyListTmp.contains(ppl.getPolNum()))
							{
								policyListTmp.add(ppl.getPolNum());
							}
						}
						
						for (String policyNo : policyListTmp) {
							RetrievePolicyDetailResponse policyDetail = policyRepository.retrievePolicyDetail(cmicEnvironmentHelper.getCmicCompanyId(), policyNo);
							if(policyDetail != null)
							{
								if(CollectionUtils.isNotEmpty(policyDetail.getPolicyList())){				
									for (int i = 0; i < policyDetail.getPolicyList().size(); i++) {
										if(CollectionUtils.isNotEmpty(policyDetail.getPolicyList().get(i).getCoverageList())){	
											for (int j = 0; j < policyDetail.getPolicyList().get(i).getCoverageList().size(); j++) {
												String planCode = policyDetail.getPolicyList().get(i).getCoverageList().get(j).getProductCd();
												if(planCode != null)
												{
													if(planCode.equals(CMiCUtil.PRODUCT_CODE_990F07))
													{
														foundAiaic = true;
													}
													
													if(planCode.equals(CMiCUtil.PRODUCT_CODE_990D07) || planCode.equals(CMiCUtil.PRODUCT_CODE_990E07))
													{
														foundAiaicDeduct = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		
		List<Lookup> lstPaymentSeqStatus = reloadPendingFile();
		List<Lookup> lstEForm = reloadEFormFile();
		model.addAttribute("lstPaymentSeqStatus", lstPaymentSeqStatus);
		model.addAttribute("lstEForm", lstEForm);
		cmicClaim.setLstDocument(lstDocument);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("processingDt", commonDataService.getProcessingDate());
		List<DocumentType> data = workflowService.getAllDocumentType(userInfoForm);
		model.addAttribute("lstDocumentType", pageSecurity.isUnloadAvaliable() ? transformToLookupList(data) : new ArrayList<>());
		model.addAttribute("pageSecurity", pageSecurity);
		model.addAttribute("channel", CMiCUtil.getCommonCodeDesc(cachingHelper.findChannel(FormatUtil.convertNull(cmicClaim.getClaimCanonical().getClaim().getChannel()))));

		model.addAttribute("AIAIC"      , foundAiaic);
		model.addAttribute("AIAICDeduct", foundAiaicDeduct);
		
		return "claim/caseDataEntry";

	}

	@RequestMapping(value = "/claimsHistoryDetail/{claimId}", method = RequestMethod.GET)
	public String openClaimsHistoryDetail(@PathVariable Long claimId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		LOG.debug(" openClaimsHistoryDetail ");
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		
		ClaimCanonical claimCano = claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId);
		Long caseId = claimCano.getClaim().getCaseId();
		CMiCClaim cmicClaim;
		String subOfficeName = "";
		try {
			cmicClaim = (caseId != null) ? workflowService.getClaimByIndex(caseId, userInfoForm) : new CMiCClaim();
			claimCano.getClaim().setCleanInd(cmicClaim.getClaimCanonical().getClaim().getCleanInd());
		} catch (CMiCException e) {
			LOG.error("getclaim from 360 error:", e);
			cmicClaim = new CMiCClaim();
		}

		cmicClaim.setClaimCanonical(claimCano);
		if (claimCano.getClaim().getClaimId() != null) {
			DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
			pageSecurity.setCustomerProfileAvaliable(true);
			pageSecurity.setBenefitDetailAvaliable(true);
			pageSecurity.setPendingDocumentAvaliable(true);

			LOG.debug("cmicClaim.getClaimCanonical().getClaim().getClaimStatus() {}", claimCano.getClaim().getClaimStatus());
			pageSecurity.setUnloadAvaliable(true);
			pageSecurity.setCommentWritable(true);
			pageSecurity.setConfirmAndCloseAvaliable(true);
			pageSecurity.setClaimpolicyAccountnoAvailable(true);
			pageSecurity.setCopyAvailable(true);
			pageSecurity.setClaimInquiry(true);
			pageSecurity.setODS(false);

			if (!ClaimStatus.CANCELLED.getValue().equals(claimCano.getClaim().getClaimStatus()) && !ClaimStatus.REVERSED.getValue().equals(claimCano.getClaim().getClaimStatus())) 
			{
				Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
				if (claimHelper.checkCancel(claimCano)) {
					
					//pageSecurity.setDeleteAvaliable(true);
					if(fnSet.contains(Function.CMIC_CLAIM_DELETE)){
						pageSecurity.setDeleteAvaliable(true);
					}
				} else {
					if(fnSet.contains(Function.CMIC_CLAIM_REVERSE) ) {
						pageSecurity.setReverseButtonAvailable(true);
					}
					
				}
				pageSecurity.setEditClaimAvaliable(claimHelper.checkEditClaim(claimCano));
			}

			List<BenefitReimbursement> reimbursementList = claimPaymentRepository.retrieveClaimPaymentApproveAmountByclaimNoAndOccurrence(claimCano.getClaim().getClaimNo(), claimCano.getClaim()
					.getOccurrence());
			BigDecimal reimbursementAmt = BigDecimal.ZERO;
			for (BenefitReimbursement benefitReimbursemen : reimbursementList) {
				reimbursementAmt = reimbursementAmt.add(benefitReimbursemen.getAmount());
			}

			List<ClaimPolicyAccountNo> claimpolicyAndAccountNo = claimService.retrieveClaimPolicyAndAccountNo(claimCano.getClaim().getClaimNo(), claimCano.getClaim().getOccurrence(), claimCano
					.getClaim().getBusinessLine());
			model.addAttribute("reimbursementAmt", reimbursementAmt);
			subOfficeName = claimHelper.findSubOfficeName(claimCano);
			model.addAttribute("screenTitle", "CLAIMS INQUIRY");
			model.addAttribute("activity", FormatUtil.convertNull(cmicClaim.getActivity()));
			model.addAttribute("caseId", caseId);
			model.addAttribute("claimId", claimId);
			model.addAttribute("claimpolicyAndAccountNo", claimpolicyAndAccountNo);
			model.addAttribute("subOfficeName", subOfficeName);

			model.addAttribute("pendingManagementList",
					claimService.retrieveClaimRequirementInfo(claimCano.getClaim().getCompanyId(), claimCano.getClaim().getClaimNo(), claimCano.getClaim().getOccurrence(), -1, -1));
			model.addAttribute("EDI", ediService.findAnyEdiDataByClaimNoAndOccurrence(claimCano.getClaim().getClaimNo(), claimCano.getClaim().getOccurrence()));
			return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	@RequestMapping(value = "/editClaim/{claimId}", method = RequestMethod.GET)
	public String openEditClaim(@PathVariable Long claimId, ModelMap model, HttpServletRequest httpServletRequest) {
		LOG.debug("edit claim id: {}", claimId);
		String view = "homeBlank";
		if (claimId != null) {
			UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
			try {
				ClaimCanonical retrieveClaimDetail = claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId);
				Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
				if (fnSet.contains(Function.CMIC_CLAIM_REVERSE) && (ClaimStatus.PENDING.getValue().equals(retrieveClaimDetail.getClaim().getClaimStatus()) //
						|| ClaimStatus.CANCELLED.getValue().equals(retrieveClaimDetail.getClaim().getClaimStatus()) || ClaimStatus.REVERSED.getValue().equals(
								retrieveClaimDetail.getClaim().getClaimStatus()))) {
					CMiCClaim cmicClaim = workflowService.getClaimByIndex(retrieveClaimDetail.getClaim().getCaseId(), userInfoForm);
					cmicClaim.setClaimCanonical(retrieveClaimDetail);
					configProviderSection(model, true, cmicClaim);
					configServiceItemSection(model, true, cmicClaim);
					configBenefitSection(model, true, cmicClaim);
					initiBenefitTableList(model);
					CMiCClaimBenefit cmicClaimBenefit = new CMiCClaimBenefit();
					ClaimBenefitCanonical claimBenefitCano = new ClaimBenefitCanonical();
					MultiMap multiMap = claimHelper.cloneClaimPaymentList(retrieveClaimDetail, claimBenefitCano, true);
					claimBenefitCano.setClaim(retrieveClaimDetail.getClaim());
					String claimStatusDesc = getCommonCodeDesc(cachingHelper.findClaimStatus(retrieveClaimDetail.getClaim().getClaimStatus()));
					claimBenefitCano.setClaimStatusDesc(claimStatusDesc);
					claimBenefitCano.setMultiMap(multiMap);
					claimBenefitCano.setAllowNotApplcable(claimHelper.isAllowNotApplicable(userInfoForm));
					cmicClaimBenefit.setClaimBenefitCanonical(claimBenefitCano);
					model.addAttribute(cmicEnvironmentHelper.getClaimBenefitAttributeName(), cmicClaimBenefit);
					Provider provider = providerService.getExistingProvider(cmicClaim.getClaimCanonical().getClaim().getProviderCode());
					List<MasterLookup> lstClaimComment = cachingHelper.getCommentType();
					model.addAttribute("providerName", provider.getProviderNameThai());
					model.addAttribute("lstClaimComment", lstClaimComment);
					model.addAttribute("cmicClaim", cmicClaim);
					model.addAttribute("screenTitle", "EDIT CLAIM");
					claimBenefitCano.setRetureCode(ClaimBenefitCanonical.SUCCESS);
					view = "claim/editClaimsHistory";
				} else {
					LOG.debug("Cound not open edit claim, not claim reverse authorize or claim status is {} ", retrieveClaimDetail.getClaim().getClaimStatus());
				}
			} catch (CMiCException e) {
				LOG.error("openEditClaim failed by: ", e);
				return "homeBlank";
			}
			return view;
		} else {
			return view;
		}
	}

	private void initiBenefitTableList(ModelMap model) {
		List<MasterLookup> riderTypeList = new ArrayList<MasterLookup>();
		List<MasterLookup> paRiderTypeList = new ArrayList<MasterLookup>();
		try {
			List<MasterLookup> riderList = cachingHelper.getInsertRider();
			for (MasterLookup lookup : riderList) {
				String value = lookup.getValue();
				String pattern = "^[P|M](.*)";
				Matcher matcher = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE).matcher(value);
				if (matcher.matches() == false) {
					riderTypeList.add(lookup);
				} else {
					paRiderTypeList.add(lookup);
				}
			}
		} catch (CMiCException e) {
			LOG.debug("error retrieve MasterLookup status ", e);
		}
		List<MasterLookup> lstPayeeType = cachingHelper.getPayeeType();
		List<MasterLookup> lstAdjustReason = cachingHelper.getAdjustReason();
		List<MasterLookup> lstDeclineReasonType = cachingHelper.getDeclineReason();
		List<MasterLookup> lstClaimDecisionType = cachingHelper.getEligibility();
		model.addAttribute("lstClaimDecisionType", lstClaimDecisionType);
		model.addAttribute("lstDeclineReasonType", lstDeclineReasonType);
		model.addAttribute("lstPayeeType", lstPayeeType);
		model.addAttribute("lstAdjustReason", lstAdjustReason);
		model.addAttribute("lstInsertRiderType", riderTypeList);
		model.addAttribute("lstInsertPARiderType", paRiderTypeList);
	}

	private CMiCClaim retriveCMiCClaim(Long caseId, UserInfoForm userInfoForm) throws Exception {
		CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
		if (cmicClaim.getClaimCanonical().getClaim().getClaimId() != null) {
			cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getClaimId()));
		} else {
			Long claimId = claimService.retriveClaimFromCaseId(caseId);
			if (claimId != null) {
				cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId));
			}
		}

		//		for (ClaimPolicyCanonical claimPolicyCanonical : cmicClaim.getClaimCanonical().getClaimPolicies()) {
		//			ClaimPolicy claimPolicy = claimPolicyCanonical.getClaimPolicy();
		//			if (!"".equals(FormatUtil.convertNull(claimPolicy.getDependentNo()))) {
		//				cmicClaim.getClaimCanonical().getClaim().setDependentNo(claimPolicy.getDependentNo());
		//			}
		//			if (!"".equals(FormatUtil.convertNull(claimPolicy.getDependentType()))) {
		//				cmicClaim.getClaimCanonical().getClaim().setDependentType(claimPolicy.getDependentType());
		//			}
		//			if (!"".equals(FormatUtil.convertNull(claimPolicy.getSubOfficeCode()))) {
		//				cmicClaim.getClaimCanonical().getClaim().setSubOfficeCode(claimPolicy.getSubOfficeCode());
		//			}
		//			if (!"".equals(FormatUtil.convertNull(claimPolicy.getSubOfficeName()))) {
		//				cmicClaim.getClaimCanonical().getClaim().setSubOfficeName(claimPolicy.getSubOfficeName());
		//			}
		//			break;
		//		}
		//
		return cmicClaim;
	}

	@RequestMapping(value = "/claimsHistoryDetailODS/{claimId}", method = RequestMethod.GET)
	public String openClaimsHistoryDetailODS(@PathVariable Long claimId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		LOG.debug(" openClaimsHistoryDetailODS ");
		final String CLAIMSTATUS_REVERSED = "Reversed";
		final String CLAIMSTATUS_CANCELLED = "Cancelled";
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
		CMiCClaim cmicClaim = retriveCMiCClaimHistory(model, null, claimId, userInfoForm);
		Long caseId = cmicClaim.getClaimCanonical().getClaim().getCaseId();
		if (cmicClaim.getClaimCanonical().getClaim().getClaimId() != null) {
			DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
			pageSecurity.setCustomerProfileAvaliable(true);
			pageSecurity.setBenefitDetailAvaliable(true);
			pageSecurity.setPendingDocumentAvaliable(true);
			if (fnSet.contains(Function.CMIC_CLAIM_REVERSE) && !CLAIMSTATUS_REVERSED.equals(cmicClaim.getClaimCanonical().getClaim().getClaimStatus()) && !CLAIMSTATUS_CANCELLED.equals(cmicClaim
					.getClaimCanonical().getClaim().getClaimStatus())) {
				pageSecurity.setReverseButtonAvailable(true);
			}
			pageSecurity.setUnloadAvaliable(true);
			pageSecurity.setCommentWritable(true);
			pageSecurity.setConfirmAndCloseAvaliable(true);
			pageSecurity.setClaimpolicyAccountnoAvailable(true);
			pageSecurity.setCopyAvailable(true);
			pageSecurity.setClaimInquiry(true);
			pageSecurity.setODS(true);

			List<BenefitReimbursement> reimbursementList = claimPaymentRepository.retrieveClaimPaymentApproveAmountByclaimNoAndOccurrence(cmicClaim.getClaimCanonical().getClaim().getClaimNo(),
					cmicClaim.getClaimCanonical().getClaim().getOccurrence());
			BigDecimal reimbursementAmt = BigDecimal.ZERO;
			for (BenefitReimbursement benefitReimbursemen : reimbursementList) {
				reimbursementAmt = reimbursementAmt.add(benefitReimbursemen.getAmount());
			}

			List<ClaimPolicyAccountNo> claimpolicyAndAccountNo = cmicClaim.getClaimCanonical().getClaimPolicyAccountNos();
			model.addAttribute("reimbursementAmt", reimbursementAmt);
			model.addAttribute("screenTitle", "CLAIMS INQUIRY");
			model.addAttribute("activity", FormatUtil.convertNull(cmicClaim.getActivity()));
			model.addAttribute("caseId", caseId);
			model.addAttribute("claimpolicyAndAccountNo", claimpolicyAndAccountNo);
			return configDataEntryPage(caseId, model, httpServletRequest, cmicClaim, userInfoForm, pageSecurity);
		} else {
			return "homeBlank";
		}
	}

	private CMiCClaim retriveCMiCClaimHistory(ModelMap model, Long caseId, Long claimIdFromODS, UserInfoForm userInfoForm) throws Exception {
		//		CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
		//		if (cmicClaim != null) {
		//			if (cmicClaim.getClaimCanonical().getClaim().getClaimId() != null) {
		//				cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getClaimId()));
		//			} else {
		//				Long claimId = claimService.retriveClaimFromCaseId(caseId);
		//				if (claimId != null) {
		//					cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId));
		//				}
		//			}
		//		} else {
		CMiCClaim cmicClaim = claimService.retrieveClaimDetailFromODS(model, cmicEnvironmentHelper.getCmicCompanyId(), claimIdFromODS);

		//		}

		return cmicClaim;
	}

	@RequestMapping(value = "/uploadDocument/{caseId}", method = RequestMethod.GET)
	public String openuploadDocument(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		model.addAttribute("lstDocumentType", transformToLookupList(workflowService.getAllDocumentType(userInfoForm)));
		model.addAttribute("caseId", caseId);
		return "claim/dialog/document_upload";
	}

	@RequestMapping(value = "/settlementDetail", method = RequestMethod.GET)
	public String opensettlementDetail(ModelMap model) {
		return "claim/settlementDetail";
	}

	//	@RequestMapping(value = "/settlementDetailCaseId/{caseId}", method = RequestMethod.GET)
	//	public String opensettlementDetailCaseId(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
	//		LOG.info("case Id:{}", caseId);
	//		BenefitSettlement benefitSettlement = new BenefitSettlement();
	//		HttpSession session = httpServletRequest.getSession();
	//		if (session != null) {
	//			UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
	//			Claim claim = claimService.findClaimByCaseId(caseId);
	//			String claimStatus = claim.getClaimStatus();
	//			CachingMasterDataHelper cachingHelper = commonDataService.getCachingMasterDataHelper();
	//			String claimStatusDesc = CMiCUtil.getCommonCodeDesc(cachingHelper.findProcessStatus(claimStatus));
	//			LOG.info("Claim from service: claim no:{}, case id:{}, claim id:{}", claim.getClaimNo(), claim.getCaseId(), claim.getClaimId());
	//			benefitSettlement = settlementService.retrieveBenefitSettle(cmicEnvironmentHelper.getCmicCompanyId(), claim, claimStatusDesc, userInfoForm);
	//			model.addAttribute("benefitSettlement", benefitSettlement);
	//		} else {
	//			LOG.error("session null");
	//		}
	//		return "claim/settlementDetail";
	//	}

	//	@RequestMapping(value = "/settlementDetail/{caseId}", method = RequestMethod.GET)
	//	public String opensettlementDetail(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
	//		LOG.info("case Id:{}", caseId);
	//		BenefitSettlement benefitSettlement = new BenefitSettlement();
	//		HttpSession session = httpServletRequest.getSession();
	//		if (session != null) {
	//			UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
	//			CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
	//			Claim claim = cmicClaim.getClaimCanonical().getClaim();
	//			String claimStatus = claim.getClaimStatus();
	//			CachingMasterDataHelper cachingHelper = commonDataService.getCachingMasterDataHelper();
	//			String claimStatusDesc = CMiCUtil.getCommonCodeDesc(cachingHelper.findProcessStatus(claimStatus));
	//			LOG.info("Claim from service: claim no:{}, case id:{}, claim id:{}", claim.getClaimNo(), claim.getCaseId(), claim.getClaimId());
	//			benefitSettlement = settlementService.retrieveBenefitSettle(cmicEnvironmentHelper.getCmicCompanyId(), claim, claimStatusDesc, userInfoForm);
	//			model.addAttribute("benefitSettlement", benefitSettlement);
	//		} else {
	//			LOG.error("session null");
	//		}
	//		return "claim/settlementDetail";
	//	}

	@RequestMapping(value = "/settlementDetailODS/{claimId}", method = RequestMethod.GET)
	public String opensettlementDetailODS(@PathVariable Long claimId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		LOG.info("claim Id:{}", claimId);
		BenefitSettlement benefitSettlement = new BenefitSettlement();
		HttpSession session = httpServletRequest.getSession();
		if (session != null) {
			UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
			CMiCClaim cmicClaim = claimService.retrieveClaimDetailFromODS(model, cmicEnvironmentHelper.getCmicCompanyId(), claimId);
			Claim claim = cmicClaim.getClaimCanonical().getClaim();
			String claimStatus = claim.getClaimStatus();
			CachingMasterDataHelper cachingHelper = commonDataService.getCachingMasterDataHelper();
			String claimStatusDesc = CMiCUtil.getCommonCodeDesc(cachingHelper.findProcessStatus(claimStatus));
			benefitSettlement = settlementService.retrieveBenefitSettleODS(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim, claimStatusDesc, userInfoForm);
			model.addAttribute("benefitSettlement", benefitSettlement);
			LOG.info("Claim from service: claim no:{}, claim id:{}", claim.getClaimNo(), claim.getClaimId());
		} else {
			LOG.error("session null");
		}
		return "claim/settlementDetail";
	}

	@RequestMapping(value = "/settlementDetailByClaimId/{claimId}", method = RequestMethod.GET)
	public String opensettlementDetailByClaimId(@PathVariable Long claimId, ModelMap model, HttpServletRequest httpServletRequest) {
		//use for data that migrate without caseId
		LOG.info("claim Id:{}", claimId);
		BenefitSettlement benefitSettlement = new BenefitSettlement();
		HttpSession session = httpServletRequest.getSession();
		if (session != null) {
			UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);

			ClaimCanonical claimCano = claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId);
			Long caseId = claimCano.getClaim().getCaseId();
			CMiCClaim cmicClaim;
			try {
				cmicClaim = (caseId != null) ? workflowService.getClaimByIndex(caseId, userInfoForm) : new CMiCClaim();
			} catch (CMiCException e) {
				LOG.error("getclaim from 360 error:", e);
				cmicClaim = new CMiCClaim();
			}
			cmicClaim.setClaimCanonical(claimCano);

			Claim claim = cmicClaim.getClaimCanonical().getClaim();
			String claimStatus = claim.getClaimStatus();
			CachingMasterDataHelper cachingHelper = commonDataService.getCachingMasterDataHelper();
			String claimStatusDesc = CMiCUtil.getCommonCodeDesc(cachingHelper.findProcessStatus(claimStatus));
			LOG.info("Claim from service: claim no:{}, case id:{}, claim id:{}", claim.getClaimNo(), claim.getCaseId(), claim.getClaimId());
			benefitSettlement = settlementService.retrieveBenefitSettle(cmicEnvironmentHelper.getCmicCompanyId(), claim, claimStatusDesc, userInfoForm);
			model.addAttribute("benefitSettlement", benefitSettlement);
		} else {
			LOG.error("session null");
		}
		return "claim/settlementDetail";
	}

	@RequestMapping(value = "/ediDetail/{caseId}", method = RequestMethod.GET)
	public String openEdiDetailByClaimNo(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
		LOG.info("open Edit detial case id :{}", caseId);
		List<EdiBillingItem> ediBillingItems = null;
		List<EdiOrderItem> ediOrderItems = null;
		List<EdiLaboratory> ediLaborytoryList = null;
		List<EdiProcedure> ediProcedureList = null;
		List<EdiVitalSigns> ediVitalSignList = null;
		List<EdiDoctor> ediDoctorList = null;
		String claimNo = null;
		Integer occurrence = null;
		try {
			Claim claim = claimService.findClaimByCaseId(caseId);
			claimNo = claim.getClaimNo();
			occurrence = claim.getOccurrence();
			LOG.info("claim no :{}/{}", claimNo, occurrence);
			ediBillingItems = ediService.findEdiBillingItemsByClaimnoOccurrence(claimNo, occurrence);
			ediOrderItems = ediService.findEdiOrderItemsByClaimNoAndOccurrence(claimNo, occurrence);
			ediLaborytoryList = ediService.findEdiLaboratoryListByClaimNoAndOccurrence(claimNo, occurrence);
			ediProcedureList = ediService.findEdiProceduresByClaimNoAndOccurrence(claimNo, occurrence);
			ediVitalSignList = ediService.findEdiVitalSignsByClaimNoAndOccurrence(claimNo, occurrence);
			ediDoctorList = ediService.findEdiDoctorsByClaimNoAndOccurrence(claimNo, occurrence);

		} catch (Exception e) {
			LOG.error("open edi detail failed by: ", e);
		} finally {
			model.addAttribute("screenTitle", "EDI Detail");
			model.addAttribute("claimNo", claimNo);
			model.addAttribute("occurrence", occurrence);
			model.addAttribute("ediBillingItems", ediBillingItems);
			model.addAttribute("ediOrderItems", ediOrderItems);
			model.addAttribute("ediLaboratoryList", ediLaborytoryList);
			model.addAttribute("ediProcedureList", ediProcedureList);
			model.addAttribute("ediVitalSignList", ediVitalSignList);
			model.addAttribute("ediDoctorsList", ediDoctorList);
		}

		return "claim/ediDetail";
	}

	@RequestMapping(value = "/claimAuditReport", method = RequestMethod.GET)
	public String openClaimAuditReport(ModelMap model) {
		model.addAttribute("lstMarkingId", transformToLookupList(commonDataService.getCommonCode("BillingStatus", "Claim")));
		model.addAttribute("lstMarkingReason", transformToLookupList(commonDataService.getCommonCode("BillingDeclineReason", "Claim")));
		return "claim/claimAuditReport";
	}

	private void setRequestDocumentTypeList(ModelMap model) {
		List<ClaimDocumentType> lstCusPendingCode = claimService.getPendingCodeByType(ClaimCalculationEnum.ClaimRequirementStartPendingCode.CUSTOMER.getStart(), 1, 50);
		List<ClaimDocumentType> lstAgentPendingCode = claimService.getPendingCodeByType(ClaimCalculationEnum.ClaimRequirementStartPendingCode.AGENT.getStart(), 1, 50);
		List<ClaimDocumentType> lstIEPendingCode = claimService.getPendingCodeByType(ClaimCalculationEnum.ClaimRequirementStartPendingCode.IE.getStart(), 1, 50);
		List<ClaimDocumentType> lstOtherPendingCode = claimService.getPendingCodeByType(ClaimCalculationEnum.ClaimRequirementStartPendingCode.OTHER.getStart(), 1, 50);
		List<ClaimDocumentType> lstHospitalPendingCode = claimService.getPendingCodeByType(ClaimCalculationEnum.ClaimRequirementStartPendingCode.HOSPITAL.getStart(), 1, 50);
		model.addAttribute("lstCusPendingCode", lstCusPendingCode);
		model.addAttribute("lstAgentPendingCode", lstAgentPendingCode);
		model.addAttribute("lstHospitalPendingCode", lstHospitalPendingCode);
		model.addAttribute("lstIEPendingCode", lstIEPendingCode);
		model.addAttribute("lstOtherPendingCode", lstOtherPendingCode);
	}

	@RequestMapping(value = "/limit/{caseId}", method = RequestMethod.GET)
	public String openLimitDetail(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) throws IllegalAccessException, InvocationTargetException, Exception {
		Claim claim = claimService.findClaimByCaseId(caseId);
		Date date = claim.getAccidentDt() != null ? claim.getAccidentDt() : claim.getHospitalizationDate();
		CMiCClaim cmicClaim = new CMiCClaim();
		ClaimCanonical claimCanonical = new ClaimCanonical();
		claimCanonical.setClaim(claim);
		cmicClaim.setClaimCanonical(claimCanonical);
		LimitDetail detail = new LimitDetail(cmicClaim);
		List<LimitReport> grids = getLimitDetailGrid(cmicClaim, date);
		DataSourceResponse grid = new DataSourceResponse(grids, grids.size());

		if ("".equals(FormatUtil.convertNull(detail.getPolicyYearFromDt()))) {
			for (LimitReport lim : grids) {
				if (!"".equals(FormatUtil.formatDate(lim.getPolicyYearFromDt())) && !"".equals(FormatUtil.formatDate(lim.getPolicyYearToDt()))) {
					detail.setPolicyYearFromDt(FormatUtil.formatDate(lim.getPolicyYearFromDt()));
					detail.setPolicyYearToDt(FormatUtil.formatDate(lim.getPolicyYearToDt()));
					break;
				}
			}
		}
		model.addAttribute("detail", detail);
		model.addAttribute("detailGrid", grid);
		return "claim/section/limit_detail";
	}
	
	@RequestMapping(value = "/hnwDeductEntry/{caseId}", method = RequestMethod.GET)
	public String openHNWDeductEntry(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest,//
			@RequestParam(name = "from", required = false) String from
		    ) throws JsonProcessingException, IOException {
		CMiCClaim cmicClaim = new CMiCClaim();
		ClaimDeduct deduct360Case = new ClaimDeduct();
		
		Boolean scan = "scan".equals(from) ? Boolean.TRUE : Boolean.FALSE;
		if (caseId != null) {
			try {
				UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
				if(!scan){
				    cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
				}
				ClaimInfoTO claimInfoTO = workflowService.getClaimInfoTO(caseId, userInfoForm);
				deduct360Case.setCaseId(caseId);
				deduct360Case.setPolicyNo(claimInfoTO.getPolicyNo());
                deduct360Case.setCertNo(claimInfoTO.getCertNo());
                deduct360Case.setMemberId(claimInfoTO.getMemberId());
                deduct360Case.setFirstName(claimInfoTO.getInsuredFirstname());
                deduct360Case.setLastName(claimInfoTO.getInsuredLastname());
                deduct360Case.setPartyId(FormatUtil.convertBigDecimalToLong(claimInfoTO.getPartyId()));
				//cmicClaim = case360Helper.transformClaimInfoTOtoCMicClaim(claimInfoTO);
			} catch (CMiCException e) {
				e.printStackTrace();
			}

		}
		
		model.addAttribute("scan", scan);
		model.addAttribute("deduct360Case", deduct360Case);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("caseId", caseId);
		configCauseOfTreatmentSection(model, true, cmicClaim);
		PartySnapshot partySnap = new PartySnapshot();
		partySnap.setPartyId(FormatUtil.convertToString(deduct360Case.getPartyId()));
		partySnap.setPolicyNo(deduct360Case.getPolicyNo());
		if(cmicClaim != null && cmicClaim.getClaimCanonical() != null && cmicClaim.getClaimCanonical().getClaim() != null){
		    partySnap.setBusinessLine(cmicClaim.getClaimCanonical().getClaim().getBusinessLine());
		    deduct360Case.setBusinessLine(cmicClaim.getClaimCanonical().getClaim().getBusinessLine());
		}
		CMiCPartySnapshot cMiCPartySnapshot = prepareCMiCPartySnapshot(partySnap);
		PartySearchForm req = new PartySearchForm();
		req.setPolicyNumber(deduct360Case.getPolicyNo());
		List<CMiCPartySnapshot> dataOutput = new ArrayList<>();
		try{
		    searchPartyHNW(req, dataOutput);
		}catch(Exception e){
			LOG.error("search nw error ",e);
			cMiCPartySnapshot = null;
		}
		
		if(dataOutput != null && dataOutput.size() > 0){
			cMiCPartySnapshot = dataOutput.get(0);
		}else{
			cMiCPartySnapshot = null;
		}
		model.addAttribute("cMiCPartySnapshot", cMiCPartySnapshot);
		return "claim/hnw_deduct_accumulate";
	}
	
	private void searchPartyHNW(PartySearchForm req, List<CMiCPartySnapshot> dataOutput) throws Exception {
		if(req.getPolicyNumber() != null ){
			List<PartySnapshot> hnwData = partyService.searchPolicyHNW(req);
			for (PartySnapshot partySnapshot : hnwData) {
					CMiCPartySnapshot cmicPartySnapshot = prepareCMiCPartySnapshot(partySnapshot);
					dataOutput.add(cmicPartySnapshot);
			}
		}else{
			List<PartySnapshot> data = partyService.retrievePartyList("1", req.getPartyIdSearch(), req.getFirstName(), req.getLastName(), req.getNationalId(), null, null, req.getCustomerId(), req.getPolicyNumber()
					.toUpperCase(), req.getCertificateNumber(), req.getMemberId());
			List<String> hnwProductCodeList = Arrays.asList(CMiCUtil.HNW_PRODUCT_CODE);
			for(PartySnapshot cmicSnapshot: data){
				if (hnwProductCodeList.contains(cmicSnapshot.getPolicyNo())) {
						CMiCPartySnapshot cmicPartySnapshot = prepareCMiCPartySnapshot(cmicSnapshot);
						dataOutput.add(cmicPartySnapshot);
				}
			}
		}
	}
	
	private CMiCPartySnapshot prepareCMiCPartySnapshot(PartySnapshot partySnapshot) {
		final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		partySnapshot.setFirstName(partySnapshot.getFirstName() == null ? "" : partySnapshot.getFirstName().trim());
		partySnapshot.setLastName(partySnapshot.getLastName() == null ? "" : partySnapshot.getLastName().trim());
		partySnapshot.setMemberFirstName(partySnapshot.getMemberFirstName() == null ? "" : partySnapshot.getMemberFirstName().trim());
		partySnapshot.setMemberLastName(partySnapshot.getMemberLastName() == null ? "" : partySnapshot.getMemberLastName().trim());
		partySnapshot.setDob(FormatUtil.convertDateStringFromWS(partySnapshot.getDob()));
		partySnapshot.setVip(partySnapshot.getVip());
		partySnapshot.setNationalId(partySnapshot.getNationalId() == null ? null : partySnapshot.getNationalId().trim());
		partySnapshot.setGender(partySnapshot.getGender());
		CMiCPartySnapshot cmicPartySnapshot = new CMiCPartySnapshot(partySnapshot);
		try {
			cmicPartySnapshot.setAge(CMiCUtil.calculateAge(sdf.parse(partySnapshot.getDob())).toString());
		} catch (ParseException e) {
			LOG.error(" prepareCMiCPartySnapshot exception ", e);
		}
		return cmicPartySnapshot;
	}
	
	private void manageNonShareGrid(List<ClaimPolicy> claimPolicyList, LinkedHashMap<String, LimitReport> nonShareReportMap, String currentPolicyNo, String currentCertNo, String currentDependentNo, Date policyYearFromdt, Date policyYearTodt) {
		for (ClaimPolicy claimPolicy : claimPolicyList) {
			sortPolicyProductBenefitDetailCOASTByProductCodeBenfitCodeAscending(claimPolicy.getLimitNonShareDetailGrid());
			List<String> keepNonShareUnique = new ArrayList<>();
			for (PolicyProductBenefitDetailCOAST nonShareGrid : claimPolicy.getLimitNonShareDetailGrid()) {
				String claimNo = claimPolicy.getClaimNo();
				String benefitCode = nonShareGrid.getBenRefCd();
				String nonSharedKey = claimNo + nonShareGrid.getUniqueKey();
				String nonSharedUnique = claimNo + nonShareGrid.getUniqueKey();// uniquekey = productcode + benefitCd + SumCategory + SumTimeFrame
				if ("B".equals(nonShareGrid.getSumTimeFrame())) {
					// Per Disability
					nonSharedKey = claimNo + nonShareGrid.getUniqueKey();
					LOG.info("Per Disability nonSharedKey {}", nonSharedKey);
				} else if ("P".equals(nonShareGrid.getSumTimeFrame())) {
					// Per Year
					nonSharedKey = nonShareGrid.getUniqueKey();
					LOG.info("Per Year nonSharedKey {}", nonSharedKey);
				}
				if (!nonShareReportMap.containsKey(nonSharedKey)) {
					// new record
					List<BenefitLimit> benefitLimitList = new ArrayList<>();
					BigDecimal sumValue = new BigDecimal(0);
					BenefitLimit benefitLimit = new BenefitLimit();
					sumValue = findClaimpaymentDetailSumValue(nonShareGrid, benefitLimitList, benefitLimit, currentPolicyNo, currentCertNo, currentDependentNo, claimNo, benefitCode, policyYearFromdt, policyYearTodt);
					if (sumValue.compareTo(BigDecimal.ZERO) > 0) {
						LimitReport report = new LimitReport(nonShareGrid, benefitLimit);
						report.setValue(sumValue);
						nonShareReportMap.put(nonSharedKey, report);
					}

				} else {
					// if same nonSharedKey(prod, beneficode,sumTimeFrame, sumCategory) , also check it will not same claimNo.
					if (!keepNonShareUnique.contains(nonSharedUnique)) {
						List<BenefitLimit> benefitLimitList = new ArrayList<>();
						BigDecimal sumValue = new BigDecimal(0);
						BenefitLimit benefitLimit = new BenefitLimit();
						sumValue = findClaimpaymentDetailSumValue(nonShareGrid, benefitLimitList, benefitLimit, currentPolicyNo, currentCertNo, currentDependentNo, claimNo, benefitCode, policyYearFromdt, policyYearTodt);
						if (sumValue.compareTo(BigDecimal.ZERO) > 0) {
							LimitReport limitReport = nonShareReportMap.get(nonSharedKey);
							BigDecimal value = limitReport.getValue();
							limitReport.setValue(value.add(sumValue));
						}
					}
				}
				if (!keepNonShareUnique.contains(nonSharedUnique)) {
					keepNonShareUnique.add(nonSharedUnique);
				}
			}
		}
	}

	private void manageShareGrid(List<ClaimPolicy> claimPolicyList, LinkedHashMap<String, LimitReport> shareReportMap, String currentPolicyNo, String currentCertNo, String currentDependentNo, Date policyYearFromdt, Date policyYearTodt) {
		for (ClaimPolicy claimPolicy : claimPolicyList) {
			sortPolicyProductBenefitDetailCOASTByProductCodeBenfitCodeAscending(claimPolicy.getLimitSharedDetailGrid());
			List<String> keepShareUnique = new ArrayList<>();
			List<String> benefitCodeUnique = new ArrayList<>();
			for (PolicyProductBenefitDetailCOAST shareGrid : claimPolicy.getLimitSharedDetailGrid()) {
				String claimNo = claimPolicy.getClaimNo();
				String benefitCode = shareGrid.getBenRefCd();
				String productCode = shareGrid.getProdCd();
				Integer accumulatorNo = shareGrid.getAccumulatorNo();
				String sharedKey = "";
				String sharedUnique = claimNo + accumulatorNo + shareGrid.getUniqueKey();// uniquekey = productcode + benefitCd + SumCategory + SumTimeFrame
				if ("B".equals(shareGrid.getSumTimeFrame())) {
					// Per Disability
					sharedKey = claimNo + Integer.toString(accumulatorNo);
					LOG.info("Per Disability sharedKey {}", sharedKey);
				} else if ("P".equals(shareGrid.getSumTimeFrame())) {
					// Per Year
					sharedKey = Integer.toString(accumulatorNo);
					LOG.info("Per Year sharedKey {}", sharedKey);
				}
				if (!keepShareUnique.contains(sharedUnique)) {
					keepShareUnique.add(sharedUnique);
					List<BenefitLimit> benefitLimitList = new ArrayList<>();
					BenefitLimit benefitLimit = new BenefitLimit();
					BigDecimal sumValue = new BigDecimal(0);
					if (!benefitCodeUnique.contains(benefitCode)) {
						benefitCodeUnique.add(benefitCode);
						sumValue = findClaimpaymentDetailSumValue(shareGrid, benefitLimitList, benefitLimit, currentPolicyNo, currentCertNo, currentDependentNo, claimNo, benefitCode, policyYearFromdt, policyYearTodt);
						if (sumValue.compareTo(BigDecimal.ZERO) > 0) {
							addToShareReportMap(shareReportMap, sharedKey, shareGrid, benefitLimit, sumValue, productCode, benefitCode);
						}
					} else {
						if (sumValue.compareTo(BigDecimal.ZERO) > 0) {
							addToShareReportMap(shareReportMap, sharedKey, shareGrid, benefitLimit, sumValue, productCode, benefitCode);
						}
					}
				}
			}
		}
		/****/
		/*
		for (PolicyProductBenefitDetailCOAST shareGrid : tempMap.values()) {
			String sharedKey = "";
			LimitReport report = null;
			BenefitLimit lim = new BenefitLimit();
			for (BenefitLimit benefitLimit : cpd) {
				if (shareGrid.getBenRefCd().contains(FormatUtil.convertNull(benefitLimit.getBenefitCode()))) {
					try {
						BeanUtils.copyProperties(lim, benefitLimit);
					} catch (IllegalAccessException | InvocationTargetException e) {
						e.printStackTrace();
					}
					if ("B".equals(shareGrid.getSumTimeFrame())) {
						// 4.1.1 Per Disability
						sharedKey = benefitLimit.getClaimNo() + Integer.toString(shareGrid.getAccumulatorNo());
					} else if ("P".equals(shareGrid.getSumTimeFrame())) {
						// 4.1.2 Per Year
						sharedKey = Integer.toString(shareGrid.getAccumulatorNo());
					}
					if (!shareReports.containsKey(sharedKey)) {
						// 4.2.1 new record
						report = new LimitReport(shareGrid, benefitLimit);
						if ("C".equals(shareGrid.getSumCategory())) {
							report.setValue(new BigDecimal(benefitLimit.getReimbursedDay()));
						} else if ("A".equals(shareGrid.getSumCategory())) {
							report.setValue(benefitLimit.getAmount());
						}
						shareReports.put(sharedKey, report);
					} else {
						// 4.2.2.B old record
						report = shareReports.get(sharedKey);
						if ("A".equals(shareGrid.getSumCategory())) {
							amount = benefitLimit.getAmount();
						} else if ("C".equals(shareGrid.getSumCategory())) {
							amount = new BigDecimal(benefitLimit.getReimbursedDay());
						}
						//if("B".equals(shareGrid.getSumTimeFrame())){
						report.addBenefitDesc(shareGrid.getBenefitDesc());
						//}
						report.setValue(amount.add(report.getValue()));
					}
				}
		
			}
		
		}
		*/
	}

	private BigDecimal findClaimpaymentDetailSumValue(PolicyProductBenefitDetailCOAST shareGrid, List<BenefitLimit> benefitLimitList, BenefitLimit benefitLimit, String currentPolicyNo, String currentCertNo, String currentDependentNo, String claimNo, String benefitCode, Date policyYearFromdt, Date policyYearTodt) {
		String sumTimeFrame = shareGrid.getSumTimeFrame();
		String sumCategory = shareGrid.getSumCategory();
		benefitLimitList = claimPaymentDetailRepository.findClaimpaymentDirectByPolicyCertDependentNoClaimNo(currentPolicyNo, currentCertNo, currentDependentNo, claimNo, benefitCode);
		BigDecimal sumValue = new BigDecimal(0);
		benefitLimit.setBenefitCode(benefitCode);
		benefitLimit.setClaimNo(claimNo);
		benefitLimit.setPolicyYearFromDt(policyYearFromdt);
		benefitLimit.setPolicyYearToDt(policyYearTodt);
		if ("B".equals(sumTimeFrame)) {
			if ("A".equals(sumCategory)) {
				for (BenefitLimit ben : benefitLimitList) {
					sumValue = sumValue.add(ben.getAmount());
				}

			} else if ("C".equals(sumCategory)) {
				for (BenefitLimit ben : benefitLimitList) {
					BigDecimal days = new BigDecimal(ben.getReimbursedDay());
					sumValue = sumValue.add(days);
				}
			}
		}
		if ("P".equals(sumTimeFrame)) {
			if ("A".equals(sumCategory)) {
				for (BenefitLimit ben : benefitLimitList) {
					sumValue = sumValue.add(ben.getAmount());
				}

			} else if ("C".equals(sumCategory)) {
				for (BenefitLimit ben : benefitLimitList) {
					BigDecimal days = new BigDecimal(ben.getReimbursedDay());
					sumValue = sumValue.add(days);
				}
			}
		}

		return sumValue;
	}

	private void addToShareReportMap(LinkedHashMap<String, LimitReport> shareReportMap, String sharedKey, PolicyProductBenefitDetailCOAST shareGrid, BenefitLimit benefitLimit, BigDecimal sumValue, String productCode, String benefitCode) {
		if (!shareReportMap.containsKey(sharedKey)) {
			LimitReport report = new LimitReport(shareGrid, benefitLimit);
			report.setBenefitDesc(productCode + "-" + benefitCode);
			report.setValue(sumValue);
			shareReportMap.put(sharedKey, report);
		} else {
			LimitReport limitReport = shareReportMap.get(sharedKey);
			BigDecimal newValue = limitReport.getValue().add(sumValue);
			limitReport.setValue(newValue);
			limitReport.addBenefitDesc(productCode + "-" + benefitCode);
		}
	}

	@SuppressWarnings("unused")
	public List<LimitReport> getListLimitDetailReport(CMiCClaim cmicClaim, Date policyYearFromDt, Date policyYearToDt, String businessLine) {//, PolicyProductBenefitCOAST limit, boolean same) {
		String currentClaimNo = cmicClaim.getClaimCanonical().getClaim().getClaimNo();
		Integer currentOccurrence = cmicClaim.getClaimCanonical().getClaim().getOccurrence();
		String currentPolicyNo = cmicClaim.getClaimCanonical().getClaim().getPolicyNo();
		String currentCertNo = cmicClaim.getClaimCanonical().getClaim().getCertNo();
		String currentDependentNo = cmicClaim.getClaimCanonical().getClaim().getDependentNo();
		LOG.info(" open limit claim no :{}/{} pol:{}, cert:{} depNo:{}", currentClaimNo, currentOccurrence, currentPolicyNo, currentCertNo, currentDependentNo);
		List<LimitReport> reports = new ArrayList<>();
		LinkedHashMap<String, LimitReport> nonShareReports = new LinkedHashMap<String, LimitReport>();
		LinkedHashMap<String, LimitReport> shareReports = new LinkedHashMap<String, LimitReport>();
		LinkedHashMap<String, PolicyProductBenefitDetailCOAST> shareGripTemp = new LinkedHashMap<String, PolicyProductBenefitDetailCOAST>();
		List<BenefitLimit> cpd = new ArrayList<>();
		List<PolicyProductBenefitCOAST> policyProdBenCoasts = new ArrayList<PolicyProductBenefitCOAST>();
		List<ClaimPolicy> claimPolicyList = new ArrayList<ClaimPolicy>();
		Map<String, List<String>> claimOccMap = new HashMap<>();
		try {
			claimOccMap = claimService.findClaimsByHospitalDateInBetween(currentPolicyNo, currentCertNo, currentDependentNo, policyYearFromDt, policyYearToDt);
			Set<Entry<String, List<String>>> entrySet = claimOccMap.entrySet();
			Iterator<Entry<String, List<String>>> ite = entrySet.iterator();
			while (ite.hasNext()) {
				Entry<String, List<String>> next = ite.next();
				String clmNo = next.getKey();
				List<String> occs = claimService.findOccurrencesClaimByClaimNoAndPaided(cmicEnvironmentHelper.getCmicCompanyId(), clmNo);
				if (CollectionUtils.isNotEmpty(occs)) {
					Date minYearFromDt = claimPolicyRepository.getMinPolicyYearFromDtByClaimNoOccurence(cmicEnvironmentHelper.getCmicCompanyId(), currentPolicyNo, currentCertNo, currentDependentNo, clmNo, occs);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
					boolean isSame = sdf.format(minYearFromDt).equals(sdf.format(policyYearFromDt)) ? true : false;
					if (isSame) {
						ClaimPolicy claimPolicy = policyService.findClaimCoverageByClaimNoOccurrenceBusinessLineSumTimeFrames(cmicEnvironmentHelper.getCmicCompanyId(), clmNo, null, occs, businessLine, new String[] { "B", "P" });
						claimPolicyList.add(claimPolicy);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<LimitReport> limitReportList = new ArrayList<>();
		LinkedHashMap<String, LimitReport> nonShareReportMap = new LinkedHashMap<String, LimitReport>();
		manageNonShareGrid(claimPolicyList, nonShareReportMap, currentPolicyNo, currentCertNo, currentDependentNo, policyYearFromDt, policyYearToDt);
		LinkedHashMap<String, LimitReport> shareReportMap = new LinkedHashMap<String, LimitReport>();
		manageShareGrid(claimPolicyList, shareReportMap, currentPolicyNo, currentCertNo, currentDependentNo, policyYearFromDt, policyYearToDt);
		limitReportList.addAll(nonShareReportMap.values());
		for (LimitReport limitReport : limitReportList) {
			limitReport.setBenefitDesc(limitReport.getProdCd() + " - " + limitReport.getBenRefCd());
		}
		limitReportList.addAll(shareReportMap.values());
		sortLimitReportByClaimnoBenefitDescAscending(limitReportList);
		return limitReportList;

	}

	public List<LimitReport> getLimitDetailGrid(CMiCClaim cmicClaim, Date date) throws IllegalAccessException, InvocationTargetException {

		//1. Define variable
		List<LimitReport> reports = new ArrayList<>();
		HashMap<String, LimitReport> nonShareReports = new HashMap<String, LimitReport>();
		HashMap<String, LimitReport> shareReports = new HashMap<String, LimitReport>();
		HashMap<String, PolicyProductBenefitDetailCOAST> shareGripTemp = new HashMap<String, PolicyProductBenefitDetailCOAST>();

		PolicyProductBenefitCOAST limit = new PolicyProductBenefitCOAST();
		List<BenefitLimit> cpd = new ArrayList<>();
		try {
			ClaimPolicy claimPolicy = policyService.findLimitByClaimNoOccurrenceBusinessLine(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getClaimNo(), cmicClaim.getClaimCanonical().getClaim().getOccurrence());
			limit = new PolicyProductBenefitCOAST(claimPolicy, cmicClaim.getClaimCanonical().getClaim());
			ClaimPolicy minClaimPolicy = policyService.findMinClaimPolicyYearByPolicyNoCertNoClaimNo(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getPolicyNo(), cmicClaim.getClaimCanonical().getClaim().getCertNo(), cmicClaim.getClaimCanonical().getClaim().getClaimNo());
			if (BusinessLine.GE.toString().equalsIgnoreCase(claimPolicy.getBusinessLine())) {
				if (minClaimPolicy != null) {
					if (minClaimPolicy.getPolicyYearFromDt() != null && minClaimPolicy.getPolicyYearToDt() != null) {
						return getListLimitDetailReport(cmicClaim, minClaimPolicy.getPolicyYearFromDt(), minClaimPolicy.getPolicyYearToDt(), minClaimPolicy.getBusinessLine());
					}
				}
				return new ArrayList<LimitReport>();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		//2. Retrieve master data
		//try {
		/*
		ClaimPolicy claimPolicy = policyService.retrieveClaimPolicyFromCOAST(cmicClaim.getClaimCanonical().getClaim().getPolicyNo(), cmicClaim.getClaimCanonical().getClaim().getCertNo(),
				cmicClaim.getClaimCanonical().getClaim().getMemberId(), date, "1", FormatUtil.convertToString(cmicClaim.getClaimCanonical().getClaim().getPartyId()), new ArrayList<Dependent>(),
				null);
		policyService.populateLimit(claimPolicy);
		*/
		//					ClaimPolicy claimPolicy = policyService.findLimitByClaimNoOccurrenceBusinessLine(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getClaimNo(), cmicClaim.getClaimCanonical().getClaim().getOccurrence());
		//					limit = new PolicyProductBenefitCOAST(claimPolicy, cmicClaim.getClaimCanonical().getClaim());
		//					if (BusinessLine.GE.toString().equalsIgnoreCase(claimPolicy.getBusinessLine())) {
		//						return getGELimitDetailGrid(limit);
		//					}
		//				} catch (Exception e) {
		//					e.printStackTrace();
		//				}

		//3. Retrieve claim data
		if (limit.getLimitNonShareGrid() != null && limit.getLimitNonShareGrid().size() > 0) {
			try {
				cpd = claimPaymentDetailRepository.findClaimpaymentDirectByPolicyInPolicyYear(limit.getPolicyNo(), limit.getCertNo(), limit.getDependentNo(), limit.getPolicyYearFromDt(),
						limit.getPolicyYearToDt());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//4. Process Data
		BigDecimal amount = new BigDecimal("0");

		//4.1. NON-Shared benefit
		for (BenefitLimit benefitLimit : cpd) {
			for (PolicyProductBenefitDetailCOAST nonShareGrid : limit.getLimitNonShareGrid()) {
				BenefitLimit lim = new BenefitLimit();
				String nonSharedKey = "";
				LimitReport report = null;

				if (FormatUtil.convertNull(nonShareGrid.getBenRefCd()).equals(FormatUtil.convertNull(benefitLimit.getBenefitCode()))) {
					BeanUtils.copyProperties(lim, benefitLimit);

					if ("B".equals(nonShareGrid.getSumTimeFrame())) {
						// 4.1.1 Per Disability
						//nonSharedKey = benefitLimit.getClaimNo() + nonShareGrid.getBenRefCd();
						nonSharedKey = benefitLimit.getClaimNo() + nonShareGrid.getUniqueKey();
					} else if ("P".equals(nonShareGrid.getSumTimeFrame())) {
						// 4.1.2 Per Year
						//nonSharedKey = nonShareGrid.getBenRefCd();
						nonSharedKey = nonShareGrid.getUniqueKey();
					}

					if (!nonShareReports.containsKey(nonSharedKey)) {
						// 4.2.1 new record
						report = new LimitReport(nonShareGrid, benefitLimit);
						if ("C".equals(nonShareGrid.getSumCategory())) {
							report.setValue(new BigDecimal("1"));
						}
						nonShareReports.put(nonSharedKey, report);
					} else {
						// 4.2.2.B old record
						report = nonShareReports.get(nonSharedKey);
						if ("A".equals(nonShareGrid.getSumCategory())) {
							amount = benefitLimit.getAmount();
						} else if ("C".equals(nonShareGrid.getSumCategory())) {
							amount = new BigDecimal("1");
						}
						report.setValue(amount.add(report.getValue()));
					}
				}
			}
		}

		//4.2. Shared benefit
		if (limit.getLimitSharedGrid() != null) {
			for (PolicyProductBenefitDetailCOAST shareGrid : limit.getLimitSharedGrid()) {
				String sharedKey = shareGrid.getShareLimit();
				if (shareGripTemp.containsKey(sharedKey)) {
					shareGripTemp.get(sharedKey).addBenRefCd(shareGrid.getBenRefCd());
					shareGripTemp.get(sharedKey).addBenefitDesc(shareGrid.getProdCd() + " - " + shareGrid.getBenRefCd());
				} else {
					shareGrid.setBenefitDesc(shareGrid.getProdCd() + " - " + shareGrid.getBenRefCd());
					shareGripTemp.put(sharedKey, shareGrid);
				}
			}
		}

		for (BenefitLimit benefitLimit : cpd) {
			for (PolicyProductBenefitDetailCOAST shareGrid : shareGripTemp.values()) {
				String sharedKey = "";
				LimitReport report = null;
				BenefitLimit lim = new BenefitLimit();

				if (shareGrid.getBenRefCd().contains(FormatUtil.convertNull(benefitLimit.getBenefitCode()))) {
					BeanUtils.copyProperties(lim, benefitLimit);

					if ("B".equals(shareGrid.getSumTimeFrame())) {
						// 4.1.1 Per Disability
						sharedKey = benefitLimit.getClaimNo() + shareGrid.getBenefitDesc();
					} else if ("P".equals(shareGrid.getSumTimeFrame())) {
						// 4.1.2 Per Year
						sharedKey = shareGrid.getBenRefCd();
					}

					if (!shareReports.containsKey(sharedKey)) {
						// 4.2.1 new record
						report = new LimitReport(shareGrid, benefitLimit);
						if ("C".equals(shareGrid.getSumCategory())) {
							report.setValue(new BigDecimal("1"));
						}
						shareReports.put(sharedKey, report);
					} else {
						// 4.2.2.B old record
						report = shareReports.get(sharedKey);
						if ("A".equals(shareGrid.getSumCategory())) {
							amount = benefitLimit.getAmount();
						} else if ("C".equals(shareGrid.getSumCategory())) {
							amount = new BigDecimal("1");
						}
						report.setValue(amount.add(report.getValue()));
					}
				}
			}
		}

		reports.addAll(shareReports.values());
		reports.addAll(nonShareReports.values());

		for (LimitReport limitReport : nonShareReports.values()) {
			limitReport.setBenefitDesc(limitReport.getProdCd() + " - " + limitReport.getBenRefCd());
		}
		return reports;
	}

	public List<LimitReport> getGELimitDetailGrid(PolicyProductBenefitCOAST limit) {
		List<LimitReport> reports = new ArrayList<>();
		LinkedHashMap<String, LimitReport> nonShareReports = new LinkedHashMap<String, LimitReport>();
		LinkedHashMap<String, LimitReport> shareReports = new LinkedHashMap<String, LimitReport>();
		LinkedHashMap<String, PolicyProductBenefitDetailCOAST> shareGripTemp = new LinkedHashMap<String, PolicyProductBenefitDetailCOAST>();
		List<BenefitLimit> cpd = new ArrayList<>();
		//3. Retrieve claim data
		if (CollectionUtils.isNotEmpty(limit.getLimitNonShareGrid()) || CollectionUtils.isNotEmpty(limit.getLimitSharedGrid())) {
			try {
				cpd = claimPaymentDetailRepository.findClaimpaymentDirectByPolicyInPolicyYear(limit.getPolicyNo(), limit.getCertNo(), limit.getDependentNo(), limit.getPolicyYearFromDt(),
						limit.getPolicyYearToDt());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//4. Process Data
		BigDecimal amount = new BigDecimal("0");
		if (CollectionUtils.isNotEmpty(cpd)) {
			sortBenefitLimitByBenefitCodeAscending(cpd);
		}
		if (CollectionUtils.isNotEmpty(limit.getLimitNonShareGrid())) {
			sortPolicyProductBenefitDetailCOASTByProductCodeBenfitCodeAscending(limit.getLimitNonShareGrid());
		}
		//4.1. NON-Shared benefit
		for (BenefitLimit benefitLimit : cpd) {
			for (PolicyProductBenefitDetailCOAST nonShareGrid : limit.getLimitNonShareGrid()) {
				BenefitLimit lim = new BenefitLimit();
				String nonSharedKey = "";
				LimitReport report = null;

				if (FormatUtil.convertNull(nonShareGrid.getBenRefCd()).equals(FormatUtil.convertNull(benefitLimit.getBenefitCode()))) {
					try {
						BeanUtils.copyProperties(lim, benefitLimit);
					} catch (IllegalAccessException | InvocationTargetException e) {
						e.printStackTrace();
					}
					if ("B".equals(nonShareGrid.getSumTimeFrame())) {
						// 4.1.1 Per Disability
						nonSharedKey = benefitLimit.getClaimNo() + nonShareGrid.getUniqueKey();
					} else if ("P".equals(nonShareGrid.getSumTimeFrame())) {
						// 4.1.2 Per Year
						nonSharedKey = nonShareGrid.getUniqueKey();
					}

					if (!nonShareReports.containsKey(nonSharedKey)) {
						// 4.2.1 new record
						report = new LimitReport(nonShareGrid, benefitLimit);
						if ("C".equals(nonShareGrid.getSumCategory())) {
							report.setValue(new BigDecimal(benefitLimit.getReimbursedDay()));
						} else if ("A".equals(nonShareGrid.getSumCategory())) {
							report.setValue(benefitLimit.getAmount());
						}
						nonShareReports.put(nonSharedKey, report);
					} else {
						// 4.2.2.B old record
						report = nonShareReports.get(nonSharedKey);
						if ("A".equals(nonShareGrid.getSumCategory())) {
							amount = benefitLimit.getAmount();
						} else if ("C".equals(nonShareGrid.getSumCategory())) {
							amount = new BigDecimal(benefitLimit.getReimbursedDay());
						}
						if ("B".equals(nonShareGrid.getSumTimeFrame())) {
							report.setBenefitDesc(report.getBenefitDesc() + ", " + nonShareGrid.getBenefitDesc());
						}
						report.setValue(amount.add(report.getValue()));
					}
				}
			}
		}

		//4.2. Shared benefit
		if (limit.getLimitSharedGrid() != null) {
			sortPolicyProductBenefitDetailCOASTByProductCodeBenfitCodeAscending(limit.getLimitSharedGrid());
			for (PolicyProductBenefitDetailCOAST shareGrid : limit.getLimitSharedGrid()) {
				String sharedKey = shareGrid.getUniqueKey();
				if (shareGripTemp.containsKey(sharedKey)) {
					shareGripTemp.get(sharedKey).addBenRefCd(shareGrid.getBenRefCd());
					shareGripTemp.get(sharedKey).addBenefitDesc(shareGrid.getProdCd() + " - " + shareGrid.getBenRefCd());
				} else {
					shareGrid.setBenefitDesc(shareGrid.getProdCd() + " - " + shareGrid.getBenRefCd());
					shareGripTemp.put(sharedKey, shareGrid);
				}
			}
		}
		/*
						for (BenefitLimit benefitLimit : cpd) {
							for (PolicyProductBenefitDetailCOAST shareGrid : shareGripTemp.values()) {
								String sharedKey = "";
								LimitReport report = null;
								BenefitLimit lim = new BenefitLimit();
		
								if (shareGrid.getBenRefCd().contains(FormatUtil.convertNull(benefitLimit.getBenefitCode()))) {
									try {
										BeanUtils.copyProperties(lim, benefitLimit);
									} catch (IllegalAccessException | InvocationTargetException e) {
										e.printStackTrace();
									}
		
									if ("B".equals(shareGrid.getSumTimeFrame())) {
										// 4.1.1 Per Disability
										//sharedKey = benefitLimit.getClaimNo() + shareGrid.getUniqueKey();
										sharedKey = benefitLimit.getClaimNo() + Integer.toString(shareGrid.getAccumulatorNo());
									} else if ("P".equals(shareGrid.getSumTimeFrame())) {
										// 4.1.2 Per Year
										//sharedKey = shareGrid.getUniqueKey();
										sharedKey =  Integer.toString(shareGrid.getAccumulatorNo());
									}
		
									if (!shareReports.containsKey(sharedKey)) {
										// 4.2.1 new record
										report = new LimitReport(shareGrid, benefitLimit);
										if ("C".equals(shareGrid.getSumCategory())) {
											report.setValue(new BigDecimal(benefitLimit.getReimbursedDay()));
										}else if ("A".equals(shareGrid.getSumCategory())) {
											report.setValue(benefitLimit.getAmount());
										}
										shareReports.put(sharedKey, report);
									} else {
										// 4.2.2.B old record
										report = shareReports.get(sharedKey);
										if ("A".equals(shareGrid.getSumCategory())) {
											amount = benefitLimit.getAmount();
										} else if ("C".equals(shareGrid.getSumCategory())) {
											amount = new BigDecimal(benefitLimit.getReimbursedDay());
										}
										if("B".equals(shareGrid.getSumTimeFrame())){
											report.setBenefitDesc(report.getBenefitDesc() + ", " + shareGrid.getBenefitDesc());
										}
										report.setValue(amount.add(report.getValue()));
									}
								}
							}
						}
		*/
		for (PolicyProductBenefitDetailCOAST shareGrid : shareGripTemp.values()) {
			String sharedKey = "";
			LimitReport report = null;
			BenefitLimit lim = new BenefitLimit();
			for (BenefitLimit benefitLimit : cpd) {
				if (shareGrid.getBenRefCd().contains(FormatUtil.convertNull(benefitLimit.getBenefitCode()))) {
					try {
						BeanUtils.copyProperties(lim, benefitLimit);
					} catch (IllegalAccessException | InvocationTargetException e) {
						e.printStackTrace();
					}
					if ("B".equals(shareGrid.getSumTimeFrame())) {
						// 4.1.1 Per Disability
						sharedKey = benefitLimit.getClaimNo() + Integer.toString(shareGrid.getAccumulatorNo());
					} else if ("P".equals(shareGrid.getSumTimeFrame())) {
						// 4.1.2 Per Year
						sharedKey = Integer.toString(shareGrid.getAccumulatorNo());
					}
					if (!shareReports.containsKey(sharedKey)) {
						// 4.2.1 new record
						report = new LimitReport(shareGrid, benefitLimit);
						if ("C".equals(shareGrid.getSumCategory())) {
							report.setValue(new BigDecimal(benefitLimit.getReimbursedDay()));
						} else if ("A".equals(shareGrid.getSumCategory())) {
							report.setValue(benefitLimit.getAmount());
						}
						shareReports.put(sharedKey, report);
					} else {
						// 4.2.2.B old record
						report = shareReports.get(sharedKey);
						if ("A".equals(shareGrid.getSumCategory())) {
							amount = benefitLimit.getAmount();
						} else if ("C".equals(shareGrid.getSumCategory())) {
							amount = new BigDecimal(benefitLimit.getReimbursedDay());
						}
						//if("B".equals(shareGrid.getSumTimeFrame())){
						report.addBenefitDesc(shareGrid.getBenefitDesc());
						//}
						report.setValue(amount.add(report.getValue()));
					}
				}

			}
		}
		reports.addAll(shareReports.values());
		reports.addAll(nonShareReports.values());

		for (LimitReport limitReport : nonShareReports.values()) {
			limitReport.setBenefitDesc(limitReport.getProdCd() + " - " + limitReport.getBenRefCd());
		}
		sortLimitReportByClaimnoBenefitDescAscending(reports);
		return reports;
	}

	private void sortBenefitLimitByBenefitCodeAscending(List<BenefitLimit> benefitLimits) {
		Collections.sort(benefitLimits, new Comparator<BenefitLimit>() {
			@Override
			public int compare(BenefitLimit o1, BenefitLimit o2) {
				int result = 0;
				if (o1.getBenefitCode() == null && o2.getBenefitCode() == null) {
					result = 0;
				} else if (o1.getBenefitCode() == null) {
					result = -1;
				} else if (o2.getBenefitCode() == null) {
					result = 1;
				} else {
					result = o1.getBenefitCode().compareTo(o2.getBenefitCode());
				}
				return result;
			}
		});
	}

	private void sortPolicyProductBenefitDetailCOASTByProductCodeBenfitCodeAscending(List<PolicyProductBenefitDetailCOAST> policyProdBenfitDetails) {
		Collections.sort(policyProdBenfitDetails, new Comparator<PolicyProductBenefitDetailCOAST>() {
			@Override
			public int compare(PolicyProductBenefitDetailCOAST o1, PolicyProductBenefitDetailCOAST o2) {
				int result = 0;
				if (o1.getProdCd() == null && o2.getProdCd() == null) {
					result = 0;
				} else if (o1.getProdCd() == null) {
					result = -1;
				} else if (o2.getProdCd() == null) {
					result = 1;
				} else {
					result = o1.getProdCd().compareTo(o2.getProdCd());
				}
				if (result == 0) {
					if (o1.getBenRefCd() == null && o2.getBenRefCd() == null) {
						result = 0;
					} else if (o1.getBenRefCd() == null) {
						result = -1;
					} else if (o2.getBenRefCd() == null) {
						result = 1;
					} else {
						result = o1.getBenRefCd().compareTo(o2.getBenRefCd());
					}
				}
				return result;
			}
		});
	}

	private void sortLimitReportByClaimnoBenefitDescAscending(List<LimitReport> limitReports) {
		Collections.sort(limitReports, new Comparator<LimitReport>() {
			@Override
			public int compare(LimitReport o1, LimitReport o2) {
				int result = 0;
				if (FormatUtil.IsEmptyWithTrim(o1.getClaimNo()) && FormatUtil.IsEmptyWithTrim(o2.getClaimNo())) {
					result = 0;
				} else if (FormatUtil.IsEmptyWithTrim(o1.getClaimNo())) {
					result = -1;
				} else if (FormatUtil.IsEmptyWithTrim(o2.getClaimNo())) {
					result = 1;
				} else {
					result = o1.getClaimNo().compareTo(o2.getClaimNo());
				}
				if (result == 0) {
					if (FormatUtil.IsEmptyWithTrim(o1.getBenefitDesc()) && FormatUtil.IsEmptyWithTrim(o2.getBenefitDesc())) {
						result = 0;
					} else if (FormatUtil.IsEmptyWithTrim(o1.getBenefitDesc())) {
						result = -1;
					} else if (FormatUtil.IsEmptyWithTrim(o2.getBenefitDesc())) {
						result = 1;
					} else {
						result = o1.getBenefitDesc().compareTo(o2.getBenefitDesc());
					}
				}
				return result;
			}
		});
	}

	public void setConsentValue(ConsentOutputTO t ,Claim claim)
	{
		if(t != null)
		{
			if(t.getConsent() != null)
			{
				ConsentResponse consentTmp = null;
				for (int i = 0; i < t.getConsent().size(); i++) {
					String sourceSystem = t.getConsent().get(i).getSourceSystem();
					if(claim.getBusinessLine().equals("OL") || claim.getBusinessLine().equals("PA"))
					{
						if(sourceSystem.equalsIgnoreCase("IGM"))
						{
							consentTmp = t.getConsent().get(i);
							break;
						}
					}
					else if(claim.getBusinessLine().equals("CS"))
					{
						if(sourceSystem.equalsIgnoreCase("COAST"))
						{
							consentTmp = t.getConsent().get(i);
							break;
						}
					}
					else if(claim.getBusinessLine().equals("GE"))
					{
						if(sourceSystem.equalsIgnoreCase("GPSE"))
						{
							consentTmp = t.getConsent().get(i);
							break;
						}
					}
				}
				
				if(consentTmp != null)
				{
					for (int i = 0; i < consentTmp.getConsents().size(); i++) {
						String consentType  = consentTmp.getConsents().get(i).getConsentType();
						String consentValue = consentTmp.getConsents().get(i).getConsentValue();
						Long consentDate    = consentTmp.getConsents().get(i).getConsentSignDate();
						if(consentType.equals("1"))
						{
							String consentDec = commonCodeRepository.findCommonDescByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_DATA_PRIVACY_CATEGORY,CMiCUtil.COMMON_CODE_DATA_PRIVACY_CODE_NAME,consentValue);
							claim.setDataPrivacyConsent(consentDec);
							
							if(consentDate != 0)
							{
								Timestamp stamp 	 = new Timestamp(consentDate);
								Date date 			 = new Date(stamp.getTime());
								DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
							    String dateStr 		 = formatter.format(date);
								claim.setDataPrivacyConsentDate(dateStr);
							}
						}
					}
				}
			}
			else 
			{
				String consentDec = commonCodeRepository.findCommonDescByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_DATA_PRIVACY_CATEGORY,CMiCUtil.COMMON_CODE_DATA_PRIVACY_CODE_NAME,"1");
				claim.setDataPrivacyConsent(consentDec);
			}
		}
		else
		{
			String consentDec = commonCodeRepository.findCommonDescByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_DATA_PRIVACY_CATEGORY,CMiCUtil.COMMON_CODE_DATA_PRIVACY_CODE_NAME,"1");
			claim.setDataPrivacyConsent(consentDec);
		}
	}
}
