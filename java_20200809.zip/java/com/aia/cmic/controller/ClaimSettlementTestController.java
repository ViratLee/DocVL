package com.aia.cmic.controller;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.soap.uam.ArrayOfUserAuthForm;
import com.aia.cmic.repository.soap.uam.UserAuthForm;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.SettlementService;
import com.aia.cmic.uam.SecurityLevel;

@Controller
@RequestMapping("/claimSettlementTest")
public class ClaimSettlementTestController {

	@Autowired
	ClaimService claimService;

	@Autowired
	ClaimRepository claimRepository;

	@Autowired
	SettlementService settlementService;

	@RequestMapping(value = "/settleClaim", method = RequestMethod.GET)
	@ResponseBody
	public String settleClaimTest(ServletRequest request,@RequestParam(required = true) Long claimId, @RequestParam(defaultValue = "TH", required = false) String companyId) {		
		UserInfoForm userInfoForm = new UserInfoForm();
		//infoForm.setUserId("test");
		
		userInfoForm = new UserInfoForm();
		userInfoForm.setUserAuthForm(new ArrayOfUserAuthForm());
		UserAuthForm userAuthForm = new UserAuthForm();


		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DP");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DSK");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		
		//infoForm.setUserId("test");
		HttpServletRequest hsr = (HttpServletRequest) request;
		if(hsr.getUserPrincipal() != null ) {
			userInfoForm.setUserId(hsr.getUserPrincipal().getName());
		} else {
			userInfoForm.setUserId("asnpac0");
		}
		userInfoForm.setUserName("Bypass UAM");


		try {
			ClaimCanonical claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);
			// allocate
			settlementService.settleClaim(companyId, claimCanonical, userInfoForm);
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}

		return "OK";
	}

	@RequestMapping(value = "/settleProviderPayment", method = RequestMethod.GET)
	@ResponseBody
	public String settleProviderPaymentTest(ServletRequest request,
			@RequestParam(required = true) Long claimId,
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(required = false) String providerInvoiceNo) {
		UserInfoForm userInfoForm = new UserInfoForm();
		//infoForm.setUserId("test");
		
		userInfoForm = new UserInfoForm();
		userInfoForm.setUserAuthForm(new ArrayOfUserAuthForm());
		UserAuthForm userAuthForm = new UserAuthForm();


		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DP");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		userAuthForm = new UserAuthForm();
		userAuthForm.setFuncId("CMIC_DSK");
		userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
		userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);

		
		//infoForm.setUserId("test");
		HttpServletRequest hsr = (HttpServletRequest) request;
		if(hsr.getUserPrincipal() != null ) {
			userInfoForm.setUserId(hsr.getUserPrincipal().getName());
		} else {
			userInfoForm.setUserId("asnpac0");
		}
		userInfoForm.setUserName("Bypass UAM");

		try {
			ClaimCanonical claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);

			// allocate
			settlementService.settleProviderPayment(companyId, claimCanonical, providerInvoiceNo, userInfoForm);
		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
		return "OK";
	}

}
