package com.aia.cmic.controller;

import static com.aia.cmic.util.CMiCUtil.getCommonCodeDesc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.BenefitItem;
import com.aia.cmic.entity.Claim;
import com.aia.cmic.entity.ClaimDeduct;
import com.aia.cmic.entity.CommonCode;
import com.aia.cmic.entity.Provider;
import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.exception.CMiCException;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.CMiCClaim;
import com.aia.cmic.model.ClaimBenefitItem;
import com.aia.cmic.model.ClaimBrokenBone;
import com.aia.cmic.model.ClaimDeductDetail;
import com.aia.cmic.model.ClaimDiagnosisCode;
import com.aia.cmic.model.ClaimDiagnosisTest;
import com.aia.cmic.model.ClaimInjuryArea;
import com.aia.cmic.model.ClaimPhysician;
import com.aia.cmic.model.ClaimPlannedMedication;
import com.aia.cmic.model.ClaimPlannedSurgery;
import com.aia.cmic.model.ClaimProcedureCode;
import com.aia.cmic.model.ClaimReferral;
import com.aia.cmic.model.ClaimSpecialist;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.repository.BenefitItemRepository;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.CommonCodeRepository;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.restservices.model.ClaimInfoTO;
import com.aia.cmic.services.ClaimDeductService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.services.helper.ClaimHelper;
import com.aia.cmic.uam.Function;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.SecurityUtil;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimStatus;
import com.aia.cmic.workflow.Activity;

import groovy.util.logging.Log;

@Controller
@RequestMapping("/")
public class HNWDeductController {
	private static final Logger LOG = LoggerFactory.getLogger(HNWDeductController.class);
	@Autowired
	private ClaimDeductService claimDeductService;
	
	@Autowired
	private ClaimRepository claimRepository;
	
	@Autowired
	private CommonCodeRepository commonCodeRepository;
	
	@Autowired
	private BenefitItemRepository benefitItemRepository;
	
	@Autowired
	private ProviderService providerService;
	
	@Autowired
	private CachingMasterDataHelper cachingHelper;
	
	@Autowired
	private CMiCEnvironmentHelper cEnvironmentHelper;
	
	@Autowired
	private WorkflowService workflowService;
	
	@Autowired
	private Case360Helper case360Helper;
	
	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;
	
	@Autowired
	private ClaimService claimService;
	
	@Autowired
	private ClaimHelper claimHelper;
	
	@RequestMapping(value = "/homeHNWDeduct", method = RequestMethod.GET)
	public String openHomeHNWDeduct(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
		if(fnSet.contains(Function.CMIC_DEDUCT_INQ) && fnSet.contains(Function.CMIC_DEDUCT_PRC)){
			List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
			List<Lookup> newlstLocation = new ArrayList<>();
			String val = "";
			for (Lookup lookup : lstLocation) {
				if (!val.equals(lookup.getValue())) {
					lookup.setKey(lookup.getValue());
					newlstLocation.add(lookup);
					val = lookup.getValue();
				}
			}
			model.addAttribute("lstLocation", newlstLocation);
			return "homeHNWDeduct";	
		}else{
			LOG.info("User {} not permisson access home deduct page",userInfoForm.getUserId());
			return "homeBlank";
		}
		
	}
	
//	@RequestMapping(value = "/homeHNWDeductDetail", method = RequestMethod.GET)
//	public String openHomeHNWDeductDetail(ModelMap model, HttpServletRequest httpServletRequest) {
//		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
//		return "claim/hnw_deduct_accumulate_detail";
//	}
	
	
	@RequestMapping(value = "/copyClaimDeduct/{deductId}", method = RequestMethod.GET)
	public String copyClaimDeduct(@PathVariable Long deductId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {


		CMiCClaim cmicClaim = new CMiCClaim();
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		final Set<Function> fnSet = SecurityUtil.getAvaliavleFunction(userInfoForm);
		
		ClaimDeduct claimDeduct = claimDeductService.findClaimDeductByDeductId(deductId);
		if (claimDeduct != null) {
			com.aia.cmic.model.ClaimDeduct claimDeductModel = new com.aia.cmic.model.ClaimDeduct();
			claimDeductModel.setClaimDeductId(claimDeduct.getClaimDeductId());
			claimDeductModel.setClaimDeductNo(claimDeduct.getClaimDeductNo());
			claimDeductModel.setClaimNo(claimDeduct.getClaimNo());
			
			
			List<String> activityList = new ArrayList<>();
			activityList.add(Activity.DEDUCT.toString());
			/*cmicClaim = copyCMiCClaim(claimDeduct.getCaseId(), userInfoForm);
			cmicClaim.setCaseValidated(true);
			ClaimCanonical claimCanonical = cmicClaim.getClaimCanonical();
			com.aia.cmic.model.Claim claim1 = claimCanonical.getClaim();
			claim1.setPartyId(claimDeduct.getPartyId());
			claim1.setPolicyNo(claimDeduct.getPolicyNo());
			claim1.setFirstName(claimDeduct.getFirstName());
			claim1.setLastName(claimDeduct.getLastName());
			claim1.setProviderCode(claimDeduct.getProviderCode());
			claim1.setBusinessLine(claimDeduct.getBusinessLine());
			claim1.setAgentCodeServicing(claimDeduct.getServicingAgentCode());
			claim1.setAgencyOfficeCodeServicing(claimDeduct.getServicingAgencyCode());*/
			
			boolean canCalculate = true;
			ClaimInfoTO to = new ClaimInfoTO();
			to.setPartyId(new BigDecimal(claimDeduct.getPartyId()));
			to.setCauseOfTreatment(claimDeduct.getCauseOfTreatment());
			to.setPolicyNo(claimDeduct.getPolicyNo());
			to.setProviderCode(claimDeduct.getProviderCode());
			to.setCategory("RCLA");
			Long caseId = null;
			try
			{
				caseId = workflowService.createAndLockWork(to, userInfoForm, activityList);
				//CMiCClaim cmicClaim1 = claimHelper.retriveCMiCClaim(caseId, userInfoForm);
			}
			catch (Exception e) {
				// TODO: handle exception
				canCalculate = false;
				LOG.error("Cannot create CaseId");
			}
			
			if(caseId != null){
				claimDeductModel.setCaseId(caseId);
			}
			
			/*if(claimDeduct.getCaseId() != null){
				claimDeductModel.setCaseId(claimDeduct.getCaseId());
			}*/
			
			if(claimDeduct.getBusinessLine() != null){
				claimDeductModel.setBusinessLine(claimDeduct.getBusinessLine());
			}
			
			if(claimDeduct.getPartyId() != null) {
				claimDeductModel.setPartyId(claimDeduct.getPartyId());
			}
			
			if(claimDeduct.getServicingAgentCode() != null) {
				claimDeductModel.setServicingAgentCode(claimDeduct.getServicingAgentCode());
			}
			
			if(claimDeduct.getServicingAgencyCode() != null) {
				claimDeductModel.setServicingAgencyCode(claimDeduct.getServicingAgencyCode());
			}
			
			if(claimDeduct.getServicingGaOfficeCode() != null) {
				claimDeductModel.setServicingGaOfficeCode(claimDeduct.getServicingGaOfficeCode());
			}
			
			if(claimDeduct.getSubmissionSource() != null && !claimDeduct.getSubmissionSource().isEmpty())
			{
				CommonCode commonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeNameAndCodeValue(CMiCUtil.DEDUCT_CATEGRY, CMiCUtil.DEDUCT_SUBMISSION_SOURCE, claimDeduct.getSubmissionSource());
				if(commonCode != null)
				{
					claimDeductModel.setClaimFrom(commonCode.getCodeDesc());		
				}
				claimDeductModel.setSubmissionSource(claimDeduct.getSubmissionSource());
			}
			else
			{
				claimDeductModel.setClaimFrom("");			    
			}
			claimDeductModel.setPolicyNo(claimDeduct.getPolicyNo());
			if(claimDeduct.getBusinessLine().equals("CS"))
			{
				Claim claim = claimRepository.findClaimByCompanyIdAndClaimNoAndOccurrence(cEnvironmentHelper.getCmicCompanyId(), claimDeduct.getClaimNo(), claimDeduct.getOccurrence());
				if(claim != null)
				{
					claimDeductModel.setCertNo(claim.getCertNo());		      
					claimDeductModel.setMemberId(claim.getMemberId());
				}
			}
			else if(claimDeduct.getBusinessLine().equals("OL") || claimDeduct.getBusinessLine().equals("PA")) // IB
			{
				claimDeductModel.setCertNo("");		      
				claimDeductModel.setMemberId("");		    
			}
			claimDeductModel.setClaimantName(claimDeduct.getFirstName()+" "+claimDeduct.getLastName());
			if(claimDeduct.getProviderCode() != null && !claimDeduct.getProviderCode().isEmpty())
			{
				Provider medicalInstitute = null;
				String providerCode = claimDeduct.getProviderCode();
				Provider provider = null;
				if (FormatUtil.haveValue(providerCode)) {
					provider = providerService.getExistingProvider(providerCode);
				}

				if (provider != null) {
					String providerType = getCommonCodeDesc(cachingHelper.findProviderType(provider.getProviderType()));
					List<ProviderContact> lstProviderContact = providerService.findProviderContactByProviderCode(provider.getProviderCode());
					if (lstProviderContact.size() > 0) {
						if (CommonCode.REGION_OVERSEA.equalsIgnoreCase(lstProviderContact.get(0).getRegion())) {
							
						} else {
							medicalInstitute = provider;
						}
					}
				}
				
				if(medicalInstitute != null)
				{
					claimDeductModel.setMedicalInstitute(medicalInstitute.getProviderCode());  
				}
			}
			else
			{
				claimDeductModel.setMedicalInstitute("");   
			}
			
			
			if(claimDeduct.getTreatmentType() != null)
			{
				claimDeductModel.setTreatmentType(claimDeduct.getTreatmentType());
//				CommonCode commonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_TREATMENTTYPE_DATACATEGORY, CMiCUtil.COMMON_CODE_TREATMENTTYPE_CODENAME, claimDeduct.getTreatmentType());
//				if(commonCode != null)
//				{
//					claimDeductModel.setTreatmentType(commonCode.getCodeDesc());
//				}
			}
			else
			{
				claimDeductModel.setTreatmentType("");
			}
			
			if(claimDeduct.getCauseOfTreatment() != null)
			{
				claimDeductModel.setCauseOfTreatment(claimDeduct.getCauseOfTreatment());
//				CommonCode commonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_CAUSEOFTREATMENT_DATACATEGORY, CMiCUtil.COMMON_CODE_CAUSEOFTREATMENT_CODENAME, claimDeduct.getCauseOfTreatment());
//				if(commonCode != null)
//				{
//					claimDeductModel.setCauseOfTreatment(commonCode.getCodeDesc());
//				}
			}
			else
			{
				claimDeductModel.setCauseOfTreatment("");
			}
			
			claimDeductModel.setHospitalizationDate(claimDeduct.getHospitalizationDate());
			claimDeductModel.setDischargeDate(claimDeduct.getDischargeDate());
			claimDeductModel.setIcuAdmissionDate(claimDeduct.getIcuAdmissionDate());
			claimDeductModel.setIcuDischargeDate(claimDeduct.getIcuDischargeDate());
			List<ClaimDeductDetail> claimDeductDetailModelList = new ArrayList<ClaimDeductDetail>();
			List<com.aia.cmic.entity.ClaimDeductDetail> claimDeductDetailList = claimDeductService.findClaimDeductDetailByClaimDeductNo(claimDeduct.getClaimDeductNo());
			if(claimDeductDetailList != null && claimDeductDetailList.size() >0 )
			{
				for (int i = 0; i < claimDeductDetailList.size(); i++) {
					ClaimDeductDetail claimDeductDetailModel = new ClaimDeductDetail();
					
					ClaimDeduct claimDeductTmp = claimDeductService.findClaimDeductByDeductNo(claimDeductDetailList.get(i).getClaimDeductNo());
					if(claimDeductTmp != null)
					{
						claimDeductDetailModel.setClaimNo(claimDeductTmp.getClaimNo()+"/"+claimDeductTmp.getOccurrence());
					}
					if(claimDeductDetailList.get(i).getBenefitCode() != null && !claimDeductDetailList.get(i).getBenefitCode().isEmpty())
					{
						BenefitItem benefitItem = benefitItemRepository.findBenefitItemByBenefitItemCode(claimDeductDetailList.get(i).getBenefitCode());
						if(benefitItem != null)
						{
							claimDeductDetailModel.setBenefitItemId(benefitItem.getBenefitItemId());
							claimDeductDetailModel.setBenefitKey(benefitItem.getBenefitItemCode());
							claimDeductDetailModel.setBenefitCode(benefitItem.getBenefitItemCode()+"-"+benefitItem.getBenefitItemDesc());
						}
					}
					claimDeductDetailModel.setNoOfCallAllocated(claimDeductDetailList.get(i).getNoOfCallAllocated());
					claimDeductDetailModel.setNoOfDaysAllocated(claimDeductDetailList.get(i).getNoOfDaysAllocated());
					claimDeductDetailModel.setApprovedAmt(claimDeductDetailList.get(i).getApprovedAmt());
					claimDeductDetailModelList.add(claimDeductDetailModel);
				}
			}
		
			List<MasterLookup> lstTypeOfTreatment = cachingHelper.getTreatmentType() ;
			List<MasterLookup> lstCauseOfTreatment = cachingHelper.getCauseOfTreatment() ;
			model.addAttribute("lstTypeOfTreatment", lstTypeOfTreatment);
			model.addAttribute("lstCauseOfTreatment", lstCauseOfTreatment);
			model.addAttribute("claimDeduct"      , claimDeductModel);
			model.addAttribute("claimDeductDetail", claimDeductDetailModelList);
			model.addAttribute("cmicClaim"        , cmicClaim);
			model.addAttribute("copyClaimDeduct"  , true);
			model.addAttribute("canCalculate"     , canCalculate);
		}
		
		return "claim/hnw_deduct_accumulate";
	}
	
	private CMiCClaim copyCMiCClaim(Long caseId, UserInfoForm userInfoForm) throws Exception {
		CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
		if (cmicClaim.getClaimCanonical().getClaim().getClaimId() != null) {
			cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getClaimId()));
		} else {
			Long claimId = claimService.retriveClaimFromCaseId(caseId);
			if (claimId != null) {
				cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId));
			}
		}
		ClaimCanonical claimCano = cmicClaim.getClaimCanonical();
		ClaimCanonical cano = new ClaimCanonical();
		cano.setClaim(new com.aia.cmic.model.Claim());
		com.aia.cmic.model.Claim claim = cano.getClaim();
		BeanUtils.copyProperties(claimCano.getClaim(), claim);
		claim.setCaseId(null);
		claim.setClaimId(null);
		claim.setClaimNo(null);
		claim.setOccurrence(null);
		claim.setPreviousClaimNo(null);
		claim.setPreviousOccurrence(null);
		claim.setReceivedDate(cmicClaim.getClaimCanonical().getClaim().getReceivedDate());
		claim.setClaimStatus(null);
		claim.setProcessStatus(null);
		claim.setClaimStatusDt(null);
		claim.setCreatedBy(null);
		claim.setLastModifiedBy(null);
		claim.setCreatedDt(null);
		claim.setLastModifiedDt(null);
	
		for (ClaimInjuryArea claimInjuryArea : claimCano.getInjuryAreas()) {
			ClaimInjuryArea cia = new ClaimInjuryArea();
			BeanUtils.copyProperties(claimInjuryArea, cia);
			cia.setClaimSupplementId(null);
			cano.getInjuryAreas().add(cia);
		}
	
		for (ClaimDiagnosisTest claimDiagnosisTest : claimCano.getDiagnosisTests()) {
			ClaimDiagnosisTest cdt = new ClaimDiagnosisTest();
			BeanUtils.copyProperties(claimDiagnosisTest, cdt);
			cdt.setClaimSupplementId(null);
			cano.getDiagnosisTests().add(cdt);
		}
	
		for (ClaimDiagnosisCode claimDiagnosisCode : claimCano.getDiagnosisCodes()) {
			ClaimDiagnosisCode cdc = new ClaimDiagnosisCode();
			BeanUtils.copyProperties(claimDiagnosisCode, cdc);
			cdc.setClaimSupplementId(null);
			cano.getDiagnosisCodes().add(cdc);
		}
	
		for (ClaimProcedureCode claimProcedureCode : claimCano.getProcedureCodes()) {
			ClaimProcedureCode cpc = new ClaimProcedureCode();
			BeanUtils.copyProperties(claimProcedureCode, cpc);
			cpc.setClaimSupplementId(null);
			cano.getProcedureCodes().add(cpc);
		}
	
		for (ClaimBrokenBone claimBrokenBone : claimCano.getBrokenBones()) {
			ClaimBrokenBone cbb = new ClaimBrokenBone();
			BeanUtils.copyProperties(claimBrokenBone, cbb);
			cbb.setClaimSupplementId(null);
			cano.getBrokenBones().add(cbb);
		}
	
		for (ClaimPhysician claimPhysician : claimCano.getPhysicians()) {
			ClaimPhysician cp = new ClaimPhysician();
			BeanUtils.copyProperties(claimPhysician, cp);
			cp.setClaimSupplementId(null);
			cano.getPhysicians().add(cp);
		}
	
		for (ClaimSpecialist claimSpecialist : claimCano.getSpecialists()) {
			ClaimSpecialist cs = new ClaimSpecialist();
			BeanUtils.copyProperties(claimSpecialist, cs);
			cs.setClaimSupplementId(null);
			cano.getSpecialists().add(cs);
		}
	
		for (ClaimReferral claimReferral : claimCano.getReferrals()) {
			ClaimReferral cr = new ClaimReferral();
			BeanUtils.copyProperties(claimReferral, cr);
			cr.setClaimSupplementId(null);
			cano.getReferrals().add(cr);
		}
	
		for (ClaimPlannedMedication claimPlannedMedication : claimCano.getClaimPlannedMedications()) {
			ClaimPlannedMedication cpm = new ClaimPlannedMedication();
			BeanUtils.copyProperties(claimPlannedMedication, cpm);
			cpm.setClaimSupplementId(null);
			cano.getClaimPlannedMedications().add(cpm);
		}
	
		for (ClaimPlannedSurgery claimPlannedSurgery : claimCano.getClaimPlannedSurgerys()) {
			ClaimPlannedSurgery cps = new ClaimPlannedSurgery();
			BeanUtils.copyProperties(claimPlannedSurgery, cps);
			cps.setClaimSupplementId(null);
			cano.getClaimPlannedSurgerys().add(cps);
		}
	
		for (ClaimBenefitItem claimBenefitItem : claimCano.getBenefitItems()) {
			ClaimBenefitItem cbi = new ClaimBenefitItem();
			BeanUtils.copyProperties(claimBenefitItem, cbi);
			cbi.setClaimBenefitItemId(null);
			cbi.setClaimNo(null);
			cbi.setOccurrence(null);
			cano.getBenefitItems().add(cbi);
		}
		cmicClaim.setClaimCanonical(cano);
		return cmicClaim;
	}

}
