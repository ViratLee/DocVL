package com.aia.cmic.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.exception.CMiCException;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimStatus;
import com.aia.cmic.util.SecurityUtil;

@Controller
@RequestMapping("/payeeTest")
public class PayeeTestController {

	@Autowired
	ClaimService claimService;

	@RequestMapping(value = "/rebuildPayeeTable", method = RequestMethod.GET)
	@ResponseBody
	public String rebuildPayeeTable(@RequestParam(required = true) Long claimId, @RequestParam(defaultValue = "051", required = false) String companyId, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);

		try {
			// retrieve claim
			ClaimCanonical claimCanonical = claimService.retrieveClaimDetail(companyId, claimId);
			if (claimCanonical.getClaim().getClaimStatus().compareTo(ClaimStatus.PENDING.getValue()) > 0) {
				throw new Exception("Cannot rebuild Payee record, claim " + claimCanonical.getClaim().getClaimNo() + " status is at " + claimCanonical.getClaim().getClaimStatus());
			}

			claimService.rebuildPayeeTable(claimCanonical, userInfoForm);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CMiCException(e);
		}

		return "OK";
	}
}
