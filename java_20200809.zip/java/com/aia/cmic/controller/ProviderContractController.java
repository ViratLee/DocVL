package com.aia.cmic.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.entity.Network;
import com.aia.cmic.entity.ServiceItem;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.ProviderContractBO;
import com.aia.cmic.model.ProviderContractDetailForm;
import com.aia.cmic.model.ProviderContractForm;
import com.aia.cmic.model.ProviderContractSearchCriteria;
import com.aia.cmic.model.ProviderContractSearchResult;
import com.aia.cmic.repository.soap.uam.UserAuthForm;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.NetworkService;
import com.aia.cmic.services.ProviderContractService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.impl.ProviderContractServiceImpl;
import com.aia.cmic.uam.Function;
import com.aia.cmic.uam.SecurityLevel;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.SecurityUtil;

@Controller
@RequestMapping("/contract")
public class ProviderContractController {
	private static final Logger LOG = LoggerFactory.getLogger(ProviderContractController.class);
	@Autowired
	private ProviderContractService providerContractService;
	@Autowired
	private SecurityControlService securityControlService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;
	@Autowired
	private NetworkService networkService;

	@RequestMapping(value = "/contractDetail", method = RequestMethod.GET)
	public String initProviderContract(ModelMap model, HttpServletRequest httpServletRequest) {
		LOG.debug("### initProviderContract ###");
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!hasAuth(userInfoForm, Function.CMIC_CONTRACT_PRC)) {
			return openHomeBlank(model, userInfoForm);
		}

		ProviderContractForm form = new ProviderContractForm();

		String contractStatus = CMiCUtil.getCommonCodeDesc(commonDataService.getCachingMasterDataHelper().findContractStatus(ProviderContractServiceImpl.STATUS_DRAFTED));
		form.setContractStatus(ProviderContractServiceImpl.STATUS_DRAFTED);
		form.setContractStatusDesc(contractStatus);

		List<ProviderContractDetailForm> serviceList = new ArrayList<ProviderContractDetailForm>();

		for (ServiceItem serviceItem : commonDataService.getDefaultServiceItemByContractInd("Y")) {
			ProviderContractDetailForm f = new ProviderContractDetailForm();

			ServiceItem si = commonDataService.getServiceItem(serviceItem.getServiceCatId());
			if (si != null) {
				Lookup serviceCatId = new Lookup();
				serviceCatId.setKey(serviceItem.getServiceCatId());
				serviceCatId.setValue(serviceItem.getServiceCatId() + " - " + serviceItem.getServiceItemDesc());
				f.setServiceCatId(serviceCatId);
			}

			f.setDiscountOnListPrice("0");
			f.setListPrice("0");
			f.setAgreedFee("0");
			f.setDiscountInd(false);
			f.setNotPaidInd(false);
			serviceList.add(f);
		}

		HttpSession session = httpServletRequest.getSession();
		session.removeAttribute("addDocumentList");

		model.addAttribute("serviceItems", serviceList);

		model.addAttribute("form", form);
		model.addAttribute("capitatedServices", new ArrayList<ProviderContractDetailForm>());
		model.addAttribute("networks", new ArrayList<ProviderContractDetailForm>());
		model.addAttribute("networkList", networkService.getListAllNetworkCode());
		return "contract/contract";
	}

	@RequestMapping(value = "/contractDetail/{providerContractId}", method = RequestMethod.GET)
	public String openProviderContract(@PathVariable Long providerContractId, ModelMap model, HttpServletRequest httpServletRequest) {
		LOG.debug("### openProviderContract ### : {} ", providerContractId);
		boolean isApprover = false;
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		isApprover = hasAuth(userInfoForm, Function.CMIC_CONTRACT_APPROVAL_PRC);
		if (!hasAuth(userInfoForm, Function.CMIC_CONTRACT_PRC) && !hasAuth(userInfoForm, Function.CMIC_CONTRACT_APPROVAL_PRC)) {
			return openHomeBlank(model, userInfoForm);
		}
		ProviderContractForm form = new ProviderContractForm();
		//		String providerCode = "";
		if (providerContractId != null) {
			ProviderContractBO providerContractBO = providerContractService.getProviderContractByProvidercontractId(providerContractId);
			if (providerContractBO != null) { // if not exist, return to empty form
				form = ProviderContractForm.convertProviderContractBOToForm(providerContractBO, commonDataService);
			}
		}

		HttpSession session = httpServletRequest.getSession();
		session.removeAttribute("addDocumentList");

		model.addAttribute("form", form);
		model.addAttribute("isApprover", isApprover);
		model.addAttribute("serviceItems", form.getProviderContractDetailFormByType("servicelist"));
		model.addAttribute("packagePricings", form.getProviderContractDetailFormByType("packagepricing"));
		model.addAttribute("payments", form.getProviderContractDetailFormByType("payment"));
		model.addAttribute("capitatedServices", form.getProviderContractDetailFormByType("capitatedservice"));

		List<ProviderContractDetailForm> networkList = form.getProviderContractDetailFormByType("network");
		if (networkList != null) {
			for (int i = 0; i < networkList.size(); i++) {
				ProviderContractDetailForm network = networkList.get(i);
				if (!StringUtils.isEmpty(network.getNetworkId())) {
					Network networkObj = networkService.retrieveNetworkByNetworkId(FormatUtil.convertStringToLong(network.getNetworkId()));
					network.setNetworkName(networkObj.getNetworkName());
				}

			}
		}
		model.addAttribute("networks", networkList);
		model.addAttribute("networkList", networkService.getListAllNetworkCode());

		return "contract/contract";
	}

	@RequestMapping(value = "/renewcontract/{contractId}", method = RequestMethod.GET)
	public String initRenewContract(@PathVariable Integer contractId, ModelMap model, HttpServletRequest httpServletRequest) {
		LOG.debug("### initRenewContract ### : {} ", contractId);
		ProviderContractForm form = new ProviderContractForm();
		//		String providerCode = "";
		if (contractId != null) {
			ProviderContractBO providerContractBO = providerContractService.getProviderContractByContractId(contractId);
			if (providerContractBO != null) { // if not exist, return to empty form
				providerContractBO.getProviderContract().setProviderContractId(null);
				providerContractBO.getProviderContract().setContractId(null);
				providerContractBO.getProviderContract().setContractStatus(ProviderContractServiceImpl.STATUS_DRAFTED);
				providerContractBO.getProviderContract().setCreatedBy(null);
				providerContractBO.getProviderContract().setLastModifiedBy(null);
				providerContractBO.getProviderContract().setCreatedDt(null);
				providerContractBO.getProviderContract().setLastModifiedDt(null);

				for (int i = 0; i < providerContractBO.getProviderContractDetails().size(); i++) {
					providerContractBO.getProviderContractDetails().get(i).setProviderContractDetailId(null);
					providerContractBO.getProviderContractDetails().get(i).setProviderContractId(null);
					providerContractBO.getProviderContractDetails().get(i).setCreatedBy(null);
					providerContractBO.getProviderContractDetails().get(i).setLastModifiedBy(null);
					providerContractBO.getProviderContractDetails().get(i).setCreatedDt(null);
					providerContractBO.getProviderContractDetails().get(i).setLastModifiedDt(null);

				}

				form = ProviderContractForm.convertProviderContractBOToForm(providerContractBO, commonDataService);
			}
		}

		HttpSession session = httpServletRequest.getSession();
		session.removeAttribute("addDocumentList");
		model.addAttribute("form", form);
		model.addAttribute("serviceItems", form.getProviderContractDetailFormByType("servicelist"));
		model.addAttribute("packagePricings", form.getProviderContractDetailFormByType("packagepricing"));
		model.addAttribute("payments", form.getProviderContractDetailFormByType("payment"));
		model.addAttribute("capitatedServices", form.getProviderContractDetailFormByType("capitatedservice"));
		List<ProviderContractDetailForm> networkList = form.getProviderContractDetailFormByType("network");
		if (networkList != null) {
			for (int i = 0; i < networkList.size(); i++) {
				ProviderContractDetailForm network = networkList.get(i);
				Network networkObj = networkService.retrieveNetworkByNetworkId(FormatUtil.convertStringToLong(network.getNetworkId()));
				network.setNetworkName(networkObj.getNetworkName());
			}
		}
		model.addAttribute("networks", networkList);
		model.addAttribute("networkList", networkService.getListAllNetworkCode());
		return "contract/contract";
	}

	private boolean hasAuth(UserInfoForm userInfoForm, Function function) {

		Map<String, UserAuthForm> userAuthFormMap = new HashMap<String, UserAuthForm>();
		for (UserAuthForm userAuthForm : userInfoForm.getUserAuthForm().getUserAuthForm()) {
			userAuthFormMap.put(userAuthForm.getFuncId(), userAuthForm);
		}

		UserAuthForm userAuthForm = null;
		if ((userAuthForm = userAuthFormMap.get(function.toString())) != null && SecurityLevel.ALLOW.getLevel().equals(userAuthForm.getSecLev())) {
			return true;
		}

		return false;
	}

	private String openHomeBlank(ModelMap model, UserInfoForm userInfoForm) {
		return "redirect:/web/home";
	}

	@RequestMapping(value = "/contractList", method = RequestMethod.GET)
	public String openContract(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);

		if (!hasAuth(userInfoForm, Function.CMIC_CONTRACT_INQ)) {
			return openHomeBlank(model, userInfoForm);
		}

		ProviderContractSearchCriteria form = new ProviderContractSearchCriteria();
		model.addAttribute("form", form);
		return "contract/contractList";
	}

	@RequestMapping(value = "/contractApprovalList", method = RequestMethod.GET)
	public String openContractApproval(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!hasAuth(userInfoForm, Function.CMIC_CONTRACT_APPROVAL_PRC)) {
			return openHomeBlank(model, userInfoForm);
		}
		ProviderContractSearchCriteria form = new ProviderContractSearchCriteria();
		form.setProviderContractStatus(ProviderContractServiceImpl.STATUS_IN_APPROVAL);
		form.setProviderContractProcessStatus(ProviderContractServiceImpl.SUB_STATUS_WAIT_FOR_APPROVAL);
		List<ProviderContractSearchResult> list = providerContractService.searchContract(form);

		model.addAttribute("form", form);
		model.addAttribute("contractApprovalList", list);
		return "contract/contractApprovalList";
	}

	//	@RequestMapping(value = "/printContract/{contractId}", method = RequestMethod.GET)
	//	public void openContractApproval(@PathVariable("contractId") Integer contractId, ModelMap model, HttpServletResponse httpServletResponse) {
	//		LOG.debug("printContract : {}", contractId);
	//		ProviderContractBO contractBO = providerContractService.getProviderContractByContractId(contractId);
	//		LOG.debug("contractBO : {}", contractBO);
	//
	//		String xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	//		StringWriter sw = new StringWriter();
	//
	//		JAXBContext jaxbContext;
	//		ByteArrayOutputStream baos = null;
	//		//		FileOutputStream fout = null;
	//		//		File pdf = null;
	//		try {
	//			jaxbContext = JAXBContext.newInstance(ProviderContractBO.class);
	//			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
	//			jaxbMarshaller.marshal(contractBO, sw);
	//			LOG.debug("xml string :{}", sw.toString());
	//
	//			long start = System.currentTimeMillis();
	//			HashMap params = new HashMap();
	//			InputStream in = new ByteArrayInputStream(sw.toString().getBytes(StandardCharsets.UTF_8));
	//			Document document = JRXmlUtils.parse(in);
	//			params.put(JRXPathQueryExecuterFactory.PARAMETER_XML_DATA_DOCUMENT, document);
	//			//		    params.put(JRXPathQueryExecuterFactory.XML_DATE_PATTERN, "yyyy-MM-dd");
	//			//		    params.put(JRXPathQueryExecuterFactory.XML_NUMBER_PATTERN, "#,##0.##");
	//			//					    params.put(JRXPathQueryExecuterFactory.XML_LOCALE, Locale.ENGLISH);
	//			//					    params.put(JRParameter.REPORT_LOCALE, Locale.US);
	//
	//			//						JasperFillManager.fillReportToFile("D:/report/testxpath.jasper", params);
	//			JasperPrint print = JasperFillManager.fillReport(cmicEnvironmentHelper.getJasperformPath() + "/contract.jasper", params);
	//
	//			//			pdf = File.createTempFile("output.", ".pdf");
	//			//			fout = new FileOutputStream(pdf);
	//			//			baos = new ByteArrayOutputStream();
	//
	//			baos = new ByteArrayOutputStream();
	//			JRPdfExporter exporter = new JRPdfExporter();
	//			exporter.setExporterInput(new SimpleExporterInput(print));
	//			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(baos));
	//			SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
	//			//			configuration.setPdfJavaScript("this.print();");
	//			exporter.setConfiguration(configuration);
	//			exporter.exportReport();
	//
	//			ServletOutputStream out = httpServletResponse.getOutputStream();
	//			httpServletResponse.setHeader("Content-Disposition", "filename=" + contractId + ".pdf");
	//			httpServletResponse.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	//			httpServletResponse.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	//			httpServletResponse.setDateHeader("Expires", 0); // Proxies.
	//			httpServletResponse.setContentType("application/pdf");
	//
	//			out.write(baos.toByteArray());
	//			out.flush();
	//			out.close();
	//			System.err.println("Filling time : " + (System.currentTimeMillis() - start));
	//			//			fout.flush();
	//			//			fout.close();
	//			baos.flush();
	//			baos.close();
	//
	//		} catch (JAXBException e) {
	//			e.printStackTrace();
	//		} catch (JRException e) {
	//			e.printStackTrace();
	//		} catch (IOException e) {
	//			e.printStackTrace();
	//		}
	//		//		System.out.println(fout.size());
	//		//		return Response.ok((Object) pdf).header("Content-Disposition", "filename=test.pdf").build();
	//		//		return "contract/contractList";
	//	}

}
