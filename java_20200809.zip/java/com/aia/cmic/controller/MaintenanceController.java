package com.aia.cmic.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.AgencyPaymentSearchCriteria;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.util.SecurityUtil;

@Controller
@RequestMapping("/maintenance")
public class MaintenanceController {
	private static final Logger LOG = LoggerFactory.getLogger(MaintenanceController.class);
	private static final String PROVIDER_MANAGER = "PROVIDER_MANAGER"; // define further
	private static final String PRODUCT_MANAGER = "PRODUCT_MANAGER"; // define further

	private CommonDataService commonDataService;
	private CachingMasterDataHelper cachingHelper;

	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		this.commonDataService = commonDataService;
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}

	@Autowired
	private SecurityControlService securityControlService;

	@RequestMapping(value = "/commonCodeMaintenance", method = RequestMethod.GET)
	public String openCommonCodeMaintenance(HttpServletRequest request, ModelMap model) {

		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(request);
		String authorize = SecurityUtil.getMaintenanceAutorization(userInfoForm);
		model.addAttribute("authorize", authorize);
		return "commonCodeMaintenance";
	}

	@RequestMapping(value = "/commonCodeAgency", method = RequestMethod.GET)
	public String openCommonCodeAgency(HttpServletRequest request, ModelMap model) {

		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(request);
		String authorize = SecurityUtil.getMaintenanceAutorization(userInfoForm);

		List<MasterLookup> lstPaymentCodition = cachingHelper.getPaymentCodition();
		List<MasterLookup> lstDistributeCodition = cachingHelper.getDistributeCodition();
		AgencyPaymentSearchCriteria form = new AgencyPaymentSearchCriteria();
		model.addAttribute("form", form);
		model.addAttribute("lstPaymentCodition", lstPaymentCodition);
		model.addAttribute("lstDistributeCodition", lstDistributeCodition);
		model.addAttribute("authorize", authorize);
		return "commonCodeAgency";
	}
}
