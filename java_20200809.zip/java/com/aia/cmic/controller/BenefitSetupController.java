package com.aia.cmic.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.model.CMiCBenefitSetup;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.NetworkService;
import com.aia.cmic.services.PlanService;
import com.aia.cmic.services.ProductService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;

@Controller
@RequestMapping("/benefitSetup")
public class BenefitSetupController {
	private static final Logger LOG = LoggerFactory.getLogger(BenefitSetupController.class);

	@Autowired
	private CommonDataService commonDataService;

	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private PlanService planService;

	@Autowired
	private ProductService productService;

	@Autowired
	private NetworkService networkService;

	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;

	@RequestMapping(value = "/benefitSetup", method = RequestMethod.GET)
	public String openBenefitSetup(ModelMap model, @Context HttpServletRequest httpServletRequest) {
		try {
			HttpSession session = httpServletRequest.getSession();
			CMiCBenefitSetup cmicBenefitSetup;
			if (session != null) {
				if (session.getAttribute(cmicEnvironmentHelper.getBenefitSetupAttributeName()) == null) {
					cmicBenefitSetup = new CMiCBenefitSetup();
					session.setAttribute(cmicEnvironmentHelper.getBenefitSetupAttributeName(), cmicBenefitSetup);
				} else {
					cmicBenefitSetup = (CMiCBenefitSetup) session.getAttribute(cmicEnvironmentHelper.getBenefitSetupAttributeName());
				}
			}
			List<MasterLookup> lstBusinessLineCode = commonDataService.getCachingMasterDataHelper().getBusinessLine();
			List<Lookup> lstProductType = productService.getListAllProductType();
			List<Lookup> lstProductCode = productService.getListAllProductCode();
			List<Lookup> lstNetworkCode = networkService.getListAllNetworkCode();
			List<Lookup> lstPlanStatus = buildPlanStatusMasterLookupList();
			List<MasterLookup> lstBenefitType = commonDataService.getCachingMasterDataHelper().getBenefitType();

			List<Lookup> lstGeneralExclusionCode = getMockGECode();
			List<Lookup> lstGeographicLimitCode = getMockGeographicLimitCode();
			List<Lookup> lstCoverageTreatmentCode = getCoverageCauseTreatmentCode();
			List<Lookup> lstCoverMedConditionCode = getCoverMedicalConditionCode();
			List<Lookup> lstRestricSectorCode = getResctricSectorCode();
			List<Lookup> lstRestricRoomTypeCode = getResctricRoomTypeCode();
			model.addAttribute("lstBusinessLineCode", lstBusinessLineCode);
			model.addAttribute("lstProductCode", lstProductCode);
			model.addAttribute("lstProductType", lstProductType);
			model.addAttribute("lstNetworkCode", lstNetworkCode);
			model.addAttribute("lstPlanStatus", lstPlanStatus);
			model.addAttribute("lstBenefitType", lstBenefitType);
			model.addAttribute("lstGeneralExclusionCode", lstGeneralExclusionCode);
			model.addAttribute("lstGeographicLimitCode", lstGeographicLimitCode);
			model.addAttribute("lstCoverageTreatmentCode", lstCoverageTreatmentCode);
			model.addAttribute("lstCoverMedConditionCode", lstCoverMedConditionCode);
			model.addAttribute("lstRestricSectorCode", lstRestricSectorCode);
			model.addAttribute("lstRestricRoomTypeCode", lstRestricRoomTypeCode);

		} catch (Exception e) {
			LOG.error("error get code list", e);
		}
		return "benefit/benefitSetup";
	}

	private List<Lookup> getMockGECode() {
		String[][] array = new String[][] { { "1", "General Exclusion type" }// 
		, { "2", "Charge for non- medical expense (administrative fee)" }//
		, { "3", "Occupation" } //
		, { "4", "Equipment/Appliance" } //
		, { "5", "Prosthesis" } //
		, { "6", "Service delivered by unqualified provider" } //
		, { "7", "Service rendered in unqualified facility" } //
		, { "8", "Treatment due the specific cause" } //
		, { "9", "Pre-existing condition" } //
		};
		return asArrayList(array);
	}

	private List<Lookup> getMockGeographicLimitCode() {

		String[][] array = new String[][] { { "1", "Thailand" }// 
		, { "2", "England" }//
		, { "3", "Japan" } //
		}; //
		return asArrayList(array);
	}

	private List<Lookup> getCoverageCauseTreatmentCode() {
		String[][] array = new String[][] { { "1", "Accident or Illness" }// 
		, { "2", "Other option" } //
		}; //
		return asArrayList(array);
	}

	private List<Lookup> getCoverMedicalConditionCode() {
		String[][] array = new String[][] { { "1", "Cancer" }// 
		, { "2", "Dental Care" } //
		}; //
		return asArrayList(array);
	}

	private List<Lookup> getResctricSectorCode() {
		String[][] array = new String[][] { { "1", "Private" }, { "2", "Public" }, { "3", "No specification" } };
		return asArrayList(array);
	}

	private List<Lookup> getResctricRoomTypeCode() {
		String[][] array = new String[][] { { "1", "Room type table" }, { "2", "No restriction" }, { "3", "No specification" } };
		return asArrayList(array);

	}

	private List<Lookup> asArrayList(String[][] array) {
		List<Lookup> lookUpList = new ArrayList<Lookup>();
		for (int i = 0; i < array.length; i++) {
			Lookup lookup = new Lookup();
			lookup.setKey(array[i][0]);
			lookup.setValue(array[i][1]);
			lookUpList.add(lookup);
		}

		return lookUpList;
	}

	private List<Lookup> buildPlanStatusMasterLookupList() {
		String[][] array = new String[][] { { "A", "Active" }, { "T", "Terminate" } };
		return asArrayList(array);
	}
}
