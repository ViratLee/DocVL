package com.aia.cmic.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.services.CommonDataService;

@Controller
@RequestMapping("/printPdf")
public class CorrespondenceController {

	private CachingMasterDataHelper cachingHelper;
	
	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String start(ModelMap model, HttpServletRequest httpServletRequest) {

		return "correspondence/index";
	}
	
	@RequestMapping(value = "/pendingReport", method = RequestMethod.GET)
	public String pendingReport(ModelMap model, HttpServletRequest httpServletRequest) {
		
		try {
			return configDataEntryPage(model, httpServletRequest);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "homeBlank";
		
	}
	
	private String configDataEntryPage(
			ModelMap model,
			HttpServletRequest httpServletRequest
			) throws Exception {

		configGeneralSection(model);
		
		return "correspondence/pendingReport";

	}
	
	private void configGeneralSection(ModelMap model) {
		List<MasterLookup> lstSubmissionType = cachingHelper.getSubmissionType();
		List<MasterLookup> lstTypeOfTreatment = cachingHelper.getTreatmentType();
		
		model.addAttribute("lstSubmissionType", lstSubmissionType);
		model.addAttribute("lstTypeOfTreatment", lstTypeOfTreatment);
		
	}

}
