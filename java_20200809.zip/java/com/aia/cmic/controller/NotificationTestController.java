package com.aia.cmic.controller;

import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.exception.CMiCException;
import com.aia.cmic.model.SystemConfig;
import com.aia.cmic.repository.IposRepository;
import com.aia.cmic.repository.SystemConfigRepository;
import com.aia.cmic.repository.TIPSCustomerRepository;
import com.aia.cmic.repository.rest.response.customer.TIPSCustomerDetailResponse;
import com.aia.cmic.repository.rest.response.ipos.Notification;
import com.aia.cmic.repository.rest.response.ipos.Notifications;
import com.aia.cmic.repository.rest.response.ipos.PaidPolicy;
import com.aia.cmic.repository.rest.response.ipos.sendNotification.NotificationsResponse;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.helper.WebServiceClientHelper;
import com.aia.cmic.services.helper.WebServiceEnvironmentHelper;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.SecurityUtil;
import com.aia.th.webservice.customer.service.TIPSCustomerService;
import com.aia.th.webservice.customer.service.TIPSCustomerServiceService;

@Controller
@RequestMapping("/notification")
public class NotificationTestController {
	private static final Logger LOG = LoggerFactory.getLogger(NotificationTestController.class);

	@Autowired
	private IposRepository iposRepository;

	@Autowired
	private SystemConfigRepository systemConfigRepository;

	@Autowired
	private WebServiceClientHelper wsClientHelper;
	@Autowired
	private WebServiceEnvironmentHelper wsHelper;

	@Autowired
	private TIPSCustomerRepository tipsCustomerRepository;

	@RequestMapping(value = "/send", method = RequestMethod.GET)
	@ResponseBody
	public String openCommonCodeMaintenance(HttpServletRequest request, @RequestParam(required = true) String agentCode, @RequestParam(required = true) String policyNo) throws Exception {

		if (!isEnableSendNotification()) {
			return "not enable notification service";
		}

		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(request);

		Notifications notis = new Notifications();
		List<Notification> notiList = new ArrayList<Notification>();

		List<PaidPolicy> paidPolicies = new ArrayList<PaidPolicy>();
		PaidPolicy paidPol = new PaidPolicy();
		paidPol.setPolicyNo(policyNo);
		paidPol.setAgentCode(agentCode);
		paidPolicies.add(paidPol);

		Notification noti = new Notification();
		noti.setPartyId(new Long(1234));
		noti.setClientId("xxxx");
		noti.setCitizenId("xxxx");
		noti.setSubmittedPolicy(paidPol);

		noti.setClaimNo("C0000xxxxx");
		noti.setOccurrence("1");
		noti.setClaimStatus("Settled");
		noti.setClaimStatusDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH).format(new Date()));
		noti.setCustomerFirstName("นายกกก");
		noti.setCustomerLastName("นะคะ");
		noti.setClaimPaidAmount(BigDecimal.ZERO);
		noti.setTotalBillAmount(BigDecimal.ZERO);
		noti.setCompensationAmout(BigDecimal.ZERO);
		noti.setHospitalName("UUUU");

		noti.setPaidPolicies(paidPolicies);
		noti.setCustomerMobileNo(""); //require

		notiList.add(noti);
		notis.setNotifications(notiList);

		NotificationsResponse responses = iposRepository.sendNotification(notis, policyNo);
		if (null == responses || null == responses.getResponse() || "0".equalsIgnoreCase(responses.getResponse().getStatusCode())) {
			throw new CMiCException("Unable to retrieve response from iPos");
		}

		return "Success";
	}

	private boolean isEnableSendNotification() {
		boolean isEnable = false;

		List<SystemConfig> enables = systemConfigRepository.findSystemConfigByParamKey("cmic.sendNotification.enable");
		if (CollectionUtils.isNotEmpty(enables)) {
			SystemConfig systemConfig = enables.get(0);
			if ("Y".equals(systemConfig.getParamvalue())) {
				isEnable = true;
			}
		}

		return isEnable;
	}

//	@RequestMapping(value = "/getCustomerMobilNoByAlphaId", method = RequestMethod.GET)
//	@ResponseBody
//	public String getCustomerMobilNoByAlphaId(HttpServletRequest request, @RequestParam(required = true) String alphaId) throws Exception {
//		String mobileNo = "";
//
//		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(request);
//
//		//retrive customer detail from TIPS
//		TIPSCustomerService service = new TIPSCustomerServiceService(new URL(wsHelper.getTipsCustomerUrl()), wsHelper.getUseHttpsURLConnectionDefaultSslSocketFactory()).getTIPSCustomerService();
//		//TIPSCustomerService service = wsClientHelper.getCustomerServiceTIPs();
//		//TIPSCustomerDetailForm customerForm = service.getCustomerDetail(alphaId);
//		TIPSCustomerDetailResponse customerForm = tipsCustomerRepository.getTIPSCustomerDetail(alphaId);
//		if (customerForm != null) {
//			mobileNo = FormatUtil.convertNull(customerForm.getResult().get(0).getMobilePhone());
//		}
//
//		return "mobileNo[" + mobileNo + "]";
//	}
}
