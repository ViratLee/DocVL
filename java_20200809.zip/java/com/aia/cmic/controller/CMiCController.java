package com.aia.cmic.controller;

import static com.aia.cmic.util.CMiCUtil.getCommonCodeDesc;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.BenefitItem;
import com.aia.cmic.entity.Claim;
import com.aia.cmic.entity.ClaimAudit;
import com.aia.cmic.entity.ClaimDeduct;
import com.aia.cmic.entity.ClaimPolicy;
import com.aia.cmic.entity.CommonCode;
import com.aia.cmic.entity.Provider;
import com.aia.cmic.entity.ProviderAudit;
import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.exception.CMiCException;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.BenefitReimbursement;
import com.aia.cmic.model.CMiCClaim;
import com.aia.cmic.model.ChartData;
import com.aia.cmic.model.ClaimDeductDetail;
import com.aia.cmic.model.ClaimPolicyAccountNo;
import com.aia.cmic.model.DataEntryPageSecurity;
import com.aia.cmic.model.DoubleCiInquiry;
import com.aia.cmic.model.HistoricalPartyName;
import com.aia.cmic.model.HomeChartData;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.repository.BenefitItemRepository;
import com.aia.cmic.repository.ClaimPolicyRepository;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.CommonCodeRepository;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.restservices.model.AuditTrailTO;
import com.aia.cmic.restservices.model.ClaimInfoTO;
import com.aia.cmic.restservices.model.CountWorkParam;
import com.aia.cmic.restservices.model.CountWorkTO;
import com.aia.cmic.restservices.model.Document;
import com.aia.cmic.restservices.model.UserInfoTO;
import com.aia.cmic.services.CMiCMonitorService;
import com.aia.cmic.services.ClaimDeductService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.PartyService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.services.impl.AroundAdviceRequestTimeService;
import com.aia.cmic.uam.Function;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.SecurityUtil;
import com.aia.cmic.util.StringUtil;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimStatus;
import com.aia.cmic.workflow.Activity;

@Controller
@RequestMapping("/")
public class CMiCController {
	private static final Logger LOG = LoggerFactory.getLogger(CMiCController.class);
	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private ClaimService claimService;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private Case360Helper case360Helper;

	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;

	@Autowired
	private PartyService partyService;
	@Autowired
	private CMiCMonitorService cMiCMonitorService;

	private CommonDataService commonDataService;
	private CachingMasterDataHelper cachingHelper;

	@Autowired
	private CommonCodeRepository commonCodeRepository;
	
	@Autowired
	private CMiCEnvironmentHelper cEnvironmentHelper;
	
	@Autowired
	private ClaimPolicyRepository claimPolicyRepository;
	
	@Autowired
	private ClaimRepository claimRepository;
	
	@Autowired
	private BenefitItemRepository benefitItemRepository;
	
	@Autowired
	private ClaimDeductService claimDeductService;
	
	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		this.commonDataService = commonDataService;
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}

	@RequestMapping(value = "/userPreference", method = RequestMethod.GET)
	public String openUserPreference(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		Lookup all = new Lookup();
		all.setKey("All");
		all.setValue("All");
		List<MasterLookup> lstSubmissionType = commonDataService.getCachingMasterDataHelper().getSubmissionType();
		lstSubmissionType.add(0, all);
		List<MasterLookup> lstTypeOfTreatment = commonDataService.getCachingMasterDataHelper().getTreatmentType();
		lstTypeOfTreatment.add(0, all);
		List<MasterLookup> lstCliamPhase = commonDataService.getCachingMasterDataHelper().getPhase();
		lstCliamPhase.add(0, all);
		model.addAttribute("lstSubmissionType", lstSubmissionType);
		model.addAttribute("lstTypeOfTreatment", lstTypeOfTreatment);
		model.addAttribute("lstCliamPhase", lstCliamPhase);
		UserInfoTO userInfoTO = workflowService.getUserPreference(userInfoForm);
		if (userInfoTO.getClaimType() == null) {
			userInfoTO.setClaimType("All");
		}
		if (userInfoTO.getTypeOfService() == null) {
			userInfoTO.setTypeOfService("All");
		}
		if (userInfoTO.getPhase() == null) {
			userInfoTO.setPhase("All");
		}

		if (userInfoTO.getInsureType() == null) {
			userInfoTO.setInsureType("All");
		}

		if (userInfoTO.getIpdOpd() == null) {
			userInfoTO.setIpdOpd("All");
		}
		userInfoTO.setPhase(case360Helper.mapPhaseFromCase360(userInfoTO.getPhase()));
		userInfoTO.setInsureType(case360Helper.mapBusinessLineFromCase360(userInfoTO.getInsureType()));

		model.addAttribute("userInfoTO", userInfoTO);
		return "userPreference";
	}

	@RequestMapping(value = "/viewDocument", method = RequestMethod.GET)
	public String openViewDocument(ModelMap model, @RequestParam("src") String src) {

		String error = StringUtil.replaceForHtml(src);
		if (error != null && !error.trim().equals("")) {
			src = "";
		}
		model.addAttribute("src", src);
		return "viewDocument";
	}

	@RequestMapping(value = "/transferCase/{caseId}", method = RequestMethod.GET)
	public String openTransferCase(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
		if (cmicClaim.getClaimCanonical().getClaim().getClaimId() != null) {
			cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), cmicClaim.getClaimCanonical().getClaim().getClaimId()));
		}
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("lstDocument", cmicClaim.getLstDocument());
		model.addAttribute("taskTypeMap", workflowService.getTaskType(userInfoForm, cmicClaim.getActivity()));
		return "transferCase";
	}
	
	@RequestMapping(value = "/transferDeductCase/{caseId}", method = RequestMethod.GET)
	public String openTransferDeductCase(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = new CMiCClaim();
		ClaimCanonical claimCanonical = new ClaimCanonical();
		com.aia.cmic.model.Claim claim = new com.aia.cmic.model.Claim();
		try{
			ClaimInfoTO to = workflowService.getClaimInfoTO(caseId, userInfoForm);
			claim.setCaseId(caseId);
			claim.setPolicyNo(to.getPolicyNo());
			claim.setChannel(case360Helper.mapChannelFromCase360(to.getChannel()));
			claim.setReceivedDate(to.getDateReceived());
			claim.setPhase(case360Helper.mapPhaseFromCase360(to.getPhase()));
			List<Document> documentList = workflowService.findDocumentByCaseId(caseId, userInfoForm);
			cmicClaim.setLstDocument(documentList);
		}catch(Exception e){
			LOG.error("transferDeductCase ",e.getMessage());
		}
		claimCanonical.setClaim(claim);
		cmicClaim.setClaimCanonical(claimCanonical);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("lstDocument", cmicClaim.getLstDocument());
		model.addAttribute("taskTypeMap", workflowService.getTaskType(userInfoForm, cmicClaim.getActivity()));
		return "transferCase";
	}
	

	@RequestMapping(value = "/workflowAuditTrail/{caseId}", method = RequestMethod.GET)
	public String openWorkflowAuditTrail(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		List<AuditTrailTO> lstAuditTrailTO = workflowService.getAllAuditTrails(caseId, userInfoForm);
		model.addAttribute("lstAuditTrailTO", lstAuditTrailTO);
		model.addAttribute("screenTitle", "Workflow Audit Trail");
		return "auditTrail";
	}

	@RequestMapping(value = "/auditTrail/{claimNo}/{occurrence}", method = RequestMethod.GET)
	public String openAuditTrail(@PathVariable String claimNo, @PathVariable Integer occurrence, ModelMap model, HttpServletRequest httpServletRequest) {
		List<ClaimAudit> lstAuditTrailTO = claimService.getClaimAuditByClaimNoAndOccurrence(claimNo, occurrence);
		List<AuditTrailTO> lstOutput = new ArrayList<>();

		for (ClaimAudit claimAudit : lstAuditTrailTO) {
			AuditTrailTO auditTrailTO = new AuditTrailTO();
			auditTrailTO.setCreationDate(new Timestamp(claimAudit.getModifideDt().getTime()));
			auditTrailTO.setUserId(claimAudit.getUserId());
			auditTrailTO.setAction(formatAuditClaimMessage(claimAudit));
			lstOutput.add(auditTrailTO);
		}
		model.addAttribute("lstAuditTrailTO", lstOutput);
		model.addAttribute("screenTitle", "Audit Trail");
		return "auditTrail";
	}

	@RequestMapping(value = "/providerAudit/{providerCode}", method = RequestMethod.GET)
	public String openProviderAudit(@PathVariable String providerCode, ModelMap model, HttpServletRequest httpServletRequest) {
		List<ProviderAudit> lstAuditTrailTO = providerService.getProviderAuditByProviderCode(providerCode);
		List<AuditTrailTO> lstOutput = new ArrayList<>();
		AuditTrailTO auditTrailTO = null;
		for (ProviderAudit providerAudit : lstAuditTrailTO) {
			auditTrailTO = new AuditTrailTO();
			auditTrailTO.setCreationDate(new Timestamp(providerAudit.getModifiedDt().getTime()));
			auditTrailTO.setUserId(providerAudit.getUserId());
			auditTrailTO.setAction(formatAuditProviderMessage(providerAudit));
			lstOutput.add(auditTrailTO);
		}

		model.addAttribute("lstAuditTrailTO", lstOutput);
		model.addAttribute("screenTitle", "Provider Audit");
		return "auditTrail";
	}

	private String formatAuditProviderMessage(ProviderAudit providerAudit) {
		String msg;
		if ("INSERT".equalsIgnoreCase(providerAudit.getAction())) {
			msg = cmicEnvironmentHelper.getAuditProviderInsertMsgFmt();
		} else {
			if ("UPDATE".equalsIgnoreCase(providerAudit.getAction())) {
				msg = cmicEnvironmentHelper.getAuditProviderUpdateMsgFmt();
			} else {
				msg = cmicEnvironmentHelper.getAuditProviderDeleteMsgFmt();
			}
		}
		msg = msg.replace("{action}", providerAudit.getAction());
		msg = msg.replace("{providerAuditId}", providerAudit.getProviderAuditId().toString());
		msg = msg.replace("{providerCode}", providerAudit.getProviderCode());
		msg = msg.replace("{columnName}", providerAudit.getColumnName());
		msg = msg.replace("{modifideDt}", providerAudit.getModifiedDt().toString());
		msg = msg.replace("{recordId}", providerAudit.getRecordId() == null ? "[NULL]" : providerAudit.getRecordId());
		msg = msg.replace("{tableName}", providerAudit.getTableName());
		msg = msg.replace("{userId}", providerAudit.getUserId());
		msg = msg.replace("{valueAfter}", providerAudit.getValueAfter() == null ? "[NULL]" : providerAudit.getValueAfter());
		msg = msg.replace("{valueBefore}", providerAudit.getValueBefore() == null ? "[NULL]" : providerAudit.getValueBefore());
		return msg;
	}

	private String formatAuditClaimMessage(ClaimAudit claimAudit) {
		String msg;
		if ("INSERT".equalsIgnoreCase(claimAudit.getAction())) {
			msg = cmicEnvironmentHelper.getAuditClaimInsertMsgFmt();
		} else {
			if ("UPDATE".equalsIgnoreCase(claimAudit.getAction())) {
				msg = cmicEnvironmentHelper.getAuditClaimUpdateMsgFmt();
			} else {
				msg = cmicEnvironmentHelper.getAuditClaimDeleteMsgFmt();
			}
		}
		String[] encryptColumn = { "MEMBERLASTNAME", "MEMBERFIRSTNAME", "LASTNAME", "FIRSTNAME", "DOB", "NATIONALID" };
		boolean encrypt = Arrays.asList(encryptColumn).contains(claimAudit.getColumnName().toUpperCase());
		msg = msg.replace("{action}", claimAudit.getAction());
		msg = msg.replace("{claimAuditId}", claimAudit.getClaimAuditId().toString());
		msg = msg.replace("{claimNo}", claimAudit.getClaimNo());
		msg = msg.replace("{columnName}", claimAudit.getColumnName());
		msg = msg.replace("{modifideDt}", claimAudit.getModifideDt().toString());
		msg = msg.replace("{occurrence}", claimAudit.getOccurrence().toString());
		msg = msg.replace("{recordId}", claimAudit.getRecordId() == null ? "[NULL]" : claimAudit.getRecordId());
		msg = msg.replace("{tableName}", claimAudit.getTableName());
		msg = msg.replace("{userId}", claimAudit.getUserId());
		String valueAfter = (claimAudit.getValueAfter() != null && encrypt) ? claimService.decryptValue(claimAudit.getValueAfter()) : claimAudit.getValueAfter();
		msg = msg.replace("{valueAfter}", valueAfter == null ? "[NULL]" : valueAfter);
		String valueBefore = (claimAudit.getValueBefore() != null && encrypt) ? claimService.decryptValue(claimAudit.getValueAfter()) : claimAudit.getValueBefore();
		msg = msg.replace("{valueBefore}", valueBefore == null ? "[NULL]" : valueBefore);
		return msg;
	}

	@RequestMapping(value = "/customerMatching", method = RequestMethod.GET)
	public String openCustomerMatching(ModelMap model, HttpServletRequest httpServletRequest) {
		return "customerMatching";
	}

	@RequestMapping(value = "/nameHistory/{partyId}", method = RequestMethod.GET)
	public String openCustomerMatching(@PathVariable Long partyId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		List<HistoricalPartyName> lstHistoricalPartyNames = partyService.getHistoricalPartyName("1", partyId.toString());
		model.addAttribute("lstHistoricalPartyNames", lstHistoricalPartyNames);
		return "nameHistory";
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String openHome(ModelMap model, HttpServletRequest httpServletRequest) {
		return "homeBlank";
	}

	@RequestMapping(value = "/homeDirector", method = RequestMethod.GET)
	public String homeDirector(ModelMap model) {
		return "homeDirector";
	}

	@RequestMapping(value = "/homeIndexing", method = RequestMethod.GET)
	public String openHomeIndexing(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_INDEX_PRC)) {
			return "homeBlank";
		}
		List<Activity> activityList = new ArrayList<>();
		activityList.add(Activity.INDEXING);

		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		model.addAttribute("homeChartData", prepareChart(userInfoForm, activityList));
		return "homeIndexing";
	}

	@RequestMapping(value = "/homeEligibility", method = RequestMethod.GET)
	public String openHomeEligibility(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_ELIGIBILITY_PRC)) {
			return "homeBlank";
		}
		List<Activity> activityList = new ArrayList<>();
		activityList.add(Activity.MANUALREVIEW);
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		model.addAttribute("homeChartData", prepareChart(userInfoForm, activityList));
		return "homeBenefitDetermination";
	}

	@RequestMapping(value = "/homeDataEntry", method = RequestMethod.GET)
	public String openHomeDataEntry(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DATAENTRY_DATAENTRY_PRC) && !SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DATAENTRY_MEDICAL_PRC)) {
			return "homeBlank";
		}
		model.addAttribute("homeChartData", prepareChart(userInfoForm, CMiCUtil.retriveHomeDataEntryActvityList(userInfoForm)));
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeCaseValidation";
	}

	@RequestMapping(value = "/homeMedicalReview", method = RequestMethod.GET)
	public String openHomeMedicalReview(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DATAENTRY_MEDICALREV_PRC)) {
			return "homeBlank";
		}
		List<Activity> activityList = new ArrayList<>();
		activityList.add(Activity.MEDICALREVIEW);
		model.addAttribute("homeChartData", prepareChart(userInfoForm, activityList));
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeMedicalReview";
	}

	@RequestMapping(value = "/homeDoctorConsultant", method = RequestMethod.GET)
	public String openHomeDoctorReview(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		List<Activity> activityList = new ArrayList<>();
		activityList.add(Activity.CONSULT);
		model.addAttribute("homeChartData", prepareChart(userInfoForm, activityList));
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeDoctorConsultant";
	}

	@RequestMapping(value = "/homeIE", method = RequestMethod.GET)
	public String openHomeIE(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		List<Activity> activityList = new ArrayList<>();
		activityList.add(Activity.CONSULT);
		model.addAttribute("homeChartData", prepareChart(userInfoForm, activityList));
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeIE";
	}

	@RequestMapping(value = "/homeValidationReport", method = RequestMethod.GET)
	public String openHomeValidationReport(ModelMap model, HttpServletRequest httpServletRequest) {
		model.addAttribute("validationActionTaken", cachingHelper.getValidationActionTakenMap());
		model.addAttribute("validationReview", cachingHelper.getValidationReviewMap());

		//		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		//		List<Activity> activityList = new ArrayList<>();
		//		activityList.add(Activity.CONSULT);
		//		model.addAttribute("homeChartData", prepareChart(userInfoForm, activityList));
		//		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		//		List<Lookup> newlstLocation = new ArrayList<>();
		//		String val = "";
		//		for (Lookup lookup : lstLocation) {
		//			if (!val.equals(lookup.getValue())) {
		//				lookup.setKey(lookup.getValue());
		//				newlstLocation.add(lookup);
		//				val = lookup.getValue();
		//			}
		//		}
		//		model.addAttribute("lstLocation", newlstLocation);
		return "correspondence/validationReport";
	}
	
	@RequestMapping(value = "/homeDeductInquiry", method = RequestMethod.GET)
	public String openHomeDeductInquiry(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DEDUCT_INQ)) {
			return "homeBlank";
		}
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeDeductInquiry";
	}
	
	@RequestMapping(value = "/caseDeductInquiry/{deductId}", method = RequestMethod.GET)
	public String openCaseDeductInquiry(@PathVariable Long deductId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		LOG.debug(" openCaseDeductInquiry ");
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		ClaimDeduct claimDeduct = claimDeductService.findClaimDeductByDeductId(deductId);
		if (claimDeduct != null) {
			
			com.aia.cmic.model.ClaimDeduct claimDeductModel = new com.aia.cmic.model.ClaimDeduct();
			claimDeductModel.setClaimDeductId(claimDeduct.getClaimDeductId());
			claimDeductModel.setCaseId(claimDeduct.getCaseId());
			claimDeductModel.setClaimDeductNo(claimDeduct.getClaimDeductNo());
			claimDeductModel.setClaimNo(claimDeduct.getClaimNo());
			if(claimDeduct.getSubmissionSource() != null && !claimDeduct.getSubmissionSource().isEmpty()){
				CommonCode commonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeNameAndCodeValue(CMiCUtil.DEDUCT_CATEGRY, CMiCUtil.DEDUCT_SUBMISSION_SOURCE, claimDeduct.getSubmissionSource());
				if(commonCode != null)
				{
					claimDeductModel.setClaimFrom(commonCode.getCodeDesc());		
				}
			}
			else{
				claimDeductModel.setClaimFrom("");			    
			}
			claimDeductModel.setPolicyNo(claimDeduct.getPolicyNo());
			if(claimDeduct.getBusinessLine().equals("CS"))
			{
				Claim claim = claimRepository.findClaimByCompanyIdAndClaimNoAndOccurrence(cEnvironmentHelper.getCmicCompanyId(), claimDeduct.getClaimNo(), claimDeduct.getOccurrence());
				if(claim != null)
				{
					claimDeductModel.setCertNo(claim.getCertNo());		      
					claimDeductModel.setMemberId(claim.getMemberId());
				}
			}
			else if(claimDeduct.getBusinessLine().equals("OL") || claimDeduct.getBusinessLine().equals("PA")) // IB
			{
				claimDeductModel.setCertNo("");		      
				claimDeductModel.setMemberId("");		    
			}
			claimDeductModel.setClaimantName(claimDeduct.getFirstName()+" "+claimDeduct.getLastName());
			if(claimDeduct.getProviderCode() != null && !claimDeduct.getProviderCode().isEmpty()){
				Provider medicalInstitute = null;
				String providerCode = claimDeduct.getProviderCode();
				Provider provider = null;
				if (FormatUtil.haveValue(providerCode)) {
					provider = providerService.getExistingProvider(providerCode);
				}
				if (provider != null) {
					String providerType = getCommonCodeDesc(cachingHelper.findProviderType(provider.getProviderType()));
					List<ProviderContact> lstProviderContact = providerService.findProviderContactByProviderCode(provider.getProviderCode());
					if (lstProviderContact.size() > 0) {
						if (CommonCode.REGION_OVERSEA.equalsIgnoreCase(lstProviderContact.get(0).getRegion())) {
							
						} else {
							medicalInstitute = provider;
						}
					}
				}
				if(medicalInstitute != null){
					claimDeductModel.setMedicalInstitute(medicalInstitute.getProviderNameThai() +" - "+medicalInstitute.getProviderCode());  
				}
			}
			else{
				claimDeductModel.setMedicalInstitute("");   
			}
			
			if(claimDeduct.getTreatmentType() != null){
				CommonCode commonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_TREATMENTTYPE_DATACATEGORY, CMiCUtil.COMMON_CODE_TREATMENTTYPE_CODENAME, claimDeduct.getTreatmentType());
				if(commonCode != null){
					claimDeductModel.setTreatmentType(commonCode.getCodeDesc());
				}
			}
			else{
				claimDeductModel.setTreatmentType("");
			}
			
			if(claimDeduct.getCauseOfTreatment() != null){
				CommonCode commonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeNameAndCodeValue(CMiCUtil.COMMON_CODE_CAUSEOFTREATMENT_DATACATEGORY, CMiCUtil.COMMON_CODE_CAUSEOFTREATMENT_CODENAME, claimDeduct.getCauseOfTreatment());
				if(commonCode != null){
					claimDeductModel.setCauseOfTreatment(commonCode.getCodeDesc());
				}
			}
			else{
				claimDeductModel.setCauseOfTreatment("");
			}
			
			claimDeductModel.setHospitalizationDate(claimDeduct.getHospitalizationDate());
			claimDeductModel.setDischargeDate(claimDeduct.getDischargeDate());
			claimDeductModel.setIcuAdmissionDate(claimDeduct.getIcuAdmissionDate());
			claimDeductModel.setIcuDischargeDate(claimDeduct.getIcuDischargeDate());
			List<ClaimDeductDetail> claimDeductDetailModelList = new ArrayList<ClaimDeductDetail>();
			List<com.aia.cmic.entity.ClaimDeductDetail> claimDeductDetailList = claimDeductService.findClaimDeductDetailByClaimDeductNo(claimDeduct.getClaimDeductNo());
			if(claimDeductDetailList != null && claimDeductDetailList.size() >0 )
			{
				for (int i = 0; i < claimDeductDetailList.size(); i++) {
					ClaimDeductDetail claimDeductDetailModel = new ClaimDeductDetail();
					
					ClaimDeduct claimDeductTmp = claimDeductService.findClaimDeductByDeductNo(claimDeductDetailList.get(i).getClaimDeductNo());
					if(claimDeductTmp != null){
						if(claimDeductTmp.getRefClaimNo() != null && claimDeductTmp.getRefOccurrence() != null){
							claimDeductDetailModel.setClaimNo(claimDeductTmp.getRefClaimNo()+"/"+claimDeductTmp.getRefOccurrence());
						}
						else{
							if(claimDeductTmp.getClaimNo() != null && claimDeductTmp.getOccurrence() != null){
								claimDeductDetailModel.setClaimNo(claimDeductTmp.getClaimNo()+"/"+claimDeductTmp.getOccurrence());
							}
							else{
								claimDeductDetailModel.setClaimNo("");
							}
						}
					}
					if(claimDeductDetailList.get(i).getBenefitCode() != null && !claimDeductDetailList.get(i).getBenefitCode().isEmpty())
					{
						BenefitItem benefitItem = benefitItemRepository.findBenefitItemByBenefitItemCodeAndBusinessLine(claimDeductDetailList.get(i).getBenefitCode(), "OL");
						if(benefitItem != null)
						{
							claimDeductDetailModel.setBenefitCode(benefitItem.getBenefitItemCode()+"-"+benefitItem.getBenefitItemDesc());
						}
					}
					claimDeductDetailModel.setNoOfCallAllocated(claimDeductDetailList.get(i).getNoOfCallAllocated());
					claimDeductDetailModel.setNoOfDaysAllocated(claimDeductDetailList.get(i).getNoOfDaysAllocated());
					claimDeductDetailModel.setApprovedAmt(claimDeductDetailList.get(i).getApprovedAmt());
					claimDeductDetailModelList.add(claimDeductDetailModel);
				}
			}
			
			boolean canDeleteDeduct = false;
			if((claimDeduct.getSubmissionSource() != null && claimDeduct.getDeductStatus() != null)){
				if(claimDeduct.getSubmissionSource().equals("OT") && !claimDeduct.getDeductStatus().equals(ClaimStatus.CANCELLED.getValue())){
					canDeleteDeduct = true;
				}
			}
			
			boolean canCopyDeduct = false;
			if((claimDeduct.getSubmissionSource() != null && claimDeduct.getDeductStatus() != null)){
				if(claimDeduct.getSubmissionSource().equals("OT")){
					canCopyDeduct = true;
				}
			}
			
			claimDeductModel.setTotalDeductAmt(claimDeduct.getTotalDeductAmt());
			model.addAttribute("claimDeduct"      , claimDeductModel);
			model.addAttribute("claimDeductDetail", claimDeductDetailModelList);
			model.addAttribute("canDeleteDeduct"  , canDeleteDeduct);
			model.addAttribute("canCopyDeduct"    , canCopyDeduct);
		}
		return "caseDeductInquiry";
	}
	
	@RequestMapping(value = "/homeDoubleCiInquiry", method = RequestMethod.GET)
	public String openHomeDoubleCiInquiry(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (!SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMC_DoubleCI_INQ) && !SecurityUtil.getAvaliavleFunction(userInfoForm).contains(Function.CMIC_DEDUCT_INQ)) { // must remove 
			return "homeBlank";
		}
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);
		return "homeDoubleCiInquiry";
	}
	
	
	@RequestMapping(value = "/caseDoubleCiInquiry/{doubleCiInquiryId}", method = RequestMethod.GET)
	public String openCaseDoubleCiInquiry(@PathVariable Long doubleCiInquiryId, ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		LOG.debug(" openCaseDoubleCiInquiry ");
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		DoubleCiInquiry doubleCiInquiry = new DoubleCiInquiry();
		doubleCiInquiry.setDoubleCiInquiryId(doubleCiInquiryId);
		model.addAttribute("doubleCiInquiry"      , doubleCiInquiry);
		return "caseDoubleCiInquiry";
	}
	

	private HomeChartData prepareChart(UserInfoForm userInfoForm, List<Activity> activityList) {
		HomeChartData homeChartData = new HomeChartData();
		CountWorkParam param = new CountWorkParam();
		param.setUserId(userInfoForm.getUserId());
		param.setCategory(cmicEnvironmentHelper.getCase360Category());
		List<String> activityStrList = new ArrayList<>();
		for (Activity a : activityList) {
			activityStrList.add(a.toString());
		}
		param.setActivityList(activityStrList);

		ChartData chartData = new ChartData();
		chartData.setCategory("Completed");
		int doneAmt = 0;
		List<CountWorkTO> countWorkTO = workflowService.getCountWorkDone(param, userInfoForm);
		if (countWorkTO != null) {
			for (CountWorkTO cwTO : workflowService.getCountWorkDone(param, userInfoForm)) {
				doneAmt += cwTO.getNoOfCase();
			}
		}
		chartData.setValue(doneAmt);
		chartData.setColor("#97cb5d");
		homeChartData.getYouChartData().add(chartData);

		chartData = new ChartData();
		chartData.setCategory("Waiting");
		int waitingAmt = 0;
		countWorkTO = new ArrayList<CountWorkTO>();
		countWorkTO = workflowService.getCountWaitingWork(param, userInfoForm);
		if (countWorkTO != null) {
			for (CountWorkTO cwTO : countWorkTO) {
				waitingAmt += cwTO.getNoOfCase();
			}
		}
		chartData.setValue(waitingAmt);
		chartData.setColor("#ff95a9");
		homeChartData.getYouChartData().add(chartData);

		chartData = new ChartData();
		chartData.setCategory("Completed");
		chartData.setValue(300);
		homeChartData.getTeamChartData().add(chartData);
		chartData = new ChartData();
		chartData.setCategory("Work Away");
		chartData.setValue(99999);
		homeChartData.getTeamChartData().add(chartData);
		chartData = new ChartData();
		chartData.setCategory("Waiting");
		chartData.setValue(150);
		homeChartData.getTeamChartData().add(chartData);

		DecimalFormat myFormatter = new DecimalFormat("###,###,###");
		homeChartData.setYouFormatedData(myFormatter.format(homeChartData.getYouChartData().get(0).getValue()));
		homeChartData.setTeamFormatedData(myFormatter.format(homeChartData.getTeamChartData().get(1).getValue()));

		return homeChartData;
	}

	@RequestMapping(value = "/wasLog", method = RequestMethod.GET)
	public String openWasLog(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		if (userInfoForm != null) {
			try {
				List<String> filenames = new ArrayList<String>();
				File[] files = new File(cmicEnvironmentHelper.getWasLogPath()).listFiles();
				for (File file : files) {
					if (file.isFile() && !file.isDirectory() && !file.isHidden() && file.canRead()) {
						filenames.add(file.getName());
					}
				}
				Collections.sort(filenames);
				model.addAttribute("logFiles", filenames);
			} catch (Exception e) {
				model.addAttribute("errorMessage", e.getMessage());
				LOG.error(e.getMessage(), e);
			}
		}
		return "wasLog";
	}

	@RequestMapping(value = "/CMiCMonitor", method = RequestMethod.GET)
	public String openTest(ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		model.addAttribute("getSysDate", cMiCMonitorService.getSysDate());
		model.addAttribute("printUsage", cMiCMonitorService.printUsage());
		return "CMiCMonitor";
	}

	@RequestMapping(value = "/CMiCRequest", method = RequestMethod.GET)
	public String CMiCRequest(ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		model.addAttribute("requestInfo", AroundAdviceRequestTimeService.methodStats);
		return "CMiCRequest";
	}

	@RequestMapping(value = "/CMiCRequestReset", method = RequestMethod.GET)
	public String CMiCRequestReset(ModelMap model, HttpServletRequest httpServletRequest) throws Exception {
		AroundAdviceRequestTimeService.reset();
		model.addAttribute("requestInfo", AroundAdviceRequestTimeService.methodStats);
		return "CMiCRequest";
	}

}
