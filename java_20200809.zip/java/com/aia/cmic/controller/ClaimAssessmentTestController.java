package com.aia.cmic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.cmic.model.AssessClaim;
import com.aia.cmic.repository.ClaimRepository;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.services.ClaimService;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Controller
@RequestMapping("/claimAssessmentTest")
public class ClaimAssessmentTestController {

	@Autowired
	ClaimService claimService;

	@Autowired
	ClaimRepository claimRepository;

	@RequestMapping(value = "/assessClaim", method = RequestMethod.GET)
	@ResponseBody
	public String claimAssessmentTest(
			@RequestParam(defaultValue = "TH", required = false) String companyId,
			@RequestParam(required = false) String claimNo,
			@RequestParam(required = false) Integer occurrence) {
		UserInfoForm infoForm = new UserInfoForm();
		infoForm.setUserId("test");
		// retrievePartyList
		AssessClaim assessClaim;
		try {
			assessClaim = claimService.assessClaim(companyId, claimNo, occurrence, infoForm);
			//Create output
			ObjectMapper mapper = new ObjectMapper();

			ObjectNode response = mapper.createObjectNode();
			response.put("Decision", assessClaim.getDecision());
			response.put("RiskLevel", assessClaim.getRiskLevel());
			response.put("Message", "OK");
			//To make the JSON String pretty
			return objectToJsonString(response);

		} catch (Exception e) {
			e.printStackTrace();
			return ("ERROR: " + e.getMessage());
		}
	}

	public static String objectToJsonString(Object inputObject) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		if (inputObject == null) {
			throw new Exception("Null when conver objectToString");
		}
		return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(inputObject);
	}
}
