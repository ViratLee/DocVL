package com.aia.cmic.controller;

import static com.aia.cmic.util.CMiCUtil.transformToLookupList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.Provider;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.CMiCClaim;
import com.aia.cmic.model.Claim;
import com.aia.cmic.model.DataEntryPageSecurity;
import com.aia.cmic.model.ImageDocument;
import com.aia.cmic.model.IndexingDocumentForm;
import com.aia.cmic.model.IndexingForm;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.model.PartySearchForm;
import com.aia.cmic.model.RequestDocumentForm;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.restservices.model.Document;
import com.aia.cmic.restservices.model.WorkQueueMonitorParam;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.SecurityUtil;
import com.aia.cmic.workflow.Activity;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
@RequestMapping("/workflow")
public class WorkflowController {
	private static final Logger LOG = LoggerFactory.getLogger(WorkflowController.class);
	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private ClaimService claimService;

	private CommonDataService commonDataService;
	private CachingMasterDataHelper cachingHelper;

	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;

	public CMiCEnvironmentHelper getCmicEnvironmentHelper() {
		return cmicEnvironmentHelper;
	}

	public void setCmicEnvironmentHelper(CMiCEnvironmentHelper cmicEnvironmentHelper) {
		this.cmicEnvironmentHelper = cmicEnvironmentHelper;
	}

	@Autowired
	public void setCommonDataService(CommonDataService commonDataService) {
		this.commonDataService = commonDataService;
		cachingHelper = commonDataService.getCachingMasterDataHelper();
	}

	@RequestMapping(value = "/outstandingWork", method = RequestMethod.GET)
	public String openOutstandingWork(ModelMap model) {
		List<Lookup> lstActivities = new ArrayList<Lookup>();

		Lookup empty = new Lookup();
		empty.setKey("");
		empty.setValue("");

		lstActivities.add(empty);

		for (Activity a : Activity.values()) {
			if (a.toString() != null) {
				Lookup lookup = new Lookup();
				lookup.setKey(a.toString());
				lookup.setValue(a.toString());
				lstActivities.add(lookup);
			}
		}
		model.addAttribute("lstActivities", lstActivities);
		return "workflow/outstandingWork";
	}

	@RequestMapping(value = "/indexing/{caseId}", method = RequestMethod.GET)
	public String openIndexingPage(@PathVariable Long caseId, ModelMap model, HttpServletRequest httpServletRequest) throws JsonProcessingException, IOException {
		LOG.debug("### openCase ### : {} ", caseId);
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, SecurityUtil.retriveUserInfoForm(httpServletRequest));
		boolean isOwner = false;
		if (cmicClaim.getLockType() == 1 && cmicClaim.getIndexingUser().equals(userInfoForm.getUserId())) {
			isOwner = true;
		}
		//CMiCClaim cmicClaim = new CMiCClaim();
		IndexingForm indexingForm = new IndexingForm(cmicClaim);
		Provider provider = providerService.getExistingProvider(indexingForm.getProviderCode());
		if (provider != null) {
			indexingForm.setHccode(FormatUtil.convertNull(provider.getProviderNameThai()));
		}
		indexingForm.setProcessingDt(commonDataService.getProcessingDate());
		LOG.debug("IndexingForm : {}", indexingForm.toString());
		ImageDocument imageDocument = new ImageDocument();
		PartySearchForm partySearchForm = new PartySearchForm();
		RequestDocumentForm requestForDocumentForm = new RequestDocumentForm();
		Lookup lookup = new Lookup();
		lookup.setKey("1234");
		lookup.setValue(null);
		List<Document> documents = cmicClaim.getLstDocument();// workflowService.getDocumentList(caseId, userInfoForm);
		List<IndexingDocumentForm> indexingDocuments = new ArrayList<>();
		IndexingDocumentForm indexingDocument;
		for (Document document : documents) {
			// If doctype code is fax = request doc from hospital.
			// So, do not show at document list grid.
			if (!"Fax".equalsIgnoreCase(document.getDocTypeCode())) {
				indexingDocument = new IndexingDocumentForm(document);
				indexingDocuments.add(indexingDocument);
				/*	CMIC-494
				if ("FAX".equalsIgnoreCase(indexingForm.getChannel())) {
					if (!"C10300".equals(document.getDocTypeCode())) {
						lookup = new Lookup();
						lookup.setKey("C10300");
						lookup.setValue("HC Claim Form C10300");
						indexingDocument = new IndexingDocumentForm(lookup);
						indexingDocuments.add(indexingDocument);
					}
				
					if (!"C90700".equals(document.getDocTypeCode())) {
						lookup = new Lookup();
						lookup.setKey("C90700");
						lookup.setValue("\u0E43\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E04\u0E48\u0E32\u0E23\u0E31\u0E01\u0E29\u0E32");
						indexingDocument = new IndexingDocumentForm(lookup);
						indexingDocuments.add(indexingDocument);
					}
				
					if (!"C30900".equals(document.getDocTypeCode())) {
						lookup = new Lookup();
						lookup.setKey("C30900");
						lookup.setValue("\u0E1A\u0E31\u0E15\u0E23\u0E1B\u0E23\u0E30\u0E0A\u0E32\u0E0A\u0E19/\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E1A\u0E49\u0E32\u0E19 C30900");
						indexingDocument = new IndexingDocumentForm(lookup);
						indexingDocuments.add(indexingDocument);
					}
				
					if (!"C32200".equals(document.getDocTypeCode())) {
						lookup = new Lookup();
						lookup.setKey("C32200");
						lookup.setValue("\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19 \u0E46 C32200");
						indexingDocument = new IndexingDocumentForm(lookup);
						indexingDocuments.add(indexingDocument);
					}
				}
				*/
			}
		}

		LOG.debug("### cmicClaim ### : {} ", cmicClaim.toString());
		//LOG.debug("### Claim ### : {} ", cmicClaim.getClaimCanonical().getClaim().toString());
		model.addAttribute("caseId", caseId);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("userInfoForm", userInfoForm);
		model.addAttribute("imageDocument", imageDocument);
		model.addAttribute("isOwner", isOwner);
		model.addAttribute("lookup", lookup);
		model.addAttribute("indexingForm", indexingForm);
		model.addAttribute("partySearchForm", partySearchForm);
		model.addAttribute("document", indexingDocuments);
		model.addAttribute("requestForDocumentForm", requestForDocumentForm);
		model.addAttribute("batchNo", indexingForm.getBatchNo());
		model.addAttribute("lstDocumentType", transformToLookupList(workflowService.getAllDocumentType(userInfoForm)));

		return "indexing";
	}

	@RequestMapping(value = "/caseValidation", method = RequestMethod.GET)
	public String openCaseValidation(ModelMap model, HttpServletRequest httpServletRequest) {
		CMiCClaim cmicClaim = new CMiCClaim();
		ClaimCanonical claimCanonical = new ClaimCanonical();
		Claim claim = new Claim();
		claim.setChannel("03");
		claimCanonical.setClaim(claim);
		cmicClaim.setClaimCanonical(claimCanonical);
		List<Lookup> lstLocation = workflowService.getAllLocation(SecurityUtil.retriveUserInfoForm(httpServletRequest));
		Collections.sort(lstLocation, new Comparator<Lookup>() {
			@Override
			public int compare(Lookup o1, Lookup o2) {
				return o1.getKey().compareTo(o2.getKey());
			}
		});
		model.addAttribute("lstLocation", lstLocation);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("channelDesc", CMiCUtil.getCommonCodeDesc(cachingHelper.findChannel(claim.getChannel())));
		model.addAttribute("processingDt", commonDataService.getProcessingDate());
		model.addAttribute("copy", Boolean.FALSE);
		DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
		model.addAttribute("pageSecurity", pageSecurity);
		return initCaseValidation(model);
	}

	@RequestMapping(value = "/caseValidation/{caseId}", method = RequestMethod.GET)
	public String openCaseValidationWithCaseId(
			@PathVariable Long caseId,
			ModelMap model,
			HttpServletRequest httpServletRequest,
			@RequestParam(name = "src", required = false) String src,
			@RequestParam(name = "copyType", required = false) String copyType) throws JsonProcessingException, IOException {
		final String SRC_CLAIM_INQUIRY = "claimInquiry";

		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		CMiCClaim cmicClaim = workflowService.getClaimByIndex(caseId, userInfoForm);
		Long claimId = cmicClaim.getClaimCanonical().getClaim().getClaimId();
		if (claimId != null) {
			cmicClaim.setClaimCanonical(claimService.retrieveClaimDetail(cmicEnvironmentHelper.getCmicCompanyId(), claimId));
		}
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		Collections.sort(lstLocation, new Comparator<Lookup>() {
			@Override
			public int compare(Lookup o1, Lookup o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		});
		String gender = cmicClaim.getClaimCanonical().getClaim().getGender();
		if ("1".equals(gender) || "M".equals(gender)) {
			gender = "Male";
		} else if ("2".equals(gender) || "F".equals(gender)) {
			gender = "Female";
		}
		model.addAttribute("gender", gender);
		model.addAttribute("lstLocation", lstLocation);
		model.addAttribute("cmicClaim", cmicClaim);
		model.addAttribute("channelDesc", CMiCUtil.getCommonCodeDesc(cachingHelper.findChannel(cmicClaim.getClaimCanonical().getClaim().getChannel())));
		model.addAttribute("processingDt", commonDataService.getProcessingDate());
		model.addAttribute("copy", SRC_CLAIM_INQUIRY.equals(src) ? Boolean.TRUE : Boolean.FALSE);
		model.addAttribute("copyType", copyType);
		DataEntryPageSecurity pageSecurity = new DataEntryPageSecurity();
		pageSecurity.setUnloadAvaliable(SRC_CLAIM_INQUIRY.equals(src) ? Boolean.FALSE : Boolean.TRUE);
		model.addAttribute("pageSecurity", pageSecurity);
		return initCaseValidation(model);
	}

	@RequestMapping(value = "/workQueueMonitor", method = RequestMethod.GET)
	public String openWorkQueueMonitor(ModelMap model, HttpServletRequest httpServletRequest) {
		WorkQueueMonitorParam form = new WorkQueueMonitorParam();
		List<Lookup> lstActivities = new ArrayList<Lookup>();

		Lookup empty = new Lookup();
		empty.setKey("");
		empty.setValue("");

		lstActivities.add(empty);

		for (Activity a : Activity.values()) {
			if (a.toString() != null) {
				Lookup lookup = new Lookup();
				lookup.setKey(a.toString());
				lookup.setValue(a.toString());
				lstActivities.add(lookup);
			}
		}
		model.addAttribute("lstActivities", lstActivities);
		model.addAttribute("searchForm", form);
		//model.addAttribute("lstUrgentCase", transformToLookupList(workflowService.getUrgentCase360(userInfoForm)));
		return "workflow/workQueueMonitor";
	}

	private String initCaseValidation(ModelMap model) {

		List<MasterLookup> lstCliamPhase = cachingHelper.getPhase();
		List<MasterLookup> lstSubmissionChannel = cachingHelper.getChannel();
		List<MasterLookup> lstSubmissionType = cachingHelper.getSubmissionType();

		model.addAttribute("lstCliamPhase", lstCliamPhase);
		model.addAttribute("lstSubmissionType", lstSubmissionType);
		model.addAttribute("lstSubmissionChannel", lstSubmissionChannel);
		return "workflow/caseValidation";
	}

	@RequestMapping(value = "/myTeamWork", method = RequestMethod.GET)
	public String openMyTeamWork(ModelMap model) {
		List<MasterLookup> lstSubmissionChannel = cachingHelper.getChannel();
		List<Lookup> lstActivities = new ArrayList<Lookup>();
		List<Lookup> lstRisks = new ArrayList<Lookup>();

		Lookup empty = new Lookup();
		empty.setKey("");
		empty.setValue("");

		for (Activity a : Activity.values()) {
			if (a.toString() != null && a.getFunction() != null) {
				Lookup lookup = new Lookup();
				lookup.setKey(a.toString());
				lookup.setValue(a.toString());
				lstActivities.add(lookup);
			}
		}

		lstRisks.add(empty);

		for (int i = 0; i <= 3; i++) {
			Lookup lookup = new Lookup();
			lookup.setKey("" + i + "");
			lookup.setValue("" + i + "");
			lstRisks.add(lookup);
		}

		model.addAttribute("lstSubmissionChannel", lstSubmissionChannel);
		model.addAttribute("lstActivities", lstActivities);
		model.addAttribute("lstRisks", lstRisks);
		return "workflow/myTeamWork";
	}

	@RequestMapping(value = "/returnOriginalReceipt", method = RequestMethod.GET)
	public String openReturnOriginalReceipt(ModelMap model, HttpServletRequest httpServletRequest) {

		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		List<Lookup> lstLocation = workflowService.getAllLocation(userInfoForm);
		List<Lookup> newlstLocation = new ArrayList<>();
		String val = "";
		for (Lookup lookup : lstLocation) {
			if (!val.equals(lookup.getValue())) {
				lookup.setKey(lookup.getValue());
				newlstLocation.add(lookup);
				val = lookup.getValue();
			}
		}
		model.addAttribute("lstLocation", newlstLocation);

		List<Lookup> lstReturnStatus = workflowService.getReturnStatus(userInfoForm);

		List<Lookup> lstInsureType = workflowService.getInsureType(userInfoForm);

		model.addAttribute("lsReturnStatus", lstReturnStatus);
		model.addAttribute("lstInsureType", lstInsureType);
		return "workflow/returnOriginalReceipt";
	}

	@RequestMapping(value = "/documentSearch", method = RequestMethod.GET)
	public String openDocumentSearch(ModelMap model) {
		return "workflow/documentSearch";
	}

	@RequestMapping(value = "/case360Report", method = RequestMethod.GET)
	public String openCase360Report(ModelMap model, HttpServletRequest httpServletRequest) {
		UserInfoForm userInfoForm = SecurityUtil.retriveUserInfoForm(httpServletRequest);
		List<Lookup> reportTypeList = workflowService.getAllReportType(userInfoForm);
		model.addAttribute("reportTypeList", reportTypeList);
		return "workflow/case360Report";
	}

}
