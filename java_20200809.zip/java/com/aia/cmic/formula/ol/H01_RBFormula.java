package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.entity.ServiceItem;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.repository.ServiceItemRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@BenifitCodeFormula("H01")
public class H01_RBFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H01_RBFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Autowired
	ServiceItemRepository serviceItemRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}

		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

	

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "NoOfUnit", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();

		//Integer totalCurrentAllocatedDays = previousClaimAllocation.getDaysAllocated();
		Integer totalCurrentAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		Integer dayAdjustment = 0;
		Integer currentH00AllocatedDays = 0;
		Boolean hasICU = Boolean.FALSE;
		PreviousClaimPaymentAllocation h00AllocatedDays = null;
		if (!StringUtils.isEmpty(working.getRollOverGroupNo())) {
			// Note: RollOverGroupNo concept was originally based on early version of StandardBilling where benefit code has rollover benefit codes. eg. H00/H01 
			PaymentAllocationTemp h00 = previousCurrentAllocationHelper.getH00Allocation(working.getPlanId(), working.getPolicyNo(), working);
			//PaymentAllocationTemp h00 = working.getRollOverHead() ;
			if (h00 != null) {
				//h00AllocatedDays = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H00.toString(), working.getPlanId(),
				//	working.getPlanCoverageNo(), working.getPolicyNo(), working);
				h00AllocatedDays = h00.getPreviousAllocation();

				totalCurrentAllocatedDays += h00AllocatedDays.getDaysAllocated();

				if (working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("is RollOver From H00 = true");
				}
				if (h00.getPresentedNosOfDays() != null && h00.getAllocatedDay() != null) {
					dayAdjustment = Math.max(h00.getPresentedNosOfDays() - h00.getAllocatedDay(), 0);
					// add h00 allocated days
					currentH00AllocatedDays = h00.getAllocatedDay();
					totalCurrentAllocatedDays += currentH00AllocatedDays;
					if (working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("RollOver From H00 has excess Days of {} to be added to DayOfAdmit", dayAdjustment);
					}
				}
			} else {
				if (claimCanonical.getClaim().getDayOfAdmitIcu() != null) {
					dayAdjustment += claimCanonical.getClaim().getDayOfAdmitIcu();
				}
				if (working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("Has an ICU/H00 case. DayOfAdmitICU={} will be added to DayOfAdmit={}", claimCanonical.getClaim().getDayOfAdmitIcu(),
							claimCanonical.getClaim().getDayOfAdmitRoom());
				}
				// Get Previous H00 allocation
				h00AllocatedDays = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H00.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),working);
				totalCurrentAllocatedDays += h00AllocatedDays.getDaysAllocated();
			}
		} else {

			List<ServiceItem> serviceItems = serviceItemRepository.findServiceItemByServiceCatId(working.getServiceCatId());
			Boolean needToAddICU = false ;
			if (!CollectionUtils.isEmpty(serviceItems)) {
				ServiceItem serviceItem = serviceItems.get(0);
				needToAddICU = serviceItem != null && !StringUtils.isEmpty(serviceItem.getServiceItemDesc())
						&& (serviceItem.getServiceItemDesc().indexOf("ICU") != -1 || serviceItem.getServiceItemDesc().indexOf("CCU") != -1);
				if (needToAddICU) {
					// Check if ICU/H00 exists 
					// refactored: no need to check H00 since redundant with needToAddICU 
					//					hasICU = previousCurrentAllocationHelper.isCurrentAllocationHasICU(BenefitCode.H00.toString(),working) ;
					//					if(hasICU) {
					// check if this policy has an H00 allocation.
					//						PaymentAllocationTemp h00 = previousCurrentAllocationHelper.getH00Allocation(working.getPlanId(),working.getPolicyNo(),working);
					//						if(h00 != null && h00.getPresentedNosOfDays() != null && h00.getAllocatedDay() != null) {
					//		                	dayAdjustment = Math.max(h00.getPresentedNosOfDays() - h00.getAllocatedDay(), 0) ;
					//		                	currentH00AllocatedDays = h00.getAllocatedDay();
					//							totalCurrentAllocatedDays += currentH00AllocatedDays;
					//		                	if(working.getCalculationLogger().isDebugEnabled()) {
					//								working.getCalculationLogger().debug("Has an ICU/H00 case. excess ICU days={} will be added to DayOfAdmit={}",dayAdjustment,claimCanonical.getClaim().getDayOfAdmitRoom());
					//							}
					//						} else {
					if (claimCanonical.getClaim().getDayOfAdmitIcu() != null) {
						dayAdjustment = claimCanonical.getClaim().getDayOfAdmitIcu();
					}
					if (working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("Has an ICU/H00 case. DayOfAdmitICU={} will be added to DayOfAdmit={}", claimCanonical.getClaim().getDayOfAdmitIcu(),
								claimCanonical.getClaim().getDayOfAdmitRoom());
					}
					//						}
					//					}	
				}
			}
			// Check Previous Claim if H00 is allocated.
			h00AllocatedDays = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H00.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),working);
			totalCurrentAllocatedDays += h00AllocatedDays.getDaysAllocated();
			if (working.getCalculationLogger().isDebugEnabled() && h00AllocatedDays.getDaysAllocated() > 0) {
				working.getCalculationLogger().debug("Has H00 allocated Days from Previous Claim. H00 Previous Days={} will be added to used Days.", h00AllocatedDays.getDaysAllocated());
			}

			Boolean icuAlreadyAdded = false ;
			PaymentAllocationTemp currentH00Claim = previousCurrentAllocationHelper.getH00Allocation(working.getPlanId(), working.getPolicyNo(), working);
			if (currentH00Claim != null && currentH00Claim.getAllocatedDay() != null) {
				    icuAlreadyAdded = true;
					currentH00AllocatedDays = currentH00Claim.getAllocatedDay();
					
					if(currentH00Claim.getPresentedNosOfDays() - currentH00AllocatedDays > 0) {
						// has an excess icu days
						dayAdjustment = currentH00Claim.getPresentedNosOfDays() - currentH00AllocatedDays ;
						if (working.getCalculationLogger().isDebugEnabled()) {
							working.getCalculationLogger().debug("Adding ICU Excess Days={} from Current H00. PresentedDay={},AllocatedDay={}", currentH00Claim.getPresentedNosOfDays() - currentH00AllocatedDays,currentH00Claim.getPresentedNosOfDays() , currentH00AllocatedDays );
						}	
					}
					
					totalCurrentAllocatedDays += currentH00AllocatedDays;
					if (working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("Adding Current H00 day allocation={} to H01 Used Day.", currentH00Claim.getAllocatedDay());
					}
			}
			if(!icuAlreadyAdded && !needToAddICU) {
				// Current service is not ICU and no current H00 allocation for this policy. Check if there is an existing ICU service
				if(previousCurrentAllocationHelper.hasICU(working, serviceItemRepository) ) {
					if (claimCanonical.getClaim().getDayOfAdmitIcu() != null) {
						dayAdjustment = claimCanonical.getClaim().getDayOfAdmitIcu();
					}
					if (working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("Current service is not ICU and no current H00 allocation, but ICU service exists.  DayOfAdmitICU={} will be added to DayOfAdmit={}", claimCanonical.getClaim().getDayOfAdmitIcu(),
								claimCanonical.getClaim().getDayOfAdmitRoom());
					}
				
				}
			}
		}
		
		if(previousCurrentAllocationHelper.getExcessICUAmt().compareTo(BigDecimal.ZERO) > 0) {			
			// Oct 3 changes, only use excess amount if H00 has an excess days -wanyupa
			if(dayAdjustment > 0) {
				if (working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("PresentedAmt={} will be added with Exccess Amt of {} from ICU Services {}", working.getPresentedAmt() , previousCurrentAllocationHelper.getExcessICUAmt(),previousCurrentAllocationHelper.getIcuServicesWithExcessAmtBuilder().toString());
				}
				working.setPresentedAmt(working.getPresentedAmt().add(previousCurrentAllocationHelper.getExcessICUAmt()));
				previousCurrentAllocationHelper.setExcessICUAmt(BigDecimal.ZERO);
				if( previousCurrentAllocationHelper.getClaimBenefitItemMap().containsKey(working.getCurrentClaimBenefitItemKey()) ) {
					com.aia.cmic.model.ClaimBenefitItem claimBenefitITem = previousCurrentAllocationHelper.getClaimBenefitItemMap().get(working.getCurrentClaimBenefitItemKey()) ;
					claimBenefitITem.setPresentedAmt(working.getPresentedAmt());
				}
				
				if (working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("New Value OF PresentedAmt={} after added excess Amt from ICU Services.", working.getPresentedAmt() );
				}
			} else {
				// reset excess amt
				previousCurrentAllocationHelper.setExcessICUAmt(BigDecimal.ZERO);
			}
		}
				
		// amount allocated
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		if (working.getProductCode().startsWith(ProductCode.HSPG.toString())) {
			valuePerUnit = new BigDecimal(2);
		}

		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit);

		Boolean isHNW = org.apache.commons.lang.StringUtils.equals(ProductCode.HNW.toString(),
				working.getProductCode());
	
		
		
		Boolean isHSJ = ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode());
		BigDecimal planSubPlanCode = BigDecimal.ZERO;

		if (isHSJ || isHNW) {
			// roomAmt for HS Juvenile
			// Room amount should be get from Plan. SubPlanCode - wanyupa
			Plan plan = planRepository.findPlanByPrimaryKey(working.getPlanId());
			amountAllocated = BigDecimal.ZERO;
			if (plan.getSubPlanCode() != null) {
				amountAllocated = new BigDecimal(plan.getSubPlanCode());
			}
			planSubPlanCode = amountAllocated;
		}
		
		if (isHSJ) {
			maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, claimPolicyPlan.getRateAge(),
					claimPolicyPlan.getPlanIssueDt(), working);
		}

		/**
		 * Commented : 2017/02/23(onsite) Restore old logic PlanBenefit.ChangeDate >  Hospitalization.Date - Wanyupa
		 */
		if (planBenefit.getChangeDate() != null && claimCanonical.getClaim().getHospitalizationDate() != null) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Integer planBenefitChangeDate = Integer.parseInt(sdf.format(planBenefit.getChangeDate()));
				Integer hospitalizationDate = Integer.parseInt(sdf.format(claimCanonical.getClaim().getHospitalizationDate()));

				if (planBenefitChangeDate > hospitalizationDate) {
					maxDaysAllocated = planBenefit.getMaxNoOfDaysHist();
					if (logger.isDebugEnabled()) {
						logger.debug("Found PlanBenefit.ChangeDate={} > Claim.HospitalizationDate={}, Setting MaxNoOfDay={} from PlanBenefit.MaxNoOfDaysHist", planBenefitChangeDate,
								hospitalizationDate, maxDaysAllocated);
					}
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().info("-----");
						working.getCalculationLogger().info("Found PlanBenefit.ChangeDate={} > Claim.HospitalizationDate={}, Setting MaxNoOfDay={} from PlanBenefit.MaxNoOfDaysHist",
								planBenefitChangeDate, hospitalizationDate, maxDaysAllocated);
						working.getCalculationLogger().info("-----");
					}
				}
			} catch (NumberFormatException e) {
				if (logger.isDebugEnabled()) {
					logger.warn("Skipping PlanBenefit.ChangeDate > Claim.HospitalizationDate due to: " + e.getMessage());
				}
			}
		}

		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays() + dayAdjustment;
		
		// no need to compute if the presented day == 0;
		if (working.getPresentedNosOfDays() == null || ( working.getPresentedNosOfDays()  + dayAdjustment) == 0) {
			working.setAllocatedDay(0);
			working.setEligibleAmt(BigDecimal.ZERO);
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("NoOfDaysPresented is ZERO or null, skipping calculation for this benefitCode.");
			}
			return;
		}
		
		if(isHNW && planBenefit.getMaxSumDay() != null) {
			maxDaysAllocated = planBenefit.getMaxSumDay() ;
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Maximum confinementday will now be  PlanBenfeit.MAXSumDay = {}. ", planBenefit.getMaxSumDay() ) ;
			}
		}
		
		if ((working.getPresentedNosOfDays() + totalCurrentAllocatedDays + dayAdjustment) > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - totalCurrentAllocatedDays ;
		}
		
		daysAllocated = Math.max(daysAllocated, 0);
//		if (daysAllocated == 0) {
//			// check if there is remaining days
//			daysAllocated = Math.max(0, maxDaysAllocated - (totalCurrentAllocatedDays));
//		}
		
		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated.multiply(new BigDecimal(daysAllocated));
		Boolean isHSJAndNotSurgery = isHSJ && StringUtils.isEmpty(working.getIcd9category().getIcd9Code()) ; 
		if(isHSJAndNotSurgery) {
			// HSJ
			eligbleAmt = working.getPresentedAmt();
		}


		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={},productCode={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(),
					working.getProductCode());
			working.getCalculationLogger().debug("PresentedAmt={}", working.getPresentedAmt());
			working.getCalculationLogger().debug(
					"Calculation Parameters: ProductCode={},NoOfUnit={},ValuePerUnit={},MaxNoOfDay={},NoOfDaysPresented={},PresentedAmt={},DaysAllocated={},H00_UsedDays={},H01_UsedDays={}",
					working.getProductCode(), nosOfUnit, valuePerUnit, maxDaysAllocated, working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated,
					h00AllocatedDays != null ? h00AllocatedDays.getDaysAllocated() + currentH00AllocatedDays : currentH00AllocatedDays, working.getPreviousAllocation().getDaysAllocated());
		}

		Boolean isHSOld = ProductCode.HSOLD.toString().equalsIgnoreCase(working.getProductCode());
		// HS OLD
		if (isHSOld) {
			BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();

			PreviousClaimPaymentAllocation h03PreviousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(
					BenefitCode.H03.toString(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
			PreviousClaimPaymentAllocation h03OldClaimAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H03.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			h03PreviousClaimAllocation.setAmountAllocated(h03PreviousClaimAllocation.getAmountAllocated().add(h03OldClaimAllocation.getAmountAllocated()));

			PreviousClaimPaymentAllocation h05PreviousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(
					BenefitCode.H05.toString(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
			PreviousClaimPaymentAllocation h05OldClaimAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H05.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			h05PreviousClaimAllocation.setAmountAllocated(h05PreviousClaimAllocation.getAmountAllocated().add(h05OldClaimAllocation.getAmountAllocated()));

			BigDecimal totalH03H05PrevAmtReimbursed = h03PreviousClaimAllocation.getAmountAllocated().add(h05PreviousClaimAllocation.getAmountAllocated());
			BigDecimal totalH01UsedAmt = previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated());

			BigDecimal newMaxBenefit = BigDecimal.ZERO;

			if (totalH03H05PrevAmtReimbursed.add(totalH01UsedAmt).compareTo(maxBenefitAmt) < 0) {
				newMaxBenefit = maxBenefitAmt.subtract(totalH03H05PrevAmtReimbursed.add(totalH01UsedAmt));
			}

			if (eligbleAmt.compareTo(newMaxBenefit) > 0) {
				eligbleAmt = newMaxBenefit;
			}
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("HS-OLD Additional Parameters: ProductCode={},MaxBenefitAmt={},H01_UsedAmt={},H03_UsedAmt={},H05_UsedAmt={},EligbleAmt={}",
						working.getProductCode(), maxBenefitAmt, totalH01UsedAmt, h03PreviousClaimAllocation.getAmountAllocated(), h05PreviousClaimAllocation.getAmountAllocated(), eligbleAmt);
			}

			// last adjustment
			if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
			}
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Formula: MaxAmtLimit = Min(PresentedAmt({}) , ( MaxBenefitAmt({}) - (H03_UsedAmt({}) +  H05_UsedAmt({}) + H01_UsedAmt({}))) ) ={}", eligbleAmt,
						working.getPresentedAmt(), maxBenefitAmt, h03PreviousClaimAllocation.getAmountAllocated(), h05PreviousClaimAllocation.getAmountAllocated(), totalH01UsedAmt,
						totalH03H05PrevAmtReimbursed.add(totalH01UsedAmt), newMaxBenefit);
				working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
			}

			// set elegibleAmt and
			working.setEligibleAmt(eligbleAmt);
			working.setAllocatedDay(daysAllocated);

			return;
		}

		if (eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {
			
			BigDecimal maxAmtLimit = eligbleAmt.multiply(BigDecimal.ONE);
			if(isHSJAndNotSurgery) {
				maxAmtLimit = maxConfinementAmt ;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("HSJ and SurgeryInd <> 'Y', limit will be maxConfinementAmt={}", maxConfinementAmt);
				}
			}
			// check with previous amount
			eligbleAmt = maxAmtLimit.subtract(previousClaimAllocation.getAmountAllocated());
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				// accumulated amount reached maxLimit
				eligbleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}

			// last adjustment
			if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
			}
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}

			if (working.isCalculationLoggerEnabled() && !isHSOld) {
				if(isHSJAndNotSurgery) {
					working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min(PresentedAmt({}) , MaxConfinementAmt({})-UsedAmt({}) = {})", working.getPresentedAmt(), maxConfinementAmt,previousClaimAllocation.getAmountAllocated(),maxAmtLimit);					
				} else if (isHSJ) {
					working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min(PresentedAmt({}) , Plan.SubPlanCode({}) x DaysAllocated({}) = {})", working.getPresentedAmt(), planSubPlanCode,
							daysAllocated, maxAmtLimit);
					working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
				} else {
					if (!StringUtils.isEmpty(working.getRollOverGroupNo())) {
						// rollover from H00
						working.getCalculationLogger().debug("Excess ICU/H00 Days={} to be added", dayAdjustment);
						working.getCalculationLogger().debug(
								"Formula: MaxAmtLimit =  Min(MaxNOfDay({}) - (H00_Used Days({}) + H01_UsedDays({}) ),DaysAllocated({})) x NoOfUnit({}) x ValuePerUnit({}) ={}", maxDaysAllocated,
								h00AllocatedDays != null ? h00AllocatedDays.getDaysAllocated() + currentH00AllocatedDays : currentH00AllocatedDays, working.getPreviousAllocation().getDaysAllocated(),
								daysAllocated, nosOfUnit, valuePerUnit, maxAmtLimit);
						working.getCalculationLogger().debug("PreviousUsedAmt={}", previousClaimAllocation.getAmountAllocated());
						working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
					} else if (hasICU) {
						working.getCalculationLogger().debug("DaysAllocated({})= Claim.DayOfAdmitRoom({}) + Claim.DayOfAdmitICU({})", daysAllocated, working.getPresentedNosOfDays(),
								claimCanonical.getClaim().getDayOfAdmitIcu());
						working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min( MaxNoOfDay({}) - H01_Used_Days({}) , DaysAllocated({})) x NoOfUnit({}) x ValuePerUnit({}) ={}",
								maxDaysAllocated, working.getPreviousAllocation().getDaysAllocated(), daysAllocated, nosOfUnit, valuePerUnit, maxAmtLimit);
						working.getCalculationLogger().debug("PreviousUsedAmt={}", previousClaimAllocation.getAmountAllocated());
						working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);

					} else {
						working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min( MaxNoOfDay({}) - H01_Used_Days({}) , DaysAllocated({})) x NoOfUnit({}) x ValuePerUnit({}) ={}",
								maxDaysAllocated, working.getPreviousAllocation().getDaysAllocated(), daysAllocated, nosOfUnit, valuePerUnit, maxAmtLimit);
						working.getCalculationLogger().debug("PreviousUsedAmt={}", previousClaimAllocation.getAmountAllocated());
						working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
					}
				}
			}
			
			working.setAllocatedDay(daysAllocated);

			if (working.getProductSpecificConfinementAdjuster() != null) {
				// further  adjustment by maxconfinement
				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
				}
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
				}
				if (maxConfinementAmt != null || ClaimCalculationEnum.ProductCode.HNW.name().equalsIgnoreCase(working.getProductCode())) {
					eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
					
					if (logger.isDebugEnabled()) {
						logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedAmt={},presentedDays={}", working.getBenefitCode(), eligbleAmt, working.getEligibleAmt(),
								working.getPresentedAmt(), working.getPresentedNosOfDays());
					}
					working.setEligibleAmt(eligbleAmt);
					return ;
					
				}
			}

		} else {
			// reset days allocated
			daysAllocated = 0;

			if (working.isCalculationLoggerEnabled()) {
				if (!StringUtils.isEmpty(working.getRollOverGroupNo())) {
					// rollover from H00
					working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min(MaxNOfDay={} - (H00_Used Days={} + H01_UsedDays={} ),NoOfDaysPresented={}) x NoOfUnit={} x ValuePerUnit={} = {}",
							maxDaysAllocated, h00AllocatedDays != null ? h00AllocatedDays.getDaysAllocated() + currentH00AllocatedDays : currentH00AllocatedDays,
							working.getPreviousAllocation().getDaysAllocated(), working.getPresentedNosOfDays(), nosOfUnit, valuePerUnit, 0);
					working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
				} else {
					working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min( MaxNoOfDay={} - H00_Used_Days={} , NoOfDaysPresented={}) x NoOfUnit={} x ValuePerUnit={} ={}", maxDaysAllocated,
							h00AllocatedDays != null ? h00AllocatedDays.getDaysAllocated() : 0, working.getPresentedNosOfDays(), nosOfUnit, valuePerUnit, 0);
					working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedAmt={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated,
					working.getPresentedAmt(), working.getPresentedNosOfDays());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);

		// commented for now
		/*
		//TransactionLogging
		if(maxDaysAllocated - ( daysAllocated  + totalCurrentAllocatedDays ) <= 1) {
			TransactionLogInfo logInfo = new TransactionLogInfo() ;
			logInfo.setResponseCode(ResponseCode.C005);
			// warn
			// ""Policy %s / Plan %s / Product Code %s / BenefitCode %s - Limit: %d days, Previous paid : %d days, Previous paid Amt: %s, Presented: %d days, Presented Amt: %s, Eligible: %d days"
			logInfo.setParameters(
			Arrays.asList(ResponseSubCode.A, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxDaysAllocated, working.getPreviousAllocation().getDaysAllocated(),previousClaimAllocation.getAmountAllocated(), 
					working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated ).toArray() ) ;
		} 
		// info
		// ""Policy %s / Plan %s / Product Code %s / BenefitCode %s - Limit: %d days, Previous paid : %d days, Previous paid Amt: %s, Presented: %d days, Presented Amt: %s, Eligible: %d days"
		TransactionLogInfo logInfo = new TransactionLogInfo() ;
		logInfo.setResponseCode(ResponseCode.C003);
		logInfo.setParameters(
		Arrays.asList(ResponseSubCode.H, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxDaysAllocated, working.getPreviousAllocation().getDaysAllocated(),previousClaimAllocation.getAmountAllocated(), 
				working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated ).toArray() ) ;
		*/
	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
