package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.model.PreviousHBPHospitalization;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPaymentRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.services.response.AllocateBenefitPaymentResponse;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.HBPType;
import com.aia.cmic.util.ClaimCalculationEnum.IPDTreatmentType;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;
import com.aia.cmic.util.ClaimCalculationEnum.SubmissionType;

@BenifitCodeFormula("H11")
public class H11_HBRBFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H11_HBRBFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
	ClaimPaymentRepository claimPaymentRepository ;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
//		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
//				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit(), working.getPresentedNosOfDays());
		List<String> parameterNames = Arrays.asList("MaxNoOfDay", "NoOfUnit", "ValuePerUnit", "PresentedNosOfDays");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// no need to compute if the presented day == 0;
		if (working.getPresentedNosOfDays() == 0) {
			working.setAllocatedDay(0);
			working.setEligibleAmt(BigDecimal.ZERO);
		}

		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();

		// previousDaysAllocated
		Integer previousAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays();
		
		// Add excess ICU days from CSME/BBL
		Boolean isCSMEorBBL = Arrays.asList(ProductType.BBL.toString(),ProductType.CSME.toString()).contains(working.getProductType()) ;
		if(isCSMEorBBL) {
			PreviousClaimPaymentAllocation h17Allocation = previousCurrentAllocationHelper.getTotalAllocationByBenefitCoverage(BenefitCode.H17.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getProductCode(), working) ;
			// get excess days from ICU if any
			if(ObjectUtils.compare(claimCanonical.getClaim().getDayOfAdmitIcu(), 0)  > 0) {				
				Integer excessICUDays = claimCanonical.getClaim().getDayOfAdmitIcu() - h17Allocation.getDaysAllocated() ;
				daysAllocated+= Math.max(excessICUDays,0) ;
				
				if (working.isCalculationLoggerEnabled() && excessICUDays > 0) {
					working.getCalculationLogger().debug("Added ICU Excess Days = {} from H17. PresentedDays will now be {}",excessICUDays, daysAllocated) ;
				}
			}
			// check H11/H17 total alocated days.
			Integer maxSumDay = FormatUtil.convertNullInteger(planBenefit.getMaxSumDay()) ;
			if(maxSumDay > 0) {
				PreviousClaimPaymentAllocation h17PreviousAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H17.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);
				Integer totalSumAllocation = previousAllocatedDays + h17Allocation.getDaysAllocated() + h17PreviousAllocation.getDaysAllocated() ;
				if(totalSumAllocation + daysAllocated > maxSumDay) {
					daysAllocated = Math.max(maxSumDay - totalSumAllocation,0) ;
					if (working.isCalculationLoggerEnabled() ) {
						working.getCalculationLogger().debug("Presented days adjusted to ({}) due to previous H11({})/H17({}) exceeded PlanBenefit.MaxSumDay({}). ",daysAllocated, previousAllocatedDays, h17Allocation.getDaysAllocated() + h17PreviousAllocation.getDaysAllocated(), maxSumDay) ;
					}
				}
			}			
		}
		
		if (daysAllocated + previousAllocatedDays > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - previousAllocatedDays;
			daysAllocated = Math.max(daysAllocated, 0);
		}

		Integer hospitalInd = getHospitalIndByHBPType(claimCanonical.getClaim().getHbpType());
		// Changes in logic: use updated data dictionary mapping (-Wanyupa May 09,2017 email -offsite
		
		//Integer hospitalInd = !StringUtils.isEmpty(claimCanonical.getClaim().getHbpType()) && StringUtils.isNumeric(claimCanonical.getClaim().getHbpType()) ? new Integer(claimCanonical.getClaim().getHbpType()) : null;
		Integer moreValue = 1;
		
		/*
		boolean attainedAge = ( claimPolicyPlan.getRateAge() != null && claimPolicyPlan.getRateAge() <= 60 && claimPolicyPlan.getRateAge() >= 21 ) || "Y".equals(claimCanonical.getClaim().getAttainedAgeInd());
		
		if (!StringUtils.isEmpty(working.getProductCode()) && working.getProductCode().startsWith(ProductCode.HBP.toString()) && hospitalInd != null) {
				if (new Integer(HBPType.ONE.toString()).equals(hospitalInd)) {
					moreValue = 3;
				} else if (new Integer(HBPType.TWO.toString()).equals(hospitalInd) && attainedAge) {
					moreValue = 2;
				} else if (new Integer(HBPType.THREE.toString()).equals(hospitalInd)) {
					moreValue = 2;
				} else if (new Integer(HBPType.FOUR.toString()).equals(hospitalInd) && attainedAge) {
					moreValue = 2;
				}
		}
		*/
  ///////////////////////
		if (working.getPlanName().matches("("+ProductCode.HBP.toString()+").*")){
			if(Arrays.asList(HBPType.ONE.toString(),HBPType.TWO.toString(),HBPType.THREE.toString(), HBPType.FOUR.toString()).contains(claimCanonical.getClaim().getHbpType())// 
			    && "Y".equals(claimCanonical.getClaim().getAttainedAgeInd())){
				    moreValue = 2;
			}
			if(Arrays.asList(HBPType.THREE.toString(),HBPType.FOUR.toString()).contains(claimCanonical.getClaim().getHbpType()) //
		        && (Arrays.asList("G","S").contains(claimCanonical.getClaim().getAnesthesiaInd()))){
			        moreValue = 2;
			}
			if(HBPType.TWO.toString().equals(claimCanonical.getClaim().getHbpType())){
	            moreValue = 3;
		    }
		}
//////////////////////		
		// amountAllocated
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit).multiply(BigDecimal.valueOf(moreValue));
		Boolean isLifeCare = ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode());
		if (isLifeCare) {
			amountAllocated = valuePerUnit;
		}

		// TODO: confinement day should be set from H17 if exists
		PreviousHBPHospitalization prevHBPHospitalization = claimPaymentDetailRepository.findPreviousHBAllocatedDays(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(),
				planBenefit.getConfinementDay());

		Integer fixBenefitx3Day = 365;
		Integer fixMaxHospitalDay = 1260;

		if (daysAllocated > 0 && prevHBPHospitalization.getPrevHBPGx3Day() >= fixBenefitx3Day) {
			daysAllocated = fixBenefitx3Day - prevHBPHospitalization.getPrevHBPGx3Day();
		}

		if (daysAllocated > 0 && prevHBPHospitalization.getHospitalizationDays() >= fixMaxHospitalDay) {
			daysAllocated = fixMaxHospitalDay - prevHBPHospitalization.getHospitalizationDays();
		}

		if (daysAllocated <= 0) {
			daysAllocated = 0;
		}

		if(isCSMEorBBL && daysAllocated > 0) {
			Integer maxSumDay = FormatUtil.convertNullInteger(planBenefit.getMaxSumDay()) ;
			if(maxSumDay > 0) {
				PreviousClaimPaymentAllocation currentH17Allocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H17.toString(),
					working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
				PreviousClaimPaymentAllocation h17PreviousAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H17.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);
				if(currentH17Allocation.getDaysAllocated() + h17PreviousAllocation.getDaysAllocated() + daysAllocated > maxSumDay) {
					Integer days = daysAllocated ;
					daysAllocated = maxSumDay - (currentH17Allocation.getDaysAllocated() + h17PreviousAllocation.getDaysAllocated()) ;
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("CSME/BBL: Recaculated DaysAllocation from= {} , new value= {} due to PlanBenefit.MaxSumDay({}) > H17 Previous Day Allocation Current Days={} + Previous Days={}",
								days, daysAllocated , maxSumDay, currentH17Allocation.getDaysAllocated() , h17PreviousAllocation.getDaysAllocated() );
					}
				}
			}
		}
		
		BigDecimal eligibleAmt = amountAllocated.multiply(BigDecimal.valueOf(daysAllocated));
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug(
					"Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfUnit={},ValuePerUnit={},RateAge={},HbpType={},HospitalInd={},SUM(H11PreviousDaysAllocated with HbpType=1 + H17PreviousDaysAllocated)={},SUM(H11PreviousDaysAllocated + H17PreviousDaysAllocated)={},DaysAllocated={}",
					working.getProductCode(), maxDaysAllocated, nosOfUnit, valuePerUnit, claimPolicyPlan.getRateAge(), claimCanonical.getClaim().getHbpType(),hospitalInd,
					prevHBPHospitalization.getPrevHBPGx3Day(), prevHBPHospitalization.getHospitalizationDays(), daysAllocated);

			if (isLifeCare) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxNoOfDay-PreviousDaysAllocated={},NoOfDaysPresented) x ValuePerUnit", eligibleAmt, previousAllocatedDays);
			} else {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxNoOfDay-PreviousDaysAllocated={},NoOfDaysPresented) x NoOfUnit x ValuePerUnit x HospitalInd_Multiplier={}", eligibleAmt,
						previousAllocatedDays, moreValue);
			}

		}

		if (eligibleAmt.compareTo(BigDecimal.ZERO) > 0) {
			if (working.getProductSpecificConfinementAdjuster() != null && ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())) {
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
				}
				// further  adjustment by maxconfinement
				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
				}
				eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, maxConfinementAmt);
				if (SubmissionType.Cashless.toString().equalsIgnoreCase(claimCanonical.getClaim().getSubmissionType())) {
					daysAllocated = 0;
				}
			}

			if (eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligibleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}
		} else {
			daysAllocated = 0;
		}
		///////////////////////////////
		if (working.getPlanName().matches("("+ProductCode.HBP.toString()+"|"+ProductCode.HBX.toString()+").*")){
			if(!Arrays.asList(IPDTreatmentType.TYPE_1.toString(),IPDTreatmentType.TYPE_2.toString()).contains(claimCanonical.getClaim().getTreatmentType())// 
						|| (HBPType.FIVE.toString().equals(claimCanonical.getClaim().getHbpType()))){
					eligibleAmt = BigDecimal.ZERO;
				}
		}
		////////////////////////////
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligibleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		if(isCSMEorBBL) {
			
			PreviousClaimPaymentAllocation currH11 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);
			
			PreviousClaimPaymentAllocation currH17 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H17.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH22 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H22.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH04 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H04.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH07 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H07.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH08 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H08.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);
			
			BigDecimal previousApprovedAmt = currH11.getAmountAllocated().add(currH17.getAmountAllocated()).add(currH22.getAmountAllocated()).
					add(currH04.getAmountAllocated()).add(currH07.getAmountAllocated()).add(currH08.getAmountAllocated()) ;
			
			ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getCompanyId(), claimCanonical) ;

			if(claimPolicy != null) {
				BigDecimal remainingSumAssured = claimPolicy.getSumAssured() != null ? claimPolicy.getSumAssured() : BigDecimal.ZERO ;
				BigDecimal totalApprovedAmt = claimPaymentRepository.findTotalPreviousPaidByPolicyPlan( working.getPolicyNo(), working.getPlanId(), working.getPlanCoverageNo(), true) ;
				
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("{} Product limit checking. Previous Paid H11={},H17={},H22={},H04={},H07={},H08={}. Total Previous Paid = {}", working.getProductType(),currH11.getAmountAllocated(),
							currH17.getAmountAllocated(), currH22.getAmountAllocated(),currH04.getAmountAllocated(),
							currH07.getAmountAllocated(),currH08.getAmountAllocated(),previousApprovedAmt);
				}
				
				if(totalApprovedAmt.compareTo(BigDecimal.ZERO) > 0) {
					remainingSumAssured = remainingSumAssured.subtract(totalApprovedAmt).max(BigDecimal.ZERO) ;					
				} 		
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("ClaimPolicy.SumAssured= {} ,Total Approved Amt={}, Remaining SumAssured={}", claimPolicy.getSumAssured(), totalApprovedAmt, remainingSumAssured) ;								
				}

				if(previousApprovedAmt.add(eligibleAmt).compareTo(remainingSumAssured) > 0) {
					eligibleAmt = eligibleAmt.min(remainingSumAssured.subtract(previousApprovedAmt)).max(BigDecimal.ZERO) ;
				}
				
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("New Value of EligbleAmt = {}",  eligibleAmt) ;
				}

			}
			
			Boolean isIPD = Arrays.asList("1", "2").contains(claimCanonical.getClaim().getTreatmentType());
			if(!isIPD) {
				eligibleAmt = BigDecimal.ZERO;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("EligbleAmt = 0 since this is not IPD case.") ;
				}
			}
		}
		
		// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		working.setAllocatedDay(daysAllocated);
		
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

	/*
	 * "Reference common object
	(0 = blank  [Hospital type benefit =blank]
	1 = R&B and/or ICU  [Hospital type benefit = 4]
	2 = Dx: CA, Ac.Heart Attack, CABG, Stroke [Hospital type benefit = 1]
	3 = IPD surgery  [Hospital type benefit = 3]
	4 = R&B and/or ICU  [Hospital type benefit = 2]
	5 = Not Applicable  [Hospital type benefit = 5])	
	 * 
	 */
	private Integer getHospitalIndByHBPType(String hbpType) {
		if (StringUtils.isEmpty(hbpType)) {
			return null ;
		}
		if (StringUtils.isNumeric(hbpType)) {
			Integer ONE = 1;
			Integer TWO = 2;
			Integer THREE = 3;
			Integer FOUR = 4;
			
			if (new Integer(hbpType).equals(ONE)) {
				return 4;
			}
			if (new Integer(hbpType).equals(TWO)) {
				return 1;
			}
			if (new Integer(hbpType).equals(THREE)) {
				return 3;
			}
			if (new Integer(hbpType).equals(FOUR)) {
				return 2;
			}
			
		}
		return null ;
	}

}
