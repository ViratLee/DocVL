package com.aia.cmic.formula.ol;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H34")
public class H34_OPDSurgery extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H34_OPDSurgery.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt() != null ? planBenefit.getMaxBenefitAmt() : BigDecimal.ZERO ;
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		if(working.getCalculationLogger().isDebugEnabled()) {
			working.getCalculationLogger().debug("PolicyNo={},MaxBenefitAmt={},PlanId={}",working.getPolicyNo(), maxBenefitAmt, working.getPlanId()) ;
			working.getCalculationLogger().debug("Current Used Amt={} , Previous Used Amt ={}, ", previousClaimAllocation.getAmountAllocated(), working.getPreviousAllocation().getAmountAllocated()) ;
		}
		BigDecimal prevAmtUSed = previousClaimAllocation.getAmountAllocated() ;
		BigDecimal eligibleAmt = BigDecimal.ZERO ;
		if(working.getPresentedAmt().compareTo(BigDecimal.ZERO) > 0 ) {
			eligibleAmt = maxBenefitAmt.min(working.getPresentedAmt());
			if(eligibleAmt.add(prevAmtUSed).compareTo(maxBenefitAmt) > 0) {
				eligibleAmt = maxBenefitAmt.subtract(prevAmtUSed) ;
			}
			if(working.getCalculationLogger().isDebugEnabled()) {
				working.getCalculationLogger().debug("Total Used Amt={} , EligibleAmt adjusted to ={}, ", prevAmtUSed , eligibleAmt) ;
			}
			if(working.getProductSpecificConfinementAdjuster() != null) {
				eligibleAmt =working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, planBenefit.getMaxConfinementAmt());
			}
			if(working.getCalculationLogger().isDebugEnabled()) {
			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(PresentedAmt={},RemainAmtPolicyYear={})", eligibleAmt,working.getPresentedAmt());
			}
		}
				// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		
	}

	public boolean isPresentedAmtRequired() {
		return true;
	}
}
