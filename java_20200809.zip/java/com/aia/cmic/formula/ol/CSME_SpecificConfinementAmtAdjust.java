package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;

@Component("CSMESpecificConfinementAmtAdjuster")
public class CSME_SpecificConfinementAmtAdjust implements ProductConfinementAdjustable {

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public BigDecimal adjustEligibleAmtViaMaxConfinement(ClaimCanonical claimCanonical, PaymentAllocationTemp working, BigDecimal eligbleAmt, BigDecimal maxConfinementAmt) {

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Checking EligibleAmt={} vs MaxConfinementAmt={}, productCode={}", eligbleAmt, maxConfinementAmt,working.getProductCode());
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		BigDecimal adjustedAmt = eligbleAmt;

		if(Arrays.asList(BenefitCode.H04.toString(),BenefitCode.H05.toString(),BenefitCode.H07.toString(),BenefitCode.H08.toString()).contains(working.getBenefitCode())) {
			// current total amt confinement
			BigDecimal amtConfinement = previousCurrentAllocationHelper.getTotalConfinementAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo());
	
			BigDecimal previousAmtReimbursedOld = BigDecimal.ZERO;
	
	
			PreviousClaimPaymentAllocation h04 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H04.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h05 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H05.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h07 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H07.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h08 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H08.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			
			
			previousAmtReimbursedOld = h04.getAmountAllocated().add(h05.getAmountAllocated()).add(h07.getAmountAllocated()).add(h08.getAmountAllocated());
	
			
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Current Total Used Amt={}", amtConfinement);
				working.getCalculationLogger().debug("Old Claim Used Amt:H04={},H05={},H07={},H08={}", h04.getAmountAllocated(),
						h05.getAmountAllocated(), h07.getAmountAllocated(), h08.getAmountAllocated());
				working.getCalculationLogger().debug("Total Used Amt for this policy/plan={}", amtConfinement.add(previousAmtReimbursedOld));
			}
	
			if (eligbleAmt.add(amtConfinement).add(previousAmtReimbursedOld).compareTo(maxConfinementAmt) > 0) {
				adjustedAmt = maxConfinementAmt.subtract(amtConfinement.add(previousAmtReimbursedOld));
				adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
			}
			
			// update confinement amt
			previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
		}
		return adjustedAmt;
	}

}
