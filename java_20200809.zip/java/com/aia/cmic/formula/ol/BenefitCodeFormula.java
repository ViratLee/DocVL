package com.aia.cmic.formula.ol;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.model.PaymentAllocationTemp;

public interface BenefitCodeFormula {

	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working);

}
