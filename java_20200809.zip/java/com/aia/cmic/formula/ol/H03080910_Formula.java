package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.CycleDate;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPaymentRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;
import com.aia.cmic.util.ClaimCalculationEnum.ServiceCategoryId;

@BenifitCodeFormula("H03,H08,H09,H10")
public class H03080910_Formula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H03080910_Formula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Autowired
	ClaimPaymentRepository claimPaymentRepository ;
	
	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}

		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);
		PreviousClaimPaymentAllocation oldAllocationDB = working.getPreviousAllocation();
		if (logger.isDebugEnabled()) {
			logger.debug("Current UsedAmount={}, DB UsedAmount={}, Total UsedAmount={}", previousClaimAllocation.getAmountAllocated(), oldAllocationDB.getAmountAllocated(),
					previousClaimAllocation.getAmountAllocated().add(oldAllocationDB.getAmountAllocated()));
		}
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmount={}, DB UsedAmount={}, Total UsedAmount={}", previousClaimAllocation.getAmountAllocated(), oldAllocationDB.getAmountAllocated(),
					previousClaimAllocation.getAmountAllocated().add(oldAllocationDB.getAmountAllocated()));
		}
		BigDecimal currentUsedAmt = previousClaimAllocation.getAmountAllocated() ;
		previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(oldAllocationDB.getAmountAllocated()));

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();

		Boolean isCSMEorBBL = Arrays.asList(ProductType.BBL.toString(),ProductType.CSME.toString()).contains(working.getProductType()) ;
		
		Boolean isLifeCareNoAnesthesiaInd = ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())
				&& (StringUtils.isEmpty(claimCanonical.getClaim().getAnesthesiaInd()) || claimCanonical.getClaim().getAnesthesiaInd().equalsIgnoreCase("N"));
		if (isLifeCareNoAnesthesiaInd) {
			maxBenefitAmt = BigDecimal.ZERO;
		}

		if (ProductCode.HSPG.toString().equalsIgnoreCase(working.getProductCode()) && BenefitCode.H09.toString().compareTo(working.getBenefitCode()) != 0) {
			ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
					working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
			if (claimPolicyPlan != null) {
				maxBenefitAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, claimPolicyPlan.getRateAge(),
						claimPolicyPlan.getPlanIssueDt(), working);
			}
		}

		if (ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode()) && !BenefitCode.H09.toString().equals(working.getBenefitCode())) {
			ClaimPolicyPlan policyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
					working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
			if (policyPlan != null) {
				maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, policyPlan.getRateAge(),
						policyPlan.getPlanIssueDt(), working);
				maxBenefitAmt = maxConfinementAmt ;
			}
		}

		
		/**
		 * Bug Fix - UAT 2017/04/04 HSJR don't have maxBenefitAmt for H02/H03
		 */

		Boolean isHSJRAndH03 = ProductCode.HSJR.toString().equals(working.getProductCode()) && BenefitCode.H03.toString().equals(working.getBenefitCode());

		/**
		 * Change Formula : 03/29/2017 - Wanyupa
		 * 
		 * IF SERVICECATID = '2.5' THEN
		IF amount_presented > Plan.SubPlanCode THEN
		 set amount_presented = Plan.SubPlanCode 
		END IF
		END IF   
		*/ 
		if (ServiceCategoryId.AMBULANCE_SERVICES.toString().equals(working.getServiceCatId())) {
			Plan plan = planRepository.findPlanByPrimaryKey(working.getPlanId());
			if (plan.getSubPlanCode() != null) {
				if (working.getPresentedAmt().compareTo(BigDecimal.valueOf(plan.getSubPlanCode())) > 0) {
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("ServiceCatId = {}, PlanId={} and presentedAmt({}) > plan.getSubPlanCode({})",working.getServiceCatId(),working.getPlanId(),working.getPresentedAmt(),plan.getSubPlanCode()) ;
						working.getCalculationLogger().debug("Setting ElgibleAmt=Plan.SubPlanCode") ;
						working.getCalculationLogger().debug("Setting ElgibleAmt{}=Plan.SubPlanCode") ;
					}
					working.setEligibleAmt(BigDecimal.valueOf(plan.getSubPlanCode()));
					
				} else {
					working.setEligibleAmt(working.getPresentedAmt()) ;
				}
				if(!isHSJRAndH03) {
					
					//amountAllocated
					BigDecimal amountAllocated = working.getEligibleAmt();

					if (working.getEligibleAmt().add(previousClaimAllocation.getAmountAllocated()).compareTo(maxBenefitAmt) > 0) {
						amountAllocated = maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated()).max(BigDecimal.ZERO);
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("EligibleAmt({})= Min(MaxBenefitAmt({}) - UsedAmt({}),presentedAmt({})", amountAllocated, maxBenefitAmt,
									previousClaimAllocation.getAmountAllocated(), working.getEligibleAmt());
						}
					}
					working.setEligibleAmt(amountAllocated);
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("Setting ElgibleAmt={}", working.getEligibleAmt());
					}

					return ;
				}
			}
		}
		
		// H03/HSX changes requested by wanyupa. 07/31/2018
		Boolean isH03AndHSX = org.apache.commons.lang.StringUtils.equals(working.getServiceCatId(), ServiceCategoryId.HOME_MEDICATION.toString())
			&& ProductCode.HSX.toString().equalsIgnoreCase(working.getProductCode()) && BenefitCode.H03.toString().equals(working.getBenefitCode());

		
		//eligible Amount
		BigDecimal eligibleAmt = working.getPresentedAmt();
		
		if(isH03AndHSX) {
			PreviousClaimPaymentAllocation h03HSXCurrentAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNoServiceCatid(working.getBenefitCode(),
					working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working.getServiceCatId(), working);
			BigDecimal remainAmtPresented = BigDecimal.valueOf(1000).subtract(h03HSXCurrentAllocation.getAmountAllocated()).max(BigDecimal.ZERO) ;
			remainAmtPresented = working.getPresentedAmt().min(remainAmtPresented);
			eligibleAmt = remainAmtPresented ;
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("ProductCode=HSX/BenefitCode=H03 recomputed presentedAmt from {} to {}", working.getPresentedAmt(), remainAmtPresented ) ;
			}
			//working.setPresentedAmt(remainAmtPresented);
		}
		
		//amountAllocated
		BigDecimal amountAllocated = working.getPresentedAmt();
				
		Boolean isHNW = org.apache.commons.lang.StringUtils.equals(ProductCode.HNW.toString(), working.getProductCode()) ;
		if(isHNW) {
			eligibleAmt = maxBenefitAmt.subtract(currentUsedAmt).min(amountAllocated).max(BigDecimal.ZERO);
			Boolean isH09AndHNW =  org.apache.commons.lang.StringUtils.equals(BenefitCode.H09.toString(), working.getBenefitCode());
			if(isH09AndHNW) {
				// requirement: 1st occurrence hospitalizationDt vs acciddentDt should be  1 day/24 hours, further claim should be within 30 days
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("requirement: 1st occurrence hospitalizationDt vs acciddentDt should be  1 day/24 hours, further claim should be within 30 days");
				}
				if(claimCanonical.getClaim().getHospitalizationDate() != null && claimCanonical.getClaim().getAccidentDt() != null) {
					Date hostpitalizationDt = claimCanonical.getClaim().getHospitalizationDate() ;
					Date accidentDt = claimCanonical.getClaim().getAccidentDt() ;
					hostpitalizationDt = DateUtils.truncate(hostpitalizationDt, Calendar.DAY_OF_MONTH) ;
					accidentDt = DateUtils.truncate(accidentDt, Calendar.DAY_OF_MONTH) ;
					Long daysDiff = TimeUnit.DAYS.convert(accidentDt.getTime() - hostpitalizationDt.getTime()  , TimeUnit.MILLISECONDS) ;
					if((claimCanonical.getClaim().getOccurrence().equals(1) && daysDiff > 1) || (claimCanonical.getClaim().getOccurrence() > 1 && daysDiff > 30)) {
						eligibleAmt = BigDecimal.ZERO ;
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("hospitalizationDt and accidentDt doesnt meet reqmt. HospitalizationDt={},AccidentDt={},Day Difference={}! Setting ElibleAmt=0.",
									hostpitalizationDt,accidentDt,daysDiff); 
						}
					}
				} else {
					eligibleAmt = BigDecimal.ZERO ;
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("hospitalizationDt and accidentDt is required and should not be NULL! Setting ElibleAmt=0."); 
					}
				}
			} 
		} else {
			/** old default flow **/
			if (!isHSJRAndH03 ) {
				if (eligibleAmt.add(previousClaimAllocation.getAmountAllocated()).compareTo(maxBenefitAmt) > 0) {
					eligibleAmt = maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated()).max(BigDecimal.ZERO);
				}
			}
		}
		
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},AnesthesiaInd={},PresentedAmt={},MaxBenefitAmt={}", working.getProductCode(),
					claimCanonical.getClaim().getAnesthesiaInd(), working.getPresentedAmt(), maxBenefitAmt);
		}

		Boolean isOldHS = working.getProductCode().indexOf(ProductCode.HSOLD.toString()) != -1 && BenefitCode.H03.toString().equals(working.getBenefitCode());
		if (eligibleAmt.compareTo(BigDecimal.ZERO) > 0) {

			if (isOldHS) {
				PreviousClaimPaymentAllocation h01Allocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCode(BenefitCode.H01.toString(), working.getPlanId(),
						working.getPolicyNo(), working);
				PreviousClaimPaymentAllocation h01OldAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);
				h01Allocation.setAmountAllocated(h01Allocation.getAmountAllocated().add(h01OldAllocation.getAmountAllocated()));

				BigDecimal totalReimbursed = h01Allocation.getAmountAllocated();

				PreviousClaimPaymentAllocation h05Allocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCode(BenefitCode.H05.toString(), working.getPlanId(),
						working.getPolicyNo(), working);
				PreviousClaimPaymentAllocation h05OldAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H05.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);
				h05Allocation.setAmountAllocated(h05Allocation.getAmountAllocated().add(h05OldAllocation.getAmountAllocated()));

				totalReimbursed = totalReimbursed.add(h05Allocation.getAmountAllocated());

				// add previous reimburse of this benefit
				totalReimbursed.add(previousClaimAllocation.getAmountAllocated());

				maxBenefitAmt = maxBenefitAmt.subtract(totalReimbursed);

				if (maxBenefitAmt.compareTo(BigDecimal.ZERO) > 0) {
					eligibleAmt = maxBenefitAmt;
				} else {
					eligibleAmt = BigDecimal.ZERO;
				}
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("HS-OLD Additional Parameters: ProductCode={},MaxBenefitAmt={},H01_UsedAmt={},H05_UsedAmt={},EligbleAmt={}", working.getProductCode(),
							planBenefit.getMaxBenefitAmt(), h01Allocation.getAmountAllocated(), h05Allocation.getAmountAllocated(), eligibleAmt);
				}
			}

			// adjustment by presentedAmt
			if (eligibleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligibleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
			}
			if (eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligibleAmt = BigDecimal.ZERO;
			}

			// further  adjustment by maxconfinement
			if (working.getProductSpecificConfinementAdjuster() != null) {
				// 2019/08/14 calculation adjustment
				Boolean doAdjust = Boolean.TRUE ;
				if(isCSMEorBBL) {
					if(!org.apache.commons.lang.StringUtils.equals(BenefitCode.H08.toString(),working.getBenefitCode())) {
						doAdjust = Boolean.FALSE ;
					}
				} 
				
				if(doAdjust) {
					if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
						maxConfinementAmt = planBenefit.getMaxMajorConfinement();
					}
					if (maxConfinementAmt != null || ClaimCalculationEnum.ProductCode.HNW.name().equalsIgnoreCase(working.getProductCode())) {
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
						}
						eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, maxConfinementAmt);
					}
				}
			}

			if (working.isCalculationLoggerEnabled()) {
				if (isLifeCareNoAnesthesiaInd) {
					working.getCalculationLogger().debug("Formula: EligbleAmt=0 ,productCode={} and AnesthesiaInd='N' or AnesthesiaInd is null/empty", working.getProductCode());
				} else if (isOldHS) {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( MaxBenefitAmt - H01_Used_Amt- H05_Used_Amt,presentedAmt)", eligibleAmt);
				} else if (isHSJRAndH03) {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( MaxConfinementAmt - PreviousUsedAmt , PresentedAmt={})", eligibleAmt, working.getPresentedAmt());
				} else {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxBenefitAmt-UsedAmt={},presentedAmt)", eligibleAmt, previousClaimAllocation.getAmountAllocated());
				}

			}

		} else {
			if (working.isCalculationLoggerEnabled()) {
				if (isLifeCareNoAnesthesiaInd) {
					working.getCalculationLogger().debug("Formula: EligbleAmt=0 ,productCode={} and AnesthesiaInd='N' or AnesthesiaInd is null/empty", working.getProductCode());
				} else if (isOldHS) {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( MaxBenefitAmt - H01_Used_Amt- H05_Used_Amt,presentedAmt)", eligibleAmt);
				} else if (isHSJRAndH03) {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( MaxConfinementAmt - PreviousUsedAmt , PresentedAmt={})", eligibleAmt, working.getPresentedAmt());
				} else {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxBenefitAmt-UsedAmt={},presentedAmt)", eligibleAmt, previousClaimAllocation.getAmountAllocated());
				}

			}
		}
		
		
		if(isCSMEorBBL && BenefitCode.H08.toString().equals(working.getBenefitCode())) {
			Boolean isIPDSurgery = Arrays.asList("2").contains(claimCanonical.getClaim().getTreatmentType());	
			Boolean isGenSpineAnesth = Arrays.asList("G","S").contains(claimCanonical.getClaim().getAnesthesiaInd());
			if(isIPDSurgery && isGenSpineAnesth) {
				PreviousClaimPaymentAllocation currH11 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);
				
				PreviousClaimPaymentAllocation currH17 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H17.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH22 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H22.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH04 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H04.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH07 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H07.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH08 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H08.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);
				
				BigDecimal previousApprovedAmt = currH11.getAmountAllocated().add(currH17.getAmountAllocated()).add(currH22.getAmountAllocated()).
						add(currH04.getAmountAllocated()).add(currH07.getAmountAllocated()).add(currH08.getAmountAllocated()) ;
				
				ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getCompanyId(), claimCanonical) ;

				if(claimPolicy != null) {
					BigDecimal remainingSumAssured = claimPolicy.getSumAssured() != null ? claimPolicy.getSumAssured() : BigDecimal.ZERO ;
					BigDecimal totalApprovedAmt = claimPaymentRepository.findTotalPreviousPaidByPolicyPlan( working.getPolicyNo(), working.getPlanId(), working.getPlanCoverageNo(), true) ;
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("{} Product limit checking. Previous Paid H11={},H17={},H22={},H04={},H07={},H08={}. Total Previous Paid = {}", working.getProductType(),currH11.getAmountAllocated(),
								currH17.getAmountAllocated(), currH22.getAmountAllocated(),currH04.getAmountAllocated(),
								currH07.getAmountAllocated(),currH08.getAmountAllocated(),previousApprovedAmt);
					}
					
					if(totalApprovedAmt.compareTo(BigDecimal.ZERO) > 0) {
						remainingSumAssured = remainingSumAssured.subtract(totalApprovedAmt).max(BigDecimal.ZERO) ;					
					} 		
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("ClaimPolicy.SumAssured= {} ,Total Approved Amt={}, Remaining SumAssured={}", claimPolicy.getSumAssured(), totalApprovedAmt, remainingSumAssured) ;								
					}

					if(previousApprovedAmt.add(eligibleAmt).compareTo(remainingSumAssured) > 0) {
						eligibleAmt = eligibleAmt.min(remainingSumAssured.subtract(previousApprovedAmt)).max(BigDecimal.ZERO) ;
					}
					
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("New Value of EligbleAmt = {}",  eligibleAmt) ;
					}
				}
				
			} else {
				eligibleAmt = BigDecimal.ZERO ;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("EligbleAmt = 0 since this is not IPD Surgery (is IPD Surgery? {}) case OR Claim.AnesthesiaInd is not General(G) or Spine (S),Claim.AnesthesiaInd={}", isIPDSurgery, claimCanonical.getClaim().getAnesthesiaInd()) ;
				}
			}
			
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},presentedAmt={}", working.getBenefitCode(), eligibleAmt, working.getPresentedAmt());
		}

		// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		
		// commented for now
				/*
		//TransactionLogging
		if( maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated().add(working.getEligibleAmt())).compareTo(BigDecimal.ZERO) <= 0 ) {
			TransactionLogInfo logInfo = new TransactionLogInfo() ;
			logInfo.setResponseCode(ResponseCode.C004);
			// warn
			// Policy %s / Plan %s / Product Code %s / BenefitCode %s / SumTimeFrame %s - Limit: %s Baht, Previous paid : %s Baht, Presented: %s Baht, Eligible: %s Baht
			logInfo.setParameters(
			Arrays.asList(ResponseSubCode.A, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxBenefitAmt, previousClaimAllocation.getAmountAllocated(), working.getPresentedAmt(), eligbleAmt ).toArray() ) ;
		} 
		// info
		// Policy %s / Plan %s / Product Code %s / BenefitCode %s / SumTimeFrame %s - Limit: %s Baht, Previous paid : %s Baht, Presented: %s Baht, Eligible: %s Baht
		TransactionLogInfo logInfo = new TransactionLogInfo() ;
		logInfo.setResponseCode(ResponseCode.C003);
		logInfo.setParameters(
		Arrays.asList(ResponseSubCode.I, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxBenefitAmt, previousClaimAllocation.getAmountAllocated(), working.getPresentedAmt(), eligbleAmt ).toArray() ) ;
		*/

	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

}
