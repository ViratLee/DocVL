package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;

@BenifitCodeFormula("A15")
public class A15_HUICUFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(A15_HUICUFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);
		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "NoOfUnit", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		// previousDaysAllocated
		Integer previousAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays();
		if (daysAllocated + previousAllocatedDays > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - previousAllocatedDays;
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfUnit={},ValuePerUnit={},PresentedNoOfDay={}", working.getProductCode(), maxDaysAllocated,
					nosOfUnit, valuePerUnit, working.getPresentedNosOfDays());

		}

		// get previous allocated Days of A16(if rollover is define)
		PaymentAllocationTemp nextA16 = previousCurrentAllocationHelper.seekNextBenefitCodeAsExpected(BenefitCode.A16.toString(), working.getPlanId(), working.getPolicyNo(), working);
		Integer prevA16DaysAllocated = 0;
		Boolean isRollOverA16 = nextA16 != null;
		if (isRollOverA16) {
			nextA16.setSeqId(working.getSeqId() + 1);
			//prevA16DaysAllocated = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H01.toString(), working.getPlanId(),
			//		working.getPlanCoverageNo(), working.getPolicyNo(), nextA16).getDaysAllocated();
			prevA16DaysAllocated = nextA16.getPreviousAllocation().getDaysAllocated();

			PlanBenefit A16PlanBenefit = previousCurrentAllocationHelper.getPlanBenefit(nextA16.getPlanId(), nextA16.getBenefitCode(), planBenefitRepository);
			Integer maxDaysAllocatedA16 = 0 ;
			if (A16PlanBenefit != null && A16PlanBenefit.getMaxNoOfDay() != null) {
				maxDaysAllocatedA16 = A16PlanBenefit.getMaxNoOfDay();

//				maxDaysAllocated = maxDaysAllocatedA16;
//				previousAllocatedDays = prevA16DaysAllocated;

				if (prevA16DaysAllocated + daysAllocated + previousAllocatedDays > maxDaysAllocatedA16) {
					daysAllocated = maxDaysAllocatedA16 - ( prevA16DaysAllocated + previousAllocatedDays);
				}
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Additional Parameters: A16.MaxNoOfDay={}, A16PreviouDaysAllocated={}", maxDaysAllocatedA16, prevA16DaysAllocated);
				}
			}
		} else {
			// still need to check A16 allocation
			PlanBenefit A16PlanBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), BenefitCode.A16.toString(), planBenefitRepository);
			Integer maxDaysAllocatedA16 = 0; 
			if(A16PlanBenefit != null) {
				maxDaysAllocatedA16 = A16PlanBenefit.getMaxNoOfDay();
			}
			
			PreviousClaimPaymentAllocation a16 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.A16.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),working) ;
			prevA16DaysAllocated = a16.getDaysAllocated() ;
			
			if (prevA16DaysAllocated + daysAllocated + previousAllocatedDays > maxDaysAllocatedA16) {
				daysAllocated = maxDaysAllocatedA16 - (prevA16DaysAllocated + previousAllocatedDays);
				if (logger.isDebugEnabled()) {
					logger.debug("{}: Readjusting daysAllocated from H01 benefit Code parameters. A16.MaxNoOfDay={}, A16PreviouDaysAllocated={}", working.getBenefitCode(), maxDaysAllocatedA16, prevA16DaysAllocated);
				}

			}
		}

		daysAllocated = Math.max(daysAllocated, 0);
//		if (daysAllocated == 0) {
//			// check if there is remaining days
//			daysAllocated = Math.max(0, maxDaysAllocated - previousAllocatedDays);
//		}

		// should not be more than presented days
		daysAllocated = Math.min(daysAllocated, working.getPresentedNosOfDays());

		// amountAllocated
		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit).multiply(BigDecimal.valueOf(2));

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated.multiply(new BigDecimal(daysAllocated));

		if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligbleAmt = BigDecimal.ZERO;
			daysAllocated = 0;
		}

		if (working.isCalculationLoggerEnabled()) {
			if (isRollOverA16) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = ValuePerUnit x NoOfUnit x Min(daysPresented,A16.MaxNoOfDay- (A16PreviousDaysAllocated +PreviousDaysAllocated={})  ) x 2", eligbleAmt,previousAllocatedDays);
			} else {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  ValuePerUnit x NoOfUnit x Min(daysPresented,MaxNoOfDay-PreviousDaysAllocated={}) x 2", eligbleAmt,
						previousAllocatedDays);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
