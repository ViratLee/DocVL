package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.ICD10Code;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.ICD10CodeRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ICD10Category;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@BenifitCodeFormula("A01,A02,A03")
public class A010203_TotalPartialDisabilityFormula extends OLBenefitCodeFormula {
	private static Logger logger = LoggerFactory.getLogger(A010203_TotalPartialDisabilityFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;
	@Autowired
	PlanRepository planRepository;
	@Autowired
	ICD10CodeRepository icd10CodeRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		 * if (working.isCalculationLoggerEnabled()) {
		 * working.getCalculationLogger().info("=====");
		 * working.getCalculationLogger().info("{}:", working.getBenefitCode());
		 * working.getCalculationLogger().info("====="); }
		 */
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		
		Plan plan = planRepository.findPlanByPrimaryKey(working.getPlanId());
		Boolean isAirCC = StringUtils.startsWithIgnoreCase(plan.getPlanName(), "AIRCC");
		if(isAirCC) {
			// 2017/09/07 AIRCC can be paid if ICD10Category is Assault only
			if(!ICD10Category.ASSAULT.getICD10Category().equalsIgnoreCase(working.getIcd10Category())) {
				working.setEligibleAmt(BigDecimal.ZERO);
				working.setAllocatedDay(0);
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("ICD10COde Category is not Assault. AIRCC can only be paid if Assault. {} not allocated",working.getBenefitCode());
				}
				return;					
			}
		}

		// Check for A03 non-alllocated treatment type
		if (BenefitCode.A03.toString().equals(working.getBenefitCode())) {
			if (!isAirCC) {

				if (NumberUtils.isDigits(claimCanonical.getClaim().getTreatmentType())) {
					// don't allocate for treatmentType :
					/*
					 * - OPD.Accident				
					- OPD.Illness
					- OPD.before admit
					- OPD.after admit
					- Dental
					- Vision
					- Daycase 3 (not Pay HB)
					- Daycase 18 (Pay HB)
					- OPD Chemo
					 */
					int treatmentType = Integer.parseInt(claimCanonical.getClaim().getTreatmentType());
					if (treatmentType >= 4 && treatmentType <= 13) {
						working.setEligibleAmt(BigDecimal.ZERO);
						working.setAllocatedDay(0);
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("TreatmentType={} is included in the filtered list. A03 not allocated", treatmentType);
						}
						return;
					}
				}

				// check ICD10Code. Assault should not be paid
				List<ICD10Code> icd10Categories = icd10CodeRepository.findICD10CodeByDiagnosisCodes2(claimCanonical.getDiagnosisCodes(), working.getIcd10CodeMap());
				if (!CollectionUtils.isEmpty(icd10Categories)) {
					for (ICD10Code icd10Code : icd10Categories) {
						if (ICD10Category.ASSAULT.getICD10Category().equalsIgnoreCase(icd10Code.getIcd10Category())) {
							working.setEligibleAmt(BigDecimal.ZERO);
							working.setAllocatedDay(0);
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("ICD10COde Category ss Assault. A03 not allocated");
							}
							return;
						}
					}

				}

			} 
		}
		
		if(BenefitCode.A01.toString().equalsIgnoreCase(working.getBenefitCode()) && ICD10Category.ASSAULT.getICD10Category().equalsIgnoreCase(working.getIcd10Category()) && !isAirCC) {
			// ICD10Category=Assault should not be paid - Wanyupa
			working.setEligibleAmt(BigDecimal.ZERO);
			working.setAllocatedDay(0);
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("ICD10Category=Assault will not be paid");
			}
			return ;
		}
		

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), planBenefit.getNoOfDays(), claimPolicyPlan.getNoOfUnit(),
				claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "NoOfDays", "NoOfUnit", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		BigDecimal nosOfDays = BigDecimal.valueOf(planBenefit.getNoOfDays());
		BigDecimal indemnityPercentage = planBenefit.getIndemnityPercentage() == null ? BigDecimal.valueOf(100) : planBenefit.getIndemnityPercentage();

		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays();
		if (daysAllocated > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated;
		}

		BigDecimal diValue = BigDecimal.ONE;
		Boolean isDoubleIndemnity = !StringUtils.isEmpty(claimCanonical.getClaim().getDoubleIndemnity()) && "Y".equals(claimCanonical.getClaim().getDoubleIndemnity().toUpperCase());
		if (isDoubleIndemnity) {
			diValue = BigDecimal.valueOf(2);
		}

		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		// eligible Amount
		BigDecimal eligbleAmt = valuePerUnit.multiply((nosOfUnit.multiply(indemnityPercentage).multiply(diValue).multiply(BigDecimal.valueOf(daysAllocated)))).setScale(2)
				.divide(nosOfDays.multiply(BigDecimal.valueOf(100)), RoundingMode.HALF_UP);

		if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligbleAmt = BigDecimal.ZERO;
			daysAllocated = 0;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfDays={},IndemnityPercentage={},DoubleIndemnity={},NoOfUnit={},ValuePerUnit={}",
					working.getProductCode(), maxDaysAllocated, nosOfDays, indemnityPercentage, claimCanonical.getClaim().getDoubleIndemnity(), nosOfUnit, valuePerUnit);
			if (isDoubleIndemnity) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = ValuePerUnit x NoOfUnit x IndemnityPercentage x 2 x Min(daysPresented={},MaxNofDays)/ ( NoOfDays * 100 )", eligbleAmt,
						working.getPresentedNosOfDays());
			} else {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = ValuePerUnit x NoOfUnit x IndemnityPercentage x Min(daysPresented={},MaxNofDays)/ ( NoOfDays * 100 ) ", eligbleAmt,
						working.getPresentedNosOfDays());
			}

		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
