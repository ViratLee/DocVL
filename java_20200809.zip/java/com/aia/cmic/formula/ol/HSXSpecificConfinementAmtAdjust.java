package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@Component("HSXSpecificConfinementAmtAdjust")
public class HSXSpecificConfinementAmtAdjust implements ProductConfinementAdjustable {

	private static Logger logger = LoggerFactory.getLogger(HSXSpecificConfinementAmtAdjust.class);
	@Autowired
	private PlanBenefitRepository planBenefitRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	public HSXSpecificConfinementAmtAdjust() {}
	
	public HSXSpecificConfinementAmtAdjust(PlanBenefitRepository planBenefitRepository, ClaimPaymentDetailRepository claimPaymentDetailRepository) {
		this.claimPaymentDetailRepository = claimPaymentDetailRepository ;
		this.planBenefitRepository = planBenefitRepository ;
	}
	
	@Override
	public BigDecimal adjustEligibleAmtViaMaxConfinement(ClaimCanonical claimCanonical, PaymentAllocationTemp working, BigDecimal eligbleAmt, BigDecimal maxConfinementAmt) {

		if (logger.isDebugEnabled()) {
			logger.debug("HSX confinement executing..");

		}
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Checking EligibleAmt={} vs MaxConfinementAmt={}", eligbleAmt, maxConfinementAmt);
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		BigDecimal adjustedAmt = eligbleAmt;
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// yearly confinement
		BigDecimal maxYearAmt = planBenefit.getMaxYearAmt();

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (logger.isDebugEnabled() && claimPolicyPlan == null) {
			logger.debug("Couldn't find ClaimPolicyPlan from canonical. {} yearly confinement adjustment will be ignored. ", working.getProductType());
		}
		if (claimPolicyPlan != null && claimPolicyPlan.getPlanIssueDt() != null && (claimCanonical.getClaim().getAccidentDt() != null || claimCanonical.getClaim().getHospitalizationDate() != null)) {

			Date startDate = previousCurrentAllocationHelper.findStartDateByIncident(claimPolicyPlan.getPlanIssueDt(), claimCanonical.getClaim().getAccidentDt(),
					claimCanonical.getClaim().getHospitalizationDate());

			if (startDate != null) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(startDate);
				cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) + 1);
				Date endDate = cal.getTime();

				BigDecimal amtConfinementYear = previousCurrentAllocationHelper.getTotalConfinementAmtPerYear(working.getPlanId(), working.getPolicyNo());
				BigDecimal previousAmtReimbursedYearOld = claimPaymentDetailRepository.findTotalHSXEligbleAmtByPlanCoveragePerYear(working.getBenefitCode(), working.getPlanId(),
						working.getPlanCoverageNo(), working.getPolicyNo(), startDate, endDate);

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Year Converage from {} to {}", startDate, endDate);
					working.getCalculationLogger().debug("Current Total Used Amt Per Year={}", amtConfinementYear);
					working.getCalculationLogger().debug("Old Total Used Amt Per Year={}", previousAmtReimbursedYearOld);
					working.getCalculationLogger().debug("PlanBenefit.MaxYearAmt={}", maxYearAmt);
				}

				if (adjustedAmt.add(amtConfinementYear).add(previousAmtReimbursedYearOld).compareTo(maxYearAmt) > 0) {
					adjustedAmt = maxYearAmt.subtract(amtConfinementYear.add(previousAmtReimbursedYearOld));
					adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
				}

			}
		}

		// update confinement amt
		previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
		previousCurrentAllocationHelper.setTotalConfinemeAmtPerYear(working.getPlanId(), working.getPolicyNo(), adjustedAmt);

		return adjustedAmt;
	}

}
