package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.ICD9Code;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.ClaimProcedureCode;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("A12,A14")
public class A1214_HIHMFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(A1214_HIHMFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "NoOfUnit", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();

		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		// amount allocated
		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit);

		PreviousClaimPaymentAllocation totalAllocation = working.getPreviousAllocation();

		Integer daysAllocated = working.getPresentedNosOfDays();
		if (daysAllocated + totalAllocation.getDaysAllocated() > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - totalAllocation.getDaysAllocated();
			daysAllocated = Math.max(daysAllocated, 0);
		}

		// check if treatment is hospitalization only as uf_claim_type sp
		// it should be IPD and not accident

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfUnit={},ValuePerUnit={},TreatmentType={}", working.getProductCode(), maxDaysAllocated,
					nosOfUnit, valuePerUnit, claimCanonical.getClaim().getTreatmentType());

		}
		
		/**
		 * Update Oct 02, Don't pay this benefit if there is no ICU days and AdmitDays. This should have both ICU and Admit Days -Wanyupa
		 */
//		Boolean eligibleToPay =  claimCanonical.getClaim().getDayOfAdmitIcu() != null  && claimCanonical.getClaim().getDayOfAdmitIcu() > 0 && 
//				claimCanonical.getClaim().getDayOfAdmitRoom() != null && claimCanonical.getClaim().getDayOfAdmitRoom() > 0 ;
//		if (!eligibleToPay) {
//			daysAllocated = 0;
//			if (working.isCalculationLoggerEnabled()) {
//				working.getCalculationLogger().debug("Formula: EligbleAmt=0 due to DayOfAdmitIc({}) should be > 0  and DayOfAdmitRoom({}) should be > 0 ",claimCanonical.getClaim().getDayOfAdmitIcu(),claimCanonical.getClaim().getDayOfAdmitRoom());
//			}
//		}

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated.multiply(new BigDecimal(daysAllocated));

		if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligbleAmt = BigDecimal.ZERO;
			daysAllocated = 0;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = ValuePerUnit x NoOfUnit x Min(daysPresented={},MaxNoOfDay-UsedDays={})", eligbleAmt, working.getPresentedNosOfDays(),
					totalAllocation.getDaysAllocated());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);

	}

	private boolean isIPD(ICD9Code icd9category) {
		return "2".equalsIgnoreCase(icd9category.getIcd9Category());
	}

	/**
	 * Check if this claim is IPD
	 *  1- OPD
	 *  2 -IPD
	 * @param icd09Codes
	 * @return
	 */
	private boolean isIPD(List<ClaimProcedureCode> icd09Codes) {
		for (ClaimProcedureCode icd09 : icd09Codes) {
			if ("2".compareToIgnoreCase(icd09.getCodeType()) == 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
