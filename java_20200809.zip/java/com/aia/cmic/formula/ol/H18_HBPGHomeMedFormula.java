package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.util.ClaimCalculationEnum.HBPType;
import com.aia.cmic.util.ClaimCalculationEnum.IPDTreatmentType;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@BenifitCodeFormula("H18")
public class H18_HBPGHomeMedFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H18_HBPGHomeMedFormula.class);

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {
		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/
		if (ProductCode.HBPG.toString().equalsIgnoreCase(working.getProductCode()) || ProductCode.HBX.toString().equalsIgnoreCase(working.getProductCode())) {

			ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(), claimCanonical);
			if (claimPolicyPlan == null) {
				logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
						working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
				throw new ClaimPaymentValidationException(
						"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
			}

			// check required parameters for calculation
			List<Object> requiredParameters = Arrays.asList((Object) claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
			List<String> parameterNames = Arrays.asList("NoOfUnit", "ValuePerUnit");
			ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

			//amountAllocated
			BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
			BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

			BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit);

			// eligible Amount
			BigDecimal eligibleAmt = amountAllocated;
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
				working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},NoOfUnit={},ValuePerUnit={}", working.getProductCode(), nosOfUnit, valuePerUnit);

				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = NoOfUnit x ValuePerUnit ", eligibleAmt);
			}

			// set elegibleAmt 
			working.setEligibleAmt(eligibleAmt);
		}
		
///////////////////////////////
		if(Arrays.asList("HBP","HBX").contains(working.getPlanName())) {
		    if(!Arrays.asList(IPDTreatmentType.TYPE_1.toString(),IPDTreatmentType.TYPE_2.toString()).contains(claimCanonical.getClaim().getTreatmentType())// 
		    		|| (HBPType.FIVE.toString().equals(claimCanonical.getClaim().getHbpType()))){
			    working.setEligibleAmt(BigDecimal.ZERO);
			}
		}
////////////////////////////
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={}", working.getBenefitCode(), working.getEligibleAmt());
		}

	}

}
