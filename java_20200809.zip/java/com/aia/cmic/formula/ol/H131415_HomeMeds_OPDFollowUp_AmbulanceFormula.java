package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@BenifitCodeFormula("H13,H14,H15")
public class H131415_HomeMeds_OPDFollowUp_AmbulanceFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H131415_HomeMeds_OPDFollowUp_AmbulanceFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousClaimAllocation.getAmountAllocated(),
					working.getPreviousAllocation().getAmountAllocated(), previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}
		
		Boolean isHSPG = ProductCode.HSPG.toString().equals(working.getProductCode()) ;
		// specs change. 2017/09/18. Don't check Previous Amt for H13/H14 - Wanyupa
		if(isHSPG || BenefitCode.H13.toString().equals(working.getBenefitCode()) || BenefitCode.H14.toString().equals(working.getBenefitCode())) {
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("For HSPG/H13/H14 : Old Claim UsedAmt should not be included in the checking. This claim will use current UsedAmt={} to determine how much to pay.", previousClaimAllocation.getAmountAllocated());
			} 
		} else {
			previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}
				
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();

		// amountAllocated
		BigDecimal amountAllocated = working.getPresentedAmt();

		Boolean isHSJR = ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode()) ; 
		if (isHSJR) {
			ClaimPolicyPlan policyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
					working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
			if (policyPlan != null) {
				maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, policyPlan.getRateAge(),
						policyPlan.getPlanIssueDt(), working);
				maxBenefitAmt = maxConfinementAmt;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Set MaxBenefitAmt({})=MaxConfinementAmt since productCode={}", maxConfinementAmt,working.getProductCode());
				}				
			}
		} 

		// formula
		amountAllocated = amountAllocated.min(maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated()));
		amountAllocated = amountAllocated.max(BigDecimal.ZERO) ;

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated;

		if (eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {

			// adjustment
			if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
			}
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
			}

			if (working.getProductSpecificConfinementAdjuster() != null) {
				// further  adjustment by maxconfinement
				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
				}
				eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
			}
			

		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxBenefitAmt={},PresentedAmt={}", working.getProductCode(), maxBenefitAmt, working.getPresentedAmt());
			if (!isHSPG && !isHSJR) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxBenefitAmt-PreviousUsedAmt={},presentedAmt)", eligbleAmt, previousClaimAllocation.getAmountAllocated());
			} else {
				working.getCalculationLogger().debug("HSPG EligibleAmt({})=Min(presentedAmt={},MaxBenefitAmt({}) - PreviousUsedAmt({}) ,MaxConfinementAmt({})-PreviousUsedAmt({}) )", eligbleAmt,
							working.getPresentedAmt(), maxBenefitAmt,previousClaimAllocation.getAmountAllocated(), maxConfinementAmt, previousClaimAllocation.getAmountAllocated());					

			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},presentedAmt={}", working.getBenefitCode(), eligbleAmt, working.getPresentedAmt());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);

	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

}
