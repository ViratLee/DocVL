package com.aia.cmic.formula.ol;

public abstract class OLBenefitCodeFormula implements BenefitCodeFormula {

	public boolean isPresentedAmtRequired() {
		return false;
	}

	public boolean isPresentedDaysRequired() {
		return false;
	}

	public boolean isPresentedPercentageRequired() {
		return false;
	}

}
