package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPaymentRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;

@BenifitCodeFormula("H22")
public class H22_IPDDRUGFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H22_IPDDRUGFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
	ClaimPaymentRepository claimPaymentRepository ;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing {} Benefit Code", working.getBenefitCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousClaimAllocation.getAmountAllocated(),
					working.getPreviousAllocation().getAmountAllocated(), previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();

		// previous allocation
		BigDecimal previousAmtReimbursed = previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated());

		// elegibleAmt
		BigDecimal eligibleAmt = maxBenefitAmt.subtract(previousAmtReimbursed);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxBenefitAmt={}", working.getProductCode(), planBenefit.getMaxBenefitAmt());

			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = ClaimPolicyPlan.MaxBenefitAmt - UsedAmt={}", eligibleAmt, maxBenefitAmt, previousAmtReimbursed);
		}

		Boolean isLifeCare = ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode());
		Boolean isCSMEorBBL = Arrays.asList(ProductType.BBL.toString(),ProductType.CSME.toString()).contains(working.getProductType()) ;
		
		if (isLifeCare) {
			ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(), claimCanonical);
			if (claimPolicyPlan == null) {
				logger.warn(
						"Can't get value for valuePerUnit/NosOfUnit from ClaimPolicyPlan Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
						working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
				return;
			}
			BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
			BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());
			BigDecimal maxPlanAmt = valuePerUnit.multiply(nosOfUnit);

			//			BigDecimal amtConfinement = previousCurrentAllocationHelper.getTotalConfinementAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo());
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Additional Parameters: ValuePerUnit={},NoOfUnit={}", valuePerUnit, nosOfUnit);
			}

			if (eligibleAmt.add(previousAmtReimbursed).compareTo(maxPlanAmt) > 0) {
				eligibleAmt = maxPlanAmt.subtract(previousAmtReimbursed);
				eligibleAmt = eligibleAmt.max(BigDecimal.ZERO);
			}
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("LifeCare Formula:  EligibleAmt({})=Min(EligbleAmt,MaxBenefitAmt={} - UsedAmt) ", eligibleAmt, maxPlanAmt);
			}

			// update amount
			previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), eligibleAmt);
		} else if (isCSMEorBBL) {
			
			Boolean isIPD = Arrays.asList("1", "2").contains(claimCanonical.getClaim().getTreatmentType());			
//			BigDecimal previousPaidAmtByPolicy = claimPaymentRepository.findTotalPreviousPaidByPolicyPlan( working.getPolicyNo(), working.getPlanId(), working.getPlanCoverageNo(), false) ;
			if(working.getPreviousAllocation().getAmountAllocated().compareTo(BigDecimal.ZERO) == 0 && isIPD  && StringUtils.equalsIgnoreCase("Y", claimCanonical.getClaim().getIpdDrug()) ) {
				eligibleAmt = eligibleAmt.min(maxBenefitAmt) ;
				
				PreviousClaimPaymentAllocation currH11 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);
				
				PreviousClaimPaymentAllocation currH17 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H17.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH22 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H22.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH04 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H04.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH07 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H07.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH08 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H08.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);
				
				BigDecimal previousApprovedAmt = currH11.getAmountAllocated().add(currH17.getAmountAllocated()).add(currH22.getAmountAllocated()).
						add(currH04.getAmountAllocated()).add(currH07.getAmountAllocated()).add(currH08.getAmountAllocated()) ;
				
				ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getCompanyId(), claimCanonical) ;

				if(claimPolicy != null) {
					BigDecimal remainingSumAssured = claimPolicy.getSumAssured() != null ? claimPolicy.getSumAssured() : BigDecimal.ZERO ;
					BigDecimal totalApprovedAmt = claimPaymentRepository.findTotalPreviousPaidByPolicyPlan( working.getPolicyNo(), working.getPlanId(), working.getPlanCoverageNo(), true) ;
					
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("{} Product limit checking. Previous Paid H11={},H17={},H22={},H04={},H07={},H08={}. Total Previous Paid = {}", working.getProductType(),currH11.getAmountAllocated(),
								currH17.getAmountAllocated(), currH22.getAmountAllocated(),currH04.getAmountAllocated(),
								currH07.getAmountAllocated(),currH08.getAmountAllocated(),previousApprovedAmt);
					}
					
					if(totalApprovedAmt.compareTo(BigDecimal.ZERO) > 0) {
						remainingSumAssured = remainingSumAssured.subtract(totalApprovedAmt).max(BigDecimal.ZERO) ;					
					} 		
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("ClaimPolicy.SumAssured= {} ,Total Approved Amt={}, Remaining SumAssured={}", claimPolicy.getSumAssured(), totalApprovedAmt, remainingSumAssured) ;								
					}

					if(previousApprovedAmt.add(eligibleAmt).compareTo(remainingSumAssured) > 0) {
						eligibleAmt = eligibleAmt.min(remainingSumAssured.subtract(previousApprovedAmt)).max(BigDecimal.ZERO) ;
					}
					
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("New Value of EligbleAmt = {}",  eligibleAmt) ;
					}
				}
						
			} else {
				eligibleAmt = BigDecimal.ZERO ;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("EligbleAmt = 0 since this is not IPD case or already has previous paid. Previous paid ={}", working.getPreviousAllocation().getAmountAllocated()) ;
				}
			}
		}

		if (eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligibleAmt = BigDecimal.ZERO;
		}

		// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={}", working.getBenefitCode(), working.getEligibleAmt());
		}

	}

}
