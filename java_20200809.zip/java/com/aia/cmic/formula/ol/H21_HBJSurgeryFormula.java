package com.aia.cmic.formula.ol;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H21")
public class H21_HBJSurgeryFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H21_HBJSurgeryFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}

		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		if (previousCurrentAllocationHelper.checkIfQualifyForH20H21(working.getBenefitCode(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working, claimCanonical)) {

			PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

			// ceiling parameters
			BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt() != null ? planBenefit.getMaxBenefitAmt() : BigDecimal.ZERO;

			// current allocation
			PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
					working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

			// previous allocation
			PreviousClaimPaymentAllocation oldAllocation = working.getPreviousAllocation();

			BigDecimal totalAllocation = previousClaimAllocation.getAmountAllocated().add(oldAllocation.getAmountAllocated());
			BigDecimal eligibleAmt = maxBenefitAmt.subtract(totalAllocation);

			eligibleAmt = eligibleAmt.max(BigDecimal.ZERO);

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={},productCode={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(),
						working.getProductCode());
				working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxBenefitAmt={},CurrentAllocation={},OldAllocation={}", working.getProductCode(), maxBenefitAmt,
						previousClaimAllocation.getAmountAllocated(), oldAllocation.getAmountAllocated());
				working.getCalculationLogger().debug("Formula: EligibleAmt({}) = MaxBenefitAmt({}) -  ( CurrentAllocation({}) + OldAllocation({}) )", eligibleAmt, maxBenefitAmt,
						previousClaimAllocation.getAmountAllocated(), oldAllocation.getAmountAllocated());
			}

			// set elegibleAmt and
			working.setEligibleAmt(eligibleAmt);
		}
	}

}
