package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.formula.logger.Logging;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@BenifitCodeFormula("H30,H31,H32")
public class H30H31H32_OPDGeneral extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H30H31H32_OPDGeneral.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;
	
	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

//		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
//				working.getPlanCoverageNo(), claimCanonical);
//		if (claimPolicyPlan == null) {
//			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
//					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
//			throw new ClaimPaymentValidationException(
//					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
//		}
//
//		// check required parameters for calculation
//		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit(), working.getPresentedNosOfDays());
//		List<String> parameterNames = Arrays.asList("MaxNoOfDay", "NoOfUnit", "ValuePerUnit", "PresentedNosOfDays");
//		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");
//		
		BigDecimal eligibleAmt = BigDecimal.ZERO ;
		if(working.getPresentedAmt().compareTo(BigDecimal.ZERO) > 0 ) {
			eligibleAmt = working.getPresentedAmt() ;
			if(working.getProductSpecificConfinementAdjuster() != null) {
				eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, planBenefit.getMaxConfinementAmt());
			}
			if(working.getCalculationLogger().isDebugEnabled()) {
			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(PresentedAmt={},RemainAmtPolicyYear={})", eligibleAmt,working.getPresentedAmt());
			}
			
			logger.debug("working.getPresentedAmt() > 0: eligibleAmt=adjustEligibleAmtViaMaxConfinement={}", eligibleAmt);

		}
				// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		
	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

}
