package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.model.PreviousHBPHospitalization;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPaymentRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.FormatUtil;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.HBPType;
import com.aia.cmic.util.ClaimCalculationEnum.IPDTreatmentType;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;
import com.aia.cmic.util.ClaimCalculationEnum.SubmissionType;

@BenifitCodeFormula("H17")
public class H17_HBICUFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H17_HBICUFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
	ClaimPaymentRepository claimPaymentRepository ;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		//		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
		//				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), working.getPresentedNosOfDays(), claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("MaxNoOfDay", "NoOfUnit", "PresentedNosOfDays", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// no need to compute if the presented day == 0;
		if (working.getPresentedNosOfDays() == 0) {
			working.setAllocatedDay(0);
			working.setEligibleAmt(BigDecimal.ZERO);
			return;
		}

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();

		// previousDaysAllocated
		Integer previousAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays();
		if (daysAllocated + previousAllocatedDays > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - previousAllocatedDays;
			daysAllocated = Math.max(daysAllocated, 0);
		}

		Integer fixBenefitx3Day = 365;
		Integer fixMaxHospitalDay = 1260;

		//amountAllocated
		int moreValue = 3;
		if(StringUtils.isBlank(claimCanonical.getClaim().getHbpType()) || //
		   claimCanonical.getClaim().getHbpType().equals("0")){
			moreValue = 1;
		}
		
		// change multiplier in case CSME/BBL -wanyupa. 2019/08/08
		Boolean isCSMEorBBL = Arrays.asList(ProductType.BBL.toString(),ProductType.CSME.toString()).contains(working.getProductType()) ;
		if(isCSMEorBBL) {
			moreValue = 2 ;
		}
		
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());
		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit).multiply(BigDecimal.valueOf(moreValue));

		Boolean isWLGIH = working.getProductCode().indexOf(ProductCode.WLGIH.toString()) != -1;
		if (isWLGIH) {
			amountAllocated = valuePerUnit.multiply(BigDecimal.valueOf(2));
		}

		Integer h11DaysAllocation = 0;
		Boolean isLifeCare = ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode());
		if (isLifeCare) {
			//PreviousClaimPaymentAllocation h11PreviousAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(),
			//	working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
			PreviousClaimPaymentAllocation h11PreviousAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H11.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);

			h11DaysAllocation = h11PreviousAllocation.getDaysAllocated();

			if (daysAllocated + h11DaysAllocation > fixBenefitx3Day) {
				daysAllocated = fixBenefitx3Day - h11DaysAllocation;
				daysAllocated = Math.max(0, daysAllocated);
			}

			if (SubmissionType.Cashless.toString().equalsIgnoreCase(claimCanonical.getClaim().getSubmissionType())) {
				daysAllocated = 0;
			}

		}

		PreviousHBPHospitalization prevHBPHospitalization = claimPaymentDetailRepository.findPreviousHBAllocatedDays(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(),
				planBenefit.getConfinementDay());
		if (daysAllocated > 0 && prevHBPHospitalization.getPrevHBPGx3Day() >= fixBenefitx3Day) {
			daysAllocated = fixBenefitx3Day - prevHBPHospitalization.getPrevHBPGx3Day();
			daysAllocated = Math.max(0, daysAllocated);
		}

		if (daysAllocated > 0 && prevHBPHospitalization.getHospitalizationDays() >= fixMaxHospitalDay) {
			daysAllocated = fixMaxHospitalDay - prevHBPHospitalization.getHospitalizationDays();
			daysAllocated = Math.max(0, daysAllocated);
		}
		
		if(isCSMEorBBL && daysAllocated > 0) {
			Integer maxSumDay = FormatUtil.convertNullInteger(planBenefit.getMaxSumDay()) ;
			if(maxSumDay > 0) {
				PreviousClaimPaymentAllocation currentH11Allocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(),
					working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
				PreviousClaimPaymentAllocation h11PreviousAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H11.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);
				if(currentH11Allocation.getDaysAllocated() + h11PreviousAllocation.getDaysAllocated() +  previousAllocatedDays +daysAllocated > maxSumDay) {
					Integer days = daysAllocated ;
					daysAllocated = maxSumDay - (currentH11Allocation.getDaysAllocated() + h11PreviousAllocation.getDaysAllocated() + previousAllocatedDays) ;
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("CSME/BBL: Recaculated DaysAllocation from= {} , new value= {} due to PlanBenefit.MaxSumDay({}) > H11 Previous Day Allocation Previous Days={} + H17 Previous Days={}",
								days, daysAllocated , maxSumDay, currentH11Allocation.getDaysAllocated() + h11PreviousAllocation.getDaysAllocated(), previousAllocatedDays);
					}
				}
			}
		}
		
		// eligible Amount
		BigDecimal eligibleAmt = amountAllocated.multiply(BigDecimal.valueOf(daysAllocated));
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug(
					"Calculation Parameters: ProductCode={},NoOfUnit={},ValuePerUnit={},MaxNoOfDay={},NoOfDaysPresented={},SUM(H11PreviousDaysAllocated with HbpType=1 + H17PreviousDaysAllocated)={},SUM(H11PreviousDaysAllocated + H17PreviousDaysAllocated)={},DaysAllocated={}",
					working.getProductCode(), nosOfUnit, valuePerUnit, maxDaysAllocated, working.getPresentedNosOfDays(), prevHBPHospitalization.getPrevHBPGx3Day(),
					prevHBPHospitalization.getHospitalizationDays(), daysAllocated);

			if (isLifeCare) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min(NoOfDaysPresented, MaxNoOfDay - H11PreviousDaysAllocated={} ) x ValuePerUnit x NoOfUnit x 3", eligibleAmt,
						h11DaysAllocation);
			} else if (isWLGIH) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(NoOfDaysPresented, MaxNoOfDay - H17PreviousDaysAllocated={} ) x ValuePerUnit x 2", eligibleAmt,
						previousAllocatedDays);
			} else {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(NoOfDaysPresented,MaxNoOfDay - H17PreviousDaysAllocated={}  x NoOfUnit x ValuePerUnit * 3", eligibleAmt,
						previousAllocatedDays);
			}
		}

		if (eligibleAmt.compareTo(BigDecimal.ZERO) > 0) {
			if (working.getProductSpecificConfinementAdjuster() != null && ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())) {
				eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, maxConfinementAmt);
			}

			if (eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligibleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}
		} else {
			daysAllocated = 0;
		}
		
///////////////////////////////
		if (working.getPlanName().matches("("+ProductCode.HBP.toString()+"|"+ProductCode.HBX.toString()+").*")){
				if(!Arrays.asList(IPDTreatmentType.TYPE_1.toString(),IPDTreatmentType.TYPE_2.toString()).contains(claimCanonical.getClaim().getTreatmentType())// 
						|| (HBPType.FIVE.toString().equals(claimCanonical.getClaim().getHbpType()))){
					eligibleAmt = BigDecimal.ZERO;
				}
			}
//////////////////////////////
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligibleAmt, daysAllocated, working.getPresentedNosOfDays());
		}
		
		if(isCSMEorBBL) {
			
			PreviousClaimPaymentAllocation currH11 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);
			
			PreviousClaimPaymentAllocation currH17 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H17.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH22 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H22.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH04 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H04.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH07 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H07.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);

			PreviousClaimPaymentAllocation currH08 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H08.toString(), working.getPlanId(), working.getPlanCoverageNo(),
					working.getPolicyNo(), working);
			
			BigDecimal previousApprovedAmt = currH11.getAmountAllocated().add(currH17.getAmountAllocated()).add(currH22.getAmountAllocated()).
					add(currH04.getAmountAllocated()).add(currH07.getAmountAllocated()).add(currH08.getAmountAllocated()) ;
			
			ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getCompanyId(), claimCanonical) ;
			
			if(claimPolicy != null) {
				BigDecimal remainingSumAssured = claimPolicy.getSumAssured() != null ? claimPolicy.getSumAssured() : BigDecimal.ZERO ;
				BigDecimal totalApprovedAmt = claimPaymentRepository.findTotalPreviousPaidByPolicyPlan( working.getPolicyNo(), working.getPlanId(), working.getPlanCoverageNo(), true) ;
				
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("{} Product limit checking. Previous Paid H11={},H17={},H22={},H04={},H07={},H08={}. Total Previous Paid = {}", working.getProductType(),currH11.getAmountAllocated(),
							currH17.getAmountAllocated(), currH22.getAmountAllocated(),currH04.getAmountAllocated(),
							currH07.getAmountAllocated(),currH08.getAmountAllocated(),previousApprovedAmt);
				}
				
				if(totalApprovedAmt.compareTo(BigDecimal.ZERO) > 0) {
					remainingSumAssured = remainingSumAssured.subtract(totalApprovedAmt).max(BigDecimal.ZERO) ;					
				} 		
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("ClaimPolicy.SumAssured= {} ,Total Approved Amt={}, Remaining SumAssured={}", claimPolicy.getSumAssured(), totalApprovedAmt, remainingSumAssured) ;								
				}

				if(previousApprovedAmt.add(eligibleAmt).compareTo(remainingSumAssured) > 0) {
					eligibleAmt = eligibleAmt.min(remainingSumAssured.subtract(previousApprovedAmt)).max(BigDecimal.ZERO) ;
				}
				
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("New Value of EligbleAmt = {}",  eligibleAmt) ;
				}
			}
			
			Boolean isIPD = Arrays.asList("1", "2").contains(claimCanonical.getClaim().getTreatmentType());
			if(!isIPD) {
				eligibleAmt = BigDecimal.ZERO;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("EligbleAmt = 0 since this is not IPD case.") ;
				}
			}
		}
		
		
		// set elegibleAmt and
		working.setEligibleAmt(eligibleAmt);
		working.setAllocatedDay(daysAllocated);
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
