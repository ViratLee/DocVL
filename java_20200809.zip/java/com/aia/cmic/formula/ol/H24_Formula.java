package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H24")
public class H24_Formula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H24_Formula.class);

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		if (previousCurrentAllocationHelper.checkIfQualifyForH24(working, claimCanonical)) {
			if (logger.isDebugEnabled()) {
				logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
			}

			ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(), claimCanonical);
			if (claimPolicyPlan == null) {
				logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
						working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
				throw new ClaimPaymentValidationException(
						"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
			}

			// check required parameters for calculation
			List<Object> requiredParameters = Arrays.asList((Object) claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
			List<String> parameterNames = Arrays.asList("NoOfUnit", "ValuePerUnit");
			ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

			BigDecimal remainPercentage = BigDecimal.valueOf(100).subtract(working.getPreviousAllocation().getPercentageAllocated());
			BigDecimal percentageAllocated = BigDecimal.ZERO;

			if (remainPercentage.compareTo(BigDecimal.ZERO) > 0) {
				if (working.getPresentedPercentage() != null) {
					percentageAllocated = remainPercentage.subtract(working.getPresentedPercentage()).max(BigDecimal.ZERO);
					if (percentageAllocated.compareTo(BigDecimal.ZERO) == 0) {
						percentageAllocated = remainPercentage;
					} else {
						percentageAllocated = working.getPresentedPercentage();
					}
				} else {
					percentageAllocated = remainPercentage;
				}
			}

			BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
			BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

			// eligible Amount
			BigDecimal eligbleAmt = valuePerUnit.multiply(nosOfUnit.multiply(percentageAllocated)).divide(BigDecimal.valueOf(100),RoundingMode.HALF_UP);

			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
				percentageAllocated = BigDecimal.ZERO;
			}

			if (logger.isDebugEnabled()) {
				logger.debug("{} Benefit Code Calculation output: eligibleAmt={},percentageAllocated={}", working.getBenefitCode(), eligbleAmt, percentageAllocated);
			}

			// set elegibleAmt and
			working.setEligibleAmt(eligbleAmt);
			working.setPercentageAllocated(percentageAllocated);

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
				working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},NoOfUnit={},ValuePerUnit={},PresentedPercentage={}", working.getProductCode(), nosOfUnit, valuePerUnit,
						working.getPresentedPercentage());
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  ValuePerUnit * NoOfUnit * Min(PresentedPercentage,100-PercentageUsed={})", eligbleAmt, remainPercentage);

			}
		}

	}

	@Override
	public boolean isPresentedPercentageRequired() {
		return true;
	}

}
