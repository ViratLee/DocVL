package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;

import org.apache.commons.lang.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@Component("HSJLifeCareConfinementAdjuster")
public class HSJ_LifecareSpecificConfinementAmtAdjust implements ProductConfinementAdjustable {

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public BigDecimal adjustEligibleAmtViaMaxConfinement(ClaimCanonical claimCanonical, PaymentAllocationTemp working, BigDecimal eligbleAmt, BigDecimal maxConfinementAmt) {

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Checking EligibleAmt={} vs MaxConfinementAmt={}, productCode={}", eligbleAmt, maxConfinementAmt,working.getProductCode());
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		BigDecimal adjustedAmt = eligbleAmt;
		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);

		// current total amt confinement
		BigDecimal amtConfinement = previousCurrentAllocationHelper.getTotalConfinementAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo());

		if (ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())) {
			if (claimPolicyPlan != null) {
				BigDecimal prevAmtConfinement = claimPaymentDetailRepository.findTotalEligibleAmtByPlanPolicyCoverageNo(working.getCompanyId(), working.getPolicyNo(), working.getPlanId(),
						working.getPlanCoverageNo());
				BigDecimal maxPlanAmt = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit()).multiply(claimPolicyPlan.getNoOfUnit());
				if (adjustedAmt.add(prevAmtConfinement).add(amtConfinement).compareTo(maxPlanAmt) > 0) {
					adjustedAmt = maxPlanAmt.subtract(amtConfinement.add(prevAmtConfinement));
					adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
					previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
					return adjustedAmt;
				}
				previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
				return adjustedAmt;
			} 
			
			return adjustedAmt;
			
		}

		// For HSJ only
//		if (claimPolicyPlan != null) {
//			maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, claimPolicyPlan.getRateAge(), claimPolicyPlan.getPlanIssueDt(),working);
//		}

		if (!BenefitCode.H09.toString().equals(working.getBenefitCode())) {
			
			// Apr 26, 2018. H00,H01,H02,H03,H04,H05,H07,H08,H10,H13,H14,H15 surgery_ind <> 'Y'
			// H02,H03,H04,H05,H07,H08,H10,H13,H14,H15   surgery_ind = 'Y'
			
			Boolean surgeryInd = Arrays.asList("S","G").contains(claimCanonical.getClaim().getAnesthesiaInd()) ;
			
			BigDecimal previousAmtReimbursedOld = BigDecimal.ZERO;

			PreviousClaimPaymentAllocation h02 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H02.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h03 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H03.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h04 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H04.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h05 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H05.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h07 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H07.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h08 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H08.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h10 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H10.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h13 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H13.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h14 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H14.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h15 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H15.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			
			
			previousAmtReimbursedOld = h02.getAmountAllocated().add(h03.getAmountAllocated()).add(h04.getAmountAllocated()).add(h05.getAmountAllocated()).add(h07.getAmountAllocated()).add(h08.getAmountAllocated())
					.add(h10.getAmountAllocated()).add(h13.getAmountAllocated()).add(h14.getAmountAllocated()).add(h15.getAmountAllocated());

			if(BooleanUtils.isFalse(surgeryInd)) {
				PreviousClaimPaymentAllocation h00 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H00.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);
				PreviousClaimPaymentAllocation h01 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(),
						working.getPlanCoverageNo(),working);

				previousAmtReimbursedOld = previousAmtReimbursedOld.add(h00.getAmountAllocated().add(h01.getAmountAllocated()));
				
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Current Total Used Amt={}", amtConfinement);
					working.getCalculationLogger().debug("Old Claim Used Amt: H00={},H01={}, H02={},H03={},H04={},H05={},H07={},H08={},H10={},H13={},H14={},H15={}", h00.getAmountAllocated(),
							h01.getAmountAllocated(), h02.getAmountAllocated(), h03.getAmountAllocated(),h04.getAmountAllocated(),h05.getAmountAllocated(), h07.getAmountAllocated(),
							h07.getAmountAllocated(),h08.getAmountAllocated(),h10.getAmountAllocated(), h13.getAmountAllocated(), h14.getAmountAllocated(), h15.getAmountAllocated());
					working.getCalculationLogger().debug("Total Used Amt for this policy/plan={}", amtConfinement.add(previousAmtReimbursedOld));
				}

			} else {
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Current Total Used Amt={}", amtConfinement);
					working.getCalculationLogger().debug("Old Claim Used Amt:H02={},H03={},H04={},H05={},H07={},H08={},H10={},H13={},H14={},H15={}", h02.getAmountAllocated(), h03.getAmountAllocated(),h04.getAmountAllocated(),
							h05.getAmountAllocated(), h07.getAmountAllocated(), h07.getAmountAllocated(),h08.getAmountAllocated(),h10.getAmountAllocated(), h13.getAmountAllocated(),h14.getAmountAllocated(), h15.getAmountAllocated());
					working.getCalculationLogger().debug("Total Used Amt for this policy/plan={}", amtConfinement.add(previousAmtReimbursedOld));
				}
			}

			if (eligbleAmt.add(amtConfinement).add(previousAmtReimbursedOld).compareTo(maxConfinementAmt) > 0) {
				adjustedAmt = maxConfinementAmt.subtract(amtConfinement.add(previousAmtReimbursedOld));
				adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
			}
		}

		// update confinement amt
		previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
		return adjustedAmt;
	}

}
