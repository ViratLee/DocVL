package com.aia.cmic.formula.ol;

import java.math.BigDecimal;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.model.PaymentAllocationTemp;

public interface ProductConfinementAdjustable {
	public BigDecimal adjustEligibleAmtViaMaxConfinement(ClaimCanonical claimCanonical, PaymentAllocationTemp working, BigDecimal eligbleAmt,BigDecimal maxConfinementAmt) ;
}
