package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.Aicode;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.AicodeRepository;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPaymentRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;

@BenifitCodeFormula("H04,H07")
public class H04H07_SurgicalAnastthesiaFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H04H07_SurgicalAnastthesiaFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
	private AicodeRepository aicodeRepository ;
	
	@Autowired
	ClaimPaymentRepository claimPaymentRepository ;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
*/
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		BigDecimal totalCurrentReimbursedAmt =  previousClaimAllocation.getAmountAllocated();
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousClaimAllocation.getAmountAllocated(),
					working.getPreviousAllocation().getAmountAllocated(), previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}
		
		previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();
		BigDecimal planMaxBenefitAmt = maxBenefitAmt ;

		Boolean isLifeCareNoAnesthesiaInd = ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())
				&& (StringUtils.isEmpty(claimCanonical.getClaim().getAnesthesiaInd()) || claimCanonical.getClaim().getAnesthesiaInd().equalsIgnoreCase("N"));
		if (isLifeCareNoAnesthesiaInd) {
			maxBenefitAmt = BigDecimal.ZERO;
			if (logger.isDebugEnabled()) {
				logger.debug("MaxbenefitAmt set as ZERO(0) for Lifecare productcode and anethesiaInd <> Y!");
			}
		}

		BigDecimal allocatedPercentage = working.getPresentedPercentage();

		if (ProductCode.HSPG.toString().equalsIgnoreCase(working.getProductCode()) || ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())
				|| ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode())) {
			//			presentedPercentage = BigDecimal.valueOf(100);
			allocatedPercentage = BigDecimal.valueOf(100);
			if (logger.isDebugEnabled()) {
				logger.debug("100% allocatedPercentage for HSPG/Lifecare/HSJ!");
			}
		} else if ((working.getPresentedPercentage() == null || working.getPresentedPercentage().compareTo(BigDecimal.ZERO) == 0)) {
			// if presentedPercentage is empty, try to look for past H04 presented percentage for non-HSPG and non-HSJ
			if (!ProductCode.HSPG.toString().equalsIgnoreCase(working.getProductCode()) && !ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode())
					&& BenefitCode.H07.toString().equalsIgnoreCase(working.getBenefitCode())) {
				Boolean hasH04 = previousCurrentAllocationHelper.isCurrentAllocationHasBenefitCode(BenefitCode.H04.toString(), working);
				if (hasH04) {
					allocatedPercentage = BigDecimal.ZERO;
					Aicode aiCode = null ;
					if (!StringUtils.isEmpty(claimCanonical.getClaim().getSurgicalPercentage())) {
						aiCode =  aicodeRepository.findAicodeByPrimaryKey(claimCanonical.getClaim().getSurgicalPercentage());
						if(aiCode != null && aiCode.getAiPercentage() != null) {
							allocatedPercentage =aiCode.getAiPercentage();
						}
					}
					if (logger.isDebugEnabled()) {
						logger.debug("presentedPercentage was not set, check previous H04 presented percentage. Setting percentageAllocated ={} from Claim.SurgicalPercentage={},NumericalValueOfSurgicalPercentage={}", allocatedPercentage,
								claimCanonical.getClaim().getSurgicalPercentage(), aiCode != null ? aiCode.getAiPercentage() : aiCode);
					}
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("Additional parameter:  productCode={},percentageAllocated={},Claim.SurgicalPercentage={},NumericalValueOfSurgicalPercentage={}", working.getProductCode(), allocatedPercentage,
								claimCanonical.getClaim().getSurgicalPercentage(), aiCode != null ? aiCode.getAiPercentage() : aiCode);
					}
				}

			}
		}

		requiredParameters = Arrays.asList((Object) allocatedPercentage);
		parameterNames = Arrays.asList("PresentedPercentage");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		if (ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode())) {
			ClaimPolicyPlan policyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
					working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
			if (policyPlan != null) {
				maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, policyPlan.getRateAge(),
						policyPlan.getPlanIssueDt(), working);
				maxBenefitAmt = maxConfinementAmt ;
				planMaxBenefitAmt = maxConfinementAmt ;
			}
		}

		// presentedAmt
		BigDecimal presentedAmt = working.getPresentedAmt();

		//amountAllocated
		BigDecimal amountAllocated = presentedAmt;
		
		// new maxbenefitAmt
		maxBenefitAmt = maxBenefitAmt.multiply(allocatedPercentage).divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP) ;
		maxBenefitAmt = maxBenefitAmt.subtract(totalCurrentReimbursedAmt);
		if (amountAllocated.compareTo(maxBenefitAmt) > 0) {
			amountAllocated = maxBenefitAmt;
		}

		BigDecimal eligibleAmt = amountAllocated;

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},PresentedPercentage={},PresentedAmt={},AnesthesiaInd={},MaxBenefitAmt={},AllocatedPercentage={},Plan.MaxBenefitAmt",
					working.getProductCode(), working.getPresentedPercentage(), working.getPresentedAmt(), claimCanonical.getClaim().getAnesthesiaInd(), maxBenefitAmt, allocatedPercentage,planMaxBenefitAmt);
		}

		if (eligibleAmt.compareTo(BigDecimal.ZERO) > 0) {
			// Fix 2017/08/05.  Plan.MaxBenefitAmt - Previous Amt not correct. 
			//if (amountAllocated.compareTo(maxBenefitAmt) > 0) {
			//	eligbleAmt = maxBenefitAmt ;
			//}

			//if (eligbleAmt.add(previousClaimAllocation.getAmountAllocated()).compareTo(planMaxBenefitAmt) > 0) {
			//	BigDecimal deductedAmt = maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated());
			//	eligbleAmt = eligbleAmt.min(deductedAmt);
			//}
			eligibleAmt = eligibleAmt.min(planMaxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated())) ;

			// last adjustment
			if (eligibleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligibleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
			}
			if (eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligibleAmt = BigDecimal.ZERO;
				allocatedPercentage = BigDecimal.ZERO;
			}

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( (Plan.MaxBenefitAmt * percentage={} ), (Plan.MaxBenefitAmt({}) - previousAllocatedAmt={}) , presentedAmt={} )", eligibleAmt, allocatedPercentage,
						planMaxBenefitAmt,previousClaimAllocation.getAmountAllocated(), working.getPresentedAmt());
			}

			if (working.getProductSpecificConfinementAdjuster() != null) {
				// further  adjustment by maxconfinement
				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
				}

				if (ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())) {
					ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
							working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
					if (claimPolicyPlan == null) {
						logger.warn(
								"Can't get value for valuePerUnit/NosOfUnit from ClaimPolicyPlan Canonical. Will not compute this benefit code using default PlanBenefit.MaxConfinementAmt; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
								working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
					} else {
						// amount allocated
						BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
						BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());
						maxConfinementAmt = valuePerUnit.multiply(nosOfUnit);
					}
				}
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
				}
				eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, maxConfinementAmt);
				
				if(eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
					allocatedPercentage  = BigDecimal.ZERO;
				}
			}

		} else {
			// reset percentage
			allocatedPercentage = BigDecimal.ZERO;
			if (working.isCalculationLoggerEnabled()) {
				if (isLifeCareNoAnesthesiaInd) {
					working.getCalculationLogger().debug("Formula: EligbleAmt=0 ,productCode={} and AnesthesiaInd='N' or AnesthesiaInd is null/empty", working.getProductCode());
				} else {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( (MaxBenefitAmt * percentage={} ), (MaxBenefitAmt - previousAllocatedAmt={}) ,presentedAmt={} )", eligibleAmt, allocatedPercentage,
							previousClaimAllocation.getAmountAllocated(), working.getPresentedAmt());
				}
			}

		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},percentageAlocated={},presentedAmt={},presentedPercentage={}", working.getBenefitCode(), eligibleAmt, allocatedPercentage,
					working.getPresentedAmt(), working.getPresentedPercentage());
		}

		Boolean isCSMEorBBL = Arrays.asList(ProductType.BBL.toString(),ProductType.CSME.toString()).contains(working.getProductType()) ;
		if(isCSMEorBBL) {
			Boolean isIPDSurgery = Arrays.asList("2").contains(claimCanonical.getClaim().getTreatmentType());	
			Boolean isGenSpineAnesth = Arrays.asList("G","S").contains(claimCanonical.getClaim().getAnesthesiaInd());
			if(isIPDSurgery && isGenSpineAnesth) {
				PreviousClaimPaymentAllocation currH11 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H11.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);
				
				PreviousClaimPaymentAllocation currH17 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H17.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH22 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H22.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH04 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H04.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH07 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H07.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);

				PreviousClaimPaymentAllocation currH08 = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(BenefitCode.H08.toString(), working.getPlanId(), working.getPlanCoverageNo(),
						working.getPolicyNo(), working);
				
				BigDecimal previousApprovedAmt = currH11.getAmountAllocated().add(currH17.getAmountAllocated()).add(currH22.getAmountAllocated()).
						add(currH04.getAmountAllocated()).add(currH07.getAmountAllocated()).add(currH08.getAmountAllocated()) ;
				
				
				ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getCompanyId(), claimCanonical) ;

				if(claimPolicy != null) {
					BigDecimal remainingSumAssured = claimPolicy.getSumAssured() != null ? claimPolicy.getSumAssured() : BigDecimal.ZERO ;
					BigDecimal totalApprovedAmt = claimPaymentRepository.findTotalPreviousPaidByPolicyPlan( working.getPolicyNo(), working.getPlanId(), working.getPlanCoverageNo(), true) ;
					
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("{} Product limit checking. Previous Paid H11={},H17={},H22={},H04={},H07={},H08={}. Total Previous Paid = {}", working.getProductType(),currH11.getAmountAllocated(),
								currH17.getAmountAllocated(), currH22.getAmountAllocated(),currH04.getAmountAllocated(),
								currH07.getAmountAllocated(),currH08.getAmountAllocated(),previousApprovedAmt);
					}
					
					if(totalApprovedAmt.compareTo(BigDecimal.ZERO) > 0) {
						remainingSumAssured = remainingSumAssured.subtract(totalApprovedAmt).max(BigDecimal.ZERO) ;					
					} 
					
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("ClaimPolicy.SumAssured= {} ,Total Approved Amt={}, Remaining SumAssured={}", claimPolicy.getSumAssured(), totalApprovedAmt, remainingSumAssured) ;								
					}

					if(previousApprovedAmt.add(eligibleAmt).compareTo(remainingSumAssured) > 0) {
						eligibleAmt = eligibleAmt.min(remainingSumAssured.subtract(previousApprovedAmt)).max(BigDecimal.ZERO) ;
					}
					
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("New Value of EligbleAmt = {}",  eligibleAmt) ;
					}
					
				}
				
			} else {
				eligibleAmt = BigDecimal.ZERO ;
				allocatedPercentage = BigDecimal.ZERO;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("EligbleAmt = 0 since this is not IPD Surgery (is IPD Surgery? {}) case OR Claim.AnesthesiaInd is not General(G) or Spine (S) , Claim.AnesthesiaInd={}", isIPDSurgery, claimCanonical.getClaim().getAnesthesiaInd()) ;
				}
			}
		}
		
		// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		working.setPercentageAllocated(allocatedPercentage);

	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

	@Override
	public boolean isPresentedPercentageRequired() {
		return true;
	}
}
