package com.aia.cmic.formula.ol;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H23")
public class H23_DayCase extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H23_DayCase.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}

		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		if (previousCurrentAllocationHelper.checkIfQualifyForH23(working)) {
			PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

			// ceiling parameters
			BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt() != null ? planBenefit.getMaxBenefitAmt() : BigDecimal.ZERO;

			// Oct 5 update , can be paid per occurrence. no need to check previous occurrence  amount allocation
			// current allocation
			PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
					working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

			BigDecimal eligibleAmt = maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated()).min(working.getPresentedAmt()).max(BigDecimal.ZERO) ;

			if (eligibleAmt.compareTo(BigDecimal.ZERO) > 0) {
				// cannot be more than presentedAmt
				eligibleAmt = eligibleAmt.min(working.getPresentedAmt());

			}

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={},productCode={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(),
						working.getProductCode());
				working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxBenefitAmt={}", working.getProductCode(), maxBenefitAmt);
				working.getCalculationLogger().debug("Formula: EligibleAmt({}) = Min( PresentedAmt({}) , MaxBenefitAmt({}) - CurrentUsedAmt({}))", eligibleAmt,working.getPresentedAmt(), maxBenefitAmt,previousClaimAllocation.getAmountAllocated());
			}

			// set elegibleAmt and
			working.setEligibleAmt(eligibleAmt);
		}
	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}
}
