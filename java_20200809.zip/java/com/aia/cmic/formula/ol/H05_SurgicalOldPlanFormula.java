package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;

@BenifitCodeFormula("H05")
public class H05_SurgicalOldPlanFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H05_SurgicalOldPlanFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/
		if (working.getPresentedPercentage() == null) {
			working.setEligibleAmt(BigDecimal.ZERO);
			working.setPercentageAllocated(BigDecimal.ZERO);
			if (logger.isDebugEnabled()) {
				logger.debug("{} Benefit Code : Presented Percentage is required to allocate this benefit. Skipping allocation.");
			}
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().info("{} Benefit Code : Presented Percentage is required to allocate this benefit. Skipping allocation.");
			}
			return;
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		//(SCR07984) add new varibable at 2019/05/23 ///////////////
		BigDecimal totalCurrentReimbursedAmt =  previousClaimAllocation.getAmountAllocated();
		//  ///////////////
		
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousClaimAllocation.getAmountAllocated(),
					working.getPreviousAllocation().getAmountAllocated(), previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}
		previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();
		
		if (ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode())) {
			ClaimPolicyPlan policyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
					working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
			if (policyPlan != null) {
				maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, policyPlan.getRateAge(),
						policyPlan.getPlanIssueDt(), working);
			}
		}


		//allocatedPercentage
		BigDecimal allocatedPercentage = working.getPresentedPercentage();

		/*
		 * Bug Fix UAT. 2015/04/04 Case S#4
		 */
		/*
		// presented Amt
		BigDecimal presentedAmt = BigDecimal.ZERO;
		// Get excess amount from H04 if any
		PaymentAllocationTemp h04 = previousCurrentAllocationHelper.seekPreviousBenefitCode(BenefitCode.H04.toString(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(),
				working);
		if (h04 != null) {
			presentedAmt = h04.getExcessAmt();
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Calculation Parameters: H04_ExcessAmt ={}", h04.getExcessAmt());
			}
		} */

		//amountAllocated
		BigDecimal amountAllocated = working.getPresentedAmt();
		if (working.getPresentedAmt().compareTo(maxBenefitAmt) > 0) {
			amountAllocated = maxBenefitAmt;

		}
    	/// ///////////////
		
		BigDecimal eligbleAmt = amountAllocated;

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},PresentedPercentage={},MaxBenefitAmt={}", working.getProductCode(), working.getPresentedPercentage(),
					maxBenefitAmt);
		}

		if (eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {
			//(SCR07984) update logic at 2019/05/23 ///////////////
			/*
			if (amountAllocated.compareTo(maxBenefitAmt.multiply(allocatedPercentage).divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP).setScale(2)) > 0) {
				eligbleAmt = maxBenefitAmt.multiply(allocatedPercentage).divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP).setScale(2);
			}
			*/
			BigDecimal maxBenefitAmtPercent = maxBenefitAmt.multiply(allocatedPercentage).divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP).setScale(2);
			maxBenefitAmtPercent = maxBenefitAmtPercent.subtract(totalCurrentReimbursedAmt);
			if (amountAllocated.compareTo(maxBenefitAmtPercent) > 0) {
				eligbleAmt = maxBenefitAmtPercent;
			}
            ////////////////////////////////////////////////////////
			/*
			if (eligbleAmt.add(previousClaimAllocation.getAmountAllocated()).compareTo(maxBenefitAmt) > 0) {
				BigDecimal deductedAmt = maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated());
				eligbleAmt = eligbleAmt.min(deductedAmt);
			}
			*/

			PreviousClaimPaymentAllocation h01Allocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCode(BenefitCode.H01.toString(), working.getPlanId(),
					working.getPolicyNo(), working);
			PreviousClaimPaymentAllocation oldH01Allocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			h01Allocation.setAmountAllocated(h01Allocation.getAmountAllocated().add(oldH01Allocation.getAmountAllocated()));

			BigDecimal totalReimbursed = h01Allocation.getAmountAllocated();
			PreviousClaimPaymentAllocation h03Allocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCode(BenefitCode.H03.toString(), working.getPlanId(),
					working.getPolicyNo(), working);
			PreviousClaimPaymentAllocation oldH03Allocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H03.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			h03Allocation.setAmountAllocated(h03Allocation.getAmountAllocated().add(oldH03Allocation.getAmountAllocated()));

			totalReimbursed = totalReimbursed.add(h03Allocation.getAmountAllocated());

			// add previous reimburse of this benefit
			totalReimbursed.add(previousClaimAllocation.getAmountAllocated());

			BigDecimal maxBenefitAmtReduced = maxBenefitAmt.subtract(totalReimbursed);

			if (maxBenefitAmtReduced.compareTo(BigDecimal.ZERO) > 0) {
				eligbleAmt = maxBenefitAmtReduced.min(eligbleAmt);
				//				eligbleAmt = maxBenefitAmt
			} else {
				eligbleAmt = BigDecimal.ZERO;
			}

			// last adjustment
			if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
				
				// apr 26, 2018 Add MaxConfinementCheck -Wanyupa
				if (working.getProductSpecificConfinementAdjuster() != null) {
					if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
						maxConfinementAmt = planBenefit.getMaxMajorConfinement();
					}
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
					}
					eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
				}

			}
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
				allocatedPercentage = BigDecimal.ZERO;
			}

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug(
						"Formula: EligbleAmt({}) = Min( (MaxBenefit({}) x presentedPercentage({}) ) , MaxBenefitAmt - (H01_UsedAmt({}) + H03_UsedAmt({}) ), presentedAmt({}) )   ", eligbleAmt,
						maxBenefitAmt, allocatedPercentage, h01Allocation.getAmountAllocated(), h03Allocation.getAmountAllocated(), working.getPresentedAmt());
			}

			// temporarily commented
			//			if (working.getProductSpecificConfinementAdjuster() != null && ProductCode.HSPG.toString().equalsIgnoreCase(working.getProductCode())) {
			//				if (working.isCalculationLoggerEnabled()) {
			//					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
			//				}
			//				eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
			//			}

		} else {
			allocatedPercentage = BigDecimal.ZERO;
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( (MaxBenefit({}) x presentedPercentage({}) ) , MaxBenefitAmt - (H01_UsedAmt + H03_UsedAmt ), presentedAmt({}) )  ",
						eligbleAmt, maxBenefitAmt, working.getPresentedPercentage(), working.getPresentedAmt());
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},percentageAlocated={},presentedAmt={},presentedPercentage={}", working.getBenefitCode(), eligbleAmt, allocatedPercentage,
					working.getPresentedAmt(), working.getPresentedPercentage());
		}
		// set elegibleAmt 
		working.setEligibleAmt(eligbleAmt);
		working.setPercentageAllocated(allocatedPercentage);
	}

	@Override
	public boolean isPresentedPercentageRequired() {
		return true;
	}
	
	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}
}
