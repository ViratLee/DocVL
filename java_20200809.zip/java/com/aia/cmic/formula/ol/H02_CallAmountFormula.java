package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseSubCode;
import com.aia.cmic.util.TransactionLogUtil.TransactionLogInfo;

@BenifitCodeFormula("H02")
public class H02_CallAmountFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H02_CallAmountFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing {} Benefit Code", working.getBenefitCode());
		}

		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousClaimAllocation.getAmountAllocated(),
					working.getPreviousAllocation().getAmountAllocated(), previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}

		/*
		 * Bug Fix UAT 04/07 Don't add up old amount.
		 */
		//previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();
		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();

		/**
		 * Bug Fix - UAT 2017/04/04 HSJR don't have maxBenefitAmt for H02/H03
		 */

		Boolean isHSJR = ProductCode.HSJR.toString().equals(working.getProductCode());

		BigDecimal eligbleAmt = working.getPresentedAmt();
		Integer daysAllocated = working.getPresentedNosOfDays();

		if (!isHSJR) {

			/**
			 * Commented : 2017/02/23(onsite) Restore old logic PlanBenefit.ChangeDate >  Hospitalization.Date - Wanyupa
			 */
			if (planBenefit.getChangeDate() != null && claimCanonical.getClaim().getHospitalizationDate() != null) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
					Integer planBenefitChangeDate = Integer.parseInt(sdf.format(planBenefit.getChangeDate()));
					Integer hospitalizationDate = Integer.parseInt(sdf.format(claimCanonical.getClaim().getHospitalizationDate()));

					if (planBenefitChangeDate > hospitalizationDate) {
						maxDaysAllocated = planBenefit.getMaxNoOfDaysHist();
						if (logger.isDebugEnabled()) {
							logger.debug("Found PlanBenefit.ChangeDate={} > Claim.HospitalizationDate={}, Setting MaxNoOfDay={} from PlanBenefit.MaxNoOfDaysHist", planBenefitChangeDate,
									hospitalizationDate, maxDaysAllocated);
						}
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().info("-----");
							working.getCalculationLogger().info("Found PlanBenefit.ChangeDate={} > Claim.HospitalizationDate={}, Setting MaxNoOfDay={} from PlanBenefit.MaxNoOfDaysHist",
									planBenefitChangeDate, hospitalizationDate, maxDaysAllocated);
							working.getCalculationLogger().info("-----");
						}
					}
				} catch (NumberFormatException e) {
					if (logger.isDebugEnabled()) {
						logger.warn("Skipping PlanBenefit.ChangeDate > Claim.HospitalizationDate due to: " + e.getMessage());
					}
				}
			}

			// days allocated
			daysAllocated = working.getPresentedNosOfDays();
			if (daysAllocated + working.getPreviousAllocation().getDaysAllocated() > maxDaysAllocated) {
				daysAllocated = maxDaysAllocated - working.getPreviousAllocation().getDaysAllocated();
			}

			daysAllocated = Math.max(daysAllocated, 0);
			if (daysAllocated == 0) {
				// check if there is remaining days
				daysAllocated = Math.max(0, maxDaysAllocated - working.getPreviousAllocation().getDaysAllocated());
			}

			// amount allocated - refer to the archive version        
			BigDecimal amountAllocated = maxBenefitAmt;

			// eligible Amount
			eligbleAmt = amountAllocated.multiply(new BigDecimal(daysAllocated));
		} else {
				maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, claimPolicyPlan.getRateAge(),
						claimPolicyPlan.getPlanIssueDt(), working);
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},NoOfDaysPresented={},PresentedAmt={},MaxNoOfDay={},MaxBenefitAmt={},DaysAllocated={}",
					working.getProductCode(), working.getPresentedNosOfDays(), working.getPresentedAmt(), maxDaysAllocated, maxBenefitAmt, daysAllocated);
		}

		if (eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {
			if (!isHSJR) {
				// previously reimbursed amt on the current benefit code/plan
				BigDecimal previousAllocation = previousClaimAllocation.getAmountAllocated();
				eligbleAmt = eligbleAmt.subtract(previousAllocation);
				if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
					eligbleAmt = BigDecimal.ZERO;
				}

				/*
				if (working.getPresentedAmt().subtract(previousAllocation).compareTo(eligbleAmt) > 0) {
					// presented amount is greater than currently total allocated amt for this benefitcode/service Cat
					BigDecimal deductedAmt = working.getPresentedAmt().subtract(previousAllocation);
					eligbleAmt = eligbleAmt.min(deductedAmt);
				} */

				// last adjustment
				if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
					// make sure that eligbleAmt will not be change when presented amt is re-calculated
					eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
				}
				if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
					eligbleAmt = BigDecimal.ZERO;
					daysAllocated = 0;
				}

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug(
							"Formula: EligbleAmt({}) =  Min( Min( MaxNoOfDay-PreviousUsedDays={},NoOfDaysPresented) x MaxBenefitAmt - PreviousUsedAmount={}  , PresentedAmt={})", eligbleAmt,
							working.getPreviousAllocation().getDaysAllocated(), previousClaimAllocation.getAmountAllocated(), working.getPresentedAmt());
				}
			}

			// further  adjustment by maxconfinement
			if (working.getProductSpecificConfinementAdjuster() != null) {
				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
				}
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
				}
				eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
			}

			if (working.isCalculationLoggerEnabled() && isHSJR) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( MaxConfinementAmt - PreviousUsedAmt , PresentedAmt={})", eligbleAmt, working.getPresentedAmt());
			}

		} else {
			daysAllocated = 0;
			if (working.isCalculationLoggerEnabled()) {
				if (isHSJR) {
					working.getCalculationLogger().debug("Formula: EligbleAmt({}) =  Min( MaxConfinementAmt - PreviousUsedAmt , PresentedAmt={})", eligbleAmt, working.getPresentedAmt());
				} else {
					working.getCalculationLogger().debug(
							"Formula: EligbleAmt({}) =  Min( Min( MaxNoOfDay-PreviousUsedDays={},NoOfDaysPresented) x MaxBenefitAmt - PreviousUsedAmount={}  , PresentedAmt={})", eligbleAmt,
							working.getPreviousAllocation().getDaysAllocated(), previousClaimAllocation.getAmountAllocated(), working.getPresentedAmt());
				}
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedAmt={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated,
					working.getPresentedAmt(), working.getPresentedNosOfDays());
		}
		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);
		// commented for now
				/*
		//TransactionLogging
		if(maxDaysAllocated - ( daysAllocated  + working.getPreviousAllocation().getDaysAllocated() ) <= 1) {
			TransactionLogInfo logInfo = new TransactionLogInfo() ;
			logInfo.setResponseCode(ResponseCode.C005);
			// warn
			// ""Policy %s / Plan %s / Product Code %s / BenefitCode %s - Limit: %d days, Previous paid : %d days, Previous paid Amt: %s, Presented: %d days, Presented Amt: %s, Eligible: %d days"
			logInfo.setParameters(
			Arrays.asList(ResponseSubCode.A, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxDaysAllocated, working.getPreviousAllocation().getDaysAllocated(),previousClaimAllocation.getAmountAllocated(), 
					working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated ).toArray() ) ;
		} 
		// info
		// ""Policy %s / Plan %s / Product Code %s / BenefitCode %s - Limit: %d days, Previous paid : %d days, Previous paid Amt: %s, Presented: %d days, Presented Amt: %s, Eligible: %d days"
		TransactionLogInfo logInfo = new TransactionLogInfo() ;
		logInfo.setResponseCode(ResponseCode.C003);
		logInfo.setParameters(
		Arrays.asList(ResponseSubCode.H, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxDaysAllocated, working.getPreviousAllocation().getDaysAllocated(),previousClaimAllocation.getAmountAllocated(), 
				working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated ).toArray() ) ;
		*/

	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
