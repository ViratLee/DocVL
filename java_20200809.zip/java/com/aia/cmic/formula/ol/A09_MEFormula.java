package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.ClaimHelper;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.SubmissionType;

/**
 * 2017/01/11 - Use ClaimPolicyPlan.sumAssured instead of PlanBenefit.MaxBenefitAmt(onsite/Wanyupa)
 * @author asnpat4
 *
 */
@BenifitCodeFormula("A09")
public class A09_MEFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(A09_MEFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;
	
	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
    ClaimHelper claimHelper;
	

	
	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) claimPolicyPlan.getNoOfUnit());
		List<String> parameterNames = Arrays.asList("NoOfUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// amountAllocated
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		//BigDecimal valuePerUnit = BigDecimal.valueOf(100);
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		PreviousClaimPaymentAllocation previousCurrentAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationForPA(working.getBenefitCode(), working.getPlanName(),working.getPolicyNo(), working);
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousCurrentAllocation.getAmountAllocated(),
					previousCurrentAllocationHelper.getPreviousAllocationForPA(working.getBenefitCode(),working, planRepository).getAmountAllocated(), previousCurrentAllocation.getAmountAllocated().add(previousCurrentAllocationHelper.
					getPreviousAllocationForPA(working.getBenefitCode(),working, planRepository).getAmountAllocated()));
		}
		previousCurrentAllocation.setAmountAllocated(previousCurrentAllocation.getAmountAllocated().add(previousCurrentAllocationHelper.getPreviousAllocationForPA(working.getBenefitCode(),working, planRepository).getAmountAllocated()));
		
		/*  po_ing_value_unit.value_per_uni* ld_no_of_unit - po_allocwsk_allocate_worksheet.prev_amount_reimbursed */
		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit).subtract(previousCurrentAllocation.getAmountAllocated()).max(BigDecimal.ZERO);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},SubmissionType={},PresentedAmt={},NoOfUnit={}", working.getProductCode(),
					claimCanonical.getClaim().getSubmissionType(), working.getPresentedAmt(), nosOfUnit);

		}
		Boolean isCashless = SubmissionType.Cashless.toString().equalsIgnoreCase(claimCanonical.getClaim().getSubmissionType());
		Boolean isCardLimitUsed = false;
		BigDecimal sumAssured = BigDecimal.ZERO;
		BigDecimal previousCareCardReimbursed = BigDecimal.ZERO;
		
		
		if (isCashless) {
			// check required parameters for calculation
			sumAssured = claimPolicyPlan.getSumAssured();

			requiredParameters = Arrays.asList((Object) sumAssured);
			parameterNames = Arrays.asList("SumAssured");
			ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

			previousCareCardReimbursed = claimPaymentDetailRepository.findTotalEligbleAmtByCareCardIndBenefitCode(working.getClaimNo(), working.getOccurence(), working.getPlanName(),working.getPolicyNo(), working.getBenefitCode());

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("CashLess=TRUE");
				working.getCalculationLogger().debug("Additional Calculation Parameters: SumAssured={},PreviousCareCardReimbursed={}", sumAssured, previousCareCardReimbursed);
			}
			if (amountAllocated.add(previousCareCardReimbursed).compareTo(sumAssured) > 0) {
				amountAllocated = sumAssured.subtract(previousCareCardReimbursed);
				isCardLimitUsed = true;
			}

		}

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated;

		// last adjustment
		if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
			// make sure that eligbleAmt will not be change when presented amt is re-calculated
			eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
		}
		if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligbleAmt = BigDecimal.ZERO;
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);

		if (working.isCalculationLoggerEnabled()) {
			if (isCashless && isCardLimitUsed) {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min( PresentedAmt={}, SumAssured({}) - PreviousCareCardReimbursed({}) )  ", eligbleAmt, working.getPresentedAmt(),sumAssured,previousCareCardReimbursed);
			} else {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min( PresentedAmt={}, NoOfUnit={} * ValuePerUnit={} - PreviousUsedAmt={} ) ", eligbleAmt, working.getPresentedAmt(),
						nosOfUnit, valuePerUnit, previousCurrentAllocation.getAmountAllocated());
			}
		}
		
		/**
		 *  Change request 2019/07/01 -Wanyupa
		 * IF product code = 'P92216' and  product count < 2 
				Find Policy benefit amount Per Year (maxYearAmt)
				Find policy_furthur = get from query.
				set amount_allocated =  maxYearAmt - (policy_furthur + current paid amt  + PresentedAmt)  
		*/
       
		List<Plan> plans =  planRepository.findPlanByPlanCode("P92216", -1, -1);
		Long planId = 0L;
		if (plans.size() > 0) {
			Plan plan = plans.get(0);
			planId = plan.getPlanId();
		}	
		if (planId.equals(working.getPlanId())) {
			Set<String> productCountSet = working.getProductCountSet();
			boolean exist = productCountSet.contains(working.getPolicyNo()) ? true : false;
			if((productCountSet != null && productCountSet.size() < 2) || exist ){
				ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoOccurencePolicyNo(claimCanonical.getClaim().getClaimNo(), claimCanonical.getClaim().getOccurrence(), working.getPolicyNo() ,working.getBusinessLine(), claimCanonical);
				Date earlyYearPaidToDate = claimHelper.findBeforeOneYearOfPaidToDate(claimPolicy);
				BigDecimal eligibleAmtPolicyYear = claimPaymentDetailRepository.findEligibleAmountByPolicyInPerYear(working.getPolicyNo(), planId ,working.getPlanCoverageNo(), "A09" ,earlyYearPaidToDate, claimPolicy.getPaidToDt() );
				PlanBenefit planBenefit = planBenefitRepository.findPlanBenefitByPlanIdBenefitCode(planId, "A09");
				BigDecimal maxYearAmt = planBenefit.getMaxYearAmt();
				PreviousClaimPaymentAllocation prevClmPaymentAllocate = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo("A09", planId,working.getPlanCoverageNo(), working.getPolicyNo(), working);
				BigDecimal currentUsedClaimAllocate = prevClmPaymentAllocate.getAmountAllocated();
				BigDecimal paidAllocatedAmt = eligibleAmtPolicyYear.add(currentUsedClaimAllocate).add(working.getPresentedAmt());
				if(paidAllocatedAmt.compareTo(maxYearAmt) > 0) {
					eligbleAmt = maxYearAmt.subtract(eligibleAmtPolicyYear.add(currentUsedClaimAllocate));
				}else{
					eligbleAmt = working.getPresentedAmt();
				}
				if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
					eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
				}
				working.setEligibleAmt(eligbleAmt);
				if(working.getEligibleAmt().compareTo(BigDecimal.ZERO)> 0){
				    productCountSet.add(working.getPolicyNo());
				}
			}else{
				working.setEligibleAmt(BigDecimal.ZERO);
				working.getCalculationLogger().debug("ProductCode={}, planid {} is maximun 2 policys", working.getProductCode(), working.getPlanId());
			}
	    		working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min( PresentedAmt={}, NoOfUnit={} * ValuePerUnit={} - PreviousUsedAmt={} ) ", eligbleAmt, working.getPresentedAmt(),
							nosOfUnit, valuePerUnit, previousCurrentAllocation.getAmountAllocated());
		}
		
	
	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

}
