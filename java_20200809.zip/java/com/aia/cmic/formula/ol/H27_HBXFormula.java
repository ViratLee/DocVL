package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.model.PreviousHBPHospitalization;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.HBPType;
import com.aia.cmic.util.ClaimCalculationEnum.IPDTreatmentType;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.SubmissionType;

@BenifitCodeFormula("H27")
public class H27_HBXFormula extends OLBenefitCodeFormula {
	private static Logger logger = LoggerFactory.getLogger(H27_HBXFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {
		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
//		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
//				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		/*
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit(), working.getPresentedNosOfDays());
		List<String> parameterNames = Arrays.asList("MaxNoOfDay", "NoOfUnit", "ValuePerUnit", "PresentedNosOfDays");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");
		*/
		// no need to compute if the presented day == 0;
		/*
		if (working.getPresentedNosOfDays() == 0) {
			working.setAllocatedDay(0);
			working.setEligibleAmt(BigDecimal.ZERO);
		}
		*/
		//BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();

		// previousDaysAllocated
		Integer previousAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays() == null ? 0 : working.getPresentedNosOfDays();
		if (daysAllocated + previousAllocatedDays > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - previousAllocatedDays;
			daysAllocated = Math.max(daysAllocated, 0);
		}

		Integer hospitalInd = getHospitalIndByHBPType(claimCanonical.getClaim().getHbpType());
		// Changes in logic: use updated data dictionary mapping (-Wanyupa May 09,2017 email -offsite
		
		//Integer hospitalInd = !StringUtils.isEmpty(claimCanonical.getClaim().getHbpType()) && StringUtils.isNumeric(claimCanonical.getClaim().getHbpType()) ? new Integer(claimCanonical.getClaim().getHbpType()) : null;
		Integer moreValue = 1;
		// amountAllocated
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit).multiply(BigDecimal.valueOf(moreValue));
		
		// TODO: confinement day should be set from H17 if exists
		PreviousHBPHospitalization prevHBPHospitalization = claimPaymentDetailRepository.findPreviousHBAllocatedDays(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(),
				planBenefit.getConfinementDay());

		Integer fixBenefitx3Day = 365;
		Integer fixMaxHospitalDay = 1260;

		if (daysAllocated > 0 && prevHBPHospitalization.getPrevHBPGx3Day() >= fixBenefitx3Day) {
			daysAllocated = fixBenefitx3Day - prevHBPHospitalization.getPrevHBPGx3Day();
		}

		if (daysAllocated > 0 && prevHBPHospitalization.getHospitalizationDays() >= fixMaxHospitalDay) {
			daysAllocated = fixMaxHospitalDay - prevHBPHospitalization.getHospitalizationDays();
		}

		if (daysAllocated <= 0) {
			daysAllocated = 0;
		}

		BigDecimal eligibleAmt = BigDecimal.ZERO;
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug(
					"Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfUnit={},ValuePerUnit={},RateAge={},HbpType={},HospitalInd={},SUM(H11PreviousDaysAllocated with HbpType=1 + H17PreviousDaysAllocated)={},SUM(H11PreviousDaysAllocated + H17PreviousDaysAllocated)={},DaysAllocated={}",
					working.getProductCode(), maxDaysAllocated, nosOfUnit, valuePerUnit, claimPolicyPlan.getRateAge(), claimCanonical.getClaim().getHbpType(),hospitalInd,
					prevHBPHospitalization.getPrevHBPGx3Day(), prevHBPHospitalization.getHospitalizationDays(), daysAllocated);

//			if (isLifeCare) {
//				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxNoOfDay-PreviousDaysAllocated={},NoOfDaysPresented) x ValuePerUnit", eligibleAmt, previousAllocatedDays);
//			} else {
//				working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxNoOfDay-PreviousDaysAllocated={},NoOfDaysPresented) x NoOfUnit x ValuePerUnit x HospitalInd_Multiplier={}", eligibleAmt,
//						previousAllocatedDays, moreValue);
//			}
			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(MaxNoOfDay-PreviousDaysAllocated={},NoOfDaysPresented) x NoOfUnit x ValuePerUnit x HospitalInd_Multiplier={}", eligibleAmt,
					previousAllocatedDays, moreValue);

		}

//		if (eligibleAmt.compareTo(BigDecimal.ZERO) > 0) {
//			if (working.getProductSpecificConfinementAdjuster() != null && ProductCode.WLGM.toString().equalsIgnoreCase(working.getProductCode())) {
//				if (working.isCalculationLoggerEnabled()) {
//					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
//				}
//				// further  adjustment by maxconfinement
//				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
//					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
//				}
//				eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, maxConfinementAmt);
//				if (SubmissionType.Cashless.toString().equalsIgnoreCase(claimCanonical.getClaim().getSubmissionType())) {
//					daysAllocated = 0;
//				}
//			}
//
//			if (eligibleAmt.compareTo(BigDecimal.ZERO) <= 0) {
//				eligibleAmt = BigDecimal.ZERO;
//				daysAllocated = 0;
//			}
//		} else {
//			daysAllocated = 0;
//		}
		///////////////////////////////
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getPreviousAllocation(working.getBenefitCode(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working);
		BigDecimal priviouConfinement = previousClaimAllocation.getAmountAllocated();
		logger.debug("priviouConfinement {}", priviouConfinement);
		if(priviouConfinement.compareTo(BigDecimal.ZERO) <= 0){
			if(Arrays.asList(IPDTreatmentType.TYPE_1.toString(),IPDTreatmentType.TYPE_2.toString()).contains(claimCanonical.getClaim().getTreatmentType())
					&& (CollectionUtils.isNotEmpty(claimCanonical.getClaimCriticalIllnesss()))) //
			{
				eligibleAmt = amountAllocated.multiply(new BigDecimal(25));
			}
		}
		////////////////////////////
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligibleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		working.setAllocatedDay(daysAllocated);
		//////////////////////////////
		
		
	}
	
	/*
	 * "Reference common object
	(0 = blank  [Hospital type benefit =blank]
	1 = R&B and/or ICU  [Hospital type benefit = 4]
	2 = Dx: CA, Ac.Heart Attack, CABG, Stroke [Hospital type benefit = 1]
	3 = IPD surgery  [Hospital type benefit = 3]
	4 = R&B and/or ICU  [Hospital type benefit = 2]
	5 = Not Applicable  [Hospital type benefit = 5])	
	 * 
	 */
	private Integer getHospitalIndByHBPType(String hbpType) {
		if (StringUtils.isEmpty(hbpType)) {
			return null ;
		}
		if (StringUtils.isNumeric(hbpType)) {
			Integer ONE = 1;
			Integer TWO = 2;
			Integer THREE = 3;
			Integer FOUR = 4;
			
			if (new Integer(hbpType).equals(ONE)) {
				return 4;
			}
			if (new Integer(hbpType).equals(TWO)) {
				return 1;
			}
			if (new Integer(hbpType).equals(THREE)) {
				return 3;
			}
			if (new Integer(hbpType).equals(FOUR)) {
				return 2;
			}
			
		}
		return null ;
	}

}
