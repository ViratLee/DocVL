package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("A08,A13")
public class A0813_WIWCFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(A0813_WIWCFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit(), working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(),
				planBenefit.getNoOfDays());
		List<String> parameterNames = Arrays.asList("NoOfUnit", "ValuePerUnit", "PresentedNosOfDays", "MaxNoOfDay", "NoOfDays");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		Integer nosOfDays = planBenefit.getNoOfDays();

		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays();
		if (daysAllocated > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated;
		}

		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		// eligible Amount
		BigDecimal eligbleAmt = valuePerUnit.multiply((nosOfUnit.multiply(BigDecimal.valueOf(daysAllocated)))).setScale(2, RoundingMode.HALF_UP).divide(BigDecimal.valueOf(nosOfDays),
				RoundingMode.HALF_UP);

		//		// last adjustment
		//		if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
		//			// make sure that eligbleAmt will not be change when presented amt is re-calculated
		//			eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
		//		}
		if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligbleAmt = BigDecimal.ZERO;
			daysAllocated = 0;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfDays={},NoOfUnit={},ValuePerUnit={}", working.getProductCode(), maxDaysAllocated, nosOfDays,
					nosOfUnit, valuePerUnit);
			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = ValuePerUnit x NoOfUnit x Min(daysPresented={},MaxNoOfDay) / NoOfDays", eligbleAmt, working.getPresentedNosOfDays());

		}

	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}
}
