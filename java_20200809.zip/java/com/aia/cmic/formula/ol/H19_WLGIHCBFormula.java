package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.ClaimPolicy;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPolicyRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H19")
public class H19_WLGIHCBFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H19_WLGIHCBFormula.class);

	@Autowired
	ClaimPolicyRepository claimPolicyRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {
		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/
		/****
		 * Refactored 2017/05/02 Use ClaimPolicy.PlanBasicSumAssured as ceiling amount
		 ***/
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		List<ClaimPolicy> claimPolicies = claimPolicyRepository.findClaimPolicyByClaimNoAndPolicyNoAndOccurrenceAndCompanyId(working.getClaimNo(), working.getPolicyNo(), working.getOccurence(),
				working.getCompanyId());

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit(), working.getPresentedNosOfDays(), claimPolicies);
		List<String> parameterNames = Arrays.asList("NoOfUnit", "ValuePerUnit", "PresentedNosOfDays", "ClaimPolicy(policyNo=" + working.getPolicyNo() + ")");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		ClaimPolicy claimPolicy = claimPolicies.get(0);

		// daysAllocated 
		Integer daysAllocated = working.getPresentedNosOfDays();

		BigDecimal maxBenefitAmt = claimPolicy.getPlanBasicSumAssured() != null ? claimPolicy.getPlanBasicSumAssured() : BigDecimal.ZERO;

		// default percentage
		BigDecimal percentage = BigDecimal.ONE;

		if (claimPolicyPlan.getPlanIssueDt() != null && (claimCanonical.getClaim().getHospitalizationDate() != null || claimCanonical.getClaim().getAccidentDt() != null)) {

			Date incidentDt = claimCanonical.getClaim().getHospitalizationDate();
			if (incidentDt == null) {
				incidentDt = claimCanonical.getClaim().getAccidentDt();
			}
			if (incidentDt != null) {
				Date planIssuedt = claimPolicyPlan.getPlanIssueDt();

				/*
				Calendar startCalendar = new GregorianCalendar();
				startCalendar.setTime(planIssuedt);
				Calendar endCalendar = new GregorianCalendar();
				endCalendar.setTime(incidentDt);
				*/

				Long planDays = TimeUnit.MILLISECONDS.toDays(planIssuedt.getTime());
				Long incidentDays = TimeUnit.MILLISECONDS.toDays(incidentDt.getTime());

				long diffYear = (incidentDays - planDays) / 365;
				if ((incidentDays - planDays) % 365 > 0) {
					// excess days will be treated + 1 year
					diffYear++;
				}

				//int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);

				if (diffYear <= 1) {
					percentage = BigDecimal.valueOf(0.1);
				} else if (diffYear == 2) {
					percentage = BigDecimal.valueOf(0.1);
				} else if (diffYear == 3) {
					percentage = BigDecimal.valueOf(0.1);
				} else if (diffYear == 4) {
					percentage = BigDecimal.valueOf(0.2);
				} else if (diffYear == 5) {
					percentage = BigDecimal.valueOf(0.3);
				} else if (diffYear == 6) {
					percentage = BigDecimal.valueOf(0.4);
				} else {
					percentage = BigDecimal.valueOf(0.5);
				}
			}

		}
		maxBenefitAmt = maxBenefitAmt.multiply(percentage).setScale(2, RoundingMode.HALF_UP);
		// amount allocated
		BigDecimal amountAllocated = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit()).multiply(claimPolicyPlan.getNoOfUnit()).multiply(BigDecimal.valueOf(daysAllocated));
		BigDecimal prevReimbursed = BigDecimal.ZERO;

		if (claimPolicyPlan.getPlanIssueDt() != null && (claimCanonical.getClaim().getHospitalizationDate() != null || claimCanonical.getClaim().getAccidentDt() != null)) {
			/*
			 * finds policyNo,plan with H19. Then, check if these policyNo,plan is used with a policy year. If used, then sum up all reimbursedAmt from this policy,plan and return the total amount
			 */
			Date startDate = previousCurrentAllocationHelper.findStartDateByIncident(claimPolicyPlan.getPlanIssueDt(), claimCanonical.getClaim().getAccidentDt(),
					claimCanonical.getClaim().getHospitalizationDate());

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Previous H19 Criteria: policyNo={},planId={},planIssueDt={},accidentDt={},hospitalizationDt={}", claimPolicyPlan.getPolicyNo(),
						claimPolicyPlan.getPlanId(), claimPolicyPlan.getPlanIssueDt(), claimCanonical.getClaim().getAccidentDt(), claimCanonical.getClaim().getHospitalizationDate());
			}
			if (startDate != null) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(startDate);
				cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) + 1);
				Date endDate = cal.getTime();

				prevReimbursed = claimPaymentDetailRepository.findTotalEligbleAmtByPlanPolicyPerYear(working.getPlanId(), working.getPolicyNo(), working.getBenefitCode(), startDate, endDate);

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Previous H19 Criteria: startDate={},endDate={}, PreviousReimbursed={}", startDate, endDate, prevReimbursed);
				}

			}
		}

		if (amountAllocated.add(prevReimbursed).compareTo(maxBenefitAmt) > 0)

		{
			amountAllocated = maxBenefitAmt.subtract(prevReimbursed);
			amountAllocated = amountAllocated.max(BigDecimal.ZERO);
		}

		if (amountAllocated.compareTo(BigDecimal.ZERO) > 0)

		{
			// eligible Amount
			BigDecimal eligbleAmt = amountAllocated;
			eligbleAmt = eligbleAmt.max(BigDecimal.ZERO);

			// set elegibleAmt and
			working.setEligibleAmt(eligbleAmt);
			working.setAllocatedDay(daysAllocated);

		} else

		{
			working.setAllocatedDay(0);
			working.setEligibleAmt(BigDecimal.ZERO);
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},PresentedNoOfDays={},ValuePerUnit={},NoOfUnit={},DaysAllocated={}", working.getProductCode(),
					working.getPresentedNosOfDays(), claimPolicyPlan.getValuePerUnit(), claimPolicyPlan.getNoOfUnit(), daysAllocated);
			working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min( ValuePerUnit({}) x NoOfUnit({}) x DaysAllocated({}) , ( PlanBasicSumAssured({}) x Percentage({}) ) - UsedAmt({}) )",
					working.getEligibleAmt(), claimPolicyPlan.getValuePerUnit(), claimPolicyPlan.getNoOfUnit(), daysAllocated, claimPolicy.getPlanBasicSumAssured(), percentage, prevReimbursed);
		}

		if (logger.isDebugEnabled())

		{
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), working.getEligibleAmt(), working.getAllocatedDay(),
					working.getPresentedNosOfDays());
		}

	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
