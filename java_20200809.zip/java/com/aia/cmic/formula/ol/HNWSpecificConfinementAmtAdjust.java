package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.model.Claim;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimDeductDetailRepository;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.ClaimPolicyPlanRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimDeductStatus;
import com.aia.cmic.util.ClaimCalculationEnum.ClaimDeductSubmissionSource;

@Component("HNWSpecificConfinementAmtAdjust")
public class HNWSpecificConfinementAmtAdjust implements ProductConfinementAdjustable {

	private static Logger logger = LoggerFactory.getLogger(HNWSpecificConfinementAmtAdjust.class);
	@Autowired
	private PlanBenefitRepository planBenefitRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
	ClaimPolicyPlanRepository claimPolicyPlanRepository;
	
	@Autowired
	ClaimDeductDetailRepository claimDeductDetailRepository ;

	public HNWSpecificConfinementAmtAdjust() {}
	
	public HNWSpecificConfinementAmtAdjust(PlanBenefitRepository planBenefitRepository, ClaimPaymentDetailRepository claimPaymentDetailRepository) {
		this.claimPaymentDetailRepository = claimPaymentDetailRepository ;
		this.planBenefitRepository = planBenefitRepository ;
	}
	
	@Override
	public BigDecimal adjustEligibleAmtViaMaxConfinement(ClaimCanonical claimCanonical, PaymentAllocationTemp working, BigDecimal eligbleAmt, BigDecimal maxConfinementAmt) {

		if (logger.isDebugEnabled()) {
			logger.debug("HNW confinement executing..");

		}
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Before  adjustEligibleAmt Checking BenefitCode= {}, EligibleAmt={} vs MaxConfinementAmt={}",working.getBenefitCode(), eligbleAmt, maxConfinementAmt);
		}

		Date startDate = null ;
		Date endDate = new Date(System.currentTimeMillis()) ;
		
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		BigDecimal adjustedAmt = eligbleAmt;
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// yearly confinement
		BigDecimal maxYearAmt = planBenefit.getMaxYearAmtHNW() ;

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (logger.isDebugEnabled() && claimPolicyPlan == null) {
			logger.debug("Couldn't find ClaimPolicyPlan from canonical. {} yearly confinement adjustment will be ignored. ", working.getProductType());
		}
		if (claimPolicyPlan != null && claimPolicyPlan.getPlanIssueDt() != null && ( claimCanonical.getClaim().getFirstAdmitDt() != null  || claimCanonical.getClaim().getHospitalizationDate() != null )) {
			Claim claim = claimCanonical.getClaim() ;
			Date incidentDt =  claim.getHospitalizationDate() ;
			Date firstAdmitDt  = claim.getFirstAdmitDt() ;
			
			if(firstAdmitDt != null) {
				incidentDt = firstAdmitDt ;
			}
			
			// Get month/day of policy issueDt
			Date planIssueDt = claimPolicyPlan.getPlanIssueDt() ;
			if(planIssueDt != null && incidentDt != null) {
				
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("MMdd") ;
					SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy") ;
					SimpleDateFormat sdf3 = new SimpleDateFormat("MMddyyyy") ;
					if(working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("HNW PlanIssueDt - " + sdf3.format(planIssueDt) + " , Incident Date - " + sdf3.format(incidentDt)) ;
					}
					
					if( Integer.parseInt(sdf.format(planIssueDt)) <= Integer.parseInt(sdf.format(incidentDt))) {
						// case 1/2
						startDate = sdf3.parse(sdf.format(planIssueDt) + sdf2.format(incidentDt) ) ;
					} else {
						// case 3
						Calendar cal = Calendar.getInstance();
						cal.setTime(incidentDt);
						startDate = cal.getTime() ;
						startDate = DateUtils.addYears(startDate,  - 1) ;
						startDate = sdf3.parse(sdf.format(planIssueDt) + sdf2.format(startDate) ) ;
					}
					
					Calendar cal = Calendar.getInstance();
					cal.setTime(startDate);
					endDate = cal.getTime();

					endDate = DateUtils.addYears(endDate, 1) ;
					endDate = DateUtils.addDays(endDate, -1) ;
					startDate = DateUtils.truncate(startDate, Calendar.DAY_OF_MONTH) ;
					endDate = DateUtils.truncate(endDate, Calendar.DAY_OF_MONTH) ;
					
					//10/31/2019 Dino Keep policy year period 
					com.aia.cmic.entity.ClaimPolicyPlan updatePolicyYear=claimPolicyPlanRepository.findClaimPolicyPlanByClaimPolicyPlanId(claimPolicyPlan.getClaimPolicyPlanId());
					if (updatePolicyYear!=null) {
						updatePolicyYear.setPolicyYearFromDt(startDate);
						updatePolicyYear.setPolicyYearToDt(endDate);
						claimPolicyPlanRepository.updateClaimPolicyPlan(updatePolicyYear);
					}
					
					Boolean checkByBenefitShare = Arrays.asList(BenefitCode.H25.toString(), BenefitCode.H29.toString()).contains(working.getBenefitCode()) && StringUtils.isNotBlank(planBenefit.getBenefitShare()) ;
					Boolean checkByBenefitPolicyYear = planBenefit.getMaxYearAmt() != null && planBenefit.getMaxYearAmt().compareTo(BigDecimal.ZERO) > 0 ;
					
					if(checkByBenefitShare ||checkByBenefitPolicyYear ) {
						BigDecimal maxYearAmtShared = planBenefit.getMaxYearAmt() != null ? planBenefit.getMaxYearAmt() : BigDecimal.ZERO ;
						BigDecimal currentAllocatedAmt = BigDecimal.ZERO ;
						BigDecimal previousUsedAmt = BigDecimal.ZERO ;
						if(checkByBenefitShare) {
							currentAllocatedAmt = previousCurrentAllocationHelper.getCurrentShareBenefitAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),planBenefit.getBenefitShare()) ;
							List<String> sharedBenefitCodes = planBenefitRepository.findPlanBenefitByBenefitShare(working.getPlanId(), planBenefit.getBenefitShare()) ;
							previousUsedAmt = claimPaymentDetailRepository.findTotalEligbleAmtByPlanCoveragePerYearByBenefit(working.getPlanId(),
									working.getPlanCoverageNo(), working.getPolicyNo(),sharedBenefitCodes, startDate, endDate);
						} else {
							PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
									working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
							currentAllocatedAmt = previousClaimAllocation.getAmountAllocated() ;
							previousUsedAmt = claimPaymentDetailRepository.findTotalEligbleAmtByPlanCoveragePerYearByBenefit(working.getPlanId(),
									working.getPlanCoverageNo(), working.getPolicyNo(),Arrays.asList(working.getBenefitCode()), startDate, endDate);
						}
						
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("Check Coverage : {} - {} , By BenefitShare={}. Check by BenefitCode?={}" , sdf3.format(startDate) , sdf3.format(endDate),planBenefit.getBenefitShare(), checkByBenefitPolicyYear) ; ;
							working.getCalculationLogger().debug("Current Shared/Benefit Amt = {}", currentAllocatedAmt);
							working.getCalculationLogger().debug("Previous Shared/Benefit  Amt By Coverage={}", previousUsedAmt);
							working.getCalculationLogger().debug("PlanBenefit.MaxYearAmt={}", maxYearAmtShared);
						}
						if(adjustedAmt.add(previousUsedAmt).add(currentAllocatedAmt).compareTo(maxYearAmtShared)> 0) {
							adjustedAmt = maxYearAmtShared.subtract(currentAllocatedAmt.add(previousUsedAmt));
							adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("MaxYearAmt Limit Reached. EligibleAmt adusted to {}", adjustedAmt);
							}
						} else {
							// adjustedAmt should not be more than maxYearAmt
							adjustedAmt = adjustedAmt.min(maxYearAmtShared) ;
							adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("EligibleAmt is now {}, should not be higher than PlanBenefit.MaxYearAmt={}", adjustedAmt, maxYearAmtShared );
							}
							
						}
						
					}
					if(StringUtils.equals(BenefitCode.H29.toString(), working.getBenefitCode()) && planBenefit.getNoOfCall() != null) {
						Long previousVisit = claimPaymentDetailRepository.findTotalVisitByPlanCoveragePerYearByBenefit(working.getPlanId(),
								working.getPlanCoverageNo(), working.getPolicyNo(),Arrays.asList(BenefitCode.H29.toString()), startDate, endDate);
						// Check PT Call
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("Check No of Visit for Coverage : {} - {} , BenefitCode={},PlanId={},NoOfCall={},Total Visit={}, Claim.PTCall={}" , sdf3.format(startDate) , sdf3.format(endDate), working.getBenefitCode(), 
									working.getPlanId(),planBenefit.getNoOfCall(), previousVisit, claimCanonical.getClaim().getPtcall()) ;
						}

						Integer ptCall = claimCanonical.getClaim().getPtcall() != null ? claimCanonical.getClaim().getPtcall(): 0;
						working.setAllocatedDay(ptCall);

						Integer noOfCall = planBenefit.getNoOfCall() != null ? planBenefit.getNoOfCall() : 0;
						boolean isPTCallLimiteReached =  ptCall + previousVisit > noOfCall;
						if (isPTCallLimiteReached) {
							working.setAllocatedDay(0);
							adjustedAmt = BigDecimal.ZERO;
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger()
										.debug("Visit/Call Limit Reached. EligibleAmt adusted to {}", adjustedAmt);
								working.getCalculationLogger()
								.debug("PT Call ={} , Limit = {}, Previous used Call ={}", ptCall , noOfCall, previousVisit );
							}
							return adjustedAmt ;
						} 
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger()
									.debug("PT Call ={} is within Limit of {}, Previous used Call ={}", ptCall , noOfCall, previousVisit );
						}
						
					}
					
					if(adjustedAmt.compareTo(BigDecimal.ZERO) > 0) {
						BigDecimal amtConfinementYear = previousCurrentAllocationHelper.getTotalConfinementAmtPerYear(working.getPlanId(), working.getPolicyNo());
						BigDecimal previousAmtReimbursedYearOld = claimPaymentDetailRepository.findTotalEligbleAmtByPlanCoveragePerYearAllBenefit(working.getPlanId(),
								working.getPlanCoverageNo(), working.getPolicyNo(), startDate, endDate);
						
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("Checking Used Amt on Coverage : {} - {}" , sdf3.format(startDate) , sdf3.format(endDate)) ;
							working.getCalculationLogger().debug("Current Total Used Amt Per Year={}", amtConfinementYear);
							working.getCalculationLogger().debug("Old Total Used Amt Per Year={}", previousAmtReimbursedYearOld);
							working.getCalculationLogger().debug("PlanBenefit.MaxYearAmtHNW={}", maxYearAmt);
						}
	
						if(working.getCalculationLogger().isDebugEnabled()) {
							working.getCalculationLogger().debug("Formula: EligbleAmt({}) = Min(PresentedAmt={},RemainAmtPolicyYear={})", adjustedAmt,working.getPresentedAmt(),maxYearAmt.subtract(amtConfinementYear.add(previousAmtReimbursedYearOld)) );
						}
						
						if (adjustedAmt.add(amtConfinementYear).add(previousAmtReimbursedYearOld).compareTo(maxYearAmt) > 0) {
							adjustedAmt = maxYearAmt.subtract(amtConfinementYear.add(previousAmtReimbursedYearOld));
							adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("Max Coverage Amt Reached.EligibleAmt adusted to {}", adjustedAmt);
							}
							if(StringUtils.equals(BenefitCode.H29.toString(), working.getBenefitCode()) && adjustedAmt.compareTo(BigDecimal.ZERO) == 0) {
								// reset any day allocation
								working.setAllocatedDay(0);
							}
						}
					}
				} catch (NumberFormatException e) {
//					e.printStackTrace();
				} catch (ParseException e) {
//					e.printStackTrace();
				}
			}
			
			
		} else {
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug(">>> Can't find incident date from Claim.HospitalizatonDate = {}, Claim.FirstAdmitDt ={}", claimCanonical.getClaim().getHospitalizationDate(), claimCanonical.getClaim().getFirstAdmitDt());
			}

		}
			
		// update confinement amt
		previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
		if(StringUtils.isNotBlank(planBenefit.getBenefitShare())) {
			previousCurrentAllocationHelper.setCurrentShareBenefitAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),planBenefit.getBenefitShare() ,adjustedAmt);
		}
		previousCurrentAllocationHelper.setTotalConfinemeAmtPerYear(working.getPlanId(), working.getPolicyNo(), adjustedAmt);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("After  adjustEligibleAmt Checking BenefitCode= {}, EligibleAmt={} vs MaxConfinementAmt={}",working.getBenefitCode(), eligbleAmt, maxConfinementAmt);
		}
		
		// 2020/05/08 Check if other partner insurance already paid for this benefit
		if(working.isPlanHNWDeduct())  {
			
			// record eligible elibleAmt
			working.setOrigHNWEligibleAmt(adjustedAmt);
						
			// check total deduction against max policy year
			BigDecimal hnwMaxYearAmt = (BigDecimal) ObjectUtils.defaultIfNull(planBenefit.getMaxYearAmt(), planBenefit.getMaxYearAmtHNW()) ;
			BigDecimal previousDeduct = claimDeductDetailRepository.findDeductAmtByPolicyBenefit(working.getPolicyNo(),startDate,endDate, claimCanonical.getClaim().getClaimNo(), 
					claimCanonical.getClaim().getOccurrence(), working.getBenefitCode());
            BigDecimal maxBenefitAmt = (BigDecimal) ObjectUtils.defaultIfNull(planBenefit.getMaxBenefitAmt(),BigDecimal.ZERO) ;
            
			adjustedAmt = adjustedAmt.min(hnwMaxYearAmt.subtract(previousDeduct)).max(BigDecimal.ZERO) ;
			if(working.getCalculationLogger().isDebugEnabled()) {
				working.getCalculationLogger().debug("HNW >> remove previous deductions from max policy year={}, previous deductions={},new EligibleAmt={}", hnwMaxYearAmt, previousDeduct, adjustedAmt ) ;
			}
			
			if(adjustedAmt.compareTo(BigDecimal.ZERO) <= 0) {
				if(working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("HNW >> Found Settled DeductAmt={} already exceed benefit limit per year of {}, Setting EligibleAmt =0 ", previousDeduct, hnwMaxYearAmt ) ;
					working.setAllocatedDay(0) ;
					return BigDecimal.ZERO ;
				}
			}
			
			// Only deductfrom currentParnerPaid if H01,H25,H28,H30,H31,H32 - Wanyupa 2020/05/13
			Boolean isDeductible = Arrays.asList(BenefitCode.H01.toString(),BenefitCode.H25.toString(),BenefitCode.H28.toString(),BenefitCode.H30.toString(),
					BenefitCode.H31.toString(),BenefitCode.H32.toString()).contains(working.getBenefitCode()) ;
			// check current
			if(isDeductible) {
				
			   // Get current deduction from other partners OT/CS
	            List<String> paidBenefits = Arrays.asList(working.getBenefitCode()) ;
				BigDecimal currentPartnerPaid = claimDeductDetailRepository.findAmtDeductFromPartneronClaimOccur(claimCanonical.getClaim().getClaimNo(), claimCanonical.getClaim().getOccurrence(),working.getPolicyNo(),Arrays.asList(ClaimDeductSubmissionSource.OT.toString(),ClaimDeductSubmissionSource.CS.toString()), 
						ClaimDeductStatus.INPROGRESS.getValue(), paidBenefits) ;
				if(working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("HNW >> Found Other Partner Insurance paid amt={} for this benefit={}. Will deduct to eligbleAmt. EligibleAmt is now ={} ", currentPartnerPaid, working.getBenefitCode(),adjustedAmt ) ;
				}
				
				// Current calculation with HS/ME allocation
				BigDecimal hsDeductible = previousCurrentAllocationHelper.getOtherHSPolicyDeductions(working) ;
				
				// remove allocation from other HS benefit.
				if( StringUtils.equals(BenefitCode.H01.toString(), working.getBenefitCode())) {
					Integer nosOfDays = (Integer) ObjectUtils.defaultIfNull(working.getAllocatedDay(), 0) ;
					// get deduct days from OT/CS
					Integer maxNoOfDays = planBenefit.getMaxNoOfDay() ;
					Long h01DeductDays = claimDeductDetailRepository.findH01DeductDays(working.getPolicyNo(), startDate, endDate, claimCanonical.getClaim().getClaimNo(), claimCanonical.getClaim().getOccurrence()) ;
					nosOfDays = Math.min(nosOfDays, maxNoOfDays-BigDecimal.valueOf(h01DeductDays).intValue()) ;
					
					working.setAllocatedDay(nosOfDays);
					if(working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("HNW >> Recalculate H01 deduct days from OT/CS={} ,maxNoOfDays{}. current dayAllocated ={} ", h01DeductDays, maxNoOfDays,nosOfDays ) ;
					}
					
					if(nosOfDays == 0) {
						return BigDecimal.ZERO ;
					}
					
					maxBenefitAmt = maxBenefitAmt.multiply(BigDecimal.valueOf(nosOfDays)) ;
					BigDecimal minDeductibleAmt = working.getOrigHNWEligibleAmt().add(currentPartnerPaid).add(hsDeductible) ;
					// new requirement 
					if(minDeductibleAmt.compareTo(maxBenefitAmt) <= 0) {
						if(working.getCalculationLogger().isDebugEnabled()) {
							working.getCalculationLogger().debug("HNW >> Total current OT/CS and HS Paid amount={} is less than max amt per day={} , EligibleAmt will be  {} ", minDeductibleAmt, maxBenefitAmt, working.getOrigHNWEligibleAmt().min(maxBenefitAmt) ) ;
						}
						return working.getOrigHNWEligibleAmt().min(maxBenefitAmt) ;
					}
					
					adjustedAmt = adjustedAmt.min(maxBenefitAmt.subtract(hsDeductible.add(currentPartnerPaid))).max(BigDecimal.ZERO) ;
					if(working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("HNW >> Recalculate H01 Eligible Amt ={}, maxBenefitAmt={}, OtherHSPaid={}, OtherPartnersPaid={} ", adjustedAmt, maxBenefitAmt, hsDeductible, currentPartnerPaid ) ;
					}
					
					return adjustedAmt ;
					
				}
				// previous deduct already contains currentPartnerPaid
				BigDecimal minDeductibleAmt = working.getOrigHNWEligibleAmt().add(hsDeductible).add(previousDeduct) ;
				if(minDeductibleAmt.compareTo(hnwMaxYearAmt) <= 0) {
					if(working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("HNW >> Total current OT/CS and HS Paid amount={} is less than max amt per year={} , EligibleAmt will be  ", minDeductibleAmt, hnwMaxYearAmt, working.getOrigHNWEligibleAmt() ) ;
					}
					return working.getOrigHNWEligibleAmt() ;
				}
				
				if(hsDeductible.compareTo(BigDecimal.ZERO) > 0) {
					
					if(maxBenefitAmt.compareTo(BigDecimal.ZERO) > 0) {
						adjustedAmt = adjustedAmt.subtract(hsDeductible) ;
						adjustedAmt = adjustedAmt.min(maxBenefitAmt.subtract(hsDeductible.add(previousDeduct))).max(BigDecimal.ZERO) ;
						if(working.getCalculationLogger().isDebugEnabled()) {
							working.getCalculationLogger().debug("HNW >> Found current HS/ME policies paid amt={} for this benefit={}. Will deduct to eligbleAmt. maxBenefitAmt={}, EligibleAmt is now ={} ", hsDeductible, working.getBenefitCode(),maxBenefitAmt, adjustedAmt ) ;
						}
					} else {
						adjustedAmt = adjustedAmt.subtract(hsDeductible).max(BigDecimal.ZERO) ;
						if(working.getCalculationLogger().isDebugEnabled()) {
							working.getCalculationLogger().debug("HNW >> Found current HS/ME policies paid amt={} for this benefit={}. Will deduct to eligbleAmt. Not using maxBenefitAmt={}, EligibleAmt is now ={} ", hsDeductible, working.getBenefitCode(),maxBenefitAmt, adjustedAmt ) ;
						}
								
					}
				} 
			}
		}
		
		return adjustedAmt;
	}

	
}
