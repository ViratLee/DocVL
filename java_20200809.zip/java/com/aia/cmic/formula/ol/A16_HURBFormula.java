package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;

@BenifitCodeFormula("A16")
public class A16_HURBFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(A16_HURBFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "NoOfUnit", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();

		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		// amount allocated
		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit);

		/**
		 * Commented : 2017/02/23(onsite) Restore old logic PlanBenefit.ChangeDate >  Hospitalization.Date - Wanyupa
		 */
		if (planBenefit.getChangeDate() != null && claimCanonical.getClaim().getHospitalizationDate() != null) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Integer planBenefitChangeDate = Integer.parseInt(sdf.format(planBenefit.getChangeDate()));
				Integer hospitalizationDate = Integer.parseInt(sdf.format(claimCanonical.getClaim().getHospitalizationDate()));
				
				if (planBenefitChangeDate > hospitalizationDate ) {
					maxDaysAllocated = planBenefit.getMaxNoOfDaysHist();
					if (logger.isDebugEnabled()) {
						logger.debug("Found PlanBenefit.ChangeDate={} > Claim.HospitalizationDate={}, Setting MaxNoOfDay={} from PlanBenefit.MaxNoOfDaysHist", 
								planBenefitChangeDate,hospitalizationDate, maxDaysAllocated);
					}
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().info("-----");
						working.getCalculationLogger().info("Found PlanBenefit.ChangeDate={} > Claim.HospitalizationDate={}, Setting MaxNoOfDay={} from PlanBenefit.MaxNoOfDaysHist", 
								planBenefitChangeDate,hospitalizationDate, maxDaysAllocated);
						working.getCalculationLogger().info("-----");
					}
				}
			} catch (NumberFormatException e) {
				if (logger.isDebugEnabled()) {
					logger.warn("Skipping PlanBenefit.ChangeDate > Claim.HospitalizationDate due to: " + e.getMessage());
				}
			}
		}


		// get A15 allocatedDays
		Integer a15TotalAllocatedDays = 0;
		Integer dayAdjustment=0;
		// check if previous benefit is A15
		PaymentAllocationTemp a15 = previousCurrentAllocationHelper.seekPreviousBenefitCodeAsExpected(BenefitCode.A15.toString(), working.getPlanId(), working.getPolicyNo(), working);
		Boolean isRollOverFromA15 = a15 != null;
		if (isRollOverFromA15) {
			//	PreviousClaimPaymentAllocation a15PreviousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(
			//			BenefitCode.A15.toString(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
			a15TotalAllocatedDays += a15.getPreviousAllocation().getDaysAllocated();
			
			if(a15.getPresentedNosOfDays() != null && a15.getAllocatedDay() != null) {
            	dayAdjustment = Math.max(a15.getPresentedNosOfDays() - a15.getAllocatedDay(), 0) ;

            	a15TotalAllocatedDays += a15.getAllocatedDay();
    			if(working.getCalculationLogger().isDebugEnabled()) {
    				working.getCalculationLogger().debug("RollOver From A15 has excess ICU Days of {} to be added to DayOfAdmit",dayAdjustment);
    			}

			}
			
		} else {
			// still need to check previous A15
			PreviousClaimPaymentAllocation a15PrevAllocation = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.A15.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),working) ;
			a15TotalAllocatedDays += a15PrevAllocation.getDaysAllocated() ;
			
			if(working.getCalculationLogger().isDebugEnabled()) {
				working.getCalculationLogger().debug("A15 has previous ICU Days of {} to be added to DayOfAdmit. Adding to A15PreviousDays. ",a15PrevAllocation.getDaysAllocated() );
			}
			
		}

		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays() + dayAdjustment;
		Integer totalCurrentAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		
		if (daysAllocated + totalCurrentAllocatedDays + a15TotalAllocatedDays > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - (totalCurrentAllocatedDays + a15TotalAllocatedDays);
		}

		daysAllocated = Math.max(daysAllocated, 0);
//		if (daysAllocated == 0) {
//			// check if there is remaining days
//			daysAllocated = Math.max(0, maxDaysAllocated - (totalCurrentAllocatedDays + a15TotalAllocatedDays));
//
//		}

		// should not be more than presented days
		daysAllocated = Math.min(daysAllocated, working.getPresentedNosOfDays());

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated.multiply(BigDecimal.valueOf(daysAllocated));

		if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
			eligbleAmt = BigDecimal.ZERO;
			daysAllocated = 0;
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},MaxNoOfDay={},NoOfUnit={},ValuePerUnit={},PresentedNosOfdays={}", working.getProductCode(),
					maxDaysAllocated,  nosOfUnit, valuePerUnit, working.getPresentedNosOfDays());

			if (isRollOverFromA15) {
				working.getCalculationLogger().debug(
						"Formula: EligbleAmt({}) = ValuePerUnit * NoOfUnit * Min(PresentedNosOfdays,MaxNoOfDay- ( A15PreviousDays={} + UsedDays={} ) ) ", eligbleAmt,
						a15TotalAllocatedDays, totalCurrentAllocatedDays);
			} else {
				working.getCalculationLogger().debug("Formula: EligbleAmt({}) =ValuePerUnit * NoOfUnit * Min(PresentedNosOfdays ,(MaxNoOfDay - UsedDays={}) ) ",
						eligbleAmt,  totalCurrentAllocatedDays);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated, working.getPresentedNosOfDays());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);

	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}

}
