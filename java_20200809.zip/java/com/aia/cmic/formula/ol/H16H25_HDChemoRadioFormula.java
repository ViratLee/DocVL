package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductType;

@BenifitCodeFormula("H16,H25")
public class H16H25_HDChemoRadioFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H16H25_HDChemoRadioFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
		*/

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmt={}, Old Claim UsedAmt={}, Total UsedAmt={}", previousClaimAllocation.getAmountAllocated(),
					working.getPreviousAllocation().getAmountAllocated(), previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));
		}
		BigDecimal currentUsedAmt = previousClaimAllocation.getAmountAllocated() ;
		previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(working.getPreviousAllocation().getAmountAllocated()));

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) planBenefit.getMaxBenefitAmt());
		List<String> parameterNames = Arrays.asList("MaxBenefitAmt");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();

		// presentedAmt
		BigDecimal presentedAmt = working.getPresentedAmt();

		//amountAllocated
		BigDecimal amountAllocated = presentedAmt;

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated.max(BigDecimal.ZERO);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo());
			working.getCalculationLogger().debug("Calculation Parameters: ProductCode={},PresentedAmt={},MaxBenefitAmt={}", working.getProductCode(), working.getPresentedAmt(), maxBenefitAmt);
		}

		if (eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {

			// previously reimbursed amt on the current benefit code/plan
			BigDecimal previousAllocation = previousClaimAllocation.getAmountAllocated();
			Boolean isHSPG = ProductCode.HSPG.toString().equalsIgnoreCase(working.getProductCode());
			Boolean isHSX =  StringUtils.equals(ProductType.HSX.toString(), working.getProductType()) ;
			Boolean isHNWShared =  StringUtils.equals(ProductCode.HNW.toString(), working.getProductCode()) && StringUtils.isNotBlank(planBenefit.getBenefitShare());
		
			boolean byPassMaxBenefitAmt = false;
			if (StringUtils.equals(ProductCode.HNW.toString(), working.getProductCode())) {
				amountAllocated = amountAllocated.subtract(currentUsedAmt).min(maxBenefitAmt);
				byPassMaxBenefitAmt = true;
			}
		
			if(!isHSX && !isHNWShared && !byPassMaxBenefitAmt ) {
				// bypass maxBenefitAmt checking. Let HSXSpecificConfinementAmt do the adjustment
				// 10/09/19 bypass maxBefnit Checking for HNW shared. Let HNWSpecificConfinementAmt do the adj
				if (amountAllocated.add(previousAllocation).compareTo(maxBenefitAmt) > 0) {
					// presented amount is greater than currently total allocated amt for this benefitcode/service Cat
					BigDecimal deductedAmt = maxBenefitAmt.subtract(previousAllocation);
					eligbleAmt = amountAllocated.min(deductedAmt);
					eligbleAmt = eligbleAmt.max(BigDecimal.ZERO);
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("presented amount is greater than currently total allocated amt for this benefitcode/service Cat eligbleAmt={}", eligbleAmt);
					}
				}
			}
			// adjustment
			if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("make sure that eligbleAmt will not be change when presented amt is re-calculated:  eligbleAmt={}", eligbleAmt);
				}
			}
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
			}

			if (isHSPG) {
				ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(),
						working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical);
				if (claimPolicyPlan != null && claimPolicyPlan.getPlanIssueDt() != null
						&& (claimCanonical.getClaim().getAccidentDt() != null || claimCanonical.getClaim().getHospitalizationDate() != null)) {
					// check total chemo
					Date startDate = previousCurrentAllocationHelper.findStartDateByIncident(claimPolicyPlan.getPlanIssueDt(), claimCanonical.getClaim().getAccidentDt(),
							claimCanonical.getClaim().getHospitalizationDate());
					Date endDate = null;
					BigDecimal chemoPerYear = BigDecimal.ZERO;
					if (startDate != null) {
						Calendar cal = Calendar.getInstance();
						cal.setTime(startDate);
						cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) + 1);
						endDate = cal.getTime();

						chemoPerYear = claimPaymentDetailRepository.findTotalEligbleAmtForChemoPerYear(claimCanonical.getClaim().getClaimNo(), working.getOccurence(), working.getPlanId(),
								working.getPolicyNo(), working.getBenefitCode(), startDate, endDate);

						if (eligbleAmt.add(chemoPerYear).compareTo(maxBenefitAmt) > 0) {
							BigDecimal deductedAmt = maxBenefitAmt.subtract(chemoPerYear);
							eligbleAmt = eligbleAmt.min(deductedAmt);
							eligbleAmt = eligbleAmt.max(BigDecimal.ZERO);
						}
					}
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("HSPG Additional Parameters: ProductCode={},AccidentDate={},HospitalizationDate={},StartDate={},EndDate={}", working.getProductCode(),
								claimCanonical.getClaim().getAccidentDt(), claimCanonical.getClaim().getHospitalizationDate(), startDate, endDate);
						working.getCalculationLogger().debug("Formula: EligbleAmt({})= Min(MaxBenefitAmt-PreviousUsedAmt={} within one year after HospitalizationDate/AccidentDate, presentedAmt)",
								eligbleAmt, chemoPerYear);
					}

				} else {
					if (logger.isDebugEnabled()) {
						logger.warn("ClaimPolicyPlan is missing for benefitCode={},claimNo={},planId{},policyNo={},productType={} Setting EligbleAmt to ZERO", working.getBenefitCode(),
								working.getClaimNo(), working.getPlanId(), working.getPolicyNo(), working.getProductCode());
					}
					eligbleAmt = BigDecimal.ZERO;
					return;
				}

			} else {

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Formula: EligbleAmt({})= Min(MaxBenefitAmt-PreviousUsedAmt={},presentedAmt))", eligbleAmt, previousAllocation);
				}
			}

			if (working.getProductSpecificConfinementAdjuster() != null) {
				eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
			}

		} else {
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Formula: EligbleAmt= 0");
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},presentedAmt={}", working.getBenefitCode(), eligbleAmt, working.getPresentedAmt());
		}
		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);

	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}
}
