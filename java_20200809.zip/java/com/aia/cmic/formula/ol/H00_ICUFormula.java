package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.Plan;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.exception.ClaimPaymentValidationException;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.repository.PlanRepository;
import com.aia.cmic.services.TransactionLogService;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.TransactionLogUtil;
import com.aia.cmic.util.TransactionLogUtil.TransactionLogInfo;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ProductCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseSubCode;

@BenifitCodeFormula("H00")
public class H00_ICUFormula extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H00_ICUFormula.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;
	
	@Autowired
	TransactionLogService transactionLogService ;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
/*
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");
		}
*/
		// no need to compute if the presented day == 0;
		if (working.getPresentedNosOfDays() == null || working.getPresentedNosOfDays() == 0) {
			working.setAllocatedDay(0);
			working.setEligibleAmt(BigDecimal.ZERO);
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("NoOfDaysPresented is ZERO or null, skipping calculation for this benefitCode.");
			}
			return;
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (claimPolicyPlan == null) {
			logger.warn("ClaimPolicyPlan is not provided on Canonical. Will not compute this benefit code ; claimNo={},occurence={},planId={},policyNo={},planCoverageNo={},benefitCode={}",
					working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getBenefitCode());
			throw new ClaimPaymentValidationException(
					"ClaimPolicyPlan is not provided on Canonical. Claim payment allocation will be aborted. Current Benefit Code = " + working.getBenefitCode() + ".");
		}

		// check required parameters for calculation
		List<Object> requiredParameters = Arrays.asList((Object) working.getPresentedNosOfDays(), planBenefit.getMaxNoOfDay(), claimPolicyPlan.getNoOfUnit(), claimPolicyPlan.getValuePerUnit());
		List<String> parameterNames = Arrays.asList("PresentedNosOfDays", "MaxNoOfDay", "NoOfUnit", "ValuePerUnit");
		ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s is required for " + working.getBenefitCode() + " benefit calculation.");

		// ceiling parameters
		Integer maxDaysAllocated = planBenefit.getMaxNoOfDay();
		BigDecimal maxConfinementAmt = planBenefit.getMaxConfinementAmt();
		
		if (ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode())) {
				maxConfinementAmt = previousCurrentAllocationHelper.getMaxConfinementAmtPerYear(claimCanonical, maxConfinementAmt, claimPolicyPlan.getRateAge(),
						claimPolicyPlan.getPlanIssueDt(), working);
		}
		

		// previousDaysAllocated
		// should come from DB instead
		//Integer previousAllocatedDays = previousClaimAllocation.getDaysAllocated();
		Integer previousAllocatedDays = working.getPreviousAllocation().getDaysAllocated();
		// days allocated
		Integer daysAllocated = working.getPresentedNosOfDays();
		if (daysAllocated + previousAllocatedDays > maxDaysAllocated) {
			daysAllocated = maxDaysAllocated - previousAllocatedDays;
		}
		// get previous allocated Days of H01
		//PaymentAllocationTemp nextH01 = previousCurrentAllocationHelper.seekNextBenefitCodeAsExpected(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(), working);
		Integer prevH01DaysAllocated = 0;
		Integer maxDaysAllocatedH01 = 0;
		Boolean isRollOverToH01 = !CollectionUtils.isEmpty(working.getRollOverGroupRefList()) && working.getRollOverGroupRefList().get(0) != null ;
		if (logger.isDebugEnabled()) {
			logger.debug("Rollover H00/H01? ->{}", isRollOverToH01 ? "yes" : "no");
		}
		Boolean isHNW = org.apache.commons.lang.StringUtils.equals(ProductCode.HNW.toString(), working.getProductCode()) ;

		if(daysAllocated > 0 ) {
			if(isHNW) {
				if (planBenefit.getMaxSumDay()!=null) {
					maxDaysAllocatedH01 = planBenefit.getMaxSumDay() ;
				}
				PreviousClaimPaymentAllocation h01 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),working) ;
				if (h01 != null && h01.getDaysAllocated() != null) {
					prevH01DaysAllocated = h01.getDaysAllocated();
				}
			} else {
				if (isRollOverToH01 ) {
					PaymentAllocationTemp nextH01 = working.getRollOverGroupRefList().get(0) ;
					prevH01DaysAllocated = nextH01.getPreviousAllocation().getDaysAllocated();
					PlanBenefit h01PlanBenefit = previousCurrentAllocationHelper.getPlanBenefit(nextH01.getPlanId(), nextH01.getBenefitCode(), planBenefitRepository);
					if(h01PlanBenefit != null) {
						maxDaysAllocatedH01 = h01PlanBenefit.getMaxNoOfDay();
					}
		
					if(working.getCalculationLogger().isDebugEnabled()) {
						working.getCalculationLogger().debug("Rollover to H01=True") ;
					}
		
				} else {
					// Make sure that allocation will not exceed H01
					PlanBenefit h01PlanBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), BenefitCode.H01.toString(), planBenefitRepository);
					if(h01PlanBenefit != null) {
						maxDaysAllocatedH01 = h01PlanBenefit.getMaxNoOfDay();
					}
		
					PreviousClaimPaymentAllocation h01 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(),working) ;
					prevH01DaysAllocated = h01.getDaysAllocated() ;
				}
			}
			
			if (prevH01DaysAllocated + daysAllocated + previousAllocatedDays > maxDaysAllocatedH01) {
				daysAllocated = maxDaysAllocatedH01 - (prevH01DaysAllocated + previousAllocatedDays);
				if (logger.isDebugEnabled()) {
					logger.debug("{}: Readjusting daysAllocated from H01 benefit Code parameters. H01 maxDays={},H01 prevDays={}", working.getBenefitCode(), maxDaysAllocatedH01, prevH01DaysAllocated);
				}
			}
			
			
		}
		daysAllocated = Math.max(daysAllocated, 0);

		// amount allocated
		BigDecimal nosOfUnit = claimPolicyPlan.getNoOfUnit();
		BigDecimal valuePerUnit = BigDecimal.valueOf(claimPolicyPlan.getValuePerUnit());

		if (working.getProductCode().equalsIgnoreCase(ProductCode.HSPG.toString())) {
			valuePerUnit = new BigDecimal(2);
		}

		BigDecimal amountAllocated = valuePerUnit.multiply(nosOfUnit).multiply(BigDecimal.valueOf(2));

		Boolean isHSJ = ProductCode.HSJR.toString().equalsIgnoreCase(working.getProductCode());
		BigDecimal planSubPlanCode = BigDecimal.ZERO;
		if (isHSJ) {
			// roomAmt for HS Juvenile
			// Room amount should be get from Plan. SubPlanCode - wanyupa
			Plan plan = planRepository.findPlanByPrimaryKey(working.getPlanId());
			amountAllocated = BigDecimal.ZERO;
			if (plan.getSubPlanCode() != null) {
				amountAllocated = new BigDecimal(plan.getSubPlanCode());
			}
			planSubPlanCode = amountAllocated;
		}

		// eligible Amount
		BigDecimal eligbleAmt = amountAllocated.multiply(new BigDecimal(daysAllocated));
		Boolean isHSJAndNotSurgery = isHSJ && StringUtils.isEmpty(working.getIcd9category().getIcd9Code()) ; 
		if(isHSJAndNotSurgery) {
			// HSJ
			eligbleAmt = working.getPresentedAmt();
		}
		if (working.isCalculationLoggerEnabled()) {

			working.getCalculationLogger().debug("PlanId={},PlanCoverageNo={},PolicyNo={},productCode={}", working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(),
					working.getProductCode());
			working.getCalculationLogger().debug("PresentedAmt={}", working.getPresentedAmt());
			working.getCalculationLogger().debug(
					"Calculation Parameters: ProductCode={},NoOfUnit={},ValuePerUnit={},MaxNoOfDay={},NoOfDaysPresented={},DaysAllocated={},PreviousDaysAllocated={},PreviousH01DaysAllocated={},H01MaxNoOfDays={}",
					working.getProductCode(), nosOfUnit, valuePerUnit, maxDaysAllocated, working.getPresentedNosOfDays(), daysAllocated, previousAllocatedDays, prevH01DaysAllocated,
					maxDaysAllocatedH01);
		}

		if (eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {
			// previously reimbursed amt on benefitCode/same serviceCatId
			//	BigDecimal totalCurrentlyAmtReimbursed = previousCurrentAllocationHelper.getCurrentAllocatedAmtByBenefitCodeServiceCat(working.getBenefitCode(), working.getServiceCatId(), working);
			
			BigDecimal maxAmtLimit = eligbleAmt.multiply(BigDecimal.ONE);
			if(isHSJAndNotSurgery) {
				maxAmtLimit = maxConfinementAmt ;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("HSJ and SurgeryInd <> 'Y', limit will be maxConfinementAmt={}", maxConfinementAmt);
				}
			}
			
			// check with previous amount
			eligbleAmt = maxAmtLimit.subtract(previousClaimAllocation.getAmountAllocated());
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				// accumulated amount reached maxLimit
				eligbleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}
			/*
			if (working.getPresentedAmt().subtract(totalCurrentlyAmtReimbursed).compareTo(eligbleAmt) > 0) {
				// presented amount is greater than currently total allocated amt for this benefitcode/service Cat
				BigDecimal deductedAmt = working.getPresentedAmt().subtract(totalCurrentlyAmtReimbursed);
				eligbleAmt = eligbleAmt.min(deductedAmt);
			}
			*/

			// adjust eligibleAmt
			if (eligbleAmt.compareTo(working.getPresentedAmt()) > 0) {
				// make sure that eligbleAmt will not be change when presented amt is re-calculated
				eligbleAmt = working.getPresentedAmt().multiply(BigDecimal.ONE);
			}
			if (eligbleAmt.compareTo(BigDecimal.ZERO) <= 0) {
				eligbleAmt = BigDecimal.ZERO;
				daysAllocated = 0;
			}

			if (working.isCalculationLoggerEnabled()) {
				if(isHSJAndNotSurgery) {
					working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min(PresentedAmt({}) , MaxConfinementAmt({})-UsedAmt({}) = {})", working.getPresentedAmt(), maxConfinementAmt,previousClaimAllocation.getAmountAllocated(),maxAmtLimit);					
				} else if (!isHSJ) {
					working.getCalculationLogger().debug("Formula: MaxAmtLimit = Min(PresentedAmt({}) , DaysAllocated({}) x NoOfUnit({}) x ValuePerUnit({}) x 2  = {})", working.getPresentedAmt(),
							daysAllocated, nosOfUnit, valuePerUnit, maxAmtLimit);
				} else {
					working.getCalculationLogger().debug("Formula: MaxAmtLimit =  Min(PresentedAmt({}) , Plan.SubPlanCode({}) x DaysAllocated({}) = {})", working.getPresentedAmt(), planSubPlanCode,
							daysAllocated, maxAmtLimit);

				}
				working.getCalculationLogger().debug("PreviousUsedAmt={}", previousClaimAllocation.getAmountAllocated());
				working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);
			}

			if (working.getProductSpecificConfinementAdjuster() != null && eligbleAmt.compareTo(BigDecimal.ZERO) > 0) {
				// further  adjustment by maxconfinement
				// TODO:  check if this part is already handled by productSpecificConfinementAdjuster
				if (claimPaymentDetailRepository.hasMajorAccidentConfinement(claimCanonical.getClaim().getClaimNo(), working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo())) {
					maxConfinementAmt = planBenefit.getMaxMajorConfinement();
				}

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("This productCode={} is eligble for further adjustment based on confinement parameters", working.getProductCode());
				}
				if (maxConfinementAmt != null || ClaimCalculationEnum.ProductCode.HNW.name().equalsIgnoreCase(working.getProductCode())) {
					eligbleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligbleAmt, maxConfinementAmt);
				}
			}

		} else {
			daysAllocated = 0;
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Formula: MaxAmtLimit = Min(PresentedAmt={} ,  DaysAllocated({}) x NoOfUnit({}) x ValuePerUnit({}) x 2  = {})", working.getPresentedAmt(),
						daysAllocated, nosOfUnit, valuePerUnit, 0);
				working.getCalculationLogger().debug("PreviousUsedAmt={}", previousClaimAllocation.getAmountAllocated());
				working.getCalculationLogger().debug("EligibleAmt={}", eligbleAmt);

			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("{} Benefit Code Calculation output: eligibleAmt={},daysAllocated={},presentedAmt={},presentedDays={}", working.getBenefitCode(), eligbleAmt, daysAllocated,
					working.getPresentedAmt(), working.getPresentedNosOfDays());
		}

		// set elegibleAmt and
		working.setEligibleAmt(eligbleAmt);
		working.setAllocatedDay(daysAllocated);
		
		/* Commented for now */
		/*
		//TransactionLogging
		if(maxDaysAllocated - ( daysAllocated  + previousAllocatedDays ) <= 1) {
			TransactionLogInfo logInfo = new TransactionLogInfo() ;
			logInfo.setResponseCode(ResponseCode.C005);
			// warn
			// ""Policy %s / Plan %s / Product Code %s / BenefitCode %s - Limit: %d days, Previous paid : %d days, Previous paid Amt: %s, Presented: %d days, Presented Amt: %s, Eligible: %d days"
			logInfo.setParameters(
			Arrays.asList(ResponseSubCode.A, working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxDaysAllocated, previousAllocatedDays,previousClaimAllocation.getAmountAllocated(), 
					working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated ).toArray() ) ;
		} 
		// info
		// ""Policy %s / Plan %s / Product Code %s / BenefitCode %s - Limit: %d days, Previous paid : %d days, Previous paid Amt: %s, Presented: %d days, Presented Amt: %s, Eligible: %d days"
		TransactionLogInfo logInfo = new TransactionLogInfo() ;
		logInfo.setResponseCode(ResponseCode.C003);
		logInfo.setParameters(
		Arrays.asList(ResponseSubCode.H,working.getPolicyNo(),working.getPlanName(), working.getProductCode(), working.getBenefitCode(), maxDaysAllocated, previousAllocatedDays,previousClaimAllocation.getAmountAllocated(), 
				working.getPresentedNosOfDays(), working.getPresentedAmt(), daysAllocated ).toArray() ) ;
		*/
	}

	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

	@Override
	public boolean isPresentedDaysRequired() {
		return true;
	}
	

}
