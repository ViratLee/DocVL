package com.aia.cmic.formula.ol;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H29")
public class H29_PTCall extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H29_PTCall.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		
		BigDecimal eligibleAmt = BigDecimal.ZERO ;
		if(working.getPresentedAmt().compareTo(BigDecimal.ZERO) > 0 ) {
			eligibleAmt = working.getPresentedAmt() ;
			
			if(working.getProductSpecificConfinementAdjuster() != null) {
				eligibleAmt = working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, planBenefit.getMaxConfinementAmt());
			}
			
		}
				// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		
	}
	
	@Override
	public boolean isPresentedAmtRequired() {
		return true;
	}

}
