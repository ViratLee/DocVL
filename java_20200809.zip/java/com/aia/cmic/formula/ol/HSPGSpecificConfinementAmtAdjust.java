package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;

@Component("HSPGConfinementAdjuster")
public class HSPGSpecificConfinementAmtAdjust implements ProductConfinementAdjustable {

	private static Logger logger = LoggerFactory.getLogger(HSPGSpecificConfinementAmtAdjust.class);
	@Autowired
	private PlanBenefitRepository planBenefitRepository;

	@Autowired
	ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Override
	public BigDecimal adjustEligibleAmtViaMaxConfinement(ClaimCanonical claimCanonical, PaymentAllocationTemp working, BigDecimal eligbleAmt, BigDecimal maxConfinementAmt) {

		if (logger.isDebugEnabled()) {
			logger.debug("HSPG confinement executing..");

		}
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Checking EligibleAmt={} vs MaxConfinementAmt={}", eligbleAmt, maxConfinementAmt);
		}

		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();

		BigDecimal adjustedAmt = eligbleAmt;
		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);

		if (working.getBenefitCode().compareTo(BenefitCode.H16.toString()) != 0 &&  working.getBenefitCode().compareTo(BenefitCode.H25.toString()) != 0) {
			if (!StringUtils.isEmpty(claimCanonical.getClaim().getMajorAccId())) {
				maxConfinementAmt = planBenefit.getMaxMajorConfinement();
			}

			BigDecimal amtConfinement = previousCurrentAllocationHelper.getTotalConfinementAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo());
			/*
			BigDecimal previousAmtReimbursedOld = previousCurrentAllocationHelper
					.getPreviousAllocation(working.getBenefitCode(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo()).getAmountAllocated();
			*/
			/*
			 * 'H00','H01', 'H02','H03','H04','H07','H08','H09','H10','H13','H14','H15
			 */
			BigDecimal previousAmtReimbursedOld = BigDecimal.ZERO;
			PreviousClaimPaymentAllocation h00 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H00.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h01 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H01.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h02 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H02.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h03 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H03.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h04 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H04.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h07 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H07.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h08 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H08.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h09 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H09.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h10 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H10.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h13 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H13.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h14 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H14.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);
			PreviousClaimPaymentAllocation h15 = previousCurrentAllocationHelper.getPreviousAllocation(BenefitCode.H15.toString(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(),working);

			previousAmtReimbursedOld = h00.getAmountAllocated().add(h01.getAmountAllocated()).add(h02.getAmountAllocated()).add(h03.getAmountAllocated()).add(h04.getAmountAllocated())
					.add(h07.getAmountAllocated()).add(h08.getAmountAllocated()).add(h09.getAmountAllocated()).add(h10.getAmountAllocated()).add(h13.getAmountAllocated()).add(h14.getAmountAllocated())
					.add(h15.getAmountAllocated());
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Current Total Used Amt={}", amtConfinement);
				working.getCalculationLogger().debug("Old Claim Used Amt: H00={},H01={}, H02={},H03={},H04={},H07={},H08={},H09={},H10={},H13={},H14={},H15={}", h00.getAmountAllocated(),
						h01.getAmountAllocated(), h02.getAmountAllocated(), h03.getAmountAllocated(), h04.getAmountAllocated(), h07.getAmountAllocated(), h08.getAmountAllocated(),
						h09.getAmountAllocated(), h10.getAmountAllocated(), h13.getAmountAllocated(), h14.getAmountAllocated(), h15.getAmountAllocated());
				working.getCalculationLogger().debug("Total Used Amt for this policy/plan={}", amtConfinement.add(previousAmtReimbursedOld));
			}

			if (adjustedAmt.add(amtConfinement).add(previousAmtReimbursedOld).compareTo(maxConfinementAmt) > 0) {
				adjustedAmt = maxConfinementAmt.subtract(amtConfinement.add(previousAmtReimbursedOld));
				adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
			}

		}

		// yearly confinement
		BigDecimal maxYearAmt = planBenefit.getMaxYearAmt();

		ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
				working.getPlanCoverageNo(), claimCanonical);
		if (logger.isDebugEnabled() && claimPolicyPlan == null) {
			logger.debug("Couldn't find ClaimPolicyPlan from canonical. {} yearly confinement adjustment will be ignored. ", working.getProductType());
		}
		if (claimPolicyPlan != null && claimPolicyPlan.getPlanIssueDt() != null && (claimCanonical.getClaim().getAccidentDt() != null || claimCanonical.getClaim().getHospitalizationDate() != null)) {

			Date startDate = previousCurrentAllocationHelper.findStartDateByIncident(claimPolicyPlan.getPlanIssueDt(), claimCanonical.getClaim().getAccidentDt(),
					claimCanonical.getClaim().getHospitalizationDate());

			if (startDate != null) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(startDate);
				cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) + 1);
				Date endDate = cal.getTime();

				BigDecimal amtConfinementYear = previousCurrentAllocationHelper.getTotalConfinementAmtPerYear(working.getPlanId(), working.getPolicyNo());
				BigDecimal previousAmtReimbursedYearOld = claimPaymentDetailRepository.findTotalEligbleAmtByPlanCoveragePerYear(claimCanonical.getClaim().getClaimNo(), working.getPlanId(),
						working.getPlanCoverageNo(), working.getPolicyNo(), startDate, endDate);

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Year Converage from {} to {}", startDate, endDate);
					working.getCalculationLogger().debug("Current Total Used Amt Per Year={}", amtConfinementYear);
					working.getCalculationLogger().debug("Old Total Used Amt Per Year={}", previousAmtReimbursedYearOld);
				}

				if (adjustedAmt.add(amtConfinementYear).add(previousAmtReimbursedYearOld).compareTo(maxYearAmt) > 0) {
					adjustedAmt = maxYearAmt.subtract(amtConfinementYear.add(previousAmtReimbursedYearOld));
					adjustedAmt = adjustedAmt.max(BigDecimal.ZERO) ;
				}

			}
		}

		// update confinement amt
		previousCurrentAllocationHelper.setTotalConfinemeAmt(working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), adjustedAmt);
		previousCurrentAllocationHelper.setTotalConfinemeAmtPerYear(working.getPlanId(), working.getPolicyNo(), adjustedAmt);

		return adjustedAmt;
	}

}
