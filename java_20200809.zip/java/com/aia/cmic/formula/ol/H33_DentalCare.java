package com.aia.cmic.formula.ol;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.entity.PlanBenefit;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.PlanBenefitRepository;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;

@BenifitCodeFormula("H33")
public class H33_DentalCare extends OLBenefitCodeFormula {

	private static Logger logger = LoggerFactory.getLogger(H33_DentalCare.class);

	@Autowired
	PlanBenefitRepository planBenefitRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Computing Benefit Code ={},Product Code={} ", working.getBenefitCode(), working.getProductCode());
		}
		
		// helper class for calculation
		PreviousCurrentAllocationHelper previousCurrentAllocationHelper = working.getPreviousCurrentAllocationHelper();
		// previous claim info
		PreviousClaimPaymentAllocation previousClaimAllocation = previousCurrentAllocationHelper.getCurrentAndPreviousAllocationByPlanPolicyNoBenefitCodePlanCoverageNo(working.getBenefitCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getPolicyNo(), working);
		
		PreviousClaimPaymentAllocation oldAllocationDB = working.getPreviousAllocation();
		if (logger.isDebugEnabled()) {
			logger.debug("Current UsedAmount={}, DB UsedAmount={}, Total UsedAmount={}", previousClaimAllocation.getAmountAllocated(), oldAllocationDB.getAmountAllocated(),
					previousClaimAllocation.getAmountAllocated().add(oldAllocationDB.getAmountAllocated()));
		}
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Current UsedAmount={}, DB UsedAmount={}, Total UsedAmount={}", previousClaimAllocation.getAmountAllocated(), oldAllocationDB.getAmountAllocated(),
					previousClaimAllocation.getAmountAllocated().add(oldAllocationDB.getAmountAllocated()));
		}

		previousClaimAllocation.setAmountAllocated(previousClaimAllocation.getAmountAllocated().add(oldAllocationDB.getAmountAllocated()));

		PlanBenefit planBenefit = previousCurrentAllocationHelper.getPlanBenefit(working.getPlanId(), working.getBenefitCode(), planBenefitRepository);
		BigDecimal maxBenefitAmt = planBenefit.getMaxBenefitAmt();
		
		BigDecimal eligibleAmt = BigDecimal.ZERO ;
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Requirement check: Further claim is not covered and hospitaliazationDt vs accidentDt should be within 7 days.") ;
		}
		if(working.getPresentedAmt().compareTo(BigDecimal.ZERO) > 0 ) {
			// requirement check: hospitaliazationDt vs accidentDt should be within 7 days.
			if(claimCanonical.getClaim().getHospitalizationDate() != null && claimCanonical.getClaim().getAccidentDt() != null) {
				Date hostpitalizationDt = claimCanonical.getClaim().getHospitalizationDate() ;
				Date accidentDt = claimCanonical.getClaim().getAccidentDt() ;
				hostpitalizationDt = DateUtils.truncate(hostpitalizationDt, Calendar.DAY_OF_MONTH) ;
				accidentDt = DateUtils.truncate(accidentDt, Calendar.DAY_OF_MONTH) ;
				Long daysDiff = TimeUnit.DAYS.convert(accidentDt.getTime() - hostpitalizationDt.getTime()  , TimeUnit.MILLISECONDS) ;
				if(claimCanonical.getClaim().getOccurrence() > 1 || daysDiff > 7) {
					eligibleAmt = BigDecimal.ZERO ;
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("hospitalizationDt and accidentDt doesnt meet reqmt. HospitalizationDt={},AccidentDt={},Day Difference={}! Setting ElibleAmt=0.",
								hostpitalizationDt,accidentDt,daysDiff); 
					}
				} else {
					eligibleAmt = working.getPresentedAmt() ;
					
					if(eligibleAmt.add(previousClaimAllocation.getAmountAllocated()).compareTo(maxBenefitAmt) > 0) {
						eligibleAmt = maxBenefitAmt.subtract(previousClaimAllocation.getAmountAllocated()) ;
					}
					if(working.getProductSpecificConfinementAdjuster() != null) {
						eligibleAmt =working.getProductSpecificConfinementAdjuster().adjustEligibleAmtViaMaxConfinement(claimCanonical, working, eligibleAmt, planBenefit.getMaxConfinementAmt());
					}
				}
			} else {
				eligibleAmt = BigDecimal.ZERO ;
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("hospitalizationDt and accidentDt is required and should not be NULL! Setting ElibleAmt=0."); 
				}
			}
		}
				// set elegibleAmt 
		working.setEligibleAmt(eligibleAmt);
		
	}
	
	public boolean isPresentedAmtRequired() {
		return true;
	}

}
