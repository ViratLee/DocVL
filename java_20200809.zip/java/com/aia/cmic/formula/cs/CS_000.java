package com.aia.cmic.formula.cs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.formula.ol.BenefitCodeFormula;
import com.aia.cmic.model.PaymentAllocationTemp;

/**
 *  Special benefitcode formula for 000/Misc
 * @author ASNPAT4
 *
 */
@BenifitCodeFormula("CS_000")
public class CS_000 implements BenefitCodeFormula {

	private Logger logger = LoggerFactory.getLogger(CS_000.class);


	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Formula for BenefitCode={} is now executing! ", working.getBenefitCode());
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");

		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Parameters : PolicyNo={},ProductCode={},PlanId={},PlanCoverageNo={},PresentedAmt={}", working.getPolicyNo(), working.getProductCode(), working.getPlanId(), working.getPlanCoverageNo(), working.getPresentedAmt()) ;
		}
		
		working.setEligibleAmt(working.getPresentedAmt());
		working.setShortFallAmount(working.getPresentedAmt());
		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("ClaimPayment.PayNonCoverItemInd='Y' for benefit {}. Pay all presentedAmt={} to ShortFall={},EligibleAmt={}.", working.getBenefitCode(), working.getPresentedAmt(), working.getShortFallAmount(), working.getEligibleAmt());
		}
	}
}
