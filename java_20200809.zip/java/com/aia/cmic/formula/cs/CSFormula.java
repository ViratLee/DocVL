package com.aia.cmic.formula.cs;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.formula.ol.BenefitCodeFormula;
import com.aia.cmic.model.ClaimPolicy;
import com.aia.cmic.model.ClaimPolicyCoverage;
import com.aia.cmic.model.Insured;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.model.PreviousClaimPaymentAllocation;
import com.aia.cmic.repository.ClaimPaymentDetailRepository;
import com.aia.cmic.repository.CommonCodeRepository;
import com.aia.cmic.services.TransactionLogService;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper.CSPresentedAmtMetaData;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.BusinessLine;
import com.aia.cmic.util.ClaimCalculationEnum.ProcedureCategory;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseSubCode;
import com.aia.cmic.util.ClaimCalculationEnum.SumCategory;
import com.aia.cmic.util.ClaimCalculationEnum.SumTimeFrame;
import com.aia.cmic.util.ClaimCalculationEnum.TreatmentType;
import com.aia.cmic.util.ClaimCalculationEnum;
import com.aia.cmic.util.TransactionLogUtil;

@BenifitCodeFormula("CSFormula")
public class CSFormula implements BenefitCodeFormula {

	private Logger logger = LoggerFactory.getLogger(CSFormula.class);
	private static final String CASH_BENEFIT_SERVICECATID = "CASH_BENEFIT";

	@Autowired
	private ClaimPaymentDetailRepository claimPaymentDetailRepository;

	@Autowired
	private TransactionLogService transactionLogService;

	@Autowired
	private CommonCodeRepository commonCodeRepository;

	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("Formula: CSFormula is now executing! Current benefitCode={}", working.getBenefitCode());
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");

		}
		String currentBenefitCode = working.getBenefitCode();
		PreviousCurrentAllocationHelper helper = working.getPreviousCurrentAllocationHelper();
		working.setPresentedNosOfDays(null);

		/*
		 * Apr 03 Changes onsite. H16 is only valid with 24 hours from hospitalizationDate vs accidentDate - Wittaya
		 * Apr 08, requested to disabled by Wittaya. Already handled in BusinessRules.
		 */
		//		if (BenefitCode.H16.toString().equalsIgnoreCase(currentBenefitCode) ) {
		//			if( claimCanonical.getClaim().getHospitalizationDate() == null || claimCanonical.getClaim().getAccidentDt() == null) {
		//				// accidentDate and hospitalizationDate cannot be null for this benefit
		//				logger.warn("Formula: CSFormula, HospitalizationDate and accidentDt cannot be both NULL for benefitCode H16!");
		//				if (working.isCalculationLoggerEnabled()) {
		//					working.getCalculationLogger().debug("Formula: ElegibleAmt=0,  HospitalizationDate and accidentDt cannot be both NULL for benefitCode H16!");
		//				}
		//				TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C312,working.getBenefitCode());
		////				TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(), working.getBenefitCode(),
		////						"N/A", "N/A", working.getPresentedAmt(), BigDecimal.ZERO, BigDecimal.ZERO, "N/A");
		//
		//				return;
		//			}
		//			long milliSecsDifference = Math.abs(claimCanonical.getClaim().getHospitalizationDate().getTime() - claimCanonical.getClaim().getAccidentDt().getTime()) ;
		//			if( milliSecsDifference > 86400000L) {
		//				// more than 24 hours is not allowed for H16!
		//				if (working.isCalculationLoggerEnabled()) {
		//					working.getCalculationLogger().debug("Formula: ElegibleAmt=0, HospitalizationDate({}) vs AccidentDate({}) is more than 24 hours. This benefit can be allocated within 24 hours only.",
		//							claimCanonical.getClaim().getHospitalizationDate(), claimCanonical.getClaim().getAccidentDt());
		//				}			
		//				TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C311,working.getBenefitCode());
		//				return ;
		//			}
		//		}
		if (BenefitCode.N20.toString().equalsIgnoreCase(currentBenefitCode)) {
			int maxDaysToReimburse = 365;
			// for H16/EOPD, need check the IncidentDate and CheckDate.
			Date incidentDate = claimCanonical.getClaim().getHospitalizationDate();

			if (TreatmentType.Accident.toString().equalsIgnoreCase(claimCanonical.getClaim().getCauseOfTreatment())) {
				incidentDate = claimCanonical.getClaim().getAccidentDt();
			}
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Parameters: CauseOfTreatment={},HospitaliztionDate={},AccidentDt={}", claimCanonical.getClaim().getCauseOfTreatment(),
						claimCanonical.getClaim().getHospitalizationDate(), claimCanonical.getClaim().getAccidentDt());
			}

			if (incidentDate == null) {
				logger.warn("Formula: CSFormula, incidentDt and accidentDt cannot be both NULL for benefitCode N20!");
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Formula: ElegibleAmt=0, incidentDt and accidentDt cannot be both NULL for benefitCode N20!");
				}
				if (helper.isEnableTransactionLogging()) {
					TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C312, working.getBenefitCode());
				}
				return;
			}

			long consultIncidentDtDifference = (claimCanonical.getClaim().getConsultationDt().getTime() - incidentDate.getTime()) / 86400000;
			// always add endDate;
			consultIncidentDtDifference++;

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Parameters: MaxDaysToReimburse={},ConsultIncidentDtDifference={}", maxDaysToReimburse, consultIncidentDtDifference);
			}
			//			if (BenefitCode.H16.toString().equalsIgnoreCase(currentBenefitCode)) {
			//				if (claimCanonical.getClaim().getOccurrence() == 1 && consultIncidentDtDifference > 1) {
			//					if (logger.isDebugEnabled()) {
			//						logger.debug("H16/EOPD validation failed! occurrence={},incidentDt={},consultationDt={},dayDifference={}", claimCanonical.getClaim().getOccurrence(), incidentDate,
			//								claimCanonical.getClaim().getConsultationDt(), consultIncidentDtDifference);
			//					}
			//					if (working.isCalculationLoggerEnabled()) {
			//						working.getCalculationLogger().debug("Formula: ElegibleAmt=0=, Occurrence= 1 and consultIncidentDtDifference > 1");
			//					}
			//					return;
			//				}
			//			}
			// for N20/AME, should reimburse within 365 days
			// for H16, should reimburse within 31 days
			if (claimCanonical.getClaim().getOccurrence() > 1 && consultIncidentDtDifference > maxDaysToReimburse) {
				if (logger.isDebugEnabled()) {
					logger.debug("N20 validation failed! occurrence={},incidentDt={},consultationDt={},dayDifference={}", claimCanonical.getClaim().getOccurrence(), incidentDate,
							claimCanonical.getClaim().getConsultationDt(), consultIncidentDtDifference);
				}
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Formula: ElegibleAmt=0=, Occurrence > 1 and consultIncidentDtDifference > {}", maxDaysToReimburse);
				}
				if (helper.isEnableTransactionLogging()) {
					TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C313, working.getBenefitCode(), String.valueOf(maxDaysToReimburse));
				}
				return;
			}

		}

		//3.4 For R&B BenefitCodes , need apply PresentedDays 
		// Move here coz it doesn't have to be inside the loop
		Boolean isRBSet = Arrays.asList(BenefitCode.H01.toString(), BenefitCode.H03.toString(), BenefitCode.H11.toString(), BenefitCode.H50.toString(), BenefitCode.HT1.toString(), BenefitCode.HT3.toString(), BenefitCode.I01.toString(),
				BenefitCode.HT5.toString(), BenefitCode.HT6.toString(), BenefitCode.IT0.toString()).contains(working.getBenefitCode());
		String fromDay = "";
		if (BenefitCode.H01.toString().equals(working.getBenefitCode()) || BenefitCode.HT1.toString().equals(working.getBenefitCode()) || BenefitCode.HT3.toString().equals(working.getBenefitCode())) {
			working.setPresentedNosOfDays(claimCanonical.getClaim().getDayOfAdmitRoom() != null ? claimCanonical.getClaim().getDayOfAdmitRoom() : null);
			fromDay = "Claim.DayOfAdmitRoom";
			if (BenefitCode.H01.toString().equals(working.getBenefitCode()) && helper.getExcessCSICUDays() > 0) {
				// Add Excess Days/Amount to Standard Room
				working.setPresentedNosOfDays((working.getPresentedNosOfDays() != null ? working.getPresentedNosOfDays() : 0) + helper.getExcessCSICUDays());
				if (working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("PresentedAmt={} will be added with Exccess Amt of {} from ICU Services {}", working.getPresentedAmt(), helper.getExcessCSICUAmt(), helper.getIcuServicesWithExcessAmtBuilder().toString());
					working.getCalculationLogger().debug("PresentedNosOfDays is now {} from Claim.DayOFAdmitRoom({}) + ICU ExcessDays({})", working.getPresentedNosOfDays(), claimCanonical.getClaim().getDayOfAdmitRoom(), helper.getExcessCSICUDays());
					helper.setIcuServicesWithExcessAmtBuilder(new StringBuilder());
				}

				working.setPresentedAmt(working.getPresentedAmt().add(helper.getExcessCSICUAmt()));
				helper.setExcessCSICUAmt(BigDecimal.ZERO);
				if (helper.getClaimBenefitItemMap().containsKey(working.getCurrentClaimBenefitItemKey())) {
					com.aia.cmic.model.ClaimBenefitItem claimBenefitITem = helper.getClaimBenefitItemMap().get(working.getCurrentClaimBenefitItemKey());
					claimBenefitITem.setPresentedAmt(working.getPresentedAmt());
				}

				if (working.getCalculationLogger().isDebugEnabled()) {
					working.getCalculationLogger().debug("New Value OF PresentedAmt={} and PresentedNosOfDays ={}  after added excess Amt from ICU Services.", working.getPresentedAmt(), working.getPresentedNosOfDays());
				}
			}

		} else if (BenefitCode.H03.toString().equals(working.getBenefitCode()) || BenefitCode.HT5.toString().equals(working.getBenefitCode()) || BenefitCode.HT6.toString().equals(working.getBenefitCode())) {
			working.setPresentedNosOfDays(claimCanonical.getClaim().getDayOfAdmitIcu() != null ? claimCanonical.getClaim().getDayOfAdmitIcu() : null);
			fromDay = "Claim.DayOfAdmitIcu";
		} else if (BenefitCode.H11.toString().equals(working.getBenefitCode())) {
			working.setPresentedNosOfDays(claimCanonical.getClaim().getDayOfCall() != null ? claimCanonical.getClaim().getDayOfCall() : null);
			fromDay = "Claim.DayOfCall";
		} else if (BenefitCode.I01.toString().equals(working.getBenefitCode()) || BenefitCode.IT0.toString().equals(working.getBenefitCode())) {
			// "30100","30111","30112","30128","30129
			if (BenefitCode.I01.toString().equals(working.getBenefitCode())) {
				Boolean isProductCodesForI01 = Arrays.asList("30100", "30111", "30112", "30128", "30129", "31110").contains(working.getProductCode());
				// don't calculate for this productcode not in above list -Sarunya
				if (!isProductCodesForI01) {
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("I01 will not calculate for ProductCode = {}. Allowed ProductCodes=('30100','30111','30112','30128','30129','31110'). Skipping this calculation.", working.getProductCode());
					}
					working.setEligibleAmt(BigDecimal.ZERO);
					working.setReimbursedDay(0);
					working.setReimbusrsedCall(0);
					if (helper.isEnableTransactionLogging()) {
						TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C314, working.getBenefitCode(), working.getProductCode());
					}
					return;
				}
			}

			working.setPresentedNosOfDays(claimCanonical.getClaim().getDayOfAdmitRoom() != null ? claimCanonical.getClaim().getDayOfAdmitRoom() : 0);
			Integer icu = claimCanonical.getClaim().getDayOfAdmitIcu() != null ? claimCanonical.getClaim().getDayOfAdmitIcu() : 0;
			working.setPresentedNosOfDays(working.getPresentedNosOfDays() + icu);
			fromDay = "Claim.DayOfAdmitRoom + Claim.DayOfAdmitIcu";
		} else if (BenefitCode.H50.toString().equals(working.getBenefitCode()) || ((BenefitCode.HE1.toString().equals(working.getBenefitCode()) || BenefitCode.N20.toString().equals(working.getBenefitCode())) && working.getPreviousCurrentAllocationHelper().thisServiceHasRB(working))) {
			if (working.getPreviousCurrentAllocationHelper().getExcessDaysFromH03H01() > 0 && helper.checkIfH01H03isHasExcessDays(working, claimCanonical.getClaim().getDayOfAdmitRoom(), claimCanonical.getClaim().getDayOfAdmitIcu())) {
				if (!helper.isAllowedToAllocateH50HE1()) {
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug(" Skipping this allocation for now. Will be allocated last!", working.getBenefitCode());

					}
					working.setEligibleAmt(BigDecimal.ZERO);
					working.setReimbursedDay(0);
					working.setReimbusrsedCall(0);

					if (helper.isEnableTransactionLogging()) {
						TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C307);
					}
					return;

				} else {
					// only applicable for H50 and HE1
					if (BenefitCode.H50.toString().equals(working.getBenefitCode()) || BenefitCode.HE1.toString().equals(working.getBenefitCode())) {
						working.setPresentedNosOfDays(working.getPreviousCurrentAllocationHelper().getExcessDaysFromH03H01());
						fromDay = "H03 + H01 excess days";
					}
				}
			} else {
				// there is no excess days from H03/H01
				if (BenefitCode.H50.toString().equals(working.getBenefitCode()) || (BenefitCode.HE1.toString().equals(working.getBenefitCode()) && BooleanUtils.isFalse(helper.isEligibleForHE1(working)))) {
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("There is no excess days from H01/H03 to allocate for this benefit = {}. Skipping this allocation", working.getBenefitCode());

					}
					working.setEligibleAmt(BigDecimal.ZERO);
					working.setReimbursedDay(0);
					working.setReimbusrsedCall(0);

					if (helper.isEnableTransactionLogging()) {
						if (BenefitCode.HE1.toString().equals(working.getBenefitCode())) {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C321, working.getBenefitCode());
						} else {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C315, working.getBenefitCode());
						}
					}
					return;
				}
			}
		} else if (BenefitCode.HE1.toString().equals(working.getBenefitCode()) && BooleanUtils.isFalse(helper.isEligibleForHE1(working))) {
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("This benefit = {} is not eligible for allocation. Skipping this allocation", working.getBenefitCode());

			}
			if (helper.isEnableTransactionLogging()) {
				TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C321, working.getBenefitCode());
			}
			return;
		}

		if (isRBSet && working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("R&B adjusted PresentedDays={} from {}", working.getPresentedNosOfDays(), fromDay);
		}

		/**
		 * HS1 calculation : Filter rollover for all benefit code except coming from H01 and H03
		 */

		if (BenefitCode.HS1.toString().equals(working.getBenefitCode())) {
			if (!working.getPreviousCurrentAllocationHelper().isHS1AllowedToCalculate(working)) {
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("HS1 cannot be computed from H01/H03 rollover. skipping this calculation.");

				}
				working.setEligibleAmt(BigDecimal.ZERO);
				working.setReimbursedDay(0);
				working.setReimbusrsedCall(0);
				if (helper.isEnableTransactionLogging()) {
					TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C316, working.getBenefitCode());
				}
				return;
			}
		}

		// elegibleAmt
		BigDecimal elegibleAmt = working.getPresentedAmt();
		Integer daysAllocated = working.getPresentedNosOfDays();

		// Retrieve DeductibleAmt, Unit4 
		String[] sumCategory = { SumCategory.D.toString() };
		List<ClaimPolicyCoverage> coverages = ClaimCanonicalUtil.findClaimPolicyCoverageByBenefitCodeSumCategory(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(),
				working.getProductCode(), working.getPlanId(), working.getPlanCoverageNo(), working.getBenefitCode(), sumCategory, claimCanonical);
		if (coverages != null && !coverages.isEmpty()) {
			ClaimPolicyCoverage claimPolicyCoverage = coverages.get(0);
			// check if non-shared is present from policy coverage. Get this policy if present
			if(claimPolicyCoverage.getAccumulatorNo() != null) {
				for(ClaimPolicyCoverage coverage: coverages) {
					if(coverage.getAccumulatorNo() == null) {
						claimPolicyCoverage = coverage ;
						break ;
					}
				}
			}
			
			BigDecimal deductibleAmt = claimPolicyCoverage.getBenefitAmount();
			// get total presented amount processed so far.
			PreviousClaimPaymentAllocation currentPresentedAmt = helper.getTotalPresentedAmountByBenefit(working) ;
			BigDecimal totalBenefitPresentedAmt = currentPresentedAmt.getAmountAllocated().subtract(deductibleAmt).max(BigDecimal.ZERO);
			elegibleAmt = totalBenefitPresentedAmt.min(working.getPresentedAmt()) ;
			
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("// Retrieve DeductibleAmt, Unit4");
				working.getCalculationLogger().debug("Parameters: DeductibleAmt={}, After deduction -> Current PresentedAmt ={}, TotalPresentedAmt={} for benefitCode={}. ", deductibleAmt, elegibleAmt, 
						currentPresentedAmt.getAmountAllocated(), working.getBenefitCode());
			}

			if (helper.isEnableTransactionLogging()) {
				TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C310, working.getPresentedAmt(), deductibleAmt, elegibleAmt, working.getBenefitCode());
			}

			// Bug fix 2018/20/30, don't filter cash benefit
			if(totalBenefitPresentedAmt.compareTo(BigDecimal.ZERO) <= 0 && !"CASH_BENEFIT".equals(working.getServiceCatId())) {
				return ;
			}
		}

		// Calculate Copayment Amt, Unit99 
		sumCategory[0] = SumCategory.O.toString();
		coverages = ClaimCanonicalUtil.findClaimPolicyCoverageByBenefitCodeSumCategory(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(),
				working.getPlanId(), working.getPlanCoverageNo(), working.getBenefitCode(), sumCategory, claimCanonical);
		if (coverages != null && !coverages.isEmpty()) {
			ClaimPolicyCoverage claimPolicyCoverage = coverages.get(0);
			if (claimPolicyCoverage.getBenefitAmount().compareTo(BigDecimal.ZERO) > 0) {
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("// Calculate Copayment Amt, Unit99 ");
					working.getCalculationLogger().debug("Parameters: EligibleAmt={},BenefitAmount={}", elegibleAmt, claimPolicyCoverage.getBenefitAmount());
				}

				if (helper.isEnableTransactionLogging()) {
					TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C319, claimPolicyCoverage.getBenefitAmount(), elegibleAmt, elegibleAmt.subtract(claimPolicyCoverage.getBenefitAmount()).setScale(2, RoundingMode.HALF_UP));
				}
				if (elegibleAmt.compareTo(claimPolicyCoverage.getBenefitAmount()) >= 0) {
					elegibleAmt = elegibleAmt.subtract(claimPolicyCoverage.getBenefitAmount());
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("EligibleAmt={} After Deducted", elegibleAmt);
					}
				} else {
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("EligibleAmt is now zero before calculate Copayment. Skipping this calculation");
					}
					return;
				}
			}
		}

		// Calculate Rebursement %, Unit8 
		if (!BenefitCode.H50.toString().equals(working.getBenefitCode()) || (BenefitCode.HE1.toString().equals(working.getBenefitCode()) && working.getPreviousCurrentAllocationHelper().isRollOverFromH01(working))) {
			sumCategory[0] = SumCategory.R.toString();
			coverages = ClaimCanonicalUtil.findClaimPolicyCoverageByBenefitCodeSumCategory(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(),
					working.getPlanId(), working.getPlanCoverageNo(), working.getBenefitCode(), sumCategory, claimCanonical);
			if (coverages != null && !coverages.isEmpty()) {
				ClaimPolicyCoverage claimPolicyCoverage = coverages.get(0);
				if (claimPolicyCoverage.getBenefitAmount().compareTo(BigDecimal.ONE) != 0) {
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("// Calculate Rebursement %, Unit8 ");
						working.getCalculationLogger().debug("Parameters: EligibleAmt={},BenefitAmount={}", elegibleAmt, claimPolicyCoverage.getBenefitAmount());
					}
					if (helper.isEnableTransactionLogging()) {
						TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C320, claimPolicyCoverage.getBenefitAmount().multiply(BigDecimal.valueOf(100)), elegibleAmt, elegibleAmt.multiply(claimPolicyCoverage.getBenefitAmount()).setScale(2, RoundingMode.HALF_UP));
					}
					// bug fix: 2017/07/19 wrong computation
					elegibleAmt = elegibleAmt.multiply(claimPolicyCoverage.getBenefitAmount()).setScale(2, RoundingMode.HALF_UP);
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("EligibleAmt={} After Recalculated", elegibleAmt);
					}
				}
			}
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Recalculating EligbleAmt={} after deduction done(if any).", elegibleAmt);
		}
		PreviousClaimPaymentAllocation limit = checkMaxLimit(claimCanonical, working, working.getPolicyNo(), working.getProductCode(), working.getPlanId(), working.getPlanCoverageNo(),
				working.getBenefitCode(), elegibleAmt, daysAllocated, helper.isEnableTransactionLogging());

		// set output
		if (working.getPresentedAmt().compareTo(BigDecimal.ZERO) > 0) {
			working.setEligibleAmt(limit.getAmountAllocated().min(working.getPresentedAmt()));
		} else {
			working.setEligibleAmt(limit.getAmountAllocated());
		}
		working.setReimbursedDay(limit.getDaysAllocated() == null ? 0 : limit.getDaysAllocated());
		working.setReimbusrsedCall(limit.getCallAllocated() == null ? 0 : limit.getCallAllocated());

		// December 07 2017, Set Call allocated to ReimbursedDay - Wittaya/Sarunya onsite
		if (working.getReimbusrsedCall() > 0) {
			working.setReimbursedDay(working.getReimbusrsedCall());
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Setting ReimbursedDay={} from ReibursedCall={}", working.getReimbursedDay(), working.getReimbusrsedCall());
			}
		}
		// if nothing allocated
		if (working.getEligibleAmt().compareTo(BigDecimal.ZERO) <= 0) {
			working.setReimbursedDay(0);
			working.setReimbusrsedCall(0);
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Nothing allocated so resetting AllocatedDay/ReimbursedCall to ZERO");
			}
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("Final Value EligibleAmt={},AllocatedDay={},ReimbursedCall={}", working.getEligibleAmt(), working.getReimbursedDay(), working.getReimbusrsedCall());
		}

	}

	/**
	 * Section 5.1.3.5 Payment Allocation Specs v2.6
	 * @param claimCanonical
	 * @param working
	 * @return
	 */
	private PreviousClaimPaymentAllocation checkMaxLimit(
			ClaimCanonical claimCanonical,
			PaymentAllocationTemp working,
			String policyNo,
			String productCode,
			Long planId,
			String planCoverageNo,
			String benefitCode,
			BigDecimal presentedAmt,
			Integer presentedDays,
			Boolean transactionLogEnable) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		PreviousCurrentAllocationHelper helper = working.getPreviousCurrentAllocationHelper();
		PreviousClaimPaymentAllocation result = new PreviousClaimPaymentAllocation();

		BigDecimal reimbursedAmt = presentedAmt.multiply(BigDecimal.ONE);
		Integer reimbursedDays = presentedDays;

		result.setAmountAllocated(reimbursedAmt);
		result.setDaysAllocated(reimbursedDays);
		result.setCallAllocated(0);

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().debug("CheckMaxLimit Parameters : PolicyNo={},ProductCode={},PlanId={},PlanCoverageNo={},BenefitCode={},PresentedAmt={},PresentedDays={}", policyNo,
					productCode, planId, planCoverageNo, benefitCode, presentedAmt, presentedDays);
		}

		List<ClaimPolicyCoverage> claimPolicyCoverages = ClaimCanonicalUtil.findClaimPolicyCoverageByBenefitCodeSumCategory(working.getClaimNo(), working.getOccurence(), policyNo,
				working.getProductCode(), working.getPlanId(), working.getPlanCoverageNo(), benefitCode, "A,C,X".split(","), claimCanonical);

		if (claimPolicyCoverages != null) {

			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Found ({}) Matching ClaimPolicyCoverage", claimPolicyCoverages.size());
			}

			if (CollectionUtils.isEmpty(claimPolicyCoverages)) {
				// no matching claimpolicycoverage
				result.setAmountAllocated(BigDecimal.ZERO);
				result.setDaysAllocated(0);
				result.setCallAllocated(0);
				return result;
			}

			Collections.sort(claimPolicyCoverages, new ClaimPolicyCoverageComparator());
			for (ClaimPolicyCoverage cpc : claimPolicyCoverages) {

				if (working.isCalculationLoggerEnabled()) {
					if (SumCategory.A.toString().equalsIgnoreCase(cpc.getSumCategory())) {
						// Amount
						working.getCalculationLogger().debug("------------------------");
						working.getCalculationLogger().debug("Setting Limit For Amount");
						working.getCalculationLogger().debug("------------------------");
					} else if (working.getPresentedNosOfDays() != null) {
						// Days
						working.getCalculationLogger().debug("------------------------");
						working.getCalculationLogger().debug("Setting Limit For Days");
						working.getCalculationLogger().debug("------------------------");
					} else {
						// Calls
						working.getCalculationLogger().debug("------------------------");
						working.getCalculationLogger().debug("Setting Limit For Calls");
						working.getCalculationLogger().debug("------------------------");
					}
				}

				Boolean printQuery = cpc.equals(claimPolicyCoverages.get(0));
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("CheckMaxLimit Parameters : SumCategory={},ProRateInd={},SumTimeFrame={},ShareLevel={},BenefitAmt={},BenefitUnit={},AccumulatorNo={},FamilyShareInd={}", cpc.getSumCategory(),
							cpc.getProRateInd(), cpc.getSumTimeFrame(), cpc.getShareLevel(), cpc.getBenefitAmount(), cpc.getBenefitUnit(), cpc.getAccumulatorNo(), cpc.getFamilyShareInd());
				}
				BigDecimal proRate = BigDecimal.ONE;

				// log parameters
				if (transactionLogEnable) {
					TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C301, cpc.getBenefitCode(), cpc.getSumCategory(), cpc.getBenefitAmount(), cpc.getSumTimeFrame(), cpc.getProRateInd(), cpc.getAccumulatorNo(), cpc.getShareLevel(), cpc.getFamilyShareInd(), cpc.getFullCreditInd());
				}

				// 3.1 Calculate Prorate
				if ("Y".equalsIgnoreCase(cpc.getProRateInd()) && SumTimeFrame.P.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {

					// Temporarily use ClaimPolicyPlan.PlanIssueDt as Insured.MemberEffectiveDate since Insured.MemberEffectiveDt was previously not set on writeClaim() and also the existing/created claims can be use for testing without the need to create new claims. This value will be the same as the Insured.MemberEffecitive anyway
					// insured
					Insured insured = ClaimCanonicalUtil.findInsuredByPolicyNo(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), claimCanonical);
					//					ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), claimCanonical) ;
					Date memberEffectiveDate = null;
					Date benefitEffectiveDate = cpc.getEffectiveDt();

					Long max1 = null;
					if (insured != null && insured.getInitialEffectiveDt() != null) {
						//					if(claimPolicyPlan != null &&  claimPolicyPlan.getPlanIssueDt() != null )  {
						memberEffectiveDate = insured.getInitialEffectiveDt();
						//						memberEffectiveDate = claimPolicyPlan.getPlanIssueDt() ;
						if (benefitEffectiveDate != null) {
							max1 = Math.max(memberEffectiveDate.getTime(), benefitEffectiveDate.getTime());
						} else {
							max1 = memberEffectiveDate.getTime();
						}
					} else {
						// set max1= cpc.getEffectiveDt if not null ;
						if (benefitEffectiveDate != null) {
							max1 = benefitEffectiveDate.getTime();
						}
					}

					// claimpolicy
					ClaimPolicy claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(),
							working.getProductCode(), working.getCompanyId(), claimCanonical);
					Date policyYearFromDate = claimPolicy.getPolicyYearFromDt();
					Date policyYearToDate = claimPolicy.getPolicyYearToDt();

					if ((policyYearFromDate == null && max1 == null) || policyYearToDate == null) {
						// should not happen. 
						if (working.isCalculationLoggerEnabled()) {
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("Parameters to determine the ProRate cannot be calculated since required parameters are null. Setting ProRate=1 instead.");
								working.getCalculationLogger().debug("MemberEffectiveDate={},BenefitEffectiveDate={},PolicyYearFromDate={},PolicyYearToDate={}",
										memberEffectiveDate, benefitEffectiveDate, policyYearFromDate, policyYearToDate);
							}
						}
					} else {
						Long maxDate = null;
						if (policyYearFromDate != null && max1 != null) {
							maxDate = Math.max(max1, policyYearFromDate.getTime());
						} else if (max1 != null) {
							maxDate = max1;
						} else {
							maxDate = policyYearFromDate.getTime();
						}

						Calendar cal = Calendar.getInstance();
						cal.setTimeInMillis(maxDate);
						// prorate should be calculated by days instead of months. - Charles
						//					int monthDiff = getMonthDifference(cal.getTime(), policyYearToDate);
						long daysDiff = (policyYearToDate.getTime() - cal.getTime().getTime()) / 86400000;
						// add end date
						daysDiff++;
						BigDecimal days = BigDecimal.valueOf(daysDiff).setScale(5);
						// check if leap year
						int dayInAYear = 365;
						if (daysDiff == 366L) {
							// add one more calendar day
							dayInAYear++;
						}

						proRate = days.divide(BigDecimal.valueOf(dayInAYear), 10, RoundingMode.HALF_UP);

						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("CheckMaxLimit Parameters : MemberEffectiveDate(Insured)={},BenefitEffectiveDate={},PolicyYearFromDate={},PolicyYearToDate={}",
									memberEffectiveDate, benefitEffectiveDate, policyYearFromDate, policyYearToDate);
							working.getCalculationLogger().debug("DaysDifference= PolicyYearToDate - Max(MemberEffectiveDate,BenefitEffectiveDate,PolicyYearFromDate) ");
							working.getCalculationLogger().debug("DaysDifference={},ProRate({})= DaysDifference/{}", days, proRate, dayInAYear);
						}
					}
				}

				BigDecimal maxBenefitAmount = cpc.getBenefitAmount().multiply(proRate).setScale(2, RoundingMode.HALF_UP);
				int maxBenefitUnit = proRate.multiply(cpc.getBenefitAmount()).setScale(0, RoundingMode.UP).intValue();
				BigDecimal allocatedPercentage = working.getPresentedPercentage();
				
				// log prorate
				if ("Y".equalsIgnoreCase(cpc.getProRateInd()) && SumTimeFrame.P.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {
					if (transactionLogEnable) {
						if ("A".equals(cpc.getSumCategory())) {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C302, proRate, cpc.getBenefitAmount(), maxBenefitAmount, "Baht");
						} else {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C302, proRate, cpc.getBenefitAmount(), String.valueOf(maxBenefitUnit), "Call/Days");
						}

					}
				}

				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("CheckMaxLimit Parameters : MaxBenefitAmt={},MaxBenefitUnit={},ProRate={},SumCategory={},SumTimeFrame={}", maxBenefitAmount, maxBenefitUnit, proRate, cpc.getSumCategory(), cpc.getSumTimeFrame());
				}
				if (logger.isDebugEnabled()) {
					logger.debug("Parameters set for computation: benefitCode={}, maxBenefitAmt={},maxBenefitUnit={},prorate={},SumCategory={},SumTimeFrame={},BenefitAmt={},BenefitUnit={}", working.getBenefitCode(), maxBenefitAmount, maxBenefitUnit, proRate,
							cpc.getSumCategory(), cpc.getSumTimeFrame(), cpc.getBenefitAmount(), cpc.getBenefitUnit());
				}

				//3.3	For Surgery, apply Surgical Rate %
				if (ClaimCalculationEnum.BusinessLine.CS.toString().equals(working.getBusinessLine()) && working.getIcd9category().getSurgicalPercentage() != null && working.getIcd9category().getSurgicalPercentage().compareTo(BigDecimal.ZERO) > 0) {
					// 03/07/2018 apply only surgical percentage for productCode=30100 and benefitcode='H05' -Wittaya onsite.
					Boolean forSurgical = Arrays.asList("30100").contains(working.getProductCode()) && BenefitCode.H05.toString().equals(working.getBenefitCode());
					if (forSurgical) {
						maxBenefitAmount = cpc.getBenefitAmount().multiply(proRate).multiply(working.getIcd9category().getSurgicalPercentage().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("CheckMaxLimit Parameters : ReComputed MaxBenefitAmt={},SurgicalPercentage={}", maxBenefitAmount,
									working.getIcd9category().getSurgicalPercentage());
						}
						if (transactionLogEnable) {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C304, working.getIcd9category().getSurgicalPercentage(), maxBenefitAmount);
						}
					}
				}
				
				// For Surgery HSOLD
				if (ClaimCalculationEnum.BusinessLine.GE.toString().equals(working.getBusinessLine()) && allocatedPercentage != null) {
					if (Arrays.asList("30100").contains(working.getProductCode()) && BenefitCode.H05.toString().equals(working.getBenefitCode())) {
						//maxBenefitAmount = cpc.getBenefitAmount().multiply(proRate).multiply(allocatedPercentage.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
						maxBenefitAmount = cpc.getBenefitAmount().multiply(proRate).multiply(allocatedPercentage).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
						working.setPercentageAllocated(allocatedPercentage);
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("CheckMaxLimit Parameters : ReComputed MaxBenefitAmt={},Surgical30100Percentage={}", maxBenefitAmount,
									allocatedPercentage);
						}
						if (transactionLogEnable) {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C304, allocatedPercentage, maxBenefitAmount);
						}
					}
				}

				if (SumCategory.A.toString().equalsIgnoreCase(cpc.getSumCategory())) {
					// setting limit is per day
					BigDecimal amountPerDayFactor = cpc.getBenefitAmount();
					if (result.getDaysAllocated() != null && result.getDaysAllocated() > 0 && (SumTimeFrame.D.toString().equalsIgnoreCase(cpc.getSumTimeFrame()) || SumTimeFrame.C.toString().equalsIgnoreCase(cpc.getSumTimeFrame()))) {

						if (BenefitCode.H03.toString().equals(working.getBenefitCode())) {
							// ICU days
							BigDecimal ratePerDay = presentedAmt.divide(BigDecimal.valueOf(claimCanonical.getClaim().getDayOfAdmitIcu()), 7, RoundingMode.HALF_UP);
							amountPerDayFactor = ratePerDay;
							if (!helper.getH03ExcessAmtList().contains(working.getCurrentClaimBenefitItemKey())) {
								helper.getH03ExcessAmtList().add(working.getCurrentClaimBenefitItemKey());
								helper.setExcessCSICUDays(working.getPresentedNosOfDays() - result.getDaysAllocated());
							}
							helper.setCurrentICUDays(result.getDaysAllocated());
						} else {
							if (!CASH_BENEFIT_SERVICECATID.equals(working.getServiceCatId())) {
								amountPerDayFactor = presentedAmt.divide(BigDecimal.valueOf(working.getPresentedNosOfDays()), 7, RoundingMode.HALF_UP);
								CSPresentedAmtMetaData metaData = working.getPreviousCurrentAllocationHelper().getMetaData(working);
								if (metaData != null) {
									//  Daily Rate
									BigDecimal ratePerDay = amountPerDayFactor;
									metaData.setRatePerDay(ratePerDay);
									metaData.setMaxRatePerDay(cpc.getBenefitAmount());
								}

							}
						}

						// amountPerDayFactor should not be more than 
						if (amountPerDayFactor.compareTo(cpc.getBenefitAmount()) > 0) {
							// should not exceed maximum amount
							amountPerDayFactor = cpc.getBenefitAmount();
						}

						// I01 w/ ProductCode='30100','30111','30112','30128','30129'  or IT0
						Boolean isProductCodesForI01 = Arrays.asList("30111", "30112", "30128", "30129").contains(working.getProductCode());
						if ((BenefitCode.I01.toString().equals(working.getBenefitCode()) && isProductCodesForI01) || BenefitCode.IT0.toString().equals(working.getBenefitCode())) {
							BigDecimal totalH01AllocatedAmt = helper.getTotalEligibleAmtForBenefitCode(BenefitCode.H01.toString(), working);
							BigDecimal totalH03AllocatedAmt = helper.getTotalEligibleAmtForBenefitCode(BenefitCode.H03.toString(), working);
							reimbursedAmt = amountPerDayFactor.multiply(BigDecimal.valueOf(result.getDaysAllocated())).subtract(totalH01AllocatedAmt.add(totalH03AllocatedAmt)).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
							if (reimbursedAmt.compareTo(BigDecimal.ZERO) > 0) {
								// additional logic - only calculates if Treatment Type is IPD - 2018/04/10 Wittaya
								List<String> ipdTreatmentTypes = commonCodeRepository.findCommonCodeByCategoryCodeDescription("TreatmentType", "IPD");
								Boolean isIPD = CollectionUtils.isNotEmpty(ipdTreatmentTypes) && ipdTreatmentTypes.contains(claimCanonical.getClaim().getTreatmentType());

								// additional logic - 03/23/2018. Don't allocate if has allocation to other benefit except H01 & H03.
								if (helper.hasNotAllocatedToOtherBenefits() && isIPD) {
									// only apply if this formula if some value allocated to H01/H03 -Wittaya 2018/03/08
									if (working.isCalculationLoggerEnabled()) {
										working.getCalculationLogger().debug("New ReimbursedAmt={} after {} benefit deducted H01 AllocatedAmt({}) + H03 AllocatedAmt({})", reimbursedAmt, working.getBenefitCode(), totalH01AllocatedAmt, totalH03AllocatedAmt);
									}
								} else {
									if (working.isCalculationLoggerEnabled()) {
										working.getCalculationLogger().debug("Has allocation to other benefit aside from H01/H03. Will not allocate this benefit");
									}
									if (transactionLogEnable) {
										TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C317, working.getBenefitCode());
									}
									reimbursedAmt = BigDecimal.ZERO;
								}
							}
							if (claimCanonical.getClaim().getCsHBAmt() != null && claimCanonical.getClaim().getCsHBAmt().compareTo(BigDecimal.ZERO) > 0) {
								reimbursedAmt = claimCanonical.getClaim().getCsHBAmt();
								result.setAmountAllocated(reimbursedAmt);
								if (transactionLogEnable) {
									TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C318, working.getBenefitCode(), reimbursedAmt);
								}
								continue;
							}

						} else {
							reimbursedAmt = amountPerDayFactor.multiply(BigDecimal.valueOf(result.getDaysAllocated())).setScale(2, RoundingMode.HALF_UP);
						}
						result.setAmountAllocated(reimbursedAmt);
						maxBenefitAmount = cpc.getBenefitAmount().multiply(proRate).multiply(BigDecimal.valueOf(result.getDaysAllocated())).setScale(2, RoundingMode.HALF_UP);

						if (BenefitCode.H50.toString().equals(working.getBenefitCode())) {
							// apply Reimbursed % on maxlimit -sarunya
							String[] sumCategory = { SumCategory.R.toString() };
							List<ClaimPolicyCoverage> coverages = ClaimCanonicalUtil.findClaimPolicyCoverageByBenefitCodeSumCategory(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(),
									working.getPlanId(), working.getPlanCoverageNo(), working.getBenefitCode(), sumCategory, claimCanonical);
							if (coverages != null && !coverages.isEmpty()) {
								ClaimPolicyCoverage claimPolicyCoverage = coverages.get(0);
								maxBenefitAmount = cpc.getBenefitAmount().multiply(claimPolicyCoverage.getBenefitAmount()).multiply(BigDecimal.valueOf(result.getDaysAllocated())).setScale(2, RoundingMode.HALF_UP);
								reimbursedAmt = reimbursedAmt.multiply(claimPolicyCoverage.getBenefitAmount()).setScale(2, RoundingMode.HALF_UP);
							}
						}

					}

					if (BenefitCode.HE1.toString().equals(working.getBenefitCode())) {

						ClaimPolicyCoverage claimPolicyCoverage = null;
						String sumCategory[] = { SumCategory.R.toString() };
						List<ClaimPolicyCoverage> coverages = ClaimCanonicalUtil.findClaimPolicyCoverageByBenefitCodeSumCategory(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(),
								working.getPlanId(), working.getPlanCoverageNo(), working.getBenefitCode(), sumCategory, claimCanonical);
						if (coverages != null && !coverages.isEmpty()) {
							claimPolicyCoverage = coverages.get(0);
						}
						/*
						if ((working.getPresentedNosOfDays() != null && working.getPresentedNosOfDays() > 0) || working.getPreviousCurrentAllocationHelper().isRollOverFromH01(working) && working.getPreviousCurrentAllocationHelper().getExcessDaysFromH03H01() > 0) {
							BigDecimal rollOverAmtFromH01 = BigDecimal.valueOf(working.getPreviousCurrentAllocationHelper().getExcessDaysFromH03H01()).multiply(working.getPreviousCurrentAllocationHelper().getH01TotalDailyRate(claimCanonical));
							// apply ReimbursedPercentage on the rollover Amt
							if (claimPolicyCoverage != null) {
								if (working.isCalculationLoggerEnabled()) {
									working.getCalculationLogger().debug("Reimbursedment Percentage appllied to RollOverBenefitAmt={} , Percentage={}, allowedAmt to HE={}", rollOverAmtFromH01, claimPolicyCoverage.getBenefitAmount(), rollOverAmtFromH01.multiply(claimPolicyCoverage.getBenefitAmount()));
								}
								rollOverAmtFromH01 = rollOverAmtFromH01.multiply(claimPolicyCoverage.getBenefitAmount()).setScale(2, RoundingMode.HALF_UP);
							}
						
							BigDecimal comingFromH01Amt = helper.getHE1AllocatedComingFromH01(working);
							// For HE1, if PresentedNosOfDays is present, then reimbursedAMT will be recomputed as MaxBenefitAmount = H01 Rate Per Day x nos Of Days 
							reimbursedAmt = presentedAmt.min(rollOverAmtFromH01.subtract(comingFromH01Amt).max(BigDecimal.ZERO)).setScale(2, RoundingMode.HALF_UP);
						
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug(" HE1 adjusted Eligible Amt({}) : Min ( H01_RolloverAmt({}) + CurrentAllocatedToHE1FromH01({}) , MaxBenefitAmt({}) , PresentedAmt({} )", reimbursedAmt, rollOverAmtFromH01, comingFromH01Amt,
										maxBenefitAmount, presentedAmt);
							}
						}  else { */
						if (claimPolicyCoverage != null) {
							reimbursedAmt = reimbursedAmt.multiply(claimPolicyCoverage.getBenefitAmount()).setScale(2, RoundingMode.HALF_UP);
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug(" Applied Reimbursed % Eligible Amt({})  =  PresentedAmt({}) x percentage({}) ", reimbursedAmt, presentedAmt, claimPolicyCoverage.getBenefitAmount());
							}

						}
						//						}

					}
					if (working.isCalculationLoggerEnabled()) {
						if (amountPerDayFactor.compareTo(cpc.getBenefitAmount()) != 0) {
							working.getCalculationLogger().debug("Daily rate used is less than ClaimPolicyCoverage.MaxBenefitAmt={}. Will be using Daily Rate of {} instead. Excess Amt( if applicable(eg. ICU) ) will be added to standard Room.",
									cpc.getBenefitAmount(), amountPerDayFactor);
							working.getCalculationLogger().debug("Setting Limit for SumCategory={},SumTimeFrame={}", cpc.getSumCategory(), cpc.getSumTimeFrame());
							working.getCalculationLogger().debug("CheckMaxLimit Parameters : ReComputed MaxBenefitAmt={},MaxBenefitUnit={}", maxBenefitAmount, maxBenefitUnit);
						} else {
							working.getCalculationLogger().debug("Setting Limit for SumCategory={},SumTimeFrame={}", cpc.getSumCategory(), cpc.getSumTimeFrame());
							working.getCalculationLogger().debug("CheckMaxLimit Parameters : ReComputed MaxBenefitAmt={},MaxBenefitUnit={}", maxBenefitAmount, maxBenefitUnit);
						}
					}

				}

				// generate query
				StringBuilder strSummaryQuery = new StringBuilder();
				// for ClaimHistory/ClaimPaymentDetailHistory
				StringBuilder strSummaryQueryHistorical = new StringBuilder();
				// For Amounts or Days 
				if (SumCategory.A.toString().equalsIgnoreCase(cpc.getSumCategory()) || SumCategory.C.toString().equalsIgnoreCase(cpc.getSumCategory())) {

					String strSummaryObj = "";
					if (SumCategory.A.toString().equalsIgnoreCase(cpc.getSumCategory())) {
						// 2019/08/08 bug fix. shortfall amout incorrect calculation. Should be applicable not only for FullCredit
						strSummaryObj = "nvl(SUM (cpd.eligibleAmt) - SUM(cpd.shortfallamt),0) as @@ID@@";
						strSummaryQuery.append("select " + strSummaryObj + " from ClaimPaymentDetail cpd ");
						/*
						if (cpc.getAccumulatorNo() != null) {
							strSummaryQuery = new StringBuilder();
							strSummaryQuery.append("select " + strSummaryObj
									+ " from ClaimPaymentAccumulator cpa inner join ClaimPaymentDetail cpd on cpa.companyId=cpd.companyId and cpa.claimNo=cpd.claimNo and cpa.occurrence=cpd.occurrence and cpa.policyNo=cpd.policyNo and cpa.productCode=cpd.productCode and cpa.planId=cpd.planId and ( cpa.planCoverageNo=cpd.planCoverageNo or (cpa.planCoverageNo is null and cpd.planCoverageNo is null ) ) and cpa.benefitCode=cpd.benefitCode ");
						}
						*/
						strSummaryQuery.append(" inner join Claim cl on cpd.companyId=cl.companyId and cpd.claimNo=cl.claimNo and cpd.occurrence=cl.occurrence ");
						strSummaryQueryHistorical.append("select " + strSummaryObj + " from ClaimPaymentDetailHistory cpd  inner join ClaimHistory cl on cpd.claimNo=cl.claimNo and cpd.occurrence=cl.occurrence ");
					} else {
						if (working.getPresentedNosOfDays() != null) {
							// if reimbursedDays is set, this means get the numberOfDays else treat as # of call
							strSummaryObj = "nvl(SUM (cpd.reimbursedDay),0) as @@ID@@";// days
							strSummaryQuery.append("select " + strSummaryObj + " from ClaimPaymentDetail cpd ");
							/*
							if (cpc.getAccumulatorNo() != null) {
								strSummaryQuery = new StringBuilder();
								strSummaryQuery.append("select " + strSummaryObj
										+ " from ClaimPaymentAccumulator cpa inner join ClaimPaymentDetail cpd on cpa.companyId=cpd.companyId and cpa.claimNo=cpd.claimNo and cpa.occurrence=cpd.occurrence and cpa.policyNo=cpd.policyNo and cpa.productCode=cpd.productCode and cpa.planId=cpd.planId and ( cpa.planCoverageNo=cpd.planCoverageNo or (cpa.planCoverageNo is null and cpd.planCoverageNo is null ) ) and cpa.benefitCode=cpd.benefitCode ");
							} */
							strSummaryQuery.append(" inner join Claim cl on cpd.companyId=cl.companyId and cpd.claimNo=cl.claimNo and cpd.occurrence=cl.occurrence ");
							strSummaryQueryHistorical.append("select " + strSummaryObj + " from ClaimPaymentDetailHistory cpd  inner join ClaimHistory cl on cpd.claimNo=cl.claimNo and cpd.occurrence=cl.occurrence ");
						} else {
							// Calls
							strSummaryQuery.append(
									"select count(*) as @@ID@@ from ( select distinct cpd.companyId,cl.claimId  from ClaimPaymentDetail cpd inner join Claim cl on cpd.companyId=cl.companyId and cpd.claimNo=cl.claimNo and cpd.occurrence=cl.occurrence ");
							/*
							if (cpc.getAccumulatorNo() != null) {
								strSummaryQuery = new StringBuilder();
								strSummaryQuery.append(
										"select count(*) as @@ID@@ from (  select distinct cpa.companyId,cl.claimId from ClaimPaymentAccumulator cpa inner join ClaimPaymentDetail cpd on cpa.companyId=cpd.companyId and cpa.claimNo=cpd.claimNo and cpa.occurrence=cpd.occurrence and cpa.policyNo=cpd.policyNo and cpa.productCode=cpd.productCode and cpa.planId=cpd.planId and ( cpa.planCoverageNo=cpd.planCoverageNo or (cpa.planCoverageNo is null and cpd.planCoverageNo is null ) ) and cpa.benefitCode=cpd.benefitCode inner join Claim cl on cpd.companyId=cl.companyId and cpd.claimNo=cl.claimNo and cpd.occurrence=cl.occurrence ");
							} */
							strSummaryQueryHistorical.append("select distinct cl.claimNo || '|' || cl.occurrence from ClaimPaymentDetailHistory cpd inner join ClaimHistory cl on  cl.claimNo=cpd.claimNo  and cl.occurrence=cpd.occurrence ");
						}
					}
				}

				// 3.5 calculate
				Boolean hasAccumulatorNo = false;
				List<ClaimPolicyCoverage> historicalCPCs = new ArrayList<ClaimPolicyCoverage>();
				if (cpc.getAccumulatorNo() == null) {
					historicalCPCs.add(cpc);
				} else {
					hasAccumulatorNo = true;
					List<ClaimPolicyCoverage> cpcsWithSameAccumulatorSumCategory = ClaimCanonicalUtil.findClaimPolicyCoverageBySumCategoryAccumulatorNo(working.getClaimNo(), working.getOccurence(), cpc.getAccumulatorNo(), cpc.getSumCategory(), claimCanonical);
					historicalCPCs.addAll(cpcsWithSameAccumulatorSumCategory);
				}
				// Check H04/H12 pairing and if there is a valid procedurecode in this claim
				if(!"30100".equals(cpc.getProductCode())){
					if (hasAccumulatorNo && BenefitCode.H12.toString().equals(working.getBenefitCode())) {
						String icd9CodeCat = working.getIcd9category().getIcd9Category();
						List<String> procedureCats = Arrays.asList(ProcedureCategory.Complex.toString(), ProcedureCategory.Intermediate.toString(), ProcedureCategory.Major.toString(), ProcedureCategory.Minor.toString());
						List<String> filteredBenefits = new ArrayList<String>();
						if (procedureCats.contains(icd9CodeCat)) {
							// check if H04 is present
							filteredBenefits.add(BenefitCode.H04.toString());
						} else {
							// check H08/HN8/HD8/HM8/HC8
							filteredBenefits = Arrays.asList(BenefitCode.H08.toString(), BenefitCode.HN8.toString(), BenefitCode.HD8.toString(), BenefitCode.HM8.toString(), BenefitCode.HC8.toString());
						}
						if (CollectionUtils.isNotEmpty(filteredBenefits)) {
							Boolean ignoreThisAccumulatorNo = false;
							String ignoredBenefit = null;
							for (ClaimPolicyCoverage h12Cpc : historicalCPCs) {
								if (filteredBenefits.contains(h12Cpc.getBenefitCode())) {
									ignoreThisAccumulatorNo = true;
									ignoredBenefit = h12Cpc.getBenefitCode();
									break;
								}
							}
							if (ignoreThisAccumulatorNo) {
								if (logger.isDebugEnabled()) {
									logger.debug("Found H12/{} pairing. Will ignore limit check for this accumulator No: {}", ignoredBenefit, cpc.getAccumulatorNo());
								}
								if (working.isCalculationLoggerEnabled()) {
									logger.debug("Found H12/{} pairing. Will ignore limit check for this accumulator No: {}", ignoredBenefit, cpc.getAccumulatorNo());
								}
								continue;
							}
						}
	
					}
			    }
				if (SumCategory.A.toString().equalsIgnoreCase(cpc.getSumCategory())) {
					BigDecimal totalPrevReimbursedAmt = BigDecimal.ZERO;
					BigDecimal totalOldSystemPrevReimbursedAmt = BigDecimal.ZERO;
					for (ClaimPolicyCoverage matchingCPC : historicalCPCs) {

						// Apr 12, 2018. If Sumcategory='C' , no need to look for previous amount. Per call means per occurrence
						if ("C".equals(cpc.getSumTimeFrame())) {
							break;
						}
						List<Object> parameters = new ArrayList<Object>();
						// claimpaymentdetail
						// align with OL to check previous settled records
						String withExtraJoin = strSummaryQuery.toString() + " inner join ClaimPayment cp on cpd.companyId=cp.companyId and cpd.claimNo=cp.claimNo and cpd.occurrence=cp.occurrence and cpd.policyno=cp.policyno and cpd.productCode=cp.productCode ";
						StringBuilder whereCondition = getWhereCondition(claimCanonical, working, sdf, matchingCPC, hasAccumulatorNo, false, parameters);
						String query1 = withExtraJoin + whereCondition.toString() + " and cp.paymentStatus IN ('50', '70')";

						if (logger.isDebugEnabled() && printQuery) {
							logger.debug("CS FORMULA Previous Reimbursed/Call QUERY: {}", query1.toString());
						}

						Map<String, Object> totalPrevReimbursedAmtMap = claimPaymentDetailRepository.performCheckLimit(printQuery, query1, parameters, "totalPrevReimbursedAmt");
						if (!totalPrevReimbursedAmtMap.isEmpty() && totalPrevReimbursedAmtMap.get("totalPrevReimbursedAmt") != null) {
							BigDecimal usedAmt = (BigDecimal) totalPrevReimbursedAmtMap.get("totalPrevReimbursedAmt");
							if (logger.isDebugEnabled()) {
								logger.debug("Previous Amt Used for BenefitCode: {} = {}, AccumulatorNo={}", matchingCPC.getBenefitCode(), usedAmt, cpc.getAccumulatorNo());
							}
							totalPrevReimbursedAmt = totalPrevReimbursedAmt.add(usedAmt);
						}
						// claimpaymentdetailhistory
						parameters = new ArrayList<Object>();
						whereCondition = getWhereCondition(claimCanonical, working, sdf, matchingCPC, hasAccumulatorNo, true, parameters);
						String historyQueryData = strSummaryQueryHistorical.toString() + whereCondition;
						historyQueryData += " and cpd.claimno||'|'||cpd.occurrence not in (select claimno||'|'||occurrence from claim where claimno=? and companyId =?)";
						parameters.add(claimCanonical.getClaim().getClaimNo() );
						parameters.add(claimCanonical.getClaim().getCompanyId());
						Map<String, Object> totalOldSystemPrevReimbursedAmtMap = claimPaymentDetailRepository.performCheckLimit(printQuery, historyQueryData,parameters, "totalOSPrevReimbursedAmt");

						if (!totalOldSystemPrevReimbursedAmtMap.isEmpty() && totalOldSystemPrevReimbursedAmtMap.get("totalOSPrevReimbursedAmt") != null) {
							BigDecimal amtUsed = (BigDecimal) totalOldSystemPrevReimbursedAmtMap.get("totalOSPrevReimbursedAmt");
							if (logger.isDebugEnabled()) {
								logger.debug("Previous Compass Used for BenefitCode: {} = {}, AccumulatorNo={}", matchingCPC.getBenefitCode(), amtUsed, cpc.getAccumulatorNo());
							}
							totalOldSystemPrevReimbursedAmt = totalOldSystemPrevReimbursedAmt.add(amtUsed);
						}

					}

					PreviousClaimPaymentAllocation totalCurrentReimbursedAmt = helper.getCurrentAllocatedAmtByLevelLimit(cpc.getShareLevel(), cpc.getAccumulatorNo(), working.getBenefitCode(),
							working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getProductCode(), working);

					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("//Amount SumCategory");
						working.getCalculationLogger().debug("PreviousRemibursedAmt(Cmic:{},Compass:{})={},CurrentReimbursedAmt={}", totalPrevReimbursedAmt, totalOldSystemPrevReimbursedAmt, totalPrevReimbursedAmt.add(totalOldSystemPrevReimbursedAmt), totalCurrentReimbursedAmt.getAmountAllocated());
					}

					totalPrevReimbursedAmt = totalPrevReimbursedAmt.add(totalOldSystemPrevReimbursedAmt);
					if (ClaimCalculationEnum.BusinessLine.CS.toString().equals(working.getBusinessLine()) && totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated()).compareTo(maxBenefitAmount) >= 0 && (result.getDaysAllocated() == null || result.getDaysAllocated() == 0) && (result.getCallAllocated() == null || result.getCallAllocated() == 0)) {
							result.setAmountAllocated(BigDecimal.ZERO);
							result.setDaysAllocated(0);
							// limit reached
							working.setLimitReached(true);
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("Formula: PreviousRemibursedAmt + CurrentReimbursedAmt > MaxBenefitAmt, EligibleAmt=0,DaysAllocated=0");
							}
							// log
							if (transactionLogEnable) {
								TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C400, working.getClaimNoForLogging(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(), working.getBenefitCode(),
										cpc.getBenefitAmount(), totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated()), presentedAmt, result.getAmountAllocated(),
										("Y".equalsIgnoreCase(cpc.getFullCreditInd())) ? presentedAmt.subtract(result.getAmountAllocated()).max(BigDecimal.ZERO) : BigDecimal.ZERO, cpc.getSumTimeFrame(), result.getDaysAllocated());
							}
							return result;
					} else {

						if (BenefitCode.H01.toString().equals(working.getBenefitCode()) && helper.isCurrentAllocationIsICUService(working) && helper.getExcessCSICUDays() == 0) {
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("H01 will not be allocated for this service{} since there is no H03/ICU excessdays!", working.getServiceCatId());
							}
							if (transactionLogEnable) {
								TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C322, working.getBenefitCode(), working.getServiceCatId());
							}
							result.setDaysAllocated(0);
							result.setAmountAllocated(BigDecimal.ZERO);
							return result;
						}
						if (((result.getDaysAllocated() != null && result.getDaysAllocated() > 0) || (result.getCallAllocated() != null && result.getCallAllocated() > 0)) && Arrays.asList("D", "C").contains(cpc.getSumTimeFrame()) && !BenefitCode.HE1.toString().equals(working.getBenefitCode())) {
							// for H50, no need to include current allocated amt since the rate is already per day
							if (BenefitCode.H01.toString().equals(working.getBenefitCode()) && !"DummyService".equals(working.getServiceCatId())) {
								BigDecimal maxH01Amt = working.getPreviousCurrentAllocationHelper().getH01TotalDailyRate(claimCanonical).multiply(BigDecimal.valueOf(result.getDaysAllocated())).setScale(2, RoundingMode.HALF_UP);
								maxBenefitAmount = maxBenefitAmount.min(maxH01Amt);
							}
							if(BenefitCode.I01.toString().equals(working.getBenefitCode()) || BenefitCode.IT0.toString().equals(working.getBenefitCode())){ 
								totalPrevReimbursedAmt = BigDecimal.ZERO;
							}
							reimbursedAmt = maxBenefitAmount.subtract(totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated())).min(reimbursedAmt).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("Formula: EligibleAmt = Max ( Min ( (MaxBenefitAmt({}) - PreviousRemibursedAmt({}) + CurrentReimbursedAmt({}) ) , PresentedAmt({}) ), 0 )",
										maxBenefitAmount, totalPrevReimbursedAmt, totalCurrentReimbursedAmt.getAmountAllocated(), reimbursedAmt);
							}

							// log
							if (transactionLogEnable) {
								TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(), working.getBenefitCode(),
										cpc.getBenefitAmount(), totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated()), presentedAmt, reimbursedAmt,
										("Y".equalsIgnoreCase(cpc.getFullCreditInd())) ? presentedAmt.subtract(result.getAmountAllocated()).max(BigDecimal.ZERO) : BigDecimal.ZERO, cpc.getSumTimeFrame(), result.getDaysAllocated());
							}
						} else {
							// SumTimeFrame=P or SumtimeFrame=B should always execute below line
							if(ClaimCalculationEnum.BusinessLine.CS.toString().equals(working.getBusinessLine())){
								reimbursedAmt = maxBenefitAmount.subtract(totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated())).min(reimbursedAmt).max(BigDecimal.ZERO);
							}else if(ClaimCalculationEnum.BusinessLine.GE.toString().equals(working.getBusinessLine())){
								//BigDecimal totalAllPaidAmount =  totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated()).add(maxBenefitAmount);
								reimbursedAmt = calculatedAdjustedAmt(cpc.getBenefitAmount(),maxBenefitAmount,totalPrevReimbursedAmt, totalCurrentReimbursedAmt.getAmountAllocated(), presentedAmt);
							}
							
							if (working.isCalculationLoggerEnabled()) {
								working.getCalculationLogger().debug("Formula: EligibleAmt = Min(PresentedAmt({}),  MaxBenefitAmt({}) - (PreviousRemibursedAmt({}) + CurrentReimbursedAmt({}) ) , AllocatedAmt({}) )",
										working.getPresentedAmt(), maxBenefitAmount, totalPrevReimbursedAmt, totalCurrentReimbursedAmt.getAmountAllocated(), reimbursedAmt);
							}

							// log
							if (transactionLogEnable) {
								TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(), working.getBenefitCode(),
										cpc.getBenefitAmount(), totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt.getAmountAllocated()), presentedAmt, reimbursedAmt.min(working.getPresentedAmt()),
										("Y".equalsIgnoreCase(cpc.getFullCreditInd())) ? presentedAmt.subtract(result.getAmountAllocated()).max(BigDecimal.ZERO) : BigDecimal.ZERO, cpc.getSumTimeFrame());
							}
						}
						if(result.getAmountAllocated() != null && result.getAmountAllocated().compareTo(BigDecimal.ZERO) > 0){
							// make sure amoutAllocate will not be more than previous coverage allocation
							reimbursedAmt = result.getAmountAllocated().min(reimbursedAmt);
						}
						result.setAmountAllocated(reimbursedAmt.setScale(2, RoundingMode.HALF_UP));
						// 2018/10/24 bug fix. Check if allocat 
						if(BigDecimal.ZERO.compareTo(result.getAmountAllocated()) == 0) {
							// should not allocated further if this allocation is already zero
							result.setDaysAllocated(0);
							result.setAmountAllocated(BigDecimal.ZERO);
							return result;
						}
					}

				}

				// Treat as Days
				if (SumCategory.C.toString().equalsIgnoreCase(cpc.getSumCategory()) && working.getPresentedNosOfDays() != null) {

					// check for presentedAmt first on R&B and ICU benefit
					if (presentedAmt.compareTo(BigDecimal.ZERO) <= 0 && Arrays.asList(BenefitCode.H03.toString(), BenefitCode.H01.toString(), BenefitCode.HT1.toString(), BenefitCode.HT3.toString(), BenefitCode.HT5.toString(), BenefitCode.HT6.toString()).contains(working.getBenefitCode())) {
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("Setting DaysAllocted=0 since presentedAmt is zero.");
						}
						result.setDaysAllocated(0);
					} else {
						Integer totalPrevDayAllocated = 0;
						Integer compassPrevDayAllocated = 0;
						for (ClaimPolicyCoverage matchingCPC : historicalCPCs) {
							// align with OL to check previous settled records
							List<Object> parameters = new ArrayList<Object>();
							String withExtraJoin = strSummaryQuery.toString() + " inner join ClaimPayment cp on cpd.companyId=cp.companyId and cpd.claimNo=cp.claimNo and cpd.occurrence=cp.occurrence and cpd.policyno=cp.policyno and cpd.productCode=cp.productCode ";
							StringBuilder whereCondition = getWhereCondition(claimCanonical, working, sdf, matchingCPC, hasAccumulatorNo, false, parameters);
							String query1 = withExtraJoin + whereCondition.toString() + " and cp.paymentStatus IN ('50', '70')";

							if (logger.isDebugEnabled() && printQuery) {
								logger.debug("CS FORMULA Previous Reimbursed/Call QUERY: {}", query1.toString());
							}

							Map<String, Object> totalPrevReimbursedAmtMap = claimPaymentDetailRepository.performCheckLimit(printQuery, query1,parameters, "totalPrevDayAllocated");
							if (!totalPrevReimbursedAmtMap.isEmpty() && totalPrevReimbursedAmtMap.get("totalPrevDayAllocated") != null) {
								Integer usedDays = ((BigDecimal) totalPrevReimbursedAmtMap.get("totalPrevDayAllocated")).intValue();
								if (logger.isDebugEnabled()) {
									logger.debug("BenefitCode={} ,previous allocated days={}, AccumulatorNo={}", matchingCPC.getBenefitCode(), usedDays, cpc.getAccumulatorNo());
								}
								totalPrevDayAllocated += usedDays;
							}
							parameters = new ArrayList<Object>();
							whereCondition = getWhereCondition(claimCanonical, working, sdf, matchingCPC, hasAccumulatorNo, true, parameters);
							String historyQueryData = strSummaryQueryHistorical.toString() + whereCondition;
							historyQueryData += " and cpd.claimno||'|'||cpd.occurrence not in (select claimno||'|'||occurrence from claim where claimno=? and companyId = ?)";
							parameters.add(claimCanonical.getClaim().getClaimNo() );
							parameters.add(claimCanonical.getClaim().getCompanyId());
							Map<String, Object> totalOldSystemPrevReimbursedAmtMap = claimPaymentDetailRepository.performCheckLimit(printQuery, historyQueryData, parameters, "totaOSPrevDayAllocated");
							if (!totalOldSystemPrevReimbursedAmtMap.isEmpty() && totalOldSystemPrevReimbursedAmtMap.get("totaOSPrevDayAllocated") != null) {
								Integer usedDays = ((BigDecimal) totalOldSystemPrevReimbursedAmtMap.get("totaOSPrevDayAllocated")).intValue();
								if (logger.isDebugEnabled()) {
									logger.debug("BenefitCode={} ,previous Compass allocated days={},AccumulatorNo={}", matchingCPC.getBenefitCode(), usedDays, cpc.getAccumulatorNo());
								}
								compassPrevDayAllocated += usedDays;
							}

						}

						Integer cmicPrevDayAllocated = totalPrevDayAllocated;
						totalPrevDayAllocated += compassPrevDayAllocated;

						PreviousClaimPaymentAllocation totalCurrentDayAllocated = helper.getCurrentAllocatedAmtByLevelLimit(cpc.getShareLevel(), cpc.getAccumulatorNo(), working.getBenefitCode(),
								working.getPlanId(), working.getPolicyNo(), working.getPlanCoverageNo(), working.getProductCode(), working);

						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("//Days SumCategory");
							working.getCalculationLogger().debug("PreviousAllocatedDays(Cmic:{} , Compass:{})={},CurrentAllocatedDays={}", cmicPrevDayAllocated, compassPrevDayAllocated, totalPrevDayAllocated, totalCurrentDayAllocated.getDaysAllocated());
						}

						Integer daysAllocated = Math.min(maxBenefitUnit - totalPrevDayAllocated, working.getPresentedNosOfDays());
						if (totalCurrentDayAllocated.getDaysAllocated() > 0) {
							if (cpc.getAccumulatorNo() != null) {
								daysAllocated = Math.min(daysAllocated, maxBenefitUnit - totalPrevDayAllocated - totalCurrentDayAllocated.getDaysAllocated());
							} else {
								daysAllocated = Math.min(daysAllocated, totalCurrentDayAllocated.getDaysAllocated());
							}
						}
						if (result.getDaysAllocated() > 0) {
							// make sure it will not be more than previous coverage allocation
							daysAllocated = Math.min(daysAllocated, result.getDaysAllocated());
						}

						daysAllocated = Math.max(daysAllocated, 0);

						if (BenefitCode.H01.toString().equals(working.getBenefitCode())) {
							// bug fix 2018/11/13. LengthOfStay is not always DayOfAdmitRoom + DayOfAdmitICU
							Integer lengthOfStay = ( claimCanonical.getClaim().getDayOfAdmitRoom() + claimCanonical.getClaim().getDayOfAdmitIcu() )  - helper.getCurrentICUDays();
							working.getPreviousCurrentAllocationHelper().setExcessDaysFromH03H01(Math.max(lengthOfStay - daysAllocated, 0));
						}

						if (cpc.getAccumulatorNo() == null && ("D".equals(cpc.getSumTimeFrame()) || "B".equals(cpc.getSumTimeFrame()))) {
							CSPresentedAmtMetaData metaData = working.getPreviousCurrentAllocationHelper().getMetaData(working);
							if (metaData != null) {
								metaData.setLimitDays(daysAllocated);
								metaData.setMaxLimitDays(cpc.getBenefitAmount().intValue());
							}
						}

						if (daysAllocated == 0) {
							result.setAmountAllocated(BigDecimal.ZERO);
							result.setDaysAllocated(0);
							// limit reached
							working.setLimitReached(true);

							if (BenefitCode.H03.toString().equals(working.getBenefitCode())) {
								// Add ICU days 
								if (!helper.getH03ExcessAmtList().contains(working.getCurrentClaimBenefitItemKey())) {
									helper.getH03ExcessAmtList().add(working.getCurrentClaimBenefitItemKey());
									helper.setExcessCSICUDays(working.getPresentedNosOfDays() - result.getDaysAllocated());
								}
							}
							// warning log 
							if (transactionLogEnable) {
								TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C500, working.getClaimNoForLogging(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(), working.getBenefitCode(),
										cpc.getSumTimeFrame(), maxBenefitUnit, totalPrevDayAllocated, working.getPresentedNosOfDays(), result.getDaysAllocated(), cpc.getSumTimeFrame());
							}

							return result;
						}
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("After checked PresentedDays={} against current/previous allocated Days, new Allocated Day is now {}", working.getPresentedNosOfDays(), daysAllocated);
							working.getCalculationLogger().debug("Formula: DaysAllocated = Min(PresentedDays({}),  MaxBenefitUnit({}) - (PreviousAllocatedDays({}) + CurrentAllocatedDays({}) ), EligibleDays={} )",
									working.getPresentedNosOfDays(), maxBenefitUnit, totalPrevDayAllocated, totalCurrentDayAllocated.getDaysAllocated(), result.getDaysAllocated());
						}

						result.setDaysAllocated(daysAllocated);

						// log
						if (transactionLogEnable) {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C305, working.getPolicyNo(), working.getProductCode(),
									working.getBenefitCode(), cpc.getBenefitAmount(), totalPrevDayAllocated, working.getPresentedNosOfDays(), daysAllocated, cpc.getSumTimeFrame());
						}

					}
				}
				/**
				 * No SumCategory=C,  Treat As Call
				 */
				else if (SumCategory.C.toString().equalsIgnoreCase(cpc.getSumCategory())) {

					Integer totalPrevCallAllocated = 0;
					Integer cmicPrevCallAllocated = 0;
					Integer compassPrevCallAllocated = 0;
					for (ClaimPolicyCoverage matchingCPC : historicalCPCs) {
						List<Object> parameters = new ArrayList<Object>();
						// align with OL to check previous settled records
						String withExtraJoin = strSummaryQuery.toString() + " inner join ClaimPayment cp on cpd.companyId=cp.companyId and cpd.claimNo=cp.claimNo and cpd.occurrence=cp.occurrence and cpd.policyNo=cp.policyNo and cpd.productCode=cp.productCode ";
						StringBuilder whereCondition = getWhereCondition(claimCanonical, working, sdf, matchingCPC, hasAccumulatorNo, false, parameters);

						String query1 = withExtraJoin + whereCondition.toString() + " and cp.paymentStatus IN ('50', '70') and cpd.presentedAmt >0 and cpd.eligibleAmt >0 )";

						//						strSummaryQuery.append(whereCondition);
						if (logger.isDebugEnabled() && printQuery) {
							logger.debug("CS FORMULA Previous Reimbursed/Call QUERY: {}", query1.toString());
						}
						Map<String, Object> totalPrevReimbursedAmtMap = claimPaymentDetailRepository.performCheckLimit(printQuery, query1, parameters, "totalPrevCallAllocated");
						if (!totalPrevReimbursedAmtMap.isEmpty() || !totalPrevReimbursedAmtMap.isEmpty()) {
							Integer usedCalls = ((BigDecimal) totalPrevReimbursedAmtMap.get("totalPrevCallAllocated")).intValue();
							if (logger.isDebugEnabled()) {
								logger.debug("BenefitCode={} ,previous allocated calls={}, AccumulatorNo={}", matchingCPC.getBenefitCode(), usedCalls, cpc.getAccumulatorNo());
							}
							cmicPrevCallAllocated += usedCalls;
						}

						// Historical
						parameters = new ArrayList<Object>();
						Set<String> oldClaims = new LinkedHashSet<String>();
						whereCondition = getWhereCondition(claimCanonical, working, sdf, matchingCPC, hasAccumulatorNo, true, parameters);
						String historyQueryData = strSummaryQueryHistorical.toString() + whereCondition + " and cpd.paymentStatus IN ('50', '70') and cpd.presentedAmt >0 and cpd.eligibleAmt >0 ";
						historyQueryData += " and cpd.claimno||'|'||cpd.occurrence not in (select claimno||'|'||occurrence from claim where claimno=? and companyId = ?)";
						historyQueryData += " and cpd.policyNo=? and cpd.productCode=?  and cpd.benefitCode=?";
						parameters.add(claimCanonical.getClaim().getClaimNo() );
						parameters.add(claimCanonical.getClaim().getCompanyId());
						parameters.add(working.getPolicyNo());
						parameters.add(working.getProductCode());
						parameters.add(working.getBenefitCode());
						List<String> matchedClaims = claimPaymentDetailRepository.performCheckLimitHistoricalCall(printQuery, historyQueryData, parameters);
						if (CollectionUtils.isNotEmpty(matchedClaims)) {
							for (String cl : matchedClaims) {
								if (!oldClaims.contains(cl)) {
									oldClaims.add(cl);
								}
							}
						}
						compassPrevCallAllocated = oldClaims.size();
						if (logger.isDebugEnabled()) {
							logger.debug("BenefitCode={} ,previous compass allocated calls={}, AccumulatorNo={}", matchingCPC.getBenefitCode(), oldClaims.size(), cpc.getAccumulatorNo());
						}

					}
					totalPrevCallAllocated = cmicPrevCallAllocated + compassPrevCallAllocated;
					if (working.isCalculationLoggerEnabled()) {
						working.getCalculationLogger().debug("//Call SumCategory");
						working.getCalculationLogger().debug("PreviousAllocatedCalls(Cmic:{},Compass:{})={},CurrentAllocatedCall={}", cmicPrevCallAllocated, compassPrevCallAllocated, totalPrevCallAllocated, 1);
					}
					if (totalPrevCallAllocated + 1 > maxBenefitUnit) {
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("Formula: PreviousAllocatedCalls + CurrentAllocatedCall > MaxBenefitUnit, EligibleAmt=0,DaysAllocated=0,CallAllocated=0");
						}
						result.setAmountAllocated(BigDecimal.ZERO);
						result.setDaysAllocated(0);
						result.setCallAllocated(0);
						// limit reached
						working.setLimitReached(true);

						// warning 
						if (transactionLogEnable) {
							TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C500, working.getClaimNoForLogging(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(), working.getBenefitCode(),
									cpc.getSumTimeFrame(), maxBenefitUnit, totalPrevCallAllocated, 1, result.getCallAllocated(), cpc.getSumTimeFrame());
						}
						return result;
					} else {
						result.setCallAllocated(1);
						if (working.isCalculationLoggerEnabled()) {
							working.getCalculationLogger().debug("Formula: CallAllocated({}) = ",
									result.getCallAllocated());
						}
					}

					// log
					if (transactionLogEnable) {
						TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C305, working.getPolicyNo(), working.getProductCode(),
								working.getBenefitCode(), cpc.getBenefitAmount(), totalPrevCallAllocated, 1, result.getCallAllocated(), cpc.getSumTimeFrame());
					}

				}

			}

		} else {
			// no matching claimpolicycoverage
			result.setAmountAllocated(BigDecimal.ZERO);
			result.setDaysAllocated(0);
			result.setCallAllocated(0);

		}

		return result;
	}

	/**
	 * Dynamic where condition
	 * 
	 * @param claimCanonical
	 * @param working
	 * @param sdf
	 * @param cpc
	 * @return
	 */
	private StringBuilder getWhereCondition(ClaimCanonical claimCanonical, PaymentAllocationTemp working, SimpleDateFormat sdf, ClaimPolicyCoverage cpc, Boolean hasAccumlatorNo, Boolean isHistorical, List<Object> parameters) {

		// check required parameters ;
		if(BusinessLine.CS.toString().equals(working.getBusinessLine())) {
			List<Object> requiredParameters = Arrays.asList((Object) (StringUtils.isEmpty(claimCanonical.getClaim().getMemberId()) ? null : claimCanonical.getClaim().getMemberId()));
			List<String> parameterNames = Arrays.asList("Claim.MemberId");
			ClaimCanonicalUtil.checkBenefitCodeCalculationRequiredParameters(requiredParameters, parameterNames, "%s cannot be blank/null.");
		}
		// where
		// align with OL status condition
		StringBuilder whereCondition = new StringBuilder();
		parameters.add( working.getCompanyId()) ;
		whereCondition.append(" where cpd.companyId= ? and cl.claimStatus IN ('40', '50','65', '70') and ( cl.deleteInd = 'N' or cl.deleteInd is null)");
		
		//Kanjana Nookaew	28/01/2019
		if(BusinessLine.CS.toString().equals(working.getBusinessLine())){//cs only
			whereCondition.append(StringUtils.isEmpty(claimCanonical.getClaim().getMemberId()) ? " and trim(cl.memberId) is null " : (" and cl.memberId= ?"));
			
		}else if(BusinessLine.GE.toString().equals(working.getBusinessLine())){
			if(!StringUtils.isEmpty(claimCanonical.getClaim().getCertNo())){
				parameters.add(claimCanonical.getClaim().getCertNo());
			}
			if(!StringUtils.isEmpty(claimCanonical.getClaim().getDependentNo())){
				parameters.add(claimCanonical.getClaim().getDependentNo());
			}
			whereCondition.append(StringUtils.isEmpty(claimCanonical.getClaim().getCertNo()) ? " and trim(cl.certNo) is null " : " and cl.certNo=?");
			whereCondition.append(StringUtils.isEmpty(claimCanonical.getClaim().getDependentNo()) ? " and trim(cl.dependentNo) is null " : " and cl.dependentNo=?");
		}
		
		if(!StringUtils.isEmpty(claimCanonical.getClaim().getMemberId())){
			parameters.add( claimCanonical.getClaim().getMemberId()) ;
		}
		
		if (hasAccumlatorNo) {
			// new logic for accumulatorNo
			parameters.add(claimCanonical.getClaim().getPartyId()) ;
			whereCondition.append(" and cl.partyId = ?");
			if (isHistorical) {
				parameters.add( cpc.getPolicyNo());
				parameters.add( cpc.getProductCode() );
				parameters.add( cpc.getBenefitCode() );
				whereCondition.append(
						" and cpd.policyNo=? and cpd.productCode=? and cpd.benefitCode=?");
			} else {
				if (BusinessLine.CS.toString().equals(claimCanonical.getClaim().getBusinessLine())) {
					parameters.add(cpc.getPolicyNo());
					parameters.add( cpc.getProductCode());
					parameters.add(cpc.getBenefitCode());
					whereCondition.append(" and cpd.policyNo=? and cpd.productCode=?").append(" and cpd.benefitCode =?");
				} else {
					parameters.add(cpc.getPolicyNo());
					parameters.add(cpc.getProductCode());
					parameters.add(cpc.getPlanId());
					parameters.add(cpc.getBenefitCode());
					whereCondition.append(" and cpd.policyNo=? and cpd.productCode=? and cpd.planId=? and cpd.benefitCode =?");
				}

			}
		} else {
			/**
			 * Apr 03, 2018 changes, ignore ShareLevel and always use upto Benefit Level - Onsite, Wittaya
			 */
			/*
			if (ShareLevel.C.toString().equalsIgnoreCase(cpc.getShareLevel())) {
				// policy level
				whereCondition.append(" and cpd.policyNo='" + working.getPolicyNo() + "'");
			} else if (ShareLevel.P.toString().equalsIgnoreCase(cpc.getShareLevel())) {
				// product level
				whereCondition.append(" and cpd.productCode='" + working.getProductCode() + "' and cpd.policyNo='" + working.getPolicyNo() + "'");
			} else if (ShareLevel.L.toString().equalsIgnoreCase(cpc.getShareLevel())) {
				// plan level
				// Dec 15, 2017. On historical there is no assurance for correct mapping of PlanId/PlanCoverageNo. Treat as Product level for now -Wittaya
				if (isHistorical) {
					whereCondition.append(" and cpd.productCode='" + working.getProductCode() + "' and cpd.policyNo='" + working.getPolicyNo() + "'");
				} else {
					whereCondition.append(" and cpd.policyNo='" + working.getPolicyNo() + "' and cpd.productCode='" + working.getProductCode() + "' and cpd.planId=" + working.getPlanId() + " and cpd.planCoverageNo " + (working.getPlanCoverageNo() != null ? (" = " + working.getPlanCoverageNo()) : " is null"));
				}
			} else if (StringUtils.isEmpty(cpc.getShareLevel())) {
			*/
			// Dec 15, 2017. On historical there is no assurance for correct mapping of PlanId/PlanCoverageNo. Treat as Product level for now -Wittaya
			if (isHistorical) {
				parameters.add(working.getPolicyNo());
				parameters.add(working.getProductCode());
				parameters.add(working.getBenefitCode());
				whereCondition.append(
						" and cpd.policyNo=? and cpd.productCode=? and cpd.benefitCode=?");
			} else {
				if (BusinessLine.CS.toString().equals(claimCanonical.getClaim().getBusinessLine())) {
					parameters.add(working.getPolicyNo());
					parameters.add(working.getProductCode());
					if(working.getPlanCoverageNo() != null) {
						parameters.add(working.getPlanCoverageNo());
					}
					parameters.add(working.getBenefitCode());
					whereCondition.append(
							" and cpd.policyNo=? and cpd.productCode=? and cpd.planCoverageNo " + (working.getPlanCoverageNo() != null ? " = ?" : " is null") + "  and cpd.benefitCode=?");
				} else {
					parameters.add(working.getPolicyNo());
					parameters.add(working.getProductCode());
					parameters.add(working.getPlanId());
					if(working.getPlanCoverageNo() != null) {
						parameters.add(working.getPlanCoverageNo());
					}
					parameters.add(working.getBenefitCode());
					whereCondition.append(
							" and cpd.policyNo=? and cpd.productCode=? and cpd.planId=? and cpd.planCoverageNo " + (working.getPlanCoverageNo() != null ? " = ?" : " is null") + "  and cpd.benefitCode=?");
				}

			}
			//			}
		}

		if (SumTimeFrame.B.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {
			// per disability
			parameters.add(claimCanonical.getClaim().getClaimNo() );
			whereCondition.append(" and cpd.claimNo=?");
		} else if (SumTimeFrame.L.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {
			// per life
		} else if (SumTimeFrame.C.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {
			// per Call
			parameters.add(claimCanonical.getClaim().getClaimNo() );
			parameters.add(claimCanonical.getClaim().getOccurrence() );
			whereCondition.append(" and cpd.claimNo=? and cpd.occurrence=?");
		} else if (SumTimeFrame.D.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {
			// per Day
			if (!TreatmentType.Accident.toString().equalsIgnoreCase(claimCanonical.getClaim().getCauseOfTreatment()) && claimCanonical.getClaim().getHospitalizationDate() != null) {
				parameters.add(claimCanonical.getClaim().getHospitalizationDate());
				whereCondition.append(" and cl.hospitalizationDate = ?");
			} else if (claimCanonical.getClaim().getAccidentDt() != null) {
				parameters.add(claimCanonical.getClaim().getAccidentDt());
				whereCondition.append(" and cl.accidentDt = ?");
			}
		} else if (SumTimeFrame.P.toString().equalsIgnoreCase(cpc.getSumTimeFrame())) {

			ClaimPolicy claimPolicy = null;
			if (!hasAccumlatorNo) {
				// per policy year
				claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), working.getPolicyNo(), working.getProductCode(),
						working.getCompanyId(), claimCanonical);
			} else {
				// per policy year
				claimPolicy = ClaimCanonicalUtil.findClaimPolicyByClaimNoPolicyNoCompanyId(working.getClaimNo(), working.getOccurence(), cpc.getPolicyNo(), cpc.getProductCode(),
						working.getCompanyId(), claimCanonical);

			}

			if (claimPolicy != null && claimPolicy.getPolicyYearFromDt() != null && claimPolicy.getPolicyYearToDt() != null) {
				// Wittaya 2017/07/28 onsite. should be check on Claim.accidentDate or Claim.hospitalizationDate instead of ClaimPaymentDetail.createdDt
				parameters.add(claimPolicy.getPolicyYearFromDt());
				parameters.add(claimPolicy.getPolicyYearToDt());
				parameters.add(claimPolicy.getPolicyYearFromDt());
				parameters.add(claimPolicy.getPolicyYearToDt());
				whereCondition.append(
						" and ( ( cl.hospitalizationDate >= ? and cl.hospitalizationDate <=?)")
						.append(" or ( cl.accidentDt>=? and cl.accidentDt <= ?) )");

			} else {
				// TODO: logging here this should not happen
			}
		}
		
		//Kanjana Nookaew	28/01/2019
		if ("Y".equalsIgnoreCase(cpc.getFamilyShareInd()) && BusinessLine.CS.toString().equals(working.getBusinessLine())) {
			// family sharing
			if(!StringUtils.isEmpty(claimCanonical.getClaim().getCertNo())){
				parameters.add(claimCanonical.getClaim().getCertNo());
			}
			whereCondition.append(StringUtils.isEmpty(claimCanonical.getClaim().getCertNo()) ? " and trim(cl.certNo) is null " : " and cl.certNo=?");
		}

		//		if(hasAccumlatorNo) {
		//			// check only benefitcode,policyno and productCode as planId/planCoverage is not properly map  on Historical -Wittaya . Dec 12, 2017
		//			whereCondition.append(
		//					" and cpd.policyNo='" + cpc.getPolicyNo() + "' and cpd.productCode='" + cpc.getProductCode() + "'  and cpd.benefitCode='" + cpc.getBenefitCode() + "'");			
		//		}

		// specs changed for non-family. remove dependentNo. Check previous history for code.
		return whereCondition;
	}

	/**
	 * For Sorting. should be sorted in C,X,A order
	 * @author Ronald
	 *
	 */
	protected static class ClaimPolicyCoverageComparator implements Comparator<ClaimPolicyCoverage> {

		@Override
		public int compare(ClaimPolicyCoverage c1, ClaimPolicyCoverage c2) {
			int comparison = c1.getSumCategory().compareToIgnoreCase(c2.getSumCategory());
			if (comparison != 0) {
				if (SumCategory.C.toString().equalsIgnoreCase(c1.getSumCategory())) {
					return -1;
				}
				if (SumCategory.X.toString().equalsIgnoreCase(c1.getSumCategory())) {
					if (SumCategory.A.toString().equalsIgnoreCase(c2.getSumCategory())) {
						return -1;
					}
					if (SumCategory.C.toString().equalsIgnoreCase(c2.getSumCategory())) {
						return 1;
					}
				}
				if (SumCategory.A.toString().equalsIgnoreCase(c1.getSumCategory())) {
					return 1;
				}
			}
			return comparison;
		}

	}

	/**
	 * Get month difference
	 * valid 1 month differene should exceed the from day of the next month. 
	 * Example:
	 *     2016-03-30 to 2016-04-29 --> 0 month
	 *     2016-03-30 to 2016-04-30 --> 1 month
	 * @param from
	 * @param to
	 * @return
	 */
	private int getMonthDifference(Date from, Date to) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(from);
		int fromYear = cal.get(Calendar.YEAR);
		int fromMonth = cal.get(Calendar.MONTH) + 1;
		int fromDay = cal.get(Calendar.DAY_OF_MONTH);

		cal.setTime(to);
		int toYear = cal.get(Calendar.YEAR);
		int toMonth = cal.get(Calendar.MONTH) + 1;
		int toDay = cal.get(Calendar.DAY_OF_MONTH);

		int months = (((toYear - 1) - fromYear) * 12) + ((toMonth + 12) - fromMonth);

		if (toDay - fromDay < 0) {
			months--;
		}

		return months;
	}
	
	public BigDecimal calculatedAdjustedAmt(BigDecimal maxBenefitAmount, BigDecimal maxBenefitAmountPercent,BigDecimal totalPrevReimbursedAmt, BigDecimal totalCurrentReimbursedAmt,  BigDecimal presentedAmt) {
		BigDecimal adjustedAmt = BigDecimal.ZERO;
		maxBenefitAmountPercent = maxBenefitAmountPercent.subtract(totalCurrentReimbursedAmt);
		maxBenefitAmountPercent = maxBenefitAmountPercent.max(BigDecimal.ZERO);
		BigDecimal minValue =  maxBenefitAmountPercent.min(presentedAmt) ;
		BigDecimal totalPrevious = totalPrevReimbursedAmt.add(totalCurrentReimbursedAmt);
		BigDecimal remainPaid = maxBenefitAmount.subtract(totalPrevious.add(minValue));
		if(remainPaid.compareTo(BigDecimal.ZERO) >= 0){
			adjustedAmt = minValue;
		}else{
			adjustedAmt = maxBenefitAmount.subtract(totalPrevious);
			adjustedAmt = adjustedAmt.min(minValue).min(presentedAmt);
		}
		return adjustedAmt.max(BigDecimal.ZERO);//
	}

}
