package com.aia.cmic.formula.cs;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.canonical.util.ClaimCanonicalUtil;
import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.formula.ol.BenefitCodeFormula;
import com.aia.cmic.model.ClaimPolicyPlan;
import com.aia.cmic.model.PaymentAllocationTemp;
import com.aia.cmic.services.TransactionLogService;
import com.aia.cmic.util.TransactionLogUtil;
import com.aia.cmic.util.ClaimCalculationEnum.BenefitCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseCode;
import com.aia.cmic.util.ClaimCalculationEnum.ResponseSubCode;
@BenifitCodeFormula("CS_L16")
public class CS_L16 implements BenefitCodeFormula {

	// 3.2 For special benefit code formula - L16
	private Logger logger = LoggerFactory.getLogger(CS_L16.class);


	@Autowired
	private TransactionLogService transactionLogService ;
	
	@Override
	public void allocateAmount(ClaimCanonical claimCanonical, PaymentAllocationTemp working) {

		if (logger.isDebugEnabled()) {
			logger.debug("CashBenefit Formula for BenefitCode={} is now executing! ", working.getBenefitCode());
		}

		if (working.isCalculationLoggerEnabled()) {
			working.getCalculationLogger().info("=====");
			working.getCalculationLogger().info("{}:", working.getBenefitCode());
			working.getCalculationLogger().info("=====");

		}
		
		// 3.2 For Special benefitcode formulas
		// L16
		BigDecimal allocatedAmt = BigDecimal.ZERO ;
		
		if(BenefitCode.L16.toString().equals(working.getBenefitCode())) {
			ClaimPolicyPlan claimPolicyPlan = ClaimCanonicalUtil.findClaimPolicyPlanByClaimNoPolicyNoPlanId(working.getClaimNo(), working.getOccurence(), working.getPlanId(), working.getPolicyNo(),
					working.getPlanCoverageNo(), claimCanonical);
			if (working.isCalculationLoggerEnabled()) {
				working.getCalculationLogger().debug("Recalculating MaxBenefitAmt for Special BenefitCode={}.",working.getBenefitCode());
			}
			if(claimPolicyPlan != null && claimPolicyPlan.getSumAssured() != null) {
				BigDecimal totalDisablity = claimCanonical.getClaim().getTotalDisability() == null ? BigDecimal.ZERO : BigDecimal.valueOf(claimCanonical.getClaim().getTotalDisability()).setScale(2);
				BigDecimal partialDisablity = claimCanonical.getClaim().getPartialDisability() == null ? BigDecimal.ZERO : BigDecimal.valueOf(claimCanonical.getClaim().getPartialDisability()).setScale(2);
				BigDecimal sumAssured = claimPolicyPlan.getSumAssured();
				BigDecimal resultPart1  = sumAssured.multiply(BigDecimal.valueOf(750)).setScale(2,RoundingMode.HALF_UP).divide(BigDecimal.valueOf(100000),RoundingMode.HALF_UP).multiply(totalDisablity).divide(BigDecimal.valueOf(7),RoundingMode.HALF_UP);
				BigDecimal resultPart2  = sumAssured.multiply(BigDecimal.valueOf(750).setScale(2,RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(0.25))).divide(BigDecimal.valueOf(100000),RoundingMode.HALF_UP).multiply(partialDisablity).divide(BigDecimal.valueOf(7),RoundingMode.HALF_UP) ;
				
				resultPart1 = resultPart1.setScale(2,RoundingMode.HALF_UP) ;
				resultPart2 = resultPart2.setScale(2,RoundingMode.HALF_UP) ;
				allocatedAmt = resultPart1.add(resultPart2) ;
				
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("EligbleAmt({}) = ClaimPolicyPlan.SumAssured({}) * 750 / 100000 * Claim.TotalDisablity({}) / 7 + ClaimPolicyPlan.SumAssured * 750 * 0.25 / 100000 * Claim.PartialDisablity({}) / 7"
							+ "==> result1({}) + result2({})",
							allocatedAmt,sumAssured,totalDisablity,partialDisablity,resultPart1, resultPart2);
				}
				// log
				TransactionLogUtil.addTransactionLog(transactionLogService, ResponseCode.C300, working.getClaimNoForLogging(), working.getOccurence(), ResponseSubCode.C303, allocatedAmt,sumAssured,totalDisablity,partialDisablity);
				
			} else {
				if (working.isCalculationLoggerEnabled()) {
					working.getCalculationLogger().debug("Unable to find ClaimPolicyPlan.SumAssured from Canonical. PolicyNo={},PlanId={},ProductCode={},PlanCoverageNo={}. Setting EligibleAmt=0.", working.getPolicyNo() , working.getPlanId(), working.getProductCode(), working.getPlanCoverageNo());
				}
			}
			
			
		}
		working.setPresentedAmt(BigDecimal.ZERO);
		working.setEligibleAmt(allocatedAmt);
	}



}
