package com.aia.cmic.formula.registry ;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.aia.cmic.formula.ol.BenefitCodeFormula;

/**
 * Maintains all registered benefit code formula for calculations
 * 
 * @author Ronald
 *
 */
@Component
public class BenefitCodeFormulaRegistry implements FormulaRegistry {

	private final Map<String, BenefitCodeFormula> bcMap = new HashMap<String, BenefitCodeFormula>();

	/**
	 * Register Benefitcode formula
	 */
	@Override
	public void register(String benefitCode, BenefitCodeFormula bcc) {
		bcMap.put(benefitCode, bcc);
	}

	@Override
	public BenefitCodeFormula getFormula(String benefitCode) throws BenefitCodeFormulaNotFoundException {
		if (hasFormula(benefitCode)) {
			return bcMap.get(benefitCode);
		}
		throw new BenefitCodeFormulaNotFoundException(benefitCode);
				
	}

	/**
	 * Check if formula is registered
	 */
	@Override
	public boolean hasFormula(String benefitCode) {
		return bcMap.containsKey(benefitCode);
	}

}
