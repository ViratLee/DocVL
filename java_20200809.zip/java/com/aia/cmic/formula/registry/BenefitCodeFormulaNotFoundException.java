package com.aia.cmic.formula.registry;

import com.aia.cmic.exception.CMiCException;

public class BenefitCodeFormulaNotFoundException extends CMiCException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2429342688384058194L;

	private String message;

	private BenefitCodeFormulaNotFoundException() {
	}

	public BenefitCodeFormulaNotFoundException(String benefitCode) {
		this();
		message = "Calculation Formula for benefit code : " + benefitCode + " missing. Allocation calculation aborted.";
	}

	@Override
	public String getMessage() {
		return message;
	}

}
