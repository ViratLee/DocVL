package com.aia.cmic.formula.registry ;

import com.aia.cmic.formula.ol.BenefitCodeFormula;

/**
 * 
 * @author Ronald
 *
 */
public interface FormulaRegistry {

	void register(String benefitCode, BenefitCodeFormula bcc) ;
	
	BenefitCodeFormula getFormula(String benefitCode) throws BenefitCodeFormulaNotFoundException;
	
	boolean hasFormula(String benefitCode) ;
}
