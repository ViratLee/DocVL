package com.aia.cmic.formula.logger;

import org.slf4j.Logger;

public interface Logging {

	public Boolean isCoastESBLoggerEnabled();

	public Boolean isCalculationLoggerEnabled();

	public Boolean isAccPostingLoggerEnabled();

	public <J> void logObj(final J instance, Logger logger);

	public Logger getCoastLogger();

	public Logger getESBLogger();

	public Logger getODSLogger();

	public Logger getCalculationLogger();
	
	public Logger getAccPostingLogger();


}
