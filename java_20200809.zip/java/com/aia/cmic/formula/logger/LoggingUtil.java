package com.aia.cmic.formula.logger;

import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.model.MasterLookup;

/**
 * Logging utility for coast/esb and benefit calculations
 * @author Ronald
 *
 */
@Component("LoggingUtil")
public class LoggingUtil implements Logging {

	@Autowired
	private CachingMasterDataHelper cachingHelper;

	private static final String COAST_LOGGER = "coast.logger";
	private static final String ESB_LOGGER = "esb.logger";
	public static final String CALCULATION_LOGGER = "calculation.logger";
	public static final String ODS_LOGGER = "ods.logger";
	public static final String ACC_POSTING_LOGGER = "acc_posting.logger";

	private static Logger coastLogger = LoggerFactory.getLogger(COAST_LOGGER);
	private static Logger esbLogger = LoggerFactory.getLogger(ESB_LOGGER);
	private static Logger calcLogger = LoggerFactory.getLogger(CALCULATION_LOGGER);
	private static Logger odsLogger = LoggerFactory.getLogger(ODS_LOGGER);
	private static Logger accPostingLogger = LoggerFactory.getLogger(ACC_POSTING_LOGGER);


	public Boolean isCoastESBLoggerEnabled() {
		return checkDebugFlag();
	}

	@Override
	public Boolean isCalculationLoggerEnabled() {
		return checkDebugFlag();
	}

	private Boolean checkDebugFlag() {
		List<MasterLookup> lst = cachingHelper.getDebugFlag();
		return lst.size() > 0 && "Y".equalsIgnoreCase(lst.get(0).getKey());
	}

	public <J> void logObj(final J instance, Logger logger) {
		if (instance == null) {
			return;
		}
		if (String.class.isAssignableFrom(instance.getClass())) {
			logger.debug(instance.toString());
		} else {
			String info = decode(instance);
			logger.debug(info);
		}
	}

	public Logger getCoastLogger() {
		return coastLogger;
	}

	public Logger getESBLogger() {
		return esbLogger;
	}

	public Logger getCalculationLogger() {
		return calcLogger;
	}

	@SuppressWarnings("unchecked")
	private <J> String decode(final J instance) {
		JAXBContext jaxbContext;
		String xmlData = "";
		try {
			StringWriter writer = new StringWriter();
			jaxbContext = JAXBContext.newInstance(instance.getClass());
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(new JAXBElement<J>(new QName("uri", "local"), (Class<J>) instance.getClass(), instance), writer);
			xmlData = writer.toString();
			return xmlData;
		} catch (JAXBException e) {
			return "Unable to marshal parameter : " + instance;
		}
	}

	@Override
	public Logger getODSLogger() {
		return odsLogger;
	}

	@Override
	public Logger getAccPostingLogger() {
		return accPostingLogger;
	}

	@Override
	public Boolean isAccPostingLoggerEnabled() {
		return checkDebugFlag();
	}

}
