package com.aia.cmic.formula.processor ;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import com.aia.cmic.formula.BenifitCodeFormula;
import com.aia.cmic.formula.ol.BenefitCodeFormula;
import com.aia.cmic.formula.registry.FormulaRegistry;

@Component
public class BenefitCodeAnnotationProcessor implements BeanPostProcessor {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass()) ;

	@Autowired
	FormulaRegistry benefitCodeFormulaRegistry ;
	
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        scanFormulaAnnotations(bean, beanName);
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

    /**
     * @param bean
     * @param beanName
     */
    protected void scanFormulaAnnotations(Object bean, String beanName) {
        Class<?> managedBeanClass = bean.getClass();
//        logger.debug("Checking bean... " + managedBeanClass);
        if( managedBeanClass.isAnnotationPresent(BenifitCodeFormula.class) && BenefitCodeFormula.class.isAssignableFrom(bean.getClass()) ) {
        	String benefitCode = managedBeanClass.getAnnotation(BenifitCodeFormula.class).value() ;
        	if(benefitCodeFormulaRegistry.hasFormula(benefitCode) ) {
        		logger.warn("Multiple Formula implementation for benefit code : {} detected" , benefitCode);
        	}
        	if(benefitCode.indexOf(",") != -1) {
        		for(String bc: benefitCode.split(",")) {
        			benefitCodeFormulaRegistry.register(bc, (BenefitCodeFormula)bean);
        		}
        	} else {
        		benefitCodeFormulaRegistry.register(benefitCode, (BenefitCodeFormula)bean);
        	}
        }
    }
}
