package com.aia.cmic;

import java.util.Locale;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.web.WebApplicationInitializer;

import com.aia.cmic.persistence.spi.HibernatePersistenceProviderResolver;

@SpringBootApplication(scanBasePackages = "com.aia.cmic.config")
@EnableConfigurationProperties
@EnableCaching
public class CMiCApplication extends SpringBootServletInitializer implements WebApplicationInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CMiCApplication.class);
	}

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		// Create the dispatcher servlet's Spring application context
		Locale.setDefault(new Locale("en", "US"));
		HibernatePersistenceProviderResolver.register();

		ServletRegistration.Dynamic registration = servletContext.addServlet("cfx", new CXFServlet());
		registration.setLoadOnStartup(2);
		registration.addMapping("/api/*");

		super.onStartup(servletContext);
	}
}
