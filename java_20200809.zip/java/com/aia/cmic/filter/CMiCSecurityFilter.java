package com.aia.cmic.filter;

import java.io.IOException;
import java.net.URL;
import java.security.Principal;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestWrapper;
import javax.servlet.ServletResponse;
import javax.servlet.ServletResponseWrapper;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.aia.cmic.repository.soap.uam.ArrayOfUserAuthForm;
import com.aia.cmic.repository.soap.uam.UAMService;
import com.aia.cmic.repository.soap.uam.UAMServiceService;
import com.aia.cmic.repository.soap.uam.UserAuthForm;
import com.aia.cmic.repository.soap.uam.UserInfoForm;
import com.aia.cmic.restservices.model.UserInfoTO;
import com.aia.cmic.restservices.model.UserProfile;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.WebServiceEnvironmentHelper;
import com.aia.cmic.uam.Function;
import com.aia.cmic.uam.SecurityLevel;
import com.aia.cmic.util.SecurityUtil;

public class CMiCSecurityFilter implements Filter {
	private static final Logger LOG = LoggerFactory.getLogger(CMiCSecurityFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
			ServletRequest sr = request;
			while (sr instanceof ServletRequestWrapper) {
				sr = ((ServletRequestWrapper) sr).getRequest();
			}
			HttpServletRequest httpSR = (HttpServletRequest) sr;
			if (httpSR.getPathInfo().equals("/logout")) {
				HttpSession session = httpSR.getSession(true);
				session.invalidate();
				ServletResponse sp = response;
				while (sp instanceof ServletResponseWrapper) {
					sp = ((ServletResponseWrapper) sp).getResponse();
				}
				HttpServletResponse httpSP = (HttpServletResponse) sp;
				httpSP.sendError(HttpServletResponse.SC_UNAUTHORIZED);
			} else {
				Principal principal = httpSR.getUserPrincipal();
				if (principal != null) {
					HttpSession session = httpSR.getSession(true);
					MDC.put("sessionId", session.getId());
					MDC.put("userName", principal.getName());

					UserInfoForm userInfoForm = (UserInfoForm) session.getAttribute("userInfoForm");
					if (userInfoForm == null) {
						WebServiceEnvironmentHelper helper = (WebServiceEnvironmentHelper) WebApplicationContextUtils.getWebApplicationContext(request.getServletContext()).getBean("wsEnvironmentHelper");
						SecurityControlService securityControlService = (SecurityControlService) WebApplicationContextUtils.getWebApplicationContext(request.getServletContext()).getBean(
								SecurityControlService.class);

						boolean callUAM = helper.isEnableUam();
						try {
							String group = "N/A";
							if (callUAM) {
								UAMService service = new UAMServiceService(new URL(helper.getUamUrl()), helper.getUseHttpsURLConnectionDefaultSslSocketFactory()).getUAMService();
								userInfoForm = service.getUserProfile("051", principal.getName(), "CMC");
								//TODO call uamservice.getgroupbyuserid

								//							for(UserAuthForm authForm :userInfoForm.getUserAuthForm().getUserAuthForm()){
								//								BigDecimal convertBigDecimal = FormatUtil.convertBigDecimal(authForm.getSecLimit());
								//								if(BigDecimal.ZERO.compareTo(convertBigDecimal ) != 0){
								//									authForm.setSecLimit("2000.00");
								//								}
								//							}
								//							
								group = securityControlService.getGroupIdBySystemTypeAndUserId("CMC", userInfoForm.getUserId());
								userInfoForm.setGroupId(group);
								session.setAttribute("userInfoForm", userInfoForm);
								session.setAttribute("menus", securityControlService.getMenuLstByUser(userInfoForm));
								session.setAttribute("userGroup", group);
							} else {
								Function[] funcs = Function.values();
								;

								userInfoForm = new UserInfoForm();
								userInfoForm.setUserAuthForm(new ArrayOfUserAuthForm());
								UserAuthForm userAuthForm = new UserAuthForm();

								for (int i = 0; i < funcs.length; i++) {
									userAuthForm = new UserAuthForm();
									userAuthForm.setFuncId(funcs[i].toString());
									if ("CMIC_RISK_LEVEL".equalsIgnoreCase(funcs[i].toString())) {
										userAuthForm.setSecLev("R3");
									} else {
										userAuthForm.setSecLev(SecurityLevel.ALLOW.getLevel());
									}
									String[] LMT_List = { "CMIC_LMT_ME_AMT_GP", "CMIC_LMT_BB_AMT_GP", "CMIC_LMT_HU_AMT_GP", "CMIC_LMT_HM_AMT_GP", "CMIC_LMT_WI_AMT_GP", "CMIC_LMT_WC_AMT_GP", "CMIC_LMT_HS_AMT_GP", "CMIC_LMT_HB_AMT_GP" };
									if (Arrays.asList(LMT_List).contains(userAuthForm.getFuncId())) {
										userAuthForm.setSecLev("90");
										userAuthForm.setSecLimit("1000000000.0000000000");
									}
									userInfoForm.getUserAuthForm().getUserAuthForm().add(userAuthForm);
								}

								userInfoForm.setUserId(principal.getName());
								userInfoForm.setUserName("Bypass UAM");
								userInfoForm.setCompanyCode("051");
								session.setAttribute("userInfoForm", userInfoForm);
								session.setAttribute("menus", securityControlService.getMenuLstByUser(userInfoForm));
								session.setAttribute("userGroup", "CMC_SUPER");
							}

							// set group to userInfoTO
							UserInfoTO userInfoTO = new UserInfoTO();
							userInfoTO.setUserId(userInfoForm.getUserId());
							userInfoTO.setGroup(group);
							userInfoTO.setUserName(userInfoForm.getUserName());
							userInfoTO.setEmail(userInfoForm.getEmail());

							//init UserProfile
							UserProfile userProfile = new UserProfile();
							userProfile.setBranch(userInfoForm.getBranch());
							userProfile.setCompanyCode(userInfoForm.getCompanyCode());
							userProfile.setDept(userInfoForm.getDept());
							userProfile.setEmail(userInfoForm.getEmail());
							userProfile.setGroup(group);
							userProfile.setRegion(userInfoForm.getRegion());
							userProfile.setSubDept(userInfoForm.getSubdept());
							userProfile.setUserId(userInfoForm.getUserId());
							userProfile.setUserName(userInfoForm.getUserName());
							userProfile.setUserType(userInfoForm.getUserType());
							userProfile.setUserAuthForm(userInfoForm.getUserAuthForm().getUserAuthForm());

							// call workflowservice.createUserprofile (userInfoTO)
							if (!"bclm998".equals(userInfoForm.getUserId())) {
								WorkflowService workflowService = (WorkflowService) WebApplicationContextUtils.getWebApplicationContext(request.getServletContext()).getBean("workflowServiceImpl");
								//workflowService.createUserProfile(userInfoTO, userInfoForm);				
								workflowService.createUserProfileActivity(workflowService.convertRisk(userProfile));
							}

						} catch (Exception e) {
							LOG.error("Cannot get authorization object for user: " + principal.getName(), e);
							userInfoForm = new UserInfoForm();
							userInfoForm.setUserAuthForm(new ArrayOfUserAuthForm());
							userInfoForm.setUserId(principal.getName());
							userInfoForm.setUserName("UAM is not responding, please contact HelpDesk");
							session.setAttribute("userInfoForm", userInfoForm);
							session.setAttribute("menus", securityControlService.getMenuLstByUser(userInfoForm));
							session.setAttribute("group", "UNAUTHORIZED");
						}
					}
					SecurityUtil.userInfo.set(userInfoForm);
					if (userInfoForm != null) {
						chain.doFilter(request, response);
					}
				} else {
					LOG.warn("Unauthorized access from {} IP Address: {} requested URL: {}", httpSR.getRemoteHost(), httpSR.getRemoteAddr(), httpSR.getRequestURI());
				}
			}
		} finally {
			MDC.remove("sessionId");
			MDC.remove("userName");
		}
	}

	@Override
	public void destroy() {
	}
}
