package com.aia.cmic.config;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@EnableWebMvc
@Configuration
@ComponentScan(basePackages = "com.aia.cmic.controller")
public class CMiCWebConfig extends WebMvcConfigurerAdapter {
	private static String serverName;

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		converters.add(new MappingJackson2HttpMessageConverter());
		super.configureMessageConverters(converters);
	}

	@Bean
	public HandlerExceptionResolver handlerExceptionResolver() {
		return new HandlerExceptionResolver() {
			private Logger log = LoggerFactory.getLogger(HandlerExceptionResolver.class);

			@Override
			public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
				ModelAndView modelAndView = new ModelAndView("error");
				modelAndView.addObject("errorMsg", ex.getMessage());
				if (ex instanceof NoHandlerFoundException) {
					modelAndView.addObject("errorCode", 404);
					String referer = request.getHeader("Referer");
					if (referer != null && referer.trim().length() > 0) {
						modelAndView.addObject("referer", "Referer URL : " + referer);
					}
					modelAndView.addObject("errorMsg", "Request URL : " + ((NoHandlerFoundException) ex).getRequestURL());
				} else {
					modelAndView.addObject("errorCode", 500);
					Long logId = new Date().getTime();
					String serverName = getServerName(request);
					modelAndView.addObject("logId", "Error Log ID : " + serverName + "-" + logId);
					modelAndView.addObject("errorMsg", ex.getMessage());
					log.error("Log ID : " + logId, ex);
				}
				return modelAndView;
			}

			public String getServerName(HttpServletRequest request) {
				if (serverName == null) {
					String temp = request.getLocalName();
					if (temp == null) {
						temp = request.getLocalAddr();
					}
					if (temp != null && temp.trim().length() >= 2) {
						serverName = temp.substring(temp.length() - 2);
					} else {
						serverName = "";
					}
				}
				return serverName;

			}
		};
	}
}
