package com.aia.cmic.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.rest.helper.ClaimsSubmissionHelper;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.services.helper.ClaimHelper;
import com.aia.cmic.services.helper.WebServiceClientHelper;
import com.aia.cmic.services.helper.WebServiceEnvironmentHelper;
import com.aia.cmic.util.BenefitValidateHelper;
import com.aia.cmic.util.ClaimBenefitHelper;
import com.aia.cmic.util.CorrespondenceUtil;
import com.aia.cmic.util.DocumentRequestUtil;
import com.aia.cmic.util.PayeeValidateHelper;

@Configuration
@ComponentScan(basePackages = { "com.aia.cmic.services.impl", "com.aia.cmic.repository.impl", "com.aia.cmic.formula", "com.aia.cmic.repository.rest", "com.aia.cmic.repository.soap" })
@PropertySource({ "classpath:cmic.properties", "classpath:promotion.properties", "classpath:documentRequestUtil.properties", "classpath:resources/bankname.properties" })
public class CMiCRootConfig {
	@Bean
	public CachingMasterDataHelper cachingMasterDataHelper() {
		return new CachingMasterDataHelper();
	}

	@Bean
	public ClaimHelper cmicHelper() {
		return new ClaimHelper();
	}

	@Bean
	public Case360Helper case360Helper() {
		return new Case360Helper();
	}

	@Bean
	public CMiCEnvironmentHelper cmicEnvironmentHelper() {
		return new CMiCEnvironmentHelper();
	}

	@Bean
	public CorrespondenceUtil correspondenceUtil() {
		return new CorrespondenceUtil();
	}

	@Bean
	public WebServiceEnvironmentHelper wsEnvironmentHelper() {
		return new WebServiceEnvironmentHelper();
	}

	@Bean
	public WebServiceClientHelper webServiceClientHelper() {
		return new WebServiceClientHelper();
	}
	
	@Bean
	public ClaimsSubmissionHelper claimsSubmissionHelper() {
		return new ClaimsSubmissionHelper();
	}

	@Bean
	public DocumentRequestUtil cocumentRequestUtil() {
		return new DocumentRequestUtil();
	}

	@Bean
	public BenefitValidateHelper benefitValidateHelper() {
		return new BenefitValidateHelper();
	}

	@Bean
	public PayeeValidateHelper payeeValidateHelper() {
		return new PayeeValidateHelper();
	}

	@Bean
	public ClaimBenefitHelper claimBenefitHelper() {
		return new ClaimBenefitHelper();
	}
}
