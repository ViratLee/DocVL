package com.aia.cmic.config;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.TimeZone;

import javax.servlet.MultipartConfigElement;

import org.apache.cxf.Bus;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.feature.LoggingFeature;
import org.apache.cxf.interceptor.Interceptor;
import org.apache.cxf.interceptor.InterceptorProvider;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.embedded.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.aia.cmic.cxf.interceptor.CmicLoggingInInterceptor;
import com.aia.cmic.cxf.interceptor.CmicLoggingOutInterceptor;
import com.aia.cmic.rest.AgencyPaymentRest;
import com.aia.cmic.rest.BatchControlRest;
import com.aia.cmic.rest.BenefitSetupRest;
import com.aia.cmic.rest.BillingRest;
import com.aia.cmic.rest.CMiCRest;
import com.aia.cmic.rest.ClaimEnquiryRest;
import com.aia.cmic.rest.ClaimHistoryRest;
import com.aia.cmic.rest.ClaimRest;
import com.aia.cmic.rest.CommonLookupRest;
import com.aia.cmic.rest.CorrespondenceRest;
import com.aia.cmic.rest.FileRest;
import com.aia.cmic.rest.HCInternetRest;
import com.aia.cmic.rest.MigrationRest;
import com.aia.cmic.rest.PartyRest;
import com.aia.cmic.rest.PhysicianRest;
import com.aia.cmic.rest.PolicyRest;
import com.aia.cmic.rest.ProviderContractRest;
import com.aia.cmic.rest.ProviderRest;
import com.aia.cmic.rest.StandardBillingRest;
import com.aia.cmic.rest.UtilityRest;
import com.aia.cmic.rest.WorkflowRest;
import com.aia.cmic.rest.helper.ClaimsSubmissionHelper;
import com.aia.cmic.services.AgencyPaymentService;
import com.aia.cmic.services.BatchControlService;
import com.aia.cmic.services.BillingService;
import com.aia.cmic.services.ClaimHistoryService;
import com.aia.cmic.services.ClaimPaymentService;
import com.aia.cmic.services.ClaimService;
import com.aia.cmic.services.ClaimDeductService;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.CorrespondenceManagerService;
import com.aia.cmic.services.MailService;
import com.aia.cmic.services.NotificationService;
import com.aia.cmic.services.PartyService;
import com.aia.cmic.services.PhysicianService;
import com.aia.cmic.services.PlanService;
import com.aia.cmic.services.PolicyService;
import com.aia.cmic.services.ProviderContractService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SearchClaimHistoryService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.services.SettlementProviderFaxService;
import com.aia.cmic.services.SettlementService;
import com.aia.cmic.services.StandardBillingService;
import com.aia.cmic.services.SuppressChequeService;
import com.aia.cmic.services.TransactionLogService;
import com.aia.cmic.services.ValidationService;
import com.aia.cmic.services.WorkflowService;
import com.aia.cmic.services.helper.CMiCEnvironmentHelper;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.services.helper.ClaimHelper;
import com.aia.cmic.services.helper.WebServiceEnvironmentHelper;
import com.aia.cmic.util.BenefitValidateHelper;
import com.aia.cmic.util.ClaimBenefitHelper;
import com.aia.cmic.util.CorrespondenceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

@Configuration
@ImportResource({ "classpath:META-INF/cxf/cxf.xml" })
public class CXFConfig {

	@Autowired
	private Bus bus;

	@Autowired
	private PartyService partyService;
	@Autowired
	private ClaimService claimService;
	@Autowired
	private ProviderService providerService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private WorkflowService workflowService;
	@Autowired
	private ProviderContractService providerContractService;
	@Autowired
	private ValidationService validationService;

	@Autowired
	private SearchClaimHistoryService searchClaimHistoryService;
	@Autowired
	private CMiCEnvironmentHelper cmicEnvironmentHelper;
	@Autowired
	private ClaimHelper cmicHelper;
	@Autowired
	private PlanService planService;
	@Autowired
	private BillingService billingService;
	@Autowired
	private PolicyService policyService;
	@Autowired
	private Case360Helper case360Helper;
	@Autowired
	private AgencyPaymentService agencyPaymentService;

	@Autowired
	private WebServiceEnvironmentHelper wsEnvironmentHelper;

	@Autowired
	@Qualifier("ClaimPaymentServiceImpl")
	private ClaimPaymentService claimPaymentService;

	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private ClaimsSubmissionHelper claimsSubmissionHelper;

	@Autowired
	private SettlementService settlementService;

	@Autowired
	private BatchControlService batchControlService;

	@Autowired
	private CorrespondenceManagerService corrManager;

	@Autowired
	private MailService mailService;

	@Autowired
	private SettlementProviderFaxService faxService;

	@Autowired
	private BenefitValidateHelper benefitValidateHelper;

	@Autowired
	CorrespondenceUtil correspondenceUtil;

	@Autowired
	private PhysicianService physicianService;

	@Autowired
	private SuppressChequeService suppressChequeService;

	@Autowired
	private ClaimBenefitHelper claimBenefitHelper;

	@Autowired
	private ClaimHistoryService claimHistoryService;

	@Autowired
	private TransactionLogService transactionLogService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private StandardBillingService standardBillingService;
	
	@Autowired
	private ClaimDeductService claimDeductService;

	@Bean
	public ObjectMapper jacksonMapper() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S'Z'");
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		ObjectMapper om = new ObjectMapper();
		om.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		om.setDateFormat(sdf);
		return om;
	}

	@Bean
	public ObjectMapper jacksonMapperExternal() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S'Z'");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT+7"));
		ObjectMapper om = new ObjectMapper();
		om.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		om.setDateFormat(sdf);
		return om;
	}

	@Bean
	public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter(@Qualifier("jacksonMapper") ObjectMapper jacksonMapper) {
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(jacksonMapper);
		return converter;
	}

	@Bean
	public JacksonJsonProvider jsonProvider(@Qualifier("jacksonMapper") ObjectMapper jacksonMapper) {
		JacksonJsonProvider jsonProvider = new JacksonJsonProvider();
		jsonProvider.setMapper(jacksonMapper);
		return jsonProvider;
	}

	@Bean
	public JacksonJsonProvider jsonProviderExternal(@Qualifier("jacksonMapperExternal") ObjectMapper jacksonMapperExternal) {
		JacksonJsonProvider jsonProvider = new JacksonJsonProvider();
		jsonProvider.setMapper(jacksonMapperExternal);
		return jsonProvider;
	}

	@Bean
	public Server jaxRsServer(@Qualifier("jsonProvider") JacksonJsonProvider provider) {
		JAXRSServerFactoryBean endpoint = new JAXRSServerFactoryBean();
		endpoint.setBus(bus);
		endpoint.setAddress("/rest");
		endpoint.setServiceBeans(Arrays.<Object> asList(cmicRest(), commonLookupRest(), providerRest(), claimRest(), partyRest(), workflowRest(), providerContractRest(), policyRest(), billingRest(), benefitSetup(), searchClaimHistoryService, claimEnquiryRest(), batchControlRest(), fileRest(), correspondenceRest(), agencyPaymentRest(), utillityRest(), migrationRest(), physicianRest(),
				claimHistoryRest(), standBillingRest()));

		endpoint.setProviders(Arrays.<Object> asList(provider));
		endpoint.setFeatures(Collections.singletonList(new LoggingFeature() {
			@Override
			protected void initializeProvider(InterceptorProvider provider, Bus bus) {
				CmicLoggingInInterceptor in = new CmicLoggingInInterceptor();
				CmicLoggingOutInterceptor out = new CmicLoggingOutInterceptor();
				provider.getInInterceptors().add(in);
				provider.getInFaultInterceptors().add(in);
				provider.getOutInterceptors().add(out);
				provider.getOutFaultInterceptors().add(out);
			}
		}));

		return endpoint.create();

	}

	@Bean
	public Server jaxRsServerExternal(@Qualifier("jsonProviderExternal") JacksonJsonProvider provider) {
		JAXRSServerFactoryBean endpoint = new JAXRSServerFactoryBean();
		endpoint.setBus(bus);
		endpoint.setAddress("/external");
		endpoint.setServiceBeans(Arrays.<Object> asList(hcInternetRest()));

		endpoint.setProviders(Arrays.<Object> asList(provider));
		endpoint.setFeatures(Collections.singletonList(new LoggingFeature() {
			@Override
			protected void initializeProvider(InterceptorProvider provider, Bus bus) {
				super.initializeProvider(provider, bus);
				for (Interceptor<? extends Message> interceptor : provider.getInInterceptors()) {
					if (interceptor instanceof LoggingInInterceptor) {
						((LoggingInInterceptor) interceptor).setLimit(4 * 1024);
						((LoggingInInterceptor) interceptor).setShowBinaryContent(false);
						((LoggingInInterceptor) interceptor).setShowMultipartContent(false);
					}
				}
				for (Interceptor<? extends Message> interceptor : provider.getOutInterceptors()) {
					if (interceptor instanceof LoggingOutInterceptor) {
						((LoggingOutInterceptor) interceptor).setLimit(4 * 1024);
						((LoggingOutInterceptor) interceptor).setShowBinaryContent(false);
						((LoggingOutInterceptor) interceptor).setShowMultipartContent(false);
					}
				}

			}
		}));

		return endpoint.create();
	}

	/*@Bean
	public Server jaxWsServer() {
		JaxWsServerFactoryBean endpoint = new JaxWsServerFactoryBean();
		endpoint.setBus(bus);
		endpoint.setAddress("/soap");
		//		endpoint.setServiceBean(exampleSoap());
		return endpoint.create();
	}*/

	@Bean
	public CMiCRest cmicRest() {
		CMiCRest cmicRest = new CMiCRest();
		cmicRest.setCMiCEnvironmentHelper(cmicEnvironmentHelper);
		cmicRest.setWorkflowService(workflowService);
		cmicRest.setSecurityControlService(securityControlService);
		cmicRest.setCommonDataService(commonDataService);
		cmicRest.setPolicyService(policyService);
		cmicRest.setWsEnvironmentHelper(wsEnvironmentHelper);
		return cmicRest;
	}

	@Bean
	public CommonLookupRest commonLookupRest() {
		CommonLookupRest commonLookupRest = new CommonLookupRest();
		commonLookupRest.setProviderService(providerService);
		commonLookupRest.setCommonDataService(commonDataService);
		commonLookupRest.setWorkflowService(workflowService);
		return commonLookupRest;
	}

	@Bean
	public ProviderRest providerRest() {
		ProviderRest providerRest = new ProviderRest();
		providerRest.setProviderService(providerService);
		return providerRest;
	}

	@Bean
	public FileRest fileRest() {
		FileRest fileRest = new FileRest();
		fileRest.setWorkflowService(workflowService);
		return fileRest;
	}

	@Bean
	public ClaimRest claimRest() {
		ClaimRest claimRest = new ClaimRest();
		claimRest.setCmicHelper(cmicHelper);
		claimRest.setCMiCEnvironmentHelper(cmicEnvironmentHelper);
		claimRest.setWorkflowService(workflowService);
		claimRest.setClaimService(claimService);
		claimRest.setCommonDataService(commonDataService);
		claimRest.setSearchClaimHistoryService(searchClaimHistoryService);
		claimRest.setPolicyService(policyService);
		claimRest.setSecurityControlService(securityControlService);
		claimRest.setSettlementService(settlementService);
		claimRest.setClaimPaymentService(claimPaymentService);
		claimRest.setWsEnvironmentHelper(wsEnvironmentHelper);
		claimRest.setMailService(mailService);
		claimRest.setProviderFaxService(faxService);
		claimRest.setBenefitValidateHelper(benefitValidateHelper);
		claimRest.setCorrespondenceUtil(correspondenceUtil);
		claimRest.setProviderService(providerService);
		claimRest.setValidationService(validationService);
		claimRest.setSuppressChequeService(suppressChequeService);
		claimRest.setClaimBenefitHelper(claimBenefitHelper);
		claimRest.setPlanService(planService);
		claimRest.setTransactionLogService(transactionLogService);
		claimRest.setNotificationService(notificationService);
		claimRest.setClaimDeductService(claimDeductService);
		return claimRest;
	}

	@Bean
	public PartyRest partyRest() {
		PartyRest partyRest = new PartyRest();
		partyRest.setPartyService(partyService);
		partyRest.setPolicyService(policyService);
		return partyRest;
	}

	@Bean
	public WorkflowRest workflowRest() {
		WorkflowRest workflowRest = new WorkflowRest();
		workflowRest.setCMiCEnvironmentHelper(cmicEnvironmentHelper);
		workflowRest.setWorkflowService(workflowService);
		workflowRest.setCommonDataService(commonDataService);
		workflowRest.setSecurityControlService(securityControlService);
		workflowRest.setProviderService(providerService);
		workflowRest.setCase360Helper(case360Helper);
		workflowRest.setWebServiceEnvironmentHelper(wsEnvironmentHelper);
		workflowRest.setClaimService(claimService);
		workflowRest.setClaimHelper(cmicHelper);
		return workflowRest;
	}

	@Bean
	public CorrespondenceRest correspondenceRest() {
		CorrespondenceRest correspondenceRest = new CorrespondenceRest();
		correspondenceRest.setCorrManager(corrManager);
		//		correspondenceRest.setThreadServiceImpl(threadServiceImpl);
		//		correspondenceRest.setCmicEnvironmentHelper(cmicEnvironmentHelper);
		return correspondenceRest;

	}

	@Bean
	public MultipartConfigElement multipartConfigElement() {
		MultipartConfigFactory factory = new MultipartConfigFactory();
		factory.setMaxFileSize("128KB");
		factory.setMaxRequestSize("128KB");
		return factory.createMultipartConfig();
	}

	@Bean
	public ProviderContractRest providerContractRest() {
		ProviderContractRest providerContractRest = new ProviderContractRest();
		providerContractRest.setProviderContractService(providerContractService);
		return providerContractRest;
	}

	@Bean
	public PolicyRest policyRest() {
		PolicyRest policyRest = new PolicyRest();
		policyRest.setClaimService(claimService);
		return policyRest;
	}

	@Bean
	public BillingRest billingRest() {
		BillingRest billingRest = new BillingRest();
		billingRest.setBillingService(billingService);
		return billingRest;
	}

	@Bean
	public BenefitSetupRest benefitSetup() {
		BenefitSetupRest benefitSetup = new BenefitSetupRest();
		benefitSetup.setPlanService(planService);
		benefitSetup.setCmicEnvironmentHelper(cmicEnvironmentHelper);
		return benefitSetup;
	}

	@Bean
	public HCInternetRest hcInternetRest() {
		HCInternetRest hcInternetRest = new HCInternetRest();

		hcInternetRest.setClaimsSubmissionHelper(claimsSubmissionHelper);
		//		hcInternetRest.setCMiCEnvironmentHelper(cmicEnvironmentHelper);
		hcInternetRest.setWorkflowService(workflowService);

		hcInternetRest.setClaimService(claimService);
		hcInternetRest.setClaimPaymentService(claimPaymentService);
		hcInternetRest.setCommonDataService(commonDataService);
		hcInternetRest.setPartyService(partyService);
		hcInternetRest.setClaimHistoryService(claimHistoryService);
		hcInternetRest.setBatchControlService(batchControlService);
		hcInternetRest.setCmicEnvironmentHelper(cmicEnvironmentHelper);
		return hcInternetRest;
	}

	@Bean
	public ClaimHistoryRest claimHistoryRest() {
		ClaimHistoryRest claimHistoryRest = new ClaimHistoryRest();
		claimHistoryRest.setClaimHistoryService(claimHistoryService);
		claimHistoryRest.setClaimService(claimService);

		return claimHistoryRest;
	}

	@Bean
	public MigrationRest migrationRest() {
		MigrationRest migrationRest = new MigrationRest();
		migrationRest.setCase360Helper(case360Helper);
		migrationRest.setClaimService(claimService);
		migrationRest.setCmicEnvironmentHelper(cmicEnvironmentHelper);
		migrationRest.setWorkflowService(workflowService);

		return migrationRest;
	}

	@Bean
	public ClaimEnquiryRest claimEnquiryRest() {
		ClaimEnquiryRest claimEnquiryRest = new ClaimEnquiryRest();
		claimEnquiryRest.setClaimService(claimService);
		return claimEnquiryRest;
	}

	@Bean
	public BatchControlRest batchControlRest() {
		BatchControlRest batchControlRest = new BatchControlRest();
		batchControlRest.setBatchControlService(batchControlService);
		return batchControlRest;
	}

	@Bean
	public AgencyPaymentRest agencyPaymentRest() {
		AgencyPaymentRest agencyPaymentRest = new AgencyPaymentRest();
		agencyPaymentRest.setAgencyPaymentService(agencyPaymentService);
		return agencyPaymentRest;
	}

	@Bean
	public UtilityRest utillityRest() {
		UtilityRest utillityRest = new UtilityRest();
		utillityRest.setClaimHelper(cmicHelper);
		utillityRest.setClaimService(claimService);
		utillityRest.setMailService(mailService);
		utillityRest.setPolicyService(policyService);
		utillityRest.setCommonDataService(commonDataService);
		utillityRest.setSettlementService(settlementService);
		utillityRest.setClaimDeductService(claimDeductService);
		utillityRest.setWorkflowService(workflowService);
		utillityRest.setTransactionLogService(transactionLogService);
		utillityRest.setPlanService(planService);
		utillityRest.setCase360Helper(case360Helper);
		return utillityRest;
	}

	@Bean
	public PhysicianRest physicianRest() {
		PhysicianRest physicianRest = new PhysicianRest();
		physicianRest.setPhysicianService(physicianService);
		return physicianRest;
	}

	@Bean
	public StandardBillingRest standBillingRest() {
		StandardBillingRest standBillingRest = new StandardBillingRest();
		standBillingRest.setStandardBillingService(standardBillingService);
		return standBillingRest;
	}
}
