package com.aia.cmic.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.aia.cmic.data.auditing.AuditingDateTimeProvider;
import com.aia.cmic.data.domain.UsernameAuditorAware;

@Configuration
@EnableTransactionManagement
@EnableJpaAuditing(dateTimeProviderRef = "dateTimeProvider", auditorAwareRef = "auditorProvider")
@EnableJpaRepositories(basePackages = { "com.aia.cmic.entity" })
public class HibernateConfig {

	/*
	@Bean
	@Autowired
	public JpaTransactionManager transactionManager(LocalContainerEntityManagerFactoryBean lcemfb) {
		JpaTransactionManager txManager = new JpaTransactionManager(lcemfb.getObject());
		return txManager;
	}

	@Bean
	@Autowired
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(DataSource DataSource) {
		LocalContainerEntityManagerFactoryBean lcemfb = new LocalContainerEntityManagerFactoryBean();
		lcemfb.setDataSource(DataSource);
		lcemfb.setPersistenceUnitName(environment.getRequiredProperty("cmic.persistenceUnitName"));
		LoadTimeWeaver loadTimeWeaver = new InstrumentationLoadTimeWeaver();
		lcemfb.setLoadTimeWeaver(loadTimeWeaver);
		return lcemfb;
	}
	*/

	@Bean
	AuditorAware<String> auditorProvider() {
		return new UsernameAuditorAware();
	}

	@Bean
	DateTimeProvider dateTimeProvider() {
		return new AuditingDateTimeProvider();
	}
}
