package com.aia.cmic.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.entity.CommonCode;
import com.aia.cmic.entity.ICD10Code;
import com.aia.cmic.entity.Provider;
import com.aia.cmic.model.CommonCodeMaster;
import com.aia.cmic.model.Lookup;
import com.aia.cmic.model.MasterLookup;
import com.aia.cmic.repository.CommonCodeRepository;
import com.aia.cmic.repository.LookUpRepository;
import com.aia.cmic.repository.rest.response.lookup.IngTedit;
import com.aia.cmic.repository.rest.response.lookup.retrievelookup.RetrieveLookupIgmTeditResponse;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.SecurityControlService;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.FormatUtil;

public class CachingMasterDataHelper {

	private static final Logger LOG = LoggerFactory.getLogger(CachingMasterDataHelper.class);

	@Autowired
	private SecurityControlService securityControlService;

	@Autowired
	private LookUpRepository lookUpRepository;

	private static final String CATEGORY_ADDRESS = "Address";
	private static final String CATEGORY_CLAIM = "Claim";
	private static final String CATEGORY_CLAIM_PAYMENT = "ClaimPayment";
	private static final String CATEGORY_CLAIM_REQUIREMENT_INFO = "ClaimRequirementInfo";
	private static final String CATEGORY_COMMENT = "Comment";
	private static final String CATEGORY_COMMON = "Common";
	private static final String CATEGORY_EXCHANGERATE = "ExchangeRate";
	private static final String CATEGORY_INSERT_RIDER = "InsertRider";
	private static final String CATEGORY_LOGGING = "Logging";
	private static final String CATEGORY_NETWORK = "Network";
	private static final String CATEGORY_PAYMENT_SEQ = "PaymentSeq";
	private static final String CATEGORY_PHYSICIAN = "Physician";
	private static final String CATEGORY_PROVIDER = "Provider";
	private static final String CATEGORY_PROVIDER_CONTRACT = "ProviderContract";
	private static final String CATEGORY_PROVIDER_CONTRACT_DETAIL = "ProviderContractDetail";
	private static final String CATEGORY_TREATMENT_TYPE = "TreatmentType";
	private static final String CATEGORY_AGENCY = "Agency";
	private static final String CATEGORY_PLAN = "Plan";
	private static final String CATEGORY_PRODUCT = "Product";
	private static final String CATEGORY_EFORM = "EForm";
	private static final String CATEGORY_VALIDATION = "Validation";
	private static final String CATEGORY_CORRESPONDENCE = "Correspondence";

	private static final String CODENAME_AIA_QUALITY_TIER = "AIAQualityTier";
	private static final String CODENAME_ADJUST_REASON = "AdjustReason";
	private static final String CODENAME_ANESTHESIAI_ND = "AnesthesiaInd";
	private static final String CODENAME_AWARD = "Award";
	private static final String CODENAME_BANK_CODE = "BankCode";
	private static final String CODENAME_BENEFIT_TYPE = "BenefitType";
	private static final String CODENAME_BILLING_DECLINE_REASON = "BillingDeclineReason";
	private static final String CODENAME_BILLING_STATUS = "BillingStatus";
	private static final String CODENAME_BLACKLIST_IND = "BlacklistInd";
	private static final String CODENAME_BLACKLIST_REASON = "BlacklistReason";
	private static final String CODENAME_BUSINESS_LINE = "BusinessLine";
	private static final String CODENAME_NETWORK_SPECIFIC_PRODUCT = "NetworkSpecificProduct";
	private static final String CODENAME_CAUSE_OF_TREATMENT = "CauseOfTreatment";
	private static final String CODENAME_CHANNEL = "Channel";
	private static final String CODENAME_CLAIM_REQUIREMENT_STATUS = "ClaimRequirementStatus";
	private static final String CODENAME_CLAIM_STATUS = "ClaimStatus";
	private static final String CODENAME_CLASS_OF_BED = "ClassOfBed";
	private static final String CODENAME_CODING_USED = "CodingUsed";
	private static final String CODENAME_COMMENT_TYPE = "CommentType";
	private static final String CODENAME_CONTACT_TYPE = "ContactType";
	private static final String CODENAME_CONTRACT_STATUS = "ContractStatus";
	private static final String CODENAME_CURRENCY_CODE = "CurrencyCode";
	private static final String CODENAME_DEBUG_FLAG = "DebugFlag";
	private static final String CODENAME_DECLINE_REASON = "DeclineReason";
	private static final String CODENAME_DEPENDENT_TYPE = "DependentType";
	private static final String CODENAME_DIAGNOSTIC_TEST = "DiagnosticTest";
	private static final String CODENAME_DISEASE_IND = "DiseaseInd";
	private static final String CODENAME_DOCUMENT_TYPE = "DocumentType";
	private static final String CODENAME_DRUG_AND_MEDICATION = "DrugAndMedication";
	private static final String CODENAME_ELIGIBILITY = "Eligibility";
	private static final String CODENAME_FAX_CLAIM_SCORE = "FaxClaimScore";
	private static final String CODENAME_GENDER = "Gender";
	private static final String CODENAME_ICU_REASON = "IcuReason";
	private static final String CODENAME_INSERT_RIDER = "InsertRider";
	private static final String CODENAME_LEVEL_OF_CONSCIOUSNESS = "LevelOfConsciousness";
	private static final String CODENAME_HBP_TYPE = "HbpType";
	private static final String CODENAME_HOLD_SERVICE = "HoldServices";
	private static final String CODENAME_HOSPITALIZATION_REASON = "HospitalizationReason";
	private static final String CODENAME_MAJOR_ACC_ID = "MajorAccId";
	private static final String CODENAME_MAJOR_INJURY_DETAIL = "MajorInjuryDetail";
	private static final String CODENAME_MEDICAL_SPECIALTY = "MedicalSpecialty";
	private static final String CODENAME_NETWORK_TYPE = "NetworkType";
	private static final String CODENAME_PAYEE_TYPE = "PayeeType";
	private static final String CODENAME_PAYMENT_CYCLE = "PaymentCycle";
	private static final String CODENAME_PAYMENT_METHOD = "PaymentMethod";
	private static final String CODENAME_PAYMENT_SEQ = "PaymentSeq";
	private static final String CODENAME_PHASE = "Phase";
	private static final String CODENAME_PHYSICIAN_STATUS = "PhysicianStatus";
	private static final String CODENAME_PHYSICIAN_TYPE = "PhysicianType";
	private static final String CODENAME_PHYSICIAN_WARNING_CODE = "PhysicianWarningCode";
	private static final String CODENAME_PLACE = "Place";
	private static final String CODENAME_PRIVATE_INSURANCE = "PrivateInsurance";
	private static final String CODENAME_PROCESS_STATUS = "ProcessStatus";
	private static final String CODENAME_PROVIDER_AFFORDABILITY_TIER = "ProviderAffordabilityTier";
	private static final String CODENAME_PROVIDER_CONTRACT_TYPE = "ProviderContractType";
	private static final String CODENAME_PROVIDER_GROUP = "ProviderGroup";
	private static final String CODENAME_PROVIDER_STATUS = "ProviderStatus";
	private static final String CODENAME_PROVIDER_TYPE = "ProviderType";
	private static final String CODENAME_PROVIDER_TYPE_SECTOR = "ProviderTypeSector";
	private static final String CODENAME_PROVIDER_WARNING_CODE = "ProviderWarningCode";
	private static final String CODENAME_PROVINCE = "Province";
	private static final String CODENAME_PUBLIC_INSURANCE = "PublicInsurance";
	private static final String CODENAME_REGION = "Region";
	private static final String CODENAME_RELATIONSHIP = "Relationship";
	private static final String CODENAME_ROOM_TYPE = "RoomType";
	private static final String CODENAME_SERVICE_PRIORITY = "ServicePriority";
	private static final String CODENAME_SERVICE_PROVIDED = "ServiceProvided";
	private static final String CODENAME_SPECIALY = "Specialy";
	private static final String CODENAME_SUBMISSION_TYPE = "SubmissionType";
	private static final String CODENAME_TREATMENT_TYPE = "TreatmentType";
	private static final String CODENAME_PAYMENT_CODITION = "PaymentCodition";
	private static final String CODENAME_DISTRIBUTE_CODITION = "DistributeCodition";
	private static final String CODENAME_SYSTEM_ELIGIBILITY = "SystemEligibility";
	private static final String CODENAME_PLAN_STATUS = "PlanStatus";
	private static final String CODENAME_PENDING_FORM = "Pending";
	private static final String CODENAME_HOSPITAL_FORM = "Hospital";
	private static final String CODENAME_OTHER_FORM = "Other";
	private static final String CODENAME_EFORM_FORM = "EForm";
	private static final String CODENAME_IE_FORM = "IE";
	private static final String CODENAME_ACTION_TOKEN = "ActionTaken";
	private static final String CODENAME_REVIEW = "Review";
	private static final String CODENAME_REPORT = "Report";
	private static final String CODENAME_CRIT_ILL = "CriticalIllness";
	private static final String CODENAME_STP_TYPE = "STPModule";

	@Autowired
	private CommonCodeRepository commonCodeRepository;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private ProviderService providerService;

	private Map<String, CommonCode> aiaQualityTierMap = new HashMap<>();
	private Map<String, CommonCode> adjustReasonMap = new HashMap<>();
	private Map<String, CommonCode> anesthesiaIndMap = new HashMap<>();
	private Map<String, CommonCode> awardMap = new HashMap<>();
	private Map<String, CommonCode> bankCodeMap = new HashMap<>();
	private Map<String, CommonCode> benefitTypeMap = new HashMap<>();
	private Map<String, CommonCode> billingDeclineReasonMap = new HashMap<>();
	private Map<String, CommonCode> billingStatusMap = new HashMap<>();
	private Map<String, CommonCode> blacklistIndMap = new HashMap<>();
	private Map<String, CommonCode> blacklistReasonMap = new HashMap<>();
	private Map<String, CommonCode> businessLineMap = new HashMap<>();
	private Map<String, CommonCode> causeOfTreatmentMap = new HashMap<>();
	private Map<String, CommonCode> channelMap = new HashMap<>();
	private Map<String, CommonCode> claimRequirementStatusMap = new HashMap<>();
	private Map<String, CommonCode> claimStatusMap = new HashMap<>();
	private Map<String, CommonCode> classOfBedMap = new HashMap<>();
	private Map<String, CommonCode> codingUsedMap = new HashMap<>();
	private Map<String, CommonCode> commentTypeMap = new HashMap<>();
	private Map<String, CommonCode> contactTypeMap = new HashMap<>();
	private Map<String, CommonCode> contractStatusMap = new HashMap<>();
	private Map<String, CommonCode> currencyCodeMap = new HashMap<>();
	private Map<String, CommonCode> debugFlagMap = new HashMap<>();
	private Map<String, CommonCode> declineReasonMap = new HashMap<>();
	private Map<String, CommonCode> dependentTypeMap = new HashMap<>();
	private Map<String, CommonCode> diagnosticTestMap = new HashMap<>();
	private Map<String, CommonCode> diseaseIndMap = new HashMap<>();
	private Map<String, CommonCode> documentTypeMap = new HashMap<>();
	private Map<String, CommonCode> drugAndMedicationMap = new HashMap<>();
	private Map<String, CommonCode> eligibilityMap = new HashMap<>();
	private Map<String, CommonCode> faxClaimScoreMap = new HashMap<>();
	private Map<String, CommonCode> genderMap = new HashMap<>();
	private Map<String, CommonCode> icuReasonMap = new HashMap<>();
	private Map<String, CommonCode> insertRiderMap = new HashMap<>();
	private Map<String, CommonCode> levelOfConsciousnessMap = new HashMap<>();
	private Map<String, CommonCode> hbpTypeMap = new HashMap<>();
	private Map<String, CommonCode> holdServiceMap = new HashMap<>();
	private Map<String, CommonCode> hospitalizationReasonMap = new HashMap<>();
	private Map<String, CommonCode> majorAccIdMap = new HashMap<>();
	private Map<String, CommonCode> majorInjuryDetailMap = new HashMap<>();
	private Map<String, CommonCode> medicalSpecialtyMap = new HashMap<>();
	private Map<String, CommonCode> networkTypeMap = new HashMap<>();
	private Map<String, CommonCode> networkSpecificProductMap = new HashMap<>();
	private Map<String, CommonCode> payeeTypeMap = new HashMap<>();
	private Map<String, CommonCode> paymentCycleMap = new HashMap<>();
	private Map<String, CommonCode> claimPaymentMethodMap = new HashMap<>();
	private Map<String, CommonCode> providerPaymentMethodMap = new HashMap<>();
	private Map<String, CommonCode> paymentSeqMap = new HashMap<>();
	private Map<String, CommonCode> phaseMap = new HashMap<>();
	private Map<String, CommonCode> physicianStatusMap = new HashMap<>();
	private Map<String, CommonCode> physicianTypeMap = new HashMap<>();
	private Map<String, CommonCode> physicianWarningCodeMap = new HashMap<>();
	private Map<String, CommonCode> placeMap = new HashMap<>();
	private Map<String, CommonCode> privateInsuranceMap = new HashMap<>();
	private Map<String, CommonCode> processStatusMap = new HashMap<>();
	private Map<String, CommonCode> providerAffordabilityTierMap = new HashMap<>();
	private Map<String, CommonCode> providerContractTypeMap = new HashMap<>();
	private Map<String, CommonCode> providerGroupMap = new HashMap<>();
	private Map<String, CommonCode> providerStatusMap = new HashMap<>();
	private Map<String, CommonCode> providerTypeMap = new HashMap<>();
	private Map<String, CommonCode> providerTypeSectorMap = new HashMap<>();
	private Map<String, CommonCode> providerWarningCodeMap = new HashMap<>();
	private Map<String, CommonCode> provinceMap = new HashMap<>();
	private Map<String, CommonCode> publicInsuranceMap = new HashMap<>();
	private Map<String, CommonCode> regionMap = new HashMap<>();
	private Map<String, CommonCode> relationshipMap = new HashMap<>();
	private Map<String, CommonCode> roomTypeMap = new HashMap<>();
	private Map<String, CommonCode> servicePriorityMap = new HashMap<>();
	private Map<String, CommonCode> serviceProvidedMap = new HashMap<>();
	private Map<String, CommonCode> specialyMap = new HashMap<>();
	private Map<String, CommonCode> submissionTypeMap = new HashMap<>();
	private Map<String, CommonCode> treatmentTypeMap = new HashMap<>();
	private Map<String, CommonCode> paymentCoditionMap = new HashMap<>();
	private Map<String, CommonCode> distributeCoditionMap = new HashMap<>();
	private Map<String, CommonCode> systemEligibilityMap = new HashMap<>();
	private Map<String, CommonCode> planStatusMap = new HashMap<>();
	private Map<String, CommonCode> pendingTypeMap = new HashMap<>();
	private Map<String, CommonCode> eFormTypeMap = new HashMap<>();
	private Map<String, CommonCode> ieTypeMap = new HashMap<>();
	private Map<String, CommonCode> validationActionTakenMap = new HashMap<>();
	private Map<String, CommonCode> validationReviewMap = new HashMap<>();
	private Map<String, CommonCode> correspondenceReportMap = new HashMap<>();
	private Map<String, CommonCode> criticalIllnessMap = new HashMap<>();
	private Map<String, CommonCode> stpMap = new HashMap<>();

	private Map<String, CommonCode> docHospitalTypeMap = new HashMap<>();
	
	private Map<String, CommonCode> docOtherTypeMap = new HashMap<>();

	private Map<Integer, List<CommonCode>> provinceParentMap = new HashMap<>();

	private Map<String, Integer> mapSubPlanCode = new HashMap<>();

	private Map<String, String> providerNameThaiMap = new HashMap<>();

	private MasterLookupValueComparator masterLookupValueComparator = new MasterLookupValueComparator();
	private CommonCodeComparator commonCodeComparator = new CommonCodeComparator();

	private void reloadProviderNameThai() {
		synchronized (providerNameThaiMap) {
			providerNameThaiMap.clear();
			List<Provider> providers = providerService.findAllProviders();
			for (Provider provider : providers) {
				providerNameThaiMap.put(provider.getProviderCode(), provider.getProviderNameThai());
			}
		}
	}

	private void reloadMasterData(String codeName, String category, Map<String, CommonCode> map) {
		map.clear();
		List<CommonCode> lstCommonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeName(category, codeName);
		for (CommonCode commonCode : lstCommonCode) {
			map.put(commonCode.getCodeValue(), commonCode);
		}
	}

	private void reloadMasterData(String category, Map<String, CommonCode> map) {
		map.clear();
		List<CommonCode> lstCommonCode = commonCodeRepository.findCommonCodeByCategory(category);
		for (CommonCode commonCode : lstCommonCode) {
			map.put(commonCode.getCodeValue(), commonCode);
		}
	}

	private void reloadProvinceData(String codeName, String category, Map<String, CommonCode> map, Map<Integer, List<CommonCode>> parentMap) {
		map.clear();
		List<CommonCode> lstCommonCode = commonCodeRepository.findCommonCodeByCategoryAndCodeName(category, codeName);
		for (CommonCode commonCode : lstCommonCode) {
			map.put(commonCode.getCodeValue(), commonCode);
			List<CommonCode> parentList = parentMap.get(commonCode.getReferCommonCodeId());
			if (parentList == null) {
				parentList = new ArrayList<>();
				parentMap.put(commonCode.getReferCommonCodeId(), parentList);
			}
			parentList.add(commonCode);
		}
	}

	public void reloadSubPlanCode() {
		synchronized (mapSubPlanCode) {
			//reloadSubPlanCode("1", "STB2", mapSubPlanCode);
			loadSubPlanCode("1", "STB2", mapSubPlanCode, true);
		}
	}

	public void reloadEmptySubPlanCode() {
		synchronized (mapSubPlanCode) {
			//reloadSubPlanCode("1", "STB2", mapSubPlanCode);
			loadSubPlanCode("1", "STB2", mapSubPlanCode, false);
		}
	}

	public void loadSubPlanCode(String companyId, String tableName, Map<String, Integer> map, boolean forceClear) {
		if (forceClear) {
			map.clear();
		}
		if (map.isEmpty()) {
			resetSubPlanCode(companyId, tableName, map);
		}
	}

	private void resetSubPlanCode(String companyId, String tableName, Map<String, Integer> map) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("companyId", companyId);
		params.put("tableName", tableName);
		try {
			RetrieveLookupIgmTeditResponse response = lookUpRepository.retrieveLookupService("/rest/AIAService/lookup/retrieveLookup/RetrieveLookupIgmTeditList", params);
			List<IngTedit> ingTeditList = response.getIngTeditList();
			if (CollectionUtils.isNotEmpty(ingTeditList)) {
				for (IngTedit ingTedit : ingTeditList) {
					String tableValueDesc = ingTedit.getTableValueDesc();
					String tableValue = ingTedit.getTableValue();
					if (!FormatUtil.IsEmptyWithTrim(tableValueDesc)) {
						LOG.debug("resetSubPlanCode: value={}, descr={}", tableValue, tableValueDesc);
						if (Arrays.asList("I1", "I2", "I3", "I4").contains(tableValue)) {
							if (tableValueDesc.indexOf("60MB") != -1) {
								map.put(tableValue, 12000);
							} else if (tableValueDesc.indexOf("120MB") != -1) {
								map.put(tableValue, 25000);
							} else {
								map.put(tableValue, 0);
							}
						} else {
							String[] tableValueDescs = tableValueDesc.split(" ");
							if (tableValueDescs.length > 1) {
								String subCodeStr = tableValueDescs[tableValueDescs.length - 1];
								int subCode = 0;
								try {
									subCode = Integer.parseInt(subCodeStr);
								} catch (NumberFormatException e) {
								}
								map.put(tableValue, subCode);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	public List<Lookup> reloadICD10Code() {
		List<ICD10Code> icd10CodeList = commonDataService.getAllICD10Code();
		Collections.sort(icd10CodeList, new Comparator<ICD10Code>() {
			@Override
			public int compare(ICD10Code o1, ICD10Code o2) {
				return o1.getIcd10Code().compareTo(o2.getIcd10Code());
			}
		});
		return CMiCUtil.transformToIcdLookupList(icd10CodeList);
	}

	private List<MasterLookup> cloneAndConvertProvinceData(List<CommonCode> lst) {
		List<MasterLookup> result = new ArrayList<>();
		for (CommonCode entry : lst) {
			result.add(new MasterLookup(entry.getCodeValue(), entry.getCodeDesc()));
		}
		return result;
	}

	private List<MasterLookup> cloneAndConvertRegionData(Map<String, CommonCode> map) {
		List<MasterLookup> result = new ArrayList<>();
		for (Map.Entry<String, CommonCode> entry : map.entrySet()) {
			CommonCode commonCode = entry.getValue();
			result.add(new MasterLookup(commonCode.getCommonCodeId().toString(), commonCode.getCodeDesc()));
		}
		return result;
	}

	private List<MasterLookup> cloneAndConvertMasterData(Map<String, CommonCode> map) {
		List<MasterLookup> result = new ArrayList<>();
		List<CommonCode> lst = new ArrayList<>(map.values());
		Collections.sort(lst, commonCodeComparator);
		for (CommonCode commonCode : lst) {
			result.add(new MasterLookup(commonCode.getCodeValue(), FormatUtil.convertNull(commonCode.getCodeDesc())));
		}
		return result;
	}

	private List<MasterLookup> cloneAndConvertMasterDataWithCodeDashDesc(Map<String, CommonCode> map) {
		List<MasterLookup> result = new ArrayList<>();
		List<CommonCode> lst = new ArrayList<>(map.values());
		Collections.sort(lst, commonCodeComparator);
		for (CommonCode commonCode : lst) {
			result.add(new MasterLookup(commonCode.getCodeValue(), commonCode.getCodeValue() + " - " + commonCode.getCodeDesc()));
		}
		return result;
	}

	private List<MasterLookup> cloneAndConvertMasterDataDescLong(Map<String, CommonCode> map) {
		List<MasterLookup> result = new ArrayList<>();
		List<CommonCode> lst = new ArrayList<>(map.values());
		Collections.sort(lst, commonCodeComparator);
		for (CommonCode commonCode : lst) {
			result.add(new MasterLookup(commonCode.getCodeValue(), commonCode.getCodeDescLong()));
		}
		return result;
	}

	private List<MasterLookup> cloneAndConvertMasterDataWithSorted(Map<String, CommonCode> map) {
		List<MasterLookup> result = cloneAndConvertMasterData(map);
		MasterLookup[] array = result.toArray(new MasterLookup[result.size()]);
		Arrays.sort(array, masterLookupValueComparator);
		return Arrays.asList(array);
	}

	private CommonCodeMaster cloneAndConvertMasterData(CommonCode commonCode) {
		return commonCode == null ? null : new CommonCodeMaster(commonCode);
	}

	@PostConstruct
	public void init() {
		reloadAIAQualityTier();
		reloadAdjustReason();
		reloadAnesthesiaInd();
		reloadAward();
		reloadBankCode();
		reloadBenefitType();
		reloadBillingDeclineReason();
		reloadBillingStatus();
		reloadBlacklistInd();
		reloadBlacklistReason();
		reloadBusinessLine();
		reloadCauseOfTreatment();
		reloadChannel();
		reloadClaimPaymentMethod();
		reloadClaimRequirementStatus();
		reloadClaimStatus();
		reloadClassOfBed();
		reloadCodingUsed();
		reloadCommentType();
		reloadContactType();
		reloadContractStatus();
		reloadCurrencyCode();
		reloadDebugFlag();
		reloadDeclineReason();
		reloadDependentType();
		reloadDiagnosticTest();
		reloadDiseaseInd();
		reloadDocumentType();
		reloadDrugAndMedication();
		reloadEligibility();
		reloadFaxClaimScore();
		reloadGender();
		reloadIcuReason();
		reloadInsertRider();
		reloadLevelOfConsciousness();
		reloadHbpType();
		reloadHoldService();
		reloadHospitalizationReason();
		reloadMajorAccId();
		reloadCriticalIllness();
		reloadMajorInjuryDetail();
		reloadMedicalSpecialty();
		reloadNetworkType();
		reloadNetworkSpecificProduct();
		reloadPayeeType();
		reloadPaymentCycle();
		reloadPaymentSeq();
		reloadPhase();
		reloadPhysicianStatus();
		reloadPhysicianType();
		reloadPhysicianWarningCode();
		reloadPlace();
		reloadPrivateInsurance();
		reloadProcessStatus();
		reloadProviderAffordabilityTier();
		reloadProviderContractType();
		reloadProviderGroup();
		reloadProviderPaymentMethod();
		reloadProviderStatus();
		reloadProviderType();
		reloadProviderTypeSector();
		reloadProviderWarningCode();
		reloadProvince();
		reloadPublicInsurance();
		reloadRegion();
		reloadRelationship();
		reloadRoomType();
		reloadServicePriority();
		reloadServiceProvided();
		reloadSpecialy();
		reloadStp();
		reloadSubmissionType();
		reloadTreatmentType();
		reloadPaymentCodition();
		reloadDistributeCodition();
		reloadSystemEligibilityMap();
		reloadPlanStatusMap();
		reloadPendingFormTypeMap();
		reloadEFormTypeMap();
		reloadIETypeMap();
		reloadValidationActionTakenMapp();
		reloadValidationReviewMap();
		reloadCorrespondenceReportMap();
		reloadSubPlanCode();
		reloadProviderNameThai();
		reloadDocHospitalTypeMap();
		reloadDocOtherTypeMap();
		
	}

	private void reloadDocOtherTypeMap() {
		// TODO Auto-generated method stub
		synchronized (docOtherTypeMap) {
			reloadMasterData(CODENAME_OTHER_FORM, CATEGORY_EFORM, docOtherTypeMap);
		}
	}

	public void reloadDocHospitalTypeMap() {
		synchronized (docHospitalTypeMap) {
			reloadMasterData(CODENAME_HOSPITAL_FORM, CATEGORY_EFORM, docHospitalTypeMap);
		}
	}

	public List<MasterLookup> getDocHospitalTypeMapByDesc() {
		synchronized (docHospitalTypeMap) {
			return cloneAndConvertMasterData(docHospitalTypeMap);
		}
	}

	public List<MasterLookup> getDocHospitalTypeMapByDescLong() {
		synchronized (docHospitalTypeMap) {
			return cloneAndConvertMasterDataDescLong(docHospitalTypeMap);
		}
	}
	
	public List<MasterLookup> getDocOtherTypeMapByDesc() {
		synchronized (docOtherTypeMap) {
			return cloneAndConvertMasterData(docOtherTypeMap);
		}
	}
	
	public List<MasterLookup> getDocOtherMapByDescLong() {
		synchronized (docOtherTypeMap) {
			return cloneAndConvertMasterDataDescLong(docOtherTypeMap);
		}
	}

	public void reloadPendingFormTypeMap() {
		synchronized (pendingTypeMap) {
			reloadMasterData(CODENAME_PENDING_FORM, CATEGORY_EFORM, pendingTypeMap);
		}
	}

	public List<MasterLookup> getPendingTypeMapByDesc() {
		synchronized (pendingTypeMap) {
			return cloneAndConvertMasterData(pendingTypeMap);
		}
	}

	public List<MasterLookup> getPendingTypeMapByDescLong() {
		synchronized (pendingTypeMap) {
			return cloneAndConvertMasterDataDescLong(pendingTypeMap);
		}
	}

	public void reloadIETypeMap() {
		synchronized (ieTypeMap) {
			reloadMasterData(CODENAME_IE_FORM, CATEGORY_EFORM, ieTypeMap);
		}
	}

	public List<MasterLookup> getIETypeMapByDescLong() {
		synchronized (ieTypeMap) {
			return cloneAndConvertMasterDataDescLong(ieTypeMap);
		}
	}

	public List<MasterLookup> getIETypeMapByDesc() {
		synchronized (ieTypeMap) {
			return cloneAndConvertMasterData(ieTypeMap);
		}
	}

	public void reloadEFormTypeMap() {
		synchronized (eFormTypeMap) {
			reloadMasterData(CODENAME_EFORM_FORM, CATEGORY_EFORM, eFormTypeMap);
		}
	}

	public List<MasterLookup> getEFormTypeMapByDescLong() {
		synchronized (eFormTypeMap) {
			return cloneAndConvertMasterDataDescLong(eFormTypeMap);
		}
	}

	public List<MasterLookup> getEFormTypeMapByDesc() {
		synchronized (eFormTypeMap) {
			return cloneAndConvertMasterData(eFormTypeMap);
		}
	}

	public void reloadAIAQualityTier() {
		synchronized (aiaQualityTierMap) {
			reloadMasterData(CODENAME_AIA_QUALITY_TIER, CATEGORY_PROVIDER, aiaQualityTierMap);
		}
	}

	public List<MasterLookup> getAIAQualityTier() {
		synchronized (aiaQualityTierMap) {
			return cloneAndConvertMasterData(aiaQualityTierMap);
		}
	}

	public CommonCodeMaster findAIAQualityTier(String value) {
		synchronized (aiaQualityTierMap) {
			return value == null ? null : cloneAndConvertMasterData(aiaQualityTierMap.get(value));
		}
	}

	public void reloadAdjustReason() {
		synchronized (adjustReasonMap) {
			reloadMasterData(CODENAME_ADJUST_REASON, CATEGORY_CLAIM_PAYMENT, adjustReasonMap);
		}
	}

	public List<MasterLookup> getAdjustReason() {
		synchronized (adjustReasonMap) {
			return cloneAndConvertMasterData(adjustReasonMap);
		}
	}

	public CommonCodeMaster findAdjustReason(String value) {
		synchronized (adjustReasonMap) {
			return value == null ? null : cloneAndConvertMasterData(adjustReasonMap.get(value));
		}
	}

	public void reloadAnesthesiaInd() {
		synchronized (anesthesiaIndMap) {
			reloadMasterData(CODENAME_ANESTHESIAI_ND, CATEGORY_CLAIM, anesthesiaIndMap);
		}
	}

	public List<MasterLookup> getAnesthesiaInd() {
		synchronized (anesthesiaIndMap) {
			return cloneAndConvertMasterData(anesthesiaIndMap);
		}
	}

	public CommonCodeMaster findAnesthesiaInd(String value) {
		synchronized (anesthesiaIndMap) {
			return value == null ? null : cloneAndConvertMasterData(anesthesiaIndMap.get(value));
		}
	}

	public void reloadAward() {
		synchronized (awardMap) {
			reloadMasterData(CODENAME_AWARD, CATEGORY_PROVIDER, awardMap);
		}
	}

	public List<MasterLookup> getAward() {
		synchronized (awardMap) {
			return cloneAndConvertMasterData(awardMap);
		}
	}

	public CommonCodeMaster findAward(String value) {
		synchronized (awardMap) {
			return value == null ? null : cloneAndConvertMasterData(awardMap.get(value));
		}
	}

	public void reloadStp() {
		synchronized (stpMap) {
			reloadMasterData(CODENAME_STP_TYPE, CATEGORY_PROVIDER, stpMap);
		}
	}

	public List<MasterLookup> getStp() {
		synchronized (stpMap) {
			return cloneAndConvertMasterData(stpMap);
		}
	}

	public CommonCodeMaster findStp(String value) {
		synchronized (stpMap) {
			return value == null ? null : cloneAndConvertMasterData(stpMap.get(value));
		}
	}

	public void reloadBankCode() {
		synchronized (bankCodeMap) {
			reloadMasterData(CODENAME_BANK_CODE, CATEGORY_COMMON, bankCodeMap);
		}
	}

	public List<MasterLookup> getBankCode() {
		synchronized (bankCodeMap) {
			return cloneAndConvertMasterDataWithCodeDashDesc(bankCodeMap);
		}
	}

	public CommonCodeMaster findBankCode(String value) {
		synchronized (bankCodeMap) {
			return value == null ? null : cloneAndConvertMasterData(bankCodeMap.get(value));
		}
	}

	public void reloadBenefitType() {
		synchronized (benefitTypeMap) {
			reloadMasterData(CODENAME_BENEFIT_TYPE, CATEGORY_PRODUCT, benefitTypeMap);
		}
	}

	public List<MasterLookup> getBenefitType() {
		synchronized (benefitTypeMap) {
			return cloneAndConvertMasterData(benefitTypeMap);
		}
	}

	public CommonCodeMaster findBenefitType(String value) {
		synchronized (benefitTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(benefitTypeMap.get(value));
		}
	}

	public void reloadBillingDeclineReason() {
		synchronized (billingDeclineReasonMap) {
			reloadMasterData(CODENAME_BILLING_DECLINE_REASON, CATEGORY_CLAIM, billingDeclineReasonMap);
		}
	}

	public List<MasterLookup> getBillingDeclineReason() {
		synchronized (billingDeclineReasonMap) {
			return cloneAndConvertMasterData(billingDeclineReasonMap);
		}
	}

	public CommonCodeMaster findBillingDeclineReason(String value) {
		synchronized (billingDeclineReasonMap) {
			return value == null ? null : cloneAndConvertMasterData(billingDeclineReasonMap.get(value));
		}
	}

	public void reloadBillingStatus() {
		synchronized (billingStatusMap) {
			reloadMasterData(CODENAME_BILLING_STATUS, CATEGORY_CLAIM, billingStatusMap);
		}
	}

	public List<MasterLookup> getBillingStatus() {
		synchronized (billingStatusMap) {
			return cloneAndConvertMasterData(billingStatusMap);
		}
	}

	public CommonCodeMaster findBillingStatus(String value) {
		synchronized (billingStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(billingStatusMap.get(value));
		}
	}

	public void reloadBlacklistInd() {
		synchronized (blacklistIndMap) {
			reloadMasterData(CODENAME_BLACKLIST_IND, CATEGORY_COMMON, blacklistIndMap);
		}
	}

	public List<MasterLookup> getBlacklistInd() {
		synchronized (blacklistIndMap) {
			return cloneAndConvertMasterData(blacklistIndMap);
		}
	}

	public CommonCodeMaster findBlacklistInd(String value) {
		synchronized (blacklistIndMap) {
			return value == null ? null : cloneAndConvertMasterData(blacklistIndMap.get(value));
		}
	}

	public void reloadBlacklistReason() {
		synchronized (blacklistReasonMap) {
			reloadMasterData(CODENAME_BLACKLIST_REASON, CATEGORY_COMMON, blacklistReasonMap);
		}
	}

	public List<MasterLookup> getBlacklistReason() {
		synchronized (blacklistReasonMap) {
			return cloneAndConvertMasterData(blacklistReasonMap);
		}
	}

	public CommonCodeMaster findBlacklistReason(String value) {
		synchronized (blacklistReasonMap) {
			return value == null ? null : cloneAndConvertMasterData(blacklistReasonMap.get(value));
		}
	}

	public void reloadBusinessLine() {
		synchronized (businessLineMap) {
			reloadMasterData(CODENAME_BUSINESS_LINE, CATEGORY_COMMON, businessLineMap);
		}
	}

	public List<MasterLookup> getBusinessLine() {
		synchronized (businessLineMap) {
			return cloneAndConvertMasterData(businessLineMap);
		}
	}

	public CommonCodeMaster findBusinessLine(String value) {
		synchronized (businessLineMap) {
			return value == null ? null : cloneAndConvertMasterData(businessLineMap.get(value));
		}
	}

	public void reloadCauseOfTreatment() {
		synchronized (causeOfTreatmentMap) {
			reloadMasterData(CODENAME_CAUSE_OF_TREATMENT, CATEGORY_CLAIM, causeOfTreatmentMap);
		}
	}

	public List<MasterLookup> getCauseOfTreatment() {
		synchronized (causeOfTreatmentMap) {
			return cloneAndConvertMasterData(causeOfTreatmentMap);
		}
	}

	public CommonCodeMaster findCauseOfTreatment(String value) {
		synchronized (causeOfTreatmentMap) {
			return value == null ? null : cloneAndConvertMasterData(causeOfTreatmentMap.get(value));
		}
	}

	public void reloadChannel() {
		synchronized (channelMap) {
			reloadMasterData(CODENAME_CHANNEL, CATEGORY_CLAIM, channelMap);
		}
	}

	public List<MasterLookup> getChannel() {
		synchronized (channelMap) {
			return cloneAndConvertMasterData(channelMap);
		}
	}

	public CommonCodeMaster findChannel(String value) {
		synchronized (channelMap) {
			return value == null ? null : cloneAndConvertMasterData(channelMap.get(value));
		}
	}

	public void reloadClaimRequirementStatus() {
		synchronized (claimRequirementStatusMap) {
			reloadMasterData(CODENAME_CLAIM_REQUIREMENT_STATUS, CATEGORY_CLAIM_REQUIREMENT_INFO, claimRequirementStatusMap);
		}
	}

	public List<MasterLookup> getClaimRequirementStatus() {
		synchronized (claimRequirementStatusMap) {
			return cloneAndConvertMasterData(claimRequirementStatusMap);
		}
	}

	public CommonCodeMaster findClaimRequirementStatus(String value) {
		synchronized (claimRequirementStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(claimRequirementStatusMap.get(value));
		}
	}

	public void reloadClaimStatus() {
		synchronized (claimStatusMap) {
			reloadMasterData(CODENAME_CLAIM_STATUS, CATEGORY_CLAIM, claimStatusMap);
		}
	}

	public List<MasterLookup> getClaimStatus() {
		synchronized (claimStatusMap) {
			return cloneAndConvertMasterData(claimStatusMap);
		}
	}

	public CommonCodeMaster findClaimStatus(String value) {
		synchronized (claimStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(claimStatusMap.get(value));
		}
	}

	public void reloadClassOfBed() {
		synchronized (classOfBedMap) {
			reloadMasterData(CODENAME_CLASS_OF_BED, CATEGORY_CLAIM, classOfBedMap);
		}
	}

	public List<MasterLookup> getClassOfBed() {
		synchronized (classOfBedMap) {
			return cloneAndConvertMasterData(classOfBedMap);
		}
	}

	public CommonCodeMaster findClassOfBed(String value) {
		synchronized (classOfBedMap) {
			return value == null ? null : cloneAndConvertMasterData(classOfBedMap.get(value));
		}
	}

	public void reloadCodingUsed() {
		synchronized (codingUsedMap) {
			reloadMasterData(CODENAME_CODING_USED, CATEGORY_PROVIDER, codingUsedMap);
		}
	}

	public List<MasterLookup> getCodingUsed() {
		synchronized (codingUsedMap) {
			return cloneAndConvertMasterData(codingUsedMap);
		}
	}

	public CommonCodeMaster findCodingUsed(String value) {
		synchronized (codingUsedMap) {
			return value == null ? null : cloneAndConvertMasterData(codingUsedMap.get(value));
		}
	}

	public void reloadCommentType() {
		synchronized (commentTypeMap) {
			reloadMasterData(CODENAME_COMMENT_TYPE, CATEGORY_COMMENT, commentTypeMap);
		}
	}

	public List<MasterLookup> getCommentType() {
		synchronized (commentTypeMap) {
			return cloneAndConvertMasterData(commentTypeMap);
		}
	}

	public CommonCodeMaster findCommentType(String value) {
		synchronized (commentTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(commentTypeMap.get(value));
		}
	}

	public void reloadContactType() {
		synchronized (contactTypeMap) {
			reloadMasterData(CODENAME_CONTACT_TYPE, CATEGORY_PROVIDER_CONTRACT, contactTypeMap);
		}
	}

	public List<MasterLookup> getContactType() {
		synchronized (contactTypeMap) {
			return cloneAndConvertMasterData(contactTypeMap);
		}
	}

	public CommonCodeMaster findContactType(String value) {
		synchronized (contactTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(contactTypeMap.get(value));
		}
	}

	public void reloadContractStatus() {
		synchronized (contractStatusMap) {
			reloadMasterData(CODENAME_CONTRACT_STATUS, CATEGORY_PROVIDER_CONTRACT, contractStatusMap);
		}
	}

	public List<MasterLookup> getContractStatus() {
		synchronized (contractStatusMap) {
			return cloneAndConvertMasterData(contractStatusMap);
		}
	}

	public CommonCodeMaster findContractStatus(String value) {
		synchronized (contractStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(contractStatusMap.get(value));
		}
	}

	public void reloadCurrencyCode() {
		synchronized (currencyCodeMap) {
			reloadMasterData(CODENAME_CURRENCY_CODE, CATEGORY_EXCHANGERATE, currencyCodeMap);
		}
	}

	public List<MasterLookup> getCurrencyCode() {
		synchronized (currencyCodeMap) {
			return cloneAndConvertMasterData(currencyCodeMap);
		}
	}

	public CommonCodeMaster findCurrencyCode(String value) {
		synchronized (currencyCodeMap) {
			return value == null ? null : cloneAndConvertMasterData(currencyCodeMap.get(value));
		}
	}

	public void reloadDebugFlag() {
		synchronized (debugFlagMap) {
			reloadMasterData(CODENAME_DEBUG_FLAG, CATEGORY_LOGGING, debugFlagMap);
		}
	}

	public List<MasterLookup> getDebugFlag() {
		synchronized (debugFlagMap) {
			return cloneAndConvertMasterData(debugFlagMap);
		}
	}

	public CommonCodeMaster findDebugFlag(String value) {
		synchronized (debugFlagMap) {
			return value == null ? null : cloneAndConvertMasterData(debugFlagMap.get(value));
		}
	}

	public void reloadDeclineReason() {
		synchronized (declineReasonMap) {
			reloadMasterData(CODENAME_DECLINE_REASON, CATEGORY_CLAIM_PAYMENT, declineReasonMap);
		}
	}

	public List<MasterLookup> getDeclineReason() {
		synchronized (declineReasonMap) {
			return cloneAndConvertMasterData(declineReasonMap);
		}
	}

	public CommonCodeMaster findDeclineReason(String value) {
		synchronized (declineReasonMap) {
			return value == null ? null : cloneAndConvertMasterData(declineReasonMap.get(value));
		}
	}

	public void reloadDependentType() {
		synchronized (dependentTypeMap) {
			reloadMasterData(CODENAME_DEPENDENT_TYPE, CATEGORY_CLAIM, dependentTypeMap);
		}
	}

	public List<MasterLookup> getDependentType() {
		synchronized (dependentTypeMap) {
			return cloneAndConvertMasterData(dependentTypeMap);
		}
	}

	public CommonCodeMaster findDependentType(String value) {
		synchronized (dependentTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(dependentTypeMap.get(value));
		}
	}

	public void reloadDiagnosticTest() {
		synchronized (diagnosticTestMap) {
			reloadMasterData(CODENAME_DIAGNOSTIC_TEST, CATEGORY_CLAIM, diagnosticTestMap);
		}
	}

	public List<MasterLookup> getDiagnosticTest() {
		synchronized (diagnosticTestMap) {
			return cloneAndConvertMasterData(diagnosticTestMap);
		}
	}

	public CommonCodeMaster findDiagnosticTest(String value) {
		synchronized (diagnosticTestMap) {
			return value == null ? null : cloneAndConvertMasterData(diagnosticTestMap.get(value));
		}
	}

	public void reloadDiseaseInd() {
		synchronized (diseaseIndMap) {
			reloadMasterData(CODENAME_DISEASE_IND, CATEGORY_CLAIM, diseaseIndMap);
		}
	}

	public List<MasterLookup> getDiseaseInd() {
		synchronized (diseaseIndMap) {
			return cloneAndConvertMasterData(diseaseIndMap);
		}
	}

	public CommonCodeMaster findDiseaseInd(String value) {
		synchronized (diseaseIndMap) {
			return value == null ? null : cloneAndConvertMasterData(diseaseIndMap.get(value));
		}
	}

	public void reloadDocumentType() {
		synchronized (documentTypeMap) {
			reloadMasterData(CODENAME_DOCUMENT_TYPE, CATEGORY_CLAIM_REQUIREMENT_INFO, documentTypeMap);
		}
	}

	public List<MasterLookup> getDocumentType() {
		synchronized (documentTypeMap) {
			return cloneAndConvertMasterData(documentTypeMap);
		}
	}

	public List<MasterLookup> getDocumentTypeByDescLong() {
		synchronized (documentTypeMap) {
			return cloneAndConvertMasterDataDescLong(documentTypeMap);
		}
	}

	public CommonCodeMaster findDocumentType(String value) {
		synchronized (documentTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(documentTypeMap.get(value));
		}
	}

	public void reloadDrugAndMedication() {
		synchronized (drugAndMedicationMap) {
			reloadMasterData(CODENAME_DRUG_AND_MEDICATION, CATEGORY_CLAIM, drugAndMedicationMap);
		}
	}

	public List<MasterLookup> getDrugAndMedication() {
		synchronized (drugAndMedicationMap) {
			return cloneAndConvertMasterData(drugAndMedicationMap);
		}
	}

	public CommonCodeMaster findDrugAndMedication(String value) {
		synchronized (drugAndMedicationMap) {
			return value == null ? null : cloneAndConvertMasterData(drugAndMedicationMap.get(value));
		}
	}

	public void reloadEligibility() {
		synchronized (eligibilityMap) {
			reloadMasterData(CODENAME_ELIGIBILITY, CATEGORY_CLAIM_PAYMENT, eligibilityMap);
		}
	}

	public List<MasterLookup> getEligibility() {
		synchronized (eligibilityMap) {
			return cloneAndConvertMasterData(eligibilityMap);
		}
	}

	public CommonCodeMaster findEligibility(String value) {
		synchronized (eligibilityMap) {
			return value == null ? null : cloneAndConvertMasterData(eligibilityMap.get(value));
		}
	}

	public void reloadFaxClaimScore() {
		synchronized (faxClaimScoreMap) {
			reloadMasterData(CODENAME_FAX_CLAIM_SCORE, CATEGORY_PROVIDER, faxClaimScoreMap);
		}
	}

	public List<MasterLookup> getFaxClaimScore() {
		synchronized (faxClaimScoreMap) {
			return cloneAndConvertMasterData(faxClaimScoreMap);
		}
	}

	public CommonCodeMaster findFaxClaimScore(String value) {
		synchronized (faxClaimScoreMap) {
			return value == null ? null : cloneAndConvertMasterData(faxClaimScoreMap.get(value));
		}
	}

	public void reloadGender() {
		synchronized (genderMap) {
			reloadMasterData(CODENAME_GENDER, CATEGORY_COMMON, genderMap);
		}
	}

	public List<MasterLookup> getGender() {
		synchronized (genderMap) {
			return cloneAndConvertMasterData(genderMap);
		}
	}

	public CommonCodeMaster findGender(String value) {
		synchronized (genderMap) {
			return value == null ? null : cloneAndConvertMasterData(genderMap.get(value));
		}
	}

	public void reloadIcuReason() {
		synchronized (icuReasonMap) {
			reloadMasterData(CODENAME_ICU_REASON, CATEGORY_CLAIM, icuReasonMap);
		}
	}

	public List<MasterLookup> getIcuReason() {
		synchronized (icuReasonMap) {
			return cloneAndConvertMasterData(icuReasonMap);
		}
	}

	public CommonCodeMaster findIcuReason(String value) {
		synchronized (icuReasonMap) {
			return value == null ? null : cloneAndConvertMasterData(icuReasonMap.get(value));
		}
	}

	public void reloadInsertRider() {
		synchronized (insertRiderMap) {
			reloadMasterData(CODENAME_INSERT_RIDER, CATEGORY_INSERT_RIDER, insertRiderMap);
		}
	}

	public List<MasterLookup> getInsertRider() {
		synchronized (insertRiderMap) {
			return cloneAndConvertMasterData(insertRiderMap);
		}
	}

	public CommonCodeMaster findInsertRider(String value) {
		synchronized (insertRiderMap) {
			return value == null ? null : cloneAndConvertMasterData(insertRiderMap.get(value));
		}
	}

	public void reloadLevelOfConsciousness() {
		synchronized (levelOfConsciousnessMap) {
			reloadMasterData(CODENAME_LEVEL_OF_CONSCIOUSNESS, CATEGORY_CLAIM, levelOfConsciousnessMap);
		}
	}

	public List<MasterLookup> getLevelOfConsciousness() {
		synchronized (levelOfConsciousnessMap) {
			return cloneAndConvertMasterData(levelOfConsciousnessMap);
		}
	}

	public CommonCodeMaster findLevelOfConsciousness(String value) {
		synchronized (levelOfConsciousnessMap) {
			return value == null ? null : cloneAndConvertMasterData(levelOfConsciousnessMap.get(value));
		}
	}

	public void reloadHbpType() {
		synchronized (hbpTypeMap) {
			reloadMasterData(CODENAME_HBP_TYPE, CATEGORY_CLAIM, hbpTypeMap);
		}
	}

	public List<MasterLookup> getHbpType() {
		synchronized (hbpTypeMap) {
			return cloneAndConvertMasterData(hbpTypeMap);
		}
	}

	public CommonCodeMaster findHbpType(String value) {
		synchronized (hbpTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(hbpTypeMap.get(value));
		}
	}

	public void reloadHoldService() {
		synchronized (holdServiceMap) {
			reloadMasterData(CODENAME_HOLD_SERVICE, CATEGORY_PROVIDER, holdServiceMap);
		}
	}

	public List<MasterLookup> getHoldService() {
		synchronized (holdServiceMap) {
			return cloneAndConvertMasterData(holdServiceMap);
		}
	}

	public CommonCodeMaster findHoldService(String value) {
		synchronized (holdServiceMap) {
			return value == null ? null : cloneAndConvertMasterData(holdServiceMap.get(value));
		}
	}

	public void reloadHospitalizationReason() {
		synchronized (hospitalizationReasonMap) {
			reloadMasterData(CODENAME_HOSPITALIZATION_REASON, CATEGORY_CLAIM, hospitalizationReasonMap);
		}
	}

	public List<MasterLookup> getHospitalizationReason() {
		synchronized (hospitalizationReasonMap) {
			return cloneAndConvertMasterData(hospitalizationReasonMap);
		}
	}

	public CommonCodeMaster findHospitalizationReason(String value) {
		synchronized (hospitalizationReasonMap) {
			return value == null ? null : cloneAndConvertMasterData(hospitalizationReasonMap.get(value));
		}
	}

	public void reloadMajorAccId() {
		synchronized (majorAccIdMap) {
			reloadMasterData(CODENAME_MAJOR_ACC_ID, CATEGORY_CLAIM, majorAccIdMap);
		}
	}

	public List<MasterLookup> getMajorAccId() {
		synchronized (majorAccIdMap) {
			return cloneAndConvertMasterData(majorAccIdMap);
		}
	}

	public CommonCodeMaster findMajorAccId(String value) {
		synchronized (majorAccIdMap) {
			return value == null ? null : cloneAndConvertMasterData(majorAccIdMap.get(value));
		}
	}

	public void reloadMajorInjuryDetail() {
		synchronized (majorInjuryDetailMap) {
			reloadMasterData(CODENAME_MAJOR_INJURY_DETAIL, CATEGORY_CLAIM, majorInjuryDetailMap);
		}
	}

	public List<MasterLookup> getMajorInjuryDetail() {
		synchronized (majorInjuryDetailMap) {
			return cloneAndConvertMasterData(majorInjuryDetailMap);
		}
	}

	public CommonCodeMaster findMajorInjuryDetail(String value) {
		synchronized (majorInjuryDetailMap) {
			return value == null ? null : cloneAndConvertMasterData(majorInjuryDetailMap.get(value));
		}
	}

	public void reloadMedicalSpecialty() {
		synchronized (medicalSpecialtyMap) {
			reloadMasterData(CODENAME_MEDICAL_SPECIALTY, CATEGORY_PROVIDER, medicalSpecialtyMap);
		}
	}

	public List<MasterLookup> getMedicalSpecialty() {
		synchronized (medicalSpecialtyMap) {
			return cloneAndConvertMasterData(medicalSpecialtyMap);
		}
	}

	public List<MasterLookup> getMedicalSpecialtyOrderByDesc() {
		synchronized (medicalSpecialtyMap) {
			return cloneAndConvertMasterDataWithSorted(medicalSpecialtyMap);
		}
	}

	public CommonCodeMaster findMedicalSpecialty(String value) {
		synchronized (medicalSpecialtyMap) {
			return value == null ? null : cloneAndConvertMasterData(medicalSpecialtyMap.get(value));
		}
	}

	public void reloadNetworkType() {
		synchronized (networkTypeMap) {
			reloadMasterData(CODENAME_NETWORK_TYPE, CATEGORY_NETWORK, networkTypeMap);
		}
	}

	public List<MasterLookup> getNetworkType() {
		synchronized (networkTypeMap) {
			return cloneAndConvertMasterData(networkTypeMap);
		}
	}

	public CommonCodeMaster findNetworkType(String value) {
		synchronized (networkTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(networkTypeMap.get(value));
		}
	}

	public void reloadNetworkSpecificProduct() {
		synchronized (networkSpecificProductMap) {
			reloadMasterData(CODENAME_NETWORK_SPECIFIC_PRODUCT, CATEGORY_NETWORK, networkSpecificProductMap);
		}
	}

	public List<MasterLookup> getNetworkSpecificProduct() {
		synchronized (networkSpecificProductMap) {
			return cloneAndConvertMasterData(networkSpecificProductMap);
		}
	}

	public CommonCodeMaster findNetworkSpecificProduct(String value) {
		synchronized (networkSpecificProductMap) {
			return value == null ? null : cloneAndConvertMasterData(networkSpecificProductMap.get(value));
		}
	}

	public void reloadPayeeType() {
		synchronized (payeeTypeMap) {
			reloadMasterData(CODENAME_PAYEE_TYPE, CATEGORY_CLAIM_PAYMENT, payeeTypeMap);
		}
	}

	public List<MasterLookup> getPayeeType() {
		synchronized (payeeTypeMap) {
			return cloneAndConvertMasterData(payeeTypeMap);
		}
	}

	public CommonCodeMaster findPayeeType(String value) {
		synchronized (payeeTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(payeeTypeMap.get(value));
		}
	}

	public void reloadPaymentCycle() {
		synchronized (paymentCycleMap) {
			reloadMasterData(CODENAME_PAYMENT_CYCLE, CATEGORY_PROVIDER, paymentCycleMap);
		}
	}

	public List<MasterLookup> getPaymentCycle() {
		synchronized (paymentCycleMap) {
			return cloneAndConvertMasterData(paymentCycleMap);
		}
	}

	public CommonCodeMaster findPaymentCycle(String value) {
		synchronized (paymentCycleMap) {
			return value == null ? null : cloneAndConvertMasterData(paymentCycleMap.get(value));
		}
	}

	public void reloadClaimPaymentMethod() {
		synchronized (claimPaymentMethodMap) {
			reloadMasterData(CODENAME_PAYMENT_METHOD, CATEGORY_CLAIM, claimPaymentMethodMap);
		}
	}

	public List<MasterLookup> getClaimPaymentMethod() {
		synchronized (claimPaymentMethodMap) {
			return cloneAndConvertMasterData(claimPaymentMethodMap);
		}
	}

	public CommonCodeMaster findClaimPaymentMethod(String value) {
		synchronized (claimPaymentMethodMap) {
			return value == null ? null : cloneAndConvertMasterData(claimPaymentMethodMap.get(value));
		}
	}

	public void reloadProviderPaymentMethod() {
		synchronized (providerPaymentMethodMap) {
			reloadMasterData(CODENAME_PAYMENT_METHOD, CATEGORY_PROVIDER, providerPaymentMethodMap);
		}
	}

	public List<MasterLookup> getProviderPaymentMethod() {
		synchronized (providerPaymentMethodMap) {
			return cloneAndConvertMasterData(providerPaymentMethodMap);
		}
	}

	public CommonCodeMaster findProviderPaymentMethod(String value) {
		synchronized (providerPaymentMethodMap) {
			return value == null ? null : cloneAndConvertMasterData(providerPaymentMethodMap.get(value));
		}
	}

	public void reloadPaymentSeq() {
		synchronized (paymentSeqMap) {
			reloadMasterData(CODENAME_PAYMENT_SEQ, CATEGORY_PAYMENT_SEQ, paymentSeqMap);
		}
	}

	public List<MasterLookup> getPaymentSeq() {
		synchronized (paymentSeqMap) {
			return cloneAndConvertMasterData(paymentSeqMap);
		}
	}

	public CommonCodeMaster findPaymentSeq(String value) {
		synchronized (paymentSeqMap) {
			return value == null ? null : cloneAndConvertMasterData(paymentSeqMap.get(value));
		}
	}

	public void reloadPhase() {
		synchronized (phaseMap) {
			reloadMasterData(CODENAME_PHASE, CATEGORY_CLAIM, phaseMap);
		}
	}

	public List<MasterLookup> getPhase() {
		synchronized (phaseMap) {
			return cloneAndConvertMasterData(phaseMap);
		}
	}

	public CommonCodeMaster findPhase(String value) {
		synchronized (phaseMap) {
			return value == null ? null : cloneAndConvertMasterData(phaseMap.get(value));
		}
	}

	public void reloadPhysicianStatus() {
		synchronized (physicianStatusMap) {
			reloadMasterData(CODENAME_PHYSICIAN_STATUS, CATEGORY_PHYSICIAN, physicianStatusMap);
		}
	}

	public List<MasterLookup> getPhysicianStatus() {
		synchronized (physicianStatusMap) {
			return cloneAndConvertMasterData(physicianStatusMap);
		}
	}

	public CommonCodeMaster findPhysicianStatus(String value) {
		synchronized (physicianStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(physicianStatusMap.get(value));
		}
	}

	public void reloadPhysicianType() {
		synchronized (physicianTypeMap) {
			reloadMasterData(CODENAME_PHYSICIAN_TYPE, CATEGORY_PHYSICIAN, physicianTypeMap);
		}
	}

	public List<MasterLookup> getPhysicianType() {
		synchronized (physicianTypeMap) {
			return cloneAndConvertMasterData(physicianTypeMap);
		}
	}

	public CommonCodeMaster findPhysicianType(String value) {
		synchronized (physicianTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(physicianTypeMap.get(value));
		}
	}

	public void reloadPhysicianWarningCode() {
		synchronized (physicianWarningCodeMap) {
			reloadMasterData(CODENAME_PHYSICIAN_WARNING_CODE, CATEGORY_PROVIDER, physicianWarningCodeMap);
		}
	}

	public List<MasterLookup> getPhysicianWarningCode() {
		synchronized (physicianWarningCodeMap) {
			return cloneAndConvertMasterData(physicianWarningCodeMap);
		}
	}

	public CommonCodeMaster findPhysicianWarningCode(String value) {
		synchronized (physicianWarningCodeMap) {
			return value == null ? null : cloneAndConvertMasterData(physicianWarningCodeMap.get(value));
		}
	}

	public void reloadPlace() {
		synchronized (placeMap) {
			reloadMasterData(CODENAME_PLACE, CATEGORY_CLAIM, placeMap);
		}
	}

	public List<MasterLookup> getPlace() {
		synchronized (placeMap) {
			return cloneAndConvertMasterData(placeMap);
		}
	}

	public CommonCodeMaster findPlace(String value) {
		synchronized (placeMap) {
			return value == null ? null : cloneAndConvertMasterData(placeMap.get(value));
		}
	}

	public void reloadPrivateInsurance() {
		synchronized (privateInsuranceMap) {
			reloadMasterData(CODENAME_PRIVATE_INSURANCE, CATEGORY_PROVIDER, privateInsuranceMap);
		}
	}

	public List<MasterLookup> getPrivateInsurance() {
		synchronized (privateInsuranceMap) {
			return cloneAndConvertMasterData(privateInsuranceMap);
		}
	}

	public CommonCodeMaster findPrivateInsurance(String value) {
		synchronized (privateInsuranceMap) {
			return value == null ? null : cloneAndConvertMasterData(privateInsuranceMap.get(value));
		}
	}

	public void reloadProcessStatus() {
		synchronized (processStatusMap) {
			reloadMasterData(CODENAME_PROCESS_STATUS, CATEGORY_CLAIM, processStatusMap);
		}
	}

	public List<MasterLookup> getProcessStatus() {
		synchronized (processStatusMap) {
			return cloneAndConvertMasterData(processStatusMap);
		}
	}

	public CommonCodeMaster findProcessStatus(String value) {
		synchronized (processStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(processStatusMap.get(value));
		}
	}

	public void reloadProviderAffordabilityTier() {
		synchronized (providerAffordabilityTierMap) {
			reloadMasterData(CODENAME_PROVIDER_AFFORDABILITY_TIER, CATEGORY_PROVIDER, providerAffordabilityTierMap);
		}
	}

	public List<MasterLookup> getProviderAffordabilityTier() {
		synchronized (providerAffordabilityTierMap) {
			return cloneAndConvertMasterData(providerAffordabilityTierMap);
		}
	}

	public CommonCodeMaster findProviderAffordabilityTier(String value) {
		synchronized (providerAffordabilityTierMap) {
			return value == null ? null : cloneAndConvertMasterData(providerAffordabilityTierMap.get(value));
		}
	}

	public void reloadProviderContractType() {
		synchronized (providerContractTypeMap) {
			reloadMasterData(CODENAME_PROVIDER_CONTRACT_TYPE, CATEGORY_PROVIDER_CONTRACT_DETAIL, providerContractTypeMap);
		}
	}

	public List<MasterLookup> getProviderContractType() {
		synchronized (providerContractTypeMap) {
			return cloneAndConvertMasterData(providerContractTypeMap);
		}
	}

	public CommonCodeMaster findProviderContractType(String value) {
		synchronized (providerContractTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(providerContractTypeMap.get(value));
		}
	}

	public void reloadProviderGroup() {
		synchronized (providerGroupMap) {
			reloadMasterData(CODENAME_PROVIDER_GROUP, CATEGORY_COMMON, providerGroupMap);
		}
	}

	public List<MasterLookup> getProviderGroup() {
		synchronized (providerGroupMap) {
			return cloneAndConvertMasterData(providerGroupMap);
		}
	}

	public CommonCodeMaster findProviderGroup(String value) {
		synchronized (providerGroupMap) {
			return value == null ? null : cloneAndConvertMasterData(providerGroupMap.get(value));
		}
	}

	public void reloadProviderStatus() {
		synchronized (providerStatusMap) {
			reloadMasterData(CODENAME_PROVIDER_STATUS, CATEGORY_PROVIDER, providerStatusMap);
		}
	}

	public List<MasterLookup> getProviderStatus() {
		synchronized (providerStatusMap) {
			return cloneAndConvertMasterData(providerStatusMap);
		}
	}

	public CommonCodeMaster findProviderStatus(String value) {
		synchronized (providerStatusMap) {
			return value == null ? null : cloneAndConvertMasterData(providerStatusMap.get(value));
		}
	}

	public void reloadProviderType() {
		synchronized (providerTypeMap) {
			reloadMasterData(CODENAME_PROVIDER_TYPE, CATEGORY_PROVIDER, providerTypeMap);
		}
	}

	public List<MasterLookup> getProviderType() {
		synchronized (providerTypeMap) {
			return cloneAndConvertMasterData(providerTypeMap);
		}
	}

	public CommonCodeMaster findProviderType(String value) {
		synchronized (providerTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(providerTypeMap.get(value));
		}
	}

	public void reloadProviderTypeSector() {
		synchronized (providerTypeSectorMap) {
			reloadMasterData(CODENAME_PROVIDER_TYPE_SECTOR, CATEGORY_PROVIDER, providerTypeSectorMap);
		}
	}

	public List<MasterLookup> getProviderTypeSector() {
		synchronized (providerTypeSectorMap) {
			return cloneAndConvertMasterData(providerTypeSectorMap);
		}
	}

	public CommonCodeMaster findProviderTypeSector(String value) {
		synchronized (providerTypeSectorMap) {
			return value == null ? null : cloneAndConvertMasterData(providerTypeSectorMap.get(value));
		}
	}

	public void reloadProviderWarningCode() {
		synchronized (providerWarningCodeMap) {
			reloadMasterData(CODENAME_PROVIDER_WARNING_CODE, CATEGORY_PROVIDER, providerWarningCodeMap);
		}
	}

	public List<MasterLookup> getProviderWarningCode() {
		synchronized (providerWarningCodeMap) {
			return cloneAndConvertMasterData(providerWarningCodeMap);
		}
	}

	public CommonCodeMaster findProviderWarningCode(String value) {
		synchronized (providerWarningCodeMap) {
			return value == null ? null : cloneAndConvertMasterData(providerWarningCodeMap.get(value));
		}
	}

	public void reloadProvince() {
		synchronized (provinceParentMap) {
			reloadProvinceData(CODENAME_PROVINCE, CATEGORY_ADDRESS, provinceMap, provinceParentMap);
		}
	}

	public List<MasterLookup> getProvince() {
		synchronized (provinceParentMap) {
			return cloneAndConvertMasterData(provinceMap);
		}
	}

	public List<MasterLookup> getProvince(Integer referCommonCodeId) {
		synchronized (provinceParentMap) {
			if (referCommonCodeId != null) {
				return cloneAndConvertProvinceData(provinceParentMap.get(referCommonCodeId));
			} else {
				return new ArrayList<>();
			}
		}
	}

	public CommonCodeMaster findProvince(String value) {
		synchronized (provinceParentMap) {
			return value == null ? null : cloneAndConvertMasterData(provinceMap.get(value));
		}
	}

	public void reloadPublicInsurance() {
		synchronized (publicInsuranceMap) {
			reloadMasterData(CODENAME_PUBLIC_INSURANCE, CATEGORY_PROVIDER, publicInsuranceMap);
		}
	}

	public List<MasterLookup> getPublicInsurance() {
		synchronized (publicInsuranceMap) {
			return cloneAndConvertMasterData(publicInsuranceMap);
		}
	}

	public CommonCodeMaster findPublicInsurance(String value) {
		synchronized (publicInsuranceMap) {
			return value == null ? null : cloneAndConvertMasterData(publicInsuranceMap.get(value));
		}
	}

	public void reloadRegion() {
		synchronized (regionMap) {
			reloadMasterData(CODENAME_REGION, CATEGORY_ADDRESS, regionMap);
		}
	}

	public List<MasterLookup> getRegion() {
		synchronized (regionMap) {
			return cloneAndConvertRegionData(regionMap);
		}
	}

	public CommonCodeMaster findRegion(String value) {
		synchronized (regionMap) {
			return value == null ? null : cloneAndConvertMasterData(regionMap.get(value));
		}
	}

	public void reloadRelationship() {
		synchronized (relationshipMap) {
			reloadMasterData(CODENAME_RELATIONSHIP, CATEGORY_CLAIM, relationshipMap);
		}
	}

	public List<MasterLookup> getRelationship() {
		synchronized (relationshipMap) {
			return cloneAndConvertMasterData(relationshipMap);
		}
	}

	public CommonCodeMaster findRelationship(String value) {
		synchronized (relationshipMap) {
			return value == null ? null : cloneAndConvertMasterData(relationshipMap.get(value));
		}
	}

	public void reloadRoomType() {
		synchronized (roomTypeMap) {
			reloadMasterData(CODENAME_ROOM_TYPE, CATEGORY_CLAIM, roomTypeMap);
		}
	}

	public List<MasterLookup> getRoomType() {
		synchronized (roomTypeMap) {
			return cloneAndConvertMasterData(roomTypeMap);
		}
	}

	public CommonCodeMaster findRoomType(String value) {
		synchronized (roomTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(roomTypeMap.get(value));
		}
	}

	public void reloadServicePriority() {
		synchronized (servicePriorityMap) {
			reloadMasterData(CODENAME_SERVICE_PRIORITY, CATEGORY_PROVIDER, servicePriorityMap);
		}
	}

	public List<MasterLookup> getServicePriority() {
		synchronized (servicePriorityMap) {
			return cloneAndConvertMasterData(servicePriorityMap);
		}
	}

	public CommonCodeMaster findServicePriority(String value) {
		synchronized (servicePriorityMap) {
			return value == null ? null : cloneAndConvertMasterData(servicePriorityMap.get(value));
		}
	}

	public void reloadServiceProvided() {
		synchronized (serviceProvidedMap) {
			reloadMasterData(CODENAME_SERVICE_PROVIDED, CATEGORY_PROVIDER, serviceProvidedMap);
		}
	}

	public List<MasterLookup> getServiceProvided() {
		synchronized (serviceProvidedMap) {
			return cloneAndConvertMasterData(serviceProvidedMap);
		}
	}

	public List<MasterLookup> getServiceProvidedOrderByDesc() {
		synchronized (serviceProvidedMap) {
			return cloneAndConvertMasterDataWithSorted(serviceProvidedMap);
		}
	}

	public CommonCodeMaster findServiceProvided(String value) {
		synchronized (serviceProvidedMap) {
			return value == null ? null : cloneAndConvertMasterData(serviceProvidedMap.get(value));
		}
	}

	public void reloadSpecialy() {
		synchronized (specialyMap) {
			reloadMasterData(CODENAME_SPECIALY, CATEGORY_PHYSICIAN, specialyMap);
		}
	}

	public List<MasterLookup> getSpecialy() {
		synchronized (specialyMap) {
			return cloneAndConvertMasterData(specialyMap);
		}
	}

	public List<MasterLookup> getSpecialyOrderByDesc() {
		synchronized (specialyMap) {
			return cloneAndConvertMasterDataWithSorted(specialyMap);
		}
	}

	public CommonCodeMaster findSpecialy(String value) {
		synchronized (specialyMap) {
			return value == null ? null : cloneAndConvertMasterData(specialyMap.get(value));
		}
	}

	public void reloadSubmissionType() {
		synchronized (submissionTypeMap) {
			reloadMasterData(CODENAME_SUBMISSION_TYPE, CATEGORY_CLAIM, submissionTypeMap);
		}
	}

	public List<MasterLookup> getSubmissionType() {
		synchronized (submissionTypeMap) {
			return cloneAndConvertMasterData(submissionTypeMap);
		}
	}

	public CommonCodeMaster findSubmissionType(String value) {
		synchronized (submissionTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(submissionTypeMap.get(value));
		}
	}

	public void reloadTreatmentType() {
		synchronized (treatmentTypeMap) {
			reloadMasterData(CODENAME_TREATMENT_TYPE, CATEGORY_TREATMENT_TYPE, treatmentTypeMap);
		}
	}

	public List<MasterLookup> getTreatmentType() {
		synchronized (treatmentTypeMap) {
			return cloneAndConvertMasterData(treatmentTypeMap);
		}
	}

	public CommonCodeMaster findTreatmentType(String value) {
		synchronized (treatmentTypeMap) {
			return value == null ? null : cloneAndConvertMasterData(treatmentTypeMap.get(value));
		}
	}

	public void reloadPaymentCodition() {
		synchronized (paymentCoditionMap) {
			reloadMasterData(CODENAME_PAYMENT_CODITION, CATEGORY_AGENCY, paymentCoditionMap);
		}
	}

	public List<MasterLookup> getPaymentCodition() {
		synchronized (paymentCoditionMap) {
			return cloneAndConvertMasterData(paymentCoditionMap);
		}
	}

	public CommonCodeMaster findPaymentCodition(String value) {
		synchronized (paymentCoditionMap) {
			return value == null ? null : cloneAndConvertMasterData(paymentCoditionMap.get(value));
		}
	}

	public void reloadDistributeCodition() {
		synchronized (distributeCoditionMap) {
			reloadMasterData(CODENAME_DISTRIBUTE_CODITION, CATEGORY_AGENCY, distributeCoditionMap);
		}
	}

	public List<MasterLookup> getDistributeCodition() {
		synchronized (distributeCoditionMap) {
			return cloneAndConvertMasterData(distributeCoditionMap);
		}
	}

	public CommonCodeMaster findDistributeCodition(String value) {
		synchronized (distributeCoditionMap) {
			return value == null ? null : cloneAndConvertMasterData(distributeCoditionMap.get(value));
		}
	}

	public void reloadSystemEligibilityMap() {
		synchronized (systemEligibilityMap) {
			reloadMasterData(CODENAME_SYSTEM_ELIGIBILITY, CATEGORY_CLAIM_PAYMENT, systemEligibilityMap);
		}
	}

	public List<MasterLookup> getSystemEligibility() {
		synchronized (systemEligibilityMap) {
			return cloneAndConvertMasterData(systemEligibilityMap);
		}
	}

	public CommonCodeMaster findSystemEligibility(String value) {
		synchronized (systemEligibilityMap) {
			return value == null ? null : cloneAndConvertMasterData(systemEligibilityMap.get(value));
		}
	}

	public void reloadPlanStatusMap() {
		synchronized (planStatusMap) {
			reloadMasterData(CODENAME_PLAN_STATUS, CATEGORY_PLAN, planStatusMap);
		}
	}

	public List<MasterLookup> getPlanStatusMap() {
		synchronized (planStatusMap) {
			return cloneAndConvertMasterData(planStatusMap);
		}
	}

	public void reloadValidationActionTakenMapp() {
		synchronized (validationActionTakenMap) {
			reloadMasterData(CODENAME_ACTION_TOKEN, CATEGORY_VALIDATION, validationActionTakenMap);
		}
	}

	public void reloadValidationReviewMap() {
		synchronized (validationReviewMap) {
			reloadMasterData(CODENAME_REVIEW, CATEGORY_VALIDATION, validationReviewMap);
		}
	}

	public List<MasterLookup> getValidationActionTakenMap() {
		synchronized (validationActionTakenMap) {
			return cloneAndConvertMasterData(validationActionTakenMap);
		}
	}

	public List<MasterLookup> getValidationReviewMap() {
		synchronized (validationReviewMap) {
			return cloneAndConvertMasterData(validationReviewMap);
		}
	}

	public CommonCodeMaster findValidationActionTaken(String value) {
		synchronized (validationActionTakenMap) {
			return value == null ? null : cloneAndConvertMasterData(validationActionTakenMap.get(value));
		}
	}

	public CommonCodeMaster findValidationReview(String value) {
		synchronized (validationReviewMap) {
			return value == null ? null : cloneAndConvertMasterData(validationReviewMap.get(value));
		}
	}

	public void reloadCorrespondenceReportMap() {
		synchronized (correspondenceReportMap) {
			reloadMasterData(CODENAME_REPORT, CATEGORY_CORRESPONDENCE, correspondenceReportMap);
		}
	}

	public List<MasterLookup> getCorrespondenceReportMap() {
		synchronized (correspondenceReportMap) {
			return cloneAndConvertMasterData(correspondenceReportMap);
		}
	}

	public CommonCodeMaster findCorrespondenceReport(String value) {
		synchronized (correspondenceReportMap) {
			return value == null ? null : cloneAndConvertMasterData(correspondenceReportMap.get(value));
		}
	}

	public Map<String, Integer> getMapSubPlanCode() {
		return mapSubPlanCode;
	}

	public void reloadCriticalIllness() {
		synchronized (criticalIllnessMap) {
			reloadMasterData(CODENAME_CRIT_ILL, CATEGORY_CLAIM, criticalIllnessMap);
		}
	}

	public List<MasterLookup> getCriticalIllness() {
		synchronized (criticalIllnessMap) {
			return cloneAndConvertMasterData(criticalIllnessMap);
		}
	}

	public CommonCodeMaster findCriticalIllness(String value) {
		synchronized (criticalIllnessMap) {
			return value == null ? null : cloneAndConvertMasterData(criticalIllnessMap.get(value));
		}
	}

	public Map<String, String> getProviderNameThaiMap() {
		return providerNameThaiMap;
	}

}

class MasterLookupValueComparator implements Comparator<MasterLookup> {
	@Override
	public int compare(MasterLookup o1, MasterLookup o2) {
		String value1 = o1.getValue() == null ? "" : o1.getValue();
		String value2 = o2.getValue() == null ? "" : o2.getValue();
		return value1.compareTo(value2);
	}
}

class CommonCodeComparator implements Comparator<CommonCode> {
	@Override
	public int compare(CommonCode o1, CommonCode o2) {
		return o1.getCommonCodeId().compareTo(o2.getCommonCodeId());
	}
}
