package com.aia.cmic.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiDoctor {
	private Long ediDoctorsId;
	private String claimNo;
	private Integer occurrence;
	@JsonProperty("doctorLicense")
	private String doctorLicense;
	@JsonProperty("doctorRole")
	private String doctorRole;
	private Integer groupId;

	public Long getEdiDoctorsId() {
		return ediDoctorsId;
	}

	public void setEdiDoctorsId(Long ediDoctorsId) {
		this.ediDoctorsId = ediDoctorsId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getDoctorLicense() {
		return doctorLicense;
	}

	public void setDoctorLicense(String doctorLicense) {
		this.doctorLicense = doctorLicense;
	}

	public String getDoctorRole() {
		return doctorRole;
	}

	public void setDoctorRole(String doctorRole) {
		this.doctorRole = doctorRole;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
}
