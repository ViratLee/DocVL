package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class ImageDocument {
	private List<String> docId;
	private List<String> docType;
	private List<String> page;
	private List<String> totalPages;
	private List<String> action;
	private String confirm;

	public final List<String> getDocId() {
		return docId;
	}

	public final void setDocId(List<String> docId) {
		this.docId = docId;
	}

	public final List<String> getDocType() {
		return docType;
	}

	public final void setDocType(List<String> docType) {
		this.docType = docType;
	}

	public final List<String> getPage() {
		return page;
	}

	public final void setPage(List<String> page) {
		this.page = page;
	}

	public List<String> getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(List<String> totalPages) {
		this.totalPages = totalPages;
	}

	public List<String> getAction() {
		return action;
	}

	public void setAction(List<String> action) {
		this.action = action;
	}

	public String getConfirm() {
		return confirm;
	}

	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
