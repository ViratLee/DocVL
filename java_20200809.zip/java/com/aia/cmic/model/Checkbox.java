package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class Checkbox {
	private String key;
	private String code;
	private String value;
	private boolean selected;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public final String getCode() {
		return code;
	}

	public final void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public final boolean isSelected() {
		return selected;
	}

	public final void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
