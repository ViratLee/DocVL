package com.aia.cmic.model;

import java.math.BigDecimal;

public class ServiceItemLookup extends Lookup {
	String serviceItemDesc;
	BigDecimal discountOnListPrice;

	public String getServiceItemDesc() {
		return serviceItemDesc;
	}

	public void setServiceItemDesc(String serviceItemDesc) {
		this.serviceItemDesc = serviceItemDesc;
	}

	public BigDecimal getDiscountOnListPrice() {
		return discountOnListPrice;
	}

	public void setDiscountOnListPrice(BigDecimal discountOnListPrice) {
		this.discountOnListPrice = discountOnListPrice;
	}
}
