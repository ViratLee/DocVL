package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentRecordSearchForm {
	
	private String providerCode;
	private String batchId;
	private String businessLine;
	private boolean isEdi;
	private boolean isStp;
	private boolean isLifePa;
	private boolean isCs;
	private String settleStartDate;
	private String settleEndDate;
	private Date settleFromDate;
	private Date settleToDate;
	private List<String> treatmentType;
	
	public String getProviderCode() {
		return providerCode;
	}
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public boolean getIsEdi() {
		return isEdi;
	}

	public boolean getIsStp() {
		return isStp;
	}

	public void setIsEdi(boolean isEdi) {
		this.isEdi = isEdi;
	}

	public void setIsStp(boolean isStp) {
		this.isStp = isStp;
	}
	public boolean getIsLifePa() {
		return isLifePa;
	}
	public void setIsLifePa(boolean isLifePa) {
		this.isLifePa = isLifePa;
	}
	public boolean getIsCs() {
		return isCs;
	}
	public void setIsCs(boolean isCs) {
		this.isCs = isCs;
	}
	public String getSettleStartDate() {
		return settleStartDate;
	}
	public void setSettleStartDate(String settleStartDate) {
		this.settleStartDate = settleStartDate;
	}
	public String getSettleEndDate() {
		return settleEndDate;
	}
	public void setSettleEndDate(String settleEndDate) {
		this.settleEndDate = settleEndDate;
	}
	public Date getSettleFromDate() {
		return settleFromDate;
	}
	public void setSettleFromDate(Date settleFromDate) {
		this.settleFromDate = settleFromDate;
	}
	public Date getSettleToDate() {
		return settleToDate;
	}
	public void setSettleToDate(Date settleToDate) {
		this.settleToDate = settleToDate;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public List<String> getTreatmentType() {
		return treatmentType;
	}
	public void setTreatmentType(List<String> treatmentType) {
		this.treatmentType = treatmentType;
	}
	public void setEdi(boolean isEdi) {
		this.isEdi = isEdi;
	}
	public void setStp(boolean isStp) {
		this.isStp = isStp;
	}
	public void setLifePa(boolean isLifePa) {
		this.isLifePa = isLifePa;
	}
	public void setCs(boolean isCs) {
		this.isCs = isCs;
	}
	
}
