package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.canonical.ClaimCanonical;

public class HCInternetClaimDetailForm {
	private ClaimCanonical claimCanonical;
	private String returnCode;
	private String returnMessage;

	public ClaimCanonical getClaimCanonical() {
		return claimCanonical;
	}

	public void setClaimCanonical(ClaimCanonical claimCanonical) {
		this.claimCanonical = claimCanonical;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}