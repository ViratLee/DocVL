package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlElement;

public class ClaimDeductDetail {
	Long claimDeductDetailId;
	String claimDeductNo;
	String policyNo;
	String benefitCode;
	Integer noOfDaysAllocated;
	Integer noOfCallAllocated;
	BigDecimal approvedAmt;
	String deductStatus;
	Date policyYearFromDt;
	Date policyYearToDt;
	String createdBy;
	String lastModifiedBy;
	Date createdDt;
	Date lastModifiedDt;
	String claimNo;
	long benefitItemId;
	String benefitKey;
	public Long getClaimDeductDetailId() {
		return claimDeductDetailId;
	}
	public String getClaimDeductNo() {
		return claimDeductNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public String getBenefitCode() {
		return benefitCode;
	}
	public Integer getNoOfDaysAllocated() {
		return noOfDaysAllocated;
	}
	public Integer getNoOfCallAllocated() {
		return noOfCallAllocated;
	}
	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}
	public String getDeductStatus() {
		return deductStatus;
	}
	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}
	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public Date getCreatedDt() {
		return createdDt;
	}
	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}
	public void setClaimDeductDetailId(Long claimDeductDetailId) {
		this.claimDeductDetailId = claimDeductDetailId;
	}
	public void setClaimDeductNo(String claimDeductNo) {
		this.claimDeductNo = claimDeductNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}
	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}
	public void setNoOfCallAllocated(Integer noOfCallAllocated) {
		this.noOfCallAllocated = noOfCallAllocated;
	}
	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}
	public void setDeductStatus(String deductStatus) {
		this.deductStatus = deductStatus;
	}
	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}
	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public long getBenefitItemId() {
		return benefitItemId;
	}
	public void setBenefitItemId(long benefitItemId) {
		this.benefitItemId = benefitItemId;
	}
	public String getBenefitKey() {
		return benefitKey;
	}
	public void setBenefitKey(String benefitKey) {
		this.benefitKey = benefitKey;
	}
	
	
}
