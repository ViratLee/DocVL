package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class Case360DocumentForm {

	//General Information
	private String businessType;
	private String category;
	private String channel;
	private String docId;
	private String docName;
	private Lookup docType;
	private String docTypeCode;
	private String policyNo;
	private String submissionPoint;
	private String totalPages;
	private String url;
	private String page;
	private boolean voidFlag;

	public final String getBusinessType() {
		return businessType;
	}

	public final void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public final String getCategory() {
		return category;
	}

	public final void setCategory(String category) {
		this.category = category;
	}

	public final String getChannel() {
		return channel;
	}

	public final void setChannel(String channel) {
		this.channel = channel;
	}

	public final String getDocId() {
		return docId;
	}

	public final void setDocId(String docId) {
		this.docId = docId;
	}

	public final String getDocName() {
		return docName;
	}

	public final void setDocName(String docName) {
		this.docName = docName;
	}

	public final Lookup getDocType() {
		return docType;
	}

	public final void setDocType(Lookup docType) {
		this.docType = docType;
	}

	public final String getDocTypeCode() {
		return docTypeCode;
	}

	public final void setDocTypeCode(String docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getSubmissionPoint() {
		return submissionPoint;
	}

	public final void setSubmissionPoint(String submissionPoint) {
		this.submissionPoint = submissionPoint;
	}

	public final String getTotalPages() {
		return totalPages;
	}

	public final void setTotalPages(String totalPages) {
		this.totalPages = totalPages;
	}

	public final String getUrl() {
		return url;
	}

	public final void setUrl(String url) {
		this.url = url;
	}

	public final boolean isVoidFlag() {
		return voidFlag;
	}

	public final void setVoidFlag(boolean voidFlag) {
		this.voidFlag = voidFlag;
	}

	public final String getPage() {
		return page;
	}

	public final void setPage(String page) {
		this.page = page;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
