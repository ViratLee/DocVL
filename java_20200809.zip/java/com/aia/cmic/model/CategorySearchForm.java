package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class CategorySearchForm {
	private String authorize;

	public String getAuthorize() {
		return authorize;
	}

	public void setAuthorize(String authorize) {
		this.authorize = authorize;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
