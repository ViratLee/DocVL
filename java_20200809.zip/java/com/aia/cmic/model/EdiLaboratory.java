package com.aia.cmic.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiLaboratory {

	public Long getEdiLaboratoryId() {
		return ediLaboratoryId;
	}

	public void setEdiLaboratoryId(Long ediLaboratoryId) {
		this.ediLaboratoryId = ediLaboratoryId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getLabCode() {
		return labCode;
	}

	public void setLabCode(String labCode) {
		this.labCode = labCode;
	}

	public String getLoinc() {
		return loinc;
	}

	public void setLoinc(String loinc) {
		this.loinc = loinc;
	}

	public String getLabGroup() {
		return labGroup;
	}

	public void setLabGroup(String labGroup) {
		this.labGroup = labGroup;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	public String getLabResult() {
		return labResult;
	}

	public void setLabResult(String labResult) {
		this.labResult = labResult;
	}

	public String getLabUnit() {
		return labUnit;
	}

	public void setLabUnit(String labUnit) {
		this.labUnit = labUnit;
	}

	public Date getResultDateTime() {
		return resultDateTime;
	}

	public void setResultDateTime(Date resultDateTime) {
		this.resultDateTime = resultDateTime;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	private Long ediLaboratoryId;
	private String claimNo;
	private Integer occurrence;
	@JsonProperty("labCode")
	private String labCode;
	@JsonProperty("LOINC")
	private String loinc;
	@JsonProperty("labGroup")
	private String labGroup;
	@JsonProperty("labName")
	private String labName;
	@JsonProperty("labResult")
	private String labResult;
	@JsonProperty("labUnit")
	private String labUnit;
	@JsonProperty("resultDatetime")
	@JsonFormat(shape = Shape.STRING, pattern = "dd-MM-yyyy HH:mm:ss")
	private Date resultDateTime;
	private Integer groupId;

}
