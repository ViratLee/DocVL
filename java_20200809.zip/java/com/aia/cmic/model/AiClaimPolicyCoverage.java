package com.aia.cmic.model;

public class AiClaimPolicyCoverage {
	
	private String BENEFITCODE;
	private String CLAIMNO;
	private Integer OCCURRENCE;
	private Long PLANID;
	private String POLICYNO;
	private String PRODUCTCODE;
	public String getBENEFITCODE() {
		return BENEFITCODE;
	}
	public void setBENEFITCODE(String bENEFITCODE) {
		BENEFITCODE = bENEFITCODE;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public Long getPLANID() {
		return PLANID;
	}
	public void setPLANID(Long pLANID) {
		PLANID = pLANID;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	public String getPRODUCTCODE() {
		return PRODUCTCODE;
	}
	public void setPRODUCTCODE(String pRODUCTCODE) {
		PRODUCTCODE = pRODUCTCODE;
	}

}
