package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class SpecialCondition {
	
	private Long claimSupplementId;
    private String codeType;
    private String strValue;
    private BigDecimal intValue;
    private String primaryInd;
    private String policyNo;
	

	public SpecialCondition() {

	}


	public Long getClaimSupplementId() {
		return claimSupplementId;
	}


	public void setClaimSupplementId(Long claimSupplementId) {
		this.claimSupplementId = claimSupplementId;
	}


	public String getCodeType() {
		return codeType;
	}


	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}


	public String getStrValue() {
		return strValue;
	}


	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}


	public BigDecimal getIntValue() {
		return intValue;
	}


	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}


	public String getPrimaryInd() {
		return primaryInd;
	}


	public void setPrimaryInd(String primaryInd) {
		this.primaryInd = primaryInd;
	}


	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

}
