package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class AiClaim {

	private String ACCIDENTDT;
	private String AGENCYCODESERVICING;
	private String AGENCYOFFICECODESERVICING;
	private String AGENTCODESERVICING;
	private String ANESTHESIAIND;
	private String ATTAINEDAGEIND;
	private String BILLINGDECLINEREASON;
	private String BROKERCODE;
	private String CARECARDIND;
	private String CAUSEOFINJURY;
	private String CAUSEOFTREATMENT;
	private String CERTNO;
	private String CHANNEL;
	private String CLAIMNO;
	private String CLASSOFBED;
	private String CLIENTID;
	private String CONSULTATIONDT;
	private String CONVCURRENCY;
	private Integer DAYOFADMITICU;
	private Integer DAYOFADMITROOM;
	private Integer DAYOFCALL;
	private String DEPENDENTNO;
	private String DEPENDENTTYPE;
	private String DISABILITYENDDT;
	private String DISABILITYSTARTDT;
	private String DISEASEIND;
	private String DOB;
	private String DOUBLEINDEMNITY;
	private Integer ESTIMATEDMONTHOFDISCOVERY;
	private Integer ESTIMATEDTIMEOFDISCOVERY;
	private String FASTTRACKAGENCY;
	private String FIRSTCONSULTATIONDT;
	private String GENDER;
	private String HBJSURGERYIND;
	private String HBPTYPE;
	private String HEALTHCARDIND;
	private String HN;
	private String HOMEMEDICALIND;
	private String HOSPITALIZATIONDATE;
	private String ICUREASON;
	private String INITIALPHASE;
	private String LEVELOFCONSCIOUSNESS;
	private String MAJORACCID;
	private String MAJORINJURYDETAIL;
	private String MEMBERID;
	private String NOORIGINALBILLIND;
	private Integer OCCURRENCE;
	private String ONECARDIND;
	private String ORIGCURRENCY;
	private String ORIGINALBILLIND;
	private Integer PARTIALDISABILITY;
	private Long PARTYID;
	private String PAYMENTMETHOD;
	private String PAYMENTSEQ;
	private String PHASE;
	private Long POLICYOWNERPARTYID;
	private String PREVTREATMENTDATE;
	private String PROVIDERCODE;
	private String RECEIVEDDATE;
	private String RELATIONSHIP;
	private String ROOMTYPE;
	private String SHORTFALLIND;
	private String SUBMISSIONTYPE;
	private String SURGERYIND;
	private String SURGICALPERCENTAGE;
	private String SYMPTOMDATE;
	private BigDecimal TOTALBILLEDAMT;
	private Integer TOTALDISABILITY;
	private BigDecimal TOTALESTIMATEDCOST;
	private String TREATMENTDATE;
	private String TREATMENTTYPE;
	private String VIP;
	private String DISCHARGEDATE;
	private String ICUADMISSIONDATE;
	private String ICUDISCHARGEDATE;
	private String HOSPITALIZATIONREASON; 
	private Integer LENGTHOFSTAY;
	private Integer ICULENGTHOFSTAY;
	private String DELETEIND;
	private String OTHERINSURER; 
	private String AUTOCLAIMIND ; 
	private String CPTCODE; 
	private String APPROVALCODE;
	
	// New Field
	private String ACCIDENTPLACE;
	private String AN;
	private String APPEALIND;
	private String ASSESSORCODE;
	private String BILLINGSTATUS;
	private String CHIEFCOMPLAINT;
	private String CLAIMSTATUSDT;
	private String CONDITIONREQUIREDTREATMENT;
	private String DIAGNOSISRESULT;
	private String EDIIND;
	private String EMERGENCYIND;
	private String HOLDPAYMENTDATE;
	private String HOLDPAYMENTIND;
	private String HOMELEAVEFROMDATE;
	private String HOMELEAVEREASON;
	private String HOMELEAVETODT;
	private String ILLNESSSPECIALCONDITION;
	private String INJURYTYPE;
	private String PAYEEISCOMPANYIND;
	private String PAYMENTIND;
	private String PHYSICALFINDING;
	private String PRESENTILLNESS;
	private String PREVDOCTORPHONE;
	private String PROCESSSTATUS;
	private String PROVISIONALDIAGNOSIS;;
	private String RECEIPTOFREFERRAL;
	private String RECONSIDERCASE;
	private String REFERRALDOCTORCODE;
	private String RELATIONSHIPNAME;
	private String RELEASEHOLDPAYMENTDATE;
	private String STPIND;
	private String SUBOFFICECODE;
	private String SUBOFFICESTATUS;
	private String UNDERLYINGCAUSE;
	
	public String getACCIDENTDT() {
		return ACCIDENTDT;
	}
	public void setACCIDENTDT(String aCCIDENTDT) {
		ACCIDENTDT = aCCIDENTDT;
	}
	public String getAGENCYCODESERVICING() {
		return AGENCYCODESERVICING;
	}
	public void setAGENCYCODESERVICING(String aGENCYCODESERVICING) {
		AGENCYCODESERVICING = aGENCYCODESERVICING;
	}
	public String getAGENCYOFFICECODESERVICING() {
		return AGENCYOFFICECODESERVICING;
	}
	public void setAGENCYOFFICECODESERVICING(String aGENCYOFFICECODESERVICING) {
		AGENCYOFFICECODESERVICING = aGENCYOFFICECODESERVICING;
	}
	public String getAGENTCODESERVICING() {
		return AGENTCODESERVICING;
	}
	public void setAGENTCODESERVICING(String aGENTCODESERVICING) {
		AGENTCODESERVICING = aGENTCODESERVICING;
	}
	public String getANESTHESIAIND() {
		return ANESTHESIAIND;
	}
	public void setANESTHESIAIND(String aNESTHESIAIND) {
		ANESTHESIAIND = aNESTHESIAIND;
	}
	public String getATTAINEDAGEIND() {
		return ATTAINEDAGEIND;
	}
	public void setATTAINEDAGEIND(String aTTAINEDAGEIND) {
		ATTAINEDAGEIND = aTTAINEDAGEIND;
	}
	public String getBILLINGDECLINEREASON() {
		return BILLINGDECLINEREASON;
	}
	public void setBILLINGDECLINEREASON(String bILLINGDECLINEREASON) {
		BILLINGDECLINEREASON = bILLINGDECLINEREASON;
	}
	public String getBROKERCODE() {
		return BROKERCODE;
	}
	public void setBROKERCODE(String bROKERCODE) {
		BROKERCODE = bROKERCODE;
	}
	public String getCARECARDIND() {
		return CARECARDIND;
	}
	public void setCARECARDIND(String cARECARDIND) {
		CARECARDIND = cARECARDIND;
	}
	public String getCAUSEOFINJURY() {
		return CAUSEOFINJURY;
	}
	public void setCAUSEOFINJURY(String cAUSEOFINJURY) {
		CAUSEOFINJURY = cAUSEOFINJURY;
	}
	public String getCAUSEOFTREATMENT() {
		return CAUSEOFTREATMENT;
	}
	public void setCAUSEOFTREATMENT(String cAUSEOFTREATMENT) {
		CAUSEOFTREATMENT = cAUSEOFTREATMENT;
	}
	public String getCERTNO() {
		return CERTNO;
	}
	public void setCERTNO(String cERTNO) {
		CERTNO = cERTNO;
	}
	public String getCHANNEL() {
		return CHANNEL;
	}
	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public String getCLASSOFBED() {
		return CLASSOFBED;
	}
	public void setCLASSOFBED(String cLASSOFBED) {
		CLASSOFBED = cLASSOFBED;
	}
	public String getCLIENTID() {
		return CLIENTID;
	}
	public void setCLIENTID(String cLIENTID) {
		CLIENTID = cLIENTID;
	}
	public String getCONSULTATIONDT() {
		return CONSULTATIONDT;
	}
	public void setCONSULTATIONDT(String cONSULTATIONDT) {
		CONSULTATIONDT = cONSULTATIONDT;
	}
	public String getCONVCURRENCY() {
		return CONVCURRENCY;
	}
	public void setCONVCURRENCY(String cONVCURRENCY) {
		CONVCURRENCY = cONVCURRENCY;
	}
	public Integer getDAYOFADMITICU() {
		return DAYOFADMITICU;
	}
	public void setDAYOFADMITICU(Integer dAYOFADMITICU) {
		DAYOFADMITICU = dAYOFADMITICU;
	}
	public Integer getDAYOFADMITROOM() {
		return DAYOFADMITROOM;
	}
	public void setDAYOFADMITROOM(Integer dAYOFADMITROOM) {
		DAYOFADMITROOM = dAYOFADMITROOM;
	}
	public Integer getDAYOFCALL() {
		return DAYOFCALL;
	}
	public void setDAYOFCALL(Integer dAYOFCALL) {
		DAYOFCALL = dAYOFCALL;
	}
	public String getDEPENDENTNO() {
		return DEPENDENTNO;
	}
	public void setDEPENDENTNO(String dEPENDENTNO) {
		DEPENDENTNO = dEPENDENTNO;
	}
	public String getDEPENDENTTYPE() {
		return DEPENDENTTYPE;
	}
	public void setDEPENDENTTYPE(String dEPENDENTTYPE) {
		DEPENDENTTYPE = dEPENDENTTYPE;
	}
	public String getDISABILITYENDDT() {
		return DISABILITYENDDT;
	}
	public void setDISABILITYENDDT(String dISABILITYENDDT) {
		DISABILITYENDDT = dISABILITYENDDT;
	}
	public String getDISABILITYSTARTDT() {
		return DISABILITYSTARTDT;
	}
	public void setDISABILITYSTARTDT(String dISABILITYSTARTDT) {
		DISABILITYSTARTDT = dISABILITYSTARTDT;
	}
	public String getDISEASEIND() {
		return DISEASEIND;
	}
	public void setDISEASEIND(String dISEASEIND) {
		DISEASEIND = dISEASEIND;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getDOUBLEINDEMNITY() {
		return DOUBLEINDEMNITY;
	}
	public void setDOUBLEINDEMNITY(String dOUBLEINDEMNITY) {
		DOUBLEINDEMNITY = dOUBLEINDEMNITY;
	}
	public Integer getESTIMATEDMONTHOFDISCOVERY() {
		return ESTIMATEDMONTHOFDISCOVERY;
	}
	public void setESTIMATEDMONTHOFDISCOVERY(Integer eSTIMATEDMONTHOFDISCOVERY) {
		ESTIMATEDMONTHOFDISCOVERY = eSTIMATEDMONTHOFDISCOVERY;
	}
	public Integer getESTIMATEDTIMEOFDISCOVERY() {
		return ESTIMATEDTIMEOFDISCOVERY;
	}
	public void setESTIMATEDTIMEOFDISCOVERY(Integer eSTIMATEDTIMEOFDISCOVERY) {
		ESTIMATEDTIMEOFDISCOVERY = eSTIMATEDTIMEOFDISCOVERY;
	}
	public String getFASTTRACKAGENCY() {
		return FASTTRACKAGENCY;
	}
	public void setFASTTRACKAGENCY(String fASTTRACKAGENCY) {
		FASTTRACKAGENCY = fASTTRACKAGENCY;
	}
	public String getFIRSTCONSULTATIONDT() {
		return FIRSTCONSULTATIONDT;
	}
	public void setFIRSTCONSULTATIONDT(String fIRSTCONSULTATIONDT) {
		FIRSTCONSULTATIONDT = fIRSTCONSULTATIONDT;
	}
	public String getGENDER() {
		return GENDER;
	}
	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}
	public String getHBJSURGERYIND() {
		return HBJSURGERYIND;
	}
	public void setHBJSURGERYIND(String hBJSURGERYIND) {
		HBJSURGERYIND = hBJSURGERYIND;
	}
	public String getHBPTYPE() {
		return HBPTYPE;
	}
	public void setHBPTYPE(String hBPTYPE) {
		HBPTYPE = hBPTYPE;
	}
	public String getHEALTHCARDIND() {
		return HEALTHCARDIND;
	}
	public void setHEALTHCARDIND(String hEALTHCARDIND) {
		HEALTHCARDIND = hEALTHCARDIND;
	}
	public String getHN() {
		return HN;
	}
	public void setHN(String hN) {
		HN = hN;
	}
	public String getHOMEMEDICALIND() {
		return HOMEMEDICALIND;
	}
	public void setHOMEMEDICALIND(String hOMEMEDICALIND) {
		HOMEMEDICALIND = hOMEMEDICALIND;
	}
	public String getHOSPITALIZATIONDATE() {
		return HOSPITALIZATIONDATE;
	}
	public void setHOSPITALIZATIONDATE(String hOSPITALIZATIONDATE) {
		HOSPITALIZATIONDATE = hOSPITALIZATIONDATE;
	}
	public String getICUREASON() {
		return ICUREASON;
	}
	public void setICUREASON(String iCUREASON) {
		ICUREASON = iCUREASON;
	}
	public String getINITIALPHASE() {
		return INITIALPHASE;
	}
	public void setINITIALPHASE(String iNITIALPHASE) {
		INITIALPHASE = iNITIALPHASE;
	}
	public String getLEVELOFCONSCIOUSNESS() {
		return LEVELOFCONSCIOUSNESS;
	}
	public void setLEVELOFCONSCIOUSNESS(String lEVELOFCONSCIOUSNESS) {
		LEVELOFCONSCIOUSNESS = lEVELOFCONSCIOUSNESS;
	}
	public String getMAJORACCID() {
		return MAJORACCID;
	}
	public void setMAJORACCID(String mAJORACCID) {
		MAJORACCID = mAJORACCID;
	}
	public String getMAJORINJURYDETAIL() {
		return MAJORINJURYDETAIL;
	}
	public void setMAJORINJURYDETAIL(String mAJORINJURYDETAIL) {
		MAJORINJURYDETAIL = mAJORINJURYDETAIL;
	}
	public String getMEMBERID() {
		return MEMBERID;
	}
	public void setMEMBERID(String mEMBERID) {
		MEMBERID = mEMBERID;
	}
	public String getNOORIGINALBILLIND() {
		return NOORIGINALBILLIND;
	}
	public void setNOORIGINALBILLIND(String nOORIGINALBILLIND) {
		NOORIGINALBILLIND = nOORIGINALBILLIND;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getONECARDIND() {
		return ONECARDIND;
	}
	public void setONECARDIND(String oNECARDIND) {
		ONECARDIND = oNECARDIND;
	}
	public String getORIGCURRENCY() {
		return ORIGCURRENCY;
	}
	public void setORIGCURRENCY(String oRIGCURRENCY) {
		ORIGCURRENCY = oRIGCURRENCY;
	}
	public String getORIGINALBILLIND() {
		return ORIGINALBILLIND;
	}
	public void setORIGINALBILLIND(String oRIGINALBILLIND) {
		ORIGINALBILLIND = oRIGINALBILLIND;
	}
	public Integer getPARTIALDISABILITY() {
		return PARTIALDISABILITY;
	}
	public void setPARTIALDISABILITY(Integer pARTIALDISABILITY) {
		PARTIALDISABILITY = pARTIALDISABILITY;
	}
	public Long getPARTYID() {
		return PARTYID;
	}
	public void setPARTYID(Long pARTYID) {
		PARTYID = pARTYID;
	}
	public String getPAYMENTMETHOD() {
		return PAYMENTMETHOD;
	}
	public void setPAYMENTMETHOD(String pAYMENTMETHOD) {
		PAYMENTMETHOD = pAYMENTMETHOD;
	}
	public String getPAYMENTSEQ() {
		return PAYMENTSEQ;
	}
	public void setPAYMENTSEQ(String pAYMENTSEQ) {
		PAYMENTSEQ = pAYMENTSEQ;
	}
	public String getPHASE() {
		return PHASE;
	}
	public void setPHASE(String pHASE) {
		PHASE = pHASE;
	}
	public Long getPOLICYOWNERPARTYID() {
		return POLICYOWNERPARTYID;
	}
	public void setPOLICYOWNERPARTYID(Long pOLICYOWNERPARTYID) {
		POLICYOWNERPARTYID = pOLICYOWNERPARTYID;
	}
	public String getPREVTREATMENTDATE() {
		return PREVTREATMENTDATE;
	}
	public void setPREVTREATMENTDATE(String pREVTREATMENTDATE) {
		PREVTREATMENTDATE = pREVTREATMENTDATE;
	}
	public String getPROVIDERCODE() {
		return PROVIDERCODE;
	}
	public void setPROVIDERCODE(String pROVIDERCODE) {
		PROVIDERCODE = pROVIDERCODE;
	}
	public String getRECEIVEDDATE() {
		return RECEIVEDDATE;
	}
	public void setRECEIVEDDATE(String rECEIVEDDATE) {
		RECEIVEDDATE = rECEIVEDDATE;
	}
	public String getRELATIONSHIP() {
		return RELATIONSHIP;
	}
	public void setRELATIONSHIP(String rELATIONSHIP) {
		RELATIONSHIP = rELATIONSHIP;
	}
	public String getROOMTYPE() {
		return ROOMTYPE;
	}
	public void setROOMTYPE(String rOOMTYPE) {
		ROOMTYPE = rOOMTYPE;
	}
	public String getSHORTFALLIND() {
		return SHORTFALLIND;
	}
	public void setSHORTFALLIND(String sHORTFALLIND) {
		SHORTFALLIND = sHORTFALLIND;
	}
	public String getSUBMISSIONTYPE() {
		return SUBMISSIONTYPE;
	}
	public void setSUBMISSIONTYPE(String sUBMISSIONTYPE) {
		SUBMISSIONTYPE = sUBMISSIONTYPE;
	}
	public String getSURGERYIND() {
		return SURGERYIND;
	}
	public void setSURGERYIND(String sURGERYIND) {
		SURGERYIND = sURGERYIND;
	}
	public String getSURGICALPERCENTAGE() {
		return SURGICALPERCENTAGE;
	}
	public void setSURGICALPERCENTAGE(String sURGICALPERCENTAGE) {
		SURGICALPERCENTAGE = sURGICALPERCENTAGE;
	}
	public String getSYMPTOMDATE() {
		return SYMPTOMDATE;
	}
	public void setSYMPTOMDATE(String sYMPTOMDATE) {
		SYMPTOMDATE = sYMPTOMDATE;
	}
	public BigDecimal getTOTALBILLEDAMT() {
		return TOTALBILLEDAMT;
	}
	public void setTOTALBILLEDAMT(BigDecimal tOTALBILLEDAMT) {
		TOTALBILLEDAMT = tOTALBILLEDAMT;
	}
	public Integer getTOTALDISABILITY() {
		return TOTALDISABILITY;
	}
	public void setTOTALDISABILITY(Integer tOTALDISABILITY) {
		TOTALDISABILITY = tOTALDISABILITY;
	}
	public BigDecimal getTOTALESTIMATEDCOST() {
		return TOTALESTIMATEDCOST;
	}
	public void setTOTALESTIMATEDCOST(BigDecimal tOTALESTIMATEDCOST) {
		TOTALESTIMATEDCOST = tOTALESTIMATEDCOST;
	}
	public String getTREATMENTDATE() {
		return TREATMENTDATE;
	}
	public void setTREATMENTDATE(String tREATMENTDATE) {
		TREATMENTDATE = tREATMENTDATE;
	}
	public String getTREATMENTTYPE() {
		return TREATMENTTYPE;
	}
	public void setTREATMENTTYPE(String tREATMENTTYPE) {
		TREATMENTTYPE = tREATMENTTYPE;
	}
	public String getVIP() {
		return VIP;
	}
	public void setVIP(String vIP) {
		VIP = vIP;
	}
	public String getDISCHARGEDATE() {
		return DISCHARGEDATE;
	}
	public void setDISCHARGEDATE(String dISCHARGEDATE) {
		DISCHARGEDATE = dISCHARGEDATE;
	}
	public String getICUADMISSIONDATE() {
		return ICUADMISSIONDATE;
	}
	public void setICUADMISSIONDATE(String iCUADMISSIONDATE) {
		ICUADMISSIONDATE = iCUADMISSIONDATE;
	}
	public String getICUDISCHARGEDATE() {
		return ICUDISCHARGEDATE;
	}
	public void setICUDISCHARGEDATE(String iCUDISCHARGEDATE) {
		ICUDISCHARGEDATE = iCUDISCHARGEDATE;
	}
	public String getHOSPITALIZATIONREASON() {
		return HOSPITALIZATIONREASON;
	}
	public void setHOSPITALIZATIONREASON(String hOSPITALIZATIONREASON) {
		HOSPITALIZATIONREASON = hOSPITALIZATIONREASON;
	}
	public Integer getLENGTHOFSTAY() {
		return LENGTHOFSTAY;
	}
	public void setLENGTHOFSTAY(Integer lENGTHOFSTAY) {
		LENGTHOFSTAY = lENGTHOFSTAY;
	}
	public Integer getICULENGTHOFSTAY() {
		return ICULENGTHOFSTAY;
	}
	public void setICULENGTHOFSTAY(Integer iCULENGTHOFSTAY) {
		ICULENGTHOFSTAY = iCULENGTHOFSTAY;
	}
	public String getDELETEIND() {
		return DELETEIND;
	}
	public void setDELETEIND(String dELETEIND) {
		DELETEIND = dELETEIND;
	}
	public String getOTHERINSURER() {
		return OTHERINSURER;
	}
	public void setOTHERINSURER(String oTHERINSURER) {
		OTHERINSURER = oTHERINSURER;
	}
	public String getAUTOCLAIMIND() {
		return AUTOCLAIMIND;
	}
	public void setAUTOCLAIMIND(String aUTOCLAIMIND) {
		AUTOCLAIMIND = aUTOCLAIMIND;
	}
	public String getCPTCODE() {
		return CPTCODE;
	}
	public void setCPTCODE(String cPTCODE) {
		CPTCODE = cPTCODE;
	}
	public String getAPPROVALCODE() {
		return APPROVALCODE;
	}
	public void setAPPROVALCODE(String aPPROVALCODE) {
		APPROVALCODE = aPPROVALCODE;
	}
	public String getACCIDENTPLACE() {
		return ACCIDENTPLACE;
	}
	public void setACCIDENTPLACE(String aCCIDENTPLACE) {
		ACCIDENTPLACE = aCCIDENTPLACE;
	}
	public String getAN() {
		return AN;
	}
	public void setAN(String aN) {
		AN = aN;
	}
	public String getAPPEALIND() {
		return APPEALIND;
	}
	public void setAPPEALIND(String aPPEALIND) {
		APPEALIND = aPPEALIND;
	}
	public String getASSESSORCODE() {
		return ASSESSORCODE;
	}
	public void setASSESSORCODE(String aSSESSORCODE) {
		ASSESSORCODE = aSSESSORCODE;
	}
	public String getBILLINGSTATUS() {
		return BILLINGSTATUS;
	}
	public void setBILLINGSTATUS(String bILLINGSTATUS) {
		BILLINGSTATUS = bILLINGSTATUS;
	}
	public String getCHIEFCOMPLAINT() {
		return CHIEFCOMPLAINT;
	}
	public void setCHIEFCOMPLAINT(String cHIEFCOMPLAINT) {
		CHIEFCOMPLAINT = cHIEFCOMPLAINT;
	}
	public String getCLAIMSTATUSDT() {
		return CLAIMSTATUSDT;
	}
	public void setCLAIMSTATUSDT(String cLAIMSTATUSDT) {
		CLAIMSTATUSDT = cLAIMSTATUSDT;
	}
	public String getCONDITIONREQUIREDTREATMENT() {
		return CONDITIONREQUIREDTREATMENT;
	}
	public void setCONDITIONREQUIREDTREATMENT(String cONDITIONREQUIREDTREATMENT) {
		CONDITIONREQUIREDTREATMENT = cONDITIONREQUIREDTREATMENT;
	}
	public String getDIAGNOSISRESULT() {
		return DIAGNOSISRESULT;
	}
	public void setDIAGNOSISRESULT(String dIAGNOSISRESULT) {
		DIAGNOSISRESULT = dIAGNOSISRESULT;
	}
	public String getEDIIND() {
		return EDIIND;
	}
	public void setEDIIND(String eDIIND) {
		EDIIND = eDIIND;
	}
	public String getEMERGENCYIND() {
		return EMERGENCYIND;
	}
	public void setEMERGENCYIND(String eMERGENCYIND) {
		EMERGENCYIND = eMERGENCYIND;
	}
	public String getHOLDPAYMENTDATE() {
		return HOLDPAYMENTDATE;
	}
	public void setHOLDPAYMENTDATE(String hOLDPAYMENTDATE) {
		HOLDPAYMENTDATE = hOLDPAYMENTDATE;
	}
	public String getHOLDPAYMENTIND() {
		return HOLDPAYMENTIND;
	}
	public void setHOLDPAYMENTIND(String hOLDPAYMENTIND) {
		HOLDPAYMENTIND = hOLDPAYMENTIND;
	}
	public String getHOMELEAVEFROMDATE() {
		return HOMELEAVEFROMDATE;
	}
	public void setHOMELEAVEFROMDATE(String hOMELEAVEFROMDATE) {
		HOMELEAVEFROMDATE = hOMELEAVEFROMDATE;
	}
	public String getHOMELEAVEREASON() {
		return HOMELEAVEREASON;
	}
	public void setHOMELEAVEREASON(String hOMELEAVEREASON) {
		HOMELEAVEREASON = hOMELEAVEREASON;
	}
	public String getHOMELEAVETODT() {
		return HOMELEAVETODT;
	}
	public void setHOMELEAVETODT(String hOMELEAVETODT) {
		HOMELEAVETODT = hOMELEAVETODT;
	}
	public String getILLNESSSPECIALCONDITION() {
		return ILLNESSSPECIALCONDITION;
	}
	public void setILLNESSSPECIALCONDITION(String iLLNESSSPECIALCONDITION) {
		ILLNESSSPECIALCONDITION = iLLNESSSPECIALCONDITION;
	}
	public String getINJURYTYPE() {
		return INJURYTYPE;
	}
	public void setINJURYTYPE(String iNJURYTYPE) {
		INJURYTYPE = iNJURYTYPE;
	}
	public String getPAYEEISCOMPANYIND() {
		return PAYEEISCOMPANYIND;
	}
	public void setPAYEEISCOMPANYIND(String pAYEEISCOMPANYIND) {
		PAYEEISCOMPANYIND = pAYEEISCOMPANYIND;
	}
	public String getPAYMENTIND() {
		return PAYMENTIND;
	}
	public void setPAYMENTIND(String pAYMENTIND) {
		PAYMENTIND = pAYMENTIND;
	}
	public String getPHYSICALFINDING() {
		return PHYSICALFINDING;
	}
	public void setPHYSICALFINDING(String pHYSICALFINDING) {
		PHYSICALFINDING = pHYSICALFINDING;
	}
	public String getPRESENTILLNESS() {
		return PRESENTILLNESS;
	}
	public void setPRESENTILLNESS(String pRESENTILLNESS) {
		PRESENTILLNESS = pRESENTILLNESS;
	}
	public String getPREVDOCTORPHONE() {
		return PREVDOCTORPHONE;
	}
	public void setPREVDOCTORPHONE(String pREVDOCTORPHONE) {
		PREVDOCTORPHONE = pREVDOCTORPHONE;
	}
	public String getPROCESSSTATUS() {
		return PROCESSSTATUS;
	}
	public void setPROCESSSTATUS(String pROCESSSTATUS) {
		PROCESSSTATUS = pROCESSSTATUS;
	}
	public String getPROVISIONALDIAGNOSIS() {
		return PROVISIONALDIAGNOSIS;
	}
	public void setPROVISIONALDIAGNOSIS(String pROVISIONALDIAGNOSIS) {
		PROVISIONALDIAGNOSIS = pROVISIONALDIAGNOSIS;
	}
	public String getRECEIPTOFREFERRAL() {
		return RECEIPTOFREFERRAL;
	}
	public void setRECEIPTOFREFERRAL(String rECEIPTOFREFERRAL) {
		RECEIPTOFREFERRAL = rECEIPTOFREFERRAL;
	}
	public String getRECONSIDERCASE() {
		return RECONSIDERCASE;
	}
	public void setRECONSIDERCASE(String rECONSIDERCASE) {
		RECONSIDERCASE = rECONSIDERCASE;
	}
	public String getREFERRALDOCTORCODE() {
		return REFERRALDOCTORCODE;
	}
	public void setREFERRALDOCTORCODE(String rEFERRALDOCTORCODE) {
		REFERRALDOCTORCODE = rEFERRALDOCTORCODE;
	}
	public String getRELATIONSHIPNAME() {
		return RELATIONSHIPNAME;
	}
	public void setRELATIONSHIPNAME(String rELATIONSHIPNAME) {
		RELATIONSHIPNAME = rELATIONSHIPNAME;
	}
	public String getRELEASEHOLDPAYMENTDATE() {
		return RELEASEHOLDPAYMENTDATE;
	}
	public void setRELEASEHOLDPAYMENTDATE(String rELEASEHOLDPAYMENTDATE) {
		RELEASEHOLDPAYMENTDATE = rELEASEHOLDPAYMENTDATE;
	}
	public String getSTPIND() {
		return STPIND;
	}
	public void setSTPIND(String sTPIND) {
		STPIND = sTPIND;
	}
	public String getSUBOFFICECODE() {
		return SUBOFFICECODE;
	}
	public void setSUBOFFICECODE(String sUBOFFICECODE) {
		SUBOFFICECODE = sUBOFFICECODE;
	}
	public String getSUBOFFICESTATUS() {
		return SUBOFFICESTATUS;
	}
	public void setSUBOFFICESTATUS(String sUBOFFICESTATUS) {
		SUBOFFICESTATUS = sUBOFFICESTATUS;
	}
	public String getUNDERLYINGCAUSE() {
		return UNDERLYINGCAUSE;
	}
	public void setUNDERLYINGCAUSE(String uNDERLYINGCAUSE) {
		UNDERLYINGCAUSE = uNDERLYINGCAUSE;
	} 
	
	
}
