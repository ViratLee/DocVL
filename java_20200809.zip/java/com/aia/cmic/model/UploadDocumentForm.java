package com.aia.cmic.model;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.restservices.model.DocumentProvider;
import com.aia.cmic.restservices.model.ProviderParam;

public class UploadDocumentForm {
	private String providerCode;
	private String docTypeCode;
	private String docName;
	private BigDecimal docId;
	private String url;
	private String doctorCode;
	private int contractId;
	private String file;

	public ProviderParam toProviderParam(UploadDocumentForm form) {
		ProviderParam param = new ProviderParam();
		param.setContractId(form.getContractId());
		param.setDoctorCode(form.getDoctorCode());
		param.setProviderCode(form.getProviderCode());
		return param;
	}

	public DocumentProvider toDocumentProvider(UploadDocumentForm form) {
		DocumentProvider param = new DocumentProvider();
		param.setDocId(form.getDocId());
		param.setDocName(form.getDocName());
		param.setDocTypeCode(form.getDocTypeCode());
		param.setUrl(form.getUrl());
		//	param.setBase64Data(form.getFile().getBytes());
		return param;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getDocTypeCode() {
		return docTypeCode;
	}

	public void setDocTypeCode(String docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public BigDecimal getDocId() {
		return docId;
	}

	public void setDocId(BigDecimal docId) {
		this.docId = docId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDoctorCode() {
		return doctorCode;
	}

	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	public int getContractId() {
		return contractId;
	}

	public void setContractId(int contractId) {
		this.contractId = contractId;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
