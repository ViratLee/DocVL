package com.aia.cmic.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiBillingItem {

	private Long ediBillingItemId;
	private String claimNo;
	private Integer occurrence;

	@JsonProperty("localBillingCode")
	private String localBillingCode;
	@JsonProperty("simbBillingCode")
	private String simbBillingCode;
	@JsonProperty("aiaBillingCode")
	private String aiaBillingCode;
	@JsonProperty("billingInitial")
	private BigDecimal billingInitial;
	@JsonProperty("billingDiscount")
	private BigDecimal billingDiscount;
	@JsonProperty("billingNetAmount")
	private BigDecimal billingNetAmount;
	@JsonProperty("localBillingName")
	private String localBillingName;

	public Long getEdiBillingItemId() {
		return ediBillingItemId;
	}

	public void setEdiBillingItemId(Long ediBillingItemId) {
		this.ediBillingItemId = ediBillingItemId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getLocalBillingCode() {
		return localBillingCode;
	}

	public void setLocalBillingCode(String localBillingCode) {
		this.localBillingCode = localBillingCode;
	}

	public String getSimbBillingCode() {
		return simbBillingCode;
	}

	public void setSimbBillingCode(String simbBillingCode) {
		this.simbBillingCode = simbBillingCode;
	}

	public String getAiaBillingCode() {
		return aiaBillingCode;
	}

	public void setAiaBillingCode(String aiaBillingCode) {
		this.aiaBillingCode = aiaBillingCode;
	}

	public BigDecimal getBillingInitial() {
		return billingInitial;
	}

	public void setBillingInitial(BigDecimal billingInitial) {
		this.billingInitial = billingInitial;
	}

	public BigDecimal getBillingDiscount() {
		return billingDiscount;
	}

	public void setBillingDiscount(BigDecimal billingDiscount) {
		this.billingDiscount = billingDiscount;
	}

	public BigDecimal getBillingNetAmount() {
		return billingNetAmount;
	}

	public void setBillingNetAmount(BigDecimal billingNetAmount) {
		this.billingNetAmount = billingNetAmount;
	}

	public String getLocalBillingName() {
		return localBillingName;
	}

	public void setLocalBillingName(String localBillingName) {
		this.localBillingName = localBillingName;
	}

}
