package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitBillingItemDetail {
	@XmlElement(name = "billingItemTotal")
	BigDecimal billingItemTotal = BigDecimal.ZERO;
	@XmlElement(name = "benefitBillingItemList")
	List<BenefitBillingItem> benefitBillingItemList = new ArrayList<BenefitBillingItem>();

	public BigDecimal getBillingItemTotal() {
		return billingItemTotal;
	}

	public void setBillingItemTotal(BigDecimal billingItemTotal) {
		this.billingItemTotal = billingItemTotal;
	}

	public List<BenefitBillingItem> getBenefitBillingItemList() {
		return benefitBillingItemList;
	}

	public void setBenefitBillingItemList(List<BenefitBillingItem> benefitBillingItemList) {
		this.benefitBillingItemList = benefitBillingItemList;
		calculateBenefitBillingItemAmount();
	}

	private void calculateBenefitBillingItemAmount() {
		if ((this.benefitBillingItemList != null) && (this.benefitBillingItemList.size() > 0)) {
			this.billingItemTotal = BigDecimal.ZERO;
			for (BenefitBillingItem billingItem : this.benefitBillingItemList) {
				BigDecimal amount = billingItem.getPresentedAmount();
				this.billingItemTotal = this.billingItemTotal.add(amount);
			}
		}
	}

}
