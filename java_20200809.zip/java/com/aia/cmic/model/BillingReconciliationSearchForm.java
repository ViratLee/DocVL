package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class BillingReconciliationSearchForm {
	private String batchNo;
	private String policyNo;
	private String providerCode;
	private Date dischargeDateFrom;
	private Date dischargeDateTo;
	private String typeOfTreatment;
	private String businessLine;
	private String aiInd;
	private int page = 1;
	private int pageSize = 10;

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getProviderCode() {
		return providerCode;
	}

	public final void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public Date getDischargeDateFrom() {
		return dischargeDateFrom;
	}

	public void setDischargeDateFrom(Date dischargeDateFrom) {
		this.dischargeDateFrom = dischargeDateFrom;
	}

	public Date getDischargeDateTo() {
		return dischargeDateTo;
	}

	public void setDischargeDateTo(Date dischargeDateTo) {
		this.dischargeDateTo = dischargeDateTo;
	}

	public final String getTypeOfTreatment() {
		return typeOfTreatment;
	}

	public final void setTypeOfTreatment(String typeOfTreatment) {
		this.typeOfTreatment = typeOfTreatment;
	}

	public final int getPage() {
		return page;
	}

	public final void setPage(int page) {
		this.page = page;
	}

	public final int getPageSize() {
		return pageSize;
	}

	public final void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public String getAiInd() {
		return aiInd;
	}

	public void setAiInd(String aiInd) {
		this.aiInd = aiInd;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
