package com.aia.cmic.model;

import java.util.List;

import com.aia.cmic.model.ClaimDeduct;
import com.aia.cmic.model.ClaimDeductDetail;

public class ClaimDeductForm {
	private String claimNo;
	private Integer occurrence;
	private Long caseId;
	private ClaimDeduct claimDeduct;
    private List<HNWBenefitCode> hnwBenefitCodeList;
    
	public ClaimDeduct getClaimDeduct() {
		return claimDeduct;
	}
	public List<HNWBenefitCode> getHnwBenefitCodeList() {
		return hnwBenefitCodeList;
	}
	public void setClaimDeduct(ClaimDeduct claimDeduct) {
		this.claimDeduct = claimDeduct;
	}
	public void setHnwBenefitCodeList(List<HNWBenefitCode> hnwBenefitCodeList) {
		this.hnwBenefitCodeList = hnwBenefitCodeList;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public Integer getOccurrence() {
		return occurrence;
	}
	public Long getCaseId() {
		return caseId;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}
	
}
