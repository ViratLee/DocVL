package com.aia.cmic.model;

import java.math.BigDecimal;

public class ClaimPaymentAccumulator {

	Long claimPaymentAccumulatorId;
	String companyId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String planCoverageNo;
	String productCode;
	String benefitCode;
	BigDecimal accumulatorNo;
	BigDecimal eligibleAmt;
	Integer reimbursedDay;

	/**
	 * @return the claimPaymentAccumulatorId
	 */
	public Long getClaimPaymentAccumulatorId() {
		return claimPaymentAccumulatorId;
	}

	/**
	 * @param claimPaymentAccumulatorId the claimPaymentAccumulatorId to set
	 */
	public void setClaimPaymentAccumulatorId(Long claimPaymentAccumulatorId) {
		this.claimPaymentAccumulatorId = claimPaymentAccumulatorId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the benefitCode
	 */
	public String getBenefitCode() {
		return benefitCode;
	}

	/**
	 * @param benefitCode the benefitCode to set
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 * @return the accumulatorNo
	 */
	public BigDecimal getAccumulatorNo() {
		return accumulatorNo;
	}

	/**
	 * @param accumulatorNo the accumulatorNo to set
	 */
	public void setAccumulatorNo(BigDecimal accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	/**
	 * @return the eligibleAmt
	 */
	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	/**
	 * @param eligibleAmt the eligibleAmt to set
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 * @return the reimbursedDay
	 */
	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	/**
	 * @param reimbursedDay the reimbursedDay to set
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

}
