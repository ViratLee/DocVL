package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class PartySnapshot {

	protected String partyId;
	protected String clientId;
	protected String policyNo;
	private String memberId;
	private String memberLastName;
	private String memberFirstName;
	private String policyHolder;
	private String policyOwner;
	private String policyOwnerPartyId;
	protected String certNo;
	protected String dependentNo;
	protected String dependentType;
	private String relationship;
	protected String firstName;
	protected String lastName;
	protected String gender;
	protected String nationalId;
	private String role;
	protected String dob;
	private String vip;
	private String agentPartyId;
	private String agentWritingCode;
	private String agencyWritingCode;
	private String brokerWritingCode;
	private String policyIssueDate;
	private String coPaymentPercent;
	protected String subOfficeCode;
	private String subOfficeName;

	/* Claim */
	private String submissionAgentName;
	private String submissionAgencyName;
	private String submissionGaOfficeName;
	private String submissionAgencyLeaderName;
	/* ClaimPolicy */
	private String writingAgentName;
	private String writingAgencyName;
	private String writingGaOfficeName;
	private String writingGaOfficeCode;
	private String writingAgencyLeaderName;

	private String status;
	private String businessLine;

	private String mdrt;
	private String bbl;

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	// implement at PartyServiceImpl.getPartySnapshot
	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the memberLastName
	 */
	public String getMemberLastName() {
		return memberLastName;
	}

	/**
	 * @param memberLastName the memberLastName to set
	 */
	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	/**
	 * @return the memberFirstName
	 */
	public String getMemberFirstName() {
		return memberFirstName;
	}

	/**
	 * @param memberFirstName the memberFirstName to set
	 */
	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	/**
	 * @return the policyHolder
	 */
	public String getPolicyHolder() {
		return policyHolder;
	}

	/**
	 * @param policyHolder the policyHolder to set
	 */
	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	/**
	 * @return the policyOwner
	 */
	public String getPolicyOwner() {
		return policyOwner;
	}

	/**
	 * @param policyOwner the policyOwner to set
	 */
	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	/**
	 * @return the policyOwnerPartyId
	 */
	public String getPolicyOwnerPartyId() {
		return policyOwnerPartyId;
	}

	/**
	 * @param policyOwnerPartyId the policyOwnerPartyId to set
	 */
	public void setPolicyOwnerPartyId(String policyOwnerPartyId) {
		this.policyOwnerPartyId = policyOwnerPartyId;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getDependentType() {
		return dependentType;
	}

	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the vip
	 */
	public String getVip() {
		return vip;
	}

	/**
	 * @param vip the vip to set
	 */
	public void setVip(String vip) {
		this.vip = vip;
	}

	public String getAgentPartyId() {
		return agentPartyId;
	}

	public void setAgentPartyId(String agentPartyId) {
		this.agentPartyId = agentPartyId;
	}

	public String getAgentWritingCode() {
		return agentWritingCode;
	}

	public void setAgentWritingCode(String agentWritingCode) {
		this.agentWritingCode = agentWritingCode;
	}

	public String getAgencyWritingCode() {
		return agencyWritingCode;
	}

	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	public String getBrokerWritingCode() {
		return brokerWritingCode;
	}

	public void setBrokerWritingCode(String brokerWritingCode) {
		this.brokerWritingCode = brokerWritingCode;
	}

	public String getPolicyIssueDate() {
		return policyIssueDate;
	}

	public void setPolicyIssueDate(String policyIssueDate) {
		this.policyIssueDate = policyIssueDate;
	}

	public String getCoPaymentPercent() {
		return coPaymentPercent;
	}

	public void setCoPaymentPercent(String coPaymentPercent) {
		this.coPaymentPercent = coPaymentPercent;
	}

	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	public String getSubmissionAgentName() {
		return submissionAgentName;
	}

	public void setSubmissionAgentName(String submissionAgentName) {
		this.submissionAgentName = submissionAgentName;
	}

	public String getSubmissionAgencyName() {
		return submissionAgencyName;
	}

	public void setSubmissionAgencyName(String submissionAgencyName) {
		this.submissionAgencyName = submissionAgencyName;
	}

	public String getSubmissionGaOfficeName() {
		return submissionGaOfficeName;
	}

	public void setSubmissionGaOfficeName(String submissionGaOfficeName) {
		this.submissionGaOfficeName = submissionGaOfficeName;
	}

	public String getSubmissionAgencyLeaderName() {
		return submissionAgencyLeaderName;
	}

	public void setSubmissionAgencyLeaderName(String submissionAgencyLeaderName) {
		this.submissionAgencyLeaderName = submissionAgencyLeaderName;
	}

	public String getWritingAgentName() {
		return writingAgentName;
	}

	public void setWritingAgentName(String writingAgentName) {
		this.writingAgentName = writingAgentName;
	}

	public String getWritingAgencyName() {
		return writingAgencyName;
	}

	public void setWritingAgencyName(String writingAgencyName) {
		this.writingAgencyName = writingAgencyName;
	}

	public String getWritingGaOfficeName() {
		return writingGaOfficeName;
	}

	public void setWritingGaOfficeName(String writingGaOfficeName) {
		this.writingGaOfficeName = writingGaOfficeName;
	}

	public String getWritingGaOfficeCode() {
		return writingGaOfficeCode;
	}

	public void setWritingGaOfficeCode(String writingGaOfficeCode) {
		this.writingGaOfficeCode = writingGaOfficeCode;
	}

	public String getWritingAgencyLeaderName() {
		return writingAgencyLeaderName;
	}

	public void setWritingAgencyLeaderName(String writingAgencyLeaderName) {
		this.writingAgencyLeaderName = writingAgencyLeaderName;
	}

	public String getSubOfficeName() {
		return subOfficeName;
	}

	public void setSubOfficeName(String subOfficeName) {
		this.subOfficeName = subOfficeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMdrt() {
		return mdrt;
	}

	public void setMdrt(String mdrt) {
		this.mdrt = mdrt;
	}

	public String getBbl() {
		return bbl;
	}

	public void setBbl(String bbl) {
		this.bbl = bbl;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((policyNo == null) ? 0 : policyNo.hashCode());
		result = prime * result + ((certNo == null) ? 0 : certNo.hashCode());
		result = prime * result + ((dependentNo == null) ? 0 : dependentNo.hashCode());
		result = prime * result + ((partyId == null) ? 0 : partyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PartySnapshot other = (PartySnapshot) obj;
		return compare(this.policyNo, other.policyNo) && compare(this.certNo, other.certNo) // 
				&& compare(this.dependentNo, other.dependentNo) && compare(this.partyId, other.partyId);

	}

	private <T> boolean compare(T o, T c) {
		if (o != null && c != null) {
			return o.equals(c);
		} else {
			return o == null && c == null;
		}
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
