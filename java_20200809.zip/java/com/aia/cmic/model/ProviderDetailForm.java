package com.aia.cmic.model;

public class ProviderDetailForm {

	private String[] codingUsed;
	private String[] serviceProvided;
	private String[] medicalSpecialty;
	private String[] awardAndAccreditation;
	private String[] otherInsuranceParticipation;
	private String[] cmacWarningCode;

	private String[] holdServices;
	private ContactForm[] contactForm;
	private int[] documentList;

	public ProviderDetailForm(ProviderForm form) {

	}

	public String[] getCodingUsed() {
		return codingUsed;
	}

	public void setCodingUsed(String[] codingUsed) {
		this.codingUsed = codingUsed;
	}

	public String[] getServiceProvided() {
		return serviceProvided;
	}

	public void setServiceProvided(String[] serviceProvided) {
		this.serviceProvided = serviceProvided;
	}

	public String[] getMedicalSpecialty() {
		return medicalSpecialty;
	}

	public void setMedicalSpecialty(String[] medicalSpecialty) {
		this.medicalSpecialty = medicalSpecialty;
	}

	public String[] getAwardAndAccreditation() {
		return awardAndAccreditation;
	}

	public void setAwardAndAccreditation(String[] awardAndAccreditation) {
		this.awardAndAccreditation = awardAndAccreditation;
	}

	public String[] getOtherInsuranceParticipation() {
		return otherInsuranceParticipation;
	}

	public void setOtherInsuranceParticipation(String[] otherInsuranceParticipation) {
		this.otherInsuranceParticipation = otherInsuranceParticipation;
	}

	public String[] getCmacWarningCode() {
		return cmacWarningCode;
	}

	public void setCmacWarningCode(String[] cmacWarningCode) {
		this.cmacWarningCode = cmacWarningCode;
	}

	public String[] getHoldServices() {
		return holdServices;
	}

	public void setHoldServices(String[] holdServices) {
		this.holdServices = holdServices;
	}

	public ContactForm[] getContactForm() {
		return contactForm;
	}

	public void setContactForm(ContactForm[] contactForm) {
		this.contactForm = contactForm;
	}

	public int[] getDocumentList() {
		return documentList;
	}

	public void setDocumentList(int[] documentList) {
		this.documentList = documentList;
	}

}
