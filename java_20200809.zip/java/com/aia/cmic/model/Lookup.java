package com.aia.cmic.model;

public class Lookup extends MasterLookup {

	public void setKey(String key) {
		this.key = key;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
