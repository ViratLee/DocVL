package com.aia.cmic.model;

import java.math.BigDecimal;

import com.aia.schemas.adam.v2_5.agreement.v1.PolicyProductPremType;

public class PolicyProductPrem {
	protected String policyProdPlanCd;
	protected String coverageCd;
	protected BigDecimal modalPremRate;
	protected BigDecimal unitPctVal;
	protected BigDecimal memberContriPct;
	protected BigDecimal memberContriAmt;
	protected String prodCd;

	public PolicyProductPrem() {
	}

	public PolicyProductPrem(PolicyProductPremType obj) {
		this.policyProdPlanCd = obj.getPolicyProdPlanCd();
		this.coverageCd = obj.getCoverageCd();
		this.modalPremRate = obj.getModalPremRate();
		this.unitPctVal = obj.getUnitPctVal();
		this.memberContriAmt = obj.getMemberContriAmt();
		this.memberContriPct = obj.getMemberContriPct();
		this.prodCd = obj.getProdCd();
	}

	public String getPolicyProdPlanCd() {
		return policyProdPlanCd;
	}

	public void setPolicyProdPlanCd(String policyProdPlanCd) {
		this.policyProdPlanCd = policyProdPlanCd;
	}

	public String getCoverageCd() {
		return coverageCd;
	}

	public void setCoverageCd(String coverageCd) {
		this.coverageCd = coverageCd;
	}

	public BigDecimal getModalPremRate() {
		return modalPremRate;
	}

	public void setModalPremRate(BigDecimal modalPremRate) {
		this.modalPremRate = modalPremRate;
	}

	public BigDecimal getUnitPctVal() {
		return unitPctVal;
	}

	public void setUnitPctVal(BigDecimal unitPctVal) {
		this.unitPctVal = unitPctVal;
	}

	public BigDecimal getMemberContriPct() {
		return memberContriPct;
	}

	public void setMemberContriPct(BigDecimal memberContriPct) {
		this.memberContriPct = memberContriPct;
	}

	public BigDecimal getMemberContriAmt() {
		return memberContriAmt;
	}

	public void setMemberContriAmt(BigDecimal memberContriAmt) {
		this.memberContriAmt = memberContriAmt;
	}

	public String getProdCd() {
		return prodCd;
	}

	public void setProdCd(String prodCd) {
		this.prodCd = prodCd;
	}

}
