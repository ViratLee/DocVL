package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class CaseValidation {
	private Long partyId;
	private String clientId;
	private String policyNo;
	private String memberId;
	private String memberLastName;
	private String memberFirstName;
	private String policyHolder;
	private String policyOwner;
	private String policyOwnerPartyId;
	private String certNo;
	private String agentWritingCode;
	private String agencyWritingCode;
	private String brokerWritingCode;
	private String dependentNo;
	private String dependentType;
	private String firstName;
	private String lastName;
	private String gender;
	private String nationalId;
	private Date dob;
	private String vip;
	private String bbl;
	private String mdrt;
	private String channel;
	private String phase;
	private String providerCode;
	private String submissionType;
	private String location;
	private Long fromCaseId;
	private Long toCaseId;
	private String businessLine;
	private String ipdOpd;
	private String subOfficeCode;

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getIpdOpd() {
		return ipdOpd;
	}

	public void setIpdOpd(String ipdOpd) {
		this.ipdOpd = ipdOpd;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public String getPolicyHolder() {
		return policyHolder;
	}

	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	public String getPolicyOwner() {
		return policyOwner;
	}

	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	public String getPolicyOwnerPartyId() {
		return policyOwnerPartyId;
	}

	public void setPolicyOwnerPartyId(String policyOwnerPartyId) {
		this.policyOwnerPartyId = policyOwnerPartyId;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getAgentWritingCode() {
		return agentWritingCode;
	}

	public void setAgentWritingCode(String agentWritingCode) {
		this.agentWritingCode = agentWritingCode;
	}

	public String getAgencyWritingCode() {
		return agencyWritingCode;
	}

	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	public String getBrokerWritingCode() {
		return brokerWritingCode;
	}

	public void setBrokerWritingCode(String brokerWritingCode) {
		this.brokerWritingCode = brokerWritingCode;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getVip() {
		return vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getFromCaseId() {
		return fromCaseId;
	}

	public void setFromCaseId(Long fromCaseId) {
		this.fromCaseId = fromCaseId;
	}

	public Long getToCaseId() {
		return toCaseId;
	}

	public void setToCaseId(Long toCaseId) {
		this.toCaseId = toCaseId;
	}

	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	public String getDependentType() {
		return dependentType;
	}

	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public String getBbl() {
		return bbl;
	}

	public void setBbl(String bbl) {
		this.bbl = bbl;
	}

	public String getMdrt() {
		return mdrt;
	}

	public void setMdrt(String mdrt) {
		this.mdrt = mdrt;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
