package com.aia.cmic.model;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;

import com.aia.cmic.entity.ICD10Code;
import com.aia.cmic.entity.ICD9Code;
import com.aia.cmic.formula.ol.ProductConfinementAdjustable;
import com.aia.cmic.services.helper.PreviousCurrentAllocationHelper;
import com.aia.cmic.util.TransactionLogUtil;
import com.aia.cmic.util.ClaimCalculationEnum.BusinessLine;

/**
 * 	CompanyId		Company Id							Claim.CompanyId
	ClaimId			Reference cliam object				Claim.ClaimId
	ClaimNo			Claim number						Claim.ClaimNo
	Occurrence		Claim occurrence					Claim.Occurrence
	BusinessLine	Business line (e.g. OL,CS,PA etc.)	ClaimPolicy.BusinessLine
	PolicyNo		Policy number						ClaimPayment.PolicyNo
	PlanId			Reference plan object				ClaimPayment.PlanId
	PlanCoverageId	Plan coverage number 				ClaimPayment.PlanCoverageId
	PlanName		Plan name							ClaimPayment.PlanName
	ProductType		Product Type (e.g. AI, HS, PA)		Product.ProductType
	ProductCode		Product Code (e.g. HSN7)			ClaimPolicy.ProductCode
	BenefitCode		Benefit code (e.g. H01, H04, etc.)	StandBilling.BenefitCode
	ProcedureCategory	Procedure category 				ClaimCanonical.ClaimProcedureCode.Value
	FullCreditInd	Full credit indicator (Y or N)		ClaimPolicy. FullCreditInd
	SeqId			Allocation Sequence number			0
	ServiceCatId	Service category Id 				ClaimBenefitItem.ServiceCatId
	TreatmentType	Treatment type (IPD / OPD / Day Case)	VARCHAR2	10	Claim.TreatmentType
	PresentAmt		Presented amount					ClaimBenefitItem.PresentAmt
	PresentedDiscountAmt	Presented discount amount	ClaimBenefitItem.PresentedDiscountAmt
	PresentedDays	No of days presented				ClaimBenefitItem.NoOfDaysPresented
	PresentedPercentage	Presented percentage			ClaimBenefitItem.PresentedPercentage
	PresentedUnit	No of unit presented				ClaimBenefitItem.NoOfUnit
	LengthOfStay	Length of stay						Claim.LengthOfStay
	EligibleAmt		Eligible amount						0
	ReimbursedDay	No of days reimbursed (for CS)		0
	ReimbursedCall	No of call reimbursed (for CS, normally 1)	0
	PercentageAllocated	Percentage settled				0
	ShortfallAmt	Shortfall amount					0
	AccumulatorNo	Accumulator No						Blank
	BusineeLineAllocSeq	Sorting seq filed 1				Blank
	PlanProductAllocSeq	Sorting seq filed 2				Blank
	RolloverGroupNo	Sorting seq filed 3					Blank
	BenCodeAllocSequence	Sorting seq filed 3			Blank


 * @author Ronald
 *
 */
public class PaymentAllocationTemp extends EligibleClaim implements Comparable<PaymentAllocationTemp> {
	private Long claimId;
	private ICD9Code icd9category;
	private String benefitCode;
	private Integer seqId;
	private Integer grpAllocSeq;
	private String icd10Category;
	private String treatmentType;
	private String serviceCatId;
	private BigDecimal presentedDiscountAmt;
	private BigDecimal presentedPercentage;
	private Integer presentedNofOfUnit;
	private Integer lengthOfStay;
	private BigDecimal presentedAmt = BigDecimal.ZERO;
	private BigDecimal eligibleAmt = BigDecimal.ZERO;
	private Integer allocatedDay = 0;
	private Integer reimbursedDay = 0;
	private Integer reimbusrsedCall = 0;
	private BigDecimal percentageAllocated;
	private Integer presentedNosOfDays;
	private BigDecimal valuePerUnit;
	private Date planIssueDt;
	private Integer allocateSeqId;
	private String dependentType;

	private BigDecimal excessAmount = BigDecimal.ZERO;
	private BigDecimal shortFallAmount = BigDecimal.ZERO;
	private String[] accumulatorNo = null;
	private Integer businessAllocSeq = 0;
	private Integer planProductAllocSeq = 0;
	private Integer benefitCodeAllocSeq = 9999;
	private String lifeProductCode;
	private Boolean h13HasExcessAmt = false ;
	private String currentClaimBenefitItemKey;

	private String rollOverGroupNo = "";
	// Supporting objects
	private List<PaymentAllocationTemp> rollOverGroupRefList;
	private PreviousClaimPaymentAllocation previousAllocation;
	private PreviousCurrentAllocationHelper previousAllocationHelper;
	private ProductConfinementAdjustable productSpecificConfinementAdjuster;
	private Logger calculationLogger;
	private Long claimBenefitItemId;
	private PaymentAllocationTemp rollOverHead = null;
	private Map<String,Map<String,List<PaymentAllocationTemp>>> serviceRollOverMap ;
	private Map<String, ICD10Code> icd10CodeMap ;
	private Integer rollOverBenefitIndex =0 ;
	private Boolean quotation = false;
	private Boolean limitReached = false;
	Set<String> productCountSet = new HashSet<String>();
	
	private BigDecimal origHNWEligibleAmt = BigDecimal.ZERO;
	/**
	 * @return the quotation
	 */
	public Boolean isQuotation() {
		return quotation;
	}

	/**
	 * @param quotation the quotation to set
	 */
	public void setQuotation(Boolean quotation) {
		this.quotation = quotation;
	}

	// TransactionLog
	private List<TransactionLogUtil.TransactionLogInfo> transLogList = new ArrayList<TransactionLogUtil.TransactionLogInfo>();
	
	public PaymentAllocationTemp(EligibleClaim eligbleClaim) {
		super(eligbleClaim.getClaimNo(), eligbleClaim.getCompanyId(), eligbleClaim.getOccurence(), eligbleClaim.getPolicyNo(), eligbleClaim.getBusinessLine(), eligbleClaim.getProductCode(),
				eligbleClaim.getFullCreditInd(), eligbleClaim.getCsProductCategory(), eligbleClaim.getPlanId(), eligbleClaim.getPlanCoverageNo(), eligbleClaim.getProductType(),
				eligbleClaim.getPaBonusAmt(), eligbleClaim.getPaBonusDt(),eligbleClaim.getCsProductCode(),eligbleClaim.getPlanName(),eligbleClaim.getPolicyIssueDt(), eligbleClaim.getPlanCode(), eligbleClaim.getClaimPaymentId());
	}

	/**
	 * @return the claimId
	 */
	public Long getClaimId() {
		return claimId;
	}

	/**
	 * @param claimId the claimId to set
	 */
	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	/**
	 * @return the icd9category
	 */
	public ICD9Code getIcd9category() {
		return icd9category;
	}

	/**
	 * @param icd9category the icd9category to set
	 */
	public void setIcd9category(ICD9Code icd9category) {
		this.icd9category = icd9category;
	}

	/**
	 * @return the seqId
	 */
	public Integer getSeqId() {
		return seqId;
	}

	/**
	 * @param seqId the seqId to set
	 */
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}

	/**
	 * @return the grpAllocSeq
	 */
	public Integer getGrpAllocSeq() {
		return grpAllocSeq;
	}

	/**
	 * @param grpAllocSeq the grpAllocSeq to set
	 */
	public void setGrpAllocSeq(Integer grpAllocSeq) {
		this.grpAllocSeq = grpAllocSeq;
	}

	/**
	 * @return the icd10Category
	 */
	public String getIcd10Category() {
		return icd10Category;
	}

	/**
	 * @param icd10Category the icd10Category to set
	 */
	public void setIcd10Category(String icd10Category) {
		this.icd10Category = icd10Category;
	}

	/**
	 * @return the treatmentType
	 */
	public String getTreatmentType() {
		return treatmentType;
	}

	/**
	 * @param treatmentType the treatmentType to set
	 */
	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	/**
	* @return the presentedDiscountAmt
	*/
	public BigDecimal getPresentedDiscountAmt() {
		return presentedDiscountAmt;
	}

	/**
	 * @param presentedDiscountAmt the presentedDiscountAmt to set
	 */
	public void setPresentedDiscountAmt(BigDecimal presentedDiscountAmt) {
		this.presentedDiscountAmt = presentedDiscountAmt;
	}

	/**
	 * @return the presentedPercentage
	 */
	public BigDecimal getPresentedPercentage() {
		return presentedPercentage == null ? BigDecimal.ZERO : presentedPercentage;
	}

	/**
	 * @param presentedPercentage the presentedPercentage to set
	 */
	public void setPresentedPercentage(BigDecimal presentedPercentage) {
		this.presentedPercentage = presentedPercentage;
	}

	/**
	 * @return the presentedNofOfUnit
	 */
	public Integer getPresentedNofOfUnit() {
		return presentedNofOfUnit;
	}

	/**
	 * @param presentedNofOfUnit the presentedNofOfUnit to set
	 */
	public void setPresentedNofOfUnit(Integer presentedNofOfUnit) {
		this.presentedNofOfUnit = presentedNofOfUnit;
	}

	/**
	 * @return the lengthOfStay
	 */
	public Integer getLengthOfStay() {
		return lengthOfStay;
	}

	/**
	 * @param lengthOfStay the lengthOfStay to set
	 */
	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 * @return the eligibleAmt
	 */
	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	/**
	 * @param eligibleAmt the eligibleAmt to set
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 * @return the reimbursedDay
	 */
	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	/**
	 * @param reimbursedDay the reimbursedDay to set
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	/**
	 * @return the reimbusrsedCall
	 */
	public Integer getReimbusrsedCall() {
		return reimbusrsedCall;
	}

	/**
	 * @param reimbusrsedCall the reimbusrsedCall to set
	 */
	public void setReimbusrsedCall(Integer reimbusrsedCall) {
		this.reimbusrsedCall = reimbusrsedCall;
	}

	/**
	 * @return the percentageAllocated
	 */
	public BigDecimal getPercentageAllocated() {
		return percentageAllocated == null ? BigDecimal.ZERO : percentageAllocated;
	}

	/**
	 * @param percentageAllocated the percentageAllocated to set
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 * @return the shortfallAmt
	 */
	public BigDecimal getExcessAmt() {
		return excessAmount;
	}

	/**
	 * @param shortfallAmt the shortfallAmt to set
	 */
	public void setExcessAmt(BigDecimal shortfallAmt) {
		this.excessAmount = shortfallAmt;
	}

	/**
	 * @return the accumulatorNo
	 */
	public String[] getAccumulatorNo() {
		return accumulatorNo;
	}

	/**
	 * @param accumulatorNo the accumulatorNo to set
	 */
	public void setAccumulatorNo(String[] accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	/**
	 * @return the businessAllocSeq
	 */
	public Integer getBusinessAllocSeq() {
		return businessAllocSeq;
	}

	/**
	 * @param businessAllocSeq the businessAllocSeq to set
	 */
	public void setBusinessAllocSeq(Integer businessAllocSeq) {
		this.businessAllocSeq = businessAllocSeq;
	}

	/**
	 * @return the planProductAllocSeq
	 */
	public Integer getPlanProductAllocSeq() {
		return planProductAllocSeq;
	}

	/**
	 * @param planProductAllocSeq the planProductAllocSeq to set
	 */
	public void setPlanProductAllocSeq(Integer planProductAllocSeq) {
		this.planProductAllocSeq = planProductAllocSeq;
	}

	/**
	 * @return the rollOverGroupNo
	 */
	public String getRollOverGroupNo() {
		return rollOverGroupNo;
	}

	/**
	 * @param rollOverGroupNo the rollOverGroupNo to set
	 */
	public void setRollOverGroupNo(String rollOverGroupNo) {
		this.rollOverGroupNo = rollOverGroupNo;
	}

	/**
	 * @return the benefitCodeAllocSeq
	 */
	public Integer getBenefitCodeAllocSeq() {
		return benefitCodeAllocSeq;
	}

	/**
	 * @param benefitCodeAllocSeq the benefitCodeAllocSeq to set
	 */
	public void setBenefitCodeAllocSeq(Integer benefitCodeAllocSeq) {
		this.benefitCodeAllocSeq = benefitCodeAllocSeq;
	}

	public static class ServiceCategoryIdComparator implements Comparator<PaymentAllocationTemp> {
		@Override
		public int compare(PaymentAllocationTemp pat1, PaymentAllocationTemp pat2) {
			int comparison = pat1.getBusinessAllocSeq().compareTo(pat2.getBusinessAllocSeq());
			if (comparison == 0) {
				// PlanProductAllocSeq
				comparison = pat1.getPlanProductAllocSeq().compareTo(pat2.getPlanProductAllocSeq());
				if (comparison == 0) {
					comparison = pat1.getBenefitCodeAllocSeq().compareTo(pat2.getBenefitCodeAllocSeq());
				}
			}
			return comparison;
		}

	}

	public static class ServiceCategoryIdComparator2 implements Comparator<PaymentAllocationTemp> {
		@Override
		public int compare(PaymentAllocationTemp pat1, PaymentAllocationTemp pat2) {
			int comparison = pat1.getServiceCatId().compareTo(pat2.getServiceCatId());
			return comparison;
		}

	}

	/**
	 * Check if need sorting by ServiceCatId is still needed.
	 * @param sortedList
	 * @return
	 */
	public static boolean needToSortByServiceCatId(List<PaymentAllocationTemp> sortedList) {
		int index = 0;
		for (PaymentAllocationTemp paymentAllocationTemp : sortedList) {
			PaymentAllocationTemp next = (index + 1) < sortedList.size() ? sortedList.get(index + 1) : null;
			if (next != null) {
				if (paymentAllocationTemp.compareTo(next) != 0) {
					return false;
				}
			}
			index++;
		}
		return true;
	}

	@Override
	public int compareTo(PaymentAllocationTemp paymentAllocationTemp) {

		/*
		 * BussineLineAllocSequence, PlanProductAllocSeq, IssueDt desc, PolicyNo desc, RolloverGroupNo, BenefitCodeAllocSeq.
		 */
		// go on With BussineLineAllocSequence
		int comparison = this.getBusinessAllocSeq().compareTo(paymentAllocationTemp.getBusinessAllocSeq());
		if (comparison == 0) {
			// go on with PlanProductAllocSeq
			comparison = this.getPlanProductAllocSeq().compareTo(paymentAllocationTemp.getPlanProductAllocSeq());
			if (comparison == 0) {
				// CS
				if(BusinessLine.CS.toString().equals(this.getBusinessLine()) && BusinessLine.CS.toString().equals(paymentAllocationTemp.getBusinessLine())) {
					comparison = this.getBenefitCodeAllocSeq().compareTo(paymentAllocationTemp.getBenefitCodeAllocSeq());
					if(comparison == 0) {
						return this.getRollOverBenefitIndex().compareTo(paymentAllocationTemp.getRollOverBenefitIndex()) ;
					}
					return comparison ;
				}

				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				// GPSE
				if(BusinessLine.GE.toString().equals(this.getBusinessLine()) && BusinessLine.GE.toString().equals(paymentAllocationTemp.getBusinessLine())) {
					// policy issue date
					comparison = sdf.format(this.getPolicyIssueDt()).compareTo(sdf.format(paymentAllocationTemp.getPolicyIssueDt())) * -1 ;
					if(comparison == 0) {
						return this.getBenefitCodeAllocSeq().compareTo(paymentAllocationTemp.getBenefitCodeAllocSeq());
					}
					return comparison ;
				}
				// OL/PA
				// go on with IssueDt
				comparison = sdf.format(this.getPlanIssueDt()).compareTo(sdf.format(paymentAllocationTemp.getPlanIssueDt()));
				if (comparison == 0) {
					// go on with policyNo
					comparison = this.getPolicyNo().compareTo(paymentAllocationTemp.getPolicyNo());
					if (comparison == 0) {
						/*RollOverGroupNo is not included in the sorting anymore */
						// go on with RolloverGroupNo
						//comparison = this.getRollOverGroupNo().compareTo(paymentAllocationTemp.getRollOverGroupNo());
						//if (comparison == 0) {
							// go on with BenefitCodeAllocSeq
							return this.getBenefitCodeAllocSeq().compareTo(paymentAllocationTemp.getBenefitCodeAllocSeq());
						//}
						//return comparison;
					}
					return comparison * -1;//  PolicyNo desc
				}
				return comparison * -1; // IssueDt desc
			}
		}
		return comparison;
	}

	/**
	 * @return the rollOverGroupRefList
	 */
	public List<PaymentAllocationTemp> getRollOverGroupRefList() {
		return rollOverGroupRefList;
	}

	/**
	 * @param rollOverGroupRefList the rollOverGroupRefList to set
	 */
	public void setRollOverGroupRefList(List<PaymentAllocationTemp> rollOverGroupRefList) {
		this.rollOverGroupRefList = rollOverGroupRefList;
	}

	/**
	 * @return the benefitCode
	 */
	public String getBenefitCode() {
		return benefitCode;
	}

	/**
	 * @param benefitCode the benefitCode to set
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 * @return the previousAllocation
	 */
	public PreviousClaimPaymentAllocation getPreviousAllocation() {
		if (previousAllocation == null) {
			return new PreviousClaimPaymentAllocation();
		}
		return previousAllocation;
	}

	/**
	 * @param previousAllocation the previousAllocation to set
	 */
	public void setPreviousAllocation(PreviousClaimPaymentAllocation previousAllocation) {
		this.previousAllocation = previousAllocation;
	}

	public void copy(PaymentAllocationTemp that) {

		setClaimId(that.getClaimId());
		setCompanyId(that.getCompanyId());
		setClaimNo(that.getClaimNo());
		setOccurence(that.getOccurence());
		setIcd9category(that.getIcd9category());
		setBenefitCode(that.getBenefitCode());
		setFullCreditInd(that.getFullCreditInd());
		setIcd10Category(that.getIcd10Category());
		setTreatmentType(that.getTreatmentType());
		setPresentedAmt(that.getPresentedAmt());
		setPresentedDiscountAmt(that.getPresentedDiscountAmt());
		setPresentedPercentage(that.getPresentedPercentage());
		setPresentedNofOfUnit(that.getPresentedNofOfUnit());
		setLengthOfStay(that.getLengthOfStay());
		setEligibleAmt(that.getEligibleAmt());
		setReimbursedDay(that.getReimbursedDay());
		setReimbusrsedCall(that.getReimbusrsedCall());
		setPercentageAllocated(that.getPercentageAllocated());
		setExcessAmt(that.getExcessAmt());
		setAccumulatorNo(that.getAccumulatorNo());
		setServiceCatId(that.getServiceCatId());
		setValuePerUnit(that.getValuePerUnit());
		setPlanIssueDt(that.getPlanIssueDt());
		setPlanName(that.getPlanName());

		setProductType(that.getProductType());
		setPolicyNo(that.getPolicyNo());
		setBusinessLine(that.getBusinessLine());
		setProductCode(that.getProductCode());
		setFullCreditInd(that.getFullCreditInd());
		setPlanId(that.getPlanId());
		setPlanCoverageNo(that.getPlanCoverageNo());
		setDependentType(that.getDependentType());

		// PA Bonus
		setPaBonusAmt(that.getPaBonusAmt());
		setPaBonusDt(that.getPaBonusDt());

		// logger
		setCalculationLogger(that.getCalculationLogger());
		
		// claimbenefititemid
		setClaimBenefitItemId(that.getClaimBenefitItemId());
		// rollOverHead
		setRollOverHead(that.getRollOverHead());
		setQuotation(that.isQuotation());
		
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return serviceCatId;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the presentedNosOfDays
	 */
	public Integer getPresentedNosOfDays() {
		return presentedNosOfDays;
	}

	/**
	 * @param presentedNosOfDays the presentedNosOfDays to set
	 */
	public void setPresentedNosOfDays(Integer presentedNosOfDays) {
		this.presentedNosOfDays = presentedNosOfDays;
	}

	/**
	 * @return the previousAllocationHelper
	 */
	public PreviousCurrentAllocationHelper getPreviousCurrentAllocationHelper() {
		return previousAllocationHelper;
	}

	/**
	 * @param previousAllocationHelper the previousAllocationHelper to set
	 */
	public void setPreviousAllocationHelper(PreviousCurrentAllocationHelper previousAllocationHelper) {
		this.previousAllocationHelper = previousAllocationHelper;
	}

	/**
	 * @return the valuePerUnit
	 */
	public BigDecimal getValuePerUnit() {
		return valuePerUnit;
	}

	/**
	 * @param valuePerUnit the valuePerUnit to set
	 */
	public void setValuePerUnit(BigDecimal valuePerUnit) {
		this.valuePerUnit = valuePerUnit;
	}

	/**
	 * @return the allocatedDay
	 */
	public Integer getAllocatedDay() {
		return allocatedDay;
	}

	/**
	 * @param allocatedDay the allocatedDay to set
	 */
	public void setAllocatedDay(Integer allocatedDay) {
		this.allocatedDay = allocatedDay;
	}

	/**
	 * @return the planIssueDt
	 */
	public Date getPlanIssueDt() {
		return planIssueDt;
	}

	/**
	 * @param planIssueDt the planIssueDt to set
	 */
	public void setPlanIssueDt(Date planIssueDt) {
		this.planIssueDt = planIssueDt;
	}

	/**
	 * @return the productSpecificConfinementAdjuster
	 */
	public ProductConfinementAdjustable getProductSpecificConfinementAdjuster() {
		return productSpecificConfinementAdjuster;
	}

	/**
	 * @param productSpecificConfinementAdjuster the productSpecificConfinementAdjuster to set
	 */
	public void setProductSpecificConfinementAdjuster(ProductConfinementAdjustable productSpecificConfinementAdjuster) {
		this.productSpecificConfinementAdjuster = productSpecificConfinementAdjuster;
	}

	/**
	 * @return the allocateSeqId
	 */
	public Integer getAllocateSeqId() {
		return allocateSeqId;
	}

	/**
	 * @param allocateSeqId the allocateSeqId to set
	 */
	public void setAllocateSeqId(Integer allocateSeqId) {
		this.allocateSeqId = allocateSeqId;
	}

	/**
	 * @return the dependentType
	 */
	public String getDependentType() {
		return dependentType;
	}

	/**
	 * @param dependentType the dependentType to set
	 */
	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	/**
	 * @return the calculationLogger
	 */
	public Logger getCalculationLogger() {
		return calculationLogger;
	}

	public String getLifeProductCode() {
		return lifeProductCode;
	}

	public void setLifeProductCode(String lifeProductCode) {
		this.lifeProductCode = lifeProductCode;
	}

	/**
	 * @param calculationLogger the calculationLogger to set
	 */
	public void setCalculationLogger(Logger calculationLogger) {
		this.calculationLogger = calculationLogger;
	}

	public Boolean isCalculationLoggerEnabled() {
		return calculationLogger != null ? true : false;
	}

	/**
	 * @return the h13HasExcessAmt
	 */
	public Boolean isH13HasExcessAmt() {
		return h13HasExcessAmt;
	}

	public void setH13HasExcessAmt(Boolean flag) {
		h13HasExcessAmt=flag ;
	}

	/**
	 * @return the claimBenefitItemId
	 */
	public Long getClaimBenefitItemId() {
		return claimBenefitItemId;
	}

	/**
	 * @param claimBenefitItemId the claimBenefitItemId to set
	 */
	public void setClaimBenefitItemId(Long claimBenefitItemId) {
		this.claimBenefitItemId = claimBenefitItemId;
	}

	/**
	 * @return the rollOverHead
	 */
	public PaymentAllocationTemp getRollOverHead() {
		return rollOverHead;
	}

	/**
	 * @param rollOverHead the rollOverHead to set
	 */
	public void setRollOverHead(PaymentAllocationTemp rollOverHead) {
		this.rollOverHead = rollOverHead;
	}

	/**
	 * @return the serviceRollOverMap
	 */
	public Map<String,Map<String,List<PaymentAllocationTemp>>> getServiceRollOverMap() {
		return serviceRollOverMap;
	}

	/**
	 * @param serviceRollOverMap the serviceRollOverMap to set
	 */
	public void setServiceRollOverMap(Map<String,Map<String,List<PaymentAllocationTemp>>> serviceRollOverMap) {
		this.serviceRollOverMap = serviceRollOverMap;
	}

	/**
	 * @return the icd10CodeMap
	 */
	public Map<String, ICD10Code> getIcd10CodeMap() {
		return icd10CodeMap;
	}

	/**
	 * @param icd10CodeMap the icd10CodeMap to set
	 */
	public void setIcd10CodeMap(Map<String, ICD10Code> icd10CodeMap) {
		this.icd10CodeMap = icd10CodeMap;
	}

	/**
	 * @return the currentClaimBenefitItemKey
	 */
	public String getCurrentClaimBenefitItemKey() {
		return currentClaimBenefitItemKey;
	}

	/**
	 * @param currentClaimBenefitItemKey the currentClaimBenefitItemKey to set
	 */
	public void setCurrentClaimBenefitItemKey(String currentClaimBenefitItemKey) {
		this.currentClaimBenefitItemKey = currentClaimBenefitItemKey;
	}

	public BigDecimal getShortFallAmount() {
		return shortFallAmount;
	}

	public void setShortFallAmount(BigDecimal shortFallAmount) {
		this.shortFallAmount = shortFallAmount;
	}

	/**
	 * @return the transLogList
	 */
	public List<TransactionLogUtil.TransactionLogInfo> getTransLogList() {
		return transLogList;
	}

	/**
	 * @param transLogList the transLogList to set
	 */
	public void setTransLogList(List<TransactionLogUtil.TransactionLogInfo> transLogList) {
		this.transLogList = transLogList;
	}

	/**
	 * @return the rollOverBenefitIndex
	 */
	public Integer getRollOverBenefitIndex() {
		return rollOverBenefitIndex;
	}

	/**
	 * @param rollOverBenefitIndex the rollOverBenefitIndex to set
	 */
	public void setRollOverBenefitIndex(Integer rollOverBenefitIndex) {
		this.rollOverBenefitIndex = rollOverBenefitIndex;
	}
	
	public String getClaimNoForLogging() {
		if(isQuotation()) {
			return "Q" + getClaimNo().substring(1);
		}
		return getClaimNo();
	}

	/**
	 * @return the limitReached
	 */
	public Boolean isLimitReached() {
		return limitReached;
	}

	/**
	 * @param limitReached the limitReached to set
	 */
	public void setLimitReached(Boolean limitReached) {
		this.limitReached = limitReached;
	}
	
	public Set<String> getProductCountSet() {
		return productCountSet;
	}

	public void setProductCountSet(Set<String> productCountSet) {
		this.productCountSet = productCountSet;
	}

	/**
	 * @return the origHNWEligibleAmt
	 */
	public BigDecimal getOrigHNWEligibleAmt() {
		return origHNWEligibleAmt;
	}

	/**
	 * @param origHNWEligibleAmt the origHNWEligibleAmt to set
	 */
	public void setOrigHNWEligibleAmt(BigDecimal origHNWEligibleAmt) {
		this.origHNWEligibleAmt = origHNWEligibleAmt;
	}
	

//	public List<TransactionLogUtil.TransactionLogInfo> getTransactionlogs() {
//		return transactionlogs;
//	}
//
//	public void setTransactionlogs(List<TransactionLogUtil.TransactionLogInfo> transactionlogs) {
//		this.transactionlogs = transactionlogs;
//	}

	public Boolean isPlanHNWDeduct() {
		return Arrays.asList("990D07","990E07").contains(getPlanCode()) ;
	}
}
