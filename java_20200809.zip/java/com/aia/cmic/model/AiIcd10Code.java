package com.aia.cmic.model;

public class AiIcd10Code {
	private Integer AGEFROM;
	private Integer AGETO;
	private String GENDER;
	private String ICD10CATEGORY;
	private String ICD10CODE;
	private String ICDSUBCODE;
	private String SUBCODEDESC;
	private String SUSPECTPREEXISTCONDITION;
	private Integer WAITINGPERIOD;
	public Integer getAGEFROM() {
		return AGEFROM;
	}
	public void setAGEFROM(Integer aGEFROM) {
		AGEFROM = aGEFROM;
	}
	public Integer getAGETO() {
		return AGETO;
	}
	public void setAGETO(Integer aGETO) {
		AGETO = aGETO;
	}
	public String getGENDER() {
		return GENDER;
	}
	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}
	public String getICD10CATEGORY() {
		return ICD10CATEGORY;
	}
	public void setICD10CATEGORY(String iCD10CATEGORY) {
		ICD10CATEGORY = iCD10CATEGORY;
	}
	public String getICD10CODE() {
		return ICD10CODE;
	}
	public void setICD10CODE(String iCD10CODE) {
		ICD10CODE = iCD10CODE;
	}
	public String getICDSUBCODE() {
		return ICDSUBCODE;
	}
	public void setICDSUBCODE(String iCDSUBCODE) {
		ICDSUBCODE = iCDSUBCODE;
	}
	public String getSUBCODEDESC() {
		return SUBCODEDESC;
	}
	public void setSUBCODEDESC(String sUBCODEDESC) {
		SUBCODEDESC = sUBCODEDESC;
	}
	public String getSUSPECTPREEXISTCONDITION() {
		return SUSPECTPREEXISTCONDITION;
	}
	public void setSUSPECTPREEXISTCONDITION(String sUSPECTPREEXISTCONDITION) {
		SUSPECTPREEXISTCONDITION = sUSPECTPREEXISTCONDITION;
	}
	public Integer getWAITINGPERIOD() {
		return WAITINGPERIOD;
	}
	public void setWAITINGPERIOD(Integer wAITINGPERIOD) {
		WAITINGPERIOD = wAITINGPERIOD;
	}
	
	
}
