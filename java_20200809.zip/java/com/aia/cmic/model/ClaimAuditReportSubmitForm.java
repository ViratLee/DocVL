package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClaimAuditReportSubmitForm {

	private static final Logger LOG = LoggerFactory.getLogger(ClaimAuditReportSubmitForm.class);

	private List<String> claimNo;
	private List<Integer> occurrence;
	private List<String> policyNo;
	private List<Integer> planId;
	private List<String> ruleNo;
	private List<String> markingId;
	private List<String> markingReason;

	public List<String> getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(List<String> claimNo) {
		this.claimNo = claimNo;
	}

	public List<Integer> getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(List<Integer> occurrence) {
		this.occurrence = occurrence;
	}

	public List<String> getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(List<String> policyNo) {
		this.policyNo = policyNo;
	}

	public List<Integer> getPlanId() {
		return planId;
	}

	public void setPlanId(List<Integer> planId) {
		this.planId = planId;
	}

	public List<String> getRuleNo() {
		return ruleNo;
	}

	public void setRuleNo(List<String> ruleNo) {
		this.ruleNo = ruleNo;
	}

	public List<String> getMarkingId() {
		return markingId;
	}

	public void setMarkingId(List<String> markingId) {
		this.markingId = markingId;
	}

	public List<String> getMarkingReason() {
		return markingReason;
	}

	public void setMarkingReason(List<String> markingReason) {
		this.markingReason = markingReason;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
