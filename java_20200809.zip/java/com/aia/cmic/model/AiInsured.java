package com.aia.cmic.model;

public class AiInsured {

	private String BLACKLISTIND;
	private String CLAIMNO;
	private Integer OCCURRENCE;
	private String WATCHLISTIND;
	public String getBLACKLISTIND() {
		return BLACKLISTIND;
	}
	public void setBLACKLISTIND(String bLACKLISTIND) {
		BLACKLISTIND = bLACKLISTIND;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getWATCHLISTIND() {
		return WATCHLISTIND;
	}
	public void setWATCHLISTIND(String wATCHLISTIND) {
		WATCHLISTIND = wATCHLISTIND;
	}
	
}
