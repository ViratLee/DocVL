package com.aia.cmic.model;

import java.math.BigDecimal;

public class ClaimBenefitItem {

	Long claimBenefitItemId;
	String claimNo;
	Integer occurrence;
	String serviceCatId;
	String companyId;
	BigDecimal presentedAmt;
	BigDecimal presentedDiscountAmt;
	BigDecimal presentedPercentage;
	Integer noOfDaysPresented;
	Integer noOfUnit;
	BigDecimal valuePerUnit;
	String benefitCode;
	BigDecimal eligibleAmt;
	BigDecimal shortfallAmt;
	String benefitPlanCode;
	String remark; // used for settlementDetailODS

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getBenefitPlanCode() {
		return benefitPlanCode;
	}

	public void setBenefitPlanCode(String benefitPlanCode) {
		this.benefitPlanCode = benefitPlanCode;
	}

	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	public BigDecimal getShortfallAmt() {
		return shortfallAmt;
	}

	public void setShortfallAmt(BigDecimal shortfallAmt) {
		this.shortfallAmt = shortfallAmt;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 * @return the claimBenefitItemId
	 */
	public Long getClaimBenefitItemId() {
		return claimBenefitItemId;
	}

	/**
	 * @param claimBenefitItemId the claimBenefitItemId to set
	 */
	public void setClaimBenefitItemId(Long claimBenefitItemId) {
		this.claimBenefitItemId = claimBenefitItemId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return serviceCatId;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the presentedAmt
	 */
	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	/**
	 * @param presentedAmt the presentedAmt to set
	 */
	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 * @return the presentedDiscountAmt
	 */
	public BigDecimal getPresentedDiscountAmt() {
		return presentedDiscountAmt;
	}

	/**
	 * @param presentedDiscountAmt the presentedDiscountAmt to set
	 */
	public void setPresentedDiscountAmt(BigDecimal presentedDiscountAmt) {
		this.presentedDiscountAmt = presentedDiscountAmt;
	}

	/**
	 * @return the presentedPercentage
	 */
	public BigDecimal getPresentedPercentage() {
		return presentedPercentage;
	}

	/**
	 * @param presentedPercentage the presentedPercentage to set
	 */
	public void setPresentedPercentage(BigDecimal presentedPercentage) {
		this.presentedPercentage = presentedPercentage;
	}

	/**
	 * @return the noOfDaysPresented
	 */
	public Integer getNoOfDaysPresented() {
		return noOfDaysPresented;
	}

	/**
	 * @param noOfDaysPresented the noOfDaysPresented to set
	 */
	public void setNoOfDaysPresented(Integer noOfDaysPresented) {
		this.noOfDaysPresented = noOfDaysPresented;
	}

	/**
	 * @return the noOfUnit
	 */
	public Integer getNoOfUnit() {
		return noOfUnit;
	}

	/**
	 * @param noOfUnit the noOfUnit to set
	 */
	public void setNoOfUnit(Integer noOfUnit) {
		this.noOfUnit = noOfUnit;
	}

	/**
	 * @return the valuePerUnit
	 */
	public BigDecimal getValuePerUnit() {
		return valuePerUnit;
	}

	/**
	 * @param valuePerUnit the valuePerUnit to set
	 */
	public void setValuePerUnit(BigDecimal valuePerUnit) {
		this.valuePerUnit = valuePerUnit;
	}

	public void copy(ClaimBenefitItem benefitItem) {
		claimBenefitItemId = benefitItem.claimBenefitItemId;
		claimNo = benefitItem.claimNo;
		occurrence = benefitItem.occurrence;
		serviceCatId = benefitItem.serviceCatId;
		companyId = benefitItem.companyId;
		presentedAmt = benefitItem.presentedAmt;
		presentedDiscountAmt = benefitItem.presentedDiscountAmt;
		presentedPercentage = benefitItem.presentedPercentage;
		noOfDaysPresented = benefitItem.noOfDaysPresented;
		noOfUnit = benefitItem.noOfUnit;
		valuePerUnit = benefitItem.valuePerUnit;

	}

}
