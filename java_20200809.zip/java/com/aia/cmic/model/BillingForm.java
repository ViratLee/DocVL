package com.aia.cmic.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BillingForm {
	private static final Logger LOG = LoggerFactory.getLogger(BillingForm.class);

	private String claimId;
	private String claimNo;
	private String decision;
	private String reason;
	private String icd10;
	private String aiBillingStatus;

	public static Logger getLog() {
		return LOG;
	}

	public String getClaimId() {
		return claimId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public String getDecision() {
		return decision;
	}

	public String getReason() {
		return reason;
	}

	public String getIcd10() {
		return icd10;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public void setIcd10(String icd10) {
		this.icd10 = icd10;
	}

	public String getAiBillingStatus() {
		return aiBillingStatus;
	}

	public void setAiBillingStatus(String aiBillingStatus) {
		this.aiBillingStatus = aiBillingStatus;
	}
	
	

}
