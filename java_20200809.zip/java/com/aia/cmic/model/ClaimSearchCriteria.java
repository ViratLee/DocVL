package com.aia.cmic.model;

import java.util.Date;

/**
 * @author dino
 * @version 1.0 Sep 7, 2016
 */
public class ClaimSearchCriteria {
    private String companyId;
    private String claimNo;
    private Date receivedDateFrom;
    private Date receivedDateTo;
    private String partyId;
    private byte[] firstName;
    private byte[] lastName;
    private String policyNo;
    private String certNo;
    private String fomStatus;
    private String toStatus;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyID) {
        this.companyId = companyID;
    }

    public String getClaimNo() {
        return claimNo;
    }

    public void setClaimNo(String claimNo) {
        this.claimNo = claimNo;
    }

    public Date getReceivedDateFrom() {
        return receivedDateFrom;
    }

    public void setReceivedDateFrom(Date receivedDateFrom) {
        this.receivedDateFrom = receivedDateFrom;
    }

    public Date getReceivedDateTo() {
        return receivedDateTo;
    }

    public void setReceivedDateTo(Date receivedDateTo) {
        this.receivedDateTo = receivedDateTo;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }
    public byte[] getFirstName() {
        return firstName;
    }

    public void setFirstName(byte[] firstName) {
        this.firstName = firstName;
    }

    public byte[] getLastName() {
        return lastName;
    }

    public void setLastName(byte[] lastName) {
        this.lastName = lastName;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    public String getFomStatus() {
        return fomStatus;
    }

    public void setFomStatus(String fomStatus) {
        this.fomStatus = fomStatus;
    }

    public String getToStatus() {
        return toStatus;
    }

    public void setToStatus(String toStatus) {
        this.toStatus = toStatus;
    }
}
