package com.aia.cmic.model;

import java.util.Date;

public class PolicySearchCriteria {
	private String agency;
	private Date issuedDateFrom;
	private Date issuedDateTo;

	public String getAgency() {
		return agency;
	}

	public void setAgency(String agency) {
		this.agency = agency;
	}

	public Date getIssuedDateFrom() {
		return issuedDateFrom;
	}

	public void setIssuedDateFrom(Date issuedDateFrom) {
		this.issuedDateFrom = issuedDateFrom;
	}

	public Date getIssuedDateTo() {
		return issuedDateTo;
	}

	public void setIssuedDateTo(Date issuedDateTo) {
		this.issuedDateTo = issuedDateTo;
	}
}
