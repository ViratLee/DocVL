package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ProviderContact;

public class ProviderContactDetailForm {

	//General Information
	private List<Long> providerContactId;
	private String providerCode;
	private List<String> contactPoint;
	private List<String> department;
	private List<String> telephone;
	private List<String> fax;
	private List<String> email;

	public ProviderContactDetailForm() {
	}

	public ProviderContactDetailForm(ProviderContact entity) {
		//	this.providerContactId = entity.getProviderContactId();
		this.providerCode = entity.getProviderCode();
		//this.contactPoint = entity.getFirstName();
		//	this.telephone = entity.getPhoneNo1();
		//	this.fax = entity.getFaxNo1();
		//	this.email = entity.getEmailAddress1();
	}

	public List<Long> getProviderContactId() {
		return providerContactId;
	}

	public void setProviderContactId(List<Long> providerContactId) {
		this.providerContactId = providerContactId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public List<String> getContactPoint() {
		return contactPoint;
	}

	public void setContactPoint(List<String> contactPoint) {
		this.contactPoint = contactPoint;
	}

	public List<String> getDepartment() {
		return department;
	}

	public void setDepartment(List<String> department) {
		this.department = department;
	}

	public List<String> getTelephone() {
		return telephone;
	}

	public void setTelephone(List<String> telephone) {
		this.telephone = telephone;
	}

	public List<String> getFax() {
		return fax;
	}

	public void setFax(List<String> fax) {
		this.fax = fax;
	}

	public List<String> getEmail() {
		return email;
	}

	public void setEmail(List<String> email) {
		this.email = email;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
