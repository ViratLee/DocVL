package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitReimbursementDetail {
	@XmlElement(name = "reImbursementTotal")
	BigDecimal reImbursementTotal = BigDecimal.ZERO;
	@XmlElement(name = "reimbursementList")
	List<BenefitReimbursement> reimbursementList = new ArrayList<BenefitReimbursement>();

	public BigDecimal getReImbursementTotal() {
		return reImbursementTotal;
	}

	public void setReImbursementTotal(BigDecimal reImbursementTotal) {
		this.reImbursementTotal = reImbursementTotal;
	}

	public List<BenefitReimbursement> getReimbursementList() {
		return reimbursementList;
	}

	public void setReimbursementList(List<BenefitReimbursement> reimbursementList) {
		this.reimbursementList = reimbursementList;
		calculateReimbursementAmount();
	}

	private void calculateReimbursementAmount() {
		if ((this.reimbursementList != null) && (this.reimbursementList.size() > 0)) {
			this.reImbursementTotal = BigDecimal.ZERO;
			for (BenefitReimbursement reimbursement : reimbursementList) {
				BigDecimal amount = reimbursement.getAmount();
				this.reImbursementTotal = this.reImbursementTotal.add(amount);
			}
		}
	}

}
