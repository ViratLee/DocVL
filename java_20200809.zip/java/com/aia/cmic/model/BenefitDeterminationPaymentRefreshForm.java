package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class BenefitDeterminationPaymentRefreshForm {
	private Boolean isResettle;
	private String suppressInd;
	private Long caseId;
	private Long claimId;
	private Integer dayOfAdmitRoom;
	private Integer dayOfAdmitIcu;
	private Integer dayOfCall;
	private Integer totalDisability;
	private Integer partialDisability;
	private Date disabilityStartDt;
	private Date disabilityEndDt;
	private String doubleIndemnity;
	private String aiCode;
	private List<ClaimBrokenBone> brokenBones;
	private String hbpType;
	private String diseaseInd;
	private String hbjSurgeryInd;
	private String majorAccid;
	private String anesthesiaInd;
	private String majorInjuryDetail;
	private String attainAge;
	private String hbpgHbxHomeMed;
	private String ipdDrug;
	private List<ClaimCriticalIllness> claimCriticalIllnesss;
	private List<BenefitDeterminationPaymentListForm> paymentList = new ArrayList<BenefitDeterminationPaymentListForm>();

	private boolean isSimplify = false;
	private boolean suppressFax = false;
	private String originalBillInd = "N";
	private String cleanInd = "N";
	private String interestInd = "N";
	private BigDecimal csHBAmt;
	private Integer ptcall;

	public Boolean getIsResettle() {
		return isResettle;
	}

	public void setIsResettle(Boolean isResettle) {
		this.isResettle = isResettle;
	}

	public List<BenefitDeterminationPaymentListForm> getPaymentList() {
		return paymentList;
	}

	public void setPaymentList(List<BenefitDeterminationPaymentListForm> paymentList) {
		this.paymentList = paymentList;
	}

	public String getSuppressInd() {
		return suppressInd;
	}

	public void setSuppressInd(String suppressInd) {
		this.suppressInd = suppressInd;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public Integer getDayOfAdmitRoom() {
		return dayOfAdmitRoom;
	}

	public void setDayOfAdmitRoom(Integer dayOfAdmitRoom) {
		this.dayOfAdmitRoom = dayOfAdmitRoom;
	}

	public Integer getDayOfAdmitIcu() {
		return dayOfAdmitIcu;
	}

	public void setDayOfAdmitIcu(Integer dayOfAdmitIcu) {
		this.dayOfAdmitIcu = dayOfAdmitIcu;
	}

	public Integer getDayOfCall() {
		return dayOfCall;
	}

	public void setDayOfCall(Integer dayOfCall) {
		this.dayOfCall = dayOfCall;
	}

	public Integer getTotalDisability() {
		return totalDisability;
	}

	public void setTotalDisability(Integer totalDisability) {
		this.totalDisability = totalDisability;
	}

	public Integer getPartialDisability() {
		return partialDisability;
	}

	public void setPartialDisability(Integer partialDisability) {
		this.partialDisability = partialDisability;
	}

	public Date getDisabilityStartDt() {
		return disabilityStartDt;
	}

	public void setDisabilityStartDt(Date disabilityStartDt) {
		this.disabilityStartDt = disabilityStartDt;
	}

	public Date getDisabilityEndDt() {
		return disabilityEndDt;
	}

	public void setDisabilityEndDt(Date disabilityEndDt) {
		this.disabilityEndDt = disabilityEndDt;
	}

	public String getDoubleIndemnity() {
		return doubleIndemnity;
	}

	public void setDoubleIndemnity(String doubleIndemnity) {
		this.doubleIndemnity = doubleIndemnity;
	}

	public String getAiCode() {
		return aiCode;
	}

	public void setAiCode(String aiCode) {
		this.aiCode = aiCode;
	}

	public List<ClaimBrokenBone> getBrokenBones() {
		return brokenBones;
	}

	public void setBrokenBones(List<ClaimBrokenBone> brokenBones) {
		this.brokenBones = brokenBones;
	}

	public String getHbpType() {
		return hbpType;
	}

	public void setHbpType(String hbpType) {
		this.hbpType = hbpType;
	}

	public String getDiseaseInd() {
		return diseaseInd;
	}

	public void setDiseaseInd(String diseaseInd) {
		this.diseaseInd = diseaseInd;
	}

	public String getHbjSurgeryInd() {
		return hbjSurgeryInd;
	}

	public void setHbjSurgeryInd(String hbjSurgeryInd) {
		this.hbjSurgeryInd = hbjSurgeryInd;
	}

	public String getMajorAccid() {
		return majorAccid;
	}

	public void setMajorAccid(String majorAccid) {
		this.majorAccid = majorAccid;
	}

	public String getAnesthesiaInd() {
		return anesthesiaInd;
	}

	public void setAnesthesiaInd(String anesthesiaInd) {
		this.anesthesiaInd = anesthesiaInd;
	}

	public String getMajorInjuryDetail() {
		return majorInjuryDetail;
	}

	public void setMajorInjuryDetail(String majorInjuryDetail) {
		this.majorInjuryDetail = majorInjuryDetail;
	}

	public Boolean getIsSimplify() {
		return isSimplify;
	}

	public void setIsSimplify(Boolean isSimplify) {
		this.isSimplify = isSimplify;
	}

	public boolean isSuppressFax() {
		return suppressFax;
	}

	public void setSuppressFax(boolean suppressFax) {
		this.suppressFax = suppressFax;
	}

	public void setSimplify(boolean isSimplify) {
		this.isSimplify = isSimplify;
	}

	public String getOriginalBillInd() {
		return originalBillInd;
	}

	public void setOriginalBillInd(String originalBillInd) {
		this.originalBillInd = originalBillInd;
	}
	
	public String getCleanInd() {
		return cleanInd;
	}

	public String getInterestInd() {
		return interestInd;
	}

	public void setCleanInd(String cleanInd) {
		this.cleanInd = cleanInd;
	}

	public void setInterestInd(String interestInd) {
		this.interestInd = interestInd;
	}

	public BigDecimal getCsHBAmt() {
		return csHBAmt;
	}

	public void setCsHBAmt(BigDecimal csHBAmt) {
		this.csHBAmt = csHBAmt;
	}

	public String getAttainAge() {
		return attainAge;
	}

	public String getHbpgHbxHomeMed() {
		return hbpgHbxHomeMed;
	}
	
	public void setAttainAge(String attainAge) {
		this.attainAge = attainAge;
	}

	public void setHbpgHbxHomeMed(String hbpgHbxHomeMed) {
		this.hbpgHbxHomeMed = hbpgHbxHomeMed;
	}

	public String getIpdDrug() {
		return ipdDrug;
	}

	public void setIpdDrug(String ipdDrug) {
		this.ipdDrug = ipdDrug;
	}
	
	public Integer getPtcall() {
		return ptcall;
	}

	public void setPtcall(Integer ptcall) {
		this.ptcall = ptcall;
	}

	public List<ClaimCriticalIllness> getClaimCriticalIllnesss() {
		return claimCriticalIllnesss;
	}

	public void setClaimCriticalIllnesss(List<ClaimCriticalIllness> claimCriticalIllnesss) {
		this.claimCriticalIllnesss = claimCriticalIllnesss;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
