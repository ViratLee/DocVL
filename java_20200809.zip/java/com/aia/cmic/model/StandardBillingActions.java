package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value = { "workbook" })
public class StandardBillingActions {
	private List<StandardBillingMessage> messages = new ArrayList<>();
	private String output;
	private volatile Workbook workbook;
	private List<StandardBilling> newItems = new ArrayList<>();
	private List<StandardBilling> updateItems = new ArrayList<>();
	private List<StandardBilling> deleteItems = new ArrayList<>();

	public List<StandardBilling> getNewItems() {
		return newItems;
	}

	public void setNewItems(List<StandardBilling> newItems) {
		this.newItems = newItems;
	}

	public List<StandardBilling> getUpdateItems() {
		return updateItems;
	}

	public void setUpdateItems(List<StandardBilling> updateItems) {
		this.updateItems = updateItems;
	}

	public List<StandardBilling> getDeleteItems() {
		return deleteItems;
	}

	public void setDeleteItems(List<StandardBilling> deleteItems) {
		this.deleteItems = deleteItems;
	}

	public List<StandardBillingMessage> getMessages() {
		return messages;
	}

	public void setMessages(List<StandardBillingMessage> errMsgs) {
		this.messages = errMsgs;
	}

	public Workbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(Workbook workbook) {
		this.workbook = workbook;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public void addMessage(String sheet, String cell, String policy, int newItems, int updateItems, int deleteItems, String message) {
		StandardBillingMessage msg = new StandardBillingMessage();
		msg.setSheet(sheet);
		msg.setCell(cell);
		msg.setPolicy(policy);
		msg.setNewItems(newItems);
		msg.setUpdateItems(updateItems);
		msg.setDeleteItems(deleteItems);
		msg.setMessage(message);
		this.getMessages().add(msg);
	} 
}
