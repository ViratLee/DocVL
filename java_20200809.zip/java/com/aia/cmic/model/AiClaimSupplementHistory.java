package com.aia.cmic.model;

public class AiClaimSupplementHistory {
	private String CLAIMNO;
	private Long CLAIMSUPPLEMENTID;
	private String CODETYPE;
	private Integer OCCURRENCE;
	private String STRVALUE;
	
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public Long getCLAIMSUPPLEMENTID() {
		return CLAIMSUPPLEMENTID;
	}
	public void setCLAIMSUPPLEMENTID(Long cLAIMSUPPLEMENTID) {
		CLAIMSUPPLEMENTID = cLAIMSUPPLEMENTID;
	}
	public String getCODETYPE() {
		return CODETYPE;
	}
	public void setCODETYPE(String cODETYPE) {
		CODETYPE = cODETYPE;
	}
	public String getSTRVALUE() {
		return STRVALUE;
	}
	public void setSTRVALUE(String sTRVALUE) {
		STRVALUE = sTRVALUE;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	
}

