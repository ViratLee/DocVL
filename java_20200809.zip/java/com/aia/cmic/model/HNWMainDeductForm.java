package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class HNWMainDeductForm {
	private String claimNo;
	private Integer occurrence;
	private Long caseId;
	private String policyNo;
	private String businessLine;
	private String hnwDeductClaimForm;
	private List<HNWDeduct> hnwDeductList;
	
	
	public Long getCaseId() {
		return caseId;
	}



	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}



	public String getClaimNo() {
		return claimNo;
	}



	public Integer getOccurrence() {
		return occurrence;
	}



	public String getPolicyNo() {
		return policyNo;
	}



	public String getBusinessLine() {
		return businessLine;
	}



	public String getHnwDeductClaimForm() {
		return hnwDeductClaimForm;
	}



	public List<HNWDeduct> getHnwDeductList() {
		return hnwDeductList;
	}



	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}



	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}



	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}



	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}



	public void setHnwDeductClaimForm(String hnwDeductClaimForm) {
		this.hnwDeductClaimForm = hnwDeductClaimForm;
	}



	public void setHnwDeductList(List<HNWDeduct> hnwDeductList) {
		this.hnwDeductList = hnwDeductList;
	}



	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
}
