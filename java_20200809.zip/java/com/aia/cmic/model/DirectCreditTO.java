package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DirectCreditTO {
	private Date settleDate;
	private Date claimStatusDate;
	private Date transferDate;
	private String providerCode;
	private List<String> treatmentType;
	private List<String> businessLine;
	private boolean isEdi;
	private boolean isStp;
	
	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date data) {
		this.settleDate = data;
	}

	public Date getClaimStatusDate() {
		return claimStatusDate;
	}

	public void setClaimStatusDate(Date claimStatusDate) {
		this.claimStatusDate = claimStatusDate;
	}
	
	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public List<String> getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(List<String> treatmentType) {
		this.treatmentType = treatmentType;
	}

	public List<String> getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(List<String> businessLine) {
		this.businessLine = businessLine;
	}

	public boolean getIsEdi() {
		return isEdi;
	}

	public boolean getIsStp() {
		return isStp;
	}

	public void setIsEdi(boolean isEdi) {
		this.isEdi = isEdi;
	}

	public void setIsStp(boolean isStp) {
		this.isStp = isStp;
	}
	

}
