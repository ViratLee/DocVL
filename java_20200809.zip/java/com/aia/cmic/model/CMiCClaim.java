package com.aia.cmic.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.restservices.model.Document;

public class CMiCClaim {

	private String businessType;
	private String category;
	private String comment;
	private Date completionDate;
	private Date creationDatetime;
	private String dataentryUser;
	private String fyi;
	private String indexingUser;
	private String medicalUser;
	private String location;
	private String receivingCentre;
	private String scanBatchId;
	private Date scanDate;
	private String scanType;
	private Date slaDatetime;
	private String submissionPoint;
	private String urgent;
	private boolean completed;
	private boolean deleted;
	private boolean contractWithProvider;
	private boolean caseValidated;
	private String deleteUser;
	private String assignTeam;
	private String activity;
	private String owner;
	private String risk;
	private String assessResult;
	private int lockType;
	private Date submissionDate;
	private Timestamp documentIntime;
	private Timestamp addDocumentIntime;
	private boolean stp;
	private String ipdStpFlag;
	private boolean suppressFax = false;
	private String billingItem;

	private ClaimCanonical claimCanonical;
	private List<Document> lstDocument = new ArrayList<>();

	boolean unidentified;
	String deduct;
	boolean fromSmartClaim;

	public CMiCClaim() {
		this.claimCanonical = new ClaimCanonical();
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}

	public Date getCreationDatetime() {
		return creationDatetime;
	}

	public void setCreationDatetime(Date creationDatetime) {
		this.creationDatetime = creationDatetime;
	}

	public String getDataentryUser() {
		return dataentryUser;
	}

	public void setDataentryUser(String dataentryUser) {
		this.dataentryUser = dataentryUser;
	}

	public String getFyi() {
		return fyi;
	}

	public void setFyi(String fyi) {
		this.fyi = fyi;
	}

	public String getIndexingUser() {
		return indexingUser;
	}

	public void setIndexingUser(String indexingUser) {
		this.indexingUser = indexingUser;
	}

	public String getMedicalUser() {
		return medicalUser;
	}

	public void setMedicalUser(String medicalUser) {
		this.medicalUser = medicalUser;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getReceivingCentre() {
		return receivingCentre;
	}

	public void setReceivingCentre(String receivingCentre) {
		this.receivingCentre = receivingCentre;
	}

	public String getScanBatchId() {
		return scanBatchId;
	}

	public void setScanBatchId(String scanBatchId) {
		this.scanBatchId = scanBatchId;
	}

	public Date getScanDate() {
		return scanDate;
	}

	public void setScanDate(Date scanDate) {
		this.scanDate = scanDate;
	}

	public String getScanType() {
		return scanType;
	}

	public void setScanType(String scanType) {
		this.scanType = scanType;
	}

	public Date getSlaDatetime() {
		return slaDatetime;
	}

	public void setSlaDatetime(Date slaDatetime) {
		this.slaDatetime = slaDatetime;
	}

	public String getSubmissionPoint() {
		return submissionPoint;
	}

	public void setSubmissionPoint(String submissionPoint) {
		this.submissionPoint = submissionPoint;
	}

	public String getUrgent() {
		return urgent;
	}

	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public boolean isContractWithProvider() {
		return contractWithProvider;
	}

	public void setContractWithProvider(boolean contractWithProvider) {
		this.contractWithProvider = contractWithProvider;
	}

	public boolean isCaseValidated() {
		return caseValidated;
	}

	public void setCaseValidated(boolean caseValidated) {
		this.caseValidated = caseValidated;
	}

	public String getDeleteUser() {
		return deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public String getAssignTeam() {
		return assignTeam;
	}

	public void setAssignTeam(String assignTeam) {
		this.assignTeam = assignTeam;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getRisk() {
		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;
	}

	public String getAssessResult() {
		return assessResult;
	}

	public void setAssessResult(String assessResult) {
		this.assessResult = assessResult;
	}

	public ClaimCanonical getClaimCanonical() {
		return claimCanonical;
	}

	public void setClaimCanonical(ClaimCanonical claimCanonical) {
		this.claimCanonical = claimCanonical;
	}

	public List<Document> getLstDocument() {
		return lstDocument;
	}

	public void setLstDocument(List<Document> lstDocument) {
		this.lstDocument = lstDocument;
	}

	public int getLockType() {
		return lockType;
	}

	public void setLockType(int lockType) {
		this.lockType = lockType;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public BigDecimal getClaimAmount() {
		if (claimCanonical == null || claimCanonical.getClaim() == null) {
			return null;
		} else {
			return claimCanonical.getClaim().getTotalBilledAmt() == null ? claimCanonical.getClaim().getTotalBilledAmt() : claimCanonical.getClaim().getTotalBilledAmt();
		}
	}

	public String getClaimNum() {
		if (claimCanonical == null || claimCanonical.getClaim() == null || claimCanonical.getClaim().getClaimNo() == null || claimCanonical.getClaim().getClaimNo().trim().length() == 0) {
			return null;
		} else {
			return claimCanonical.getClaim().getClaimNo() + "/" + claimCanonical.getClaim().getOccurrence();
		}
	}

	public boolean isUnidentified() {
		return unidentified;
	}

	public void setUnidentified(boolean unidentified) {
		this.unidentified = unidentified;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public Timestamp getDocumentIntime() {
		return documentIntime;
	}

	public void setDocumentIntime(Timestamp documentIntime) {
		this.documentIntime = documentIntime;
	}

	public Timestamp getAddDocumentIntime() {
		return addDocumentIntime;
	}

	public void setAddDocumentIntime(Timestamp addDocumentIntime) {
		this.addDocumentIntime = addDocumentIntime;
	}

	public boolean isStp() {
		return stp;
	}

	public void setStp(boolean stp) {
		this.stp = stp;
	}

	public String getIpdStpFlag() {
		return ipdStpFlag;
	}

	public void setIpdStpFlag(String ipdStpFlag) {
		this.ipdStpFlag = ipdStpFlag;
	}

	public boolean isSuppressFax() {
		return suppressFax;
	}

	public void setSuppressFax(boolean suppressFax) {
		this.suppressFax = suppressFax;
	}

	public String getBillingItem() {
		return billingItem;
	}

	public void setBillingItem(String billingItem) {
		this.billingItem = billingItem;
	}

	public String getDeduct() {
		return deduct;
	}

	public void setDeduct(String deduct) {
		this.deduct = deduct;
	}

	public boolean isFromSmartClaim() {
		return fromSmartClaim;
	}

	public void setFromSmartClaim(boolean fromSmartClaim) {
		this.fromSmartClaim = fromSmartClaim;
	}
	
    
}
