package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.CommonCode;

public class CommonCodeModel {
	private String category;
	private String codeName;
	private String codeValue;
	private String codeDesc;
	private String codeDescThai;

	public CommonCodeModel(CommonCode CommonCode) {
		this.category = CommonCode.getCategory();
		this.codeName = CommonCode.getCodeName();
		this.codeValue = CommonCode.getCodeValue();
		this.codeDesc = CommonCode.getCodeDesc();
		this.codeDescThai = CommonCode.getCodeDescThai();
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCodeName() {
		return codeName;
	}

	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}

	public String getCodeValue() {
		return codeValue;
	}

	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}

	public String getCodeDesc() {
		return codeDesc;
	}

	public void setCodeDesc(String codeDesc) {
		this.codeDesc = codeDesc;
	}

	public String getCodeDescThai() {
		return codeDescThai;
	}

	public void setCodeDescThai(String codeDescThai) {
		this.codeDescThai = codeDescThai;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}