package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

public class AiProvider {
	private String  BANKCODE;
	private String  BLACKLISTIND;
	private String  BLACKLISTREASON;
	private String    BLACKLISTSTARTDATE;
	private String    EFFECTIVEFROMDT;
	private Integer EXAMROOM;
	private String  HCCODE;
	private Integer ICUBED;
	private Integer OPERATEDBED;
	private Integer ORROOM;
	private String  PREVHOSPITALCODE;
	private String  PROVIDERCODE;
	private String  PROVIDERGROUP;
	private String  PROVIDERSTATUS;
	private String  PROVIDERTYPE;
	private String  PROVIDERTYPESECTOR;
	private Integer REGISTEREDBED;
	
	// New Field
	private String  BLACKLISTENDDATE;
	private String  PAYMENTMETHOD;
	private Long  PROVIDERID;
	
	public String getBANKCODE() {
		return BANKCODE;
	}
	public void setBANKCODE(String bANKCODE) {
		BANKCODE = bANKCODE;
	}
	public String getBLACKLISTIND() {
		return BLACKLISTIND;
	}
	public void setBLACKLISTIND(String bLACKLISTIND) {
		BLACKLISTIND = bLACKLISTIND;
	}
	public String getBLACKLISTREASON() {
		return BLACKLISTREASON;
	}
	public void setBLACKLISTREASON(String bLACKLISTREASON) {
		BLACKLISTREASON = bLACKLISTREASON;
	}
	public String getBLACKLISTSTARTDATE() {
		return BLACKLISTSTARTDATE;
	}
	public void setBLACKLISTSTARTDATE(String bLACKLISTSTARTDATE) {
		BLACKLISTSTARTDATE = bLACKLISTSTARTDATE;
	}
	public String getEFFECTIVEFROMDT() {
		return EFFECTIVEFROMDT;
	}
	public void setEFFECTIVEFROMDT(String eFFECTIVEFROMDT) {
		EFFECTIVEFROMDT = eFFECTIVEFROMDT;
	}
	public Integer getEXAMROOM() {
		return EXAMROOM;
	}
	public void setEXAMROOM(Integer eXAMROOM) {
		EXAMROOM = eXAMROOM;
	}
	public String getHCCODE() {
		return HCCODE;
	}
	public void setHCCODE(String hCCODE) {
		HCCODE = hCCODE;
	}
	public Integer getICUBED() {
		return ICUBED;
	}
	public void setICUBED(Integer iCUBED) {
		ICUBED = iCUBED;
	}
	public Integer getOPERATEDBED() {
		return OPERATEDBED;
	}
	public void setOPERATEDBED(Integer oPERATEDBED) {
		OPERATEDBED = oPERATEDBED;
	}
	public Integer getORROOM() {
		return ORROOM;
	}
	public void setORROOM(Integer oRROOM) {
		ORROOM = oRROOM;
	}
	public String getPREVHOSPITALCODE() {
		return PREVHOSPITALCODE;
	}
	public void setPREVHOSPITALCODE(String pREVHOSPITALCODE) {
		PREVHOSPITALCODE = pREVHOSPITALCODE;
	}
	public String getPROVIDERCODE() {
		return PROVIDERCODE;
	}
	public void setPROVIDERCODE(String pROVIDERCODE) {
		PROVIDERCODE = pROVIDERCODE;
	}
	public String getPROVIDERGROUP() {
		return PROVIDERGROUP;
	}
	public void setPROVIDERGROUP(String pROVIDERGROUP) {
		PROVIDERGROUP = pROVIDERGROUP;
	}
	public String getPROVIDERSTATUS() {
		return PROVIDERSTATUS;
	}
	public void setPROVIDERSTATUS(String pROVIDERSTATUS) {
		PROVIDERSTATUS = pROVIDERSTATUS;
	}
	public String getPROVIDERTYPE() {
		return PROVIDERTYPE;
	}
	public void setPROVIDERTYPE(String pROVIDERTYPE) {
		PROVIDERTYPE = pROVIDERTYPE;
	}
	public String getPROVIDERTYPESECTOR() {
		return PROVIDERTYPESECTOR;
	}
	public void setPROVIDERTYPESECTOR(String pROVIDERTYPESECTOR) {
		PROVIDERTYPESECTOR = pROVIDERTYPESECTOR;
	}
	public Integer getREGISTEREDBED() {
		return REGISTEREDBED;
	}
	public void setREGISTEREDBED(Integer rEGISTEREDBED) {
		REGISTEREDBED = rEGISTEREDBED;
	}
	public String getBLACKLISTENDDATE() {
		return BLACKLISTENDDATE;
	}
	public void setBLACKLISTENDDATE(String bLACKLISTENDDATE) {
		BLACKLISTENDDATE = bLACKLISTENDDATE;
	}
	public String getPAYMENTMETHOD() {
		return PAYMENTMETHOD;
	}
	public void setPAYMENTMETHOD(String pAYMENTMETHOD) {
		PAYMENTMETHOD = pAYMENTMETHOD;
	}
	public Long getPROVIDERID() {
		return PROVIDERID;
	}
	public void setPROVIDERID(Long pROVIDERID) {
		PROVIDERID = pROVIDERID;
	}
	
	
}
