package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class AiClaimSupplement {
	private String CLAIMNO;
	private Long CLAIMSUPPLEMENTID;
	private String CODETYPE;
	private String DATEVALUE;
	private Integer OCCURRENCE;
	private String STRVALUE;
	private BigDecimal INTVALUE;
	private String PRIMARYIND;
	private String CREATEDBY;
	private String CREATEDDT;
	private String LASTMODIFIEDBY;
	private String LASTMODIFIEDDT;
	private String POLICYNO;
	
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public Long getCLAIMSUPPLEMENTID() {
		return CLAIMSUPPLEMENTID;
	}
	public void setCLAIMSUPPLEMENTID(Long cLAIMSUPPLEMENTID) {
		CLAIMSUPPLEMENTID = cLAIMSUPPLEMENTID;
	}
	public String getCODETYPE() {
		return CODETYPE;
	}
	public void setCODETYPE(String cODETYPE) {
		CODETYPE = cODETYPE;
	}
	public String getDATEVALUE() {
		return DATEVALUE;
	}
	public void setDATEVALUE(String dATEVALUE) {
		DATEVALUE = dATEVALUE;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getSTRVALUE() {
		return STRVALUE;
	}
	public void setSTRVALUE(String sTRVALUE) {
		STRVALUE = sTRVALUE;
	}
	public BigDecimal getINTVALUE() {
		return INTVALUE;
	}
	public void setINTVALUE(BigDecimal iNTVALUE) {
		INTVALUE = iNTVALUE;
	}
	public String getPRIMARYIND() {
		return PRIMARYIND;
	}
	public void setPRIMARYIND(String pRIMARYIND) {
		PRIMARYIND = pRIMARYIND;
	}
	public String getCREATEDBY() {
		return CREATEDBY;
	}
	public void setCREATEDBY(String cREATEDBY) {
		CREATEDBY = cREATEDBY;
	}
	public String getCREATEDDT() {
		return CREATEDDT;
	}
	public void setCREATEDDT(String cREATEDDT) {
		CREATEDDT = cREATEDDT;
	}
	public String getLASTMODIFIEDBY() {
		return LASTMODIFIEDBY;
	}
	public void setLASTMODIFIEDBY(String lASTMODIFIEDBY) {
		LASTMODIFIEDBY = lASTMODIFIEDBY;
	}
	public String getLASTMODIFIEDDT() {
		return LASTMODIFIEDDT;
	}
	public void setLASTMODIFIEDDT(String lASTMODIFIEDDT) {
		LASTMODIFIEDDT = lASTMODIFIEDDT;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	
}
