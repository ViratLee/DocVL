package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
public class DoubleCiInquiry {
	
	private long doubleCiInquiryId;
	private Date receivedDate;
	private Date settlementDate;
	private String claimStatus;
	private String claimNumber;
	private String policyNumber;
	private String claimantName;
	private Date inHospDiscDate;
	private String icd10;
	private String doubleCiCondition;
	private Date doubleCiStartDate;
	private Date doubleCiEndDate;
	private String benefitPerPolicyYear;
	private String presentedAmount;
	private String settleAmount;
	
	

	public Date getReceivedDate() {
		return receivedDate;
	}



	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}



	public Date getSettlementDate() {
		return settlementDate;
	}



	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}



	public String getClaimStatus() {
		return claimStatus;
	}



	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}



	public String getClaimNumber() {
		return claimNumber;
	}



	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}



	public String getPolicyNumber() {
		return policyNumber;
	}



	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}



	public String getClaimantName() {
		return claimantName;
	}



	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}



	public Date getInHospDiscDate() {
		return inHospDiscDate;
	}



	public void setInHospDiscDate(Date inHospDiscDate) {
		this.inHospDiscDate = inHospDiscDate;
	}



	public String getIcd10() {
		return icd10;
	}



	public void setIcd10(String icd10) {
		this.icd10 = icd10;
	}



	public String getDoubleCiCondition() {
		return doubleCiCondition;
	}



	public void setDoubleCiCondition(String doubleCiCondition) {
		this.doubleCiCondition = doubleCiCondition;
	}



	public Date getDoubleCiStartDate() {
		return doubleCiStartDate;
	}



	public void setDoubleCiStartDate(Date doubleCiStartDate) {
		this.doubleCiStartDate = doubleCiStartDate;
	}



	public Date getDoubleCiEndDate() {
		return doubleCiEndDate;
	}



	public void setDoubleCiEndDate(Date doubleCiEndDate) {
		this.doubleCiEndDate = doubleCiEndDate;
	}



	public String getBenefitPerPolicyYear() {
		return benefitPerPolicyYear;
	}



	public void setBenefitPerPolicyYear(String benefitPerPolicyYear) {
		this.benefitPerPolicyYear = benefitPerPolicyYear;
	}



	public String getPresentedAmount() {
		return presentedAmount;
	}



	public void setPresentedAmount(String presentedAmount) {
		this.presentedAmount = presentedAmount;
	}



	public String getSettleAmount() {
		return settleAmount;
	}



	public void setSettleAmount(String settleAmount) {
		this.settleAmount = settleAmount;
	}



	public long getDoubleCiInquiryId() {
		return doubleCiInquiryId;
	}



	public void setDoubleCiInquiryId(long doubleCiInquiryId) {
		this.doubleCiInquiryId = doubleCiInquiryId;
	}



	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
