package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.restservices.model.DocumentParam;
import com.aia.cmic.restservices.model.UserProfile;
import com.aia.cmic.util.FormatUtil;

public class DocumentSearchForm {

	//private static final Logger LOG = LoggerFactory.getLogger(SearchDocumentForm.class);
	String policyNo;
	String certNo;
	String scanBatchId;
	Date dateFrom;
	Date dateTo;

	public DocumentSearchForm() {

	}

	public DocumentParam transformToDocumentParam(UserProfile userProfile) {

		DocumentParam doc = new DocumentParam();
		doc.setCertNo(certNo);
		doc.setDateFrom(FormatUtil.convertDateToTimeStamp(dateFrom));
		doc.setDateTo(FormatUtil.convertDateToTimeStamp(dateTo));
		doc.setMemberId("");
		doc.setPolicyNo(policyNo);
		doc.setScanBatchId(scanBatchId);
		doc.setUserProfile(userProfile);
		return doc;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getScanBatchId() {
		return scanBatchId;
	}

	public void setScanBatchId(String scanBatchId) {
		this.scanBatchId = scanBatchId;
	}

	public Date getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}

	public Date getDateTo() {
		return dateTo;
	}

	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
