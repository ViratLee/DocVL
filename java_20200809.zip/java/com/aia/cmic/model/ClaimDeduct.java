package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.ColumnTransformer;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.apache.commons.lang.builder.ToStringBuilder;
public class ClaimDeduct {
	
	private Long claimDeductId;
	private String claimDeductNo;
	private String claimNo;
	private Integer occurrence;
	private Date receivedDate;
	private String submissionSource;
	private String policyNo;
	private String businessLine;
	private String lastName;
	private String firstName;
	private String providerCode;
	private String treatmentType;
	private Date accidentDt;
	private Date hospitalizationDate;
	private Date dischargeDate;
	private Date icuAdmissionDate;
	private Date icuDischargeDate;
	private Integer lengthOfStay;
	private Integer icuLengthOfStay;
	private String deductStatus;
	private Date policyYearFromDt;
	private Date policyYearToDt;
	private Long caseId;
	private Long partyId;
	private String causeOfTreatment;
	private BigDecimal totalDeductAmt;
	private String lastModifiedUserDept;
	private String lastModifiedUserDesk;
	private String servicingAgentCode;
	private String servicingAgencyCode;
	private String servicingGaOfficeCode;
	private String payeeTitle;
	private String payeeFirstName;
	private String payeeLastName;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String zipCode;
	private String createdBy;
	private String lastModifiedBy;
	private Date createdDt;
	private Date lastModifiedDt;
	private String refClaimNo;
	Integer refOccurrence;
	
	private String claimFrom;
	private String certNo;
	private String memberId;
	private String claimantName;
	private String medicalInstitute;
	private String deductAmountStr;
	
	public Long getClaimDeductId() {
		return claimDeductId;
	}


	public String getClaimDeductNo() {
		return claimDeductNo;
	}


	public String getClaimNo() {
		return claimNo;
	}


	public Integer getOccurrence() {
		return occurrence;
	}


	public Date getReceivedDate() {
		return receivedDate;
	}


	public String getSubmissionSource() {
		return submissionSource;
	}


	public String getPolicyNo() {
		return policyNo;
	}


	public String getBusinessLine() {
		return businessLine;
	}


	public String getLastName() {
		return lastName;
	}


	public String getFirstName() {
		return firstName;
	}


	public String getProviderCode() {
		return providerCode;
	}


	public String getTreatmentType() {
		return treatmentType;
	}


	public Date getAccidentDt() {
		return accidentDt;
	}


	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}


	public Date getDischargeDate() {
		return dischargeDate;
	}


	public Date getIcuAdmissionDate() {
		return icuAdmissionDate;
	}


	public Date getIcuDischargeDate() {
		return icuDischargeDate;
	}


	public Integer getLengthOfStay() {
		return lengthOfStay;
	}


	public Integer getIcuLengthOfStay() {
		return icuLengthOfStay;
	}


	public String getDeductStatus() {
		return deductStatus;
	}


	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}


	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}


	public Long getCaseId() {
		return caseId;
	}


	public Long getPartyId() {
		return partyId;
	}


	public String getCauseOfTreatment() {
		return causeOfTreatment;
	}


	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}


	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}


	public String getServicingAgentCode() {
		return servicingAgentCode;
	}


	public String getServicingAgencyCode() {
		return servicingAgencyCode;
	}


	public String getServicingGaOfficeCode() {
		return servicingGaOfficeCode;
	}


	public String getPayeeTitle() {
		return payeeTitle;
	}


	public String getPayeeFirstName() {
		return payeeFirstName;
	}


	public String getPayeeLastName() {
		return payeeLastName;
	}


	public String getAddressLine1() {
		return addressLine1;
	}


	public String getAddressLine2() {
		return addressLine2;
	}


	public String getAddressLine3() {
		return addressLine3;
	}


	public String getAddressLine4() {
		return addressLine4;
	}


	public String getZipCode() {
		return zipCode;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	public Date getCreatedDt() {
		return createdDt;
	}


	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}


	public void setClaimDeductId(Long claimDeductId) {
		this.claimDeductId = claimDeductId;
	}


	public void setClaimDeductNo(String claimDeductNo) {
		this.claimDeductNo = claimDeductNo;
	}


	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}


	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}


	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}


	public void setSubmissionSource(String submissionSource) {
		this.submissionSource = submissionSource;
	}


	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}


	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}


	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}


	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}


	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}


	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}


	public void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}


	public void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}


	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}


	public void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}


	public void setDeductStatus(String deductStatus) {
		this.deductStatus = deductStatus;
	}


	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}


	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}


	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}


	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}


	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}


	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}


	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}


	public void setServicingAgentCode(String servicingAgentCode) {
		this.servicingAgentCode = servicingAgentCode;
	}


	public void setServicingAgencyCode(String servicingAgencyCode) {
		this.servicingAgencyCode = servicingAgencyCode;
	}


	public void setServicingGaOfficeCode(String servicingGaOfficeCode) {
		this.servicingGaOfficeCode = servicingGaOfficeCode;
	}


	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}


	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}


	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}


	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}


	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}


	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}


	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}


	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}


	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}


	public String getClaimFrom() {
		return claimFrom;
	}


	public void setClaimFrom(String claimFrom) {
		this.claimFrom = claimFrom;
	}


	public String getCertNo() {
		return certNo;
	}


	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}



	public String getMemberId() {
		return memberId;
	}


	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}


	public String getClaimantName() {
		return claimantName;
	}


	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}


	public String getMedicalInstitute() {
		return medicalInstitute;
	}


	public void setMedicalInstitute(String medicalInstitute) {
		this.medicalInstitute = medicalInstitute;
	}


	public String getDeductAmountStr() {
		return deductAmountStr;
	}


	public void setDeductAmountStr(String deductAmountStr) {
		this.deductAmountStr = deductAmountStr;
	}

	

	public BigDecimal getTotalDeductAmt() {
		return totalDeductAmt;
	}


	public void setTotalDeductAmt(BigDecimal totalDeductAmt) {
		this.totalDeductAmt = totalDeductAmt;
	}

	public String getRefClaimNo() {
		return refClaimNo;
	}

	public Integer getRefOccurrence() {
		return refOccurrence;
	}


	public void setRefClaimNo(String refClaimNo) {
		this.refClaimNo = refClaimNo;
	}


	public void setRefOccurrence(Integer refOccurrence) {
		this.refOccurrence = refOccurrence;
	}


	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
