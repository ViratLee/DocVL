package com.aia.cmic.model;

public class ResponseBatchControl {
	String batchControlNo;
	String successIndicator;
	String errorMessage;

	public String getBatchControlNo() {
		return batchControlNo;
	}

	public void setBatchControlNo(String batchControlNo) {
		this.batchControlNo = batchControlNo;
	}

	public String getSuccessIndicator() {
		return successIndicator;
	}

	public void setSuccessIndicator(String successIndicator) {
		this.successIndicator = successIndicator;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String toString() {
		return "batchControlNo: " + batchControlNo + "successIndicator: " + successIndicator + ",errorMessage: "
				+ errorMessage;
	}
}
