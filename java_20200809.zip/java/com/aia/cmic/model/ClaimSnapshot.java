package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClaimSnapshot {

	private Long claimId;
	private String claimNo;
	private Integer occurrence;
	private Date receivedDate;
	private String policyNo;
	private String certNo;
	private String dependentNo;
	private String memberId;
	private String clientId;
	private Long partyId;
	private String firstName;
	private String lastName;
	private String claimStatus;
	private String majorAccId;
	private Date accidentDt;
	private Date hospitalizationDate;
	private Date dischargeDate;
	private String medicalInstitute;
	private Long caseId;
	private String providerCode;
	private String providerNameThai;
	private String channel;
	private String submissionType;
	private String phase;
	private BigDecimal totalBilledAmt;
	private String comment;
	private String treatmentType;
	private String lastModifiedBy;
	private Date disabilityEndDt;
	private List<ClaimInjuryArea> injuryAreas = new ArrayList<ClaimInjuryArea>();
	private List<ClaimDiagnosisCode> diagnosisCodes = new ArrayList<ClaimDiagnosisCode>();

	private String stpInd;
	private String ediInd;

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getMajorAccId() {
		return majorAccId;
	}

	public void setMajorAccId(String majorAccId) {
		this.majorAccId = majorAccId;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public String getMedicalInstitute() {
		return medicalInstitute;
	}

	public void setMedicalInstitute(String medicalInstitute) {
		this.medicalInstitute = medicalInstitute;
	}

	/**
	 * @return the caseId
	 */

	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	/**
	 * @return the providerNameThai
	 */
	public String getProviderNameThai() {
		return providerNameThai;
	}

	/**
	 * @param providerNameThai the providerNameThai to set
	 */
	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	/**
	 * @return the totalBilledAmt
	 */
	public BigDecimal getTotalBilledAmt() {
		return totalBilledAmt;
	}

	/**
	 * @param totalBilledAmt the totalBilledAmt to set
	 */
	public void setTotalBilledAmt(BigDecimal totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

	/**
	 * @return the injuryAreas
	 */
	public List<ClaimInjuryArea> getInjuryAreas() {
		return injuryAreas;
	}

	/**
	 * @param injuryAreas the injuryAreas to set
	 */
	public void setInjuryAreas(List<ClaimInjuryArea> injuryAreas) {
		this.injuryAreas = injuryAreas;
	}

	/**
	 * @return the diagnosisCode
	 */
	public List<ClaimDiagnosisCode> getDiagnosisCodes() {
		return diagnosisCodes;
	}

	/**
	 * @param diagnosisCode the diagnosisCode to set
	 */
	public void setDiagnosisCodes(List<ClaimDiagnosisCode> diagnosisCodes) {
		this.diagnosisCodes = diagnosisCodes;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public Date getDisabilityEndDt() {
		return disabilityEndDt;
	}

	public void setDisabilityEndDt(Date disabilityEndDt) {
		this.disabilityEndDt = disabilityEndDt;
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

}
