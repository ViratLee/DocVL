package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class BenefitDetail {
	Long claimPaymentId;
	String businessLine;
	String policyNo;
	Long planId;
	String planCoverageNo;
	String planShortName;
	String productShortName;
	BigDecimal sumAssured;
	String exc;
	String imp;
	String eligibility;
	String claimDecision;
	String declineReason;
	String payee;
	BigDecimal systemQuotation;
	BigDecimal total;
	BigDecimal coInsurance;
	String suppressCheque;
	BigDecimal adjusted;
	String adjustedReason;
	String eligibilityPolicyNo;
	Date settlementDate;
	String lastModifiedBy;
	Date lastModifiedDt;
	String payNonCoverItemInd;
	BigDecimal shortfallAmt;
	String certNo;
	boolean isCS;
	String claimNo;
	Integer occurrence;
	String productCode;

	String dataPrivacyConsent;
	String dataPrivacyConsentDate;
	String aiDecision;
	
	public BigDecimal getShortfallAmt() {
		return shortfallAmt;
	}

	public void setShortfallAmt(BigDecimal shortfallAmt) {
		this.shortfallAmt = shortfallAmt;
	}

	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	public String getPlanShortName() {
		return planShortName;
	}

	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}

	public String getProductShortName() {
		return productShortName;
	}

	public void setProductShortName(String productShortName) {
		this.productShortName = productShortName;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getExc() {
		return exc;
	}

	public void setExc(String exc) {
		this.exc = exc;
	}

	public String getImp() {
		return imp;
	}

	public void setImp(String imp) {
		this.imp = imp;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getClaimDecision() {
		return claimDecision;
	}

	public void setClaimDecision(String claimDecision) {
		this.claimDecision = claimDecision;
	}

	public String getDeclineReason() {
		return declineReason;
	}

	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public BigDecimal getSystemQuotation() {
		return systemQuotation;
	}

	public void setSystemQuotation(BigDecimal systemQuotation) {
		this.systemQuotation = systemQuotation;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getCoInsurance() {
		return coInsurance;
	}

	public void setCoInsurance(BigDecimal coInsurance) {
		this.coInsurance = coInsurance;
	}

	public String getSuppressCheque() {
		return suppressCheque;
	}

	public void setSuppressCheque(String suppressCheque) {
		this.suppressCheque = suppressCheque;
	}

	public BigDecimal getAdjusted() {
		return adjusted;
	}

	public void setAdjusted(BigDecimal adjusted) {
		this.adjusted = adjusted;
	}

	public String getAdjustedReason() {
		return adjustedReason;
	}

	public void setAdjustedReason(String adjustedReason) {
		this.adjustedReason = adjustedReason;
	}

	public String getEligibilityPolicyNo() {
		return eligibilityPolicyNo;
	}

	public void setEligibilityPolicyNo(String eligibilityPolicyNo) {
		this.eligibilityPolicyNo = eligibilityPolicyNo;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String getPayNonCoverItemInd() {
		return payNonCoverItemInd;
	}

	public void setPayNonCoverItemInd(String payNonCoverItemInd) {
		this.payNonCoverItemInd = payNonCoverItemInd;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public boolean getIsCS() {
		return isCS;
	}

	public void setIsCS(boolean isCS) {
		this.isCS = isCS;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getDataPrivacyConsent() {
		return dataPrivacyConsent;
	}

	public void setDataPrivacyConsent(String dataPrivacyConsent) {
		this.dataPrivacyConsent = dataPrivacyConsent;
	}

	public String getDataPrivacyConsentDate() {
		return dataPrivacyConsentDate;
	}

	public void setDataPrivacyConsentDate(String dataPrivacyConsentDate) {
		this.dataPrivacyConsentDate = dataPrivacyConsentDate;
	}

	public String getAiDecision() {
		return aiDecision;
	}

	public void setAiDecision(String aiDecision) {
		this.aiDecision = aiDecision;
	}

	public void setCS(boolean isCS) {
		this.isCS = isCS;
	}

}
