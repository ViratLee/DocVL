package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class ClaimHistorySearchCriteria {
	private String insuredName;
	private String claimNo;
	private String policyNo;
	private Date submissionDate;
	private String certificateNo;
	private Date settlementDate;
	private String memberId;
	private Date lossAccidentDate;
	private String providerName;
	private Date inHospitalDate;
	private String province;
	private String partyId;
	private boolean includeQuotation;
	private String claimId;
	
	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public Date getLossAccidentDate() {
		return lossAccidentDate;
	}

	public void setLossAccidentDate(Date lossAccidentDate) {
		this.lossAccidentDate = lossAccidentDate;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Date getInHospitalDate() {
		return inHospitalDate;
	}

	public void setInHospitalDate(Date inHospitalDate) {
		this.inHospitalDate = inHospitalDate;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getOnlyClaimNo() {
		if (claimNo != null && claimNo.length() > 0) {
			String[] spl = claimNo.split("/");

			if (spl != null && spl.length == 2) {
				return spl[0].trim();
			}
		}
		return StringUtils.isNotBlank(claimNo) ? claimNo.trim() : null;
	}

	public String getOnlyOccurrence() {
		if (claimNo != null && claimNo.length() > 0) {
			String[] spl = claimNo.split("/");

			if (spl != null && spl.length == 2) {
				return spl[1].trim();
			}
		}
		return null;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public boolean isIncludeQuotation() {
		return includeQuotation;
	}

	public void setIncludeQuotation(boolean includeQuotation) {
		this.includeQuotation = includeQuotation;
	}

}
