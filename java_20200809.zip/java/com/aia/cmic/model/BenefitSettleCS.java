package com.aia.cmic.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitSettleCS {
	@XmlElement(name = "benefitSettlePolicyDetail")
	BenefitSettlePolicyDetail benefitSettlePolicyDetail;
	@XmlElement(name = "benefitSettlePolicy")
	BenefitSettlePolicy benefitSettlePolicy;

	public BenefitSettlePolicyDetail getBenefitSettlePolicyDetail() {
		return benefitSettlePolicyDetail;
	}

	public void setBenefitSettlePolicyDetail(BenefitSettlePolicyDetail benefitSettlePolicyDetail) {
		this.benefitSettlePolicyDetail = benefitSettlePolicyDetail;
	}

	public BenefitSettlePolicy getBenefitSettlePolicy() {
		return benefitSettlePolicy;
	}

	public void setBenefitSettlePolicy(BenefitSettlePolicy benefitSettlePolicy) {
		this.benefitSettlePolicy = benefitSettlePolicy;
	}

}
