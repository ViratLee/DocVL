package com.aia.cmic.model;

import java.util.List;

public class OriginalReceiptResponse {
	private Integer totalRows;
	private List<OriginalReceiptTO> resultSets;

	public Integer getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(Integer totalRows) {
		this.totalRows = totalRows;
	}

	public List<OriginalReceiptTO> getResultSets() {
		return resultSets;
	}

	public void setResultSets(List<OriginalReceiptTO> resultSets) {
		this.resultSets = resultSets;
	}


}
