package com.aia.cmic.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class BenefitSettlement {
	@XmlElement(name = "benefitSettlementDetail")
	BenefitSettlementDetail benefitSettlementDetail;
	@XmlElement(name = "benefitBillingItemDetail")
	BenefitBillingItemDetail benefitBillingItemDetail;
	@XmlElement(name = "reimbursementDetail")
	BenefitReimbursementDetail reimbursementDetail;
	@XmlElement(name = "benefitSettleFL")
	BenefitSettleFL benefitSettleFL;
	@XmlElement(name = "benefitSettleCSMain")
	BenefitSettleCSMain benefitSettleCSMain;

	public BenefitSettleCSMain getBenefitSettleCSMain() {
		return benefitSettleCSMain;
	}

	public void setBenefitSettleCSMain(BenefitSettleCSMain benefitSettleCSMain) {
		this.benefitSettleCSMain = benefitSettleCSMain;
	}

	public BenefitSettleFL getBenefitSettleFL() {
		return benefitSettleFL;
	}

	public void setBenefitSettleFL(BenefitSettleFL benefitSettleFL) {
		this.benefitSettleFL = benefitSettleFL;
	}

	public BenefitSettlementDetail getBenefitSettlementDetail() {
		return benefitSettlementDetail;
	}

	public void setBenefitSettlementDetail(BenefitSettlementDetail benefitSettlementDetail) {
		this.benefitSettlementDetail = benefitSettlementDetail;
	}

	public BenefitBillingItemDetail getBenefitBillingItemDetail() {
		return benefitBillingItemDetail;
	}

	public void setBenefitBillingItemDetail(BenefitBillingItemDetail benefitBillingItemDetail) {
		this.benefitBillingItemDetail = benefitBillingItemDetail;
	}

	public BenefitReimbursementDetail getReimbursementDetail() {
		return reimbursementDetail;
	}

	public void setReimbursementDetail(BenefitReimbursementDetail reimbursementDetail) {
		this.reimbursementDetail = reimbursementDetail;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
