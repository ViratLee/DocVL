package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

public class PolicyProductBenefitCOAST {

	String policyNo;
	String certNo;
	String dependentNo;
	Date policyYearFromDt;
	Date policyYearToDt;
	List<PolicyProductBenefitDetailCOAST> limitNonShareGrid;
	List<PolicyProductBenefitDetailCOAST> limitSharedGrid;

	public PolicyProductBenefitCOAST() {
	}

	public PolicyProductBenefitCOAST(ClaimPolicy claimPolicy, Claim claim) {
		this.policyNo = claim.getPolicyNo();
		this.certNo = claim.getCertNo();
		this.dependentNo = claim.getDependentNo();
		this.policyYearFromDt = claimPolicy.getPolicyYearFromDt();
		this.policyYearToDt = claimPolicy.getPolicyYearToDt();
		this.limitNonShareGrid = claimPolicy.getLimitNonShareDetailGrid();
		this.limitSharedGrid = claimPolicy.getLimitSharedDetailGrid();
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public List<PolicyProductBenefitDetailCOAST> getLimitNonShareGrid() {
		return limitNonShareGrid;
	}

	public void setLimitNonShareGrid(List<PolicyProductBenefitDetailCOAST> limitNonShareGrid) {
		this.limitNonShareGrid = limitNonShareGrid;
	}

	public List<PolicyProductBenefitDetailCOAST> getLimitSharedGrid() {
		return limitSharedGrid;
	}

	public void setLimitSharedGrid(List<PolicyProductBenefitDetailCOAST> limitSharedGrid) {
		this.limitSharedGrid = limitSharedGrid;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

}
