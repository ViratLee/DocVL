package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class BaseCaseData {
	private String nextAction;
	private Long caseId;
	private Long claimId;
	private String claimNo;
	private String submissionType;
	private String relationship;
	private String relationshipName;
	private String originalBillInd;
	private String noOriginalBillInd;
	private String brokerCode;
	private String agentCodeServicing;
	private String paymentMethod;
	private String payeeIsCompanyInd;
	private String paymentSeq;
	private String fastTrackAgency;
	private Date billDtFrom;
	private Date billDtTo;
	private String providerCode;
	private String classOfBed;
	private List<ClaimPhysician> physicians;
	private List<ClaimSpecialist> specialists;
	private List<ClaimReferral> referrals;
	private String origCurrency;
	private String convCurrency;
	private List<BillingItem> billingItems;
	private BigDecimal totalEstimatedCost;
	private BigDecimal totalBilledAmt;
	private String treatmentType;
	private String causeOfTreatment;
	private Date consultationDt;
	private Date accidentDt;
	private String accidentPlace;
	private String levelOfConsciousness;
	private String causeOfInjury;
	private String injuryType;
	private Integer estimatedTimeOfDiscovery;
	private Integer estimatedMonthOfDiscovery;
	private List<ClaimInjuryArea> injuryAreas;
	private BigDecimal temperature;
	private BigDecimal pulse;
	private BigDecimal systolic;
	private BigDecimal diastolic;
	private BigDecimal respiratoryRate;
	private Integer painScore;
	private Integer comaScore;
	private BigDecimal weight;
	private BigDecimal height;
	private String presentIllness;
	private String physicalFinding;
	private String chiefComplaint;
	private String underlyingCause;
	private String illnessSpecialCondition;
	private Date symptomDate;
	private Date firstConsultationDt;
	private Date prevTreatmentDate;
	private String prevDoctorName;
	private String prevDoctorEmail;
	private String prevlDoctorPhone;
	private String prevDoctorFax;
	private String referralDoctorName;
	private String referralDoctorEmail;
	private String referralDoctorPhone;
	private String referralDoctorFax;
	private String diagnosisResult;
	private String provisionalDiagnosis;
	private String conditionRequiredTreatment;
	private String roomType;
	private String hospitalizationReason;
	private Date treatmentDate;
	private List<ClaimDiagnosisTest> diagnosisTests;
	private List<ClaimDiagnosisCode> diagnosisCodes;
	private List<ClaimProcedureCode> procedureCodes;
	private List<ClaimPlannedMedication> claimPlannedMedications;
	private List<ClaimPlannedSurgery> claimPlannedSurgerys;
	private List<ClaimCriticalIllness> claimCriticalIllnesss;
	private Date firstAdmitDt;
	private Date hospitalizationDate;
	private Date dischargeDate;
	private Date icuAdmissionDate;
	private Date icuDischargeDate;
	private Integer lengthOfStay;
	private Integer icuLengthOfStay;
	private String icuReason;
	private String otherInsurer;
	private Date homeLeaveFromDate;
	private Date homeLeaveToDt;
	private String homeLeaveReason;
	private Integer dayOfAdmitRoom;
	private Integer dayOfAdmitIcu;
	private Integer dayOfCall;
	private Integer totalDisability;
	private Integer partialDisability;
	private Date disabilityStartDt;
	private Date disabilityEndDt;
	private String doubleIndemnity;
	private String attainAge;
	private String hbpgHbxHomeMed;
	private String ipdDrug;
	private String aiCode;
	private List<ClaimBrokenBone> brokenBones;
	private String hbpType;
	private String diseaseInd;
	private String hbjSurgeryInd;
	private String majorAccid;
	private String anesthesiaInd;
	private String majorInjuryDetail;
	private List<ClaimComment> claimComments;
	private boolean quotationClaim = false;
	private BenefitDeterminationPaymentRefreshForm benefitDeterminationPaymentRefreshForm;

	private String membershipNo;
	private String hn;
	private String an;
	private BigDecimal csHBAmt;
	private Integer ptcall;
	
	private String cleanInd;
	private String interestInd;

	private List<EdiBillingItem> ediBillings;
	private List<EdiOrderItem> ediOrderItems;
	private List<EdiLaboratory> ediLaboratories;
	private List<EdiProcedure> ediProcedures;
	private List<EdiVitalSigns> ediVitalSigns;
	private List<EdiDoctor> ediDoctors;

	public String getMembershipNo() {
		return membershipNo;
	}

	public void setMembershipNo(String membershipNo) {
		this.membershipNo = membershipNo;
	}

	public String getNextAction() {
		return nextAction;
	}

	public void setNextAction(String nextAction) {
		this.nextAction = nextAction;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getRelationshipName() {
		return relationshipName;
	}

	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}

	public String getOriginalBillInd() {
		return originalBillInd;
	}

	public void setOriginalBillInd(String originalBillInd) {
		this.originalBillInd = originalBillInd;
	}

	public String getNoOriginalBillInd() {
		return noOriginalBillInd;
	}

	public void setNoOriginalBillInd(String noOriginalBillInd) {
		this.noOriginalBillInd = noOriginalBillInd;
	}

	public String getBrokerCode() {
		return brokerCode;
	}

	public void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}

	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPayeeIsCompanyInd() {
		return payeeIsCompanyInd;
	}

	public void setPayeeIsCompanyInd(String payeeIsCompanyInd) {
		this.payeeIsCompanyInd = payeeIsCompanyInd;
	}

	public String getPaymentSeq() {
		return paymentSeq;
	}

	public void setPaymentSeq(String paymentSeq) {
		this.paymentSeq = paymentSeq;
	}

	public String getFastTrackAgency() {
		return fastTrackAgency;
	}

	public void setFastTrackAgency(String fastTrackAgency) {
		this.fastTrackAgency = fastTrackAgency;
	}

	public Date getBillDtFrom() {
		return billDtFrom;
	}

	public void setBillDtFrom(Date billDtFrom) {
		this.billDtFrom = billDtFrom;
	}

	public Date getBillDtTo() {
		return billDtTo;
	}

	public void setBillDtTo(Date billDtTo) {
		this.billDtTo = billDtTo;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getClassOfBed() {
		return classOfBed;
	}

	public void setClassOfBed(String classOfBed) {
		this.classOfBed = classOfBed;
	}

	public List<ClaimPhysician> getPhysicians() {
		return physicians;
	}

	public void setPhysicians(List<ClaimPhysician> physicians) {
		this.physicians = physicians;
	}

	public List<ClaimSpecialist> getSpecialists() {
		return specialists;
	}

	public void setSpecialists(List<ClaimSpecialist> specialists) {
		this.specialists = specialists;
	}

	public List<ClaimReferral> getReferrals() {
		return referrals;
	}

	public void setReferrals(List<ClaimReferral> referrals) {
		this.referrals = referrals;
	}

	public String getOrigCurrency() {
		return origCurrency;
	}

	public void setOrigCurrency(String origCurrency) {
		this.origCurrency = origCurrency;
	}

	public String getConvCurrency() {
		return convCurrency;
	}

	public void setConvCurrency(String convCurrency) {
		this.convCurrency = convCurrency;
	}

	public List<BillingItem> getBillingItems() {
		return billingItems;
	}

	public void setBillingItems(List<BillingItem> billingItems) {
		this.billingItems = billingItems;
	}

	public BigDecimal getTotalEstimatedCost() {
		return totalEstimatedCost;
	}

	public void setTotalEstimatedCost(BigDecimal totalEstimatedCost) {
		this.totalEstimatedCost = totalEstimatedCost;
	}

	public BigDecimal getTotalBilledAmt() {
		return totalBilledAmt;
	}

	public void setTotalBilledAmt(BigDecimal totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public String getCauseOfTreatment() {
		return causeOfTreatment;
	}

	public void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	public Date getConsultationDt() {
		return consultationDt;
	}

	public void setConsultationDt(Date consultationDt) {
		this.consultationDt = consultationDt;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public String getAccidentPlace() {
		return accidentPlace;
	}

	public void setAccidentPlace(String accidentPlace) {
		this.accidentPlace = accidentPlace;
	}

	public String getLevelOfConsciousness() {
		return levelOfConsciousness;
	}

	public void setLevelOfConsciousness(String levelOfConsciousness) {
		this.levelOfConsciousness = levelOfConsciousness;
	}

	public String getCauseOfInjury() {
		return causeOfInjury;
	}

	public void setCauseOfInjury(String causeOfInjury) {
		this.causeOfInjury = causeOfInjury;
	}

	public String getInjuryType() {
		return injuryType;
	}

	public void setInjuryType(String injuryType) {
		this.injuryType = injuryType;
	}

	public Integer getEstimatedTimeOfDiscovery() {
		return estimatedTimeOfDiscovery;
	}

	public void setEstimatedTimeOfDiscovery(Integer estimatedTimeOfDiscovery) {
		this.estimatedTimeOfDiscovery = estimatedTimeOfDiscovery;
	}

	public Integer getEstimatedMonthOfDiscovery() {
		return estimatedMonthOfDiscovery;
	}

	public void setEstimatedMonthOfDiscovery(Integer estimatedMonthOfDiscovery) {
		this.estimatedMonthOfDiscovery = estimatedMonthOfDiscovery;
	}

	public List<ClaimInjuryArea> getInjuryAreas() {
		return injuryAreas;
	}

	public void setInjuryAreas(List<ClaimInjuryArea> injuryAreas) {
		this.injuryAreas = injuryAreas;
	}

	public BigDecimal getTemperature() {
		return temperature;
	}

	public void setTemperature(BigDecimal temperature) {
		this.temperature = temperature;
	}

	public BigDecimal getPulse() {
		return pulse;
	}

	public void setPulse(BigDecimal pulse) {
		this.pulse = pulse;
	}

	public BigDecimal getSystolic() {
		return systolic;
	}

	public void setSystolic(BigDecimal systolic) {
		this.systolic = systolic;
	}

	public BigDecimal getDiastolic() {
		return diastolic;
	}

	public void setDiastolic(BigDecimal diastolic) {
		this.diastolic = diastolic;
	}

	public BigDecimal getRespiratoryRate() {
		return respiratoryRate;
	}

	public void setRespiratoryRate(BigDecimal respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}

	public Integer getPainScore() {
		return painScore;
	}

	public void setPainScore(Integer painScore) {
		this.painScore = painScore;
	}

	public Integer getComaScore() {
		return comaScore;
	}

	public void setComaScore(Integer comaScore) {
		this.comaScore = comaScore;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getHeight() {
		return height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public String getPresentIllness() {
		return presentIllness;
	}

	public void setPresentIllness(String presentIllness) {
		this.presentIllness = presentIllness;
	}

	public String getPhysicalFinding() {
		return physicalFinding;
	}

	public void setPhysicalFinding(String physicalFinding) {
		this.physicalFinding = physicalFinding;
	}

	public String getChiefComplaint() {
		return chiefComplaint;
	}

	public void setChiefComplaint(String chiefComplaint) {
		this.chiefComplaint = chiefComplaint;
	}

	public String getUnderlyingCause() {
		return underlyingCause;
	}

	public void setUnderlyingCause(String underlyingCause) {
		this.underlyingCause = underlyingCause;
	}

	public String getIllnessSpecialCondition() {
		return illnessSpecialCondition;
	}

	public void setIllnessSpecialCondition(String illnessSpecialCondition) {
		this.illnessSpecialCondition = illnessSpecialCondition;
	}

	public Date getSymptomDate() {
		return symptomDate;
	}

	public void setSymptomDate(Date symptomDate) {
		this.symptomDate = symptomDate;
	}

	public Date getFirstConsultationDt() {
		return firstConsultationDt;
	}

	public void setFirstConsultationDt(Date firstConsultationDt) {
		this.firstConsultationDt = firstConsultationDt;
	}

	public Date getPrevTreatmentDate() {
		return prevTreatmentDate;
	}

	public void setPrevTreatmentDate(Date prevTreatmentDate) {
		this.prevTreatmentDate = prevTreatmentDate;
	}

	public String getPrevDoctorName() {
		return prevDoctorName;
	}

	public void setPrevDoctorName(String prevDoctorName) {
		this.prevDoctorName = prevDoctorName;
	}

	public String getPrevDoctorEmail() {
		return prevDoctorEmail;
	}

	public void setPrevDoctorEmail(String prevDoctorEmail) {
		this.prevDoctorEmail = prevDoctorEmail;
	}

	public String getPrevlDoctorPhone() {
		return prevlDoctorPhone;
	}

	public void setPrevlDoctorPhone(String prevlDoctorPhone) {
		this.prevlDoctorPhone = prevlDoctorPhone;
	}

	public String getPrevDoctorFax() {
		return prevDoctorFax;
	}

	public void setPrevDoctorFax(String prevDoctorFax) {
		this.prevDoctorFax = prevDoctorFax;
	}

	public String getReferralDoctorName() {
		return referralDoctorName;
	}

	public void setReferralDoctorName(String referralDoctorName) {
		this.referralDoctorName = referralDoctorName;
	}

	public String getReferralDoctorEmail() {
		return referralDoctorEmail;
	}

	public void setReferralDoctorEmail(String referralDoctorEmail) {
		this.referralDoctorEmail = referralDoctorEmail;
	}

	public String getReferralDoctorPhone() {
		return referralDoctorPhone;
	}

	public void setReferralDoctorPhone(String referralDoctorPhone) {
		this.referralDoctorPhone = referralDoctorPhone;
	}

	public String getReferralDoctorFax() {
		return referralDoctorFax;
	}

	public void setReferralDoctorFax(String referralDoctorFax) {
		this.referralDoctorFax = referralDoctorFax;
	}

	public String getDiagnosisResult() {
		return diagnosisResult;
	}

	public void setDiagnosisResult(String diagnosisResult) {
		this.diagnosisResult = diagnosisResult;
	}

	public String getProvisionalDiagnosis() {
		return provisionalDiagnosis;
	}

	public void setProvisionalDiagnosis(String provisionalDiagnosis) {
		this.provisionalDiagnosis = provisionalDiagnosis;
	}

	public String getConditionRequiredTreatment() {
		return conditionRequiredTreatment;
	}

	public void setConditionRequiredTreatment(String conditionRequiredTreatment) {
		this.conditionRequiredTreatment = conditionRequiredTreatment;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getHospitalizationReason() {
		return hospitalizationReason;
	}

	public void setHospitalizationReason(String hospitalizationReason) {
		this.hospitalizationReason = hospitalizationReason;
	}

	public Date getTreatmentDate() {
		return treatmentDate;
	}

	public void setTreatmentDate(Date treatmentDate) {
		this.treatmentDate = treatmentDate;
	}

	public List<ClaimDiagnosisTest> getDiagnosisTests() {
		return diagnosisTests;
	}

	public void setDiagnosisTests(List<ClaimDiagnosisTest> diagnosisTests) {
		this.diagnosisTests = diagnosisTests;
	}

	public List<ClaimDiagnosisCode> getDiagnosisCodes() {
		return diagnosisCodes;
	}

	public void setDiagnosisCodes(List<ClaimDiagnosisCode> diagnosisCodes) {
		this.diagnosisCodes = diagnosisCodes;
	}

	public List<ClaimProcedureCode> getProcedureCodes() {
		return procedureCodes;
	}

	public void setProcedureCodes(List<ClaimProcedureCode> procedureCodes) {
		this.procedureCodes = procedureCodes;
	}

	public List<ClaimPlannedMedication> getClaimPlannedMedications() {
		return claimPlannedMedications;
	}

	public void setClaimPlannedMedications(List<ClaimPlannedMedication> claimPlannedMedications) {
		this.claimPlannedMedications = claimPlannedMedications;
	}

	public List<ClaimPlannedSurgery> getClaimPlannedSurgerys() {
		return claimPlannedSurgerys;
	}

	public void setClaimPlannedSurgerys(List<ClaimPlannedSurgery> claimPlannedSurgerys) {
		this.claimPlannedSurgerys = claimPlannedSurgerys;
	}

	public Date getFirstAdmitDt() {
		return firstAdmitDt;
	}

	public void setFirstAdmitDt(Date firstAdmitDt) {
		this.firstAdmitDt = firstAdmitDt;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public Date getIcuAdmissionDate() {
		return icuAdmissionDate;
	}

	public void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}

	public Date getIcuDischargeDate() {
		return icuDischargeDate;
	}

	public void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}

	public Integer getLengthOfStay() {
		return lengthOfStay;
	}

	public void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public Integer getIcuLengthOfStay() {
		return icuLengthOfStay;
	}

	public void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}

	public String getIcuReason() {
		return icuReason;
	}

	public void setIcuReason(String icuReason) {
		this.icuReason = icuReason;
	}

	public String getOtherInsurer() {
		return otherInsurer;
	}

	public void setOtherInsurer(String otherInsurer) {
		this.otherInsurer = otherInsurer;
	}

	public Date getHomeLeaveFromDate() {
		return homeLeaveFromDate;
	}

	public void setHomeLeaveFromDate(Date homeLeaveFromDate) {
		this.homeLeaveFromDate = homeLeaveFromDate;
	}

	public Date getHomeLeaveToDt() {
		return homeLeaveToDt;
	}

	public void setHomeLeaveToDt(Date homeLeaveToDt) {
		this.homeLeaveToDt = homeLeaveToDt;
	}

	public String getHomeLeaveReason() {
		return homeLeaveReason;
	}

	public void setHomeLeaveReason(String homeLeaveReason) {
		this.homeLeaveReason = homeLeaveReason;
	}

	public Integer getDayOfAdmitRoom() {
		return dayOfAdmitRoom;
	}

	public void setDayOfAdmitRoom(Integer dayOfAdmitRoom) {
		this.dayOfAdmitRoom = dayOfAdmitRoom;
	}

	public Integer getDayOfAdmitIcu() {
		return dayOfAdmitIcu;
	}

	public void setDayOfAdmitIcu(Integer dayOfAdmitIcu) {
		this.dayOfAdmitIcu = dayOfAdmitIcu;
	}

	public Integer getDayOfCall() {
		return dayOfCall;
	}

	public void setDayOfCall(Integer dayOfCall) {
		this.dayOfCall = dayOfCall;
	}

	public Integer getTotalDisability() {
		return totalDisability;
	}

	public void setTotalDisability(Integer totalDisability) {
		this.totalDisability = totalDisability;
	}

	public Integer getPartialDisability() {
		return partialDisability;
	}

	public void setPartialDisability(Integer partialDisability) {
		this.partialDisability = partialDisability;
	}

	public Date getDisabilityStartDt() {
		return disabilityStartDt;
	}

	public void setDisabilityStartDt(Date disabilityStartDt) {
		this.disabilityStartDt = disabilityStartDt;
	}

	public Date getDisabilityEndDt() {
		return disabilityEndDt;
	}

	public void setDisabilityEndDt(Date disabilityEndDt) {
		this.disabilityEndDt = disabilityEndDt;
	}

	public String getDoubleIndemnity() {
		return doubleIndemnity;
	}

	public void setDoubleIndemnity(String doubleIndemnity) {
		this.doubleIndemnity = doubleIndemnity;
	}

	public String getAiCode() {
		return aiCode;
	}

	public void setAiCode(String aiCode) {
		this.aiCode = aiCode;
	}

	public List<ClaimBrokenBone> getBrokenBones() {
		return brokenBones;
	}

	public void setBrokenBones(List<ClaimBrokenBone> brokenBones) {
		this.brokenBones = brokenBones;
	}

	public String getHbpType() {
		return hbpType;
	}

	public void setHbpType(String hbpType) {
		this.hbpType = hbpType;
	}

	public String getDiseaseInd() {
		return diseaseInd;
	}

	public void setDiseaseInd(String diseaseInd) {
		this.diseaseInd = diseaseInd;
	}

	public String getHbjSurgeryInd() {
		return hbjSurgeryInd;
	}

	public void setHbjSurgeryInd(String hbjSurgeryInd) {
		this.hbjSurgeryInd = hbjSurgeryInd;
	}

	public String getMajorAccid() {
		return majorAccid;
	}

	public void setMajorAccid(String majorAccid) {
		this.majorAccid = majorAccid;
	}

	public String getAnesthesiaInd() {
		return anesthesiaInd;
	}

	public void setAnesthesiaInd(String anesthesiaInd) {
		this.anesthesiaInd = anesthesiaInd;
	}

	public String getMajorInjuryDetail() {
		return majorInjuryDetail;
	}

	public void setMajorInjuryDetail(String majorInjuryDetail) {
		this.majorInjuryDetail = majorInjuryDetail;
	}

	public List<ClaimComment> getClaimComments() {
		return claimComments;
	}

	public void setClaimComments(List<ClaimComment> claimComments) {
		this.claimComments = claimComments;
	}

	public BenefitDeterminationPaymentRefreshForm getBenefitDeterminationPaymentRefreshForm() {
		return benefitDeterminationPaymentRefreshForm;
	}

	public void setBenefitDeterminationPaymentRefreshForm(
			BenefitDeterminationPaymentRefreshForm benefitDeterminationPaymentRefreshForm) {
		this.benefitDeterminationPaymentRefreshForm = benefitDeterminationPaymentRefreshForm;
	}

	public boolean isQuotationClaim() {
		return quotationClaim;
	}

	public void setQuotationClaim(boolean quotationClaim) {
		this.quotationClaim = quotationClaim;
	}

	public String getHn() {
		return hn;
	}

	public void setHn(String hn) {
		this.hn = hn;
	}

	public String getAn() {
		return an;
	}

	public void setAn(String an) {
		this.an = an;
	}

	public BigDecimal getCsHBAmt() {
		return csHBAmt;
	}

	public void setCsHBAmt(BigDecimal csHBAmt) {
		this.csHBAmt = csHBAmt;
	}
	
	public Integer getPtcall() {
		return ptcall;
	}

	public void setPtcall(Integer ptcall) {
		this.ptcall = ptcall;
	}

	public String getAttainAge() {
		return attainAge;
	}

	public String getHbpgHbxHomeMed() {
		return hbpgHbxHomeMed;
	}

	public void setAttainAge(String attainAge) {
		this.attainAge = attainAge;
	}

	public void setHbpgHbxHomeMed(String hbpgHbxHomeMed) {
		this.hbpgHbxHomeMed = hbpgHbxHomeMed;
	}

	public String getIpdDrug() {
		return ipdDrug;
	}

	public void setIpdDrug(String ipdDrug) {
		this.ipdDrug = ipdDrug;
	}
	
	public String getCleanInd() {
		return cleanInd;
	}

	public String getInterestInd() {
		return interestInd;
	}

	public void setCleanInd(String cleanInd) {
		this.cleanInd = cleanInd;
	}

	public void setInterestInd(String interestInd) {
		this.interestInd = interestInd;
	}

	public List<EdiBillingItem> getEdiBillings() {
		return ediBillings;
	}

	public void setEdiBillings(List<EdiBillingItem> ediBillings) {
		this.ediBillings = ediBillings;
	}

	public List<EdiOrderItem> getEdiOrderItems() {
		return ediOrderItems;
	}

	public void setEdiOrderItems(List<EdiOrderItem> ediOrderItems) {
		this.ediOrderItems = ediOrderItems;
	}

	public List<EdiLaboratory> getEdiLaboratories() {
		return ediLaboratories;
	}

	public void setEdiLaboratories(List<EdiLaboratory> ediLaboratories) {
		this.ediLaboratories = ediLaboratories;
	}

	public List<EdiProcedure> getEdiProcedures() {
		return ediProcedures;
	}

	public void setEdiProcedures(List<EdiProcedure> ediProcedures) {
		this.ediProcedures = ediProcedures;
	}

	public List<EdiVitalSigns> getEdiVitalSigns() {
		return ediVitalSigns;
	}

	public void setEdiVitalSigns(List<EdiVitalSigns> ediVitalSigns) {
		this.ediVitalSigns = ediVitalSigns;
	}

	public List<EdiDoctor> getEdiDoctors() {
		return ediDoctors;
	}

	public void setEdiDoctors(List<EdiDoctor> ediDoctors) {
		this.ediDoctors = ediDoctors;
	}

	public List<ClaimCriticalIllness> getClaimCriticalIllnesss() {
		return claimCriticalIllnesss;
	}

	public void setClaimCriticalIllnesss(List<ClaimCriticalIllness> claimCriticalIllnesss) {
		this.claimCriticalIllnesss = claimCriticalIllnesss;
	}
	

}
