package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomeIndexingSearchResult {

	private static final Logger LOG = LoggerFactory.getLogger(IndexingSubmitForm.class);
	private BigDecimal caseId;
	private Date dateReceive;
	String channel;
	int totalPage;
	String policyNo;
	private String memberId;
	private String scanType;
	private String scanBatchId;
	private String comment;

	public HomeIndexingSearchResult() {

	}

	public final BigDecimal getCaseId() {
		return caseId;
	}

	public final void setCaseId(BigDecimal caseId) {
		this.caseId = caseId;
	}

	public final Date getDateReceive() {
		return dateReceive;
	}

	public final void setDateReceive(Date dateReceive) {
		this.dateReceive = dateReceive;
	}

	public final String getChannel() {
		return channel;
	}

	public final void setChannel(String channel) {
		this.channel = channel;
	}

	public final int getTotalPage() {
		return totalPage;
	}

	public final void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getMemberId() {
		return memberId;
	}

	public final void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public final String getScanType() {
		return scanType;
	}

	public final void setScanType(String scanType) {
		this.scanType = scanType;
	}

	public final String getScanBatchId() {
		return scanBatchId;
	}

	public final void setScanBatchId(String scanBatchId) {
		this.scanBatchId = scanBatchId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
