package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.util.FormatUtil;

public class LimitReport {

	String timeFrame;
	String claimNo;
	String benefitDesc;
	BigDecimal value;
	String unit;
	Date policyYearFromDt;
	Date policyYearToDt;

	//BigInteger sumSequenceNum;
	//String unitNum;

	String shareInd;
	BigDecimal outNetworkSumValue;
	String benRefCd;
	String prodCd;

	public LimitReport() {
	}

	public LimitReport(PolicyProductBenefitDetailCOAST ben, BenefitLimit lim) {
		this.benefitDesc = FormatUtil.convertNull(ben.getBenefitDesc());

		this.value = lim.getAmount();
		if ("P".equals(FormatUtil.convertNull(ben.getSumTimeFrame()).trim())) {
			this.timeFrame = "Year";
			this.claimNo = "";
		} else if ("B".equals(FormatUtil.convertNull(ben.getSumTimeFrame()).trim())) {
			this.timeFrame = "Claim";
			this.claimNo = lim.getClaimNo();
		}
		if ("A".equals(FormatUtil.convertNull(ben.getSumCategory()).trim())) {
			this.unit = "THB";
		} else if ("C".equals(FormatUtil.convertNull(ben.getSumCategory()).trim())) {
			this.unit = "Call";
		}
		this.policyYearFromDt = lim.getPolicyYearFromDt();
		this.policyYearToDt = lim.getPolicyYearToDt();
		this.shareInd = ben.getShareInd();
		this.outNetworkSumValue = ben.getOutNetworkSumValue();
		this.benRefCd = FormatUtil.convertNull(ben.getBenRefCd());
		this.prodCd = FormatUtil.convertNull(ben.getProdCd());
		//System.out.println(this.toString());
	}

	public String getTimeFrame() {
		return timeFrame;
	}

	public void setTimeFrame(String timeFrame) {
		this.timeFrame = timeFrame;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getBenefitDesc() {
		return benefitDesc;
	}

	public void setBenefitDesc(String benefitDesc) {
		this.benefitDesc = benefitDesc;
	}

	public void addBenefitDesc(String benefitDesc) {
		if(FormatUtil.haveValue(this.benefitDesc)){
			if(!this.benefitDesc.contains(benefitDesc)){
				this.benefitDesc = this.benefitDesc + ", " + benefitDesc;
			}
		}else{
			this.benefitDesc = benefitDesc;
		}
	}
	
	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public String getShareInd() {
		return shareInd;
	}

	public void setShareInd(String shareInd) {
		this.shareInd = shareInd;
	}

	public BigDecimal getOutNetworkSumValue() {
		return outNetworkSumValue;
	}

	public void setOutNetworkSumValue(BigDecimal outNetworkSumValue) {
		this.outNetworkSumValue = outNetworkSumValue;
	}

	public String getBenRefCd() {
		return benRefCd;
	}

	public void setBenRefCd(String benRefCd) {
		this.benRefCd = benRefCd;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getProdCd() {
		return prodCd;
	}

	public void setProdCd(String prodCd) {
		this.prodCd = prodCd;
	}
}
