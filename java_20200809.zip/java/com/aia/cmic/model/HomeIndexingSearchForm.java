package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomeIndexingSearchForm {

	private static final Logger LOG = LoggerFactory.getLogger(IndexingSubmitForm.class);
	String policyNo;
	String location;
	String channel;
	String insuredName;
	String insuredLastName;

	public HomeIndexingSearchForm() {

	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getLocation() {
		return location;
	}

	public final void setLocation(String location) {
		this.location = location;
	}

	public final String getChannel() {
		return channel;
	}

	public final void setChannel(String channel) {
		this.channel = channel;
	}

	public final String getInsuredName() {
		return insuredName;
	}

	public final void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public final String getInsuredLastName() {
		return insuredLastName;
	}

	public final void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
