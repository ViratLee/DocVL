package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BatchControlUpdate {

	String batchControlNum = "";
	List<BatchControlUpdateDetail> data = new ArrayList<BatchControlUpdateDetail>();

	/**
	 * @return the batchControlNum
	 */
	public String getBatchControlNum() {
		return batchControlNum;
	}

	/**
	 * @param batchControlNum the batchControlNum to set
	 */
	public void setBatchControlNum(String batchControlNum) {
		this.batchControlNum = batchControlNum;
	}


	public List<BatchControlUpdateDetail> getData() {
		return data;
	}

	public void setData(List<BatchControlUpdateDetail> data) {
		this.data = data;
	}


}
