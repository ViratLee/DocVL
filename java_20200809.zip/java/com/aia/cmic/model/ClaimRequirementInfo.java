package com.aia.cmic.model;

import java.util.Date;

public class ClaimRequirementInfo {

	Long claimRequirementInfoId;
	String claimNo;
	Integer occurrence;
	String target;
	String documentType;
	String pendingCode;
	String seqNo;
	String status;
	String requirementDetail;
	String resolveDetail;
	String letter;
	Date requestedDt;
	Date receivedDt;
	Date fulfilledDt;
	Date dueDt;
	String remark;
	String resolveInd;
	String resolveBy;
	Date resolveDt;
	String requestBy;

	public String getRequestBy() {
		return requestBy;
	}

	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}

	/**
	 * @return the claimRequirementInfoId
	 */
	public Long getClaimRequirementInfoId() {
		return claimRequirementInfoId;
	}

	/**
	 * @param claimRequirementInfoId the claimRequirementInfoId to set
	 */
	public void setClaimRequirementInfoId(Long claimRequirementInfoId) {
		this.claimRequirementInfoId = claimRequirementInfoId;
	}

	/**
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 */
	public String getClaimNo() {
		return this.claimNo;
	}

	/**
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 */
	public Integer getOccurrence() {
		return this.occurrence;
	}

	/**
	 * @return the target
	 */
	public String getTarget() {
		return target;
	}

	/**
	 * @param target the target to set
	 */
	public void setTarget(String target) {
		this.target = target;
	}

	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * @return the pendingCode
	 */
	public String getPendingCode() {
		return pendingCode;
	}

	/**
	 * @param pendingCode the pendingCode to set
	 */
	public void setPendingCode(String pendingCode) {
		this.pendingCode = pendingCode;
	}

	/**
	 * @return the seqNo
	 */
	public String getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the requirementDetail
	 */
	public String getRequirementDetail() {
		return requirementDetail;
	}

	/**
	 * @param requirementDetail the requirementDetail to set
	 */
	public void setRequirementDetail(String requirementDetail) {
		this.requirementDetail = requirementDetail;
	}

	/**
	 * @return the resolveDetail
	 */
	public String getResolveDetail() {
		return resolveDetail;
	}

	/**
	 * @param resolveDetail the resolveDetail to set
	 */
	public void setResolveDetail(String resolveDetail) {
		this.resolveDetail = resolveDetail;
	}

	/**
	 * @return the letter
	 */
	public String getLetter() {
		return letter;
	}

	/**
	 * @param letter the letter to set
	 */
	public void setLetter(String letter) {
		this.letter = letter;
	}

	/**
	 * @return the requestedDt
	 */
	public Date getRequestedDt() {
		return requestedDt;
	}

	/**
	 * @param requestedDt the requestedDt to set
	 */
	public void setRequestedDt(Date requestedDt) {
		this.requestedDt = requestedDt;
	}

	/**
	 * @return the receivedDt
	 */
	public Date getReceivedDt() {
		return receivedDt;
	}

	/**
	 * @param receivedDt the receivedDt to set
	 */
	public void setReceivedDt(Date receivedDt) {
		this.receivedDt = receivedDt;
	}

	/**
	 * @return the fulfilledDt
	 */
	public Date getFulfilledDt() {
		return fulfilledDt;
	}

	/**
	 * @param fulfilledDt the fulfilledDt to set
	 */
	public void setFulfilledDt(Date fulfilledDt) {
		this.fulfilledDt = fulfilledDt;
	}

	/**
	 * @return the dueDt
	 */
	public Date getDueDt() {
		return dueDt;
	}

	/**
	 * @param dueDt the dueDt to set
	 */
	public void setDueDt(Date dueDt) {
		this.dueDt = dueDt;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the resolveInd
	 */
	public String getResolveInd() {
		return resolveInd;
	}

	/**
	 * @param resolveInd the resolveInd to set
	 */
	public void setResolveInd(String resolveInd) {
		this.resolveInd = resolveInd;
	}

	/**
	 * @return the resolveBy
	 */
	public String getResolveBy() {
		return resolveBy;
	}

	/**
	 * @param resolveBy the resolveBy to set
	 */
	public void setResolveBy(String resolveBy) {
		this.resolveBy = resolveBy;
	}

	/**
	 * @return the resolveDt
	 */
	public Date getResolveDt() {
		return resolveDt;
	}

	/**
	 * @param resolveDt the resolveDt to set
	 */
	public void setResolveDt(Date resolveDt) {
		this.resolveDt = resolveDt;
	}

}
