package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.aia.cmic.repository.rest.response.policy.CoveragePartyRelation;
import com.aia.cmic.repository.rest.response.policy.HoldingPartyRelation;
import com.aia.schemas.adam.v2_5.party.v1.IndividualType;
import com.aia.schemas.retrievecontractinformationresponse.v1.CoverageType;
import com.aia.schemas.retrievecontractinformationresponse.v1.PolicyProductPlanRelnType;
import com.aia.schemas.retrievecontractinformationresponse.v1.PolicyProductRelnType;

public class ClaimPolicy {

	Long claimPolicyId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	String subOfficeCode;
	String subOfficeStatus;
	String certNo;
	String policyStatus;
	String policyStatusReason;
	String policyStatusPremiumHoliday;
	Date policyIssueDt;
	Date policyLapseDt;
	Date policyYearFromDt;
	Date policyYearToDt;
	String companyId;
	String businessLine;
	String policyHolder;
	String subOfficeName;
	String policyOwner;
	String productCode;
	String productName;
	String dependentType;
	String csProductCategory;
	String holdClaimInd;
	Date holdClaimDate;
	String claimHoldByInd;
	String releaseHoldClaimInd;
	Date releaseHoldClaimDate;
	String fullCreditInd;
	BigDecimal policyShortFallAmt;
	BigDecimal memberShortFallAmt;
	BigDecimal sumAssured;
	Date paidToDt;
	Date paidToCurrDt;
	Date applicationDt;
	Date contractDt;
	Date etiDt;
	Integer chgDaysBefore;
	Integer chgDaysAfter;
	Date paCoverDt;
	BigDecimal paBonusAmt;
	Date paBonusDt;
	BigDecimal paBonusDeductAmt;
	Date paidDt;
	Date reinstatementDt;
	Date nextAnniversaryDt;
	Date takeOverDt;
	String takeOverStatus;
	String paymentMode;
	BigDecimal modalPremium;
	String relationship;
	String occupationCode;
	String agentPolicyInd;
	String agentWritingCode;
	String agencyWritingCode;
	String servicingAgentCode;
	String servicingAgencyCode;
	String broker;
	String suppressInd;
	String marketingChannel;
	String marketingCampaign;
	String absoluteAssignInd;
	String egp;
	String planBasicCode;
	BigDecimal planBasicSumAssured;
	String impairmentCode1;
	String impairmentCode2;
	String impairmentCode3;
	String exclusion1;
	String exclusion2;
	String exclusion3;
	String chequeNo;
	String bankCheque;

	// for search result
	String dependentNo;
	com.aia.schemas.adam.v2_5.party.v1.IndividualType individualType;
	String payeeType;
	String productType;
	String partyId;
	String memberId;
	String memberFirstName;
	String memberLastName;
	String vip;
	boolean fromCOAST;
	List<Dependent> dependents;
	Set<String> partyIdOfChildren;
	String writingAgentPartyId;
	String servicingAgentPartyId;
	String distributionInd;
	String sendTo;
	String shortfallInd;
	String fcsInd;

	List<HoldingPartyRelation> holdingPartyRelationList = new ArrayList<HoldingPartyRelation>();
	CoveragePartyRelation coveragePartyRelation;
	List<SpecialCondition> specialConditions;
	List<DepartmentCode> departmentCodes;

	List<CoverageType> coverage;
	List<PolicyProductRelnType> policyProductReln;
	List<PolicyProductPlanRelnType> policyProductPlanReln;
	List<PolicyProductBenefitDetailCOAST> limitNonShareDetailGrid;
	List<PolicyProductBenefitDetailCOAST> limitSharedDetailGrid;

	String DepartmentCd;
	String DepartmentNm;
	String ClientNm;

	String policyEnglishInd;
	String letterEngInd;
	String contactPersonName;
	String businessSource;

	String status;
	String defaultMemberPayeeName;
	String defaultCompanyPayeeName;

	String corrNormal;
	String corrShortfall;
	
	String consentInd;
	Date consentDt;

	public String getDefaultMemberPayeeName() {
		return defaultMemberPayeeName;
	}

	public void setDefaultMemberPayeeName(String defaultMemberPayeeName) {
		this.defaultMemberPayeeName = defaultMemberPayeeName;
	}

	public String getDefaultCompanyPayeeName() {
		return defaultCompanyPayeeName;
	}

	public void setDefaultCompanyPayeeName(String defaultCompanyPayeeName) {
		this.defaultCompanyPayeeName = defaultCompanyPayeeName;
	}

	/**
	 * @return the claimPolicyId
	 */
	public Long getClaimPolicyId() {
		return claimPolicyId;
	}

	/**
	 * @param claimPolicyId the claimPolicyId to set
	 */
	public void setClaimPolicyId(Long claimPolicyId) {
		this.claimPolicyId = claimPolicyId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the subOfficeCode
	 */
	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	/**
	 * @param subOfficeCode the subOfficeCode to set
	 */
	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	/**
	 * @return the subOfficeStatus
	 */
	public String getSubOfficeStatus() {
		return subOfficeStatus;
	}

	/**
	 * @param subOfficeStatus the subOfficeStatus to set
	 */
	public void setSubOfficeStatus(String subOfficeStatus) {
		this.subOfficeStatus = subOfficeStatus;
	}

	/**
	 * @return the certNo
	 */
	public String getCertNo() {
		return certNo;
	}

	/**
	 * @param certNo the certNo to set
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	/**
	 * @return the policyStatus
	 */
	public String getPolicyStatus() {
		return policyStatus;
	}

	/**
	 * @param policyStatus the policyStatus to set
	 */
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	/**
	 * @return the policyStatusReason
	 */
	public String getPolicyStatusReason() {
		return policyStatusReason;
	}

	/**
	 * @param policyStatusReason the policyStatusReason to set
	 */
	public void setPolicyStatusReason(String policyStatusReason) {
		this.policyStatusReason = policyStatusReason;
	}

	/**
	 * @return the policyStatusPremiumHoliday
	 */
	public String getPolicyStatusPremiumHoliday() {
		return policyStatusPremiumHoliday;
	}

	/**
	 * @param policyStatusPremiumHoliday the policyStatusPremiumHoliday to set
	 */
	public void setPolicyStatusPremiumHoliday(String policyStatusPremiumHoliday) {
		this.policyStatusPremiumHoliday = policyStatusPremiumHoliday;
	}

	/**
	 * @return the policyIssueDt
	 */
	public Date getPolicyIssueDt() {
		return policyIssueDt;
	}

	/**
	 * @param policyIssueDt the policyIssueDt to set
	 */
	public void setPolicyIssueDt(Date policyIssueDt) {
		this.policyIssueDt = policyIssueDt;
	}

	/**
	 * @return the policyLapseDt
	 */
	public Date getPolicyLapseDt() {
		return policyLapseDt;
	}

	/**
	 * @param policyLapseDt the policyLapseDt to set
	 */
	public void setPolicyLapseDt(Date policyLapseDt) {
		this.policyLapseDt = policyLapseDt;
	}

	/**
	 * @return the policyYearFromDt
	 */
	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	/**
	 * @param policyYearFromDt the policyYearFromDt to set
	 */
	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	/**
	 * @return the policyYearToDt
	 */
	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	/**
	 * @param policyYearToDt the policyYearToDt to set
	 */
	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 * @return the policyHolder
	 */
	public String getPolicyHolder() {
		return policyHolder;
	}

	/**
	 * @param policyHolder the policyHolder to set
	 */
	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	/**
	 * @return the subOfficeName
	 */
	public String getSubOfficeName() {
		return subOfficeName;
	}

	/**
	 * @param subOfficeName the subOfficeName to set
	 */
	public void setSubOfficeName(String subOfficeName) {
		this.subOfficeName = subOfficeName;
	}

	/**
	 * @return the policyOwner
	 */
	public String getPolicyOwner() {
		return policyOwner;
	}

	/**
	 * @param policyOwner the policyOwner to set
	 */
	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the csProductCategory
	 */
	public String getCsProductCategory() {
		return csProductCategory;
	}

	/**
	 * @param csProductCategory the csProductCategory to set
	 */
	public void setCsProductCategory(String csProductCategory) {
		this.csProductCategory = csProductCategory;
	}

	/**
	 * @return the holdClaimInd
	 */
	public String getHoldClaimInd() {
		return holdClaimInd;
	}

	/**
	 * @param holdClaimInd the holdClaimInd to set
	 */
	public void setHoldClaimInd(String holdClaimInd) {
		this.holdClaimInd = holdClaimInd;
	}

	/**
	 * @return the holdClaimDate
	 */
	public Date getHoldClaimDate() {
		return holdClaimDate;
	}

	/**
	 * @param holdClaimDate the holdClaimDate to set
	 */
	public void setHoldClaimDate(Date holdClaimDate) {
		this.holdClaimDate = holdClaimDate;
	}

	public String getClaimHoldByInd() {
		return claimHoldByInd;
	}

	public void setClaimHoldByInd(String claimHoldByInd) {
		this.claimHoldByInd = claimHoldByInd;
	}

	/**
	 * @return the releaseHoldClaimInd
	 */
	public String getReleaseHoldClaimInd() {
		return releaseHoldClaimInd;
	}

	/**
	 * @param releaseHoldClaimInd the releaseHoldClaimInd to set
	 */
	public void setReleaseHoldClaimInd(String releaseHoldClaimInd) {
		this.releaseHoldClaimInd = releaseHoldClaimInd;
	}

	/**
	 * @return the releaseHoldClaimDate
	 */
	public Date getReleaseHoldClaimDate() {
		return releaseHoldClaimDate;
	}

	/**
	 * @param releaseHoldClaimDate the releaseHoldClaimDate to set
	 */
	public void setReleaseHoldClaimDate(Date releaseHoldClaimDate) {
		this.releaseHoldClaimDate = releaseHoldClaimDate;
	}

	/**
	 * @return the fullCreditInd
	 */
	public String getFullCreditInd() {
		return fullCreditInd;
	}

	/**
	 * @param fullCreditInd the fullCreditInd to set
	 */
	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	/**
	 * @return the policyShortFallAmt
	 */
	public BigDecimal getPolicyShortFallAmt() {
		return policyShortFallAmt;
	}

	/**
	 * @param policyShortFallAmt the policyShortFallAmt to set
	 */
	public void setPolicyShortFallAmt(BigDecimal policyShortFallAmt) {
		this.policyShortFallAmt = policyShortFallAmt;
	}

	/**
	 * @return the memberShortFallAmt
	 */
	public BigDecimal getMemberShortFallAmt() {
		return memberShortFallAmt;
	}

	/**
	 * @param memberShortFallAmt the memberShortFallAmt to set
	 */
	public void setMemberShortFallAmt(BigDecimal memberShortFallAmt) {
		this.memberShortFallAmt = memberShortFallAmt;
	}

	/**
	 * @return the sumAssured
	 */
	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	/**
	 * @return the paidToDt
	 */
	public Date getPaidToDt() {
		return paidToDt;
	}

	/**
	 * @param paidToDt the paidToDt to set
	 */
	public void setPaidToDt(Date paidToDt) {
		this.paidToDt = paidToDt;
	}

	/**
	 * @return the paidToCurrDt
	 */
	public Date getPaidToCurrDt() {
		return paidToCurrDt;
	}

	/**
	 * @param paidToCurrDt the paidToCurrDt to set
	 */
	public void setPaidToCurrDt(Date paidToCurrDt) {
		this.paidToCurrDt = paidToCurrDt;
	}

	/**
	 * @return the applicationDt
	 */
	public Date getApplicationDt() {
		return applicationDt;
	}

	/**
	 * @param applicationDt the applicationDt to set
	 */
	public void setApplicationDt(Date applicationDt) {
		this.applicationDt = applicationDt;
	}

	/**
	 * @return the contractDt
	 */
	public Date getContractDt() {
		return contractDt;
	}

	/**
	 * @param contractDt the contractDt to set
	 */
	public void setContractDt(Date contractDt) {
		this.contractDt = contractDt;
	}

	/**
	 * @return the etiDt
	 */
	public Date getEtiDt() {
		return etiDt;
	}

	/**
	 * @param etiDt the etiDt to set
	 */
	public void setEtiDt(Date etiDt) {
		this.etiDt = etiDt;
	}

	/**
	 * @return the chgDaysBefore
	 */
	public Integer getChgDaysBefore() {
		return chgDaysBefore;
	}

	/**
	 * @param chgDaysBefore the chgDaysBefore to set
	 */
	public void setChgDaysBefore(Integer chgDaysBefore) {
		this.chgDaysBefore = chgDaysBefore;
	}

	/**
	 * @return the chgDaysAfter
	 */
	public Integer getChgDaysAfter() {
		return chgDaysAfter;
	}

	/**
	 * @param chgDaysAfter the chgDaysAfter to set
	 */
	public void setChgDaysAfter(Integer chgDaysAfter) {
		this.chgDaysAfter = chgDaysAfter;
	}

	/**
	 * @return the paCoverDt
	 */
	public Date getPaCoverDt() {
		return paCoverDt;
	}

	/**
	 * @param paCoverDt the paCoverDt to set
	 */
	public void setPaCoverDt(Date paCoverDt) {
		this.paCoverDt = paCoverDt;
	}

	/**
	 * @return the paBonusAmt
	 */
	public BigDecimal getPaBonusAmt() {
		return paBonusAmt;
	}

	/**
	 * @param paBonusAmt the paBonusAmt to set
	 */
	public void setPaBonusAmt(BigDecimal paBonusAmt) {
		this.paBonusAmt = paBonusAmt;
	}

	/**
	 * @return the paBonusDt
	 */
	public Date getPaBonusDt() {
		return paBonusDt;
	}

	/**
	 * @param paBonusDt the paBonusDt to set
	 */
	public void setPaBonusDt(Date paBonusDt) {
		this.paBonusDt = paBonusDt;
	}

	/**
	 * @return the paBonusDeductAmt
	 */
	public BigDecimal getPaBonusDeductAmt() {
		return paBonusDeductAmt;
	}

	/**
	 * @param paBonusDeductAmt the paBonusDeductAmt to set
	 */
	public void setPaBonusDeductAmt(BigDecimal paBonusDeductAmt) {
		this.paBonusDeductAmt = paBonusDeductAmt;
	}

	/**
	 * @return the paidDt
	 */
	public Date getPaidDt() {
		return paidDt;
	}

	/**
	 * @param paidDt the paidDt to set
	 */
	public void setPaidDt(Date paidDt) {
		this.paidDt = paidDt;
	}

	/**
	 * @return the reinstatementDt
	 */
	public Date getReinstatementDt() {
		return reinstatementDt;
	}

	/**
	 * @param reinstatementDt the reinstatementDt to set
	 */
	public void setReinstatementDt(Date reinstatementDt) {
		this.reinstatementDt = reinstatementDt;
	}

	/**
	 * @return the nextAnniversaryDt
	 */
	public Date getNextAnniversaryDt() {
		return nextAnniversaryDt;
	}

	/**
	 * @param nextAnniversaryDt the nextAnniversaryDt to set
	 */
	public void setNextAnniversaryDt(Date nextAnniversaryDt) {
		this.nextAnniversaryDt = nextAnniversaryDt;
	}

	/**
	 * @return the takeOverDt
	 */
	public Date getTakeOverDt() {
		return takeOverDt;
	}

	/**
	 * @param takeOverDt the takeOverDt to set
	 */
	public void setTakeOverDt(Date takeOverDt) {
		this.takeOverDt = takeOverDt;
	}

	/**
	 * @return the takeOverStatus
	 */
	public String getTakeOverStatus() {
		return takeOverStatus;
	}

	/**
	 * @param takeOverStatus the takeOverStatus to set
	 */
	public void setTakeOverStatus(String takeOverStatus) {
		this.takeOverStatus = takeOverStatus;
	}

	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}

	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	/**
	 * @return the modalPremium
	 */
	public BigDecimal getModalPremium() {
		return modalPremium;
	}

	/**
	 * @param modalPremium the modalPremium to set
	 */
	public void setModalPremium(BigDecimal modalPremium) {
		this.modalPremium = modalPremium;
	}

	/**
	 * @return the relationship
	 */
	public String getRelationship() {
		return relationship;
	}

	/**
	 * @param relationship the relationship to set
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 * @return the occupationCode
	 */
	public String getOccupationCode() {
		return occupationCode;
	}

	/**
	 * @param occupationCode the occupationCode to set
	 */
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	/**
	 * @return the agentPolicyInd
	 */
	public String getAgentPolicyInd() {
		return agentPolicyInd;
	}

	/**
	 * @param agentPolicyInd the agentPolicyInd to set
	 */
	public void setAgentPolicyInd(String agentPolicyInd) {
		this.agentPolicyInd = agentPolicyInd;
	}

	/**
	 * @return the agentWritingCode
	 */
	public String getAgentWritingCode() {
		return agentWritingCode;
	}

	/**
	 * @param agentWritingCode the agentWritingCode to set
	 */
	public void setAgentWritingCode(String agentWritingCode) {
		this.agentWritingCode = agentWritingCode;
	}

	/**
	 * @return the agencyWritingCode
	 */
	public String getAgencyWritingCode() {
		return agencyWritingCode;
	}

	/**
	 * @param agencyWritingCode the agencyWritingCode to set
	 */
	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	/**
	 * @return the broker
	 */
	public String getBroker() {
		return broker;
	}

	/**
	 * @param broker the broker to set
	 */
	public void setBroker(String broker) {
		this.broker = broker;
	}

	/**
	 * @return the suppressInd
	 */
	public String getSuppressInd() {
		return suppressInd;
	}

	/**
	 * @param suppressInd the suppressInd to set
	 */
	public void setSuppressInd(String suppressInd) {
		this.suppressInd = suppressInd;
	}

	/**
	 * @return the marketingChannel
	 */
	public String getMarketingChannel() {
		return marketingChannel;
	}

	/**
	 * @param marketingChannel the marketingChannel to set
	 */
	public void setMarketingChannel(String marketingChannel) {
		this.marketingChannel = marketingChannel;
	}

	/**
	 * @return the marketingCampaign
	 */
	public String getMarketingCampaign() {
		return marketingCampaign;
	}

	/**
	 * @param marketingCampaign the marketingCampaign to set
	 */
	public void setMarketingCampaign(String marketingCampaign) {
		this.marketingCampaign = marketingCampaign;
	}

	/**
	 * @return the absoluteAssignInd
	 */
	public String getAbsoluteAssignInd() {
		return absoluteAssignInd;
	}

	/**
	 * @param absoluteAssignInd the absoluteAssignInd to set
	 */
	public void setAbsoluteAssignInd(String absoluteAssignInd) {
		this.absoluteAssignInd = absoluteAssignInd;
	}

	/**
	 * @return the egp
	 */
	public String getEgp() {
		return egp;
	}

	/**
	 * @param egp the egp to set
	 */
	public void setEgp(String egp) {
		this.egp = egp;
	}

	/**
	 * @return the planBasicCode
	 */
	public String getPlanBasicCode() {
		return planBasicCode;
	}

	/**
	 * @param planBasicCode the planBasicCode to set
	 */
	public void setPlanBasicCode(String planBasicCode) {
		this.planBasicCode = planBasicCode;
	}

	/**
	 * @return the planBasicSumAssured
	 */
	public BigDecimal getPlanBasicSumAssured() {
		return planBasicSumAssured;
	}

	/**
	 * @param planBasicSumAssured the planBasicSumAssured to set
	 */
	public void setPlanBasicSumAssured(BigDecimal planBasicSumAssured) {
		this.planBasicSumAssured = planBasicSumAssured;
	}

	/**
	 * @return the impairmentCode1
	 */
	public String getImpairmentCode1() {
		return impairmentCode1;
	}

	/**
	 * @param impairmentCode1 the impairmentCode1 to set
	 */
	public void setImpairmentCode1(String impairmentCode1) {
		this.impairmentCode1 = impairmentCode1;
	}

	/**
	 * @return the impairmentCode2
	 */
	public String getImpairmentCode2() {
		return impairmentCode2;
	}

	/**
	 * @param impairmentCode2 the impairmentCode2 to set
	 */
	public void setImpairmentCode2(String impairmentCode2) {
		this.impairmentCode2 = impairmentCode2;
	}

	/**
	 * @return the impairmentCode3
	 */
	public String getImpairmentCode3() {
		return impairmentCode3;
	}

	/**
	 * @param impairmentCode3 the impairmentCode3 to set
	 */
	public void setImpairmentCode3(String impairmentCode3) {
		this.impairmentCode3 = impairmentCode3;
	}

	/**
	 * @return the exclusion1
	 */
	public String getExclusion1() {
		return exclusion1;
	}

	/**
	 * @param exclusion1 the exclusion1 to set
	 */
	public void setExclusion1(String exclusion1) {
		this.exclusion1 = exclusion1;
	}

	/**
	 * @return the exclusion2
	 */
	public String getExclusion2() {
		return exclusion2;
	}

	/**
	 * @param exclusion2 the exclusion2 to set
	 */
	public void setExclusion2(String exclusion2) {
		this.exclusion2 = exclusion2;
	}

	/**
	 * @return the exclusion3
	 */
	public String getExclusion3() {
		return exclusion3;
	}

	/**
	 * @param exclusion3 the exclusion3 to set
	 */
	public void setExclusion3(String exclusion3) {
		this.exclusion3 = exclusion3;
	}

	/**
	 * @return the chequeNo
	 */
	public String getChequeNo() {
		return chequeNo;
	}

	/**
	 * @param chequeNo the chequeNo to set
	 */
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	/**
	 * @return the bankCheque
	 */
	public String getBankCheque() {
		return bankCheque;
	}

	/**
	 * @param bankCheque the bankCheque to set
	 */
	public void setBankCheque(String bankCheque) {
		this.bankCheque = bankCheque;
	}

	/**
	 * @return the dependentNo
	 */
	public String getDependentNo() {
		return dependentNo;
	}

	/**
	 * @param dependentNo the dependentNo to set
	 */
	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	/**
	 * @return the individualType
	 */
	public IndividualType getIndividualType() {
		return individualType;
	}

	/**
	 * @param individualType the individualType to set
	 */
	public void setIndividualType(IndividualType individualType) {
		this.individualType = individualType;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the partyId
	 */
	public String getPartyId() {
		return partyId;
	}

	/**
	 * @param partyId the partyId to set
	 */
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	/**
	 * @return the memberId
	 */
	public String getMemberId() {
		return memberId;
	}

	/**
	 * @param memberId the memberId to set
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the memberFirstName
	 */
	public String getMemberFirstName() {
		return memberFirstName;
	}

	/**
	 * @param memberFirstName the memberFirstName to set
	 */
	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	/**
	 * @return the memberLastName
	 */
	public String getMemberLastName() {
		return memberLastName;
	}

	/**
	 * @param memberLastName the memberLastName to set
	 */
	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	/**
	 * @return the vip
	 */
	public String getVip() {
		return vip;
	}

	/**
	 * @param vip the vip to set
	 */
	public void setVip(String vip) {
		this.vip = vip;
	}

	/**
	 * @return the dependents
	 */
	public List<Dependent> getDependents() {
		return dependents;
	}

	/**
	 * @param dependents the dependents to set
	 */
	public void setDependents(List<Dependent> dependents) {
		this.dependents = dependents;
	}

	/**
	 * @return the fromCOAST
	 */
	public boolean isFromCOAST() {
		return fromCOAST;
	}

	/**
	 * @param fromCOAST the fromCOAST to set
	 */
	public void setFromCOAST(boolean fromCOAST) {
		this.fromCOAST = fromCOAST;
	}

	public String getDependentType() {
		return dependentType;
	}

	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public Set<String> getPartyIdOfChildren() {
		return partyIdOfChildren;
	}

	public void setPartyIdOfChildren(Set<String> partyIdOfChildren) {
		this.partyIdOfChildren = partyIdOfChildren;
	}

	public List<HoldingPartyRelation> getHoldingPartyRelationList() {
		return holdingPartyRelationList;
	}

	public void setHoldingPartyRelationList(List<HoldingPartyRelation> holdingPartyRelationList) {
		this.holdingPartyRelationList = holdingPartyRelationList;
	}

	public CoveragePartyRelation getCoveragePartyRelation() {
		return coveragePartyRelation;
	}

	public void setCoveragePartyRelation(CoveragePartyRelation coveragePartyRelation) {
		this.coveragePartyRelation = coveragePartyRelation;
	}

	public String getWritingAgentPartyId() {
		return writingAgentPartyId;
	}

	public void setWritingAgentPartyId(String writingAgentPartyId) {
		this.writingAgentPartyId = writingAgentPartyId;
	}

	public String getServicingAgentPartyId() {
		return servicingAgentPartyId;
	}

	public void setServicingAgentPartyId(String servicingAgentPartyId) {
		this.servicingAgentPartyId = servicingAgentPartyId;
	}

	public List<SpecialCondition> getSpecialConditions() {
		return specialConditions;
	}

	public void setSpecialConditions(List<SpecialCondition> specialConditions) {
		this.specialConditions = specialConditions;
	}

	public List<CoverageType> getCoverage() {
		return coverage;
	}

	public void setCoverage(List<CoverageType> coverage) {
		this.coverage = coverage;
	}

	public List<PolicyProductRelnType> getPolicyProductReln() {
		return policyProductReln;
	}

	public void setPolicyProductReln(List<PolicyProductRelnType> policyProductReln) {
		this.policyProductReln = policyProductReln;
	}

	public List<PolicyProductPlanRelnType> getPolicyProductPlanReln() {
		return policyProductPlanReln;
	}

	public void setPolicyProductPlanReln(List<PolicyProductPlanRelnType> policyProductPlanReln) {
		this.policyProductPlanReln = policyProductPlanReln;
	}

	public List<PolicyProductBenefitDetailCOAST> getLimitNonShareDetailGrid() {
		return limitNonShareDetailGrid;
	}

	public void setLimitNonShareDetailGrid(List<PolicyProductBenefitDetailCOAST> limitNonShareDetailGrid) {
		this.limitNonShareDetailGrid = limitNonShareDetailGrid;
	}

	public List<PolicyProductBenefitDetailCOAST> getLimitSharedDetailGrid() {
		return limitSharedDetailGrid;
	}

	public void setLimitSharedDetailGrid(List<PolicyProductBenefitDetailCOAST> limitSharedDetailGrid) {
		this.limitSharedDetailGrid = limitSharedDetailGrid;
	}

	public String getDepartmentCd() {
		return DepartmentCd;
	}

	public void setDepartmentCd(String departmentCd) {
		DepartmentCd = departmentCd;
	}

	public String getDepartmentNm() {
		return DepartmentNm;
	}

	public void setDepartmentNm(String departmentNm) {
		DepartmentNm = departmentNm;
	}

	public String getClientNm() {
		return ClientNm;
	}

	public void setClientNm(String clientNm) {
		ClientNm = clientNm;
	}

	/**
	 * @return the distributionInd
	 */
	public String getDistributionInd() {
		return distributionInd;
	}

	/**
	 * @param distributionInd the distributionInd to set
	 */
	public void setDistributionInd(String distributionInd) {
		this.distributionInd = distributionInd;
	}

	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}

	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	/**
	 * @return the shortfallInd
	 */
	public String getShortfallInd() {
		return shortfallInd;
	}

	/**
	 * @param shortfallInd the shortfallInd to set
	 */
	public void setShortfallInd(String shortfallInd) {
		this.shortfallInd = shortfallInd;
	}

	/**
	 * @return the fcsInd
	 */
	public String getFcsInd() {
		return fcsInd;
	}

	/**
	 * @param fcsInd the fcsInd to set
	 */
	public void setFcsInd(String fcsInd) {
		this.fcsInd = fcsInd;
	}

	public String getPolicyEnglishInd() {
		return policyEnglishInd;
	}

	public void setPolicyEnglishInd(String policyEnglishInd) {
		this.policyEnglishInd = policyEnglishInd;
	}

	public String getLetterEngInd() {
		return letterEngInd;
	}

	public void setLetterEngInd(String letterEngInd) {
		this.letterEngInd = letterEngInd;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public List<DepartmentCode> getDepartmentCodes() {
		return departmentCodes;
	}

	public void setDepartmentCodes(List<DepartmentCode> departmentCodes) {
		this.departmentCodes = departmentCodes;
	}

	public String getBusinessSource() {
		return businessSource;
	}

	public void setBusinessSource(String businessSource) {
		this.businessSource = businessSource;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getServicingAgentCode() {
		return servicingAgentCode;
	}

	public String getServicingAgencyCode() {
		return servicingAgencyCode;
	}

	public void setServicingAgentCode(String servicingAgentCode) {
		this.servicingAgentCode = servicingAgentCode;
	}

	public void setServicingAgencyCode(String servicingAgencyCode) {
		this.servicingAgencyCode = servicingAgencyCode;
	}

	public String getCorrNormal() {
		return corrNormal;
	}

	public void setCorrNormal(String corrNormal) {
		this.corrNormal = corrNormal;
	}

	public String getCorrShortfall() {
		return corrShortfall;
	}

	public void setCorrShortfall(String corrShortfall) {
		this.corrShortfall = corrShortfall;
	}

	public String getConsentInd() {
		return consentInd;
	}

	public void setConsentInd(String consentInd) {
		this.consentInd = consentInd;
	}

	public Date getConsentDt() {
		return consentDt;
	}

	public void setConsentDt(Date consentDt) {
		this.consentDt = consentDt;
	}

}
