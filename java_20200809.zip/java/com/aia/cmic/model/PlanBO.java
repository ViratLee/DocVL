package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class PlanBO {
	private Long planId;
	private Boolean duplicateFlag;
	private Boolean mark;
	private String businessLine;
	private String productType;
	private String policyNo;
	private Integer furtherClaimDay;
	private Integer emergencyDay;
	private String productCode;
	private Integer subPlanCode;
	private String planCode;
	private String planShortName;
	private String planName;
	private String planStatus;
	private String planThaiDesc;
	private Date terminateDt;
	private Date effectiveDt;
	private Integer networkCode;
	private String networkBenefitInd;
	private String benefitType;
	private BigDecimal reserveCashPercentage;
	private BigDecimal reserveCashlessPercentage;
	private Long defaultPlanId;

	private String typeOfServiceIpd;
	private String typeOfServiceOpd;
	private String typeOfServiceDayCase;

	private String benefitTypeAccident;
	private String benefitTypeAssault;
	private String benefitTypeCancer;
	private String benefitTypeOthers;
	private String benefitTypeMaternity;
	private String benefitTypeDental;
	private String benefitTypeVision;
	private String healthCheckup;

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public Boolean getDuplicateFlag() {
		return duplicateFlag;
	}

	public void setDuplicateFlag(Boolean duplicateFlag) {
		this.duplicateFlag = duplicateFlag;
	}

	public Boolean getMark() {
		return mark;
	}

	public void setMark(Boolean mark) {
		this.mark = mark;
	}

	public Integer getFurtherClaimDay() {
		return furtherClaimDay;
	}

	public void setFurtherClaimDay(Integer furtherClaimDay) {
		this.furtherClaimDay = furtherClaimDay;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Integer getEmergencyDay() {
		return emergencyDay;
	}

	public void setEmergencyDay(Integer emergencyDay) {
		this.emergencyDay = emergencyDay;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Integer getSubPlanCode() {
		return subPlanCode;
	}

	public void setSubPlanCode(Integer subPlanCode) {
		this.subPlanCode = subPlanCode;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getPlanShortName() {
		return planShortName;
	}

	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getPlanStatus() {
		return planStatus;
	}

	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	public String getPlanThaiDesc() {
		return planThaiDesc;
	}

	public void setPlanThaiDesc(String planThaiDesc) {
		this.planThaiDesc = planThaiDesc;
	}

	public Date getEffectiveDt() {
		return effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getTerminateDt() {
		return terminateDt;
	}

	public void setTerminateDt(Date terminateDt) {
		this.terminateDt = terminateDt;
	}

	public Integer getNetworkCode() {
		return networkCode;
	}

	public void setNetworkCode(Integer networkCode) {
		this.networkCode = networkCode;
	}

	public String getNetworkBenefitInd() {
		return networkBenefitInd;
	}

	public void setNetworkBenefitInd(String networkBenefitInd) {
		this.networkBenefitInd = networkBenefitInd;
	}

	public String getBenefitType() {
		return benefitType;
	}

	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public BigDecimal getReserveCashPercentage() {
		return reserveCashPercentage;
	}

	public void setReserveCashPercentage(BigDecimal reserveCashPercentage) {
		this.reserveCashPercentage = reserveCashPercentage;
	}

	public BigDecimal getReserveCashlessPercentage() {
		return reserveCashlessPercentage;
	}

	public void setReserveCashlessPercentage(BigDecimal reserveCashlessPercentage) {
		this.reserveCashlessPercentage = reserveCashlessPercentage;
	}

	public String getTypeOfServiceIpd() {
		return typeOfServiceIpd;
	}

	public void setTypeOfServiceIpd(String typeOfServiceIpd) {
		this.typeOfServiceIpd = typeOfServiceIpd;
	}

	public String getTypeOfServiceOpd() {
		return typeOfServiceOpd;
	}

	public void setTypeOfServiceOpd(String typeOfServiceOpd) {
		this.typeOfServiceOpd = typeOfServiceOpd;
	}

	public String getTypeOfServiceDayCase() {
		return typeOfServiceDayCase;
	}

	public void setTypeOfServiceDayCase(String typeOfServiceDayCase) {
		this.typeOfServiceDayCase = typeOfServiceDayCase;
	}

	public String getBenefitTypeAccident() {
		return benefitTypeAccident;
	}

	public void setBenefitTypeAccident(String benefitTypeAccident) {
		this.benefitTypeAccident = benefitTypeAccident;
	}

	public String getBenefitTypeAssault() {
		return benefitTypeAssault;
	}

	public void setBenefitTypeAssault(String benefitTypeAssault) {
		this.benefitTypeAssault = benefitTypeAssault;
	}

	public String getBenefitTypeCancer() {
		return benefitTypeCancer;
	}

	public void setBenefitTypeCancer(String benefitTypeCancer) {
		this.benefitTypeCancer = benefitTypeCancer;
	}

	public String getBenefitTypeOthers() {
		return benefitTypeOthers;
	}

	public void setBenefitTypeOthers(String benefitTypeOthers) {
		this.benefitTypeOthers = benefitTypeOthers;
	}

	public String getBenefitTypeMaternity() {
		return benefitTypeMaternity;
	}

	public void setBenefitTypeMaternity(String benefitTypeMaternity) {
		this.benefitTypeMaternity = benefitTypeMaternity;
	}

	public String getBenefitTypeDental() {
		return benefitTypeDental;
	}

	public void setBenefitTypeDental(String benefitTypeDental) {
		this.benefitTypeDental = benefitTypeDental;
	}

	public String getBenefitTypeVision() {
		return benefitTypeVision;
	}

	public void setBenefitTypeVision(String benefitTypeVision) {
		this.benefitTypeVision = benefitTypeVision;
	}
	
	public String getHealthCheckup() {
		return healthCheckup;
	}

	public void setHealthCheckup(String healthCheckup) {
		this.healthCheckup = healthCheckup;
	}

	public Long getDefaultPlanId() {
		return defaultPlanId;
	}

	public void setDefaultPlanId(Long defaultPlanId) {
		this.defaultPlanId = defaultPlanId;
	}
}
