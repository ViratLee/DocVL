package com.aia.cmic.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.util.FormatUtil;
import com.aia.schemas.adam.v2_5.agreement.v1.PolicyProductBenSumType;
import com.aia.schemas.retrievecontractinformationresponse.v1.CoverageType;
import com.aia.schemas.retrievecontractinformationresponse.v1.PolicyProductBenRelnType;
import com.aia.schemas.retrievecontractinformationresponse.v1.PolicyProductPlanRelnType;
import com.aia.schemas.retrievecontractinformationresponse.v1.PolicyProductRelnType;

public class PolicyProductBenefitDetailCOAST {
	String uniqueKey;
	String prodCd;
	String benefitPlanCd;
	String planDesc;
	String benRefCd;
	String benefitDesc;
	//BigInteger sumSequenceNum;
	//String unitNum;
	String sumCategory;
	String sumTimeFrame;
	BigDecimal outNetworkSumValue;
	String shareInd;
	String shareLevel;
	String shareLimit;
	BigInteger sumSequenceNum;
	Integer accumulatorNo; 
	List<PolicyProductBenefitDetailCOAST> chill = new ArrayList<PolicyProductBenefitDetailCOAST>();

	//String shareInd;

	public PolicyProductBenefitDetailCOAST() {
	}

//	public PolicyProductBenefitDetailCOAST(PolicyProductRelnType pro, CoverageType cov, PolicyProductPlanRelnType plan, PolicyProductBenRelnType ben, PolicyProductBenSumType sum) {
//		this.prodCd = pro.getProdCd();//31201
//		this.benefitPlanCd = plan.getBenefitPlanCd();//001
//		this.planDesc = (plan.getPlanDesc() != null) ? plan.getPlanDesc().trim() : null;
//		this.benRefCd = ben.getBenRefCd();// C01
//		this.benefitDesc = (ben.getBenefitDesc() != null) ? ben.getBenefitDesc().trim() : null;
//		//this.sumSequenceNum = sum.getSumSequenceNum();
//		//this.unitNum = sum.getUnitNum();
//		this.sumCategory = sum.getSumCategory();
//		this.sumTimeFrame = sum.getSumTimeFrame();
//		this.outNetworkSumValue = sum.getOutNetworkSumValue();
//		this.shareInd = sum.getShareInd();
//		this.shareLevel = sum.getShareLevel();
//		this.shareLimit = sum.getShareLimit();
//		this.uniqueKey = FormatUtil.convertNullWithDefault(this.prodCd,"_") + FormatUtil.convertNullWithDefault(this.benefitPlanCd,"_")// 
//		+FormatUtil.convertNullWithDefault(this.benRefCd,"_") +  FormatUtil.convertBigIntegerToStringDefault(this.sumSequenceNum,"_")//
//		+FormatUtil.convertNullWithDefault(this.sumCategory,"_") + FormatUtil.convertNullWithDefault(this.sumTimeFrame,"_");
//	}
	
	public PolicyProductBenefitDetailCOAST(com.aia.cmic.model.ClaimPolicyCoverage claimPolicyCoverage){
		this.prodCd = claimPolicyCoverage.getProductCode();//31101
		this.benefitPlanCd ="";//001
		this.planDesc = "";//(plan.getPlanDesc() != null) ? plan.getPlanDesc().trim() : null;
		this.benRefCd =  claimPolicyCoverage.getBenefitCode();//C10
		this.benefitDesc = claimPolicyCoverage.getProductCode() + "-" +claimPolicyCoverage.getBenefitCode();//+"-"+claimPolicyCoverage.getSumSequenceNo() ;//(ben.getBenefitDesc() != null) ? ben.getBenefitDesc().trim() : null;
		//this.sumSequenceNum = sum.getSumSequenceNum();
		//this.unitNum = sum.getUnitNum();
		this.sumCategory = claimPolicyCoverage.getSumCategory();// A, C
		this.sumTimeFrame = claimPolicyCoverage.getSumTimeFrame();// B, P
		this.outNetworkSumValue = claimPolicyCoverage.getOutNetworkSumValue();
		//this.shareInd = claimPolicyCoverage.getShareInd();
		this.shareLevel = claimPolicyCoverage.getShareLevel();
		this.shareLimit = claimPolicyCoverage.getShareDesc();
		this.sumSequenceNum = BigInteger.valueOf(claimPolicyCoverage.getSumSequenceNo());//sum.getSequenceNum()
		this.accumulatorNo = claimPolicyCoverage.getAccumulatorNo();
		this.shareInd = (this.accumulatorNo == null || this.accumulatorNo == 0) ? "N" : "S";
		this.uniqueKey = FormatUtil.convertNullWithDefault(this.prodCd,"_") //FormatUtil.convertNullWithDefault(this.benefitPlanCd,"_")// 
		+FormatUtil.convertNullWithDefault(this.benRefCd,"_")+FormatUtil.convertNullWithDefault(this.sumCategory,"_") 
		+ FormatUtil.convertNullWithDefault(this.sumTimeFrame,"_");
		
	}

	public String getProdCd() {
		return prodCd;
	}

	public void setProdCd(String prodCd) {
		this.prodCd = prodCd;
	}

	public String getBenefitPlanCd() {
		return benefitPlanCd;
	}

	public void setBenefitPlanCd(String benefitPlanCd) {
		this.benefitPlanCd = benefitPlanCd;
	}

	public String getPlanDesc() {
		return planDesc;
	}

	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}

	public String getBenRefCd() {
		return benRefCd;
	}

	public void setBenRefCd(String benRefCd) {
		this.benRefCd = benRefCd;
	}

	public void addBenRefCd(String benRefCd) {
		if(FormatUtil.haveValue(this.benRefCd)){
			this.benRefCd = this.benRefCd + ", " + benRefCd;
		}else{
			this.benRefCd = benRefCd;
		}
	}

	public String getBenefitDesc() {
		return benefitDesc;
	}

	public void setBenefitDesc(String benefitDesc) {
		this.benefitDesc = benefitDesc;
	}
	
	public void addBenefitDesc(String benefitDesc) {
		if(FormatUtil.haveValue(this.benefitDesc)){
			this.benefitDesc = this.benefitDesc + ", " + benefitDesc;
		}else{
			this.benefitDesc = benefitDesc;
		}
	}

	public String getSumCategory() {
		return sumCategory;
	}

	public void setSumCategory(String sumCategory) {
		this.sumCategory = sumCategory;
	}

	public String getSumTimeFrame() {
		return sumTimeFrame;
	}

	public void setSumTimeFrame(String sumTimeFrame) {
		this.sumTimeFrame = sumTimeFrame;
	}

	public BigDecimal getOutNetworkSumValue() {
		return outNetworkSumValue;
	}

	public void setOutNetworkSumValue(BigDecimal outNetworkSumValue) {
		this.outNetworkSumValue = outNetworkSumValue;
	}

	public String getShareInd() {
		return shareInd;
	}

	public void setShareInd(String shareInd) {
		this.shareInd = shareInd;
	}

	public String getShareLevel() {
		return shareLevel;
	}

	public void setShareLevel(String shareLevel) {
		this.shareLevel = shareLevel;
	}

	public String getShareLimit() {
		return shareLimit;
	}

	public void setShareLimit(String shareLimit) {
		this.shareLimit = shareLimit;
	}
	
	public Integer getAccumulatorNo() {
		return accumulatorNo;
	}

	public void setAccumulatorNo(Integer accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	public List<PolicyProductBenefitDetailCOAST> getChill() {
		return chill;
	}

	public void setChill(List<PolicyProductBenefitDetailCOAST> chill) {
		this.chill = chill;
	}
	
	public String getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.uniqueKey == null) ? 0 : this.uniqueKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PolicyProductBenefitDetailCOAST other = (PolicyProductBenefitDetailCOAST) obj;
		return compare(this.uniqueKey, other.uniqueKey);
	
	}
	private <T> boolean compare(T o, T c) {
		if (o != null && c != null) {
			return o.equals(c);
		} else {
			return o == null && c == null;
		}
	}
	
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
