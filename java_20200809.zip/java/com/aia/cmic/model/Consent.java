package com.aia.cmic.model;

public class Consent {

	private String consentType;
	private String consentValue;
	private long consentSignDate;
	public String getConsentType() {
		return consentType;
	}
	public void setConsentType(String consentType) {
		this.consentType = consentType;
	}
	public String getConsentValue() {
		return consentValue;
	}
	public void setConsentValue(String consentValue) {
		this.consentValue = consentValue;
	}
	public long getConsentSignDate() {
		return consentSignDate;
	}
	public void setConsentSignDate(long consentSignDate) {
		this.consentSignDate = consentSignDate;
	}

	
}
