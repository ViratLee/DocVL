package com.aia.cmic.model;

public class DataPrivacyPolicy {

	private String policyNo;
	private String consentValue;
	private long consentDate;
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getConsentValue() {
		return consentValue;
	}
	public void setConsentValue(String consentValue) {
		this.consentValue = consentValue;
	}
	public long getConsentDate() {
		return consentDate;
	}
	public void setConsentDate(long consentDate) {
		this.consentDate = consentDate;
	}
	
	
}
