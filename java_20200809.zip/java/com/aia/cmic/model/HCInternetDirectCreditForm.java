package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class HCInternetDirectCreditForm {
	private List<DirectCreditModel> directCreditModel;
	private String returnCode;
	private String returnMessage;

	public List<DirectCreditModel> getDirectCreditModel() {
		return directCreditModel;
	}

	public void setDirectCreditModel(List<DirectCreditModel> directCreditModel) {
		this.directCreditModel = directCreditModel;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}