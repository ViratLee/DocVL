package com.aia.cmic.model;

import java.util.Date;

public class PhysicianBO {

	Long physicianId;
	String doctorCode;
	String companyId;
	String licenseNo;
	String type;
	String firstName;
	String lastName;
	String status;
	String specialist;
	Date effectiveFromDt;
	Date effectiveToDt;
	String deathInd;
	String blacklistInd;
	String blacklistReason;
	Date blacklistStartDate;
	Date blacklistEndDate;
	String prevDoctorCode;

	public String getPrevDoctorCode() {
		return prevDoctorCode;
	}

	public void setPrevDoctorCode(String prevDoctorCode) {
		this.prevDoctorCode = prevDoctorCode;
	}

	public Long getPhysicianId() {
		return physicianId;
	}

	public void setPhysicianId(Long physicianId) {
		this.physicianId = physicianId;
	}

	public String getDoctorCode() {
		return doctorCode;
	}

	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSpecialist() {
		return specialist;
	}

	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}

	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public String getDeathInd() {
		return deathInd;
	}

	public void setDeathInd(String deathInd) {
		this.deathInd = deathInd;
	}

	public String getBlacklistInd() {
		return blacklistInd;
	}

	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	public String getBlacklistReason() {
		return blacklistReason;
	}

	public void setBlacklistReason(String blacklistReason) {
		this.blacklistReason = blacklistReason;
	}

	public Date getBlacklistStartDate() {
		return blacklistStartDate;
	}

	public void setBlacklistStartDate(Date blacklistStartDate) {
		this.blacklistStartDate = blacklistStartDate;
	}

	public Date getBlacklistEndDate() {
		return blacklistEndDate;
	}

	public void setBlacklistEndDate(Date blacklistEndDate) {
		this.blacklistEndDate = blacklistEndDate;
	}

}
