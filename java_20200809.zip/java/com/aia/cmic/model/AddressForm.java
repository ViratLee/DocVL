package com.aia.cmic.model;

import java.util.Date;

public class AddressForm {

	//General Information
	private String addressID;
	private String addressNo;
	private String addressBuilding;
	private String providerNameEN;
	private String registeredNameTH;
	private String registeredNameEN;
	private String providerGroup;
	private String providerType;
	private String providerTypeSector;
	private Date registrationEffectiveDate;
	private Date registrationTerminationDate;
	private Date startOperationDate;
	private String registeredBed;
	private String operatedBed;
	private String icuBed;
	private String icuRoom;
	private String examinationRoom;

	private String[] codingUsed;
	private String[] serviceProvided;
	private String[] medicalSpecialty;
	private String[] awardAndAccreditation;
	private String aiaQualityTier;
	private String providerAffordabilityTier;
	private String iaScore;
	private String servicePriority;
	private String[] otherInsuranceParticipation;
	private String prioritizeFaxClaimScore;

	//Black List
	private String blacklistIndicator;
	private Date startDate;
	private Date endDate;
	private String blacklistReason;
	private String[] cmacWarningCode;

	private String[] holdServices;

}
