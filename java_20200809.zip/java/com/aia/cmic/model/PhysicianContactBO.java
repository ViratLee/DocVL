package com.aia.cmic.model;

public class PhysicianContactBO {
	private PhysicianBO physicianBo;
	private ProviderContactBO providerContactBo;

	public PhysicianContactBO(PhysicianBO physicianBo, ProviderContactBO providerContactBo) {
		super();
		this.physicianBo = physicianBo;
		this.providerContactBo = providerContactBo;
	}

	public PhysicianBO getPhysicianBO() {
		return physicianBo;
	}

	public void setPhysicianBO(PhysicianBO physicianBO) {
		this.physicianBo = physicianBO;
	}

	public ProviderContactBO getProviderContactBO() {
		return providerContactBo;
	}

	public void setProviderContactBO(ProviderContactBO providerContactBO) {
		this.providerContactBo = providerContactBO;
	}

}
