package com.aia.cmic.model;

import java.util.List;

public class BillingSubmit {
	private List<BillingForm> billingForms;
	private String userId;

	public List<BillingForm> getBillingForms() {
		return billingForms;
	}

	public void setBillingForms(List<BillingForm> billingForms) {
		this.billingForms = billingForms;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
