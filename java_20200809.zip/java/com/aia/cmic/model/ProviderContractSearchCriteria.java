package com.aia.cmic.model;

import java.util.Date;

public class ProviderContractSearchCriteria {
	private String providerId;
	private String providerName;
	private String providerType;
	private String province;
	private String region;
	private String providerContract;
	private String providerContractStatus;
	private String providerContractProcessStatus;
	private Date effectiveFromDt;
	private Date effectiveToDt;
	private Date expiryFromDt;
	private Date expiryToDt;

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getProviderContract() {
		return providerContract;
	}

	public void setProviderContract(String providerContract) {
		this.providerContract = providerContract;
	}

	public String getProviderContractStatus() {
		return providerContractStatus;
	}

	public void setProviderContractStatus(String providerContractStatus) {
		this.providerContractStatus = providerContractStatus;
	}

	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public Date getExpiryFromDt() {
		return expiryFromDt;
	}

	public void setExpiryFromDt(Date expiryFromDt) {
		this.expiryFromDt = expiryFromDt;
	}

	public Date getExpiryToDt() {
		return expiryToDt;
	}

	public void setExpiryToDt(Date expiryToDt) {
		this.expiryToDt = expiryToDt;
	}

	public String getProviderContractProcessStatus() {
		return providerContractProcessStatus;
	}

	public void setProviderContractProcessStatus(String providerContractProcessStatus) {
		this.providerContractProcessStatus = providerContractProcessStatus;
	}

}
