package com.aia.cmic.model;

import java.math.BigDecimal;

/**
 * Hold previous amount allocation info by product,benefitCode level
 * 
 * @author Ronald
 *
 */
public class PreviousClaimPaymentAllocation {

	public PreviousClaimPaymentAllocation() {
	}

	public PreviousClaimPaymentAllocation(Long planId, String planCoverageNo, String productType, String policyNo, String benefitCode, BigDecimal amountAllocated, Integer daysAllocated,
			BigDecimal percentageAllocated) {
		this.planId = planId;
		this.planCoverageNo = planCoverageNo;
		this.productType = productType;
		this.policyNo = policyNo;
		this.benefitCode = benefitCode;
		this.amountAllocated = amountAllocated;
		this.daysAllocated = daysAllocated;
		this.percentageAllocated = percentageAllocated;
	}

	private Long planId;
	private String planCoverageNo;
	private String productType;
	private String policyNo;
	private String benefitCode;

	private BigDecimal amountAllocated = BigDecimal.ZERO;
	private Integer daysAllocated = 0;
	private BigDecimal percentageAllocated = BigDecimal.ZERO;
	private Integer callAllocated = 0;
	private BigDecimal presentedPercentage = BigDecimal.ZERO;

	/**
	 * @return the planName
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planName the planName to set
	 */
	public void setPlanId(Long planName) {
		this.planId = planName;
	}

	/**
	 * @return the planCoverageId
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageId to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the benefitCode
	 */
	public String getBenefitCode() {
		return benefitCode;
	}

	/**
	 * @param benefitCode the benefitCode to set
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 * @return the amountAllocated
	 */
	public BigDecimal getAmountAllocated() {
		return amountAllocated;
	}

	/**
	 * @param amountAllocated the amountAllocated to set
	 */
	public void setAmountAllocated(BigDecimal amountAllocated) {
		this.amountAllocated = amountAllocated;
	}

	/**
	 * @return the daysAllocated
	 */
	public Integer getDaysAllocated() {
		return daysAllocated;
	}

	/**
	 * @param daysAllocated the daysAllocated to set
	 */
	public void setDaysAllocated(Integer daysAllocated) {
		this.daysAllocated = daysAllocated;
	}

	/**
	 * @return the percentageAllocated
	 */
	public BigDecimal getPercentageAllocated() {
		return percentageAllocated;
	}

	/**
	 * @param percentageAllocated the percentageAllocated to set
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 * @return the callAllocated
	 */
	public Integer getCallAllocated() {
		return callAllocated;
	}

	/**
	 * @param callAllocated the callAllocated to set
	 */
	public void setCallAllocated(Integer callAllocated) {
		this.callAllocated = callAllocated;
	}

	/**
	 * @return the presentedPercentage
	 */
	public BigDecimal getPresentedPercentage() {
		return presentedPercentage == null ? BigDecimal.ZERO : presentedPercentage;
	}

	/**
	 * @param presentedPercentage the presentedPercentage to set
	 */
	public void setPresentedPercentage(BigDecimal presentedPercentage) {
		this.presentedPercentage = presentedPercentage;
	}

}
