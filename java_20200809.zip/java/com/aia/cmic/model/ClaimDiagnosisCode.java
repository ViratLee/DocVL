package com.aia.cmic.model;

import java.math.BigDecimal;

public class ClaimDiagnosisCode {

	private Long claimSupplementId;
	private String codeType;
	private String strValue;
	private BigDecimal intValue;
	private String primaryInd;
	private String codeDesc;

	/**
	 * @return the claimSupplementId
	 */
	public Long getClaimSupplementId() {
		return claimSupplementId;
	}

	/**
	 * @param claimSupplementId the claimSupplementId to set
	 */
	public void setClaimSupplementId(Long claimSupplementId) {
		this.claimSupplementId = claimSupplementId;
	}

	/**
	 * @return the codeType
	 */
	public String getCodeType() {
		return codeType;
	}

	/**
	 * @param codeType the codeType to set
	 */
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	/**
	 * @return the strValue
	 */
	public String getStrValue() {
		return strValue;
	}

	/**
	 * @param strValue the strValue to set
	 */
	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	/**
	 * @return the intValue
	 */
	public BigDecimal getIntValue() {
		return intValue;
	}

	/**
	 * @param intValue the intValue to set
	 */
	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}

	/**
	 * @return the primaryInd
	 */
	public String getPrimaryInd() {
		return primaryInd;
	}

	/**
	 * @param primaryInd the primaryInd to set
	 */
	public void setPrimaryInd(String primaryInd) {
		this.primaryInd = primaryInd;
	}
	
	@Override
	public boolean equals(Object o) {
		if(o != null && strValue.equalsIgnoreCase(((ClaimDiagnosisCode)o).getStrValue())){
			return true;
		}
		return false;
	}

	public String getCodeDesc() {
		return codeDesc;
	}

	public void setCodeDesc(String codeDesc) {
		this.codeDesc = codeDesc;
	}

}
