package com.aia.cmic.model;

import java.util.Date;

public class SystemConfig {
	String paramkey;
	String paramvalue;
	String createdby;
	Date createddt;
	String lastmodifiedby;
	Date lastmodifieddt;

	public String getParamkey() {
		return paramkey;
	}

	public void setParamkey(String paramkey) {
		this.paramkey = paramkey;
	}

	public String getParamvalue() {
		return paramvalue;
	}

	public void setParamvalue(String paramvalue) {
		this.paramvalue = paramvalue;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Date getCreateddt() {
		return createddt;
	}

	public void setCreateddt(Date createddt) {
		this.createddt = createddt;
	}

	public String getLastmodifiedby() {
		return lastmodifiedby;
	}

	public void setLastmodifiedby(String lastmodifiedby) {
		this.lastmodifiedby = lastmodifiedby;
	}

	public Date getLastmodifieddt() {
		return lastmodifieddt;
	}

	public void setLastmodifieddt(Date lastmodifieddt) {
		this.lastmodifieddt = lastmodifieddt;
	}

}
