/**
 * 
 */
package com.aia.cmic.model;

/**
 * 
 * @author Ronald
 *
 */
public class PreviousHBPHospitalization {
	
	private Integer prevHBPGx3Day =0;
	private Integer hospitalizationDays =0;
	/**
	 * @return the prevHBPGx3Day
	 */
	public Integer getPrevHBPGx3Day() {
		return prevHBPGx3Day;
	}
	/**
	 * @param prevHBPGx3Day the prevHBPGx3Day to set
	 */
	public void setPrevHBPGx3Day(Integer prevHBPGx3Day) {
		this.prevHBPGx3Day = prevHBPGx3Day;
	}
	/**
	 * @return the hospitalizationDays
	 */
	public Integer getHospitalizationDays() {
		return hospitalizationDays;
	}
	/**
	 * @param hospitalizationDays the hospitalizationDays to set
	 */
	public void setHospitalizationDays(Integer hospitalizationDays) {
		this.hospitalizationDays = hospitalizationDays;
	}
	

}
