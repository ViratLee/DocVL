package com.aia.cmic.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class BenefitSettlePolicyDetail {
	@XmlElement(name = "policyNo")
	String policyNo = "";
	@XmlElement(name = "certificateNo")
	String certificateNo = "";
	@XmlElement(name = "subOfficeCd")
	String subOfficeCd = "";
	@XmlElement(name = "employerName")
	String employerName = "";
	@XmlElement(name = "dependentNo")
	String dependentNo = "";
	@XmlElement(name = "claimantName")
	String claimantName = "";
	@XmlElement(name = "diagnosisCode")
	String diagnosisCode = "";
	@XmlElement(name = "incidentDate")
	Date incidentDate;

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getClaimantName() {
		return claimantName;
	}

	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}

	public String getDiagnosisCode() {
		return diagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}

	public Date getIncidentDate() {
		return incidentDate;
	}

	public void setIncidentDate(Date incidentDate) {
		this.incidentDate = incidentDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	public String getSubOfficeCd() {
		return subOfficeCd;
	}

	public void setSubOfficeCd(String subOfficeCd) {
		this.subOfficeCd = subOfficeCd;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

}
