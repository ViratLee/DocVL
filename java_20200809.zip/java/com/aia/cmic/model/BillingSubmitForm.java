package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.util.FormatUtil;

public class BillingSubmitForm {

	private static final Logger LOG = LoggerFactory.getLogger(BillingSubmitForm.class);

	private List<Long> claimId;
	private List<String> claimNo;
	private List<Long> caseId;
	private List<String> decision;
	private List<String> reason;

	public static BillingSubmitForm convertToSingleList(BillingSubmitForm form, int index) {
		BillingSubmitForm tmp = new BillingSubmitForm();
		List<Long> tmpClaimId = new ArrayList<Long>();
		List<String> tmpClaimNo = new ArrayList<String>();
		List<Long> tmpCaseId = new ArrayList<Long>();
		List<String> tmpDecision = new ArrayList<String>();
		List<String> tmpReason = new ArrayList<String>();
		if (form.getClaimId() != null) {
			tmpClaimId.add(FormatUtil.convertToLong(form.getClaimId().get(index)));
		}
		if (form.getClaimNo() != null) {
			tmpClaimNo.add(FormatUtil.convertNull(form.getClaimNo().get(index)));
		}
		if (form.getCaseId() != null) {
			tmpCaseId.add(FormatUtil.convertToLong(form.getCaseId().get(index)));
		}

		if (form.getReason() != null) {
			tmpReason.add(FormatUtil.convertNull(form.getReason().get(index)));
		}
		if (form.getDecision() != null) {
			tmpDecision.add(FormatUtil.convertNull(form.getDecision().get(index)));
		}

		tmp.setCaseId(tmpCaseId);
		tmp.setClaimId(tmpClaimId);
		tmp.setClaimNo(tmpClaimNo);
		tmp.setDecision(tmpDecision);
		tmp.setReason(tmpReason);

		return tmp;
	}

	public List<Long> getClaimId() {
		return claimId;
	}

	public void setClaimId(List<Long> claimId) {
		this.claimId = claimId;
	}

	public List<String> getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(List<String> claimNo) {
		this.claimNo = claimNo;
	}

	public List<Long> getCaseId() {
		return caseId;
	}

	public void setCaseId(List<Long> caseId) {
		this.caseId = caseId;
	}

	public List<String> getDecision() {
		return decision;
	}

	public void setDecision(List<String> decision) {
		this.decision = decision;
	}

	public List<String> getReason() {
		return reason;
	}

	public void setReason(List<String> reason) {
		this.reason = reason;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
