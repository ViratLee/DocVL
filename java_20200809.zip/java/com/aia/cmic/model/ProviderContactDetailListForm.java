package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ProviderContact;

public class ProviderContactDetailListForm {

	//General Information
	private Long providerContactId;
	private String providerCode;
	private String department;
	private String contactPoint;
	private String telephone;
	private String fax;
	private String email;

	public ProviderContactDetailListForm() {
	}

	public ProviderContactDetailListForm(ProviderContact entity) {
		this.providerContactId = entity.getProviderContactId();
		this.providerCode = entity.getProviderCode();
		this.department = entity.getDepartment();
		this.contactPoint = entity.getFirstName();
		this.telephone = entity.getPhoneNo1();
		this.fax = entity.getFaxNo1();
		this.email = entity.getEmailAddress1();
	}

	public Long getProviderContactId() {
		return providerContactId;
	}

	public void setProviderContactId(Long providerContactId) {
		this.providerContactId = providerContactId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getContactPoint() {
		return contactPoint;
	}

	public void setContactPoint(String contactPoint) {
		this.contactPoint = contactPoint;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
