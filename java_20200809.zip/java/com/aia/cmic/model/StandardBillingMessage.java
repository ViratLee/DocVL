package com.aia.cmic.model;

public class StandardBillingMessage {
	private String sheet;
	private String cell;
	private String policy;
	private int newItems;
	private int updateItems;
	private int deleteItems;
	private String message;

	public String getSheet() {
		return sheet;
	}

	public void setSheet(String sheet) {
		this.sheet = sheet;
	}

	public String getCell() {
		return cell;
	}

	public void setCell(String cell) {
		this.cell = cell;
	}

	public String getPolicy() {
		return policy;
	}

	public void setPolicy(String policy) {
		this.policy = policy;
	}

	public int getNewItems() {
		return newItems;
	}

	public void setNewItems(int newItems) {
		this.newItems = newItems;
	}

	public int getUpdateItems() {
		return updateItems;
	}

	public void setUpdateItems(int updateItems) {
		this.updateItems = updateItems;
	}

	public int getDeleteItems() {
		return deleteItems;
	}

	public void setDeleteItems(int deleteItems) {
		this.deleteItems = deleteItems;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
