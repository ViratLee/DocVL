package com.aia.cmic.model;

import java.util.Date;

import com.aia.cmic.repository.rest.response.policy.EmploymentFamily;

public class Dependent {
	String firstName;
	String lastName;
	Date dob;
	String gender;
	String customerId;
	String policyNo;
	String subOfficeCd;
	String certNo;
	String nationalId;
	String dependentNo;
	String partyId;
	String dependenttype;
	String relationship;
	String membershipId;

	public Dependent() {

	}

	public Dependent(EmploymentFamily emp) {
		this.certNo = emp.getCertificateNum();
		this.subOfficeCd = emp.getSubCorporateCd();
		this.dependentNo = emp.getDependentCd();
		this.membershipId = emp.getMembershipNo();
		this.dependenttype = emp.getMembershipType();
		this.partyId = emp.getPartyId();
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getSubOfficeCd() {
		return subOfficeCd;
	}

	public void setSubOfficeCd(String subOfficeCd) {
		this.subOfficeCd = subOfficeCd;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getDependenttype() {
		return dependenttype;
	}

	public void setDependenttype(String dependenttype) {
		this.dependenttype = dependenttype;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getMembershipId() {
		return membershipId;
	}

	public void setMembershipId(String membershipId) {
		this.membershipId = membershipId;
	}

}
