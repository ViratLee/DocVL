package com.aia.cmic.model;

public class DataEntryPageSecurity {
	private boolean generalWritable;
	private boolean claimantWritable;
	private boolean submissionWritable;
	private boolean paymentWritable;
	private boolean providerWritable;
	private boolean serviceItemWritable;
	private boolean causeOfTreatmentWritable;
	private boolean detailOfAccidentWritable;
	private boolean medicalConditionWritable;
	private boolean diagnosisWritable;
	private boolean benefitWritable;
	private boolean commentWritable;
	private boolean saveAvaliable;
	private boolean transferAvaliable;
	private boolean confirmAndDuplicateAvaliable;
	private boolean confirmAndCloseAvaliable;
	private boolean confirmAndGetNextAvaliable;
	private boolean rejectAvaliable;
	private boolean pendAvaliable;
	private boolean doctorAvaliable;
	private boolean unlockAvaliable;
	private boolean unloadAvaliable;
	private boolean customerProfileAvaliable;
	private boolean benefitDetailAvaliable;
	private boolean pendingDocumentAvaliable;
	private boolean reverseButtonAvailable;
	private boolean claimpolicyAccountnoAvailable;
	private boolean copyAvailable;
	private boolean claimInquiry;
	private boolean saveMedicalAvaliable;
	private boolean disabledRequestDoc;
	private boolean deleteAvaliable;
	private boolean deleteAvaliable2;
	private boolean editClaimAvaliable;
	private boolean isODS;

	public boolean isODS() {
		return isODS;
	}

	public void setODS(boolean isODS) {
		this.isODS = isODS;
	}

	public boolean isGeneralWritable() {
		return generalWritable;
	}

	public void setGeneralWritable(boolean generalWritable) {
		this.generalWritable = generalWritable;
	}

	public boolean isClaimantWritable() {
		return claimantWritable;
	}

	public void setClaimantWritable(boolean claimantWritable) {
		this.claimantWritable = claimantWritable;
	}

	public boolean isSubmissionWritable() {
		return submissionWritable;
	}

	public void setSubmissionWritable(boolean submissionWritable) {
		this.submissionWritable = submissionWritable;
	}

	public boolean isPaymentWritable() {
		return paymentWritable;
	}

	public void setPaymentWritable(boolean paymentWritable) {
		this.paymentWritable = paymentWritable;
	}

	public boolean isProviderWritable() {
		return providerWritable;
	}

	public void setProviderWritable(boolean providerWritable) {
		this.providerWritable = providerWritable;
	}

	public boolean isServiceItemWritable() {
		return serviceItemWritable;
	}

	public void setServiceItemWritable(boolean serviceItemWritable) {
		this.serviceItemWritable = serviceItemWritable;
	}

	public boolean isCauseOfTreatmentWritable() {
		return causeOfTreatmentWritable;
	}

	public void setCauseOfTreatmentWritable(boolean causeOfTreatmentWritable) {
		this.causeOfTreatmentWritable = causeOfTreatmentWritable;
	}

	public boolean isDetailOfAccidentWritable() {
		return detailOfAccidentWritable;
	}

	public void setDetailOfAccidentWritable(boolean detailOfAccidentWritable) {
		this.detailOfAccidentWritable = detailOfAccidentWritable;
	}

	public boolean isMedicalConditionWritable() {
		return medicalConditionWritable;
	}

	public void setMedicalConditionWritable(boolean medicalConditionWritable) {
		this.medicalConditionWritable = medicalConditionWritable;
	}

	public boolean isDiagnosisWritable() {
		return diagnosisWritable;
	}

	public void setDiagnosisWritable(boolean diagnosisWritable) {
		this.diagnosisWritable = diagnosisWritable;
	}

	public boolean isBenefitWritable() {
		return benefitWritable;
	}

	public void setBenefitWritable(boolean benefitWritable) {
		this.benefitWritable = benefitWritable;
	}

	public boolean isCommentWritable() {
		return commentWritable;
	}

	public void setCommentWritable(boolean commentWritable) {
		this.commentWritable = commentWritable;
	}

	public boolean isSaveAvaliable() {
		return saveAvaliable;
	}

	public void setSaveAvaliable(boolean saveAvaliable) {
		this.saveAvaliable = saveAvaliable;
	}

	public boolean isTransferAvaliable() {
		return transferAvaliable;
	}

	public void setTransferAvaliable(boolean transferAvaliable) {
		this.transferAvaliable = transferAvaliable;
	}

	public boolean isConfirmAndDuplicateAvaliable() {
		return confirmAndDuplicateAvaliable;
	}

	public void setConfirmAndDuplicateAvaliable(boolean confirmAndDuplicateAvaliable) {
		this.confirmAndDuplicateAvaliable = confirmAndDuplicateAvaliable;
	}

	public boolean isConfirmAndCloseAvaliable() {
		return confirmAndCloseAvaliable;
	}

	public void setConfirmAndCloseAvaliable(boolean confirmAndCloseAvaliable) {
		this.confirmAndCloseAvaliable = confirmAndCloseAvaliable;
	}

	public boolean isConfirmAndGetNextAvaliable() {
		return confirmAndGetNextAvaliable;
	}

	public void setConfirmAndGetNextAvaliable(boolean confirmAndGetNextAvaliable) {
		this.confirmAndGetNextAvaliable = confirmAndGetNextAvaliable;
	}

	public boolean isRejectAvaliable() {
		return rejectAvaliable;
	}

	public void setRejectAvaliable(boolean rejectAvaliable) {
		this.rejectAvaliable = rejectAvaliable;
	}

	public boolean isPendAvaliable() {
		return pendAvaliable;
	}

	public void setPendAvaliable(boolean pendAvaliable) {
		this.pendAvaliable = pendAvaliable;
	}

	public boolean isDoctorAvaliable() {
		return doctorAvaliable;
	}

	public void setDoctorAvaliable(boolean doctorAvaliable) {
		this.doctorAvaliable = doctorAvaliable;
	}

	public boolean isUnlockAvaliable() {
		return unlockAvaliable;
	}

	public void setUnlockAvaliable(boolean unlockAvaliable) {
		this.unlockAvaliable = unlockAvaliable;
	}

	public boolean isUnloadAvaliable() {
		return unloadAvaliable;
	}

	public void setUnloadAvaliable(boolean unloadAvaliable) {
		this.unloadAvaliable = unloadAvaliable;
	}

	public boolean isCustomerProfileAvaliable() {
		return customerProfileAvaliable;
	}

	public void setCustomerProfileAvaliable(boolean customerProfileAvaliable) {
		this.customerProfileAvaliable = customerProfileAvaliable;
	}

	public boolean isBenefitDetailAvaliable() {
		return benefitDetailAvaliable;
	}

	public void setBenefitDetailAvaliable(boolean benefitDetailAvaliable) {
		this.benefitDetailAvaliable = benefitDetailAvaliable;
	}

	public boolean isPendingDocumentAvaliable() {
		return pendingDocumentAvaliable;
	}

	public void setPendingDocumentAvaliable(boolean pendingDocumentAvaliable) {
		this.pendingDocumentAvaliable = pendingDocumentAvaliable;
	}

	public boolean isReverseButtonAvailable() {
		return reverseButtonAvailable;
	}

	public void setReverseButtonAvailable(boolean reverseButtonAvailable) {
		this.reverseButtonAvailable = reverseButtonAvailable;
	}

	public boolean isClaimpolicyAccountnoAvailable() {
		return claimpolicyAccountnoAvailable;
	}

	public void setClaimpolicyAccountnoAvailable(boolean claimpolicyAccountnoAvailable) {
		this.claimpolicyAccountnoAvailable = claimpolicyAccountnoAvailable;
	}

	public boolean isCopyAvailable() {
		return copyAvailable;
	}

	public void setCopyAvailable(boolean copyAvailable) {
		this.copyAvailable = copyAvailable;
	}

	public boolean isClaimInquiry() {
		return claimInquiry;
	}

	public void setClaimInquiry(boolean claimInquiry) {
		this.claimInquiry = claimInquiry;
	}

	public boolean isSaveMedicalAvaliable() {
		return saveMedicalAvaliable;
	}

	public void setSaveMedicalAvaliable(boolean saveMedicalAvaliable) {
		this.saveMedicalAvaliable = saveMedicalAvaliable;
	}

	public boolean isDisabledRequestDoc() {
		return disabledRequestDoc;
	}

	public void setDisabledRequestDoc(boolean disabledRequestDoc) {
		this.disabledRequestDoc = disabledRequestDoc;
	}

	public boolean isDeleteAvaliable() {
		return deleteAvaliable;
	}

	public void setDeleteAvaliable(boolean deleteAvaliable) {
		this.deleteAvaliable = deleteAvaliable;
	}

	public boolean isEditClaimAvaliable() {
		return editClaimAvaliable;
	}

	public void setEditClaimAvaliable(boolean editClaimAvaliable) {
		this.editClaimAvaliable = editClaimAvaliable;
	}

	public boolean isDeleteAvaliable2() {
		return deleteAvaliable2;
	}

	public void setDeleteAvaliable2(boolean deleteAvaliable2) {
		this.deleteAvaliable2 = deleteAvaliable2;
	}

}
