package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomerMatchingSearchForm {

	private static final Logger LOG = LoggerFactory.getLogger(CustomerMatchingSearchForm.class);

	private String customerFirstName;
	private String customerLastName;
	private String policyNo;
	private String nationalID;
	private String certNo;
	private String customerID;
	private String memberID;
	private String dependentCode;

	public final String getCustomerFirstName() {
		return customerFirstName;
	}

	public final void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public final String getCustomerLastName() {
		return customerLastName;
	}

	public final void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getNationalID() {
		return nationalID;
	}

	public final void setNationalID(String nationalID) {
		this.nationalID = nationalID;
	}

	public final String getCertNo() {
		return certNo;
	}

	public final void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public final String getCustomerID() {
		return customerID;
	}

	public final void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public final String getMemberID() {
		return memberID;
	}

	public final void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public final String getDependentCode() {
		return dependentCode;
	}

	public final void setDependentCode(String dependentCode) {
		this.dependentCode = dependentCode;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
