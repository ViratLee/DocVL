package com.aia.cmic.model;

import java.io.Serializable;

public class OriginalReceiptTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String location;
	private String policyNo;
	private String certNo;
	private String memberId;
	private String insuredName;
	private String insuredFirstname;
	private String insuredLastname;
	private String submissionDate;
	private String settlementDate;
	private String claimNum;
	private String returnStatus;
	private String printDate;
	private Integer caseId;
	private String scanBatchId;
	private String dateReceive;
	private String returnDate;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getClaimNum() {
		return claimNum;
	}

	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}

	public String getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}

	public String getPrintDate() {
		return printDate;
	}

	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public String getScanBatchId() {
		return scanBatchId;
	}

	public void setScanBatchId(String scanBatchId) {
		this.scanBatchId = scanBatchId;
	}

	public String getInsuredFirstname() {
		return insuredFirstname;
	}

	public void setInsuredFirstname(String insuredFirstname) {
		this.insuredFirstname = insuredFirstname;
	}

	public String getInsuredLastname() {
		return insuredLastname;
	}

	public void setInsuredLastname(String insuredLastname) {
		this.insuredLastname = insuredLastname;
	}

	public String getDateReceive() {
		return dateReceive;
	}

	public void setDateReceive(String dateReceive) {
		this.dateReceive = dateReceive;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}

}
