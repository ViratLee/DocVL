package com.aia.cmic.model;

import java.io.Serializable;
import java.util.Date;


public class MyTeamWorkResponseTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer caseId;
	private String dateReceive;
	private String providerCode;//hospitalName
	private String providerName;
	private String policyNo;
	private String certNo;
	private String memberId;
	private String insureFirstName;
	private String insureLastName;
	private String scanBatchId;
	private String channel;
	private String location;
	private String dependentCode;
	private String previousUser; //PreviousOwner
	private String owner;//ActivityOwner
	private String dueDate;
	private String insuredName;
	private String completionDate;
	private String creationDateTime;
	private String claimNum;
	private String claimType;
	private String partyId;
	private String scanDate;
	private String scanType;
	private String activity;
	private String category;
	private Integer risk;
	private String claimStatus;
	private String phase;
	private String typeOfService;//requestType
	private String assignGroup;
	private String lockType;
	private String vip;
	private String urgent;
	private String isAssign;
	private Long id;
	private String claimAmount;
	
	
	public Integer getCaseId() {
		return caseId;
	}
	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}
	public String getDateReceive() {
		return dateReceive;
	}
	public void setDateReceive(String dateReceive) {
		this.dateReceive = dateReceive;
	}
	public String getProviderCode() {
		return providerCode;
	}
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getInsureFirstName() {
		return insureFirstName;
	}
	public void setInsureFirstName(String insureFirstName) {
		this.insureFirstName = insureFirstName;
	}
	public String getInsureLastName() {
		return insureLastName;
	}
	public void setInsureLastName(String insureLastName) {
		this.insureLastName = insureLastName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getScanBatchId() {
		return scanBatchId;
	}
	public void setScanBatchId(String scanBatchId) {
		this.scanBatchId = scanBatchId;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDependentCode() {
		return dependentCode;
	}
	public void setDependentCode(String dependentCode) {
		this.dependentCode = dependentCode;
	}

	public String getPreviousUser() {
		return previousUser;
	}
	public void setPreviousUser(String previousUser) {
		this.previousUser = previousUser;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	public String getCreationDateTime() {
		return creationDateTime;
	}
	public void setCreationDateTime(String creationDateTime) {
		this.creationDateTime = creationDateTime;
	}
	public String getClaimNum() {
		return claimNum;
	}
	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}
	public String getClaimType() {
		return claimType;
	}
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	public String getScanDate() {
		return scanDate;
	}
	public void setScanDate(String scanDate) {
		this.scanDate = scanDate;
	}
	public String getScanType() {
		return scanType;
	}
	public void setScanType(String scanType) {
		this.scanType = scanType;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Integer getRisk() {
		return risk;
	}
	public void setRisk(Integer risk) {
		this.risk = risk;
	}
	public String getClaimStatus() {
		return claimStatus;
	}
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public String getTypeOfService() {
		return typeOfService;
	}
	public void setTypeOfService(String typeOfService) {
		this.typeOfService = typeOfService;
	}
	public String getAssignGroup() {
		return assignGroup;
	}
	public void setAssignGroup(String assignGroup) {
		this.assignGroup = assignGroup;
	}
	public String getLockType() {
		return lockType;
	}
	public void setLockType(String lockType) {
		this.lockType = lockType;
	}
	public String getVip() {
		return vip;
	}
	public void setVip(String vip) {
		this.vip = vip;
	}
	public String getUrgent() {
		return urgent;
	}
	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}
	public String getIsAssign() {
		return isAssign;
	}
	public void setIsAssign(String isAssign) {
		this.isAssign = isAssign;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(String claimAmount) {
		this.claimAmount = claimAmount;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	
	
}
