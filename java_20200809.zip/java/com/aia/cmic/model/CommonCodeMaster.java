package com.aia.cmic.model;

import com.aia.cmic.entity.CommonCode;

public class CommonCodeMaster {
	private Long commonCodeId;
	private String category;
	private String codeName;
	private String codeValue;
	private String codeDesc;
	private String codeDescThai;
	private String codeDescLong;
	private String codeDescLongThai;
	private Integer referCommonCodeId;

	public CommonCodeMaster(CommonCode commonCode) {
		commonCodeId = commonCode.getCommonCodeId();
		category = commonCode.getCategory();
		codeName = commonCode.getCodeName();
		codeValue = commonCode.getCodeValue();
		codeDesc = commonCode.getCodeDesc();
		codeDescThai = commonCode.getCodeDescThai();
		codeDescLong = commonCode.getCodeDescLong();
		codeDescLongThai = commonCode.getCodeDescLongThai();
		referCommonCodeId = commonCode.getReferCommonCodeId();
	}

	public Long getCommonCodeId() {
		return commonCodeId;
	}

	public String getCategory() {
		return category;
	}

	public String getCodeName() {
		return codeName;
	}

	public String getCodeValue() {
		return codeValue;
	}

	public String getCodeDesc() {
		return codeDesc;
	}

	public String getCodeDescThai() {
		return codeDescThai;
	}

	public String getCodeDescLong() {
		return codeDescLong;
	}

	public String getCodeDescLongThai() {
		return codeDescLongThai;
	}

	public Integer getReferCommonCodeId() {
		return referCommonCodeId;
	}
}
