package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.xml.bind.annotation.XmlElement;


public class ClaimPolicyPlan {

	Long claimPolicyPlanId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String planCode;
	String planCoverageNo;
	String productCode;
	String paPackageName;
	String planStatus;
	BigDecimal sumAssured;
	BigDecimal faceAmt;
	BigDecimal hsBonusAmt ;
	Date hsBonusDt ;
	Integer rateAge;
	BigDecimal noOfUnit;
	Integer valuePerUnit;
	Date planIssueDt;
	Date planPaidUpDt;
	Date planExpiryDt;
	String geographicCoverage;
	String reinsuranceSchemeCode;
	BigDecimal percentageReinsurance;
	String createdBy;
	String lastModifiedBy;
	Date createdDt;
	Date lastModifiedDt;
	String coverageId;
	String planNum;
	String exclusion1;
	String exclusion2;
	String exclusion3;
	String admitArea;
	Date policyYearFromDt;
	Date policyYearToDt;
	String par;
	String inforcePlanCode;
	String planCoverageNoRcc;
	String relatePlanCode;
	String relateInforcePlanCode;
	String inforcePlanCode01;
	String matuityTransferInd;
	String riderConInd;

	/**
	 * @return the claimPolicyPlanId
	 */
	public Long getClaimPolicyPlanId() {
		return claimPolicyPlanId;
	}

	/**
	 * @param claimPolicyPlanId the claimPolicyPlanId to set
	 */
	public void setClaimPolicyPlanId(Long claimPolicyPlanId) {
		this.claimPolicyPlanId = claimPolicyPlanId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCode
	 */
	public String getPlanCode() {
		return planCode;
	}

	/**
	 * @param planCode the planCode to set
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the paPackageName
	 */
	public String getPaPackageName() {
		return paPackageName;
	}

	/**
	 * @param paPackageName the paPackageName to set
	 */
	public void setPaPackageName(String paPackageName) {
		this.paPackageName = paPackageName;
	}

	/**
	 * @return the planStatus
	 */
	public String getPlanStatus() {
		return planStatus;
	}

	/**
	 * @param planStatus the planStatus to set
	 */
	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	/**
	 * @return the sumAssured
	 */
	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	/**
	 * @return the faceAmt
	 */
	public BigDecimal getFaceAmt() {
		return faceAmt;
	}

	/**
	 * @param faceAmt the faceAmt to set
	 */
	public void setFaceAmt(BigDecimal faceAmt) {
		this.faceAmt = faceAmt;
	}

	/**
	 * @return the rateAge
	 */
	public Integer getRateAge() {
		return rateAge;
	}

	/**
	 * @param rateAge the rateAge to set
	 */
	public void setRateAge(Integer rateAge) {
		this.rateAge = rateAge;
	}

	/**
	 * @return the noOfUnit
	 */
	public BigDecimal getNoOfUnit() {
		return noOfUnit;
	}

	/**
	 * @param noOfUnit the noOfUnit to set
	 */
	public void setNoOfUnit(BigDecimal noOfUnit) {
		this.noOfUnit = noOfUnit;
	}

	/**
	 * @return the valuePerUnit
	 */
	public Integer getValuePerUnit() {
		return valuePerUnit;
	}

	/**
	 * @param valuePerUnit the valuePerUnit to set
	 */
	public void setValuePerUnit(Integer valuePerUnit) {
		this.valuePerUnit = valuePerUnit;
	}

	/**
	 * @return the planIssueDt
	 */
	public Date getPlanIssueDt() {
		return planIssueDt;
	}

	/**
	 * @param planIssueDt the planIssueDt to set
	 */
	public void setPlanIssueDt(Date planIssueDt) {
		this.planIssueDt = planIssueDt;
	}

	/**
	 * @return the planPaidUpDt
	 */
	public Date getPlanPaidUpDt() {
		return planPaidUpDt;
	}

	/**
	 * @param planPaidUpDt the planPaidUpDt to set
	 */
	public void setPlanPaidUpDt(Date planPaidUpDt) {
		this.planPaidUpDt = planPaidUpDt;
	}

	/**
	 * @return the planExpiryDt
	 */
	public Date getPlanExpiryDt() {
		return planExpiryDt;
	}

	/**
	 * @param planExpiryDt the planExpiryDt to set
	 */
	public void setPlanExpiryDt(Date planExpiryDt) {
		this.planExpiryDt = planExpiryDt;
	}

	/**
	 * @return the geographicCoverage
	 */
	public String getGeographicCoverage() {
		return geographicCoverage;
	}

	/**
	 * @param geographicCoverage the geographicCoverage to set
	 */
	public void setGeographicCoverage(String geographicCoverage) {
		this.geographicCoverage = geographicCoverage;
	}

	/**
	 * @return the reinsuranceSchemeCode
	 */
	public String getReinsuranceSchemeCode() {
		return reinsuranceSchemeCode;
	}

	/**
	 * @param reinsuranceSchemeCode the reinsuranceSchemeCode to set
	 */
	public void setReinsuranceSchemeCode(String reinsuranceSchemeCode) {
		this.reinsuranceSchemeCode = reinsuranceSchemeCode;
	}

	/**
	 * @return the percentageReinsurance
	 */
	public BigDecimal getPercentageReinsurance() {
		return percentageReinsurance;
	}

	/**
	 * @param percentageReinsurance the percentageReinsurance to set
	 */
	public void setPercentageReinsurance(BigDecimal percentageReinsurance) {
		this.percentageReinsurance = percentageReinsurance;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return the createdDt
	 */
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the lastModifiedDt
	 */
	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	/**
	 * @param lastModifiedDt the lastModifiedDt to set
	 */
	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String getCoverageId() {
		return coverageId;
	}

	public void setCoverageId(String coverageId) {
		this.coverageId = coverageId;
	}

	public String getPlanNum() {
		return planNum;
	}

	public void setPlanNum(String planNum) {
		this.planNum = planNum;
	}

	public String getExclusion1() {
		return exclusion1;
	}

	public void setExclusion1(String exclusion1) {
		this.exclusion1 = exclusion1;
	}

	public String getExclusion2() {
		return exclusion2;
	}

	public void setExclusion2(String exclusion2) {
		this.exclusion2 = exclusion2;
	}

	public String getExclusion3() {
		return exclusion3;
	}

	public void setExclusion3(String exclusion3) {
		this.exclusion3 = exclusion3;
	}

	public BigDecimal getHsBonusAmt() {
		return hsBonusAmt;
	}

	public void setHsBonusAmt(BigDecimal hsBonusAmt) {
		this.hsBonusAmt = hsBonusAmt;
	}

	public Date getHsBonusDt() {
		return hsBonusDt;
	}

	public void setHsBonusDt(Date hsBonusDt) {
		this.hsBonusDt = hsBonusDt;
	}

	public String getAdmitArea() {
		return admitArea;
	}

	public void setAdmitArea(String admitArea) {
		this.admitArea = admitArea;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public String getPar() {
		return par;
	}

	public String getInforcePlanCode() {
		return inforcePlanCode;
	}

	public String getPlanCoverageNoRcc() {
		return planCoverageNoRcc;
	}

	public void setPlanCoverageNoRcc(String planCoverageNoRcc) {
		this.planCoverageNoRcc = planCoverageNoRcc;
	}

	public String getRelatePlanCode() {
		return relatePlanCode;
	}

	public String getRelateInforcePlanCode() {
		return relateInforcePlanCode;
	}

	public String getInforcePlanCode01() {
		return inforcePlanCode01;
	}

	public void setPar(String par) {
		this.par = par;
	}

	public void setInforcePlanCode(String inforcePlanCode) {
		this.inforcePlanCode = inforcePlanCode;
	}

	
	public void setRelatePlanCode(String relatePlanCode) {
		this.relatePlanCode = relatePlanCode;
	}

	public void setRelateInforcePlanCode(String relateInforcePlanCode) {
		this.relateInforcePlanCode = relateInforcePlanCode;
	}

	public void setInforcePlanCode01(String inforcePlanCode01) {
		this.inforcePlanCode01 = inforcePlanCode01;
	}

	public String getMatuityTransferInd() {
		return matuityTransferInd;
	}

	public void setMatuityTransferInd(String matuityTransferInd) {
		this.matuityTransferInd = matuityTransferInd;
	}

	public String getRiderConInd() {
		return riderConInd;
	}

	public void setRiderConInd(String riderConInd) {
		this.riderConInd = riderConInd;
	}

	
	
	
	

}
