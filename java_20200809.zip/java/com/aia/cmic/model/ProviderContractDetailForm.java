package com.aia.cmic.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProviderContractDetailForm {
	private static final Logger LOG = LoggerFactory.getLogger(ProviderContractDetailForm.class);
	private Long providerContractDetailId;
	private String type;
	private Lookup serviceCatId = new Lookup();
	private String discountOnListPrice;
	private String listPrice;
	private String agreedFee;
	private String packageName;
	private Lookup icd9Code = new Lookup();
	private Lookup icd10Code = new Lookup();
	private String paymentTerm;
	private String volumeDiscount;
	private String tierPricing;
	private boolean discountInd;
	private boolean notPaidInd;
	private String capitatedService;
	private String networkId;
	private String networkName;

	public String getDiscountOnListPrice() {
		return discountOnListPrice;
	}

	public void setDiscountOnListPrice(String discountOnListPrice) {
		this.discountOnListPrice = discountOnListPrice;
	}

	public String getListPrice() {
		return listPrice;
	}

	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}

	public String getAgreedFee() {
		return agreedFee;
	}

	public void setAgreedFee(String agreedFee) {
		this.agreedFee = agreedFee;
	}

	public boolean isDiscountInd() {
		return discountInd;
	}

	public void setDiscountInd(boolean discountInd) {
		this.discountInd = discountInd;
	}

	public boolean isNotPaidInd() {
		return notPaidInd;
	}

	public void setNotPaidInd(boolean notPaidInd) {
		this.notPaidInd = notPaidInd;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(String paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public String getVolumeDiscount() {
		return volumeDiscount;
	}

	public void setVolumeDiscount(String volumeDiscount) {
		this.volumeDiscount = volumeDiscount;
	}

	public String getTierPricing() {
		return tierPricing;
	}

	public void setTierPricing(String tierPricing) {
		this.tierPricing = tierPricing;
	}

	public Lookup getServiceCatId() {
		return serviceCatId;
	}

	public void setServiceCatId(Lookup serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	public Lookup getIcd9Code() {
		return icd9Code;
	}

	public void setIcd9Code(Lookup icd9Code) {
		this.icd9Code = icd9Code;
	}

	public Lookup getIcd10Code() {
		return icd10Code;
	}

	public void setIcd10Code(Lookup icd10Code) {
		this.icd10Code = icd10Code;
	}

	public Long getProviderContractDetailId() {
		return providerContractDetailId;
	}

	public void setProviderContractDetailId(Long providerContractDetailId) {
		this.providerContractDetailId = providerContractDetailId;
	}

	public String getCapitatedService() {
		return capitatedService;
	}

	public void setCapitatedService(String capitatedService) {
		this.capitatedService = capitatedService;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

}
