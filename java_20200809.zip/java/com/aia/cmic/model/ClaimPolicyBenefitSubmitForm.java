package com.aia.cmic.model;

import java.util.List;

public class ClaimPolicyBenefitSubmitForm {

	private List<String> claimNo;
	private List<String> occurrence;
	private List<String> policyNo;
	private List<String> planId;
	private List<String> productCode;
	private List<String> benefitCode;
	private List<String> decision;
	private List<String> copaymentPercent;
	private List<String> deductAmount;
	private List<String> isFullCredit;

	public List<String> getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(List<String> claimNo) {
		this.claimNo = claimNo;
	}

	public List<String> getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(List<String> occurrence) {
		this.occurrence = occurrence;
	}

	public List<String> getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(List<String> policyNo) {
		this.policyNo = policyNo;
	}

	public List<String> getPlanId() {
		return planId;
	}

	public void setPlanId(List<String> planId) {
		this.planId = planId;
	}

	public List<String> getProductCode() {
		return productCode;
	}

	public void setProductCode(List<String> productCode) {
		this.productCode = productCode;
	}

	public List<String> getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(List<String> benefitCode) {
		this.benefitCode = benefitCode;
	}

	public List<String> getDecision() {
		return decision;
	}

	public void setDecision(List<String> decision) {
		this.decision = decision;
	}

	public List<String> getCopaymentPercent() {
		return copaymentPercent;
	}

	public void setCopaymentPercent(List<String> copaymentPercent) {
		this.copaymentPercent = copaymentPercent;
	}

	public List<String> getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(List<String> deductAmount) {
		this.deductAmount = deductAmount;
	}

	public List<String> getIsFullCredit() {
		return isFullCredit;
	}

	public void setIsFullCredit(List<String> isFullCredit) {
		this.isFullCredit = isFullCredit;
	}

}
