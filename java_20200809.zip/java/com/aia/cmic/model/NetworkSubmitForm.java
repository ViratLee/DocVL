package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.entity.Network;
import com.aia.cmic.entity.NetworkDetail;

public class NetworkSubmitForm {

	private static final Logger LOG = LoggerFactory.getLogger(NetworkForm.class);

	private Long networkId;
	private String networkName;
	private Date effectiveToDt;
	private List<String> networkType;
	private List<String> networkSpecificProduct;
	private List<String> businessLine;
	private String createdBy;
	private Date createdDt;
	private String lastModifiedBy;
	private Date lastModifiedDt;

	public NetworkSubmitForm() {
	}

	public static Network toNetworkEntity(NetworkSubmitForm form) {
		Network retrunValue = new Network();
		retrunValue.setNetworkId(form.getNetworkId());
		retrunValue.setNetworkName(form.getNetworkName());
		retrunValue.setEffectiveToDt(form.getEffectiveToDt());
		retrunValue.setCompanyId("051");
		retrunValue.setCreatedBy(form.getCreatedBy());
		retrunValue.setLastModifiedBy(form.getLastModifiedBy());
		retrunValue.setCreatedDt(new Date());
		retrunValue.setLastModifiedDt(new Date());
		return retrunValue;
	}

	public static NetworkDetail toNetworkDetailEntity(NetworkSubmitForm form) {
		NetworkDetail retrunValue = new NetworkDetail();
		retrunValue.setNetworkId(form.getNetworkId());
		retrunValue.setCreatedBy(form.getCreatedBy());
		retrunValue.setLastModifiedBy(form.getLastModifiedBy());
		retrunValue.setCreatedDt(new Date());
		retrunValue.setLastModifiedDt(new Date());
		return retrunValue;
	}

	public final Long getNetworkId() {
		return networkId;
	}

	public final void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public final String getNetworkName() {
		return networkName;
	}

	public final void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public final Date getEffectiveToDt() {
		return effectiveToDt;
	}

	public final void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public final List<String> getNetworkType() {
		return networkType;
	}

	public final void setNetworkType(List<String> networkType) {
		this.networkType = networkType;
	}

	public final List<String> getNetworkSpecificProduct() {
		return networkSpecificProduct;
	}

	public final void setNetworkSpecificProduct(List<String> networkSpecificProduct) {
		this.networkSpecificProduct = networkSpecificProduct;
	}

	public final List<String> getBusinessLine() {
		return businessLine;
	}

	public final void setBusinessLine(List<String> businessLine) {
		this.businessLine = businessLine;
	}

	public final String getCreatedBy() {
		return createdBy;
	}

	public final void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public final Date getCreatedDt() {
		return createdDt;
	}

	public final void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public final String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public final void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public final Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public final void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
