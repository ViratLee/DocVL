package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class PlanBenefitBO {
	Long planBenefitId;
	Long planId;
	String benefitItemCode;
	BigDecimal indemnityPercentage;
	Integer noOfDays;
	Integer maxNoOfDay;
	Integer confinementDay;
	BigDecimal maxBenefitAmt;
	BigDecimal maxConfinementAmt;
	BigDecimal maxYearAmt;
	BigDecimal maxMajorConfinement;
	BigDecimal nonIpdSurgeryAmt;
	BigDecimal ipdSurgeryAmt;
	BigDecimal specialIPDAmt;
	Date changeDate;
	Integer maxNoOfDaysHist;
	// for cs
	BigDecimal totalBenefitAmt;
	Integer waitingPeriod;
	String saCalculateType;

	// new for cs
	String sumDuplicateCheckInd;
	String oopInd;
	String membershipType;
	BigDecimal maxSaamt;
	BigDecimal minSaamt;
	BigDecimal flatAmt;
	BigDecimal multipleFactor;
	String benefitUnit;
	BigDecimal benefitAmount;
	Integer sumSequenceNo;
	Integer accumulatorNo;
	Integer unitNo;
	String sumCategory;
	String sumTimeFrame;
	String familyShareInd;
	BigDecimal outNetworkSumValue;
	BigDecimal inNetworkSumValue;
	Date effectiveDt;
	String geographicCoverage;
	String proRateInd;
	String shareInd;
	String shareDesc;
	String shareLevel;
	
	Integer maxSumDay;
	String benefitShare;
	Integer noOfCall;
	BigDecimal maxYearAmtHNW;
	
	public BigDecimal getMaxYearAmtHNW() {
		return maxYearAmtHNW;
	}

	public void setMaxYearAmtHNW(BigDecimal maxYearAmtHNW) {
		this.maxYearAmtHNW = maxYearAmtHNW;
	}

	public Integer getNoOfCall() {
		return noOfCall;
	}

	public void setNoOfCall(Integer noOfCall) {
		this.noOfCall = noOfCall;
	}

	public String getBenefitShare() {
		return benefitShare;
	}

	public void setBenefitShare(String benefitShare) {
		this.benefitShare = benefitShare;
	}

	public Integer getMaxSumDay() {
		return maxSumDay;
	}

	public void setMaxSumDay(Integer maxSumDay) {
		this.maxSumDay = maxSumDay;
	}

	public String getSumDuplicateCheckInd() {
		return sumDuplicateCheckInd;
	}

	public String getOopInd() {
		return oopInd;
	}

	public String getMembershipType() {
		return membershipType;
	}

	public BigDecimal getMaxSaamt() {
		return maxSaamt;
	}

	public BigDecimal getMinSaamt() {
		return minSaamt;
	}

	public BigDecimal getFlatAmt() {
		return flatAmt;
	}

	public BigDecimal getMultipleFactor() {
		return multipleFactor;
	}

	public String getBenefitUnit() {
		return benefitUnit;
	}

	public BigDecimal getBenefitAmount() {
		return benefitAmount;
	}

	public Integer getSumSequenceNo() {
		return sumSequenceNo;
	}

	public Integer getAccumulatorNo() {
		return accumulatorNo;
	}

	public Integer getUnitNo() {
		return unitNo;
	}

	public String getSumCategory() {
		return sumCategory;
	}

	public String getSumTimeFrame() {
		return sumTimeFrame;
	}

	public String getFamilyShareInd() {
		return familyShareInd;
	}

	public BigDecimal getOutNetworkSumValue() {
		return outNetworkSumValue;
	}

	public BigDecimal getInNetworkSumValue() {
		return inNetworkSumValue;
	}

	public Date getEffectiveDt() {
		return effectiveDt;
	}

	public String getGeographicCoverage() {
		return geographicCoverage;
	}

	public String getProRateInd() {
		return proRateInd;
	}

	public String getShareInd() {
		return shareInd;
	}

	public String getShareDesc() {
		return shareDesc;
	}

	public String getShareLevel() {
		return shareLevel;
	}

	public void setSumDuplicateCheckInd(String sumDuplicateCheckInd) {
		this.sumDuplicateCheckInd = sumDuplicateCheckInd;
	}

	public void setOopInd(String oopInd) {
		this.oopInd = oopInd;
	}

	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}

	public void setMaxSaamt(BigDecimal maxSaamt) {
		this.maxSaamt = maxSaamt;
	}

	public void setMinSaamt(BigDecimal minSaamt) {
		this.minSaamt = minSaamt;
	}

	public void setFlatAmt(BigDecimal flatAmt) {
		this.flatAmt = flatAmt;
	}

	public void setMultipleFactor(BigDecimal multipleFactor) {
		this.multipleFactor = multipleFactor;
	}

	public void setBenefitUnit(String benefitUnit) {
		this.benefitUnit = benefitUnit;
	}

	public void setBenefitAmount(BigDecimal benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	public void setSumSequenceNo(Integer sumSequenceNo) {
		this.sumSequenceNo = sumSequenceNo;
	}

	public void setAccumulatorNo(Integer accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	public void setUnitNo(Integer unitNo) {
		this.unitNo = unitNo;
	}

	public void setSumCategory(String sumCategory) {
		this.sumCategory = sumCategory;
	}

	public void setSumTimeFrame(String sumTimeFrame) {
		this.sumTimeFrame = sumTimeFrame;
	}

	public void setFamilyShareInd(String familyShareInd) {
		this.familyShareInd = familyShareInd;
	}

	public void setOutNetworkSumValue(BigDecimal outNetworkSumValue) {
		this.outNetworkSumValue = outNetworkSumValue;
	}

	public void setInNetworkSumValue(BigDecimal inNetworkSumValue) {
		this.inNetworkSumValue = inNetworkSumValue;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public void setGeographicCoverage(String geographicCoverage) {
		this.geographicCoverage = geographicCoverage;
	}

	public void setProRateInd(String proRateInd) {
		this.proRateInd = proRateInd;
	}

	public void setShareInd(String shareInd) {
		this.shareInd = shareInd;
	}

	public void setShareDesc(String shareDesc) {
		this.shareDesc = shareDesc;
	}

	public void setShareLevel(String shareLevel) {
		this.shareLevel = shareLevel;
	}

	public Long getPlanBenefitId() {
		return planBenefitId;
	}

	public void setPlanBenefitId(Long planBenefitId) {
		this.planBenefitId = planBenefitId;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getBenefitItemCode() {
		return benefitItemCode;
	}

	public void setBenefitItemCode(String benefitItemCode) {
		this.benefitItemCode = benefitItemCode;
	}

	public BigDecimal getIndemnityPercentage() {
		return indemnityPercentage;
	}

	public void setIndemnityPercentage(BigDecimal indemnityPercentage) {
		this.indemnityPercentage = indemnityPercentage;
	}

	public Integer getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}

	public Integer getMaxNoOfDay() {
		return maxNoOfDay;
	}

	public void setMaxNoOfDay(Integer maxNoOfDay) {
		this.maxNoOfDay = maxNoOfDay;
	}

	public Integer getConfinementDay() {
		return confinementDay;
	}

	public void setConfinementDay(Integer confinementDay) {
		this.confinementDay = confinementDay;
	}

	public BigDecimal getMaxBenefitAmt() {
		return maxBenefitAmt;
	}

	public void setMaxBenefitAmt(BigDecimal maxBenefitAmt) {
		this.maxBenefitAmt = maxBenefitAmt;
	}

	public BigDecimal getMaxConfinementAmt() {
		return maxConfinementAmt;
	}

	public void setMaxConfinementAmt(BigDecimal maxConfinementAmt) {
		this.maxConfinementAmt = maxConfinementAmt;
	}

	public BigDecimal getMaxYearAmt() {
		return maxYearAmt;
	}

	public void setMaxYearAmt(BigDecimal maxYearAmt) {
		this.maxYearAmt = maxYearAmt;
	}

	public BigDecimal getMaxMajorConfinement() {
		return maxMajorConfinement;
	}

	public void setMaxMajorConfinement(BigDecimal maxMajorConfinement) {
		this.maxMajorConfinement = maxMajorConfinement;
	}

	public BigDecimal getNonIpdSurgeryAmt() {
		return nonIpdSurgeryAmt;
	}

	public void setNonIpdSurgeryAmt(BigDecimal nonIpdSurgeryAmt) {
		this.nonIpdSurgeryAmt = nonIpdSurgeryAmt;
	}

	public BigDecimal getIpdSurgeryAmt() {
		return ipdSurgeryAmt;
	}

	public void setIpdSurgeryAmt(BigDecimal ipdSurgeryAmt) {
		this.ipdSurgeryAmt = ipdSurgeryAmt;
	}

	public BigDecimal getSpecialIPDAmt() {
		return specialIPDAmt;
	}

	public void setSpecialIPDAmt(BigDecimal specialIPDAmt) {
		this.specialIPDAmt = specialIPDAmt;
	}

	public Date getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}

	public Integer getMaxNoOfDaysHist() {
		return maxNoOfDaysHist;
	}

	public void setMaxNoOfDaysHist(Integer maxNoOfDaysHist) {
		this.maxNoOfDaysHist = maxNoOfDaysHist;
	}

	public BigDecimal getTotalBenefitAmt() {
		return totalBenefitAmt;
	}

	public void setTotalBenefitAmt(BigDecimal totalBenefitAmt) {
		this.totalBenefitAmt = totalBenefitAmt;
	}

	public Integer getWaitingPeriod() {
		return waitingPeriod;
	}

	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	public String getSaCalculateType() {
		return saCalculateType;
	}

	public void setSaCalculateType(String saCalculateType) {
		this.saCalculateType = saCalculateType;
	}

}
