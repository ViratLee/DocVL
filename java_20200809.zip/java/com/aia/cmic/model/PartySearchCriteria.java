package com.aia.cmic.model;

import java.util.Date;

/**
 * @author ASNPAGM
 * @version 1.0
 * @created 10-Sep-2016 11:16:48 PM
 */
public class PartySearchCriteria extends BaseSearchCriteria {

	private String firstName;
	private String lastName;
	private String nationalId;
	private Date dateOfBirth;
	private String gender;
	private String policyNumber;
	private String clientId;
	private String certificateNumber;
	private String dependentCode;
	private String memberId;

	public PartySearchCriteria() {

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public String getFirstName() {
		return "";
	}

	/**
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName) {

	}

	public String getLastName() {
		return "";
	}

	/**
	 * 
	 * @param lastName
	 */
	public void setLastName(String lastName) {

	}

	public String getNationalId() {
		return "";
	}

	/**
	 * 
	 * @param nationalId
	 */
	public void setNationalId(String nationalId) {

	}

	public Date getDateOfBirth() {
		return null;
	}

	/**
	 * 
	 * @param dateOfBirth
	 */
	public void setDateOfBirth(Date dateOfBirth) {

	}

	public String getGender() {
		return "";
	}

	/**
	 * 
	 * @param gender
	 */
	public void setGender(String gender) {

	}

	public String getPolicyNumber() {
		return "";
	}

	/**
	 * 
	 * @param policyNumber
	 */
	public void setPolicyNumber(String policyNumber) {

	}

	public String getClientId() {
		return "";
	}

	/**
	 * 
	 * @param clientId
	 */
	public void setClientId(String clientId) {

	}

	public String getCertificateNumber() {
		return "";
	}

	/**
	 * 
	 * @param certificateNumber
	 */
	public void setCertificateNumber(String certificateNumber) {

	}

	public String getDependentCode() {
		return "";
	}

	/**
	 * 
	 * @param dependentCode
	 */
	public void setDependentCode(String dependentCode) {

	}

	public String getMemberId() {
		return "";
	}

	/**
	 * 
	 * @param memberId
	 */
	public void setMemberId(String memberId) {

	}

}