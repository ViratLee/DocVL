package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.entity.Physician;
import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.entity.ProviderDetail;
import com.aia.cmic.util.CMiCProviderConst;
import com.aia.cmic.util.FormatUtil;

public class PhysicianForm {
	private static final Logger LOG = LoggerFactory.getLogger(PhysicianForm.class);
	private Long physicianId;
	private String doctorID;
	private String doctorType = "";
	private String licenseNumber = "";
	private String companyId = " ";
	private Date effectivePeriod;
	private String doctorStatus = "";
	private Date terminatePeriod;
	private String doctorName = "";
	private String doctorSurname = "";
	private Boolean deathFlag;

	private String blackListIndicator = "";
	private String blackListReason = "";

	private Date backListStartDate;
	private Date backListEndDate;
	private String warningCode1_1 = "";
	private String warningCode1_2 = "";

	private String streetAddress = " ";

	private String district = "";
	private String city = "";
	private String province = "";
	private String region = "";
	private String country = "";
	private String zipcode = "";

	private String telephone = " ";
	private String fax = "";
	private List<String> medicalSpecialty;
	private List<String> holdServices;
	private List<String> practiceHospital;
	private List<String> serviceProvided;
	private List<String> awardAndAccreditation;
	private List<String> cmacWarningCode;

	public PhysicianForm() {
		init();
	}

	private void init() {
		this.physicianId = 0L;
		this.doctorID = null;
		this.medicalSpecialty = new ArrayList<>();
		this.holdServices = new ArrayList<>();
		this.practiceHospital = new ArrayList<>();
		this.serviceProvided = new ArrayList<>();
		this.awardAndAccreditation = new ArrayList<>();
		this.cmacWarningCode = new ArrayList<>();
	}

	public PhysicianForm(Physician physician, ProviderContact providerContact) {
		init();
		if (physician != null) {
			this.physicianId = physician.getPhysicianId();
			this.doctorID = FormatUtil.convertNull(physician.getDoctorCode());
			this.licenseNumber = FormatUtil.convertNull(physician.getLicenseNo());
			this.companyId = FormatUtil.convertNull(physician.getCompanyId());
			this.doctorType = FormatUtil.convertNull(physician.getType());
			this.doctorName = FormatUtil.convertNull(physician.getFirstName());
			this.doctorSurname = FormatUtil.convertNull(physician.getLastName());
			this.doctorStatus = FormatUtil.convertNull(physician.getStatus());
			this.effectivePeriod = physician.getEffectiveFromDt();
			this.terminatePeriod = physician.getEffectiveToDt();
			this.deathFlag = FormatUtil.convertNull(physician.getDeathInd()).equals("Y") ? Boolean.TRUE : Boolean.FALSE;
			this.backListStartDate = physician.getBlacklistStartDate();
			this.backListEndDate = physician.getBlacklistEndDate();
			this.blackListIndicator = physician.getBlacklistInd();
			this.blackListReason = physician.getBlacklistReason();

		}
		if (providerContact != null) {
			this.streetAddress = FormatUtil.convertNull(providerContact.getAddressLine1());
			this.district = FormatUtil.convertNull(providerContact.getDistrict());
			this.city = FormatUtil.convertNull(providerContact.getCity());
			this.province = FormatUtil.convertNull(providerContact.getProvince());
			this.region = FormatUtil.convertNull(providerContact.getRegion());
			this.country = FormatUtil.convertNull(providerContact.getCountry());
			this.zipcode = FormatUtil.convertNull(providerContact.getPostalCode());
			this.telephone = FormatUtil.convertNull(providerContact.getPhoneNo1());
			this.fax = FormatUtil.convertNull(providerContact.getFaxNo1());
		}

	}

	public Long getPhysicianId() {
		return physicianId;
	}

	public void setPhysicianId(Long physicianId) {
		this.physicianId = physicianId;
	}

	public String getDoctorID() {
		return doctorID;
	}

	public void setDoctorID(String doctorID) {
		this.doctorID = doctorID;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public Date getTerminatePeriod() {
		return terminatePeriod;
	}

	public void setTerminatePeriod(Date terminatePeriod) {
		this.terminatePeriod = terminatePeriod;
	}

	public Date getEffectivePeriod() {
		return effectivePeriod;
	}

	public void setEffectivePeriod(Date effectivePeriod) {
		this.effectivePeriod = effectivePeriod;
	}

	public List<String> getMedicalSpecialty() {
		return medicalSpecialty;
	}

	public void setMedicalSpecialty(List<String> medicalSpecialty) {
		this.medicalSpecialty = medicalSpecialty;
	}

	public List<String> getHoldServices() {
		return holdServices;
	}

	public void setHoldServices(List<String> holdServices) {
		this.holdServices = holdServices;
	}

	public List<String> getPracticeHospital() {
		return practiceHospital;
	}

	public void setPracticeHospital(List<String> practiceHospital) {
		this.practiceHospital = practiceHospital;
	}

	public List<String> getServiceProvided() {
		return serviceProvided;
	}

	public void setServiceProvided(List<String> serviceProvided) {
		this.serviceProvided = serviceProvided;
	}

	public List<String> getAwardAndAccreditation() {
		return awardAndAccreditation;
	}

	public void setAwardAndAccreditation(List<String> awardAndAccreditation) {
		this.awardAndAccreditation = awardAndAccreditation;
	}

	public List<String> getCmacWarningCode() {
		return cmacWarningCode;
	}

	public void setCmacWarningCode(List<String> cmacWarningCode) {
		this.cmacWarningCode = cmacWarningCode;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDoctorType() {
		return doctorType;
	}

	public void setDoctorType(String doctorType) {
		this.doctorType = doctorType;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public String getDoctorStatus() {
		return doctorStatus;
	}

	public void setDoctorStatus(String doctorStatus) {
		this.doctorStatus = doctorStatus;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getDoctorSurname() {
		return doctorSurname;
	}

	public void setDoctorSurname(String doctorSurname) {
		this.doctorSurname = doctorSurname;
	}

	public Boolean getDeathFlag() {
		return deathFlag;
	}

	public void setDeathFlag(Boolean deathFlag) {
		this.deathFlag = deathFlag;
	}

	public String getBlackListIndicator() {
		return blackListIndicator;
	}

	public void setBlackListIndicator(String blackListIndicator) {
		this.blackListIndicator = blackListIndicator;
	}

	public String getBlackListReason() {
		return blackListReason;
	}

	public void setBlackListReason(String blackListReason) {
		this.blackListReason = blackListReason;
	}

	public Date getBackListStartDate() {
		return backListStartDate;
	}

	public void setBackListStartDate(Date backListStartDate) {
		this.backListStartDate = backListStartDate;
	}

	public Date getBackListEndDate() {
		return backListEndDate;
	}

	public void setBackListEndDate(Date backListEndDate) {
		this.backListEndDate = backListEndDate;
	}

	public String getWarningCode1_1() {
		return warningCode1_1;
	}

	public void setWarningCode1_1(String warningCode1_1) {
		this.warningCode1_1 = warningCode1_1;
	}

	public String getWarningCode1_2() {
		return warningCode1_2;
	}

	public void setWarningCode1_2(String warningCode1_2) {
		this.warningCode1_2 = warningCode1_2;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getRegion() {
		return region;
	}

	public void setRegi(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public Physician toPhysicianEntity() {
		Physician physician = new Physician();
		physician.setDoctorCode(this.getDoctorID());
		physician.setLicenseNo(FormatUtil.convertNull(this.getLicenseNumber()));
		physician.setFirstName(FormatUtil.convertNull(this.getDoctorName()));
		physician.setLastName(FormatUtil.convertNull(this.getDoctorSurname()));
		physician.setType(this.getDoctorType());
		physician.setEffectiveFromDt(this.getEffectivePeriod());
		physician.setEffectiveToDt(this.getTerminatePeriod());
		physician.setDeathInd(FormatUtil.buildBooleanToString(this.getDeathFlag(), "N"));
		physician.setStatus(this.getDoctorStatus());
		physician.setBlacklistInd(this.getBlackListIndicator());
		physician.setBlacklistStartDate(this.getBackListStartDate());
		physician.setBlacklistEndDate(this.getBackListEndDate());
		physician.setBlacklistReason(FormatUtil.convertNull(this.getBlackListReason()));
		return physician;
	}

	public ProviderContact toProviderContact() {
		ProviderContact providerContact = new ProviderContact();
		providerContact.setDoctorCode(this.getDoctorID());
		providerContact.setFirstName(FormatUtil.convertNull(this.getDoctorName()));
		providerContact.setLastName(FormatUtil.convertNull(this.getDoctorSurname()));
		providerContact.setAddressLine1(FormatUtil.SetDefaultIsEmpty(this.getStreetAddress(), " "));
		providerContact.setCity(this.getCity());
		providerContact.setDistrict(this.getDistrict());
		providerContact.setProvince(this.getProvince());
		providerContact.setCountry(this.getCountry());
		providerContact.setRegion(this.getRegion());
		providerContact.setPhoneNo1(FormatUtil.SetDefaultIsEmpty(this.getTelephone(), " "));
		providerContact.setFaxNo1(this.getFax());
		providerContact.setPostalCode(this.getZipcode());
		providerContact.setContactType("PRIMARY");
		providerContact.setCreatedBy(" ");
		providerContact.setCreatedDt(new Date());
		return providerContact;

	}

	public List<ProviderDetail> toProviderDetail() {
		List<ProviderDetail> providerDetails = new ArrayList<ProviderDetail>();
		for (String medicalId : medicalSpecialty) {
			if (!StringUtils.isBlank(medicalId)) {
				providerDetails.add(initProviderDetail(CMiCProviderConst.MEDICALSPECIALTY, medicalId));
			}

		}
		for (String holdServ : holdServices) {
			if (!StringUtils.isBlank(holdServ)) {
				providerDetails.add(initProviderDetail(CMiCProviderConst.HOLDSERVICE, holdServ));
			}
		}

		for (String serviceProv : serviceProvided) {
			if (!StringUtils.isBlank(serviceProv)) {
				providerDetails.add(initProviderDetail(CMiCProviderConst.SERVICEPROVIDED, serviceProv));
			}
		}
		for (String warning : cmacWarningCode) {
			if (!StringUtils.isBlank(warning)) {
				providerDetails.add(initProviderDetail(CMiCProviderConst.CMICDORTORWARNINGCODE, warning));
			}
		}
		for (String accredition : awardAndAccreditation) {
			if (!StringUtils.isBlank(accredition)) {
				providerDetails.add(initProviderDetail(CMiCProviderConst.ACCREDITATION, accredition));
			}
		}

		for (String practiceHosp : practiceHospital) {
			if (!StringUtils.isBlank(practiceHosp)) {
				providerDetails.add(initProviderDetail(CMiCProviderConst.PRACTICALHOSPITAL, practiceHosp));
			}
		}

		return providerDetails;
	}

	ProviderDetail initProviderDetail(String codeType, String strValue) {
		ProviderDetail providerDetail = new ProviderDetail();
		providerDetail.setDoctorCode(this.getDoctorID());
		providerDetail.setCodeType(codeType);
		providerDetail.setCodeName(codeType);
		providerDetail.setStrValue(strValue);
		return providerDetail;
	}

}
