package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClaimView {
	private Long caseId;
	private Date receivedDate;
	private String policyNo;
	private String certNo;
	private String firstName;
	private String lastName;
	private String claimNo;
	private List<String> lossCodes = new ArrayList<>();
	private List<String> injuryAreas = new ArrayList<>();
	private Date lossDt;
	private Date dischargeDate;
	private Date hospitalizationDate;
	private String providerNameThai;
	private String channel;
	private Boolean vip;
	private Boolean urgent;
	private String urgentReason;
	private Date slaDt;
	private String claimStatus;
	private String claimType;
	private String phase;

	private Long claimId;
	private Date submissionDate;
	private Date settlementDate;
	//	private String claimStatus;
	//	private String claimNo;
	//	private String policyNo;
	//	private String certNo;
	private String memberId;
	private String insuredName;
	//	private String firstName;
	//	private String lastName;
	private Date accidentDt;
	private Date inHospitalDate;
	//	private Date dischargeDate;
	private String hospitalName;
	//	private String claimType;
	private String benefitType;
	private String lastUser;
	private String comment;
	private String treatmentType;
	private String fyi;

	//	private Long caseId;

	public ClaimView(Long caseId, Date receivedDate, String policyNo, String certNo, String firstName, String lastName, String claimNo, List<String> lossCodes, List<String> injuryAreas, Date lossDt,
			Date dischargeDate, Date hospitalizationDate, String providerNameThai, String channel) {
		this.caseId = caseId;
		this.receivedDate = receivedDate;
		this.policyNo = policyNo;
		this.certNo = certNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.claimNo = claimNo;
		this.lossCodes = lossCodes;
		this.injuryAreas = injuryAreas;
		this.lossDt = lossDt;
		this.dischargeDate = dischargeDate;
		this.hospitalizationDate = hospitalizationDate;
		this.providerNameThai = providerNameThai;
		this.channel = channel;
	}

	public ClaimView() {
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public List<String> getLossCodes() {
		return lossCodes;
	}

	public void setLossCode(List<String> lossCodes) {
		this.lossCodes = lossCodes;
	}

	public List<String> getInjuryAreas() {
		return injuryAreas;
	}

	public void setInjuryAreas(List<String> injuryAreas) {
		this.injuryAreas = injuryAreas;
	}

	public Date getLossDt() {
		return lossDt;
	}

	public void setLossDt(Date lossDt) {
		this.lossDt = lossDt;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Boolean getVip() {
		return vip;
	}

	public void setVip(Boolean vip) {
		this.vip = vip;
	}

	public Boolean getUrgent() {
		return urgent;
	}

	public void setUrgent(Boolean urgent) {
		this.urgent = urgent;
	}

	public String getUrgentReason() {
		return urgentReason;
	}

	public void setUrgentReason(String urgentReason) {
		this.urgentReason = urgentReason;
	}

	public Date getSlaDt() {
		return slaDt;
	}

	public void setSlaDt(Date slaDt) {
		this.slaDt = slaDt;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public void setLossCodes(List<String> lossCodes) {
		this.lossCodes = lossCodes;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Date getInHospitalDate() {
		return inHospitalDate;
	}

	public void setInHospitalDate(Date inHospitalDate) {
		this.inHospitalDate = inHospitalDate;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getBenefitType() {
		return benefitType;
	}

	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}

	public String getLastUser() {
		return lastUser;
	}

	public void setLastUser(String lastUser) {
		this.lastUser = lastUser;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public String getFyi() {
		return fyi;
	}

	public void setFyi(String fyi) {
		this.fyi = fyi;
	}

}