package com.aia.cmic.model;

import java.io.Serializable;

public class ProviderCompass implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String hcCode;
	private String providerCode;
	private String payeeName;
	private String providerNameThai;
	private String providerRegNameThai;
	private String prevHospitalCode;
	private String prevCompassCode;
	private String emailAddres1;
	private String emailAddres2;
	private String faxNo1;
	private String faxNo2;

	public String getHcCode() {
		return hcCode;
	}

	public void setHcCode(String hcCode) {
		this.hcCode = hcCode;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getProviderRegNameThai() {
		return providerRegNameThai;
	}

	public void setProviderRegNameThai(String providerRegNameThai) {
		this.providerRegNameThai = providerRegNameThai;
	}

	public String getPrevHospitalCode() {
		return prevHospitalCode;
	}

	public void setPrevHospitalCode(String prevHospitalCode) {
		this.prevHospitalCode = prevHospitalCode;
	}

	public String getPrevCompassCode() {
		return prevCompassCode;
	}

	public void setPrevCompassCode(String prevCompassCode) {
		this.prevCompassCode = prevCompassCode;
	}

	public String getEmailAddres1() {
		return emailAddres1;
	}

	public void setEmailAddres1(String emailAddres1) {
		this.emailAddres1 = emailAddres1;
	}

	public String getEmailAddres2() {
		return emailAddres2;
	}

	public void setEmailAddres2(String emailAddres2) {
		this.emailAddres2 = emailAddres2;
	}

	public String getFaxNo1() {
		return faxNo1;
	}

	public void setFaxNo1(String faxNo1) {
		this.faxNo1 = faxNo1;
	}

	public String getFaxNo2() {
		return faxNo2;
	}

	public void setFaxNo2(String faxNo2) {
		this.faxNo2 = faxNo2;
	}

}
