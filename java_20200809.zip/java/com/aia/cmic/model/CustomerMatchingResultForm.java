package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomerMatchingResultForm {

	private static final Logger LOG = LoggerFactory.getLogger(CustomerMatchingResultForm.class);
	private String partyID;
	private String name;
	private Date dob;
	private String gender;
	private String policyNo;
	private String certNo;
	private String nationalID;
	private String role;

	public final String getPartyID() {
		return partyID;
	}

	public final void setPartyID(String partyID) {
		this.partyID = partyID;
	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}

	public final Date getDob() {
		return dob;
	}

	public final void setDob(Date dob) {
		this.dob = dob;
	}

	public final String getGender() {
		return gender;
	}

	public final void setGender(String gender) {
		this.gender = gender;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getCertNo() {
		return certNo;
	}

	public final void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public final String getNationalID() {
		return nationalID;
	}

	public final void setNationalID(String nationalID) {
		this.nationalID = nationalID;
	}

	public final String getRole() {
		return role;
	}

	public final void setRole(String role) {
		this.role = role;
	}

	public static final Logger getLog() {
		return LOG;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
