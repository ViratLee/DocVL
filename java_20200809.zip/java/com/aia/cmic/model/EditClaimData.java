package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.List;

public class EditClaimData {
	BenefitDeterminationPaymentRefreshForm benefitDeterminationPaymentRefreshForm;
	private List<BillingItem> billingItems;
	List<ClaimComment> comments;
	private BigDecimal totalEstimatedCost;
	private BigDecimal totalBilledAmt;

	public List<ClaimComment> getComments() {
		return comments;
	}

	public void setComments(List<ClaimComment> comments) {
		this.comments = comments;
	}

	public BenefitDeterminationPaymentRefreshForm getBenefitDeterminationPaymentRefreshForm() {
		return benefitDeterminationPaymentRefreshForm;
	}

	public void setBenefitDeterminationPaymentRefreshForm(BenefitDeterminationPaymentRefreshForm benefitDeterminationPaymentRefreshForm) {
		this.benefitDeterminationPaymentRefreshForm = benefitDeterminationPaymentRefreshForm;
	}

	public List<BillingItem> getBillingItems() {
		return billingItems;
	}

	public void setBillingItems(List<BillingItem> billingItems) {
		this.billingItems = billingItems;
	}

	public BigDecimal getTotalEstimatedCost() {
		return totalEstimatedCost;
	}

	public void setTotalEstimatedCost(BigDecimal totalEstimatedCost) {
		this.totalEstimatedCost = totalEstimatedCost;
	}

	public BigDecimal getTotalBilledAmt() {
		return totalBilledAmt;
	}

	public void setTotalBilledAmt(BigDecimal totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

}
