package com.aia.cmic.model;

import java.util.Date;

public class Payee {
	private Long payeeId;
	private String claimNo;
	private Integer occurrence;
	private String policyNo;
	private String payeeType;
	private String title;
	private String firstName;
	private String lastName;
	private String nationalId;
	private String bankruptcyInd;
	private Date bankruptcyDt;
	private String blacklistInd;
	private String amloInd;
	private String ofacInd;
	private String fatcaInd;
	private String secInd;
	private String oncbInd;
	private String politicalInd;
	private String suspenseInd;
	private String watchlistInd;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String city;
	private String state;
	private String postalCode;
	private String country;
	private String emailAddress;
	private String mobile;
	private String telephone;
	private String bankAccountNo;
	private String bankCode;
	private String acctType;
	private String payeeTaxNo;
	private String billingTypeCd;
	private Date dob;

	/**
	 * @return the payeeId
	 */
	public Long getPayeeId() {
		return payeeId;
	}

	/**
	 * @param payeeId
	 *            the payeeId to set
	 */
	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo
	 *            the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence
	 *            the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo
	 *            the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the nationalId
	 */
	public String getNationalId() {
		return nationalId;
	}

	/**
	 * @param nationalId
	 *            the nationalId to set
	 */
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	/**
	 * @return the bankruptcyInd
	 */
	public String getBankruptcyInd() {
		return bankruptcyInd;
	}

	/**
	 * @param bankruptcyInd
	 *            the bankruptcyInd to set
	 */
	public void setBankruptcyInd(String bankruptcyInd) {
		this.bankruptcyInd = bankruptcyInd;
	}

	/**
	 * @return the blacklistInd
	 */
	public String getBlacklistInd() {
		return blacklistInd;
	}

	/**
	 * @param blacklistInd
	 *            the blacklistInd to set
	 */
	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	/**
	 * @return the amloInd
	 */
	public String getAmloInd() {
		return amloInd;
	}

	/**
	 * @param amloInd
	 *            the amloInd to set
	 */
	public void setAmloInd(String amloInd) {
		this.amloInd = amloInd;
	}

	/**
	 * @return the ofacInd
	 */
	public String getOfacInd() {
		return ofacInd;
	}

	/**
	 * @param ofacInd
	 *            the ofacInd to set
	 */
	public void setOfacInd(String ofacInd) {
		this.ofacInd = ofacInd;
	}

	/**
	 * @return the fatcaInd
	 */
	public String getFatcaInd() {
		return fatcaInd;
	}

	/**
	 * @param fatcaInd
	 *            the fatcaInd to set
	 */
	public void setFatcaInd(String fatcaInd) {
		this.fatcaInd = fatcaInd;
	}

	public String getSecInd() {
		return secInd;
	}

	public void setSecInd(String secInd) {
		this.secInd = secInd;
	}

	public String getOncbInd() {
		return oncbInd;
	}

	public void setOncbInd(String oncbInd) {
		this.oncbInd = oncbInd;
	}

	public String getPoliticalInd() {
		return politicalInd;
	}

	public void setPoliticalInd(String politicalInd) {
		this.politicalInd = politicalInd;
	}

	public String getSuspenseInd() {
		return suspenseInd;
	}

	public void setSuspenseInd(String suspenseInd) {
		this.suspenseInd = suspenseInd;
	}

	public String getWatchlistInd() {
		return watchlistInd;
	}

	public void setWatchlistInd(String watchlistInd) {
		this.watchlistInd = watchlistInd;
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1
	 *            the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2
	 *            the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3
	 *            the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 * @return the addressLine4
	 */
	public String getAddressLine4() {
		return addressLine4;
	}

	/**
	 * @param addressLine4
	 *            the addressLine4 to set
	 */
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city
	 *            the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode
	 *            the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone
	 *            the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @return the bankAccountNo
	 */
	public String getBankAccountNo() {
		return bankAccountNo;
	}

	/**
	 * @param bankAccountNo
	 *            the bankAccountNo to set
	 */
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode
	 *            the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the acctType
	 */
	public String getAcctType() {
		return acctType;
	}

	/**
	 * @param acctType
	 *            the acctType to set
	 */
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	/**
	 * @return the payeeTaxNo
	 */
	public String getPayeeTaxNo() {
		return payeeTaxNo;
	}

	/**
	 * @param payeeTaxNo
	 *            the payeeTaxNo to set
	 */
	public void setPayeeTaxNo(String payeeTaxNo) {
		this.payeeTaxNo = payeeTaxNo;
	}

	/**
	 * @return the billingTypeCd
	 */
	public String getBillingTypeCd() {
		return billingTypeCd;
	}

	/**
	 * @param billingTypeCd
	 *            the billingTypeCd to set
	 */
	public void setBillingTypeCd(String billingTypeCd) {
		this.billingTypeCd = billingTypeCd;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getBankruptcyDt() {
		return bankruptcyDt;
	}

	public void setBankruptcyDt(Date bankruptcyDt) {
		this.bankruptcyDt = bankruptcyDt;
	}

}
