package com.aia.cmic.model;

import java.math.BigDecimal;

public class ClaimPaymentWorking {

	Long claimPaymentWorkingId;
	String companyId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String planCoverageNo;
	String productCode;
	String productType;
	String businessLine;
	String procedureCatId;
	String benefitCode;
	String serviceCatId;
	Integer seqId;
	BigDecimal presentedAmt;
	BigDecimal eligibleAmt;
	Integer noOfDaysAllocated;
	BigDecimal percentageAllocated;
	BigDecimal shortFallAmt;
	Integer reimbursedDay;

	/**
	 * @return the claimPaymentWorkingId
	 */
	public Long getClaimPaymentWorkingId() {
		return claimPaymentWorkingId;
	}

	/**
	 * @param claimPaymentWorkingId the claimPaymentWorkingId to set
	 */
	public void setClaimPaymentWorkingId(Long claimPaymentWorkingId) {
		this.claimPaymentWorkingId = claimPaymentWorkingId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 * @return the procedureCatId
	 */
	public String getProcedureCatId() {
		return procedureCatId;
	}

	/**
	 * @param procedureCatId the procedureCatId to set
	 */
	public void setProcedureCatId(String procedureCatId) {
		this.procedureCatId = procedureCatId;
	}

	/**
	 * @return the benefitCode
	 */
	public String getBenefitCode() {
		return benefitCode;
	}

	/**
	 * @param benefitCode the benefitCode to set
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 * @return the serviceCatId
	 */
	public String getServiceCatId() {
		return serviceCatId;
	}

	/**
	 * @param serviceCatId the serviceCatId to set
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 * @return the seqId
	 */
	public Integer getSeqId() {
		return seqId;
	}

	/**
	 * @param seqId the seqId to set
	 */
	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}

	/**
	 * @return the presentedAmt
	 */
	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	/**
	 * @param presentedAmt the presentedAmt to set
	 */
	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 * @return the eligibleAmt
	 */
	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	/**
	 * @param eligibleAmt the eligibleAmt to set
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 * @return the noOfDaysAllocated
	 */
	public Integer getNoOfDaysAllocated() {
		return noOfDaysAllocated;
	}

	/**
	 * @param noOfDaysAllocated the noOfDaysAllocated to set
	 */
	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	/**
	 * @return the percentageAllocated
	 */
	public BigDecimal getPercentageAllocated() {
		return percentageAllocated;
	}

	/**
	 * @param percentageAllocated the percentageAllocated to set
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 * @return the shortFallAmt
	 */
	public BigDecimal getShortFallAmt() {
		return shortFallAmt;
	}

	/**
	 * @param shortFallAmt the shortFallAmt to set
	 */
	public void setShortFallAmt(BigDecimal shortFallAmt) {
		this.shortFallAmt = shortFallAmt;
	}

	/**
	 * @return the reimbursedDay
	 */
	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	/**
	 * @param reimbursedDay the reimbursedDay to set
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

}
