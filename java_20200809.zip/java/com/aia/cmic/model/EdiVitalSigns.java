package com.aia.cmic.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiVitalSigns {

	private Long ediVitalSignId;
	private String claimNo;
	private Integer occurrence;
	@JsonProperty("respiratoryRate")
	private String respiratoryRate;
	@JsonProperty("heartRate")
	private String heartRate;
	@JsonProperty("temperature")
	private String temperature;
	@JsonProperty("systolicBp")
	private String systolicbp;
	@JsonProperty("diastolicBp")
	private String diastolicbp;
	@JsonProperty("painScore")
	private String painScore;
	@JsonProperty("vitalSignEntryDateTime")
	@JsonFormat(shape = Shape.STRING, pattern = "dd-MM-yyyy HH:mm:ss")
	private Date vitalSignEntryDateTime;
	private Integer groupId;

	public Long getEdiVitalSignId() {
		return ediVitalSignId;
	}

	public void setEdiVitalSignId(Long ediVitalSignId) {
		this.ediVitalSignId = ediVitalSignId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getRespiratoryRate() {
		return respiratoryRate;
	}

	public void setRespiratoryRate(String respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}

	public String getHeartRate() {
		return heartRate;
	}

	public void setHeartRate(String heartRate) {
		this.heartRate = heartRate;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getSystolicbp() {
		return systolicbp;
	}

	public void setSystolicbp(String systolicbp) {
		this.systolicbp = systolicbp;
	}

	public String getDiastolicbp() {
		return diastolicbp;
	}

	public void setDiastolicbp(String diastolicbp) {
		this.diastolicbp = diastolicbp;
	}

	public String getPainScore() {
		return painScore;
	}

	public void setPainScore(String painScore) {
		this.painScore = painScore;
	}

	public Date getVitalSignEntryDateTime() {
		return vitalSignEntryDateTime;
	}

	public void setVitalSignEntryDateTime(Date vitalSignEntryDateTime) {
		this.vitalSignEntryDateTime = vitalSignEntryDateTime;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

}
