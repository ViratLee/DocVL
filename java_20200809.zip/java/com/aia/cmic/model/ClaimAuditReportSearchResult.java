package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ClaimAuditReport;
import com.aia.cmic.util.FormatUtil;

public class ClaimAuditReportSearchResult {

	private String claimNo;
	private int occurrence;
	private String policyNo;
	private int planId;
	private String planName;
	private String ruleNo;
	private Date settlementDate;
	private BigDecimal approvedAmt;

	private Lookup markingId;
	private Lookup markingReason;

	public ClaimAuditReportSearchResult() {

	}

	public ClaimAuditReportSearchResult(ClaimAuditReport claim) {
		this.claimNo = claim.getClaimNo();
		this.occurrence = claim.getOccurrence();
		this.policyNo = claim.getPolicyNo();
		this.planId = claim.getPlanId();
		this.planName = claim.getPlanName();
		this.ruleNo = claim.getRuleNo();
		this.settlementDate = claim.getSettlementDate();
		this.approvedAmt = claim.getApprovedAmt();

		Lookup lookup = new Lookup();
		lookup.setKey(FormatUtil.convertNull(claim.getMarkingId()));
		lookup.setValue(FormatUtil.convertNull(claim.getMarkingDesc()));
		this.markingId = lookup;
		lookup = new Lookup();
		lookup.setKey(FormatUtil.convertNull(claim.getMarkingReason()));
		lookup.setValue(FormatUtil.convertNull(claim.getMarkingReasonDesc()));
		this.markingReason = lookup;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public int getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(int occurrence) {
		this.occurrence = occurrence;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getRuleNo() {
		return ruleNo;
	}

	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}

	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

	public Lookup getMarkingId() {
		return markingId;
	}

	public void setMarkingId(Lookup markingId) {
		this.markingId = markingId;
	}

	public Lookup getMarkingReason() {
		return markingReason;
	}

	public void setMarkingReason(Lookup markingReason) {
		this.markingReason = markingReason;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
