package com.aia.cmic.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "PRINT")
@XmlAccessorType(XmlAccessType.FIELD)
public class OnlinePrint {
	@XmlElement(name = "FORM")
	OnlinePrintForm form;

	public OnlinePrintForm getForm() {
		return form;
	}

	public void setForm(OnlinePrintForm form) {
		this.form = form;
	}

}
