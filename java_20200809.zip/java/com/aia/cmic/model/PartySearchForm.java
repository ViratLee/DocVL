package com.aia.cmic.model;

public class PartySearchForm extends SearchForm {
	private String partyIdSearch;
	private String firstName;
	private String lastName;
	private String policyNumber;
	private String nationalId;
	private String customerId;
	private String certificateNumber;
	private String dependentCode;
	private String memberId;
	private boolean hnwPolicy = false;

	public String getPartyIdSearch() {
		return partyIdSearch;
	}

	public void setPartyIdSearch(String partyIdSearch) {
		this.partyIdSearch = partyIdSearch;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCertificateNumber() {
		return certificateNumber;
	}

	public void setCertificateNumber(String certificateNumber) {
		this.certificateNumber = certificateNumber;
	}

	public String getDependentCode() {
		return dependentCode;
	}

	public void setDependentCode(String dependentCode) {
		this.dependentCode = dependentCode;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public boolean isHnwPolicy() {
		return hnwPolicy;
	}

	public void setHnwPolicy(boolean hnwPolicy) {
		this.hnwPolicy = hnwPolicy;
	}
	
	
}
