package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.repository.soap.uam.UserInfoForm;

public class IndexingSubmitForm {

	private static final Logger LOG = LoggerFactory.getLogger(IndexingSubmitForm.class);
	String action;
	Long caseId;
	CMiCClaim cmicClaim;
	UserInfoForm userInfoForm;
	ImageDocument images;

	public IndexingSubmitForm() {

	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public final Long getCaseId() {
		return caseId;
	}

	public final void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public final CMiCClaim getCmicClaim() {
		return cmicClaim;
	}

	public final void setCmicClaim(CMiCClaim cmicClaim) {
		this.cmicClaim = cmicClaim;
	}

	public final UserInfoForm getUserInfoForm() {
		return userInfoForm;
	}

	public final void setUserInfoForm(UserInfoForm userInfoForm) {
		this.userInfoForm = userInfoForm;
	}

	public final ImageDocument getImages() {
		return images;
	}

	public final void setImages(ImageDocument images) {
		this.images = images;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
