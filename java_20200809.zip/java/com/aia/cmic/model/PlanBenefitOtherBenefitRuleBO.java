package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

public class PlanBenefitOtherBenefitRuleBO {
	List<String> generalExclusionList = new ArrayList<String>();
	List<String> geographicLimitList = new ArrayList<String>();
	List<String> coverageTreatmentList = new ArrayList<String>();
	List<String> coverMedConditionList = new ArrayList<String>();
	List<String> restricSectorList = new ArrayList<String>();
	List<String> restricRoomTypeList = new ArrayList<String>();

	public List<String> getGeneralExclusionList() {
		return generalExclusionList;
	}

	public void setGeneralExclusionList(List<String> generalExclusionList) {
		this.generalExclusionList = generalExclusionList;
	}

	public List<String> getGeographicLimitList() {
		return geographicLimitList;
	}

	public void setGeographicLimitList(List<String> geographicLimitList) {
		this.geographicLimitList = geographicLimitList;
	}

	public List<String> getCoverageTreatmentList() {
		return coverageTreatmentList;
	}

	public void setCoverageTreatmentList(List<String> coverageTreatmentList) {
		this.coverageTreatmentList = coverageTreatmentList;
	}

	public List<String> getCoverMedConditionList() {
		return coverMedConditionList;
	}

	public void setCoverMedConditionList(List<String> coverMedConditionList) {
		this.coverMedConditionList = coverMedConditionList;
	}

	public List<String> getRestricSectorList() {
		return restricSectorList;
	}

	public void setRestricSectorList(List<String> restricSectorList) {
		this.restricSectorList = restricSectorList;
	}

	public List<String> getRestricRoomTypeList() {
		return restricRoomTypeList;
	}

	public void setRestricRoomTypeList(List<String> restricRoomTypeList) {
		this.restricRoomTypeList = restricRoomTypeList;
	}

}
