package com.aia.cmic.model;

import java.math.BigDecimal;

public class AiClaimPaymentHistory {
	private Long CLAIMPAYMENTID;
	private BigDecimal APPROVEDAMT;
	private String CLAIMNO;
	private String ELIGIBILITY;
	private Integer OCCURRENCE;
	private String PAYEETYPE;
	private String PAYMENTSTATUS;
	private String PLANCOVERAGENO;
	private Long PLANID;
	private String POLICYNO;
	private String AIDECISION;
	private String AIINDICATOR;
	private String AISCORE;
	
	public Long getCLAIMPAYMENTID() {
		return CLAIMPAYMENTID;
	}
	public void setCLAIMPAYMENTID(Long cLAIMPAYMENTID) {
		CLAIMPAYMENTID = cLAIMPAYMENTID;
	}
	public BigDecimal getAPPROVEDAMT() {
		return APPROVEDAMT;
	}
	public void setAPPROVEDAMT(BigDecimal aPPROVEDAMT) {
		APPROVEDAMT = aPPROVEDAMT;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public String getELIGIBILITY() {
		return ELIGIBILITY;
	}
	public void setELIGIBILITY(String eLIGIBILITY) {
		ELIGIBILITY = eLIGIBILITY;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getPAYEETYPE() {
		return PAYEETYPE;
	}
	public void setPAYEETYPE(String pAYEETYPE) {
		PAYEETYPE = pAYEETYPE;
	}
	public String getPAYMENTSTATUS() {
		return PAYMENTSTATUS;
	}
	public void setPAYMENTSTATUS(String pAYMENTSTATUS) {
		PAYMENTSTATUS = pAYMENTSTATUS;
	}
	public String getPLANCOVERAGENO() {
		return PLANCOVERAGENO;
	}
	public void setPLANCOVERAGENO(String pLANCOVERAGENO) {
		PLANCOVERAGENO = pLANCOVERAGENO;
	}
	public Long getPLANID() {
		return PLANID;
	}
	public void setPLANID(Long pLANID) {
		PLANID = pLANID;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	public String getAIDECISION() {
		return AIDECISION;
	}
	public void setAIDECISION(String aIDECISION) {
		AIDECISION = aIDECISION;
	}
	public String getAIINDICATOR() {
		return AIINDICATOR;
	}
	public void setAIINDICATOR(String aIINDICATOR) {
		AIINDICATOR = aIINDICATOR;
	}
	public String getAISCORE() {
		return AISCORE;
	}
	public void setAISCORE(String aISCORE) {
		AISCORE = aISCORE;
	}
	
	

}
