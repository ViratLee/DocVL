package com.aia.cmic.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class BenefitSettleBenefitDetail {
	@XmlElement(name = "benefitDetailId")
	Long benefitDetailId;
	@XmlElement(name = "planId")
	Long planId;
	@XmlElement(name = "benefitCode")
	String benefitCode;
	@XmlElement(name = "benefitDesc")
	String benefitDesc;
	@XmlElement(name = "amount")
	BigDecimal amount = BigDecimal.ZERO;
	@XmlElement(name = "day")
	int day = 0;
	@XmlElement(name = "percentage")
	BigDecimal percentage = BigDecimal.ZERO;
	@XmlElement(name = "disabilityBetweenDate")
	String disabilityBetweenDate = "";
	@XmlElement(name = "dbInd")
	String dbInd = "";
	@XmlElement(name = "reimbursedDay")
	Integer reimbursedDay = 0;
	@XmlElement(name = "eligibleAmtL")
	BigDecimal eligibleAmtL = BigDecimal.ZERO;
	@XmlElement(name = "presentedAmt")
	BigDecimal presentedAmt = BigDecimal.ZERO;
	@XmlElement(name = "copaymentPercent")
	BigDecimal copaymentPercent = BigDecimal.ZERO;

	@XmlElement(name = "productCode")
	String productCode;

	@XmlElement(name = "benefitLimit")
	BigDecimal benefitLimit = BigDecimal.ZERO;

	@XmlElement(name = "dayTime")
	BigDecimal dayTime = BigDecimal.ZERO;

	@XmlElement(name = "shortfallAmt")
	BigDecimal shortfallAmt = BigDecimal.ZERO;

	@XmlElement(name = "deductAmt")
	BigDecimal deductAmt = BigDecimal.ZERO;

	@XmlElement(name = "reimbursedPercent")
	BigDecimal reimbursedPercent = BigDecimal.ZERO;

	@XmlElement(name = "copaymentAmt")
	BigDecimal copaymentAmt = BigDecimal.ZERO;

	@XmlElement(name = "eligibleMinusShortfallAmt")
	BigDecimal eligibleMinusShortfallAmt = BigDecimal.ZERO;

	public BigDecimal getCopaymentAmt() {
		return copaymentAmt;
	}

	public void setCopaymentAmt(BigDecimal copaymentAmt) {
		this.copaymentAmt = copaymentAmt;
	}

	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	public BigDecimal getReimbursedPercent() {
		return reimbursedPercent;
	}

	public void setReimbursedPercent(BigDecimal reimbursedPercent) {
		this.reimbursedPercent = reimbursedPercent;
	}

	public BigDecimal getShortfallAmt() {
		return shortfallAmt;
	}

	public void setShortfallAmt(BigDecimal shortfallAmt) {
		this.shortfallAmt = shortfallAmt;
	}

	public BigDecimal getBenefitLimit() {
		return benefitLimit;
	}

	public void setBenefitLimit(BigDecimal benefitLimit) {
		this.benefitLimit = benefitLimit;
	}

	public BigDecimal getDayTime() {
		return dayTime;
	}

	public void setDayTime(BigDecimal dayTime) {
		this.dayTime = dayTime;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Long getBenefitDetailId() {
		return benefitDetailId;
	}

	public void setBenefitDetailId(Long benefitDetailId) {
		this.benefitDetailId = benefitDetailId;
	}

	public BigDecimal getCopaymentPercent() {
		return copaymentPercent;
	}

	public void setCopaymentPercent(BigDecimal copaymentPercent) {
		this.copaymentPercent = copaymentPercent;
	}

	public String getDbInd() {
		return dbInd;
	}

	public void setDbInd(String dbInd) {
		this.dbInd = dbInd;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	public BigDecimal getEligibleAmtL() {
		return eligibleAmtL;
	}

	public void setEligibleAmtL(BigDecimal eligibleAmtL) {
		this.eligibleAmtL = eligibleAmtL;
	}

	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public String getBenefitDesc() {
		return benefitDesc;
	}

	public void setBenefitDesc(String benefitDesc) {
		this.benefitDesc = benefitDesc;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public BigDecimal getPercentage() {
		return percentage;
	}

	public void setPercentage(BigDecimal percentage) {
		this.percentage = percentage;
	}

	public String getDisabilityBetweenDate() {
		return disabilityBetweenDate;
	}

	public void setDisabilityBetweenDate(String disabilityBetweenDate) {
		this.disabilityBetweenDate = disabilityBetweenDate;
	}

	public BigDecimal getEligibleMinusShortfallAmt() {
		return eligibleMinusShortfallAmt;
	}

	public void setEligibleMinusShortfallAmt(BigDecimal eligibleMinusShortfallAmt) {
		this.eligibleMinusShortfallAmt = eligibleMinusShortfallAmt;
	}

}
