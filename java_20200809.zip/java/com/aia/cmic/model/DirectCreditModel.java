package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ClaimPaymentTransfer;

public class DirectCreditModel {
	private String providerCode;
	private String providerName;
	private String typeOfTreatment;
	private BigDecimal transferAmount;
	private Date settleDate;
	private Date transferDate;
	private String stpInd;
	private String ediInd;

	private List<DirectCreditDetailModel> lstDirectCreditDetail = new ArrayList<>();

	public DirectCreditModel() {
	}

	public DirectCreditModel(ClaimPaymentTransfer entity) {
		providerCode = entity.getProviderCode();
		providerName = entity.getProviderNameThai();
		typeOfTreatment = entity.getTreatmentType();
		transferAmount = entity.getPresentedAmt();
		transferDate = entity.getPaymentTransferDt();
		settleDate = entity.getSettlementDate();
		stpInd = StringUtils.isEmpty(entity.getStpInd()) ? "N" : entity.getStpInd();
		ediInd = StringUtils.isEmpty(entity.getEdiInd()) ? "N" : entity.getEdiInd();
	}

	public void addChild(ClaimPaymentTransfer child) {
		if (child.getPresentedAmt() != null) {
			transferAmount = transferAmount.add(child.getPresentedAmt());
		}
		DirectCreditDetailModel lst = new DirectCreditDetailModel();
		lst.setAmount(child.getPresentedAmt());
		lst.setClaimPaymentId(child.getClaimPaymentId());
		lst.setName(child.getName());
		lst.setIncidentDt(child.getIncidentDt());
		lst.setInvoiceDt(child.getInvoiceDate());
		lst.setRemark(child.getRemark());
		lst.setInvoiceNum(child.getInvoiceNum());
		lst.setEdiInd(StringUtils.isEmpty(child.getEdiInd()) ? "N" : child.getEdiInd());
		lst.setStpInd(StringUtils.isEmpty(child.getStpInd()) ? "N" : child.getStpInd());
		lstDirectCreditDetail.add(lst);

		//lstClaimPaymentId.add(child.lstClaimPaymentId.get(0));
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getTypeOfTreatment() {
		return typeOfTreatment;
	}

	public void setTypeOfTreatment(String typeOfTreatment) {
		this.typeOfTreatment = typeOfTreatment;
	}

	public BigDecimal getTransferAmount() {
		return transferAmount;
	}

	public void setTransferAmount(BigDecimal transferAmount) {
		this.transferAmount = transferAmount;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public List<DirectCreditDetailModel> getLstDirectCreditDetail() {
		return lstDirectCreditDetail;
	}

	public void setLstDirectCreditDetail(List<DirectCreditDetailModel> lstDirectCreditDetail) {
		this.lstDirectCreditDetail = lstDirectCreditDetail;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

}