package com.aia.cmic.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class BenefitBillingItem {
	@XmlElement(name = "presentedID")
	Long presentedID;
	@XmlElement(name = "presentedBillingItems")
	String presentedBillingItems;
	@XmlElement(name = "presentedAmount")
	BigDecimal presentedAmount = BigDecimal.ZERO;

	public String getPresentedBillingItems() {
		return presentedBillingItems;
	}

	public void setPresentedBillingItems(String presentedBillingItems) {
		this.presentedBillingItems = presentedBillingItems;
	}

	public Long getPresentedID() {
		return this.presentedID;
	}

	public void setPresentedID(Long presentedID) {
		this.presentedID = presentedID;
	}

	public BigDecimal getPresentedAmount() {
		return presentedAmount;
	}

	public void setPresentedAmount(BigDecimal presentedAmount) {
		this.presentedAmount = presentedAmount;
	}

}
