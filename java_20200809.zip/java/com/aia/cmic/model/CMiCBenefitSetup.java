package com.aia.cmic.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CMiCBenefitSetup implements Serializable {

	private List<PlanBenefitSetupDetail> planSetupList = new ArrayList<PlanBenefitSetupDetail>();

	public List<PlanBenefitSetupDetail> getPlanSetupList() {
		return planSetupList;
	}

	public void setPlanSetupList(List<PlanBenefitSetupDetail> planSetupList) {
		this.planSetupList = planSetupList;
	}

	public void resetPlanSetupList() {
		planSetupList = null;
	}

	public void newPlanSetupList() {
		planSetupList = new ArrayList<PlanBenefitSetupDetail>();
	}

}
