package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.entity.ICD10Code;
import com.aia.cmic.entity.ICD9Code;
import com.aia.cmic.entity.ProviderContract;
import com.aia.cmic.entity.ProviderContractDetail;
import com.aia.cmic.entity.ServiceItem;
import com.aia.cmic.services.CommonDataService;
import com.aia.cmic.util.CMiCUtil;
import com.aia.cmic.util.FormatUtil;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProviderContractForm {
	private static final Logger LOG = LoggerFactory.getLogger(ProviderContractForm.class);
	private String saveMode;
	private Long providerContractId;
	private String providerCode;
	private String providerName;
	private String contractCode;
	private String contractStatus;
	private String contractStatusDesc;
	private String contractProcessStatus;
	private String networkName;
	private Date effectiveDate;
	private Date expiryDate;
	private Integer paymentTerm;
	private List<Long> removeProviderContractDetailId = new ArrayList<Long>();
	private String capitatedService;

	private List<String> serviceCatId;
	//	private String serviceCoverage;
	private String serviceCoverageOPD;
	private String serviceCoverageIPD;

	public static final String OPD = "OPD";
	public static final String IPD = "IPD";
	public static final String CAPITATEDSERVICE = "capitatedservice";

	private List<ProviderContractDetailForm> providerContractDetail = new ArrayList<ProviderContractDetailForm>();

	public Long getProviderContractId() {
		return providerContractId;
	}

	public void setProviderContractId(Long providerContractId) {
		this.providerContractId = providerContractId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(Integer paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public List<String> getServiceCatId() {
		return serviceCatId;
	}

	public void setServiceCatId(List<String> serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	public List<ProviderContractDetailForm> getProviderContractDetail() {
		return providerContractDetail;
	}

	public void setProviderContractDetail(List<ProviderContractDetailForm> providerContractDetail) {
		this.providerContractDetail = providerContractDetail;
	}

	public List<Long> getRemoveProviderContractDetailId() {
		return removeProviderContractDetailId;
	}

	public void setRemoveProviderContractDetailId(List<Long> removeProviderContractDetailId) {
		this.removeProviderContractDetailId = removeProviderContractDetailId;
	}

	//	public String getServiceCoverage() {
	//		return serviceCoverage;
	//	}
	//
	//	public void setServiceCoverage(String serviceCoverage) {
	//		this.serviceCoverage = serviceCoverage;
	//	}

	public String getSaveMode() {
		return saveMode;
	}

	public void setSaveMode(String saveMode) {
		this.saveMode = saveMode;
	}

	public static ProviderContractForm convertProviderContractBOToForm(ProviderContractBO providerContractBO, CommonDataService commonDataService) {
		ProviderContract providerContract = providerContractBO.getProviderContract();
		List<ProviderContractDetail> providerContractDetails = providerContractBO.getProviderContractDetails();

		ProviderContractForm providerContractForm = new ProviderContractForm();
		providerContractForm.setContractCode(convertToString(providerContract.getContractId()));

		String contractStatus = CMiCUtil.getCommonCodeDesc(commonDataService.getCachingMasterDataHelper().findContractStatus(providerContract.getContractStatus()));
		providerContractForm.setContractStatus(providerContract.getContractStatus());
		providerContractForm.setContractStatusDesc(contractStatus);

		providerContractForm.setContractProcessStatus(providerContract.getContractProcessStatus());
		providerContractForm.setEffectiveDate(providerContract.getEffectiveFromDt());
		providerContractForm.setExpiryDate(providerContract.getEffectiveToDt());
		providerContractForm.setNetworkName(providerContract.getNetworkName());
		providerContractForm.setPaymentTerm(providerContract.getPaymentTerm());
		providerContractForm.setProviderCode(providerContract.getProviderCode());
		//		providerContractForm.setProviderContractDetail(providerContractDetail);
		providerContractForm.setProviderContractId(providerContract.getProviderContractId());
		//		providerContractForm.setProviderName(providerContract.getpro);
		String serviceCoverage = providerContract.getServiceCoverage();
		if (serviceCoverage != null) {
			String scs[] = serviceCoverage.split("/");
			for (int i = 0; i < scs.length; i++) {
				if (OPD.equalsIgnoreCase(scs[i])) {
					providerContractForm.setServiceCoverageOPD(OPD);
				} else if (IPD.equalsIgnoreCase(scs[i])) {
					providerContractForm.setServiceCoverageIPD(IPD);
				}
			}
		}
		providerContractForm.setProviderContractDetail(new ArrayList<ProviderContractDetailForm>());
		for (int i = 0; i < providerContractDetails.size(); i++) {
			ProviderContractDetail providerContractDetail = providerContractDetails.get(i);
			ProviderContractDetailForm providerContractDetailForm = new ProviderContractDetailForm();
			providerContractDetailForm.setProviderContractDetailId(providerContractDetail.getProviderContractDetailId());
			providerContractDetailForm.setAgreedFee(convertToString(providerContractDetail.getAgreedFee()));
			providerContractDetailForm.setDiscountInd(("Y").equals(providerContractDetail.getDiscountInd()) ? true : false);
			providerContractDetailForm.setDiscountOnListPrice(convertToString(providerContractDetail.getDiscountOnListPrice()));
			Lookup icd10CodeLookup = new Lookup();
			if (providerContractDetail.getIcd10Code() != null) {
				ICD10Code icd10Code = commonDataService.findICD10CodeByICD10CodeAndICDSubCode(providerContractDetail.getIcd10Code());
				icd10CodeLookup.setKey(providerContractDetail.getIcd10Code());
				icd10CodeLookup.setValue(icd10Code.getIcd10Code() + "." + icd10Code.getIcdSubCode() + " - " + icd10Code.getSubCodeDesc());
			} else {
				icd10CodeLookup.setKey(null);
				icd10CodeLookup.setValue("");
			}
			providerContractDetailForm.setIcd10Code(icd10CodeLookup);

			Lookup icd9CodeLookup = new Lookup();
			if (providerContractDetail.getIcd9Code() != null) {
				ICD9Code icd9Code = commonDataService.findICD9CodeByICD9CodeAndICDSubCode(providerContractDetail.getIcd9Code());
				icd9CodeLookup.setKey(providerContractDetail.getIcd9Code());
				icd9CodeLookup.setValue(icd9Code.getIcd9Code() + "." + icd9Code.getIcdSubCode() + " - " + icd9Code.getSubCodeDesc());
			} else {
				icd9CodeLookup.setKey(null);
				icd9CodeLookup.setValue("");
			}
			providerContractDetailForm.setIcd9Code(icd9CodeLookup);

			//			providerContractDetailForm.setIcd9Code("");
			providerContractDetailForm.setListPrice(convertToString(providerContractDetail.getListPrice()));
			providerContractDetailForm.setNotPaidInd(("Y").equals(providerContractDetail.getNotPaidInd()) ? true : false);
			providerContractDetailForm.setPackageName(providerContractDetail.getPackageName());
			//			providerContractDetailForm.setPaymentTerm(providerContractDetail.getpa);

			ServiceItem serviceItem = commonDataService.getServiceItem(providerContractDetail.getServiceCatId());
			if (serviceItem != null) {
				Lookup serviceCatId = new Lookup();
				serviceCatId.setKey(serviceItem.getServiceCatId());
				serviceCatId.setValue(serviceItem.getServiceCatId() + " - " + serviceItem.getServiceItemDesc());
				providerContractDetailForm.setServiceCatId(serviceCatId);
			}

			providerContractDetailForm.setTierPricing(convertToString(providerContractDetail.getTierPricing()));
			providerContractDetailForm.setType(providerContractDetail.getContractType());
			providerContractDetailForm.setVolumeDiscount(convertToString(providerContractDetail.getVolumeDiscount()));
			providerContractDetailForm.setCapitatedService(providerContractDetail.getCapitatedService());
			providerContractDetailForm.setNetworkId(convertToString(providerContractDetail.getNetworkId()));
			providerContractForm.getProviderContractDetail().add(providerContractDetailForm);

			if (CAPITATEDSERVICE.equals(providerContractDetail.getContractType()) && CAPITATEDSERVICE.equals(providerContractDetail.getServiceCatId())) {
				providerContractForm.setCapitatedService(providerContractDetail.getCapitatedService());
			}

		}
		return providerContractForm;
	}

	public static ProviderContractBO convertModelToProviderContractBO(ProviderContractForm providerContractForm) {
		ProviderContract providerContract = new ProviderContract();
		providerContract.setProviderContractId(providerContractForm.getProviderContractId());
		providerContract.setProviderCode(providerContractForm.getProviderCode());
		providerContract.setContractId(convertStringToInteger(providerContractForm.getContractCode()));
		providerContract.setContractStatus(providerContractForm.getContractStatus());
		providerContract.setContractProcessStatus(providerContractForm.getContractProcessStatus());

		String serviceCoverages = null;
		if (IPD.equalsIgnoreCase(providerContractForm.getServiceCoverageIPD())) {
			serviceCoverages = IPD;
		}

		if (OPD.equalsIgnoreCase(providerContractForm.getServiceCoverageOPD())) {
			if (serviceCoverages != null) {
				serviceCoverages += "/" + OPD;
			} else {
				serviceCoverages = OPD;
			}
		}

		providerContract.setServiceCoverage(serviceCoverages);
		providerContract.setEffectiveFromDt(providerContractForm.getEffectiveDate());
		providerContract.setEffectiveToDt(providerContractForm.getExpiryDate());
		providerContract.setNetworkName(providerContractForm.getNetworkName());
		providerContract.setPaymentTerm(providerContractForm.getPaymentTerm());
		//		providerContract.setVolumeDiscount(volumeDiscount);

		//		providerContract.setPreparedBy(preparedBy);
		//		providerContract.setApprovedBy(approvedBy);
		//		providerContract.setCreatedBy(createdBy);
		//		providerContract.setCreatedDt(createdDt);
		//		providerContract.setLastModifiedBy(lastModifiedBy);
		//		providerContract.setLastModifiedDt(lastModifiedDt);

		List<ProviderContractDetailForm> providerContractDetailForms = providerContractForm.getProviderContractDetail();
		List<ProviderContractDetail> providerContractDetails = new ArrayList<ProviderContractDetail>();
		for (int i = 0; i < providerContractDetailForms.size(); i++) {
			ProviderContractDetailForm providerContractDetailForm = providerContractDetailForms.get(i);
			ProviderContractDetail providerContractDetail = new ProviderContractDetail();
			providerContractDetail.setProviderContractDetailId(providerContractDetailForm.getProviderContractDetailId());
			providerContractDetail.setAgreedFee(convertStringToBigDecimal(providerContractDetailForm.getAgreedFee()));
			providerContractDetail.setDiscountInd(providerContractDetailForm.isDiscountInd() ? "Y" : "N");
			providerContractDetail.setDiscountOnListPrice(convertStringToBigDecimal(providerContractDetailForm.getDiscountOnListPrice()));
			providerContractDetail.setIcd10Code(providerContractDetailForm.getIcd10Code().getKey());
			providerContractDetail.setIcd9Code(providerContractDetailForm.getIcd9Code().getKey());
			providerContractDetail.setListPrice(convertStringToBigDecimal(providerContractDetailForm.getListPrice()));
			providerContractDetail.setNotPaidInd(providerContractDetailForm.isNotPaidInd() ? "Y" : "N");
			providerContractDetail.setPackageName(providerContractDetailForm.getPackageName());
			providerContractDetail.setServiceCatId(providerContractDetailForm.getServiceCatId().getKey());
			providerContractDetail.setNetworkId(providerContractDetailForm.getNetworkId() == null ? null : FormatUtil.convertStringToLong(providerContractDetailForm.getNetworkId()));
			//			providerContractDetail.setServiceName(providerContractDetailForm.gets);
			providerContractDetail.setTierPricing(convertStringToBigDecimal(providerContractDetailForm.getTierPricing()));
			providerContractDetail.setContractType(providerContractDetailForm.getType());
			providerContractDetail.setVolumeDiscount(convertStringToBigDecimal(providerContractDetailForm.getVolumeDiscount()));
			providerContractDetail.setCapitatedService(providerContractDetailForm.getCapitatedService());
			providerContractDetails.add(providerContractDetail);
		}

		ProviderContractBO providerContractBO = new ProviderContractBO();
		providerContractBO.setProviderContract(providerContract);
		providerContractBO.setProviderContractDetails(providerContractDetails);
		providerContractBO.setRemoveproviderContractDetailId(providerContractForm.getRemoveProviderContractDetailId());

		return providerContractBO;
	}

	public List<ProviderContractDetailForm> getProviderContractDetailFormByType(String type) {
		List<ProviderContractDetailForm> result = new ArrayList<ProviderContractDetailForm>();
		for (int i = 0; i < providerContractDetail.size(); i++) {
			ProviderContractDetailForm form = providerContractDetail.get(i);
			if (type.equals(form.getType())) {
				result.add(form);
			}
		}
		return result;
	}

	public static String convertToString(Object val) {
		if (val == null)
			return "";
		return val.toString();
	}

	public static Integer convertStringToInteger(String val) {
		Integer result = null;
		try {
			result = Integer.parseInt(val);
		} catch (Exception e) {
			result = null;
		}
		return result;
	}

	public static BigDecimal convertStringToBigDecimal(String val) {
		BigDecimal result = new BigDecimal(0);
		try {
			result = new BigDecimal(val);
		} catch (Exception e) {
			result = null;
		}
		return result;
	}

	public String getServiceCoverageOPD() {
		return serviceCoverageOPD;
	}

	public void setServiceCoverageOPD(String serviceCoverageOPD) {
		this.serviceCoverageOPD = serviceCoverageOPD;
	}

	public String getServiceCoverageIPD() {
		return serviceCoverageIPD;
	}

	public void setServiceCoverageIPD(String serviceCoverageIPD) {
		this.serviceCoverageIPD = serviceCoverageIPD;
	}

	public String getCapitatedService() {
		return capitatedService;
	}

	public void setCapitatedService(String capitatedService) {
		this.capitatedService = capitatedService;
	}

	public String getContractProcessStatus() {
		return contractProcessStatus;
	}

	public void setContractProcessStatus(String contractProcessStatus) {
		this.contractProcessStatus = contractProcessStatus;
	}

	public String getContractStatusDesc() {
		return contractStatusDesc;
	}

	public void setContractStatusDesc(String contractStatusDesc) {
		this.contractStatusDesc = contractStatusDesc;
	}

}
