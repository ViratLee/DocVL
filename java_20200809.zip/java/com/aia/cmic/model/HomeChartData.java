package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

public class HomeChartData {
	private String youFormatedData;
	private String teamFormatedData;
	private List<ChartData> youChartData = new ArrayList<>();
	private List<ChartData> teamChartData = new ArrayList<>();
	
	
	public String getYouFormatedData() {
		return youFormatedData;
	}
	public void setYouFormatedData(String youFormatedData) {
		this.youFormatedData = youFormatedData;
	}
	public String getTeamFormatedData() {
		return teamFormatedData;
	}
	public void setTeamFormatedData(String teamFormatedData) {
		this.teamFormatedData = teamFormatedData;
	}
	public List<ChartData> getYouChartData() {
		return youChartData;
	}
	public void setYouChartData(List<ChartData> youChartData) {
		this.youChartData = youChartData;
	}
	public List<ChartData> getTeamChartData() {
		return teamChartData;
	}
	public void setTeamChartData(List<ChartData> teamChartData) {
		this.teamChartData = teamChartData;
	}
}
