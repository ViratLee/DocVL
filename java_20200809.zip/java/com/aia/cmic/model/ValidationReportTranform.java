package com.aia.cmic.model;


public class ValidationReportTranform {
	private String rowNum;
	private String claimNo;
	private String occurrenceNo;
	private String policyNo;
	private String planName;
	private String validationNumber;
	private String validationDesc;
	private String amount;
	private String approval;
	private String review;
	private String actionTaken;
	private String reviewer;
	private String lastUpdate;
	private String settleDate;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getOccurrenceNo() {
		return occurrenceNo;
	}

	public void setOccurrenceNo(String occurrenceNo) {
		this.occurrenceNo = occurrenceNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getValidationNumber() {
		return validationNumber;
	}

	public void setValidationNumber(String validationNumber) {
		this.validationNumber = validationNumber;
	}

	public String getValidationDesc() {
		return validationDesc;
	}

	public void setValidationDesc(String validationDesc) {
		this.validationDesc = validationDesc;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getApproval() {
		return approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(String settleDate) {
		this.settleDate = settleDate;
	}

	public String getRowNum() {
		return rowNum;
	}

	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}

}
