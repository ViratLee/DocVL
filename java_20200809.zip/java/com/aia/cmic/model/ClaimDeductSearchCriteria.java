package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class ClaimDeductSearchCriteria {
	
	private String policyNo;
	private String policyYear;
	private String claimNo;
	private String deductNo;
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getPolicyYear() {
		return policyYear;
	}
	public void setPolicyYear(String policyYear) {
		this.policyYear = policyYear;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public String getDeductNo() {
		return deductNo;
	}
	public void setDeductNo(String deductNo) {
		this.deductNo = deductNo;
	}
	

}
