package com.aia.cmic.model;

public class EligibleClaimPayment {
	private String planName;
	private String productType;
	private String policyNo;
	private String businessLine;
	private String productCode;
	private String fullCreditInd;
	private Integer planId;
	private String planCoverageId;

	public EligibleClaimPayment(String planName, String productType, String policyNo, String businessLine, String productCode,
	        String fullCreditInd, Integer planId, String planCoverageId) {
		this.planName = planName;
		this.productType =productType;
		this.policyNo = policyNo ;
		this.businessLine = businessLine;
		this.productCode = productCode ;
		this.fullCreditInd = fullCreditInd;
		this.planId = planId;
		this.planCoverageId = planCoverageId;
	}

	/**
	 * @return the planName
	 */
	public String getPlanName() {
		return planName;
	}


	/**
	 * @return the poductType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @return the fullCreditInd
	 */
	public String getFullCreditInd() {
		return fullCreditInd;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public String getPlanCoverageId() {
		return planCoverageId;
	}

	/**
	 * @param planName the planName to set
	 */
	protected void setPlanName(String planName) {
		this.planName = planName;
	}

	/**
	 * @param productType the productType to set
	 */
	protected void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	protected void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	protected void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 * @param productCode the productCode to set
	 */
	protected void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @param fullCreditInd the fullCreditInd to set
	 */
	protected void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	/**
	 * @param planCoverageId the planCoverageId to set
	 */
	protected void setPlanCoverageId(String planCoverageId) {
		this.planCoverageId = planCoverageId;
	}

}
