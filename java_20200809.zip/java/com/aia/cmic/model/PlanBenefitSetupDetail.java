package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

public class PlanBenefitSetupDetail {
	private String uid;
	private Long planId;
	private Boolean duplicateFlag;
	PlanBO planBO;
	List<PlanBenefitBO> planBenefitBOList = new ArrayList<PlanBenefitBO>();
	PlanBenefitOtherBenefitRuleBO planBenefitOtherBenefitRuleBO;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public Boolean getDuplicateFlag() {
		return duplicateFlag;
	}

	public void setDuplicateFlag(Boolean duplicateFlag) {
		this.duplicateFlag = duplicateFlag;
	}

	public PlanBO getPlanBO() {
		return planBO;
	}

	public void setPlanBO(PlanBO planBO) {
		this.planBO = planBO;
	}

	public List<PlanBenefitBO> getPlanBenefitBOList() {
		return planBenefitBOList;
	}

	public void setPlanBenefitBOList(List<PlanBenefitBO> planBenefitBOList) {
		this.planBenefitBOList = planBenefitBOList;
	}

	public PlanBenefitOtherBenefitRuleBO getPlanBenefitOtherBenefitRuleBO() {
		return planBenefitOtherBenefitRuleBO;
	}

	public void setPlanBenefitOtherBenefitRuleBO(PlanBenefitOtherBenefitRuleBO planBenefitOtherBenefitRuleBO) {
		this.planBenefitOtherBenefitRuleBO = planBenefitOtherBenefitRuleBO;
	}

}
