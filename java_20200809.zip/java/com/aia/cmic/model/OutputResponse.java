package com.aia.cmic.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "OutputResponse")
public class OutputResponse {
	String successIndicator;
	String errorMessage;

	/**
	 * @return the successIndicator
	 */
	public String getSuccessIndicator() {
		return successIndicator;
	}

	/**
	 * @param successIndicator the successIndicator to set
	 */
	public void setSuccessIndicator(String successIndicator) {
		this.successIndicator = successIndicator;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String toString() {
		return "successIndicator: " + successIndicator + ",errorMessage: " + errorMessage;
	}

}
