package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class DocumentRecordDetailModel {
	private Long claimId;
	private String batchNo;
	private String providerCode;
	private String providerName;
	private String businessLine;
	private String stpInd;
	private String ediInd;
	private Date settlementDt;
	private Date paymentDt;
	private Date transferDt;
	private BigDecimal amount;
	private Date receiveDocDt;
	private Date receiveDocModifiedDt;
	private String remark;
	private Date currentCycleDt;

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public Date getSettlementDt() {
		return settlementDt;
	}

	public void setSettlementDt(Date settlementDt) {
		this.settlementDt = settlementDt;
	}

	public Date getPaymentDt() {
		return paymentDt;
	}

	public void setPaymentDt(Date paymentDt) {
		this.paymentDt = paymentDt;
	}

	public Date getTransferDt() {
		return transferDt;
	}

	public void setTransferDt(Date transferDt) {
		this.transferDt = transferDt;
	}

	public Date getReceiveDocDt() {
		return receiveDocDt;
	}

	public void setReceiveDocDt(Date receiveDocDt) {
		this.receiveDocDt = receiveDocDt;
	}

	public Date getReceiveDocModifiedDt() {
		return receiveDocModifiedDt;
	}

	public void setReceiveDocModifiedDt(Date receiveDocModifiedDt) {
		this.receiveDocModifiedDt = receiveDocModifiedDt;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public Date getCurrentCycleDt() {
		return currentCycleDt;
	}

	public void setCurrentCycleDt(Date currentCycleDt) {
		this.currentCycleDt = currentCycleDt;
	}

}