package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitSettleFL {
	@XmlElement(name = "benefitSettlePolicyList")
	List<BenefitSettlePolicy> benefitSettlePolicyList;
	@XmlElement(name = "policyAmtSum")
	BigDecimal policyAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "policyReimbursedSum")
	BigDecimal policyReimbursedSum = BigDecimal.ZERO;
	@XmlElement(name = "presentedAmtSum")
	BigDecimal presentedAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "paNoClaimBonusAmt")
	BigDecimal paNoClaimBonusAmt = BigDecimal.ZERO;
	@XmlElement(name = "hsNoClaimBonusAmt")
	BigDecimal hsNoClaimBonusAmt = BigDecimal.ZERO;
	@XmlElement(name = "reimbursedPaidAmt")
	BigDecimal reimbursedPaidAmt = BigDecimal.ZERO;
	@XmlElement(name = "interestLastPayment")
	BigDecimal interestLastPayment = BigDecimal.ZERO;
	@XmlElement(name = "totalAmt")
	BigDecimal totalAmt = BigDecimal.ZERO;
	@XmlElement(name = "deductTotalAmt")
	BigDecimal deductTotalAmt = BigDecimal.ZERO;
	@XmlElement(name = "deductAmt")
	BigDecimal deductAmt = BigDecimal.ZERO;
	
	
	public BigDecimal getPolicyAmtSum() {
		return policyAmtSum;
	}

	public void setPolicyAmtSum(BigDecimal policyAmtSum) {
		this.policyAmtSum = policyAmtSum;
	}

	public BigDecimal getPolicyReimbursedSum() {
		return policyReimbursedSum;
	}

	public void setPolicyReimbursedSum(BigDecimal policyReimbursedSum) {
		this.policyReimbursedSum = policyReimbursedSum;
	}

	public BigDecimal getPresentedAmtSum() {
		return presentedAmtSum;
	}

	public void setPresentedAmtSum(BigDecimal presentedAmtSum) {
		this.presentedAmtSum = presentedAmtSum;
	}

	public BigDecimal getPaNoClaimBonusAmt() {
		return paNoClaimBonusAmt;
	}

	public void setPaNoClaimBonusAmt(BigDecimal paNoClaimBonusAmt) {
		this.paNoClaimBonusAmt = paNoClaimBonusAmt;
	}

	public BigDecimal getHsNoClaimBonusAmt() {
		return hsNoClaimBonusAmt;
	}

	public void setHsNoClaimBonusAmt(BigDecimal hsNoClaimBonusAmt) {
		this.hsNoClaimBonusAmt = hsNoClaimBonusAmt;
	}

	public BigDecimal getReimbursedPaidAmt() {
		return reimbursedPaidAmt;
	}

	public void setReimbursedPaidAmt(BigDecimal reimbursedPaidAmt) {
		this.reimbursedPaidAmt = reimbursedPaidAmt;
	}
	
	public BigDecimal getInterestLastPayment() {
		return interestLastPayment;
	}

	public BigDecimal getTotalAmt() {
		return totalAmt;
	}

	public void setInterestLastPayment(BigDecimal interestLastPayment) {
		this.interestLastPayment = interestLastPayment;
	}

	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}
	
	public BigDecimal getDeductTotalAmt() {
		return deductTotalAmt;
	}

	public void setDeductTotalAmt(BigDecimal deductTotalAmt) {
		this.deductTotalAmt = deductTotalAmt;
	}
	
	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	public BenefitSettleFL() {
		benefitSettlePolicyList = new ArrayList<BenefitSettlePolicy>();
	}

	public List<BenefitSettlePolicy> getBenefitSettlePolicyList() {
		return benefitSettlePolicyList;
	}

	public void setBenefitSettlePolicyList(List<BenefitSettlePolicy> benefitSettlePolicyList) {
		this.benefitSettlePolicyList = benefitSettlePolicyList;
		sumPolicyAmount();
	}

	private void sumPolicyAmount() {
		if ((this.benefitSettlePolicyList != null) && (this.benefitSettlePolicyList.size() > 0)) {
			this.policyAmtSum = BigDecimal.ZERO;
			this.policyReimbursedSum = BigDecimal.ZERO;
			this.presentedAmtSum = BigDecimal.ZERO;
			for (BenefitSettlePolicy policy : this.benefitSettlePolicyList) {
				BigDecimal amount = policy.getPlanAmtSum();
				this.policyAmtSum = this.policyAmtSum.add(amount);
				BigDecimal presentedAmtS = policy.getPresentedAmtSum();
				this.presentedAmtSum = this.presentedAmtSum.add(presentedAmtS);
			}
		}
	}
}
