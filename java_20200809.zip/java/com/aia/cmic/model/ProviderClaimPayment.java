package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aia.cmic.entity.ClaimPaymentTransfer;

public class ProviderClaimPayment {
	String providerCode;
	String providerNameThai;
	String treatmentType;
	Date settlementDate;
	BigDecimal presentedGrossAmt;
	Date paymentTransferDt;
	Date invoiceDate;
	String paymentTransferRemark;
	Boolean updatable;
	List<Long> lstClaimPaymentId = new ArrayList<>();
	String billno;
	Date claimstatusdt;
	String ediInd;
	String stpInd;
	
	public ProviderClaimPayment(ClaimPaymentTransfer entity) {
		providerCode = entity.getProviderCode();
		providerNameThai = entity.getProviderNameThai();
		treatmentType = entity.getTreatmentType();
		presentedGrossAmt = entity.getPresentedAmt() == null ? new BigDecimal(0) : entity.getPresentedAmt();
		paymentTransferDt = entity.getPaymentTransferDt();
		paymentTransferRemark = entity.getPaymentTransferRemark();
		updatable = paymentTransferDt == null;
		lstClaimPaymentId.add(entity.getClaimPaymentId());
		invoiceDate = entity.getInvoiceDate();
		settlementDate = entity.getSettlementDate();
		billno = entity.getInvoiceNum();
		claimstatusdt = entity.getClaimstatusdt();
		stpInd = entity.getStpInd();
		ediInd = entity.getEdiInd();
	}

	public ProviderClaimPayment() {

	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public BigDecimal getPresentedGrossAmt() {
		return presentedGrossAmt;
	}

	public void setPresentedGrossAmt(BigDecimal presentedGrossAmt) {
		this.presentedGrossAmt = presentedGrossAmt;
	}

	public Date getPaymentTransferDt() {
		return paymentTransferDt;
	}

	public void setPaymentTransferDt(Date paymentTransferDt) {
		this.paymentTransferDt = paymentTransferDt;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getPaymentTransferRemark() {
		return paymentTransferRemark;
	}

	public void setPaymentTransferRemark(String paymentTransferRemark) {
		this.paymentTransferRemark = paymentTransferRemark;
	}

	public Boolean getUpdatable() {
		return updatable;
	}

	public void setUpdatable(Boolean updatable) {
		this.updatable = updatable;
	}

	public List<Long> getLstClaimPaymentId() {
		return lstClaimPaymentId;
	}

	public void setLstClaimPaymentId(List<Long> lstClaimPaymentId) {
		this.lstClaimPaymentId = lstClaimPaymentId;
	}

	public String getBillno() {
		return billno;
	}

	public void setBillno(String billno) {
		this.billno = billno;
	}

	public Date getClaimstatusdt() {
		return claimstatusdt;
	}

	public void setClaimstatusdt(Date claimstatusdt) {
		this.claimstatusdt = claimstatusdt;
	}
	
	public String getEdiInd() {
		return ediInd;
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public void addChild(ProviderClaimPayment child) {
		presentedGrossAmt = presentedGrossAmt.add(child.presentedGrossAmt);
		lstClaimPaymentId.add(child.lstClaimPaymentId.get(0));
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof ProviderClaimPayment) {
			ProviderClaimPayment c = (ProviderClaimPayment) o;
			return compare(this.providerCode, c.providerCode) && compare(this.treatmentType, c.treatmentType) && compare(this.paymentTransferDt, c.paymentTransferDt)
					&& compare(this.paymentTransferRemark, c.paymentTransferRemark) && compare(this.ediInd, c.ediInd) && compare(this.stpInd, c.stpInd);
		} else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (providerCode == null ? 0 : providerCode.hashCode()) + (treatmentType == null ? 0 : treatmentType.hashCode());
	}

	private <T> boolean compare(T o, T c) {
		if (o != null && c != null) {
			return o.equals(c);
		} else {
			return o == null && c == null;
		}
	}
}
