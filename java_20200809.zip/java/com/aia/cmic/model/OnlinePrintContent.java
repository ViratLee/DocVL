package com.aia.cmic.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class OnlinePrintContent {
	@XmlElement(name = "FIELD")
	private List<OnlinePrintField> onlinePrintDatas;

	public List<OnlinePrintField> getOnlinePrintDatas() {
		return onlinePrintDatas;
	}

	public void setOnlinePrintDatas(List<OnlinePrintField> onlinePrintDatas) {
		this.onlinePrintDatas = onlinePrintDatas;
	}

}
