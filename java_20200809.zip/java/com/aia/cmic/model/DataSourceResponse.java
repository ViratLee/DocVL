package com.aia.cmic.model;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ASNPAGM
 * @version 1.0
 * @updated 21-Aug-2016 1:59:47 AM
 */
@XmlRootElement(name = "DataSourceResponse")
public class DataSourceResponse {

	private String code;
	private String message;
	private List<?> data;
	private long total;
	private Map<String, Object> aggregates;

	public DataSourceResponse() {

	}

	public DataSourceResponse(List<?> data, long size) {
		this.data = data;
		this.total = size;
	}

	public List<?> getData() {
		return data;
	}

	/**
	 * 
	 * @param data
	 */
	public void setData(List<?> data) {
		this.data = data;
	}

	public long getTotal() {
		return total;
	}

	/**
	 * 
	 * @param total
	 */
	public void setTotal(long total) {
		this.total = total;
	}

	public Map<String, Object> getAggregates() {
		return aggregates;
	}

	/**
	 * 
	 * @param aggregates
	 */
	public void setAggregates(Map<String, Object> aggregates) {
		this.aggregates = aggregates;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
