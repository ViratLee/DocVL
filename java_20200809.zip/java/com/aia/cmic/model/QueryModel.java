package com.aia.cmic.model;

public class QueryModel {

}
