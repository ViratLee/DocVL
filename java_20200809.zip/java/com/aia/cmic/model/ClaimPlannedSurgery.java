package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class ClaimPlannedSurgery {
    private Long claimSupplementId;
    private String codeType;
    private String strValue;
    private BigDecimal intValue;
    private Date dateValue;
    private String primaryInd;
    private String createdBy;
    private  String lastModifiedBy;
    private Date createdDt;
    private Date lastModifiedDt;

    public Long getClaimSupplementId() {
        return claimSupplementId;
    }

    public void setClaimSupplementId(Long claimSupplementId) {
        this.claimSupplementId = claimSupplementId;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    public BigDecimal getIntValue() {
        return intValue;
    }

    public void setIntValue(BigDecimal intValue) {
        this.intValue = intValue;
    }

    public Date getDateValue() {
        return dateValue;
    }

    public void setDateValue(Date dateValue) {
        this.dateValue = dateValue;
    }

    public String getPrimaryInd() {
        return primaryInd;
    }

    public void setPrimaryInd(String primaryInd) {
        this.primaryInd = primaryInd;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Date getLastModifiedDt() {
        return lastModifiedDt;
    }

    public void setLastModifiedDt(Date lastModifiedDt) {
        this.lastModifiedDt = lastModifiedDt;
    }
}
