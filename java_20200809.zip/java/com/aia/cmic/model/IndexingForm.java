package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.cmic.canonical.ClaimCanonical;
import com.aia.cmic.services.ProviderService;
import com.aia.cmic.services.helper.Case360Helper;
import com.aia.cmic.util.FormatUtil;

public class IndexingForm {
	@Autowired
	private ProviderService providerService;

	private static final Logger LOG = LoggerFactory.getLogger(IndexingForm.class);

	private String firstName;
	private String lastName;

	private String batchNo;
	private String claimType;
	private String dependentCode;
	private String channel;
	private Date dateReceived;
	private Date processingDt;
	private String policyNo;
	private String certNo;
	private String memberId;
	private String location;
	private String providerCode;
	private String phase;
	private String urgentCase;
	private String fyi;
	private String activity;
	private Long partyId;
	private String urgent;
	private String comment;
	private String nationalId;
	private String hccode;
	private String owner;
	private String clientId;
	private boolean unidentified;
	private String businessLine;
	private String ipdOpd;

	//private String certNo;
	//private String lastname;

	public IndexingForm() {

	}

	public IndexingForm(CMiCClaim cmicClaim) {
		if (cmicClaim != null) {
			this.batchNo = FormatUtil.convertNull(cmicClaim.getScanBatchId());
			this.activity = FormatUtil.convertNull(cmicClaim.getActivity());
			this.comment = FormatUtil.convertNull(cmicClaim.getComment());
			this.claimType = FormatUtil.convertNull(cmicClaim.getClaimCanonical().getClaim().getSubmissionType());
			this.dependentCode = FormatUtil.convertNull(cmicClaim.getClaimCanonical().getClaim().getDependentNo());
			this.dateReceived = cmicClaim.getClaimCanonical().getClaim().getReceivedDate();
			this.location = FormatUtil.convertNull(cmicClaim.getLocation());
			this.providerCode = FormatUtil.convertNull(cmicClaim.getClaimCanonical().getClaim().getProviderCode());
			this.fyi = FormatUtil.convertNull(cmicClaim.getFyi());
			this.partyId = cmicClaim.getClaimCanonical().getClaim().getPartyId();
			this.urgent = FormatUtil.convertNull(cmicClaim.getUrgent());
			this.owner = FormatUtil.convertNull(cmicClaim.getOwner());
			this.unidentified = cmicClaim.isUnidentified();
			ClaimCanonical claimCanonical = cmicClaim.getClaimCanonical();

			if (claimCanonical != null) {
				Claim claim = claimCanonical.getClaim();
				if (claim != null) {
					this.firstName = FormatUtil.convertNull(claim.getFirstName());
					this.lastName = FormatUtil.convertNull(claim.getLastName());
					this.channel = FormatUtil.convertNull(Case360Helper.mapChannelFromCMiC(claim.getChannel()));
					this.policyNo = FormatUtil.convertNull(claim.getPolicyNo());
					this.certNo = FormatUtil.convertNull(claim.getCertNo());
					this.memberId = FormatUtil.convertNull(claim.getMemberId());
					this.phase = FormatUtil.convertNull(claim.getPhase());
					if ("FAX".equals(FormatUtil.convertNull(channel))) {
						this.phase = "02";
					}
					this.nationalId = FormatUtil.convertNull(claim.getNationalId());
					this.clientId = FormatUtil.convertNull(claim.getClientId());
					this.businessLine = FormatUtil.convertNull(claim.getBusinessLine());
					this.ipdOpd = FormatUtil.convertNull(claim.getIpdOpd());
					//this.firstname = FormatUtil.convertNull(claim.getFirstName());
					//this.lastname = FormatUtil.convertNull(claim.getLastName());
				}
			}
		}
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getIpdOpd() {
		return ipdOpd;
	}

	public void setIpdOpd(String ipdOpd) {
		this.ipdOpd = ipdOpd;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public final String getClaimType() {
		return claimType;
	}

	public final void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public final String getDependentCode() {
		return dependentCode;
	}

	public final void setDependentCode(String dependentCode) {
		this.dependentCode = dependentCode;
	}

	public final String getChannel() {
		return channel;
	}

	public final void setChannel(String channel) {
		this.channel = channel;
	}

	public final Date getDateReceived() {
		return dateReceived;
	}

	public final void setDateReceived(Date dateReceived) {
		this.dateReceived = dateReceived;
	}

	public final Date getProcessingDt() {
		return processingDt;
	}

	public final void setProcessingDt(Date processingDt) {
		this.processingDt = processingDt;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getCertNo() {
		return certNo;
	}

	public final void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public final String getMemberId() {
		return memberId;
	}

	public final void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public final String getLocation() {
		return location;
	}

	public final void setLocation(String location) {
		this.location = location;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public final String getPhase() {
		return phase;
	}

	public final void setPhase(String phase) {
		this.phase = phase;
	}

	public final String getUrgentCase() {
		return urgentCase;
	}

	public final void setUrgentCase(String urgentCase) {
		this.urgentCase = urgentCase;
	}

	public final String getFyi() {
		return fyi;
	}

	public final void setFyi(String fyi) {
		this.fyi = fyi;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public String getUrgent() {
		return urgent;
	}

	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getHccode() {
		return hccode;
	}

	public void setHccode(String hccode) {
		this.hccode = hccode;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public boolean isUnidentified() {
		return unidentified;
	}

	public void setUnidentified(boolean unidentified) {
		this.unidentified = unidentified;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
