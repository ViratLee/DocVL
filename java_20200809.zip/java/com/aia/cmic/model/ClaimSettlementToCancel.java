package com.aia.cmic.model;

public class ClaimSettlementToCancel {

	
	/**
	 * @param claimNo
	 * @param companyId
	 * @param occurence
	 * @param policyNo
	 * @param businessLine
	 * @param productCode

	 */

	
	public ClaimSettlementToCancel(String claimNo, String companyId, Integer occurence, String policyNo, String businessLine, String productCode) {
		super();
		this.claimNo = claimNo;
		this.companyId = companyId;
		this.occurence = occurence;
		this.policyNo = policyNo;
		this.businessLine = businessLine;
		this.productCode = productCode;

	}
	private String claimNo;
	private String companyId;
	private Integer occurence;
	private String policyNo;
	private String businessLine;
	private String productCode;

	
	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}
	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}
	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	/**
	 * @return the occurence
	 */
	public Integer getOccurence() {
		return occurence;
	}
	/**
	 * @param occurence the occurence to set
	 */
	public void setOccurence(Integer occurence) {
		this.occurence = occurence;
	}
	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}
	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}
	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

}
