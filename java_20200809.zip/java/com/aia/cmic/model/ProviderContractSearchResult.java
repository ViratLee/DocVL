package com.aia.cmic.model;

public class ProviderContractSearchResult {
	private String providerContractId;
	private String providerCode;
	private String providerName;
	private String providerNameThai;
	private String providerType;
	private String province;
	private String region;
	private String networkName;
	private String providerStatus;
	private String effectiveFromDt;
	private String effectiveToDt;
	private String contractStatus;

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getProviderStatus() {
		return providerStatus;
	}

	public void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	public String getEffectiveFromDt() {
		return effectiveFromDt;
	}

	public void setEffectiveFromDt(String effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	public String getEffectiveToDt() {
		return effectiveToDt;
	}

	public void setEffectiveToDt(String effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public String getProviderContractId() {
		return providerContractId;
	}

	public void setProviderContractId(String providerContractId) {
		this.providerContractId = providerContractId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

}
