package com.aia.cmic.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgencyPaymentForm {
	private static final Logger LOG = LoggerFactory.getLogger(AgencyPaymentForm.class);
	private String agencyCode;
	private String paymentCode;
	private String distributeCode;

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getPaymentCode() {
		return paymentCode;
	}

	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}

	public String getDistributeCode() {
		return distributeCode;
	}

	public void setDistributeCode(String distributeCode) {
		this.distributeCode = distributeCode;
	}

}
