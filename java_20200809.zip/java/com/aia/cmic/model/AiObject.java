package com.aia.cmic.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

public class AiObject {
	
	AiClaim 				 		CLAIM;
	List<AiClaimPayment> 	 		CLAIMPAYMENTLIST;
	List<AiClaimPolicy>  	 		CLAIMPOLICYLIST;
	List<AiClaimSupplement>  		CLAIMSUPPLEMENTLIST;
	List<AiIcd10Code>  		 		ICD10CODELIST;
	List<AiPlan>  			 		PLANLIST;
	List<AiProvider>  		 		PROVIDERLIST;
	List<AiProviderContact>  		PROVIDERCONTACTLIST;
	
	// New Object
	List<AiProviderDetail>     		PROVIDERDETAILLIST;
	List<AiClaimPaymentDetail>		CLAIMPAYMENTDETAILLIST;
	List<AiInsured>					INSUREDLIST;
	List<AiClaimHistory>           	CLAIMHISTORYLIST;
	List<AiClaimPaymentHistory>    	CLAIMPAYMENTHISTORYLIST;
	List<AiClaimSupplementHistory>	CLAIMSUPPLEMENTHISTORYLIST;
	List<AiClaimCommentHistory>		CLAIMCOMMENTHISTORYLIST;
	List<AiClaimPolicyCoverage> 	CLAIMPOLICYCOVERAGELIST;

	// Remove Field
	//List<AiIcd10Code>  				ICD10HISTORYLIST;
	
	
	
	public AiClaim getCLAIM() {
		return CLAIM;
	}
	public void setCLAIM(AiClaim cLAIM) {
		CLAIM = cLAIM;
	}
	public List<AiClaimPayment> getCLAIMPAYMENTLIST() {
		return CLAIMPAYMENTLIST;
	}
	public void setCLAIMPAYMENTLIST(List<AiClaimPayment> cLAIMPAYMENTLIST) {
		CLAIMPAYMENTLIST = cLAIMPAYMENTLIST;
	}
	public List<AiClaimPolicy> getCLAIMPOLICYLIST() {
		return CLAIMPOLICYLIST;
	}
	public void setCLAIMPOLICYLIST(List<AiClaimPolicy> cLAIMPOLICYLIST) {
		CLAIMPOLICYLIST = cLAIMPOLICYLIST;
	}
	public List<AiClaimSupplement> getCLAIMSUPPLEMENTLIST() {
		return CLAIMSUPPLEMENTLIST;
	}
	public void setCLAIMSUPPLEMENTLIST(List<AiClaimSupplement> cLAIMSUPPLEMENTLIST) {
		CLAIMSUPPLEMENTLIST = cLAIMSUPPLEMENTLIST;
	}
	public List<AiIcd10Code> getICD10CODELIST() {
		return ICD10CODELIST;
	}
	public void setICD10CODELIST(List<AiIcd10Code> iCD10CODELIST) {
		ICD10CODELIST = iCD10CODELIST;
	}
	public List<AiPlan> getPLANLIST() {
		return PLANLIST;
	}
	public void setPLANLIST(List<AiPlan> pLANLIST) {
		PLANLIST = pLANLIST;
	}
	public List<AiProvider> getPROVIDERLIST() {
		return PROVIDERLIST;
	}
	public void setPROVIDERLIST(List<AiProvider> pROVIDERLIST) {
		PROVIDERLIST = pROVIDERLIST;
	}
	public List<AiProviderContact> getPROVIDERCONTACTLIST() {
		return PROVIDERCONTACTLIST;
	}
	public void setPROVIDERCONTACTLIST(List<AiProviderContact> pROVIDERCONTACTLIST) {
		PROVIDERCONTACTLIST = pROVIDERCONTACTLIST;
	}
	
	public List<AiProviderDetail> getPROVIDERDETAILLIST() {
		return PROVIDERDETAILLIST;
	}
	public void setPROVIDERDETAILLIST(List<AiProviderDetail> pROVIDERDETAILLIST) {
		PROVIDERDETAILLIST = pROVIDERDETAILLIST;
	}
	public List<AiClaimPaymentDetail> getCLAIMPAYMENTDETAILLIST() {
		return CLAIMPAYMENTDETAILLIST;
	}
	public void setCLAIMPAYMENTDETAILLIST(List<AiClaimPaymentDetail> cLAIMPAYMENTDETAILLIST) {
		CLAIMPAYMENTDETAILLIST = cLAIMPAYMENTDETAILLIST;
	}
	public List<AiInsured> getINSUREDLIST() {
		return INSUREDLIST;
	}
	public void setINSUREDLIST(List<AiInsured> iNSUREDLIST) {
		INSUREDLIST = iNSUREDLIST;
	}
	
	public List<AiClaimHistory> getCLAIMHISTORYLIST() {
		return CLAIMHISTORYLIST;
	}
	public void setCLAIMHISTORYLIST(List<AiClaimHistory> cLAIMHISTORYLIST) {
		CLAIMHISTORYLIST = cLAIMHISTORYLIST;
	}
	public List<AiClaimPaymentHistory> getCLAIMPAYMENTHISTORYLIST() {
		return CLAIMPAYMENTHISTORYLIST;
	}
	public void setCLAIMPAYMENTHISTORYLIST(List<AiClaimPaymentHistory> cLAIMPAYMENTHISTORYLIST) {
		CLAIMPAYMENTHISTORYLIST = cLAIMPAYMENTHISTORYLIST;
	}
	public List<AiClaimSupplementHistory> getCLAIMSUPPLEMENTHISTORYLIST() {
		return CLAIMSUPPLEMENTHISTORYLIST;
	}
	public void setCLAIMSUPPLEMENTHISTORYLIST(List<AiClaimSupplementHistory> cLAIMSUPPLEMENTHISTORYLIST) {
		CLAIMSUPPLEMENTHISTORYLIST = cLAIMSUPPLEMENTHISTORYLIST;
	}
	public List<AiClaimCommentHistory> getCLAIMCOMMENTHISTORYLIST() {
		return CLAIMCOMMENTHISTORYLIST;
	}
	public void setCLAIMCOMMENTHISTORYLIST(List<AiClaimCommentHistory> cLAIMCOMMENTHISTORYLIST) {
		CLAIMCOMMENTHISTORYLIST = cLAIMCOMMENTHISTORYLIST;
	}
	public List<AiClaimPolicyCoverage> getCLAIMPOLICYCOVERAGELIST() {
		return CLAIMPOLICYCOVERAGELIST;
	}
	public void setCLAIMPOLICYCOVERAGELIST(List<AiClaimPolicyCoverage> cLAIMPOLICYCOVERAGELIST) {
		CLAIMPOLICYCOVERAGELIST = cLAIMPOLICYCOVERAGELIST;
	}
	
	/*public List<AiIcd10Code> getICD10HISTORYLIST() {
		return ICD10HISTORYLIST;
	}
	public void setICD10HISTORYLIST(List<AiIcd10Code> iCD10HISTORYLIST) {
		ICD10HISTORYLIST = iCD10HISTORYLIST;
	}*/
}
