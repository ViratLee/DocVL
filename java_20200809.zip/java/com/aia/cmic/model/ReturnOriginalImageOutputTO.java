package com.aia.cmic.model;

public class ReturnOriginalImageOutputTO {
	private String code;
	private String message;
	private ReturnOriginalImageTO data;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ReturnOriginalImageTO getData() {
		return data;
	}

	public void setData(ReturnOriginalImageTO data) {
		this.data = data;
	}

	
}
