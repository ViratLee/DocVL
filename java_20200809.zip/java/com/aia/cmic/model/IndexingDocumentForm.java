package com.aia.cmic.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.aia.cmic.restservices.model.Document;
import com.aia.cmic.util.FormatUtil;

public class IndexingDocumentForm implements Serializable {
	private BigDecimal docId;
	private String businessType;
	private String category;
	private String channel;
	private String docName;
	private Lookup docType;
	private String policyNo;
	private String submissionPoint;
	private int totalPages;
	private boolean voidFlag;
	private byte[] base64Data;
	private String url;

	public IndexingDocumentForm(Document doc) {
		Lookup lookup = new Lookup();
		lookup.setKey(doc.getDocTypeCode());
		lookup.setValue(doc.getDocType());
		this.docId = doc.getDocId();
		this.businessType = doc.getBusinessType();
		this.category = doc.getCategory();
		this.channel = doc.getChannel();
		this.docName = doc.getDocName();
		this.docType = lookup;
		this.policyNo = doc.getPolicyNo();
		this.submissionPoint = doc.getSubmissionPoint();
		this.totalPages = doc.getTotalPages();
		this.voidFlag = doc.isVoidFlag();
		this.base64Data = doc.getBase64Data();
		this.url = doc.getUrl();
	}

	public IndexingDocumentForm(Lookup lookup) {
		this.docType = lookup;
	}

	public byte[] getBase64Data() {
		return base64Data;
	}

	public void setBase64Data(byte[] base64Data) {
		this.base64Data = base64Data;
	}

	public BigDecimal getDocId() {
		return docId;
	}

	public void setDocId(BigDecimal docId) {
		this.docId = docId;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getCategory() {
		return FormatUtil.convertNull(category);
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getChannel() {
		return FormatUtil.convertNull(channel);
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getDocName() {
		return FormatUtil.convertNull(docName);
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public Lookup getDocType() {
		return docType;
	}

	public void setDocType(Lookup docType) {
		this.docType = docType;
	}

	public String getPolicyNo() {
		return FormatUtil.convertNull(policyNo);
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getSubmissionPoint() {
		return FormatUtil.convertNull(submissionPoint);
	}

	public void setSubmissionPoint(String submissionPoint) {
		this.submissionPoint = submissionPoint;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public boolean isVoidFlag() {
		return voidFlag;
	}

	public void setVoidFlag(boolean voidFlag) {
		this.voidFlag = voidFlag;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
