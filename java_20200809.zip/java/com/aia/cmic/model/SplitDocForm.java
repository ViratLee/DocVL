package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SplitDocForm {

	private static final Logger LOG = LoggerFactory.getLogger(SplitDocForm.class);

	private List<String> docId;
	private List<String> docType;
	private List<String> page;

	public final List<String> getDocId() {
		return docId;
	}

	public final void setDocId(List<String> docId) {
		this.docId = docId;
	}

	public final List<String> getDocType() {
		return docType;
	}

	public final void setDocType(List<String> docType) {
		this.docType = docType;
	}

	public final List<String> getPage() {
		return page;
	}

	public final void setPage(List<String> page) {
		this.page = page;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
