package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 	CompanyId			Company Id							ClaimPayment.CompanyId
	ClaimPaymenId		ClaimPaymentId						ClaimPayment.ClaimPaymentId
	ClaimNo				Claim number						ClaimPayment.ClaimNo
	Occurrence			Claim occurrence					ClaimPayment.Occurrence
	BusinessLine		Business line (e.g. OL,CS,PA etc.)	ClaimPolicy.BusinessLine
	ProductCode			Product Code (e.g. HSN7)			ClaimPayment.ProductCode
	PolicyNo			Policy number						ClaimPayment.PolicyNo
	PlanId				Reference plan object				ClaimPayment.PlanId	
	CycleDate			Cydle date							current.CycleDate
	PayeeTitle			PayeeTitle							Payee.PayeeTitle
	PayeeLastName		PayeeLastName						Payee.LastName
	PayeeFirstName		PayeeFirstName						Payee.FirstName
	InsuredTitle		InsuredTitle						Insured.Title
	InsuredLastName		InsuredLastName						Insured.LastName
	InsuredFirstName	InsuredFirstName					Insured.FirstName
	PolicyIssueDate		Policy issue date					ClamPolicy.IssueDate
	payeeType			PayeeType							Payee.PayeeType
	bankCode			Bank Code							Payee.BankCode
	bankAccountNo		Bank Account No						Payee.BankAccountNo		
	
*/	
public class ClaimPaymentChannel {

	private String companyId ;			
	private Long claimPaymenId;		
	private String claimNo;				
	private Integer occurrence;			
	private String businessLine;		
	private String productCode;			
	private String policyNo;			
	private Long planId;					
	private String cycleDate;			
	private String payeeTitle;			
	private String payeeLastName;		
	private String payeeFirstName;		
	private String insuredTitle	;	
	private String insuredLastName ;	
	private String insuredFirstName;
	private Date policyIssueDate;
	private String paymentKey ;
	private String paymentChannel ;
	private Boolean thisPolicyHasOtherProduct=false;
	private String productType;
	private String payeeType;
	private List<ClaimPaymentChannel> sameProductTypeList = new ArrayList<ClaimPaymentChannel>();
	private String bankCode;
	private String bankAccountNo;
	
	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}
	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	/**
	 * @return the claimPaymenId
	 */
	public Long getClaimPaymenId() {
		return claimPaymenId;
	}
	/**
	 * @param claimPaymenId the claimPaymenId to set
	 */
	public void setClaimPaymenId(Long claimPaymenId) {
		this.claimPaymenId = claimPaymenId;
	}
	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}
	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}
	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}
	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}
	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}
	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}
	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}
	/**
	 * @return the cycleDate
	 */
	public String getCycleDate() {
		return cycleDate;
	}
	/**
	 * @param cycleDate the cycleDate to set
	 */
	public void setCycleDate(String cycleDate) {
		this.cycleDate = cycleDate;
	}
	/**
	 * @return the payeeTitle
	 */
	public String getPayeeTitle() {
		return payeeTitle;
	}
	/**
	 * @param payeeTitle the payeeTitle to set
	 */
	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}
	/**
	 * @return the payeeLastName
	 */
	public String getPayeeLastName() {
		return payeeLastName;
	}
	/**
	 * @param payeeLastName the payeeLastName to set
	 */
	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}
	/**
	 * @return the payeeFirstName
	 */
	public String getPayeeFirstName() {
		return payeeFirstName;
	}
	/**
	 * @param payeeFirstName the payeeFirstName to set
	 */
	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}
	/**
	 * @return the insuredTitle
	 */
	public String getInsuredTitle() {
		return insuredTitle;
	}
	/**
	 * @param insuredTitle the insuredTitle to set
	 */
	public void setInsuredTitle(String insuredTitle) {
		this.insuredTitle = insuredTitle;
	}
	/**
	 * @return the insuredLastName
	 */
	public String getInsuredLastName() {
		return insuredLastName;
	}
	/**
	 * @param insuredLastName the insuredLastName to set
	 */
	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}
	/**
	 * @return the insuredFirstName
	 */
	public String getInsuredFirstName() {
		return insuredFirstName;
	}
	/**
	 * @param insuredFirstName the insuredFirstName to set
	 */
	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}
	/**
	 * @return the policyIssueDate
	 */
	public Date getPolicyIssueDate() {
		return policyIssueDate;
	}
	/**
	 * @param policyIssueDate the policyIssueDate to set
	 */
	public void setPolicyIssueDate(Date policyIssueDate) {
		this.policyIssueDate = policyIssueDate;
	}
	/**
	 * @return the paymentKey
	 */
	public String getPaymentKey() {
		return paymentKey;
	}
	/**
	 * @param paymentKey the paymentKey to set
	 */
	public void setPaymentKey(String paymentKey) {
		this.paymentKey = paymentKey;
	}
	/**
	 * @return the paymentChannel
	 */
	public String getPaymentChannel() {
		return paymentChannel;
	}
	/**
	 * @param paymentChannel the paymentChannel to set
	 */
	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}
	public Boolean getThisPolicyHasOtherProduct() {
		return thisPolicyHasOtherProduct;
	}
	public void setThisPolicyHasOtherProduct(Boolean thisPolicyHasOtherProduct) {
		this.thisPolicyHasOtherProduct = thisPolicyHasOtherProduct;
	}
	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}
	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}
	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}
	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}
	/**
	 * @return the sameProductTypeList
	 */
	public List<ClaimPaymentChannel> getSameProductTypeList() {
		return sameProductTypeList;
	}
	/**
	 * @param sameProductTypeList the sameProductTypeList to set
	 */
	public void setSameProductTypeList(List<ClaimPaymentChannel> sameProductTypeList) {
		this.sameProductTypeList = sameProductTypeList;
	}
	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}
	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	/**
	 * @return the bankAccountNo
	 */
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	/**
	 * @param bankAccountNo the bankAccountNo to set
	 */
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	 

}
