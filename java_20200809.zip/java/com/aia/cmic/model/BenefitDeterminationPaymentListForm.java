package com.aia.cmic.model;

public class BenefitDeterminationPaymentListForm {
	private Long claimPaymentId;
	private String productType;
	private String businessLine;
	private String planShortName;
	private String productShortName;
	private String policyNo;
	private String exclusion;
	private String impairmentCode;
	private String eligibility;
	private String claimsDecision;
	private String declineReason;
	private String sumAssure;
	private String payee;
	private String systemQuotation;
	private String coInsurance;
	private String adjusted;
	private String adjustReason;
	private String suppressCheque;
	private String total;
	private Long planId;
	private String planName;
	private String rider;
	private Boolean isCalculated;
	private String payNonCoverItemInd;
	private String dataPrivacyConsent;
	private String dataPrivacyConsentDate;
	private String aiDecision;

	public BenefitDeterminationPaymentListForm() {
		resetAll();
	}

	public void resetAll() {
		productType = "";
		businessLine = "";
		planShortName = "";
		productShortName = "";
		planName = "";
		policyNo = "";
		exclusion = "FALSE";
		impairmentCode = "FALSE";
		eligibility = "";
		claimsDecision = "N/A";
		declineReason = "N/A";
		sumAssure = "0";
		payee = "N/A";
		systemQuotation = "0";
		coInsurance = "0";
		adjusted = "0";
		adjustReason = "N/A";
		suppressCheque = "NO";
		total = "0";
		planId = 0L;
		rider = "FALSE";
		payNonCoverItemInd = "";
		dataPrivacyConsent = "";
		dataPrivacyConsentDate = "";
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getPlanShortName() {
		return planShortName;
	}

	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}

	public String getProductShortName() {
		return productShortName;
	}

	public void setProductShortName(String productShortName) {
		this.productShortName = productShortName;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getExclusion() {
		return exclusion;
	}

	public void setExclusion(String exclusion) {
		this.exclusion = exclusion;
	}

	public String getImpairmentCode() {
		return impairmentCode;
	}

	public void setImpairmentCode(String impairmentCode) {
		this.impairmentCode = impairmentCode;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getClaimsDecision() {
		return claimsDecision;
	}

	public void setClaimsDecision(String claimsDecision) {
		this.claimsDecision = claimsDecision;
	}

	public String getDeclineReason() {
		return declineReason;
	}

	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}

	public String getSumAssure() {
		return sumAssure;
	}

	public void setSumAssure(String sumAssure) {
		this.sumAssure = sumAssure;
	}

	public String getPayee() {
		return payee;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	public String getSystemQuotation() {
		return systemQuotation;
	}

	public void setSystemQuotation(String systemQuotation) {
		this.systemQuotation = systemQuotation;
	}

	public String getCoInsurance() {
		return coInsurance;
	}

	public void setCoInsurance(String coInsurance) {
		this.coInsurance = coInsurance;
	}

	public String getAdjusted() {
		return adjusted;
	}

	public void setAdjusted(String adjusted) {
		this.adjusted = adjusted;
	}

	public String getAdjustReason() {
		return adjustReason;
	}

	public void setAdjustReason(String adjustReason) {
		this.adjustReason = adjustReason;
	}

	public String getSuppressCheque() {
		return suppressCheque;
	}

	public void setSuppressCheque(String suppressCheque) {
		this.suppressCheque = suppressCheque;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getRider() {
		return rider;
	}

	public void setRider(String rider) {
		this.rider = rider;
	}

	public Boolean getIsCalculated() {
		return isCalculated;
	}

	public void setIsCalculated(Boolean isCalculated) {
		this.isCalculated = isCalculated;
	}

	public String getPayNonCoverItemInd() {
		return payNonCoverItemInd;
	}

	public void setPayNonCoverItemInd(String payNonCoverItemInd) {
		this.payNonCoverItemInd = payNonCoverItemInd;
	}

	public String getDataPrivacyConsent() {
		return dataPrivacyConsent;
	}

	public void setDataPrivacyConsent(String dataPrivacyConsent) {
		this.dataPrivacyConsent = dataPrivacyConsent;
	}

	public String getDataPrivacyConsentDate() {
		return dataPrivacyConsentDate;
	}

	public void setDataPrivacyConsentDate(String dataPrivacyConsentDate) {
		this.dataPrivacyConsentDate = dataPrivacyConsentDate;
	}

	public String getAiDecision() {
		return aiDecision;
	}

	public void setAiDecision(String aiDecision) {
		this.aiDecision = aiDecision;
	}
	
	

}
