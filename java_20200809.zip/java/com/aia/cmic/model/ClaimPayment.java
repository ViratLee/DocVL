package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class ClaimPayment {

	Long claimPaymentId;
	String companyId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String planCoverageNo;
	String productCode;
	String productType;
	String systemEligibility;
	String eligibility;
	String declineCode;
	String declineReason;
	BigDecimal presentedAmt;
	BigDecimal eligibleAmt;
	BigDecimal allocatedAmt;
	BigDecimal adjustedAmt;
	BigDecimal interestAmt;
	BigDecimal hsBonusDeductAmt ;
	String adjustedReason;
	BigDecimal approvedAmt;
	String paymentStatus;
	String payeeType;
	BigDecimal coPaymentPercent;
	BigDecimal coPaymentAmt;
	String suppressChequeInd;
	BigDecimal shortFallAmt;
	Integer noOfDaysAllocated;
	BigDecimal percentageAllocated;
	Integer reimbursedDay;
	String lastModifiedUserDept;
	String lastModifiedUserDesk;
	Date settlementDate;
	String lastModifiedBy;
	Date lastModifiedDt;
	String planCode;
	String payNonCoverItemInd;
	Date paymentDate;
	String planName;
	String planNum;

	BigDecimal bonusAmt;
	BigDecimal deductAmt ;
	String aiEligibility;
	String aiScore;
	
	private String paymentChannel;
	private String paymentTransferRemark;
	/**
	 * @return the claimPaymentId
	 */
	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	/**
	 * @param claimPaymentId the claimPaymentId to set
	 */
	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the systemEligibility
	 */
	public String getSystemEligibility() {
		return systemEligibility;
	}

	/**
	 * @param systemEligibility the systemEligibility to set
	 */
	public void setSystemEligibility(String systemEligibility) {
		this.systemEligibility = systemEligibility;
	}

	/**
	 * @return the eligibility
	 */
	public String getEligibility() {
		return eligibility;
	}

	/**
	 * @param eligibility the eligibility to set
	 */
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	/**
	 * @return the declineCode
	 */
	public String getDeclineCode() {
		return declineCode;
	}

	/**
	 * @param declineCode the declineCode to set
	 */
	public void setDeclineCode(String declineCode) {
		this.declineCode = declineCode;
	}

	/**
	 * @return the declineReason
	 */
	public String getDeclineReason() {
		return declineReason;
	}

	/**
	 * @param declineReason the declineReason to set
	 */
	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}

	/**
	 * @return the presentedAmt
	 */
	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	/**
	 * @param presentedAmt the presentedAmt to set
	 */
	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	/**
	 * @return the eligibleAmt
	 */
	public BigDecimal getEligibleAmt() {
		return eligibleAmt;
	}

	/**
	 * @param eligibleAmt the eligibleAmt to set
	 */
	public void setEligibleAmt(BigDecimal eligibleAmt) {
		this.eligibleAmt = eligibleAmt;
	}

	/**
	 * @return the allocatedAmt
	 */
	public BigDecimal getAllocatedAmt() {
		return allocatedAmt;
	}

	/**
	 * @param allocatedAmt the allocatedAmt to set
	 */
	public void setAllocatedAmt(BigDecimal allocatedAmt) {
		this.allocatedAmt = allocatedAmt;
	}

	/**
	 * @return the adjustedAmt
	 */
	public BigDecimal getAdjustedAmt() {
		return adjustedAmt;
	}

	/**
	 * @param adjustedAmt the adjustedAmt to set
	 */
	public void setAdjustedAmt(BigDecimal adjustedAmt) {
		this.adjustedAmt = adjustedAmt;
	}

	/**
	 * @return the adjustedReason
	 */
	public String getAdjustedReason() {
		return adjustedReason;
	}

	/**
	 * @param adjustedReason the adjustedReason to set
	 */
	public void setAdjustedReason(String adjustedReason) {
		this.adjustedReason = adjustedReason;
	}

	/**
	 * @return the approvedAmt
	 */
	public BigDecimal getApprovedAmt() {
		return approvedAmt;
	}

	/**
	 * @param approvedAmt the approvedAmt to set
	 */
	public void setApprovedAmt(BigDecimal approvedAmt) {
		this.approvedAmt = approvedAmt;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the coPaymentPercent
	 */
	public BigDecimal getCoPaymentPercent() {
		return coPaymentPercent;
	}

	/**
	 * @param coPaymentPercent the coPaymentPercent to set
	 */
	public void setCoPaymentPercent(BigDecimal coPaymentPercent) {
		this.coPaymentPercent = coPaymentPercent;
	}

	/**
	 * @return the coPaymentAmt
	 */
	public BigDecimal getCoPaymentAmt() {
		return coPaymentAmt;
	}

	/**
	 * @param coPaymentAmt the coPaymentAmt to set
	 */
	public void setCoPaymentAmt(BigDecimal coPaymentAmt) {
		this.coPaymentAmt = coPaymentAmt;
	}

	/**
	 * @return the suppressChequeInd
	 */
	public String getSuppressChequeInd() {
		return suppressChequeInd;
	}

	/**
	 * @param suppressChequeInd the suppressChequeInd to set
	 */
	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	/**
	 * @return the shortFallAmt
	 */
	public BigDecimal getShortFallAmt() {
		return shortFallAmt;
	}

	/**
	 * @param shortFallAmt the shortFallAmt to set
	 */
	public void setShortFallAmt(BigDecimal shortFallAmt) {
		this.shortFallAmt = shortFallAmt;
	}

	/**
	 * @return the noOfDaysAllocated
	 */
	public Integer getNoOfDaysAllocated() {
		return noOfDaysAllocated;
	}

	/**
	 * @param noOfDaysAllocated the noOfDaysAllocated to set
	 */
	public void setNoOfDaysAllocated(Integer noOfDaysAllocated) {
		this.noOfDaysAllocated = noOfDaysAllocated;
	}

	/**
	 * @return the percentageAllocated
	 */
	public BigDecimal getPercentageAllocated() {
		return percentageAllocated;
	}

	/**
	 * @param percentageAllocated the percentageAllocated to set
	 */
	public void setPercentageAllocated(BigDecimal percentageAllocated) {
		this.percentageAllocated = percentageAllocated;
	}

	/**
	 * @return the reimbursedDay
	 */
	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	/**
	 * @param reimbursedDay the reimbursedDay to set
	 */
	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	/**
	 * @return the lastModifiedUserDept
	 */
	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	/**
	 * @param lastModifiedUserDept the lastModifiedUserDept to set
	 */
	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	/**
	 * @return the lastModifiedUserDesk
	 */
	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	/**
	 * @param lastModifiedUserDesk the lastModifiedUserDesk to set
	 */
	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getPayNonCoverItemInd() {
		return payNonCoverItemInd;
	}

	public void setPayNonCoverItemInd(String payNonCoverItemInd) {
		this.payNonCoverItemInd = payNonCoverItemInd;
	}

	/**
	 * @return the paymentDate
	 */
	public Date getPaymentDate() {
		return paymentDate;
	}

	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPlanNum() {
		return planNum;
	}

	public void setPlanNum(String planNum) {
		this.planNum = planNum;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public BigDecimal getBonusAmt() {
		return bonusAmt;
	}

	public void setBonusAmt(BigDecimal bonusAmt) {
		this.bonusAmt = bonusAmt;
	}

	public BigDecimal getInterestAmt() {
		return interestAmt;
	}

	public void setInterestAmt(BigDecimal interestAmt) {
		this.interestAmt = interestAmt;
	}

	public BigDecimal getHsBonusDeductAmt() {
		return hsBonusDeductAmt;
	}

	public void setHsBonusDeductAmt(BigDecimal hsBonusDeductAmt) {
		this.hsBonusDeductAmt = hsBonusDeductAmt;
	}

	/**
	 * @return the deductAmt
	 */
	public BigDecimal getDeductAmt() {
		return deductAmt;
	}

	/**
	 * @param deductAmt the deductAmt to set
	 */
	public void setDeductAmt(BigDecimal deductAmt) {
		this.deductAmt = deductAmt;
	}

	public String getAiEligibility() {
		return aiEligibility;
	}

	public void setAiEligibility(String aiEligibility) {
		this.aiEligibility = aiEligibility;
	}

	public String getAiScore() {
		return aiScore;
	}

	public void setAiScore(String aiScore) {
		this.aiScore = aiScore;
	}

	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

	public String getPaymentTransferRemark() {
		return paymentTransferRemark;
	}

	public void setPaymentTransferRemark(String paymentTransferRemark) {
		this.paymentTransferRemark = paymentTransferRemark;
	}

	public String toString() {

		StringBuilder buffer = new StringBuilder();
		buffer.append("claimPaymentId=[").append(claimPaymentId).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("claimNo=[").append(claimNo).append("] ");
		buffer.append("occurrence=[").append(occurrence).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("planId=[").append(planId).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("productType=[").append(productType).append("] ");
		buffer.append("planCoverageNo=[").append(planCoverageNo).append("] ");
		buffer.append("systemEligibility=[").append(systemEligibility).append("] ");
		buffer.append("eligibility=[").append(eligibility).append("] ");
		buffer.append("declineReason=[").append(declineReason).append("] ");
		buffer.append("presentedAmt=[").append(presentedAmt).append("] ");
		buffer.append("eligibleAmt=[").append(eligibleAmt).append("] ");
		buffer.append("allocatedAmt=[").append(allocatedAmt).append("] ");
		buffer.append("adjustedAmt=[").append(adjustedAmt).append("] ");
		buffer.append("adjustedReason=[").append(adjustedReason).append("] ");
		buffer.append("approvedAmt=[").append(approvedAmt).append("] ");
		buffer.append("paymentStatus=[").append(paymentStatus).append("] ");
		buffer.append("payeeType=[").append(payeeType).append("] ");
		buffer.append("coPaymentPercent=[").append(coPaymentPercent).append("] ");
		buffer.append("coPaymentAmt=[").append(coPaymentAmt).append("] ");
		buffer.append("suppressChequeInd=[").append(suppressChequeInd).append("] ");
		buffer.append("shortFallAmt=[").append(shortFallAmt).append("] ");
		buffer.append("noOfDaysAllocated=[").append(noOfDaysAllocated).append("] ");
		buffer.append("percentageAllocated=[").append(percentageAllocated).append("] ");
		buffer.append("reimbursedDay=[").append(reimbursedDay).append("] ");
		buffer.append("lastModifiedUserDept=[").append(lastModifiedUserDept).append("] ");
		buffer.append("lastModifiedUserDesk=[").append(lastModifiedUserDesk).append("] ");
		buffer.append("settlementDate=[").append(settlementDate).append("] ");
		buffer.append("paymentTransferRemark=[").append(paymentTransferRemark).append("] ");
		buffer.append("paymentChannel=[").append(paymentChannel).append("] ");
		buffer.append("planCode=[").append(planCode).append("] ");
		buffer.append("payNonCoverItemInd=[").append(payNonCoverItemInd).append("] ");
		buffer.append("paymentDate=[").append(paymentDate).append("] ");
		buffer.append("deductAmt=[").append(deductAmt).append("] ");
		buffer.append("aiEligibility=[").append(aiEligibility).append("] ");
		buffer.append("aiScore=[").append(aiScore).append("] ");
		
		return buffer.toString();
	}


}
