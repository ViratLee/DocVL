package com.aia.cmic.model;

import java.math.BigDecimal;

public class ClaimCriticalIllness {
	private Long claimSupplementId;
	private String codeType;
	private String strValue;
	private BigDecimal intValue;
	private String primaryInd;
	public Long getClaimSupplementId() {
		return claimSupplementId;
	}
	public String getCodeType() {
		return codeType;
	}
	public String getStrValue() {
		return strValue;
	}
	public BigDecimal getIntValue() {
		return intValue;
	}
	public String getPrimaryInd() {
		return primaryInd;
	}
	public void setClaimSupplementId(Long claimSupplementId) {
		this.claimSupplementId = claimSupplementId;
	}
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}
	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}
	public void setIntValue(BigDecimal intValue) {
		this.intValue = intValue;
	}
	public void setPrimaryInd(String primaryInd) {
		this.primaryInd = primaryInd;
	}
	
}
