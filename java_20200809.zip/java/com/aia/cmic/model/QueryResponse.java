package com.aia.cmic.model;

import java.util.List;

public class QueryResponse {

	private Integer totalRows;
	private List<ResultSet> resultSets;

	public Integer getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(Integer totalRows) {
		this.totalRows = totalRows;
	}

	public List<ResultSet> getResultSets() {
		return resultSets;
	}

	public void setResultSets(List<ResultSet> resultSets) {
		this.resultSets = resultSets;
	}
}
