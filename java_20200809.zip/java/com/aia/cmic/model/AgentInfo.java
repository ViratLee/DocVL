package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.springframework.util.StringUtils;

public class AgentInfo {

	private String agentCode;
	private String agentName;
	private String agencyCode;
	private String agencyName;
	private String agencyLeader;
	private String agencyGaOfficeName;
	private String agencyGaOfficeCode;

	private String brokerCode;
	private String brokerName;

	private String bbl;
	private String mdrt;

	public AgentInfo() {

	}

	public AgentInfo(Claim claim) {
		this.agentCode = claim.getAgentCodeServicing();
		this.agentName = claim.getSubmissionAgentName();
		this.agencyCode = claim.getAgencyCodeServicing();
		this.agencyName = claim.getSubmissionAgencyName();
		this.agencyLeader = claim.getSubmissionAgencyLeaderName();
		this.agencyGaOfficeName = claim.getSubmissionOfficeName();
		this.agencyGaOfficeCode = claim.getAgencyOfficeCodeServicing();
		this.brokerCode = claim.getBrokerCode();
		this.brokerName = claim.getBrokerName();
		this.mdrt = claim.getMdrt();
		this.bbl = claim.getBbl();
	}

	/*
	public Claim convertAgentInfo2Claim(Claim claim) {
		claim.setAgentCodeServicing(this.agentCode);
		claim.setSubmissionAgentName(this.agentName);
		claim.setAgencyCodeServicing(this.agencyCode);
		claim.setSubmissionAgencyName(this.agencyName);
		claim.setSubmissionAgencyLeaderName(this.agencyLeader);
		claim.setSubmissionOfficeName(this.agencyGaOfficeName);
		claim.setAgencyOfficeCodeServicing(this.agencyGaOfficeCode);
		claim.setBrokerCode(this.brokerCode);
		claim.setBrokerName(this.brokerName);
	
		return claim;
	}
	*/
	public AgentInfo(String agentCode, String agencyCode, String brokerCode) {
		this.agentCode = agentCode;
		this.agencyCode = agencyCode;
		this.brokerCode = brokerCode;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getAgencyLeader() {
		return agencyLeader;
	}

	public void setAgencyLeader(String agencyLeader) {
		this.agencyLeader = agencyLeader;
	}

	public String getAgencyGaOfficeName() {
		return agencyGaOfficeName;
	}

	public void setAgencyGaOfficeName(String agencyGaOfficeName) {
		this.agencyGaOfficeName = agencyGaOfficeName;
	}

	public String getAgencyGaOfficeCode() {
		return agencyGaOfficeCode;
	}

	public void setAgencyGaOfficeCode(String agencyGaOfficeCode) {
		this.agencyGaOfficeCode = agencyGaOfficeCode;
	}

	public String getBrokerCode() {
		return brokerCode;
	}

	public void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public String getBbl() {
		return bbl;
	}

	public void setBbl(String bbl) {
		this.bbl = bbl;
	}

	public String getMdrt() {
		return mdrt;
	}

	public void setMdrt(String mdrt) {
		this.mdrt = mdrt;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public boolean empty() {
		if (!StringUtils.isEmpty(agentCode) || !StringUtils.isEmpty(agentName) || !StringUtils.isEmpty(agencyCode) || !StringUtils.isEmpty(agencyName)) {
			return false;
		}
		return true;
	}
}
