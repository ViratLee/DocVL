package com.aia.cmic.model;

public class AiProviderDetail {
	
	private String PROVIDERCODE;
	private String CODENAME ;
	private String STRVALUE;
	
	public String getPROVIDERCODE() {
		return PROVIDERCODE;
	}
	public void setPROVIDERCODE(String pROVIDERCODE) {
		PROVIDERCODE = pROVIDERCODE;
	}
	public String getCODENAME() {
		return CODENAME;
	}
	public void setCODENAME(String cODENAME) {
		CODENAME = cODENAME;
	}
	public String getSTRVALUE() {
		return STRVALUE;
	}
	public void setSTRVALUE(String sTRVALUE) {
		STRVALUE = sTRVALUE;
	}
	
}
