package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class HCInternetICD10CodeForm {
	private List<ICD10CodeModel> icd10Code;
	private String returnCode;
	private String returnMessage;

	public List<ICD10CodeModel> getIcd10Code() {
		return icd10Code;
	}

	public void setIcd10Code(List<ICD10CodeModel> icd10Code) {
		this.icd10Code = icd10Code;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}