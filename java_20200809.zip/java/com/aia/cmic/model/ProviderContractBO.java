package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

import com.aia.cmic.entity.ProviderContract;
import com.aia.cmic.entity.ProviderContractDetail;

public class ProviderContractBO {
	private ProviderContract providerContract;
	private List<ProviderContractDetail> providerContractDetails = new ArrayList<>();
	private List<Long> removeproviderContractDetailId = new ArrayList<Long>();

	public ProviderContract getProviderContract() {
		return providerContract;
	}

	public void setProviderContract(ProviderContract providerContract) {
		this.providerContract = providerContract;
	}

	public List<ProviderContractDetail> getProviderContractDetails() {
		return providerContractDetails;
	}

	public void setProviderContractDetails(List<ProviderContractDetail> providerContractDetails) {
		this.providerContractDetails = providerContractDetails;
	}

	public List<Long> getRemoveproviderContractDetailId() {
		return removeproviderContractDetailId;
	}

	public void setRemoveproviderContractDetailId(List<Long> removeproviderContractDetailId) {
		this.removeproviderContractDetailId = removeproviderContractDetailId;
	}

}
