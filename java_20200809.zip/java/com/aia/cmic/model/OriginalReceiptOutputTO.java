package com.aia.cmic.model;

public class OriginalReceiptOutputTO {	
	/**
	 * 
	 */
	private String code;
	private String message;
	private OriginalReceiptResponse data;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public OriginalReceiptResponse getData() {
		return data;
	}

	public void setData(OriginalReceiptResponse data) {
		this.data = data;
	}

}
