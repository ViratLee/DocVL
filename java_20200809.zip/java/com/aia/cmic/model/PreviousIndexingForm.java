package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PreviousIndexingForm {

	private static final Logger LOG = LoggerFactory.getLogger(PreviousIndexingForm.class);

	private long caseId;
	private String comment;

	public long getCaseId() {
		return caseId;
	}

	public void setCaseId(long caseId) {
		this.caseId = caseId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
