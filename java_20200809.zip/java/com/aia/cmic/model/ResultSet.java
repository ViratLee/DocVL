package com.aia.cmic.model;

import java.util.List;

public class ResultSet {

	private List<Lookup> fieldList;

	public List<Lookup> getFieldList() {
		return fieldList;
	}

	public void setFieldList(List<Lookup> fieldList) {
		this.fieldList = fieldList;
	}
}
