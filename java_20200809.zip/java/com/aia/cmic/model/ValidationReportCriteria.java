package com.aia.cmic.model;

import java.util.Date;

public class ValidationReportCriteria {
	private Date dateStart;
	private Date dateEnd;
	private String claimNo;
	private String policyNo;
	private String planName;
	private String valiationRuleNo;
	private String approval;
	private String actionTaken;
	private String reviewAction;
	private String reviewer;
	private Date lastUpdateDate;

	public Date getDateStart() {
		return dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateEnd() {
		return dateEnd;
	}

	public void setDateEnd(Date dateEnd) {
		this.dateEnd = dateEnd;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getValiationRuleNo() {
		return valiationRuleNo;
	}

	public void setValiationRuleNo(String valiationRuleNo) {
		this.valiationRuleNo = valiationRuleNo;
	}

	public String getApproval() {
		return approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public String getReviewAction() {
		return reviewAction;
	}

	public void setReviewAction(String reviewAction) {
		this.reviewAction = reviewAction;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getOnlyClaimNo() {
		if (claimNo != null && claimNo.length() > 0) {
			String[] spl = claimNo.split("/");

			if (spl != null && spl.length == 2) {

				return spl[0];
			}
		}
		return claimNo;
	}

	public String getOnlyOccurrence() {
		if (claimNo != null && claimNo.length() > 0) {
			String[] spl = claimNo.split("/");

			if (spl != null && spl.length == 2) {

				return spl[1];
			}
		}
		return null;
	}

}
