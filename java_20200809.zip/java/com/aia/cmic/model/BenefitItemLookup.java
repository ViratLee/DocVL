package com.aia.cmic.model;

public class BenefitItemLookup extends Lookup {
	Long benefitItemId;
	String benefitValueKey;
	public Long getBenefitItemId() {
		return benefitItemId;
	}
	public String getBenefitValueKey() {
		return benefitValueKey;
	}
	public void setBenefitItemId(Long benefitItemId) {
		this.benefitItemId = benefitItemId;
	}
	public void setBenefitValueKey(String benefitValueKey) {
		this.benefitValueKey = benefitValueKey;
	}
	
}
