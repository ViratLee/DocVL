package com.aia.cmic.model;

import java.math.BigDecimal;

public class AiClaimHistory {
	private String ACCIDENTDT;
	private String CAUSEOFINJURY;
	private String CAUSEOFTREATMENT;
	private String CLAIMNO;
	private String CLIENTID;
	private String CONSULTATIONDT;
	private String HOSPITALIZATIONDATE;
	private String MEMBERID;
	private Integer OCCURRENCE;
	private String RECEIVEDDATE;
	private BigDecimal TOTALBILLEDAMT;
	private BigDecimal TOTALESTIMATEDCOST;
	private String TREATMENTTYPE;
	private String EDIIND;
	private String STPIND;
	private String AIINDICATOR;
	private String AITHRESHOLD;
	private String AIVERSION;
	private String CLAIMSTATUS;
	private String DISCHARGEDT;
	public String getACCIDENTDT() {
		return ACCIDENTDT;
	}
	public void setACCIDENTDT(String aCCIDENTDT) {
		ACCIDENTDT = aCCIDENTDT;
	}
	public String getCAUSEOFINJURY() {
		return CAUSEOFINJURY;
	}
	public void setCAUSEOFINJURY(String cAUSEOFINJURY) {
		CAUSEOFINJURY = cAUSEOFINJURY;
	}
	public String getCAUSEOFTREATMENT() {
		return CAUSEOFTREATMENT;
	}
	public void setCAUSEOFTREATMENT(String cAUSEOFTREATMENT) {
		CAUSEOFTREATMENT = cAUSEOFTREATMENT;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public String getCLIENTID() {
		return CLIENTID;
	}
	public void setCLIENTID(String cLIENTID) {
		CLIENTID = cLIENTID;
	}
	public String getCONSULTATIONDT() {
		return CONSULTATIONDT;
	}
	public void setCONSULTATIONDT(String cONSULTATIONDT) {
		CONSULTATIONDT = cONSULTATIONDT;
	}
	public String getHOSPITALIZATIONDATE() {
		return HOSPITALIZATIONDATE;
	}
	public void setHOSPITALIZATIONDATE(String hOSPITALIZATIONDATE) {
		HOSPITALIZATIONDATE = hOSPITALIZATIONDATE;
	}
	public String getMEMBERID() {
		return MEMBERID;
	}
	public void setMEMBERID(String mEMBERID) {
		MEMBERID = mEMBERID;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getRECEIVEDDATE() {
		return RECEIVEDDATE;
	}
	public void setRECEIVEDDATE(String rECEIVEDDATE) {
		RECEIVEDDATE = rECEIVEDDATE;
	}
	public BigDecimal getTOTALBILLEDAMT() {
		return TOTALBILLEDAMT;
	}
	public void setTOTALBILLEDAMT(BigDecimal tOTALBILLEDAMT) {
		TOTALBILLEDAMT = tOTALBILLEDAMT;
	}
	public BigDecimal getTOTALESTIMATEDCOST() {
		return TOTALESTIMATEDCOST;
	}
	public void setTOTALESTIMATEDCOST(BigDecimal tOTALESTIMATEDCOST) {
		TOTALESTIMATEDCOST = tOTALESTIMATEDCOST;
	}
	public String getTREATMENTTYPE() {
		return TREATMENTTYPE;
	}
	public void setTREATMENTTYPE(String tREATMENTTYPE) {
		TREATMENTTYPE = tREATMENTTYPE;
	}
	public String getEDIIND() {
		return EDIIND;
	}
	public void setEDIIND(String eDIIND) {
		EDIIND = eDIIND;
	}
	public String getSTPIND() {
		return STPIND;
	}
	public void setSTPIND(String sTPIND) {
		STPIND = sTPIND;
	}
	public String getAIINDICATOR() {
		return AIINDICATOR;
	}
	public void setAIINDICATOR(String aIINDICATOR) {
		AIINDICATOR = aIINDICATOR;
	}
	public String getAITHRESHOLD() {
		return AITHRESHOLD;
	}
	public void setAITHRESHOLD(String aITHRESHOLD) {
		AITHRESHOLD = aITHRESHOLD;
	}
	public String getAIVERSION() {
		return AIVERSION;
	}
	public void setAIVERSION(String aIVERSION) {
		AIVERSION = aIVERSION;
	}
	public String getCLAIMSTATUS() {
		return CLAIMSTATUS;
	}
	public void setCLAIMSTATUS(String cLAIMSTATUS) {
		CLAIMSTATUS = cLAIMSTATUS;
	}
	public String getDISCHARGEDT() {
		return DISCHARGEDT;
	}
	public void setDISCHARGEDT(String dISCHARGEDT) {
		DISCHARGEDT = dISCHARGEDT;
	}
}
