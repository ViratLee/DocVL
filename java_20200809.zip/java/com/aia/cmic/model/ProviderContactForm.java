package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.util.FormatUtil;

public class ProviderContactForm {

	//General Information
	private Long providerContactId;
	private String providerCode;

	private String addressLine1;
	private String district;
	private String city;
	private String province;
	private String region;
	private String country;
	private String latitude;
	private String longitude;
	private String zipcode;
	private String firstname;
	private String lastname;
	private String phoneNo1;
	private String phoneNo2;
	private String faxNo1;
	private String faxNo2;
	private String emailAddress1;
	private String emailAddress2;
	private String website;

	public static ProviderContact toProviderContactEntity(ProviderForm form) {
		ProviderContact providerContact = new ProviderContact();
		providerContact.setAddressLine1(FormatUtil.convertNull(form.getAddressLine1()));
		//providerContact.setAreaCode(areaCode);

		providerContact.setCity(FormatUtil.convertNull(form.getCity()));
		providerContact.setCountry(FormatUtil.convertNull(form.getCountry()));
		//providerContact.setCreatedBy(createdBy);
		//providerContact.setCreatedDt(createdDt);
		providerContact.setDistrict(FormatUtil.convertNull(form.getDistrict()));
		//providerContact.setDoctorCode(doctorCode);
		providerContact.setEmailAddress1(FormatUtil.convertNull(form.getEmailAddress1()));
		providerContact.setEmailAddress2(FormatUtil.convertNull(form.getEmailAddress2()));
		providerContact.setFaxNo1(FormatUtil.convertNull(form.getFaxNo1()));
		providerContact.setFaxNo2(FormatUtil.convertNull(form.getFaxNo2()));
		providerContact.setFirstName(FormatUtil.convertNull(form.getFirstname()));
		providerContact.setLastName(FormatUtil.convertNull(form.getFirstname()));
		//providerContact.setLastModifiedBy(lastModifiedBy));
		//providerContact.setLastModifiedDt(lastModifiedDt);
		providerContact.setLatitude(form.getLatitude());
		providerContact.setLongitude(form.getLongitude());
		providerContact.setPhoneNo1(FormatUtil.convertNull(form.getPhoneNo1()));
		providerContact.setPhoneNo2(FormatUtil.convertNull(form.getPhoneNo2()));
		providerContact.setPostalCode(FormatUtil.convertNull(form.getZipcode()));
		providerContact.setProviderCode(FormatUtil.convertNull(form.getProviderCode()));
		//providerContact.setProviderContactId(form.getProviderContactId());
		providerContact.setProvince(FormatUtil.convertNull(form.getProvinceName()));
		providerContact.setRegion(FormatUtil.convertNull(form.getRegionName()));
		providerContact.setDepartment(FormatUtil.convertNull(form.getDepartment()));
		//providerContact.setWebsite(FormatUtil.convertNull(form.getWebsite()));
		providerContact.setWorkingHours(FormatUtil.convertNull(form.getWorkingHours()));
		return providerContact;
	}

	public Long getProviderContactId() {
		return providerContactId;
	}

	public void setProviderContactId(Long providerContactId) {
		this.providerContactId = providerContactId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhoneNo1() {
		return phoneNo1;
	}

	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	public String getPhoneNo2() {
		return phoneNo2;
	}

	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}

	public String getFaxNo1() {
		return faxNo1;
	}

	public void setFaxNo1(String faxNo1) {
		this.faxNo1 = faxNo1;
	}

	public String getFaxNo2() {
		return faxNo2;
	}

	public void setFaxNo2(String faxNo2) {
		this.faxNo2 = faxNo2;
	}

	public String getEmailAddress1() {
		return emailAddress1;
	}

	public void setEmailAddress1(String emailAddress1) {
		this.emailAddress1 = emailAddress1;
	}

	public String getEmailAddress2() {
		return emailAddress2;
	}

	public void setEmailAddress2(String emailAddress2) {
		this.emailAddress2 = emailAddress2;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
