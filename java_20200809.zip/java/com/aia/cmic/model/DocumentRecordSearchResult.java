package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class DocumentRecordSearchResult {
	private String rownum;
	private String totalCase;
	private String batchNo;
	private String providerCode;
	private String providerName;
	private String businessLine;
	private String stpInd;
	private String ediInd;
	private Date settlementDt;
	private Date paymentDt;
	private Date transferDt;
	private BigDecimal amount;
	private Date receiveDocDt;
	private Date receiveDocModifiedDt;
	private String remark;
	List<Long> lstClaimId;
	private boolean updatableReceiveDocDt;
	private boolean updatableRemark;
	 

	public List<Long> getLstClaimId() {
		return lstClaimId;
	}

	public void setLstClaimId(List<Long> lstClaimId) {
		this.lstClaimId = lstClaimId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public Date getSettlementDt() {
		return settlementDt;
	}

	public void setSettlementDt(Date settlementDt) {
		this.settlementDt = settlementDt;
	}

	public Date getPaymentDt() {
		return paymentDt;
	}

	public void setPaymentDt(Date paymentDt) {
		this.paymentDt = paymentDt;
	}

	public Date getTransferDt() {
		return transferDt;
	}

	public void setTransferDt(Date transferDt) {
		this.transferDt = transferDt;
	}

	public Date getReceiveDocDt() {
		return receiveDocDt;
	}

	public void setReceiveDocDt(Date receiveDocDt) {
		this.receiveDocDt = receiveDocDt;
	}

	public Date getReceiveDocModifiedDt() {
		return receiveDocModifiedDt;
	}

	public void setReceiveDocModifiedDt(Date receiveDocModifiedDt) {
		this.receiveDocModifiedDt = receiveDocModifiedDt;
	}

	public String getTotalCase() {
		return totalCase;
	}

	public void setTotalCase(String totalCase) {
		this.totalCase = totalCase;
	}

	public String getRownum() {
		return rownum;
	}

	public void setRownum(String rownum) {
		this.rownum = rownum;
	}

	public boolean isUpdatableReceiveDocDt() {
		return updatableReceiveDocDt;
	}

	public void setUpdatableReceiveDocDt(boolean updatableReceiveDocDt) {
		this.updatableReceiveDocDt = updatableReceiveDocDt;
	}

	public boolean isUpdatableRemark() {
		return updatableRemark;
	}

	public void setUpdatableRemark(boolean updatableRemark) {
		this.updatableRemark = updatableRemark;
	}
 
}