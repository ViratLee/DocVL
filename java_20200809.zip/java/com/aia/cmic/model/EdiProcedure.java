package com.aia.cmic.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiProcedure {

	private Long ediProcedureId;
	private String claimNo;
	private Integer occurrence;
	@JsonProperty("ICD9")
	private String icd9;
	@JsonProperty("icd9_sub")
	private String icd9Sub;
	@JsonProperty("procedureName")
	private String procedureName;
	@JsonProperty("procedureDate")
	@JsonFormat(shape = Shape.STRING, pattern = "dd-MM-yyyy HH:mm:ss")
	private Date procedureDate;
	private Integer groupId;

	public Long getEdiProcedureId() {
		return ediProcedureId;
	}

	public void setEdiProcedureId(Long ediProcedureId) {
		this.ediProcedureId = ediProcedureId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getIcd9() {
		return icd9;
	}

	public void setIcd9(String icd9) {
		this.icd9 = icd9;
	}

	public String getIcd9Sub() {
		return icd9Sub;
	}

	public void setIcd9Sub(String icd9Sub) {
		this.icd9Sub = icd9Sub;
	}

	public String getProcedureName() {
		return procedureName;
	}

	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}

	public Date getProcedureDate() {
		return procedureDate;
	}

	public void setProcedureDate(Date procedureDate) {
		this.procedureDate = procedureDate;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

}
