package com.aia.cmic.model;

import java.util.List;

import com.aia.cmic.restservices.model.AuditTrailTO;

public class GetAuditTrailResponse {
	private Integer totalRows;
	private List<AuditTrailTO> resultSets;

	public Integer getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(Integer totalRows) {
		this.totalRows = totalRows;
	}

	public List<AuditTrailTO> getResultSets() {
		return resultSets;
	}

	public void setResultSets(List<AuditTrailTO> resultSets) {
		this.resultSets = resultSets;
	}
}
