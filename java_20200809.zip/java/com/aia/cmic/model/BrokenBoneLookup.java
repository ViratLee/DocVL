package com.aia.cmic.model;

import java.math.BigDecimal;

public class BrokenBoneLookup extends Lookup {
    BigDecimal bbPercentage;

    public BigDecimal getBbPercentage() {
        return bbPercentage;
    }

    public void setBbPercentage(BigDecimal bbPercentage) {
        this.bbPercentage = bbPercentage;
    }
}
