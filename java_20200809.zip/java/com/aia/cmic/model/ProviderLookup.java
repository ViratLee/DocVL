package com.aia.cmic.model;

public class ProviderLookup extends Lookup {
	private String providerType;

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}
}
