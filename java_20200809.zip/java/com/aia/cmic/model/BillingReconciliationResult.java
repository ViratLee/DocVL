package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ClaimBilling;
import com.aia.cmic.util.FormatUtil;

public class BillingReconciliationResult {
	private String chklist;
	private Long claimId;
	private String batchNo;
	private String ediInd;
	private String stpInd;
	private String treatmentType;
	private String policyNo;
	private String certNo;
	private String memberId;
	private String firstName;
	private String lastName;
	private String claimNo;
	private String providerCode;
	private String providerName;
	private Date hospitalizationDate;
	private Date dischargeDate;
	private Date settlementDate;
	private Date accidentDt;
	private BigDecimal amount;
	private Lookup decision;
	private Lookup decisionBackend;
	private Date decisionDate;
	private Lookup reason;
	private Date transferDate;
	private Long caseId;
	private String[] icd10;
	private String[] newIcd10;
	private String aiInd;
	private Lookup aiBillingStatus;
	private String aiBillingDeclineReason;
	
	public BillingReconciliationResult() {
	}

	public BillingReconciliationResult(ClaimBilling claim) {
		Lookup lookup = new Lookup();
		this.chklist = "" + claim.getClaimId();
		this.claimId = claim.getClaimId();
		this.batchNo = claim.getBatchNo();
		this.stpInd = claim.getStpInd();
		this.ediInd = claim.getEdiInd();
		this.treatmentType = claim.getTreatmentType();
		this.policyNo = claim.getPolicyNo();
		this.certNo = claim.getCertNo();
		this.memberId = claim.getMemberId();
		this.firstName = claim.getFirstName();
		this.lastName = claim.getLastName();
		this.claimNo = claim.getClaimNo();
		this.providerCode = claim.getProviderCode();
		this.providerName = claim.getPhysicalFinding(); // using physicalFinding to instead of providerName
		this.hospitalizationDate = claim.getHospitalizationDate();
		this.dischargeDate = claim.getDischargeDate();
		//this.settlementDate = claim.getLastModifiedDt();
		this.amount = claim.getTotalBilledAmt();
		lookup.setKey(FormatUtil.convertNull(claim.getBillingStatus()));
		lookup.setValue(FormatUtil.convertNull(claim.getBillingStatusDesc()));
		this.decision = lookup;
		this.decisionBackend = lookup;
		this.decisionDate = new Date();
		lookup = new Lookup();
		lookup.setKey(FormatUtil.convertNull(claim.getBillingDeclineReason()));
		lookup.setValue(FormatUtil.convertNull(claim.getBillingDeclineReasonDesc()));
		this.reason = lookup;
		this.transferDate = new Date();
		this.caseId = claim.getCaseId();
		this.icd10 = FormatUtil.convertNull(claim.getIcd10()).split(",");
		this.accidentDt = claim.getAccidentDt();
		this.settlementDate = claim.getSettlementDate();
		this.aiInd = claim.getAiInd();
		lookup = new Lookup();
		lookup.setKey(FormatUtil.convertNull(claim.getAiBillingStatus()));
		lookup.setValue(FormatUtil.convertNull(claim.getAiBillingStatusDesc()));
		this.aiBillingStatus = lookup;
		this.aiBillingDeclineReason = claim.getAiBillingDeclineReason();
	}

	public String[] getNewIcd10() {
		return newIcd10;
	}

	public void setNewIcd10(String[] newIcd10) {
		this.newIcd10 = newIcd10;
	}

	public String getChklist() {
		return chklist;
	}

	public void setChklist(String chklist) {
		this.chklist = chklist;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Lookup getDecision() {
		return decision;
	}

	public void setDecision(Lookup decision) {
		this.decision = decision;
	}

	public Lookup getDecisionBackend() {
		return decisionBackend;
	}

	public void setDecisionBackend(Lookup decisionBackend) {
		this.decisionBackend = decisionBackend;
	}

	public Date getDecisionDate() {
		return decisionDate;
	}

	public void setDecisionDate(Date decisionDate) {
		this.decisionDate = decisionDate;
	}

	public Lookup getReason() {
		return reason;
	}

	public void setReason(Lookup reason) {
		this.reason = reason;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String[] getIcd10() {
		return icd10;
	}

	public void setIcd10(String[] icd10) {
		this.icd10 = icd10;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}
	

	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}
	
	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}
	
	public String getAiInd() {
		return aiInd;
	}

	public void setAiInd(String aiInd) {
		this.aiInd = aiInd;
	}

	public Lookup getAiBillingStatus() {
		return aiBillingStatus;
	}

	public void setAiBillingStatus(Lookup aiBillingStatus) {
		this.aiBillingStatus = aiBillingStatus;
	}

	public String getAiBillingDeclineReason() {
		return aiBillingDeclineReason;
	}

	public void setAiBillingDeclineReason(String aiBillingDeclineReason) {
		this.aiBillingDeclineReason = aiBillingDeclineReason;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
