package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ICD10Code;

public class ICD10CodeModel {
	private String code;
	private String subcodeDesc;

	public ICD10CodeModel(ICD10Code icd10Code) {
		this.code = icd10Code.getIcd10Code() + "." + icd10Code.getIcdSubCode();
		this.subcodeDesc = icd10Code.getSubCodeDesc();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSubcodeDesc() {
		return subcodeDesc;
	}

	public void setSubcodeDesc(String subcodeDesc) {
		this.subcodeDesc = subcodeDesc;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}