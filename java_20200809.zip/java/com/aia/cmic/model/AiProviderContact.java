package com.aia.cmic.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AiProviderContact {
	
	private String AREACODE;
	private String COUNTRY;
	private String DEPARTMENT;
	private String POSTALCODE;
	private String PROVIDERCODE;
	private String PROVINCE;
	private String REGION;
	
	// New Field
	private Long PROVIDERCONTACTID;
	
	
	public String getAREACODE() {
		return AREACODE;
	}
	public void setAREACODE(String aREACODE) {
		AREACODE = aREACODE;
	}
	public String getCOUNTRY() {
		return COUNTRY;
	}
	public void setCOUNTRY(String cOUNTRY) {
		COUNTRY = cOUNTRY;
	}
	public String getDEPARTMENT() {
		return DEPARTMENT;
	}
	public void setDEPARTMENT(String dEPARTMENT) {
		DEPARTMENT = dEPARTMENT;
	}
	public String getPOSTALCODE() {
		return POSTALCODE;
	}
	public void setPOSTALCODE(String pOSTALCODE) {
		POSTALCODE = pOSTALCODE;
	}
	public String getPROVIDERCODE() {
		return PROVIDERCODE;
	}
	public void setPROVIDERCODE(String pROVIDERCODE) {
		PROVIDERCODE = pROVIDERCODE;
	}
	public String getPROVINCE() {
		return PROVINCE;
	}
	public void setPROVINCE(String pROVINCE) {
		PROVINCE = pROVINCE;
	}
	public String getREGION() {
		return REGION;
	}
	public void setREGION(String rEGION) {
		REGION = rEGION;
	}
	public Long getPROVIDERCONTACTID() {
		return PROVIDERCONTACTID;
	}
	public void setPROVIDERCONTACTID(Long pROVIDERCONTACTID) {
		PROVIDERCONTACTID = pROVIDERCONTACTID;
	}
	
	
}
