package com.aia.cmic.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class BenefitSettlementDetail {
	@XmlElement(name = "insuredName")
	String insuredName;
	@XmlElement(name = "claimStatus")
	String claimStatus;
	@XmlElement(name = "claimStatusDesc")
	String claimStatusDesc;
	@XmlElement(name = "claimNo")
	String claimNo;
	@XmlElement(name = "occurrence")
	int occurrence;
	@XmlElement(name = "accidentDt")
	String accidentDt;
	@XmlElement(name = "receivedDate")
	String receivedDate;
	@XmlElement(name = "hospitalizationDate")
	String hospitalizationDate;
	@XmlElement(name = "settlementDate")
	String settlementDate;
	@XmlElement(name = "dischargeDate")
	String dischargeDate;

	public String getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(String accidentDt) {
		this.accidentDt = accidentDt;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getHospitalizationDate() {
		return hospitalizationDate;
	}

	public void setHospitalizationDate(String hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public String getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public int getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(int occurrence) {
		this.occurrence = occurrence;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getClaimStatusDesc() {
		return claimStatusDesc;
	}

	public void setClaimStatusDesc(String claimStatusDesc) {
		this.claimStatusDesc = claimStatusDesc;
	}

}
