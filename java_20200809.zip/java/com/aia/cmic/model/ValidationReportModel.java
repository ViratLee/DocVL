package com.aia.cmic.model;

public class ValidationReportModel {

	private Long claimRulesLogId;
	private String ruleReviewAction;
	private String ruleReviewDecision;

	public Long getClaimRulesLogId() {
		return claimRulesLogId;
	}

	public void setClaimRulesLogId(Long claimRulesLogId) {
		this.claimRulesLogId = claimRulesLogId;
	}

	public String getRuleReviewAction() {
		return ruleReviewAction;
	}

	public void setRuleReviewAction(String ruleReviewAction) {
		this.ruleReviewAction = ruleReviewAction;
	}

	public String getRuleReviewDecision() {
		return ruleReviewDecision;
	}

	public void setRuleReviewDecision(String ruleReviewDecision) {
		this.ruleReviewDecision = ruleReviewDecision;
	}

}
