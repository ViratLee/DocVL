package com.aia.cmic.model;

import java.util.Date;

public class Insured {
	Long insuredId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	String title;
	String firstName;
	String lastName;
	String gender;
	Date dob;
	String nationalId;
	String status;
	String bankruptcyInd;
	Date bankruptcyDt;
	String blacklistInd;
	String amloInd;
	String ofacInd;
	String fatcaInd;
	String secInd;
	String oncbInd;
	String politicalInd;
	String suspenseInd;
	String watchlistInd;
	String addressLine1;
	String addressLine2;
	String addressLine3;
	String addressLine4;
	String city;
	String state;
	String postalCode;
	String country;
	String emailAddress;
	String mobile;
	String telephone;
	Date initialEffectiveDt;
	Date effectiveDt;

	/**
	 * @return the insuredId
	 */
	public Long getInsuredId() {
		return insuredId;
	}

	/**
	 * @param insuredId the insuredId to set
	 */
	public void setInsuredId(Long insuredId) {
		this.insuredId = insuredId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	/**
	 * @return the nationalId
	 */
	public String getNationalId() {
		return nationalId;
	}

	/**
	 * @param nationalId the nationalId to set
	 */
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the bankruptcyInd
	 */
	public String getBankruptcyInd() {
		return bankruptcyInd;
	}

	/**
	 * @param bankruptcyInd the bankruptcyInd to set
	 */
	public void setBankruptcyInd(String bankruptcyInd) {
		this.bankruptcyInd = bankruptcyInd;
	}

	/**
	 * @return the blacklistInd
	 */
	public String getBlacklistInd() {
		return blacklistInd;
	}

	/**
	 * @param blacklistInd the blacklistInd to set
	 */
	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	/**
	 * @return the amloInd
	 */
	public String getAmloInd() {
		return amloInd;
	}

	/**
	 * @param amloInd the amloInd to set
	 */
	public void setAmloInd(String amloInd) {
		this.amloInd = amloInd;
	}

	/**
	 * @return the ofacInd
	 */
	public String getOfacInd() {
		return ofacInd;
	}

	/**
	 * @param ofacInd the ofacInd to set
	 */
	public void setOfacInd(String ofacInd) {
		this.ofacInd = ofacInd;
	}

	/**
	 * @return the fatcaInd
	 */
	public String getFatcaInd() {
		return fatcaInd;
	}

	/**
	 * @param fatcaInd the fatcaInd to set
	 */
	public void setFatcaInd(String fatcaInd) {
		this.fatcaInd = fatcaInd;
	}

	/**
	 * @return the secInd
	 */
	public String getSecInd() {
		return secInd;
	}

	/**
	 * @param secInd the secInd to set
	 */
	public void setSecInd(String secInd) {
		this.secInd = secInd;
	}

	/**
	 * @return the onbcInd
	 */

	/**
	 * @return the politicalInd
	 */
	public String getPoliticalInd() {
		return politicalInd;
	}


	public String getOncbInd() {
		return oncbInd;
	}

	public void setOncbInd(String oncbInd) {
		this.oncbInd = oncbInd;
	}

	/**
	 * @param politicalInd the politicalInd to set
	 */
	public void setPoliticalInd(String politicalInd) {
		this.politicalInd = politicalInd;
	}

	/**
	 * @return the suspenseInd
	 */
	public String getSuspenseInd() {
		return suspenseInd;
	}

	/**
	 * @param suspenseInd the suspenseInd to set
	 */
	public void setSuspenseInd(String suspenseInd) {
		this.suspenseInd = suspenseInd;
	}

	/**
	 * @return the watchlistInd
	 */
	public String getWatchlistInd() {
		return watchlistInd;
	}

	/**
	 * @param watchlistInd the watchlistInd to set
	 */
	public void setWatchlistInd(String watchlistInd) {
		this.watchlistInd = watchlistInd;
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 * @return the addressLine4
	 */
	public String getAddressLine4() {
		return addressLine4;
	}

	/**
	 * @param addressLine4 the addressLine4 to set
	 */
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @return the initialEffectiveDt
	 */
	public Date getInitialEffectiveDt() {
		return initialEffectiveDt;
	}

	/**
	 * @param initialEffectiveDt the initialEffectiveDt to set
	 */
	public void setInitialEffectiveDt(Date initialEffectiveDt) {
		this.initialEffectiveDt = initialEffectiveDt;
	}

	/**
	 * @return the effectiveDt
	 */
	public Date getEffectiveDt() {
		return effectiveDt;
	}

	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getBankruptcyDt() {
		return bankruptcyDt;
	}

	public void setBankruptcyDt(Date bankruptcyDt) {
		this.bankruptcyDt = bankruptcyDt;
	}
	
	

}
