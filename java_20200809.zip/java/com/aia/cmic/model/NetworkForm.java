package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.entity.NetworkJoinNetworkDetail;

public class NetworkForm {

	private static final Logger LOG = LoggerFactory.getLogger(NetworkForm.class);

	private Long networkId;
	private String networkName;
	private Date effectiveToDt;
	private String createdBy;
	private Date createdDt;
	String businessLine;
	String networkType;
	String networkSpecificProduct;
	String businessLineId;
	String networkTypeId;
	String networkSpecificProductId;
	String[] arrBusinessLine;
	String[] arrNetworkType;
	String[] arrNetworkSpecificProduct;
	private String lastModifiedBy;
	private Date lastModifiedDt;

	public NetworkForm() {
	}

	public NetworkForm(NetworkJoinNetworkDetail network) {
		this.networkId = network.getNetworkId();
		this.networkName = network.getNetworkName();
		this.effectiveToDt = network.getEffectiveToDt();
		this.createdBy = network.getCreatedBy();
		this.createdDt = network.getCreatedDt();
		this.businessLine = network.getBusinessLine();
		this.networkType = network.getNetworkType();
		this.networkSpecificProduct = network.getNetworkSpecificProduct();
		this.businessLineId = network.getBusinessLineId();
		this.networkTypeId = network.getNetworkTypeId();
		this.networkSpecificProductId = network.getNetworkSpecificProductId();
		this.lastModifiedBy = network.getLastModifiedBy();
		this.lastModifiedDt = network.getLastModifiedDt();
		this.arrBusinessLine = network.getBusinessLine().split(",");
		this.arrNetworkSpecificProduct = network.getNetworkSpecificProduct().split(",");
		this.arrNetworkType = network.getNetworkType().split(",");
	}

	public final Long getNetworkId() {
		return networkId;
	}

	public final void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public final String getNetworkName() {
		return networkName;
	}

	public final void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public final Date getEffectiveToDt() {
		return effectiveToDt;
	}

	public final void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public final String getCreatedBy() {
		return createdBy;
	}

	public final void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public final Date getCreatedDt() {
		return createdDt;
	}

	public final void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public final String getBusinessLine() {
		return businessLine;
	}

	public final void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public final String getNetworkType() {
		return networkType;
	}

	public final void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public final String getNetworkSpecificProduct() {
		return networkSpecificProduct;
	}

	public final void setNetworkSpecificProduct(String networkSpecificProduct) {
		this.networkSpecificProduct = networkSpecificProduct;
	}

	public String getBusinessLineId() {
		return businessLineId;
	}

	public void setBusinessLineId(String businessLineId) {
		this.businessLineId = businessLineId;
	}

	public String getNetworkTypeId() {
		return networkTypeId;
	}

	public void setNetworkTypeId(String networkTypeId) {
		this.networkTypeId = networkTypeId;
	}

	public String getNetworkSpecificProductId() {
		return networkSpecificProductId;
	}

	public void setNetworkSpecificProductId(String networkSpecificProductId) {
		this.networkSpecificProductId = networkSpecificProductId;
	}

	public final String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public final void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public final Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public final void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String[] getArrBusinessLine() {
		return arrBusinessLine;
	}

	public void setArrBusinessLine(String[] arrBusinessLine) {
		this.arrBusinessLine = arrBusinessLine;
	}

	public String[] getArrNetworkType() {
		return arrNetworkType;
	}

	public void setArrNetworkType(String[] arrNetworkType) {
		this.arrNetworkType = arrNetworkType;
	}

	public String[] getArrNetworkSpecificProduct() {
		return arrNetworkSpecificProduct;
	}

	public void setArrNetworkSpecificProduct(String[] arrNetworkSpecificProduct) {
		this.arrNetworkSpecificProduct = arrNetworkSpecificProduct;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
