package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class DoubleCiInquirySearchCriteria {
	
	private String policyNo;
	private String clientId;
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	

}
