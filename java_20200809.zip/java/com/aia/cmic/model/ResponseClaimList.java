package com.aia.cmic.model;

import java.util.List;

public class ResponseClaimList {

	private List<ClaimSnapshot> lstOfClaimSnapshot;
	private String successIndicator;
	private String errorMessage;

	public List<ClaimSnapshot> getLstOfClaimSnapshot() {
		return lstOfClaimSnapshot;
	}

	public void setLstOfClaimSnapshot(List<ClaimSnapshot> lstOfClaimSnapshot) {
		this.lstOfClaimSnapshot = lstOfClaimSnapshot;
	}

	public String getSuccessIndicator() {
		return successIndicator;
	}

	public void setSuccessIndicator(String successIndicator) {
		this.successIndicator = successIndicator;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
