package com.aia.cmic.model;

import java.sql.Timestamp;
import java.util.List;

import com.aia.cmic.restservices.model.MyQueueTO;

public class ConsentResponse {
	private String policyNo;
	private String memberId;
	private String nationalId;
	private String partyId;
	private String clientId;
	private Timestamp updateDate;
	private String updateBy;
	private String consentDocversion;
	private String sourceSystem;
	private String subOffice;
	private String clientCode;
	private long consentSignDate;
	private String certId;
	private String dependNo;
	private String assigneeName;
	private String clientName;
	private String status;
	private String channel;
	private String clientType;
	private String customerId;
	private String docId;
	private String dataSource;
	private List<Consent> consents;
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getNationalId() {
		return nationalId;
	}
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public Timestamp getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public String getConsentDocversion() {
		return consentDocversion;
	}
	public void setConsentDocversion(String consentDocversion) {
		this.consentDocversion = consentDocversion;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getSubOffice() {
		return subOffice;
	}
	public void setSubOffice(String subOffice) {
		this.subOffice = subOffice;
	}
	public String getClientCode() {
		return clientCode;
	}
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}
	
	public long getConsentSignDate() {
		return consentSignDate;
	}
	public void setConsentSignDate(long consentSignDate) {
		this.consentSignDate = consentSignDate;
	}
	public String getCertId() {
		return certId;
	}
	public void setCertId(String certId) {
		this.certId = certId;
	}
	public String getDependNo() {
		return dependNo;
	}
	public void setDependNo(String dependNo) {
		this.dependNo = dependNo;
	}
	public String getAssigneeName() {
		return assigneeName;
	}
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getClientType() {
		return clientType;
	}
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public List<Consent> getConsents() {
		return consents;
	}
	public void setConsents(List<Consent> consents) {
		this.consents = consents;
	}
	
	

}
