package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianSearchForm {
	@JsonProperty
	private String firstName;
	@JsonProperty
	private String lastName;
	@JsonProperty
	private String doctorCode;
	@JsonProperty
	private String licenseNo;
	@JsonProperty
	private String specialty;
	@JsonProperty
	private String blacklistInd;
	@JsonProperty
	private Date effectivePeriodStart;
	@JsonProperty
	private Date effectivePeriodEnd;
	@JsonProperty
	private Date terminatePeriodStart;
	@JsonProperty
	private Date terminatePeriodEnd;
	@JsonProperty
	private Boolean deathFlag;
	@JsonProperty
	private String blackListReason = "";
	@JsonProperty
	private int page = 1;
	@JsonProperty
	private int pageSize = 10;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getDoctorCode() {
		return doctorCode;
	}

	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	public String getBlacklistInd() {
		return blacklistInd;
	}

	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public Boolean getDeathFlag() {
		return deathFlag;
	}

	public void setDeathFlag(Boolean deathFlag) {
		this.deathFlag = deathFlag;
	}

	public String getBlackListReason() {
		return blackListReason;
	}

	public void setBlackListReason(String blackListReason) {
		this.blackListReason = blackListReason;
	}

	public Date getEffectivePeriodStart() {
		return effectivePeriodStart;
	}

	public void setEffectivePeriodStart(Date effectivePeriodStart) {
		this.effectivePeriodStart = effectivePeriodStart;
	}

	public Date getEffectivePeriodEnd() {
		return effectivePeriodEnd;
	}

	public void setEffectivePeriodEnd(Date effectivePeriodEnd) {
		this.effectivePeriodEnd = effectivePeriodEnd;
	}

	public Date getTerminatePeriodStart() {
		return terminatePeriodStart;
	}

	public void setTerminatePeriodStart(Date terminatePeriodStart) {
		this.terminatePeriodStart = terminatePeriodStart;
	}

	public Date getTerminatePeriodEnd() {
		return terminatePeriodEnd;
	}

	public void setTerminatePeriodEnd(Date terminatePeriodEnd) {
		this.terminatePeriodEnd = terminatePeriodEnd;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
