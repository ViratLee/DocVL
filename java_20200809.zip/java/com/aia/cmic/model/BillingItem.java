package com.aia.cmic.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingItem {
	Long claimBenefitItemId;
	Lookup serviceCatId;
	String serviceItemDesc;
	Integer seqNo;
	BigDecimal presentedAmt;
	BigDecimal presentedDiscountAmt;
	BigDecimal presentedPercentage;
	BigDecimal netAmt;
	BigDecimal discountOnListPrice;

	public Long getClaimBenefitItemId() {
		return claimBenefitItemId;
	}

	public void setClaimBenefitItemId(Long claimBenefitItemId) {
		this.claimBenefitItemId = claimBenefitItemId;
	}

	public Lookup getServiceCatId() {
		return serviceCatId;
	}

	public void setServiceCatId(Lookup serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	public String getServiceItemDesc() {
		return serviceItemDesc;
	}

	public void setServiceItemDesc(String serviceItemDesc) {
		this.serviceItemDesc = serviceItemDesc;
	}

	public BigDecimal getPresentedAmt() {
		return presentedAmt;
	}

	public void setPresentedAmt(BigDecimal presentedAmt) {
		this.presentedAmt = presentedAmt;
	}

	public BigDecimal getPresentedDiscountAmt() {
		return presentedDiscountAmt;
	}

	public void setPresentedDiscountAmt(BigDecimal presentedDiscountAmt) {
		this.presentedDiscountAmt = presentedDiscountAmt;
	}

	public BigDecimal getPresentedPercentage() {
		return presentedPercentage;
	}

	public void setPresentedPercentage(BigDecimal presentedPercentage) {
		this.presentedPercentage = presentedPercentage;
	}

	public BigDecimal getNetAmt() {
		return netAmt;
	}

	public void setNetAmt(BigDecimal netAmt) {
		this.netAmt = netAmt;
	}

	public BigDecimal getDiscountOnListPrice() {
		return discountOnListPrice;
	}

	public void setDiscountOnListPrice(BigDecimal discountOnListPrice) {
		this.discountOnListPrice = discountOnListPrice;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}
	
	
}
