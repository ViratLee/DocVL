package com.aia.cmic.model;

public class HNWDeductForm {
	Long hnwDeductId;
	Long claimId;
	Long caseId;
    String claimNo;
    String policyNo;
    Integer occurrence;
    String businessLine;
    String nationalId;
    
	public Long getHnwDeductId() {
		return hnwDeductId;
	}
	public Long getClaimId() {
		return claimId;
	}
	public Long getCaseId() {
		return caseId;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public Integer getOccurrence() {
		return occurrence;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public String getNationalId() {
		return nationalId;
	}
	public void setHnwDeductId(Long hnwDeductId) {
		this.hnwDeductId = hnwDeductId;
	}
	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}
	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}
    
     
}
