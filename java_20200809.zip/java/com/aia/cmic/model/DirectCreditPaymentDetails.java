package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

public class DirectCreditPaymentDetails {
	
	private String providerCode;
	private String providerNameThai;
	private Double presentedGrossAmt;
	private String paymentTransferDt;
	private List<Long> lstClaimPaymentId;

	
	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public List<Long> getLstClaimPaymentId() {
		return lstClaimPaymentId;
	}

	public void setLstClaimPaymentId(List<Long> lstClaimPaymentId) {
		this.lstClaimPaymentId = lstClaimPaymentId;
	}

	public String getProviderNameThai() {
		return providerNameThai;
	}

	public void setProviderNameThai(String providerNameThai) {
		this.providerNameThai = providerNameThai;
	}

	public Double getPresentedGrossAmt() {
		return presentedGrossAmt;
	}

	public void setPresentedGrossAmt(Double presentedGrossAmt) {
		this.presentedGrossAmt = presentedGrossAmt;
	}

	public String getPaymentTransferDt() {
		return paymentTransferDt;
	}

	public void setPaymentTransferDt(String paymentTransferDt) {
		this.paymentTransferDt = paymentTransferDt;
	}

	
}
