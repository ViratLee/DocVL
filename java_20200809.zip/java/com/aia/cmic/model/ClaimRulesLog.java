package com.aia.cmic.model;

public class ClaimRulesLog {

	Long claimRulesLogId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String planCoverageNo;
	String ruleName;
	String riskLevel;
	String decision;
	String reason;
	String ruleNo;
	String ruleDesc;

	/**
	 * @return the claimRulesLogId
	 */
	public Long getClaimRulesLogId() {
		return claimRulesLogId;
	}

	/**
	 * @param claimRulesLogId the claimRulesLogId to set
	 */
	public void setClaimRulesLogId(Long claimRulesLogId) {
		this.claimRulesLogId = claimRulesLogId;
	}

	public String getRuleNo() {
		return ruleNo;
	}

	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}

	/**
	 * @return the occurrence
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}

	/**
	 * @param ruleName the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	/**
	 * @return the riskLevel
	 */
	public String getRiskLevel() {
		return riskLevel;
	}

	/**
	 * @param riskLevel the riskLevel to set
	 */
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}

	/**
	 * @return the decision
	 */
	public String getDecision() {
		return decision;
	}

	/**
	 * @param decision the decision to set
	 */
	public void setDecision(String decision) {
		this.decision = decision;
	}

	/**
	 * @return the reason 
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRuleDesc() {
		return ruleDesc;
	}

	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}

}
