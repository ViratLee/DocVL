package com.aia.cmic.model;

import java.math.BigDecimal;

public class HNWBenefitCodeCoverage {
	private String policyNo;
	private String rider;
	private String coverage;
	Long benefitItemId;
	Lookup benefitValueKey;
	private Integer call;
	private BigDecimal deductAmount;
	public String getPolicyNo() {
		return policyNo;
	}
	public String getRider() {
		return rider;
	}
	public String getCoverage() {
		return coverage;
	}
	public Long getBenefitItemId() {
		return benefitItemId;
	}
	public Lookup getBenefitValueKey() {
		return benefitValueKey;
	}
	public Integer getCall() {
		return call;
	}
	public BigDecimal getDeductAmount() {
		return deductAmount;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public void setRider(String rider) {
		this.rider = rider;
	}
	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}
	public void setBenefitItemId(Long benefitItemId) {
		this.benefitItemId = benefitItemId;
	}
	public void setBenefitValueKey(Lookup benefitValueKey) {
		this.benefitValueKey = benefitValueKey;
	}
	public void setCall(Integer call) {
		this.call = call;
	}
	public void setDeductAmount(BigDecimal deductAmount) {
		this.deductAmount = deductAmount;
	}
	
	
}
