package com.aia.cmic.model;

import java.util.Date;

/**
 * @author ASNPAGM
 * @version 1.0
 * @created 10-Sep-2016 11:16:53 PM
 */
public class AuditTrail {

	private String userId;
	private Date transactionDate;
	private String description;

	public AuditTrail() {

	}

	public void finalize() throws Throwable {

	}

}