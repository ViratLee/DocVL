package com.aia.cmic.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
public class OnlinePrintKey {
	@XmlElement(name = "FORMID")
	private String formID;
	@XmlElement(name = "POLICYNO")
	private String policyNO;
	@XmlElement(name = "COMPANY")
	private String company;
	@XmlElement(name = "CYCLEDATE")
	@XmlJavaTypeAdapter(DateFormatter.class)
	private Date cycleDate;
	@XmlElement(name = "USERID")
	private String userID;
	@XmlElement(name = "USERDEPT")
	private String userDept;
	@XmlElement(name = "USERNAME")
	private String userName;
	@XmlElement(name = "ADMITFROM")
	@XmlJavaTypeAdapter(DateThaiFormatter.class)
	private Date admitFrom;
	@XmlElement(name = "ADMITTO")
	@XmlJavaTypeAdapter(DateThaiFormatter.class)
	private Date admitTo;
	@XmlElement(name = "SUBMISSIONDATE")
	@XmlJavaTypeAdapter(DateFormatter.class)
	private Date submissionDate;
	@XmlElement(name = "INSUREDFIRSTNAME", required = true)
	private String insuredFirstName;
	@XmlElement(name = "INSUREDLASTNAME", required = true)
	private String insuredLastName;
	@XmlElement(name = "DOCUMENTINTIME", required = true)
	@XmlJavaTypeAdapter(DateFormatter.class)
	private Date documentIntime;
	@XmlElement(name = "ADDDOCUMENTINTIME", required = true)
	@XmlJavaTypeAdapter(DateFormatter.class)
	private Date addDocumentIntime;
	@XmlElement(name = "HOSPITALNAME", required = true)
	private String hospitalName;

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Date getCycleDate() {
		return cycleDate;
	}

	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserDept() {
		return userDept;
	}

	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public String getPolicyNO() {
		return policyNO;
	}

	public void setPolicyNO(String policyNO) {
		this.policyNO = policyNO;
	}

	public Date getDocumentIntime() {
		return documentIntime;
	}

	public void setDocumentIntime(Date documentIntime) {
		this.documentIntime = documentIntime;
	}

	public Date getAddDocumentIntime() {
		return addDocumentIntime;
	}

	public void setAddDocumentIntime(Date addDocumentIntime) {
		this.addDocumentIntime = addDocumentIntime;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getInsuredFirstName() {
		return insuredFirstName;
	}

	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	public String getInsuredLastName() {
		return insuredLastName;
	}

	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public Date getAdmitFrom() {
		return admitFrom;
	}

	public void setAdmitFrom(Date admitFrom) {
		this.admitFrom = admitFrom;
	}

	public Date getAdmitTo() {
		return admitTo;
	}

	public void setAdmitTo(Date admitTo) {
		this.admitTo = admitTo;
	}

	private static class DateFormatter extends XmlAdapter<String, Date> {
		private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		@Override
		public String marshal(Date arg0) throws Exception {
			return dateFormat.format(arg0);

		}

		@Override
		public Date unmarshal(String arg0) throws Exception {
			return dateFormat.parse(arg0);
		}

	}

	private static class DateThaiFormatter extends XmlAdapter<String, Date> {
		private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		@Override
		public String marshal(Date arg0) throws Exception {
			return dateFormat.format(arg0);

		}

		@Override
		public Date unmarshal(String arg0) throws Exception {
			return dateFormat.parse(arg0);
		}

	}
}
