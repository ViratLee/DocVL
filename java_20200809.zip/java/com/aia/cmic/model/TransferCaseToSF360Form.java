package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class TransferCaseToSF360Form {

	private BigDecimal caseId;
	private List<BigDecimal> docIdList;
	private String taskType;
	private String comment;
	private boolean isDelete;

	private String policyno;
	private String certno;

	public BigDecimal getCaseId() {
		return caseId;
	}

	public void setCaseId(BigDecimal caseId) {
		this.caseId = caseId;
	}

	public List<BigDecimal> getDocIdList() {
		return docIdList;
	}

	public void setDocIdList(List<BigDecimal> docIdList) {
		this.docIdList = docIdList;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public String getPolicyno() {
		return policyno;
	}

	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}

	public String getCertno() {
		return certno;
	}

	public void setCertno(String certno) {
		this.certno = certno;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
