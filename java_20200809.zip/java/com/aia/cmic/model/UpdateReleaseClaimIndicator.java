package com.aia.cmic.model;


public class UpdateReleaseClaimIndicator {
	private String companyId;
	private String policyNo;
	private String subOffice;
	private String productCode;
	private String memberId;
	private String claimPaidToDate;
	private String claimReleasedByInd ;
	

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getSubOffice() {
		return subOffice;
	}

	public void setSubOffice(String subOffice) {
		this.subOffice = subOffice;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getClaimPaidToDate() {
		return claimPaidToDate;
	}

	public void setClaimPaidToDate(String claimPaidToDate) {
		this.claimPaidToDate = claimPaidToDate;
	}

	/**
	 * @return the claimReleasedByInd
	 */
	public String getClaimReleasedByInd() {
		return claimReleasedByInd;
	}

	/**
	 * @param claimReleasedByInd the claimReleasedByInd to set
	 */
	public void setClaimReleasedByInd(String claimReleasedByInd) {
		this.claimReleasedByInd = claimReleasedByInd;
	}

}
