package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ICD9Code;

public class ICD9CodeModel {
	private String code;
	private String subcodeDesc;

	public ICD9CodeModel(ICD9Code icd9Code) {
		this.code = icd9Code.getIcd9Code() + "." + icd9Code.getIcdSubCode();
		this.subcodeDesc = icd9Code.getSubCodeLongDesc();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSubcodeDesc() {
		return subcodeDesc;
	}

	public void setSubcodeDesc(String subcodeDesc) {
		this.subcodeDesc = subcodeDesc;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}