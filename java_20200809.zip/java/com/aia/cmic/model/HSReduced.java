package com.aia.cmic.model;

import java.text.SimpleDateFormat;

import com.aia.cmic.entity.ClaimPaymentDetail;

/**
 * Use for HS-PA Reduced allocation
 * @author Ronald
 *
 */
public class HSReduced implements Comparable<HSReduced> {
	public HSReduced(ClaimPaymentDetail claimPaymentDetail, ClaimPolicy claimPolicy) {
		this.claimPaymentDetail = claimPaymentDetail;
		this.claimPolicy = claimPolicy;
	}

	private ClaimPaymentDetail claimPaymentDetail;
	private ClaimPolicy claimPolicy;

	/**
	 * @return the claimPaymentDetail
	 */
	public ClaimPaymentDetail getClaimPaymentDetail() {
		return claimPaymentDetail;
	}

	/**
	 * @param claimPaymentDetail the claimPaymentDetail to set
	 */
	public void setClaimPaymentDetail(ClaimPaymentDetail claimPaymentDetail) {
		this.claimPaymentDetail = claimPaymentDetail;
	}

	/**
	 * @return the claimPolicy
	 */
	public ClaimPolicy getClaimPolicy() {
		return claimPolicy;
	}

	/**
	 * @param claimPolicy the claimPolicy to set
	 */
	public void setClaimPolicy(ClaimPolicy claimPolicy) {
		this.claimPolicy = claimPolicy;
	}

	@Override
	public int compareTo(HSReduced that) {

		int comparison = this.getClaimPaymentDetail().getHsReductionSeq().compareTo(that.getClaimPaymentDetail().getHsReductionSeq());
		if (comparison == 0) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			comparison = sdf.format(this.getClaimPolicy().getPolicyIssueDt()).compareTo(sdf.format(that.getClaimPolicy().getPolicyIssueDt()));
			if (comparison == 0) {
				comparison = this.getClaimPolicy().getPolicyNo().compareTo(that.getClaimPolicy().getPolicyNo());
			}
		}
		return comparison;
	}
}
