package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;



public class AiClaimPolicy {
	private String ABSOLUTEASSIGNIND;
	private String AGENCYWRITINGCODE;
	private String AGENTWRITINGCODE;
	private String BANKCHEQUE;
	private String BUSINESSLINE;
	private String CLAIMNO;
	private String CONTRACTDT;
	private String EXCLUSION1;
	private String EXCLUSION2;
	private String EXCLUSION3;
	private String IMPAIRMENTCODE1;
	private String IMPAIRMENTCODE2;
	private String IMPAIRMENTCODE3;
	private String MARKETINGCAMPAIGN;
	private String MARKETINGCHANNEL;
	private BigDecimal MODALPREMIUM;
	private String NEXTANNIVERSARYDT;
	private String OCCUPATIONCODE;
	private Integer OCCURRENCE;
	private BigDecimal PABONUSAMT;
	private BigDecimal PABONUSDEDUCTAMT;
	private String PABONUSDT;
	private String PACOVERDT;
	private String PAIDTOCURRDT;
	private String PAIDTODT;
	private String PAYMENTMODE;
	private String PLANBASICCODE;
	private BigDecimal PLANBASICSUMASSURED;
	private String POLICYISSUEDT;
	private String POLICYLAPSEDT;
	private String POLICYNO;
	private String POLICYSTATUS;
	private String POLICYSTATUSPREMIUMHOLIDAY;
	private String POLICYSTATUSREASON;
	private String REINSTATEMENTDT;
	private BigDecimal SUMASSURED;
	private String SUPPRESSIND;
	
	// New Field
	private String AGENTPOLICYIND;
	private String BROKER;
	private String CHEQUENO;
	private String CLAIMHOLDBYIND;
	private String CSPRODUCTCATEGORY;
	private String DEPENDENTNO;
	private String DEPENDENTTYPE;
	private String EGP;
	private String ETIDT;
	private String FULLCREDITIND;
	private String HOLDCLAIMDATE;
	private String HOLDCLAIMIND;
	private String MEMBERID;
	private String PAIDDT;
	private String POLICYENGLISHIND;
	private String POLICYYEARFROMDT;
	private String POLICYYEARTODT;
	private String PRODUCTCODE;
	private String RELATIONSHIP;
	private String RELEASEHOLDCLAIMDATE;
	private String RELEASEHOLDCLAIMIND;
	private String SUBOFFICECODE;
	private String SUBOFFICESTATUS;
	private String TAKEOVERDT;
	private String TAKEOVERSTATUS;
	private String WRITINGGAOFFICECODE;

	
	public String getABSOLUTEASSIGNIND() {
		return ABSOLUTEASSIGNIND;
	}
	public void setABSOLUTEASSIGNIND(String aBSOLUTEASSIGNIND) {
		ABSOLUTEASSIGNIND = aBSOLUTEASSIGNIND;
	}
	public String getAGENCYWRITINGCODE() {
		return AGENCYWRITINGCODE;
	}
	public void setAGENCYWRITINGCODE(String aGENCYWRITINGCODE) {
		AGENCYWRITINGCODE = aGENCYWRITINGCODE;
	}
	public String getAGENTWRITINGCODE() {
		return AGENTWRITINGCODE;
	}
	public void setAGENTWRITINGCODE(String aGENTWRITINGCODE) {
		AGENTWRITINGCODE = aGENTWRITINGCODE;
	}
	public String getBANKCHEQUE() {
		return BANKCHEQUE;
	}
	public void setBANKCHEQUE(String bANKCHEQUE) {
		BANKCHEQUE = bANKCHEQUE;
	}
	public String getBUSINESSLINE() {
		return BUSINESSLINE;
	}
	public void setBUSINESSLINE(String bUSINESSLINE) {
		BUSINESSLINE = bUSINESSLINE;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public String getCONTRACTDT() {
		return CONTRACTDT;
	}
	public void setCONTRACTDT(String cONTRACTDT) {
		CONTRACTDT = cONTRACTDT;
	}
	public String getEXCLUSION1() {
		return EXCLUSION1;
	}
	public void setEXCLUSION1(String eXCLUSION1) {
		EXCLUSION1 = eXCLUSION1;
	}
	public String getEXCLUSION2() {
		return EXCLUSION2;
	}
	public void setEXCLUSION2(String eXCLUSION2) {
		EXCLUSION2 = eXCLUSION2;
	}
	public String getEXCLUSION3() {
		return EXCLUSION3;
	}
	public void setEXCLUSION3(String eXCLUSION3) {
		EXCLUSION3 = eXCLUSION3;
	}
	public String getIMPAIRMENTCODE1() {
		return IMPAIRMENTCODE1;
	}
	public void setIMPAIRMENTCODE1(String iMPAIRMENTCODE1) {
		IMPAIRMENTCODE1 = iMPAIRMENTCODE1;
	}
	public String getIMPAIRMENTCODE2() {
		return IMPAIRMENTCODE2;
	}
	public void setIMPAIRMENTCODE2(String iMPAIRMENTCODE2) {
		IMPAIRMENTCODE2 = iMPAIRMENTCODE2;
	}
	public String getIMPAIRMENTCODE3() {
		return IMPAIRMENTCODE3;
	}
	public void setIMPAIRMENTCODE3(String iMPAIRMENTCODE3) {
		IMPAIRMENTCODE3 = iMPAIRMENTCODE3;
	}
	public String getMARKETINGCAMPAIGN() {
		return MARKETINGCAMPAIGN;
	}
	public void setMARKETINGCAMPAIGN(String mARKETINGCAMPAIGN) {
		MARKETINGCAMPAIGN = mARKETINGCAMPAIGN;
	}
	public String getMARKETINGCHANNEL() {
		return MARKETINGCHANNEL;
	}
	public void setMARKETINGCHANNEL(String mARKETINGCHANNEL) {
		MARKETINGCHANNEL = mARKETINGCHANNEL;
	}
	public BigDecimal getMODALPREMIUM() {
		return MODALPREMIUM;
	}
	public void setMODALPREMIUM(BigDecimal mODALPREMIUM) {
		MODALPREMIUM = mODALPREMIUM;
	}
	public String getNEXTANNIVERSARYDT() {
		return NEXTANNIVERSARYDT;
	}
	public void setNEXTANNIVERSARYDT(String nEXTANNIVERSARYDT) {
		NEXTANNIVERSARYDT = nEXTANNIVERSARYDT;
	}
	public String getOCCUPATIONCODE() {
		return OCCUPATIONCODE;
	}
	public void setOCCUPATIONCODE(String oCCUPATIONCODE) {
		OCCUPATIONCODE = oCCUPATIONCODE;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public BigDecimal getPABONUSAMT() {
		return PABONUSAMT;
	}
	public void setPABONUSAMT(BigDecimal pABONUSAMT) {
		PABONUSAMT = pABONUSAMT;
	}
	public BigDecimal getPABONUSDEDUCTAMT() {
		return PABONUSDEDUCTAMT;
	}
	public void setPABONUSDEDUCTAMT(BigDecimal pABONUSDEDUCTAMT) {
		PABONUSDEDUCTAMT = pABONUSDEDUCTAMT;
	}
	public String getPABONUSDT() {
		return PABONUSDT;
	}
	public void setPABONUSDT(String pABONUSDT) {
		PABONUSDT = pABONUSDT;
	}
	public String getPACOVERDT() {
		return PACOVERDT;
	}
	public void setPACOVERDT(String pACOVERDT) {
		PACOVERDT = pACOVERDT;
	}
	public String getPAIDTOCURRDT() {
		return PAIDTOCURRDT;
	}
	public void setPAIDTOCURRDT(String pAIDTOCURRDT) {
		PAIDTOCURRDT = pAIDTOCURRDT;
	}
	public String getPAIDTODT() {
		return PAIDTODT;
	}
	public void setPAIDTODT(String pAIDTODT) {
		PAIDTODT = pAIDTODT;
	}
	public String getPAYMENTMODE() {
		return PAYMENTMODE;
	}
	public void setPAYMENTMODE(String pAYMENTMODE) {
		PAYMENTMODE = pAYMENTMODE;
	}
	public String getPLANBASICCODE() {
		return PLANBASICCODE;
	}
	public void setPLANBASICCODE(String pLANBASICCODE) {
		PLANBASICCODE = pLANBASICCODE;
	}
	public BigDecimal getPLANBASICSUMASSURED() {
		return PLANBASICSUMASSURED;
	}
	public void setPLANBASICSUMASSURED(BigDecimal pLANBASICSUMASSURED) {
		PLANBASICSUMASSURED = pLANBASICSUMASSURED;
	}
	public String getPOLICYISSUEDT() {
		return POLICYISSUEDT;
	}
	public void setPOLICYISSUEDT(String pOLICYISSUEDT) {
		POLICYISSUEDT = pOLICYISSUEDT;
	}
	public String getPOLICYLAPSEDT() {
		return POLICYLAPSEDT;
	}
	public void setPOLICYLAPSEDT(String pOLICYLAPSEDT) {
		POLICYLAPSEDT = pOLICYLAPSEDT;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	public String getPOLICYSTATUS() {
		return POLICYSTATUS;
	}
	public void setPOLICYSTATUS(String pOLICYSTATUS) {
		POLICYSTATUS = pOLICYSTATUS;
	}
	public String getPOLICYSTATUSPREMIUMHOLIDAY() {
		return POLICYSTATUSPREMIUMHOLIDAY;
	}
	public void setPOLICYSTATUSPREMIUMHOLIDAY(String pOLICYSTATUSPREMIUMHOLIDAY) {
		POLICYSTATUSPREMIUMHOLIDAY = pOLICYSTATUSPREMIUMHOLIDAY;
	}
	public String getPOLICYSTATUSREASON() {
		return POLICYSTATUSREASON;
	}
	public void setPOLICYSTATUSREASON(String pOLICYSTATUSREASON) {
		POLICYSTATUSREASON = pOLICYSTATUSREASON;
	}
	public String getREINSTATEMENTDT() {
		return REINSTATEMENTDT;
	}
	public void setREINSTATEMENTDT(String rEINSTATEMENTDT) {
		REINSTATEMENTDT = rEINSTATEMENTDT;
	}
	public BigDecimal getSUMASSURED() {
		return SUMASSURED;
	}
	public void setSUMASSURED(BigDecimal sUMASSURED) {
		SUMASSURED = sUMASSURED;
	}
	public String getSUPPRESSIND() {
		return SUPPRESSIND;
	}
	public void setSUPPRESSIND(String sUPPRESSIND) {
		SUPPRESSIND = sUPPRESSIND;
	}
	public String getAGENTPOLICYIND() {
		return AGENTPOLICYIND;
	}
	public void setAGENTPOLICYIND(String aGENTPOLICYIND) {
		AGENTPOLICYIND = aGENTPOLICYIND;
	}
	public String getBROKER() {
		return BROKER;
	}
	public void setBROKER(String bROKER) {
		BROKER = bROKER;
	}
	public String getCHEQUENO() {
		return CHEQUENO;
	}
	public void setCHEQUENO(String cHEQUENO) {
		CHEQUENO = cHEQUENO;
	}
	public String getCLAIMHOLDBYIND() {
		return CLAIMHOLDBYIND;
	}
	public void setCLAIMHOLDBYIND(String cLAIMHOLDBYIND) {
		CLAIMHOLDBYIND = cLAIMHOLDBYIND;
	}
	public String getCSPRODUCTCATEGORY() {
		return CSPRODUCTCATEGORY;
	}
	public void setCSPRODUCTCATEGORY(String cSPRODUCTCATEGORY) {
		CSPRODUCTCATEGORY = cSPRODUCTCATEGORY;
	}
	public String getDEPENDENTNO() {
		return DEPENDENTNO;
	}
	public void setDEPENDENTNO(String dEPENDENTNO) {
		DEPENDENTNO = dEPENDENTNO;
	}
	public String getDEPENDENTTYPE() {
		return DEPENDENTTYPE;
	}
	public void setDEPENDENTTYPE(String dEPENDENTTYPE) {
		DEPENDENTTYPE = dEPENDENTTYPE;
	}
	public String getEGP() {
		return EGP;
	}
	public void setEGP(String eGP) {
		EGP = eGP;
	}
	public String getETIDT() {
		return ETIDT;
	}
	public void setETIDT(String eTIDT) {
		ETIDT = eTIDT;
	}
	public String getFULLCREDITIND() {
		return FULLCREDITIND;
	}
	public void setFULLCREDITIND(String fULLCREDITIND) {
		FULLCREDITIND = fULLCREDITIND;
	}
	public String getHOLDCLAIMDATE() {
		return HOLDCLAIMDATE;
	}
	public void setHOLDCLAIMDATE(String hOLDCLAIMDATE) {
		HOLDCLAIMDATE = hOLDCLAIMDATE;
	}
	public String getHOLDCLAIMIND() {
		return HOLDCLAIMIND;
	}
	public void setHOLDCLAIMIND(String hOLDCLAIMIND) {
		HOLDCLAIMIND = hOLDCLAIMIND;
	}
	public String getMEMBERID() {
		return MEMBERID;
	}
	public void setMEMBERID(String mEMBERID) {
		MEMBERID = mEMBERID;
	}
	public String getPAIDDT() {
		return PAIDDT;
	}
	public void setPAIDDT(String pAIDDT) {
		PAIDDT = pAIDDT;
	}
	public String getPOLICYENGLISHIND() {
		return POLICYENGLISHIND;
	}
	public void setPOLICYENGLISHIND(String pOLICYENGLISHIND) {
		POLICYENGLISHIND = pOLICYENGLISHIND;
	}
	public String getPOLICYYEARFROMDT() {
		return POLICYYEARFROMDT;
	}
	public void setPOLICYYEARFROMDT(String pOLICYYEARFROMDT) {
		POLICYYEARFROMDT = pOLICYYEARFROMDT;
	}
	public String getPOLICYYEARTODT() {
		return POLICYYEARTODT;
	}
	public void setPOLICYYEARTODT(String pOLICYYEARTODT) {
		POLICYYEARTODT = pOLICYYEARTODT;
	}
	public String getPRODUCTCODE() {
		return PRODUCTCODE;
	}
	public void setPRODUCTCODE(String pRODUCTCODE) {
		PRODUCTCODE = pRODUCTCODE;
	}
	public String getRELATIONSHIP() {
		return RELATIONSHIP;
	}
	public void setRELATIONSHIP(String rELATIONSHIP) {
		RELATIONSHIP = rELATIONSHIP;
	}
	public String getRELEASEHOLDCLAIMDATE() {
		return RELEASEHOLDCLAIMDATE;
	}
	public void setRELEASEHOLDCLAIMDATE(String rELEASEHOLDCLAIMDATE) {
		RELEASEHOLDCLAIMDATE = rELEASEHOLDCLAIMDATE;
	}
	public String getRELEASEHOLDCLAIMIND() {
		return RELEASEHOLDCLAIMIND;
	}
	public void setRELEASEHOLDCLAIMIND(String rELEASEHOLDCLAIMIND) {
		RELEASEHOLDCLAIMIND = rELEASEHOLDCLAIMIND;
	}
	public String getSUBOFFICECODE() {
		return SUBOFFICECODE;
	}
	public void setSUBOFFICECODE(String sUBOFFICECODE) {
		SUBOFFICECODE = sUBOFFICECODE;
	}
	public String getSUBOFFICESTATUS() {
		return SUBOFFICESTATUS;
	}
	public void setSUBOFFICESTATUS(String sUBOFFICESTATUS) {
		SUBOFFICESTATUS = sUBOFFICESTATUS;
	}
	public String getTAKEOVERDT() {
		return TAKEOVERDT;
	}
	public void setTAKEOVERDT(String tAKEOVERDT) {
		TAKEOVERDT = tAKEOVERDT;
	}
	public String getTAKEOVERSTATUS() {
		return TAKEOVERSTATUS;
	}
	public void setTAKEOVERSTATUS(String tAKEOVERSTATUS) {
		TAKEOVERSTATUS = tAKEOVERSTATUS;
	}
	public String getWRITINGGAOFFICECODE() {
		return WRITINGGAOFFICECODE;
	}
	public void setWRITINGGAOFFICECODE(String wRITINGGAOFFICECODE) {
		WRITINGGAOFFICECODE = wRITINGGAOFFICECODE;
	}
	
}
