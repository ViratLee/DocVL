package com.aia.cmic.model;

public class ClaimDocumentType {
	private String DocTypeItemsId;
	private String DocTypeItemsName;

	public String getDocTypeItemsId() {
		return DocTypeItemsId;
	}

	public void setDocTypeItemsId(String docTypeItemsId) {
		this.DocTypeItemsId = docTypeItemsId;
	}

	public String getDocTypeItemsName() {
		return DocTypeItemsName;
	}

	public void setDocTypeItemsName(String docTypeItemsName) {
		this.DocTypeItemsName = docTypeItemsName;
	}

}
