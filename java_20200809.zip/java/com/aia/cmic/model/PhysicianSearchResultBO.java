package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class PhysicianSearchResultBO {
	Long physicianId;
	String doctorCode;
	String licenseNo;
	String firstName;
	String lastName;
	String specialist;
	String telephone;
	String fax;
	String email;
	String blackListInd;
	String deathInd;

	public String getBlackListInd() {
		return blackListInd;
	}

	public void setBlackListInd(String blackListInd) {
		this.blackListInd = blackListInd;
	}

	List<String> specialty = new ArrayList<String>();

	public List<String> getSpecialty() {
		return specialty;
	}

	public void setSpecialty(List<String> specialty) {
		this.specialty = specialty;
	}

	public Long getPhysicianId() {
		return physicianId;
	}

	public void setPhysicianId(Long physicianId) {
		this.physicianId = physicianId;
	}

	public String getDoctorCode() {
		return doctorCode;
	}

	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSpecialist() {
		return specialist;
	}

	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDeathInd() {
		return deathInd;
	}

	public void setDeathInd(String deathInd) {
		this.deathInd = deathInd;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
