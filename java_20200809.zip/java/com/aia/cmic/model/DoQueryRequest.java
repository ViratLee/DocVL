package com.aia.cmic.model;

import java.util.List;

public class DoQueryRequest {
	private String queryName;
	private List<Lookup> params;
	private Integer rowPerPages;
	private Integer startPage;

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public List<Lookup> getParams() {
		return params;
	}

	public void setParams(List<Lookup> params) {
		this.params = params;
	}

	public Integer getRowPerPages() {
		return rowPerPages;
	}

	public void setRowPerPages(Integer rowPerPages) {
		this.rowPerPages = rowPerPages;
	}

	public Integer getStartPage() {
		return startPage;
	}

	public void setStartPage(Integer startPage) {
		this.startPage = startPage;
	}
}
