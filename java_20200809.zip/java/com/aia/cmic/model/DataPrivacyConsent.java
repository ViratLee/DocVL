package com.aia.cmic.model;

public class DataPrivacyConsent {
	private String consentValue;
	private String consentDate;
	public String getConsentValue() {
		return consentValue;
	}
	public void setConsentValue(String consentValue) {
		this.consentValue = consentValue;
	}
	public String getConsentDate() {
		return consentDate;
	}
	public void setConsentDate(String consentDate) {
		this.consentDate = consentDate;
	}
	
	
}
