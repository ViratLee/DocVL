package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class BenefitReferForm {
	String userType;
	String user;
	String comment;

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
