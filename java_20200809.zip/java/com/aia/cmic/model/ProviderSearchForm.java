package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class ProviderSearchForm {
	private String providerCode;
	private String providerName;
	private String providerType;
	private String providerTypeSector;
	private String province;
	private String region;
	private String contract;
	private String blackList;
	private int page = 1;
	private int pageSize = 10;

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getProviderTypeSector() {
		return providerTypeSector;
	}

	public void setProviderTypeSector(String providerTypeSector) {
		this.providerTypeSector = providerTypeSector;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getBlackList() {
		return blackList;
	}

	public void setBlackList(String blackList) {
		this.blackList = blackList;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
