package com.aia.cmic.model;

public class AiClaimCommentHistory {

	private String CLAIMNO;
	private String COMMENTDETAIL;
	private String COMMENTYPE;
	private Integer OCCURRENCE;
	
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public String getCOMMENTDETAIL() {
		return COMMENTDETAIL;
	}
	public void setCOMMENTDETAIL(String cOMMENTDETAIL) {
		COMMENTDETAIL = cOMMENTDETAIL;
	}
	public String getCOMMENTYPE() {
		return COMMENTYPE;
	}
	public void setCOMMENTYPE(String cOMMENTYPE) {
		COMMENTYPE = cOMMENTYPE;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}

	
}
