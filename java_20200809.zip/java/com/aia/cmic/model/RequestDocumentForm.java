package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RequestDocumentForm {

	private static final Logger LOG = LoggerFactory.getLogger(RequestDocumentForm.class);

	private long caseId;
	private String reqHospitalName;
	private String reqFaxNo;
	private String reqCustomerName;
	private String reqPolicyNo;
	private String reqCertNo;
	private List<String> reqDocument;

	public final long getCaseId() {
		return caseId;
	}

	public final void setCaseId(long caseId) {
		this.caseId = caseId;
	}

	public final String getReqHospitalName() {
		return reqHospitalName;
	}

	public final void setReqHospitalName(String reqHospitalName) {
		this.reqHospitalName = reqHospitalName;
	}

	public final String getReqFaxNo() {
		return reqFaxNo;
	}

	public final void setReqFaxNo(String reqFaxNo) {
		this.reqFaxNo = reqFaxNo;
	}

	public final String getReqCustomerName() {
		return reqCustomerName;
	}

	public final void setReqCustomerName(String reqCustomerName) {
		this.reqCustomerName = reqCustomerName;
	}

	public final String getReqPolicyNo() {
		return reqPolicyNo;
	}

	public final void setReqPolicyNo(String reqPolicyNo) {
		this.reqPolicyNo = reqPolicyNo;
	}

	public final List<String> getReqDocument() {
		return reqDocument;
	}

	public final void setReqDocument(List<String> reqDocument) {
		this.reqDocument = reqDocument;
	}

	public String getReqCertNo() {
		return reqCertNo;
	}

	public void setReqCertNo(String reqCertNo) {
		this.reqCertNo = reqCertNo;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
