package com.aia.cmic.model;

public class ReceiptSearchFrom {

	private String policyNo;
	private String certNo;
	private String memberId;
	private String dependentCode;
	private String insuredFirstName;
	private String insuredLastName;
	private String dateFrom;
	private String dateTo;
	private String location;
	private String claimNum;
	private String returnStatus;
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getDependentCode() {
		return dependentCode;
	}
	public void setDependentCode(String dependentCode) {
		this.dependentCode = dependentCode;
	}
	public String getInsuredFirstName() {
		return insuredFirstName;
	}
	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}
	public String getInsuredLastName() {
		return insuredLastName;
	}
	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getClaimNum() {
		return claimNum;
	}
	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}
	public String getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}
	
}
