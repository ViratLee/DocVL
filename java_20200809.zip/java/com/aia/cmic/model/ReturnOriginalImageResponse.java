package com.aia.cmic.model;

import java.util.List;

public class ReturnOriginalImageResponse {
		private List<ReturnOriginalImageTO> resultSets;

		public List<ReturnOriginalImageTO> getResultSets() {
			return resultSets;
		}
		public void setResultSets(List<ReturnOriginalImageTO> resultSets) {
			this.resultSets = resultSets;
		}
}
