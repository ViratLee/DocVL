package com.aia.cmic.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiOrderItem {

	private Long ediOrderItemId;
	private String claimNo;
	private Integer occurrence;
	@JsonProperty("itemId")
	private String itemId;
	@JsonProperty("itemName")
	private String itemName;
	@JsonProperty("itemLocalBillingCode")
	private String itemLocalBillingCode;
	@JsonProperty("simbBillingCode")
	private String itemSimbBillingCode;
	@JsonProperty("itemAmount")
	private BigDecimal itemAmount;
	@JsonProperty("initial")
	private BigDecimal itemInitial;
	@JsonProperty("discount")
	private BigDecimal discount;
	@JsonProperty("netAmount")
	private String netAmount;

	public Long getEdiOrderItemId() {
		return ediOrderItemId;
	}

	public void setEdiOrderItemId(Long ediOrderItemId) {
		this.ediOrderItemId = ediOrderItemId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemLocalBillingCode() {
		return itemLocalBillingCode;
	}

	public void setItemLocalBillingCode(String itemLocalBillingCode) {
		this.itemLocalBillingCode = itemLocalBillingCode;
	}

	public String getItemSimbBillingCode() {
		return itemSimbBillingCode;
	}

	public void setItemSimbBillingCode(String itemSimbBillingCode) {
		this.itemSimbBillingCode = itemSimbBillingCode;
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public BigDecimal getItemInitial() {
		return itemInitial;
	}

	public void setItemInitial(BigDecimal itemInitial) {
		this.itemInitial = itemInitial;
	}

	public BigDecimal getDiscount() {
		return discount;
	}

	public void setDiscount(BigDecimal discount) {
		this.discount = discount;
	}

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

}
