package com.aia.cmic.model;

public class CaseStatus {
	private Long caseId;
	private Integer state;
	private String activity;
	private Integer lockType;
	private String owner;
	private Boolean caseValidated;
	private String hcStatus;

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Integer getLockType() {
		return lockType;
	}

	public void setLockType(Integer lockType) {
		this.lockType = lockType;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Boolean getCaseValidated() {
		return caseValidated;
	}

	public void setCaseValidated(Boolean caseValidated) {
		this.caseValidated = caseValidated;
	}

	public String getHcStatus() {
		return hcStatus;
	}

	public void setHcStatus(String hcStatus) {
		this.hcStatus = hcStatus;
	}
}
