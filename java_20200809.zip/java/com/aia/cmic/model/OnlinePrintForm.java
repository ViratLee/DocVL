package com.aia.cmic.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class OnlinePrintForm {
	@XmlElement(name = "KEY")
	private OnlinePrintKey key;
	@XmlElement(name = "CONTENT")
	private OnlinePrintContent content;

	public OnlinePrintContent getContent() {
		return content;
	}

	public void setContent(OnlinePrintContent content) {
		this.content = content;
	}

	public OnlinePrintKey getKey() {
		return key;
	}

	public void setKey(OnlinePrintKey key) {
		this.key = key;
	}

}
