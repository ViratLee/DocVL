package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class BenefitLimit {

	String claimNo;
	Integer occurrence;
	String benefitCode;
	BigDecimal amount;
	Date effectDT;
	Date policyYearFromDt;
	Date policyYearToDt;
	Integer reimbursedDay;
	Boolean samePolicyYear;
	

	//String shareInd;
	public BenefitLimit() {
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public Date getEffectDT() {
		return effectDT;
	}

	public void setEffectDT(Date effectDT) {
		this.effectDT = effectDT;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public Integer getReimbursedDay() {
		return reimbursedDay;
	}

	public void setReimbursedDay(Integer reimbursedDay) {
		this.reimbursedDay = reimbursedDay;
	}

	public Boolean getSamePolicyYear() {
		return samePolicyYear;
	}

	public void setSamePolicyYear(Boolean samePolicyYear) {
		this.samePolicyYear = samePolicyYear;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
