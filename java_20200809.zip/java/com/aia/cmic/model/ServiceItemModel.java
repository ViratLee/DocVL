package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.ServiceItem;

public class ServiceItemModel {
	private Long serviceItemId;
	private String serviceCatId;
	private String serviceItemDesc;
	private String serviceItemDescThai;
	private String parentServiceItemiId;

	public ServiceItemModel(ServiceItem serviceItem) {
		this.serviceItemId = serviceItem.getServiceItemId();
		this.serviceCatId = serviceItem.getServiceCatId();
		this.serviceItemDesc = serviceItem.getServiceItemDesc();
		this.serviceItemDescThai = serviceItem.getServiceItemDescThai();
		this.parentServiceItemiId = serviceItem.getParentServiceItemiId();
	}

	public Long getServiceItemId() {
		return serviceItemId;
	}

	public void setServiceItemId(Long serviceItemId) {
		this.serviceItemId = serviceItemId;
	}

	public String getServiceCatId() {
		return serviceCatId;
	}

	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	public String getServiceItemDesc() {
		return serviceItemDesc;
	}

	public void setServiceItemDesc(String serviceItemDesc) {
		this.serviceItemDesc = serviceItemDesc;
	}

	public String getServiceItemDescThai() {
		return serviceItemDescThai;
	}

	public void setServiceItemDescThai(String serviceItemDescThai) {
		this.serviceItemDescThai = serviceItemDescThai;
	}

	public String getParentServiceItemiId() {
		return parentServiceItemiId;
	}

	public void setParentServiceItemiId(String parentServiceItemiId) {
		this.parentServiceItemiId = parentServiceItemiId;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}