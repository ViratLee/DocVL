package com.aia.cmic.model;

public class PlanSetupBO {
	private Long planId;
	private String uid;
	private Boolean clone;
	private Boolean success;

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Boolean getClone() {
		return clone;
	}

	public void setClone(Boolean clone) {
		this.clone = clone;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

}
