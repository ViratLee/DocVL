package com.aia.cmic.model;

public class Account {

	Long accountId;
	String accountingType;
	String accountingDesc;
	String accountingActionCode;
	String businessLine;
	String accountingCategory;
	String productType;
	String policyPrefix;
	String accountCode;

	/**
	 * @return the accountId
	 */
	public Long getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	/**
	 * @return the accountingType
	 */
	public String getAccountingType() {
		return accountingType;
	}

	/**
	 * @param accountingType the accountingType to set
	 */
	public void setAccountingType(String accountingType) {
		this.accountingType = accountingType;
	}

	/**
	 * @return the accountingDesc
	 */
	public String getAccountingDesc() {
		return accountingDesc;
	}

	/**
	 * @param accountingDesc the accountingDesc to set
	 */
	public void setAccountingDesc(String accountingDesc) {
		this.accountingDesc = accountingDesc;
	}

	/**
	 * @return the accountingActionCode
	 */
	public String getAccountingActionCode() {
		return accountingActionCode;
	}

	/**
	 * @param accountingActionCode the accountingActionCode to set
	 */
	public void setAccountingActionCode(String accountingActionCode) {
		this.accountingActionCode = accountingActionCode;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 * @return the accountingCategory
	 */
	public String getAccountingCategory() {
		return accountingCategory;
	}

	/**
	 * @param accountingCategory the accountingCategory to set
	 */
	public void setAccountingCategory(String accountingCategory) {
		this.accountingCategory = accountingCategory;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the policyPrefix
	 */
	public String getPolicyPrefix() {
		return policyPrefix;
	}

	/**
	 * @param policyPrefix the policyPrefix to set
	 */
	public void setPolicyPrefix(String policyPrefix) {
		this.policyPrefix = policyPrefix;
	}

	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}

	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	/**
	 */
	public Account() {
	}

}
