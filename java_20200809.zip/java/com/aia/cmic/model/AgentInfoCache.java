package com.aia.cmic.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aia.cmic.repository.rest.response.party.Individual;
import com.aia.cmic.repository.rest.response.party.Organization;
import com.aia.cmic.repository.rest.response.producer.AmsAgencyTab;
import com.aia.cmic.repository.rest.response.producer.Producer;

public class AgentInfoCache {

	Map<String, List<Producer>> hmLstProducerByPartyId = new HashMap<String, List<Producer>>(); //A0030
	Map<String, List<Individual>> hmLstIndividualByPartyId = new HashMap<String, List<Individual>>(); //P0030
	Map<String, List<Organization>> hmLstOrganizationByAgencyCode = new HashMap<String, List<Organization>>();//P0040
	Map<String, List<Producer>> hmLstProducerByProducerId = new HashMap<String, List<Producer>>();// A1010
	Map<String, List<Producer>> hmLstProducerByrelatedProducerId = new HashMap<String, List<Producer>>(); //A0010
	Map<String, List<AmsAgencyTab>> hmLstAmsAgencyByAgencyCode = new HashMap<String, List<AmsAgencyTab>>();

	public Map<String, List<Producer>> getHmLstProducerByPartyId() {
		return hmLstProducerByPartyId;
	}

	public void setHmLstProducerByPartyId(Map<String, List<Producer>> hmLstProducerByPartyId) {
		this.hmLstProducerByPartyId = hmLstProducerByPartyId;
	}

	public Map<String, List<Individual>> getHmLstIndividualByPartyId() {
		return hmLstIndividualByPartyId;
	}

	public void setHmLstIndividualByPartyId(Map<String, List<Individual>> hmLstIndividualByPartyId) {
		this.hmLstIndividualByPartyId = hmLstIndividualByPartyId;
	}

	public Map<String, List<Organization>> getHmLstOrganizationByAgencyCode() {
		return hmLstOrganizationByAgencyCode;
	}

	public void setHmLstOrganizationByAgencyCode(Map<String, List<Organization>> hmLstOrganizationByAgencyCode) {
		this.hmLstOrganizationByAgencyCode = hmLstOrganizationByAgencyCode;
	}

	public Map<String, List<Producer>> getHmLstProducerByProducerId() {
		return hmLstProducerByProducerId;
	}

	public void setHmLstProducerByProducerId(Map<String, List<Producer>> hmLstProducerByProducerId) {
		this.hmLstProducerByProducerId = hmLstProducerByProducerId;
	}

	public Map<String, List<Producer>> getHmLstProducerByrelatedProducerId() {
		return hmLstProducerByrelatedProducerId;
	}

	public void setHmLstProducerByrelatedProducerId(Map<String, List<Producer>> hmLstProducerByrelatedProducerId) {
		this.hmLstProducerByrelatedProducerId = hmLstProducerByrelatedProducerId;
	}

	public Map<String, List<AmsAgencyTab>> getHmLstAmsAgencyByAgencyCode() {
		return hmLstAmsAgencyByAgencyCode;
	}

	public void setHmLstAmsAgencyByAgencyCode(Map<String, List<AmsAgencyTab>> hmLstAmsAgencyByAgencyCode) {
		this.hmLstAmsAgencyByAgencyCode = hmLstAmsAgencyByAgencyCode;
	}

}
