package com.aia.cmic.model;

import org.springframework.beans.BeanUtils;

public class CMiCPartySnapshot extends PartySnapshot {
	private String age;

	public CMiCPartySnapshot(PartySnapshot partySnapshot) {
		BeanUtils.copyProperties(partySnapshot, this);
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
}
