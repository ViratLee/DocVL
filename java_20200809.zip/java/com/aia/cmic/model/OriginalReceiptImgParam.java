package com.aia.cmic.model;

public class OriginalReceiptImgParam {
	private Integer[] caseIdList;

	public Integer[] getCaseIdList() {
		return caseIdList;
	}

	public void setCaseIdList(Integer[] caseIdList) {
		this.caseIdList = caseIdList;
	}
	
}
