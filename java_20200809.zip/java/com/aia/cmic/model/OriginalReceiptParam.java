package com.aia.cmic.model;

public class OriginalReceiptParam {

	private String policyNo;
	private String certNo;
	private String location;
	private String claimNum;
	private String memberId;
	private String returnStatus;
	private String dateFrom;
	private String dateTo;
	private String dependentCode;
	private String insuredFirstname;
	private String insuredLastname;
	private Integer rowPerPages;
	private Integer startPage;
	private String insureType;
	private String neverReturnOriginalFlag;
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getClaimNum() {
		return claimNum;
	}
	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getDependentCode() {
		return dependentCode;
	}
	public void setDependentCode(String dependentCode) {
		this.dependentCode = dependentCode;
	}
	public String getInsuredFirstname() {
		return insuredFirstname;
	}
	public void setInsuredFirstname(String insuredFirstname) {
		this.insuredFirstname = insuredFirstname;
	}
	public String getInsuredLastname() {
		return insuredLastname;
	}
	public void setInsuredLastname(String insuredLastname) {
		this.insuredLastname = insuredLastname;
	}
	public Integer getRowPerPages() {
		return rowPerPages;
	}
	public void setRowPerPages(Integer rowPerPages) {
		this.rowPerPages = rowPerPages;
	}
	public Integer getStartPage() {
		return startPage;
	}
	public void setStartPage(Integer startPage) {
		this.startPage = startPage;
	}
	public String getInsureType() {
		return insureType;
	}
	public void setInsureType(String insureType) {
		this.insureType = insureType;
	}
	public String getNeverReturnOriginalFlag() {
		return neverReturnOriginalFlag;
	}
	public void setNeverReturnOriginalFlag(String neverReturnOriginalFlag) {
		this.neverReturnOriginalFlag = neverReturnOriginalFlag;
	}
	

	
}
