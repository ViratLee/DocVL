package com.aia.cmic.model;

import java.math.BigDecimal;

public class ClaimPolicyBenefit {

	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String productCode;
	String benefitCode;
	String decision;
	BigDecimal copaymentPercent;
	BigDecimal deductAmount;
	String isFullCredit;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getBenefitCode() {
		return benefitCode;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public BigDecimal getCopaymentPercent() {
		return copaymentPercent;
	}

	public void setCopaymentPercent(BigDecimal copaymentPercent) {
		this.copaymentPercent = copaymentPercent;
	}

	public BigDecimal getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(BigDecimal deductAmount) {
		this.deductAmount = deductAmount;
	}

	public String getIsFullCredit() {
		return isFullCredit;
	}

	public void setIsFullCredit(String isFullCredit) {
		this.isFullCredit = isFullCredit;
	}

}
