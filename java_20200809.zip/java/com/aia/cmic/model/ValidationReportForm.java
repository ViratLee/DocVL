package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

public class ValidationReportForm {
	private List<ValidationReportModel> claimRulesLogs = new ArrayList<ValidationReportModel>();

	public List<ValidationReportModel> getClaimRulesLogs() {
		return claimRulesLogs;
	}

	public void setClaimRulesLogs(List<ValidationReportModel> claimRulesLogs) {
		this.claimRulesLogs = claimRulesLogs;
	}
}
