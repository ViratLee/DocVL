package com.aia.cmic.model;

import java.text.SimpleDateFormat;

import com.aia.cmic.entity.ClaimPaymentDetail;
import com.aia.cmic.util.ClaimCalculationEnum.HSXBenefitDeductSequence;

/**
 * Use for HSX Reduced allocation
 * @author Ronald
 *
 */
public class HSXReduced implements Comparable<HSXReduced> {

	public HSXReduced(ClaimPaymentDetail cpd, ClaimPolicyPlan claimPolicyPlan2,HSXBenefitDeductSequence hsxBenefitDeductSequence) {
		this.claimPaymentDetail = cpd;
		this.claimPolicyPlan = claimPolicyPlan2;
		this.setBenefitSequence(hsxBenefitDeductSequence) ;
	}

	private ClaimPaymentDetail claimPaymentDetail;
	private ClaimPolicyPlan claimPolicyPlan;
	private HSXBenefitDeductSequence benefitSequence ;

	/**
	 * @return the claimPaymentDetail
	 */
	public ClaimPaymentDetail getClaimPaymentDetail() {
		return claimPaymentDetail;
	}

	/**
	 * @param claimPaymentDetail the claimPaymentDetail to set
	 */
	public void setClaimPaymentDetail(ClaimPaymentDetail claimPaymentDetail) {
		this.claimPaymentDetail = claimPaymentDetail;
	}

	/**
	 * @return the claimPolicy
	 */
	public ClaimPolicyPlan getClaimPolicyPlan() {
		return claimPolicyPlan;
	}

	/**
	 * @param claimPolicyPlan the claimPolicy to set
	 */
	public void setClaimPolicyPlan(ClaimPolicyPlan claimPolicyPlan) {
		this.claimPolicyPlan = claimPolicyPlan;
	}

	@Override
	public int compareTo(HSXReduced that) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		// ascending plan issue date
		int comparison =sdf.format(this.getClaimPolicyPlan().getPlanIssueDt()).compareTo(sdf.format(that.getClaimPolicyPlan().getPlanIssueDt())) * -1;
		if (comparison == 0) {
			Integer this_sequence = this.getBenefitSequence() != null ? this.getBenefitSequence().getDeductSequence() : 999;
			Integer that_sequence = that.getBenefitSequence() != null ? that.getBenefitSequence().getDeductSequence() : 999 ;
			comparison = this_sequence.compareTo(that_sequence);
			if (comparison == 0) {
				comparison = this.getClaimPolicyPlan().getPolicyNo().compareTo(that.getClaimPolicyPlan().getPolicyNo());
			}
		}
		return comparison;
	}

	public HSXBenefitDeductSequence getBenefitSequence() {
		return benefitSequence;
	}

	public void setBenefitSequence(HSXBenefitDeductSequence benefitSequence) {
		this.benefitSequence = benefitSequence;
	}
}
