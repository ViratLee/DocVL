package com.aia.cmic.model;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ToStringBuilder;

public class HNWBenefitCode {
	Long benefitItemId;
	Lookup benefitValueKey;
	private Integer call;
	private Integer day;
	private BigDecimal amount;
	
	public Long getBenefitItemId() {
		return benefitItemId;
	}
	public void setBenefitItemId(Long benefitItemId) {
		this.benefitItemId = benefitItemId;
	}
	public Lookup getBenefitValueKey() {
		return benefitValueKey;
	}
	public void setBenefitValueKey(Lookup benefitValueKey) {
		this.benefitValueKey = benefitValueKey;
	}

	public Integer getCall() {
		return call;
	}
	public Integer getDay() {
		return day;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	
	public void setCall(Integer call) {
		this.call = call;
	}
	public void setDay(Integer day) {
		this.day = day;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
