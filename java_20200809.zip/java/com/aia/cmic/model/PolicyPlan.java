package com.aia.cmic.model;

import java.util.ArrayList;
import java.util.List;

import com.aia.schemas.adam.v2_5.agreement.v1.PolicyProductPremType;
import com.aia.schemas.retrievecontractinformationresponse.v1.PolicyProductPlanRelnType;

public class PolicyPlan {
	private String BenefitPlanCd;
	private String planDesc;
	private String benefitPlanLongDesc;
	private List<PolicyProductPrem> policyProductPrem;

	public PolicyPlan() {

	}

	public PolicyPlan(PolicyProductPlanRelnType obj) {
		this.BenefitPlanCd = obj.getBenefitPlanCd();
		this.planDesc = obj.getPlanDesc();
		this.benefitPlanLongDesc = obj.getBenefitPlanLongDesc();
		List<PolicyProductPrem> tmp = new ArrayList<>();
		PolicyProductPrem prem;
		if (obj.getPolicyProductPrem().size() > 0) {
			for (PolicyProductPremType premType : obj.getPolicyProductPrem()) {
				prem = new PolicyProductPrem(premType);
				tmp.add(prem);
			}
		}
		this.policyProductPrem = tmp;
	}

	public String getBenefitPlanCd() {
		return BenefitPlanCd;
	}

	public void setBenefitPlanCd(String benefitPlanCd) {
		BenefitPlanCd = benefitPlanCd;
	}

	public String getPlanDesc() {
		return planDesc;
	}

	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}

	public String getBenefitPlanLongDesc() {
		return benefitPlanLongDesc;
	}

	public void setBenefitPlanLongDesc(String benefitPlanLongDesc) {
		this.benefitPlanLongDesc = benefitPlanLongDesc;
	}

	public List<PolicyProductPrem> getPolicyProductPrem() {
		return policyProductPrem;
	}

	public void setPolicyProductPrem(List<PolicyProductPrem> policyProductPrem) {
		this.policyProductPrem = policyProductPrem;
	}

}
