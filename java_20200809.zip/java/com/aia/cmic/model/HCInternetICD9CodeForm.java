package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class HCInternetICD9CodeForm {
	private List<ICD9CodeModel> icd9Code;
	private String returnCode;
	private String returnMessage;

	public List<ICD9CodeModel> getIcd9Code() {
		return icd9Code;
	}

	public void setIcd9Code(List<ICD9CodeModel> icd9Code) {
		this.icd9Code = icd9Code;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}