package com.aia.cmic.model;


public class DirectCreditSearchCriteria {
	private String companyId;
	private String providerCode;
	private String settleStartDate;
	private String settleEndDate;
	private String transferStartDate;
	private String transferEndDate;
	private boolean isCS;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getSettleStartDate() {
		return settleStartDate;
	}

	public void setSettleStartDate(String settleStartDate) {
		this.settleStartDate = settleStartDate;
	}

	public String getSettleEndDate() {
		return settleEndDate;
	}

	public void setSettleEndDate(String settleEndDate) {
		this.settleEndDate = settleEndDate;
	}

	public String getTransferStartDate() {
		return transferStartDate;
	}

	public void setTransferStartDate(String transferStartDate) {
		this.transferStartDate = transferStartDate;
	}

	public String getTransferEndDate() {
		return transferEndDate;
	}

	public void setTransferEndDate(String transferEndDate) {
		this.transferEndDate = transferEndDate;
	}

	public boolean isCS() {
		return isCS;
	}

	public void setIsCS(boolean isCS) {
		this.isCS = isCS;
	}

}