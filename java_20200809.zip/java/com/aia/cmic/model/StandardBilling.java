package com.aia.cmic.model;

import java.io.Serializable;

/**
 */

public class StandardBilling implements Serializable {

	Long standardBillingId;
	String serviceCatId;
	String businessLine;
	String companyId;
	String icd10Category;
	String procedureCategory;
	String lengthOfStayCategory;
	String policyNo;
	Long planId;
	String treatmentType;
	String productCode;
	String benefitCode;
	String rolloverBenefitCode1;
	String rolloverBenefitCode2;
	String rolloverBenefitCode3;
	String rolloverBenefitCode4;
	String rolloverBenefitCode5;
	String followUpInd;
	String sheetName;
	String cellRef;

	String key;

	/**
	 */
	public void setStandardBillingId(Long standardBillingId) {
		this.standardBillingId = standardBillingId;
	}

	/**
	 */
	public Long getStandardBillingId() {
		return this.standardBillingId;
	}

	/**
	 */
	public void setServiceCatId(String serviceCatId) {
		this.serviceCatId = serviceCatId;
	}

	/**
	 */
	public String getServiceCatId() {
		return this.serviceCatId;
	}

	/**
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 */
	public String getBusinessLine() {
		return this.businessLine;
	}

	/**
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 */
	public String getCompanyId() {
		return this.companyId;
	}

	/**
	 */
	public void setIcd10Category(String icd10Category) {
		this.icd10Category = icd10Category;
	}

	/**
	 */
	public String getIcd10Category() {
		return this.icd10Category;
	}

	/**
	 */
	public void setProcedureCategory(String procedureCategory) {
		this.procedureCategory = procedureCategory;
	}

	/**
	 */
	public String getProcedureCategory() {
		return this.procedureCategory;
	}

	/**
	 */
	public void setLengthOfStayCategory(String lengthOfStayCategory) {
		this.lengthOfStayCategory = lengthOfStayCategory;
	}

	/**
	 */
	public String getLengthOfStayCategory() {
		return this.lengthOfStayCategory;
	}

	/**
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 */
	public String getPolicyNo() {
		return this.policyNo;
	}

	/**
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 */
	public Long getPlanId() {
		return this.planId;
	}

	/**
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 */
	public String getProductCode() {
		return this.productCode;
	}

	/**
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 */
	public String getBenefitCode() {
		return this.benefitCode;
	}

	/**
	 */
	public void setRolloverBenefitCode1(String rolloverBenefitCode1) {
		this.rolloverBenefitCode1 = rolloverBenefitCode1;
	}

	/**
	 */
	public String getRolloverBenefitCode1() {
		return this.rolloverBenefitCode1;
	}

	/**
	 */
	public void setRolloverBenefitCode2(String rolloverBenefitCode2) {
		this.rolloverBenefitCode2 = rolloverBenefitCode2;
	}

	/**
	 */
	public String getRolloverBenefitCode2() {
		return this.rolloverBenefitCode2;
	}

	/**
	 */
	public void setRolloverBenefitCode3(String rolloverBenefitCode3) {
		this.rolloverBenefitCode3 = rolloverBenefitCode3;
	}

	/**
	 */
	public String getRolloverBenefitCode3() {
		return this.rolloverBenefitCode3;
	}

	/**
	 */
	public void setRolloverBenefitCode4(String rolloverBenefitCode4) {
		this.rolloverBenefitCode4 = rolloverBenefitCode4;
	}

	/**
	 */
	public String getRolloverBenefitCode4() {
		return this.rolloverBenefitCode4;
	}

	/**
	 */
	public void setRolloverBenefitCode5(String rolloverBenefitCode5) {
		this.rolloverBenefitCode5 = rolloverBenefitCode5;
	}

	/**
	 */
	public String getRolloverBenefitCode5() {
		return this.rolloverBenefitCode5;
	}

	/**
	 * @return the followUpInd
	 */
	public String getFollowUpInd() {
		return followUpInd;
	}

	/**
	 * @param followUpInd the followUpInd to set
	 */
	public void setFollowUpInd(String followUpInd) {
		this.followUpInd = followUpInd;
	}

	/**
	 */
	public StandardBilling() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(StandardBilling that) {
		setStandardBillingId(that.getStandardBillingId());
		setServiceCatId(that.getServiceCatId());
		setBusinessLine(that.getBusinessLine());
		setCompanyId(that.getCompanyId());
		setIcd10Category(that.getIcd10Category());
		setProcedureCategory(that.getProcedureCategory());
		setLengthOfStayCategory(that.getLengthOfStayCategory());
		setPolicyNo(that.getPolicyNo());
		setPlanId(that.getPlanId());
		setTreatmentType(that.getTreatmentType());
		setProductCode(that.getProductCode());
		setBenefitCode(that.getBenefitCode());
		setRolloverBenefitCode1(that.getRolloverBenefitCode1());
		setRolloverBenefitCode2(that.getRolloverBenefitCode2());
		setRolloverBenefitCode3(that.getRolloverBenefitCode3());
		setRolloverBenefitCode4(that.getRolloverBenefitCode4());
		setRolloverBenefitCode5(that.getRolloverBenefitCode5());
		setFollowUpInd(that.getFollowUpInd());
		setSheetName(that.getSheetName());
		setCellRef(that.getCellRef());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("standardBillingId=[").append(standardBillingId).append("] ");
		buffer.append("serviceCatId=[").append(serviceCatId).append("] ");
		buffer.append("businessLine=[").append(businessLine).append("] ");
		buffer.append("companyId=[").append(companyId).append("] ");
		buffer.append("icd10Category=[").append(icd10Category).append("] ");
		buffer.append("procedureCategory=[").append(procedureCategory).append("] ");
		buffer.append("lengthOfStayCategory=[").append(lengthOfStayCategory).append("] ");
		buffer.append("policyNo=[").append(policyNo).append("] ");
		buffer.append("productCode=[").append(productCode).append("] ");
		buffer.append("benefitCode=[").append(benefitCode).append("] ");
		buffer.append("rolloverBenefitCode1=[").append(rolloverBenefitCode1).append("] ");
		buffer.append("rolloverBenefitCode2=[").append(rolloverBenefitCode2).append("] ");
		buffer.append("rolloverBenefitCode3=[").append(rolloverBenefitCode3).append("] ");
		buffer.append("rolloverBenefitCode4=[").append(rolloverBenefitCode4).append("] ");
		buffer.append("rolloverBenefitCode5=[").append(rolloverBenefitCode5).append("] ");
		buffer.append("followUpInd=[").append(followUpInd).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((standardBillingId == null) ? 0 : standardBillingId.hashCode());
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (!(obj instanceof StandardBilling)) {
			return false;
		}
		StandardBilling equalCheck = (StandardBilling) obj;
		if ((standardBillingId == null && equalCheck.standardBillingId != null) || (standardBillingId != null && equalCheck.standardBillingId == null)) {
			return false;
		}
		if (standardBillingId != null && !standardBillingId.equals(equalCheck.standardBillingId)) {
			return false;
		}
		return true;
	}

	/**
	 * @return the treatmentType
	 */
	public String getTreatmentType() {
		return treatmentType;
	}

	/**
	 * @param treatmentType the treatmentType to set
	 */
	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getCellRef() {
		return cellRef;
	}

	public void setCellRef(String cellRef) {
		this.cellRef = cellRef;
	}

	public String getKey() {
		if (key == null) {
			StringBuilder text = new StringBuilder(90);
			text.append(serviceCatId);
			text.append('_');
			text.append(icd10Category);
			text.append('_');
			text.append(lengthOfStayCategory);
			text.append('_');
			text.append(procedureCategory);
			text.append('_');
			text.append(treatmentType);
			text.append('_');
			text.append(productCode);
			key = text.toString();
		}
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}