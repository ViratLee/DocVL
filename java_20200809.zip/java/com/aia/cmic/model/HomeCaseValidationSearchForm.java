package com.aia.cmic.model;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.restservices.model.MyQueueParam;
import com.aia.cmic.util.FormatUtil;

public class HomeCaseValidationSearchForm extends SearchForm {
	private String policyNo;
	private String channel;
	private String providerCode;
	private String location;
	private String category;
	private String insuredFirstName;
	private String insuredLastName;
	private String claimNo;
	private String certNo;
	private String risk;
	private boolean unidentified;
	private String nationalId;
	private String workType;
	private String memberId;
	private BigDecimal caseId;
	private String partyId;
	private String scanBatchId;

	public static MyQueueParam convertToMyQueueParam(HomeCaseValidationSearchForm req) {
		MyQueueParam myQueueParam = new MyQueueParam();
		myQueueParam.setCategory(FormatUtil.convertNull(req.getCategory()));
		myQueueParam.setPolicyNo(FormatUtil.convertNull(req.getPolicyNo()));
		myQueueParam.setProviderCode(FormatUtil.convertNull(req.getProviderCode()));
		myQueueParam.setLocation(FormatUtil.convertNull(req.getLocation()));
		myQueueParam.setInsuredName(FormatUtil.convertNull(req.getInsuredFirstName()));
		myQueueParam.setInsuredLastName(FormatUtil.convertNull(req.getInsuredLastName()));
		myQueueParam.setChannel(FormatUtil.convertNull(req.getChannel()));
		myQueueParam.setClaimNo(FormatUtil.convertNull(req.getClaimNo()));
		myQueueParam.setCertNo(FormatUtil.convertNull(req.getCertNo()));
		myQueueParam.setRisk(FormatUtil.convertNull(req.getRisk()));
		myQueueParam.setUnidentified(req.isUnidentified());
		myQueueParam.setMemberId(FormatUtil.convertNull(req.getMemberId()));
		myQueueParam.setNationalId(FormatUtil.convertNull(req.getNationalId()));
		myQueueParam.setCaseId(req.getCaseId());
		myQueueParam.setWorkType(FormatUtil.convertNull(req.getWorkType()));
		myQueueParam.setPartyId("".equals(FormatUtil.convertNull(req.getPartyId())) ? null : FormatUtil.convertBigDecimal(req.getPartyId()));
		myQueueParam.setScanBatchId(FormatUtil.convertNull(req.getScanBatchId()));
		return myQueueParam;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getInsuredFirstName() {
		return insuredFirstName;
	}

	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	public String getInsuredLastName() {
		return insuredLastName;
	}

	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getRisk() {
		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;
	}

	public boolean isUnidentified() {
		return unidentified;
	}

	public void setUnidentified(boolean unidentified) {
		this.unidentified = unidentified;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getWorkType() {
		return workType;
	}

	public void setWorkType(String workType) {
		this.workType = workType;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public BigDecimal getCaseId() {
		return caseId;
	}

	public void setCaseId(BigDecimal caseId) {
		this.caseId = caseId;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getScanBatchId() {
		return scanBatchId;
	}

	public void setScanBatchId(String scanBatchId) {
		this.scanBatchId = scanBatchId;
	}

}
