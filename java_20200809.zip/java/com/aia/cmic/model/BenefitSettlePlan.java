package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitSettlePlan {
	@XmlElement(name = "benefitSettleBenefitDetailList")
	List<BenefitSettleBenefitDetail> benefitSettleBenefitDetailList;
	@XmlElement(name = "benefitAmtSum")
	BigDecimal benefitAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "benefitReimbursedSum")
	BigDecimal benefitReimbursedSum = BigDecimal.ZERO;
	@XmlElement(name = "reimburseMinusShortfallSum")
	BigDecimal eligibleMinusShortfallSum = BigDecimal.ZERO;
	@XmlElement(name = "presentedAmtSum")
	BigDecimal presentedAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "adjustedAmt")
	BigDecimal adjustedAmt = BigDecimal.ZERO;
	@XmlElement(name = "sumAssured")
	BigDecimal sumAssured = BigDecimal.ZERO;
	@XmlElement(name = "planName")
	String planName;
	@XmlElement(name = "planId")
	Long planId;
	@XmlElement(name = "planCoverageNo")
	String planCoverageNo;
	@XmlElement(name = "productCode")
	String productCode;
	@XmlElement(name = "productType")
	String productType;
	@XmlElement(name = "productName")
	String productName;

	@XmlElement(name = "benefitReimbursedAmtSum")
	BigDecimal benefitReimbursedAmtSum = BigDecimal.ZERO;
	
	@XmlElement(name = "hsDeductAmount")
	BigDecimal hsDeductAmount = BigDecimal.ZERO;
	
	@XmlElement(name = "totalOfPlan")
	BigDecimal totalOfPlan = BigDecimal.ZERO;

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public BenefitSettlePlan() {
		benefitSettleBenefitDetailList = new ArrayList<BenefitSettleBenefitDetail>();
	}

	public List<BenefitSettleBenefitDetail> getBenefitSettleBenefitDetailList() {
		return benefitSettleBenefitDetailList;
	}

	public void setBenefitSettleBenefitDetailList(List<BenefitSettleBenefitDetail> benefitSettleBenefitDetailList) {
		this.benefitSettleBenefitDetailList = benefitSettleBenefitDetailList;
		sumBenefitForEachPlan();
	}

	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public BigDecimal getBenefitAmtSum() {
		return benefitAmtSum;
	}

	public void setBenefitAmtSum(BigDecimal benefitAmtSum) {
		this.benefitAmtSum = benefitAmtSum;
	}

	public BigDecimal getBenefitReimbursedSum() {
		return benefitReimbursedSum;
	}

	public void setBenefitReimbursedSum(BigDecimal benefitReimbursedSum) {
		this.benefitReimbursedSum = benefitReimbursedSum;
	}

	public BigDecimal getPresentedAmtSum() {
		return presentedAmtSum;
	}

	public void setPresentedAmtSum(BigDecimal presentedAmtSum) {
		this.presentedAmtSum = presentedAmtSum;
	}

	public BigDecimal getAdjustedAmt() {
		return adjustedAmt;
	}

	public void setAdjustedAmt(BigDecimal adjustedAmt) {
		this.adjustedAmt = adjustedAmt;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	public BigDecimal getEligibleMinusShortfallSum() {
		return eligibleMinusShortfallSum;
	}

	public void setEligibleMinusShortfallSum(BigDecimal eligibleMinusShortfallSum) {
		this.eligibleMinusShortfallSum = eligibleMinusShortfallSum;
	}

	public BigDecimal getBenefitReimbursedAmtSum() {
		return benefitReimbursedAmtSum;
	}

	public void setBenefitReimbursedAmtSum(BigDecimal benefitReimbursedAmtSum) {
		this.benefitReimbursedAmtSum = benefitReimbursedAmtSum;
	}
	

	public BigDecimal getHsDeductAmount() {
		return hsDeductAmount;
	}

	public BigDecimal getTotalOfPlan() {
		return totalOfPlan;
	}

	public void setHsDeductAmount(BigDecimal hsDeductAmount) {
		this.hsDeductAmount = hsDeductAmount;
	}

	public void setTotalOfPlan(BigDecimal totalOfPlan) {
		this.totalOfPlan = totalOfPlan;
	}


	private void sumBenefitForEachPlan() {
		if ((this.benefitSettleBenefitDetailList != null) && (this.benefitSettleBenefitDetailList.size() > 0)) {
			this.benefitAmtSum = BigDecimal.ZERO;
			this.benefitReimbursedSum = BigDecimal.ZERO;
			this.presentedAmtSum = BigDecimal.ZERO;
			this.benefitReimbursedAmtSum = BigDecimal.ZERO;
			for (BenefitSettleBenefitDetail benefitDesc : this.benefitSettleBenefitDetailList) {
				BigDecimal amount = benefitDesc.getAmount();
				this.benefitAmtSum = this.benefitAmtSum.add(amount);

				BigDecimal reimbursed = benefitDesc.getEligibleAmtL();
				this.benefitReimbursedSum = this.benefitReimbursedSum.add(reimbursed);

				BigDecimal reimbursedAmt = benefitDesc.getEligibleMinusShortfallAmt();
				this.benefitReimbursedAmtSum = this.benefitReimbursedAmtSum.add(reimbursedAmt);

				this.eligibleMinusShortfallSum = this.eligibleMinusShortfallSum.add(benefitDesc.getEligibleMinusShortfallAmt());

				BigDecimal presentedAmt = benefitDesc.getPresentedAmt();
				this.presentedAmtSum = this.presentedAmtSum.add(presentedAmt);

			}
		}
	}

}
