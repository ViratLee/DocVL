package com.aia.cmic.model;

import static com.aia.cmic.util.CMiCUtil.getCommonCodeDesc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.entity.Provider;
import com.aia.cmic.entity.ProviderContact;
import com.aia.cmic.entity.ProviderDetail;
import com.aia.cmic.helper.CachingMasterDataHelper;
import com.aia.cmic.util.FormatUtil;

public class ProviderForm {

	private static final Logger LOG = LoggerFactory.getLogger(ProviderForm.class);
	private static final String PROVIDER_CATEGORY = "Provider";
	private static final String STP_CODENAME = "STPModule";
	private static final String CMAC_WARNING_CODE = "cmacWarningCode";
	private static final String PRIVATE_INSURANCE = "privateInsurance";
	//private static final String DATE_FOTMAT = "MM/dd/yyyy";
	//private static final String LOCALE = "US";
	//General Information

	private Long providerId;
	private String providerCode;
	private String providerStatus = "A";
	private String providerNameTH;
	private String providerNameEN;
	private String registeredNameTH;
	private String registeredNameEN;
	private String providerGroup;
	private String providerType;
	private String providerTypeSector;
	private String hcCode;
	private String stp;
	//@JsonFormat(pattern = DATE_FOTMAT, locale = LOCALE)
	private Date effectiveFromDt;
	//@JsonFormat(pattern = DATE_FOTMAT, locale = LOCALE)
	private Date effectiveToDt;
	//@JsonFormat(pattern = DATE_FOTMAT, locale = LOCALE)
	private Date startOperationDate;
	private Integer registeredBed;
	private Integer operatedBed;
	private Integer icuBed;
	private Integer orRoom;
	private Integer examRoom;

	private List<String> codingUsed;
	private List<String> serviceProvided;
	private List<String> medicalSpecialty;
	private List<String> award;
	private String aiaQualityTier;
	private String providerAffordabilityTier;
	private BigDecimal iaScore;
	private String servicePriority;
	private List<String> publicInsurance;
	private List<String> privateInsurance;
	private String faxClaimScore;

	//Black List
	private String blacklistIndicator;
	//@JsonFormat(pattern = DATE_FOTMAT, locale = LOCALE)
	private Date blacklistStartDate;
	//@JsonFormat(pattern = DATE_FOTMAT, locale = LOCALE)
	private Date blacklistEndDate;
	private String blacklistReason;
	private List<String> cmacWarningCode;

	private List<String> holdService;
	private List<ProviderContactForm> providerContactForm;

	private ProviderContactDetailForm providerContactDetailForm;
	private String streetAddress;

	//Payment Detail
	private String payeeFirstName;
	private String payeeLastName;
	private String bankAccountNo;
	private String bankCode;
	private String paymentCycle = "D";
	private String paymentMethod;

	private List<Integer> documentList;

	private String createBy = "System";
	//@JsonFormat(pattern = DATE_FOTMAT, locale = LOCALE)
	private Date createDt;

	//Address Form
	private String addressLine1;
	private String district;
	private String city;
	private String province;
	private String provinceName;
	private String region;
	private String regionName;
	private String country;
	private String zipcode;
	private String firstname;
	private String lastname;
	private String phoneNo1;
	private String phoneNo2;
	private String faxNo1;
	private String faxNo2;
	private String emailAddress1;
	private String emailAddress2;
	private String webSite;
	private String latitude;
	private String longitude;
	private String department;
	private String workingHours;

	public ProviderForm() {
		this.providerId = 0L;
		this.registeredBed = 0;
		this.operatedBed = 0;
		this.icuBed = 0;
		this.orRoom = 0;
		this.examRoom = 0;
	}

	public ProviderForm(Provider provider, List<ProviderDetail> providerDetails, ProviderContact providerContact) {
		this.providerId = FormatUtil.convertToLong(provider.getProviderId());
		this.providerCode = FormatUtil.convertNull(provider.getProviderCode());
		this.hcCode = FormatUtil.convertNull(provider.getHcCode());
		this.providerStatus = FormatUtil.convertNull(provider.getProviderStatus());
		this.providerNameTH = FormatUtil.convertNull(provider.getProviderNameThai());
		this.providerNameEN = FormatUtil.convertNull(provider.getProviderName());
		this.registeredNameTH = FormatUtil.convertNull(provider.getProviderRegNameThai());
		this.registeredNameEN = FormatUtil.convertNull(provider.getProviderRegName());
		this.providerGroup = FormatUtil.convertNull(provider.getProviderGroup());
		this.providerType = FormatUtil.convertNull(provider.getProviderType());
		this.providerTypeSector = FormatUtil.convertNull(provider.getProviderTypeSector());
		this.effectiveFromDt = provider.getEffectiveFromDt();
		this.effectiveToDt = provider.getEffectiveToDt();
		this.startOperationDate = provider.getOperationFromDt();
		this.registeredBed = provider.getRegisteredBed();
		this.operatedBed = provider.getOperatedBed();
		this.icuBed = provider.getIcuBed();
		this.orRoom = provider.getOrRoom();
		this.examRoom = provider.getExamRoom();
		this.createDt = provider.getCreatedDt();
		this.createBy = FormatUtil.convertNull(provider.getCreatedBy());
		this.aiaQualityTier = FormatUtil.convertNull(provider.getAiaQualityTier());
		this.providerAffordabilityTier = FormatUtil.convertNull(provider.getProviderAffordAbilityTier());
		this.iaScore = provider.getIaScore();
		this.servicePriority = FormatUtil.convertNull(provider.getServicePriority());

		this.faxClaimScore = FormatUtil.convertNull(provider.getFaxClaimScore());
		this.blacklistReason = FormatUtil.convertNull(provider.getBlacklistReason());
		this.blacklistIndicator = FormatUtil.convertNull(provider.getBlacklistInd());
		this.blacklistStartDate = provider.getBlacklistStartDate();
		this.blacklistEndDate = provider.getBlacklistEndDate();
		this.payeeFirstName = FormatUtil.convertNull(provider.getPayeeName());
		this.paymentCycle = FormatUtil.convertNull(provider.getPaymentCycle());
		this.paymentMethod = FormatUtil.convertNull(provider.getPaymentMethod());
		this.bankAccountNo = FormatUtil.convertNull(provider.getBankAccountNo());
		this.bankCode = FormatUtil.convertNull(provider.getBankCode());
		this.addressLine1 = FormatUtil.convertNull(providerContact.getAddressLine1());
		this.district = FormatUtil.convertNull(providerContact.getDistrict());
		this.city = FormatUtil.convertNull(providerContact.getCity());
		this.province = FormatUtil.convertNull(providerContact.getProvince());
		this.region = FormatUtil.convertNull(providerContact.getRegion());
		this.country = FormatUtil.convertNull(providerContact.getCountry()) == "" ? "66" : providerContact.getCountry();

		this.zipcode = FormatUtil.convertNull(providerContact.getPostalCode());
		this.firstname = FormatUtil.convertNull(providerContact.getFirstName());
		this.lastname = FormatUtil.convertNull(providerContact.getLastName());
		this.phoneNo1 = FormatUtil.convertNull(providerContact.getPhoneNo1());
		this.phoneNo2 = FormatUtil.convertNull(providerContact.getPhoneNo2());
		this.faxNo1 = FormatUtil.convertNull(providerContact.getFaxNo1());
		this.faxNo2 = FormatUtil.convertNull(providerContact.getFaxNo2());
		this.emailAddress1 = FormatUtil.convertNull(providerContact.getEmailAddress1());
		this.emailAddress2 = FormatUtil.convertNull(providerContact.getEmailAddress2());
		this.latitude = providerContact.getLatitude();
		this.longitude = providerContact.getLongitude();
		this.cmacWarningCode = new ArrayList<String>();
		this.privateInsurance = new ArrayList<String>();
		this.department = providerContact.getDepartment();
		this.workingHours = providerContact.getWorkingHours();
		if (providerDetails != null) {
			for (ProviderDetail providerDetail : providerDetails) {
				LOG.debug("ProviderDetail >> {} : {}", providerDetail.getCodeName(), providerDetail.getStrValue());
				if (CMAC_WARNING_CODE.equals(providerDetail.getCodeName())) {
					this.cmacWarningCode.add(providerDetail.getStrValue());
				}
				if (PRIVATE_INSURANCE.equals(providerDetail.getCodeName())) {
					this.privateInsurance.add(providerDetail.getStrValue());
				}
				if(PROVIDER_CATEGORY.equals(providerDetail.getCodeType()) && STP_CODENAME.equals(providerDetail.getCodeName())){
					this.stp = FormatUtil.convertNull(providerDetail.getStrValue());
				}
			}
		}
	}

	public Provider toProviderEntity(ProviderForm form, Provider provider) {
		if (provider == null) {
			provider = new Provider();
		}

		provider.setAiaQualityTier(FormatUtil.convertNull(form.getAiaQualityTier()));
		provider.setHcCode(FormatUtil.convertNull(form.getHcCode()));
		provider.setBankAccountNo(FormatUtil.convertNull(form.getBankAccountNo()));
		provider.setBankCode(FormatUtil.convertNull(form.getBankCode()));
		provider.setBlacklistEndDate(form.getBlacklistEndDate());
		provider.setBlacklistInd(FormatUtil.convertNull(form.getBlacklistIndicator()));
		provider.setBlacklistStartDate(form.getBlacklistStartDate());
		provider.setCreatedBy(FormatUtil.convertNull(form.getCreateBy()));
		provider.setCreatedDt(form.getCreateDt());
		provider.setEffectiveFromDt(form.getEffectiveFromDt());
		provider.setEffectiveToDt(form.getEffectiveToDt());
		provider.setExamRoom(form.getExamRoom());
		provider.setFaxClaimScore(FormatUtil.convertNull(form.getFaxClaimScore()));
		provider.setIaScore(form.getIaScore());
		provider.setIcuBed(form.getIcuBed());
		//provider.setLastModifiedBy();
		//provider.setLastModifiedDt("");
		provider.setRegisteredBed(form.getRegisteredBed());
		provider.setOperatedBed(form.getOperatedBed());
		provider.setOperationFromDt(form.getStartOperationDate());
		provider.setOrRoom(form.getOrRoom());
		provider.setPayeeName(FormatUtil.convertNull(form.getPayeeFirstName()));
		provider.setPaymentCycle(FormatUtil.convertNull(form.getPaymentCycle()));
		provider.setPaymentMethod(FormatUtil.convertNull(form.getPaymentMethod()));
		provider.setProviderAffordAbilityTier(FormatUtil.convertNull(form.getProviderAffordabilityTier()));
		provider.setProviderCode(FormatUtil.convertNull(form.getProviderCode()));
		provider.setProviderGroup(FormatUtil.convertNull(form.getProviderGroup()));

		provider.setProviderId(form.getProviderId());
		//provider.setProviderLicenseNum("");
		provider.setProviderName(FormatUtil.convertNull(form.getProviderNameEN()));
		provider.setProviderNameThai(FormatUtil.convertNull(form.getProviderNameTH()));
		provider.setProviderRegName(FormatUtil.convertNull(form.getRegisteredNameEN()));
		provider.setProviderRegNameThai(FormatUtil.convertNull(form.getRegisteredNameTH()));
		provider.setProviderStatus(FormatUtil.convertNull(form.getProviderStatus()));
		provider.setProviderType(FormatUtil.convertNull(form.getProviderType()));
		provider.setProviderTypeSector(FormatUtil.convertNull(form.getProviderTypeSector()));
		provider.setServicePriority(FormatUtil.convertNull(form.getServicePriority()));
		provider.setBlacklistReason(FormatUtil.convertNull(form.getBlacklistReason()));
		return provider;
	}

	public ProviderDetail toProviderDetailEntity(ProviderForm form) {
		ProviderDetail providerDetail = new ProviderDetail();
		//providerDetail.setProviderDetailId(FormatUtil.convertToLong((Math.random() * 1000))); // Just for Unit test
		providerDetail.setProviderCode(FormatUtil.convertNull(form.getProviderCode()));
		providerDetail.setCreatedBy(form.getCreateBy());
		providerDetail.setCreatedDt(form.getCreateDt());
		providerDetail.setCodeType("Provider");
		return providerDetail;
	}

	public Long getProviderId() {
		return providerId;
	}

	public void setProviderId(Long providerId) {
		this.providerId = providerId;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getHcCode() {
		return hcCode;
	}

	public void setHcCode(String hcCode) {
		this.hcCode = hcCode;
	}

	public String getStp() {
		return stp;
	}

	public void setStp(String stp) {
		this.stp = stp;
	}

	public String getProviderStatus() {
		return providerStatus;
	}

	public void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	public String getProviderNameTH() {
		return providerNameTH;
	}

	public void setProviderNameTH(String providerNameTH) {
		this.providerNameTH = providerNameTH;
	}

	public String getProviderNameEN() {
		return providerNameEN;
	}

	public void setProviderNameEN(String providerNameEN) {
		this.providerNameEN = providerNameEN;
	}

	public String getRegisteredNameTH() {
		return registeredNameTH;
	}

	public void setRegisteredNameTH(String registeredNameTH) {
		this.registeredNameTH = registeredNameTH;
	}

	public String getRegisteredNameEN() {
		return registeredNameEN;
	}

	public void setRegisteredNameEN(String registeredNameEN) {
		this.registeredNameEN = registeredNameEN;
	}

	public String getProviderGroup() {
		return providerGroup;
	}

	public void setProviderGroup(String providerGroup) {
		this.providerGroup = providerGroup;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getProviderTypeSector() {
		return providerTypeSector;
	}

	public void setProviderTypeSector(String providerTypeSector) {
		this.providerTypeSector = providerTypeSector;
	}

	public Date getEffectiveFromDt() {
		return effectiveFromDt;
	}

	public void setEffectiveFromDt(Date effectiveFromDt) {
		this.effectiveFromDt = effectiveFromDt;
	}

	public Date getEffectiveToDt() {
		return effectiveToDt;
	}

	public void setEffectiveToDt(Date effectiveToDt) {
		this.effectiveToDt = effectiveToDt;
	}

	public Date getStartOperationDate() {
		return startOperationDate;
	}

	public void setStartOperationDate(Date startOperationDate) {
		this.startOperationDate = startOperationDate;
	}

	public Integer getRegisteredBed() {
		return registeredBed;
	}

	public void setRegisteredBed(Integer registeredBed) {
		this.registeredBed = registeredBed;
	}

	public Integer getOperatedBed() {
		return operatedBed;
	}

	public void setOperatedBed(Integer operatedBed) {
		this.operatedBed = operatedBed;
	}

	public Integer getIcuBed() {
		return icuBed;
	}

	public void setIcuBed(Integer icuBed) {
		this.icuBed = icuBed;
	}

	public Integer getOrRoom() {
		return orRoom;
	}

	public void setOrRoom(Integer orRoom) {
		this.orRoom = orRoom;
	}

	public Integer getExamRoom() {
		return examRoom;
	}

	public void setExamRoom(Integer examRoom) {
		this.examRoom = examRoom;
	}

	public List<String> getCodingUsed() {
		return codingUsed;
	}

	public void setCodingUsed(List<String> codingUsed) {
		this.codingUsed = codingUsed;
	}

	public List<String> getServiceProvided() {
		return serviceProvided;
	}

	public void setServiceProvided(List<String> serviceProvided) {
		this.serviceProvided = serviceProvided;
	}

	public List<String> getMedicalSpecialty() {
		return medicalSpecialty;
	}

	public void setMedicalSpecialty(List<String> medicalSpecialty) {
		this.medicalSpecialty = medicalSpecialty;
	}

	public List<String> getAward() {
		return award;
	}

	public void setAward(List<String> award) {
		this.award = award;
	}

	public String getAiaQualityTier() {
		return aiaQualityTier;
	}

	public void setAiaQualityTier(String aiaQualityTier) {
		this.aiaQualityTier = aiaQualityTier;
	}

	public String getProviderAffordabilityTier() {
		return providerAffordabilityTier;
	}

	public void setProviderAffordabilityTier(String providerAffordabilityTier) {
		this.providerAffordabilityTier = providerAffordabilityTier;
	}

	public BigDecimal getIaScore() {
		return iaScore;
	}

	public void setIaScore(BigDecimal iaScore) {
		this.iaScore = iaScore;
	}

	public String getServicePriority() {
		return servicePriority;
	}

	public void setServicePriority(String servicePriority) {
		this.servicePriority = servicePriority;
	}

	public List<String> getPublicInsurance() {
		return publicInsurance;
	}

	public void setPublicInsurance(List<String> publicInsurance) {
		this.publicInsurance = publicInsurance;
	}

	public List<String> getPrivateInsurance() {
		return privateInsurance;
	}

	public void setPrivateInsurance(List<String> privateInsurance) {
		this.privateInsurance = privateInsurance;
	}

	public String getFaxClaimScore() {
		return faxClaimScore;
	}

	public void setFaxClaimScore(String faxClaimScore) {
		this.faxClaimScore = faxClaimScore;
	}

	public String getBlacklistIndicator() {
		return blacklistIndicator;
	}

	public void setBlacklistIndicator(String blacklistIndicator) {
		this.blacklistIndicator = blacklistIndicator;
	}

	public Date getBlacklistStartDate() {
		return blacklistStartDate;
	}

	public void setBlacklistStartDate(Date blacklistStartDate) {
		this.blacklistStartDate = blacklistStartDate;
	}

	public Date getBlacklistEndDate() {
		return blacklistEndDate;
	}

	public void setBlacklistEndDate(Date blacklistEndDate) {
		this.blacklistEndDate = blacklistEndDate;
	}

	public String getBlacklistReason() {
		return blacklistReason;
	}

	public void setBlacklistReason(String blacklistReason) {
		this.blacklistReason = blacklistReason;
	}

	public final List<String> getCmacWarningCode() {
		return cmacWarningCode;
	}

	public final void setCmacWarningCode(List<String> cmacWarningCode) {
		this.cmacWarningCode = cmacWarningCode;
	}

	public List<String> getHoldService() {
		return holdService;
	}

	public void setHoldService(List<String> holdService) {
		this.holdService = holdService;
	}

	public List<ProviderContactForm> getProviderContactForm() {
		return providerContactForm;
	}

	public void setProviderContactForm(List<ProviderContactForm> providerContactForm) {
		this.providerContactForm = providerContactForm;
	}

	public ProviderContactDetailForm getProviderContactDetailForm() {
		return providerContactDetailForm;
	}

	public void setProviderContactDetailForm(ProviderContactDetailForm providerContactDetailForm) {
		this.providerContactDetailForm = providerContactDetailForm;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getPayeeFirstName() {
		return payeeFirstName;
	}

	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	public String getPayeeLastName() {
		return payeeLastName;
	}

	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getPaymentCycle() {
		return paymentCycle;
	}

	public void setPaymentCycle(String paymentCycle) {
		this.paymentCycle = paymentCycle;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public List<Integer> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<Integer> documentList) {
		this.documentList = documentList;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhoneNo1() {
		return phoneNo1;
	}

	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	public String getPhoneNo2() {
		return phoneNo2;
	}

	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}

	public String getFaxNo1() {
		return faxNo1;
	}

	public void setFaxNo1(String faxNo1) {
		this.faxNo1 = faxNo1;
	}

	public String getFaxNo2() {
		return faxNo2;
	}

	public void setFaxNo2(String faxNo2) {
		this.faxNo2 = faxNo2;
	}

	public String getEmailAddress1() {
		return emailAddress1;
	}

	public void setEmailAddress1(String emailAddress1) {
		this.emailAddress1 = emailAddress1;
	}

	public String getEmailAddress2() {
		return emailAddress2;
	}

	public void setEmailAddress2(String emailAddress2) {
		this.emailAddress2 = emailAddress2;
	}

	public String getWebSite() {
		return webSite;
	}

	public void setWebSite(String webSite) {
		this.webSite = webSite;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getWorkingHours() {
		return workingHours;
	}

	public void setWorkingHours(String workingHours) {
		this.workingHours = workingHours;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
