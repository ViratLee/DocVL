package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class HCInternetRetrievePartyResponse {
	private List<PartySnapshot> parties;
	private String returnCode;
	private String returnMessage;

	public List<PartySnapshot> getParties() {
		return parties;
	}

	public void setParties(List<PartySnapshot> parties) {
		this.parties = parties;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}