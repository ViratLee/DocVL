package com.aia.cmic.model;

import java.math.BigDecimal;

public class AiClaimPaymentDetail {

	private BigDecimal ALLOCATEDAMT;
	private String BENEFITCODE;
	private String CLAIMNO;
	private Integer OCCURRENCE;
	private String PLANCOVERAGENO;
	private Long PLANID;
	private String POLICYNO;
	private String PRODUCTCODE;
	private String PRODUCTTYPE;
	
	public BigDecimal getALLOCATEDAMT() {
		return ALLOCATEDAMT;
	}
	public void setALLOCATEDAMT(BigDecimal aLLOCATEDAMT) {
		ALLOCATEDAMT = aLLOCATEDAMT;
	}
	public String getBENEFITCODE() {
		return BENEFITCODE;
	}
	public void setBENEFITCODE(String bENEFITCODE) {
		BENEFITCODE = bENEFITCODE;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getPLANCOVERAGENO() {
		return PLANCOVERAGENO;
	}
	public void setPLANCOVERAGENO(String pLANCOVERAGENO) {
		PLANCOVERAGENO = pLANCOVERAGENO;
	}
	public Long getPLANID() {
		return PLANID;
	}
	public void setPLANID(Long pLANID) {
		PLANID = pLANID;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	public String getPRODUCTCODE() {
		return PRODUCTCODE;
	}
	public void setPRODUCTCODE(String pRODUCTCODE) {
		PRODUCTCODE = pRODUCTCODE;
	}
	public String getPRODUCTTYPE() {
		return PRODUCTTYPE;
	}
	public void setPRODUCTTYPE(String pRODUCTTYPE) {
		PRODUCTTYPE = pRODUCTTYPE;
	}
}
