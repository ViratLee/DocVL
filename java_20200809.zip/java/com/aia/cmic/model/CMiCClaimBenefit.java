package com.aia.cmic.model;

import com.aia.cmic.canonical.ClaimBenefitCanonical;

public class CMiCClaimBenefit {
	private ClaimBenefitCanonical claimBenefitCanonical;

	public ClaimBenefitCanonical getClaimBenefitCanonical() {
		return claimBenefitCanonical;
	}

	public void setClaimBenefitCanonical(ClaimBenefitCanonical claimBenefitCanonical) {
		this.claimBenefitCanonical = claimBenefitCanonical;
	}
}
