package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.cmic.entity.NetworkDetail;

public class NetworkDetailForm {

	private static final Logger LOG = LoggerFactory.getLogger(NetworkForm.class);

	private Long networkId;
	private Long networkDetailId;
	private String codeType;
	private String strValue;
	private String createdBy;
	private Date createdDt;
	private String lastModifiedBy;
	private Date lastModifiedDt;

	public NetworkDetailForm() {
	}

	public static NetworkDetail toNetworkDetailEntity(NetworkDetailForm form) {
		NetworkDetail retrunValue = new NetworkDetail();
		retrunValue.setNetworkId(form.getNetworkId());
		retrunValue.setCodeType(form.getCodeType());
		retrunValue.setStrValue(form.getStrValue());
		retrunValue.setCreatedBy(form.getCreatedBy());
		retrunValue.setLastModifiedBy(form.getLastModifiedBy());
		retrunValue.setCreatedDt(new Date());
		retrunValue.setLastModifiedDt(new Date());
		return retrunValue;
	}

	public final Long getNetworkId() {
		return networkId;
	}

	public final void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public final Long getNetworkDetailId() {
		return networkDetailId;
	}

	public final void setNetworkDetailId(Long networkDetailId) {
		this.networkDetailId = networkDetailId;
	}

	public final String getCodeType() {
		return codeType;
	}

	public final void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public final String getStrValue() {
		return strValue;
	}

	public final void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	public final String getCreatedBy() {
		return createdBy;
	}

	public final void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public final Date getCreatedDt() {
		return createdDt;
	}

	public final void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public final String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public final void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public final Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public final void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
