package com.aia.cmic.model;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class PendingManagementBO {
	Long pendMangeId;
	Lookup pendMangeStatus;
	String pendingRequirement;
	String createdUser;
	Date requestedDate;
	String resolvedUser;
	Date resolvedDate;
	String target;

	public Long getPendMangeId() {
		return pendMangeId;
	}

	public void setPendMangeId(Long pendMangeId) {
		this.pendMangeId = pendMangeId;
	}

	public Lookup getPendMangeStatus() {
		return pendMangeStatus;
	}

	public void setPendMangeStatus(Lookup pendMangeStatus) {
		this.pendMangeStatus = pendMangeStatus;
	}

	public String getPendingRequirement() {
		return pendingRequirement;
	}

	public void setPendingRequirement(String pendingRequirement) {
		this.pendingRequirement = pendingRequirement;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public Date getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}

	public String getResolvedUser() {
		return resolvedUser;
	}

	public void setResolvedUser(String resolvedUser) {
		this.resolvedUser = resolvedUser;
	}

	public Date getResolvedDate() {
		return resolvedDate;
	}

	public void setResolvedDate(Date resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
