package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class Claim {

	Long claimId;
	String claimNo;
	Integer occurrence;
	String previousClaimNo;
	Integer previousOccurrence;
	Date receivedDate;
	String policyNo;
	String companyId;
	String certNo;
	String memberId;
	String dependentNo;
	String dependentType;
	String relationship;
	String relationshipName;
	String vip;
	String clientId;
	Long partyId;
	String memberLastName;
	String memberFirstName;
	String lastName;
	String firstName;
	String gender;
	Date dob;
	String nationalId;
	String subOfficeCode;
	String SubOfficeName;
	String subOfficeStatus;
	String policyHolder;
	String policyOwner;
	Long policyOwnerPartyId;
	String channel;
	String submissionType;
	String paymentSeq;
	String noOriginalBillInd;
	String originalBillInd;
	String billNo;
	Date billDtFrom;
	Date billDtTo;

	String fastTrackAgency;
	String brokerCode;
	String brokerName;
	String payeeIsCompanyInd;
	String paymentMethod;
	String billingStatus;
	String billingDeclineReason;
	String classOfBed;
	String roomType;
	String providerCode;
	String referralDoctorCode;
	String referralDoctorName;
	String referralDoctorEmail;
	String referralDoctorPhone;
	String referralDoctorFax;
	String prevDoctorName;
	String prevDoctorEmail;
	String prevDoctorPhone;
	String prevDoctorFax;
	Date firstConsultationDt;
	Date consultationDt;
	Date symptomDate;
	String physicalFinding;
	String chiefComplaint;
	String underlyingCause;
	String illnessSpecialCondition;
	String diagnosisResult;
	String provisionalDiagnosis;
	String conditionRequiredTreatment;
	String presentIllness;
	BigDecimal temperature;
	BigDecimal pulse;
	BigDecimal respiratoryRate;
	BigDecimal systolic;
	BigDecimal diastolic;
	Integer painScore;
	Integer comaScore;
	BigDecimal weight;
	BigDecimal height;
	BigDecimal bmi;
	Date accidentDt;
	String accidentPlace;
	String levelOfConsciousness;
	String causeOfInjury;
	String injuryType;
	Integer estimatedTimeOfDiscovery;
	Integer estimatedMonthOfDiscovery;
	Date prevTreatmentDate;
	Date treatmentDate;
	String treatmentType;
	String causeOfTreatment;
	Date hospitalizationDate;
	String hospitalizationReason;
	Date dischargeDate;
	Integer lengthOfStay;
	Date icuAdmissionDate;
	Date icuDischargeDate;
	Integer icuLengthOfStay;
	String icuReason;
	String otherInsurer;
	Date homeLeaveFromDate;
	Date homeLeaveToDt;
	String homeLeaveReason;
	String reconsiderCase;
	String deleteInd;
	String autoClaimInd;
	String cptCode;
	String assessorCode;
	String approvalCode;
	String paymentInd;
	String healthCardInd;
	String careCardInd;
	String oneCardInd;
	String claimStatus;
	String processStatus;
	Date claimStatusDt;
	String receiptOfReferral;
	String appealInd;
	String emergencyInd;
	Integer dayOfAdmitRoom;
	Integer dayOfAdmitIcu;
	Integer dayOfCall;
	Integer totalDisability;
	Integer partialDisability;
	Date disabilityStartDt;
	Date disabilityEndDt;
	String surgicalPercentage;
	String doubleIndemnity;
	String homeMedicalInd;
	String hbpType;
	String attainedAgeInd;
	String anesthesiaInd;
	String surgeryInd;
	String diseaseInd;
	Integer dayOfAdmitJunior;
	String majorAccId;
	String majorInjuryDetail;
	String hbjSurgeryInd;
	String shortFallInd;
	String origCurrency;
	String convCurrency;
	String exchangeRateDesc;
	BigDecimal totalEstimatedCost;
	BigDecimal totalBilledAmt;
	String holdPaymentInd;
	Date holdPaymentDate;
	String releaseHoldPaymentInd;
	Date releaseHoldPaymentDate;
	String initialPhase;
	String phase;
	Long caseId;
	String batchNo;
	String createdBy;
	String lastModifiedBy;
	Date createdDt;
	Date lastModifiedDt;

	Date plannedHospitalizationDate;
	Date plannedDischargeDate;
	Date plannedIcuAdmissionDate;
	Date plannedIcuDischargeDate;

	String agencyCodeServicing;
	String agentCodeServicing;
	String agencyOfficeCodeServicing;

	String submissionAgentName;
	String submissionAgencyName;
	String submissionOfficeName;
	String submissionAgencyLeaderName;
	String writingAgencyLeaderName;

	String businessLine;
	String ipdOpd;

	String hn;
	String an;
	
	Date documentInTime ;
	String interestInd ;
	String cleanInd;

	Boolean aiOnly;
	boolean quotationClaim = false;

	boolean stp = false;
	String ipdStpFlag;

	Date policyYearFromDt;
	Date policyYearToDt;

	BigDecimal csHBAmt;

	boolean isFurther = false;

	String mdrt;
	String bbl;
	String ipdDrug;
	String ediInd;
	String stpInd;

	String claimCriticalIllnesss;
	private Date firstAdmitDt ;
	private Integer ptcall;

	String dataPrivacyConsent;
	String dataPrivacyConsentDate;
	
	String deductInd;
	Date deductDt;
	
	String aiInd;
	String aiBillingStatus;
	String aiBillingDeclineReason;
	String aiVersion;
	
	public String getDeductInd() {
		return deductInd;
	}

	public Date getDeductDt() {
		return deductDt;
	}

	public void setDeductInd(String deductInd) {
		this.deductInd = deductInd;
	}

	public void setDeductDt(Date deductDt) {
		this.deductDt = deductDt;
	}

	public String getIpdOpd() {
		return ipdOpd;
	}

	public void setIpdOpd(String ipdOpd) {
		this.ipdOpd = ipdOpd;
	}

	public final Long getClaimId() {
		return claimId;
	}

	public final void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public final String getClaimNo() {
		return claimNo;
	}

	public final void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public final Integer getOccurrence() {
		return occurrence;
	}

	public final void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public final String getPreviousClaimNo() {
		return previousClaimNo;
	}

	public final void setPreviousClaimNo(String previousClaimNo) {
		this.previousClaimNo = previousClaimNo;
	}

	public final Integer getPreviousOccurrence() {
		return previousOccurrence;
	}

	public final void setPreviousOccurrence(Integer previousOccurrence) {
		this.previousOccurrence = previousOccurrence;
	}

	public final String getPolicyNo() {
		return policyNo;
	}

	public final void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public final String getCompanyId() {
		return companyId;
	}

	public final void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public final String getCertNo() {
		return certNo;
	}

	public final void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public final String getMemberId() {
		return memberId;
	}

	public final void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public final String getDependentNo() {
		return dependentNo;
	}

	public final void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public final String getDependentType() {
		return dependentType;
	}

	public final void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public final String getRelationship() {
		return relationship;
	}

	public final void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getRelationshipName() {
		return relationshipName;
	}

	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}

	public final String getVip() {
		return vip;
	}

	public final void setVip(String vip) {
		this.vip = vip;
	}

	public final String getClientId() {
		return clientId;
	}

	public final void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public final Long getPartyId() {
		return partyId;
	}

	public final void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public final String getMemberLastName() {
		return memberLastName;
	}

	public final void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	public final String getMemberFirstName() {
		return memberFirstName;
	}

	public final void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public final String getLastName() {
		return lastName;
	}

	public final void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public final String getFirstName() {
		return firstName;
	}

	public final void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public final String getGender() {
		return gender;
	}

	public final void setGender(String gender) {
		this.gender = gender;
	}

	public final Date getDob() {
		return dob;
	}

	public final void setDob(Date dob) {
		this.dob = dob;
	}

	public final Date getReceivedDate() {
		return receivedDate;
	}

	public final void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public final String getNationalId() {
		return nationalId;
	}

	public final void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public final String getSubOfficeCode() {
		return subOfficeCode;
	}

	public final void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	public String getSubOfficeName() {
		return SubOfficeName;
	}

	public void setSubOfficeName(String subOfficeName) {
		SubOfficeName = subOfficeName;
	}

	public String getSubOfficeStatus() {
		return subOfficeStatus;
	}

	public void setSubOfficeStatus(String subOfficeStatus) {
		this.subOfficeStatus = subOfficeStatus;
	}

	public final String getPolicyHolder() {
		return policyHolder;
	}

	public final void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}

	public final String getPolicyOwner() {
		return policyOwner;
	}

	public final void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	public final Long getPolicyOwnerPartyId() {
		return policyOwnerPartyId;
	}

	public final void setPolicyOwnerPartyId(Long policyOwnerPartyId) {
		this.policyOwnerPartyId = policyOwnerPartyId;
	}

	public final String getChannel() {
		return channel;
	}

	public final void setChannel(String channel) {
		this.channel = channel;
	}

	public final String getSubmissionType() {
		return submissionType;
	}

	public final void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public final String getPaymentSeq() {
		return paymentSeq;
	}

	public final void setPaymentSeq(String paymentSeq) {
		this.paymentSeq = paymentSeq;
	}

	public final String getNoOriginalBillInd() {
		return noOriginalBillInd;
	}

	public final void setNoOriginalBillInd(String noOriginalBillInd) {
		this.noOriginalBillInd = noOriginalBillInd;
	}

	public final String getOriginalBillInd() {
		return originalBillInd;
	}

	public final void setOriginalBillInd(String originalBillInd) {
		this.originalBillInd = originalBillInd;
	}

	public final String getBillNo() {
		return billNo;
	}

	public final void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	public final Date getBillDtFrom() {
		return billDtFrom;
	}

	public final void setBillDtFrom(Date billDtFrom) {
		this.billDtFrom = billDtFrom;
	}

	public final Date getBillDtTo() {
		return billDtTo;
	}

	public final void setBillDtTo(Date billDtTo) {
		this.billDtTo = billDtTo;
	}

	public final String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	public final void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	public final String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public final void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	public final String getAgencyOfficeCodeServicing() {
		return agencyOfficeCodeServicing;
	}

	public final void setAgencyOfficeCodeServicing(String agencyOfficeCodeServicing) {
		this.agencyOfficeCodeServicing = agencyOfficeCodeServicing;
	}

	public final String getFastTrackAgency() {
		return fastTrackAgency;
	}

	public final void setFastTrackAgency(String fastTrackAgency) {
		this.fastTrackAgency = fastTrackAgency;
	}

	public final String getBrokerCode() {
		return brokerCode;
	}

	public final void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}

	public final String getBrokerName() {
		return brokerName;
	}

	public final void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public final String getPayeeIsCompanyInd() {
		return payeeIsCompanyInd;
	}

	public final void setPayeeIsCompanyInd(String payeeIsCompanyInd) {
		this.payeeIsCompanyInd = payeeIsCompanyInd;
	}

	public final String getPaymentMethod() {
		return paymentMethod;
	}

	public final void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public final String getBillingStatus() {
		return billingStatus;
	}

	public final void setBillingStatus(String billingStatus) {
		this.billingStatus = billingStatus;
	}

	public final String getBillingDeclineReason() {
		return billingDeclineReason;
	}

	public final void setBillingDeclineReason(String billingDeclineReason) {
		this.billingDeclineReason = billingDeclineReason;
	}

	public final String getClassOfBed() {
		return classOfBed;
	}

	public final void setClassOfBed(String classOfBed) {
		this.classOfBed = classOfBed;
	}

	public final String getRoomType() {
		return roomType;
	}

	public final void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public final String getProviderCode() {
		return providerCode;
	}

	public final void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public final String getReferralDoctorCode() {
		return referralDoctorCode;
	}

	public final void setReferralDoctorCode(String referralDoctorCode) {
		this.referralDoctorCode = referralDoctorCode;
	}

	public final String getReferralDoctorName() {
		return referralDoctorName;
	}

	public final void setReferralDoctorName(String referralDoctorName) {
		this.referralDoctorName = referralDoctorName;
	}

	public final String getReferralDoctorEmail() {
		return referralDoctorEmail;
	}

	public final void setReferralDoctorEmail(String referralDoctorEmail) {
		this.referralDoctorEmail = referralDoctorEmail;
	}

	public final String getReferralDoctorPhone() {
		return referralDoctorPhone;
	}

	public final void setReferralDoctorPhone(String referralDoctorPhone) {
		this.referralDoctorPhone = referralDoctorPhone;
	}

	public final String getReferralDoctorFax() {
		return referralDoctorFax;
	}

	public final void setReferralDoctorFax(String referralDoctorFax) {
		this.referralDoctorFax = referralDoctorFax;
	}

	public final String getPrevDoctorName() {
		return prevDoctorName;
	}

	public final void setPrevDoctorName(String prevDoctorName) {
		this.prevDoctorName = prevDoctorName;
	}

	public final String getPrevDoctorEmail() {
		return prevDoctorEmail;
	}

	public final void setPrevDoctorEmail(String prevDoctorEmail) {
		this.prevDoctorEmail = prevDoctorEmail;
	}

	public String getPrevDoctorPhone() {
		return prevDoctorPhone;
	}

	public void setPrevDoctorPhone(String prevDoctorPhone) {
		this.prevDoctorPhone = prevDoctorPhone;
	}

	public final String getPrevDoctorFax() {
		return prevDoctorFax;
	}

	public final void setPrevDoctorFax(String prevDoctorFax) {
		this.prevDoctorFax = prevDoctorFax;
	}

	public final Date getFirstConsultationDt() {
		return firstConsultationDt;
	}

	public final void setFirstConsultationDt(Date firstConsultationDt) {
		this.firstConsultationDt = firstConsultationDt;
	}

	public final Date getConsultationDt() {
		return consultationDt;
	}

	public final void setConsultationDt(Date consultationDt) {
		this.consultationDt = consultationDt;
	}

	public final Date getSymptomDate() {
		return symptomDate;
	}

	public final void setSymptomDate(Date symptomDate) {
		this.symptomDate = symptomDate;
	}

	public final String getPhysicalFinding() {
		return physicalFinding;
	}

	public final void setPhysicalFinding(String physicalFinding) {
		this.physicalFinding = physicalFinding;
	}

	public final String getChiefComplaint() {
		return chiefComplaint;
	}

	public final void setChiefComplaint(String chiefComplaint) {
		this.chiefComplaint = chiefComplaint;
	}

	public final String getUnderlyingCause() {
		return underlyingCause;
	}

	public final void setUnderlyingCause(String underlyingCause) {
		this.underlyingCause = underlyingCause;
	}

	public final String getIllnessSpecialCondition() {
		return illnessSpecialCondition;
	}

	public final void setIllnessSpecialCondition(String illnessSpecialCondition) {
		this.illnessSpecialCondition = illnessSpecialCondition;
	}

	public final String getDiagnosisResult() {
		return diagnosisResult;
	}

	public final void setDiagnosisResult(String diagnosisResult) {
		this.diagnosisResult = diagnosisResult;
	}

	public final String getProvisionalDiagnosis() {
		return provisionalDiagnosis;
	}

	public final void setProvisionalDiagnosis(String provisionalDiagnosis) {
		this.provisionalDiagnosis = provisionalDiagnosis;
	}

	public final String getConditionRequiredTreatment() {
		return conditionRequiredTreatment;
	}

	public final void setConditionRequiredTreatment(String conditionRequiredTreatment) {
		this.conditionRequiredTreatment = conditionRequiredTreatment;
	}

	public final String getPresentIllness() {
		return presentIllness;
	}

	public final void setPresentIllness(String presentIllness) {
		this.presentIllness = presentIllness;
	}

	public final BigDecimal getTemperature() {
		return temperature;
	}

	public final void setTemperature(BigDecimal temperature) {
		this.temperature = temperature;
	}

	public final BigDecimal getPulse() {
		return pulse;
	}

	public final void setPulse(BigDecimal pulse) {
		this.pulse = pulse;
	}

	public final BigDecimal getRespiratoryRate() {
		return respiratoryRate;
	}

	public final void setRespiratoryRate(BigDecimal respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}

	public final BigDecimal getSystolic() {
		return systolic;
	}

	public final void setSystolic(BigDecimal systolic) {
		this.systolic = systolic;
	}

	public final BigDecimal getDiastolic() {
		return diastolic;
	}

	public final void setDiastolic(BigDecimal diastolic) {
		this.diastolic = diastolic;
	}

	public final Integer getPainScore() {
		return painScore;
	}

	public final void setPainScore(Integer painScore) {
		this.painScore = painScore;
	}

	public final Integer getComaScore() {
		return comaScore;
	}

	public final void setComaScore(Integer comaScore) {
		this.comaScore = comaScore;
	}

	public final BigDecimal getWeight() {
		return weight;
	}

	public final void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public final BigDecimal getHeight() {
		return height;
	}

	public final void setHeight(BigDecimal height) {
		this.height = height;
	}

	public final BigDecimal getBmi() {
		return bmi;
	}

	public final void setBmi(BigDecimal bmi) {
		this.bmi = bmi;
	}

	public final Date getAccidentDt() {
		return accidentDt;
	}

	public final void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public final String getAccidentPlace() {
		return accidentPlace;
	}

	public final void setAccidentPlace(String accidentPlace) {
		this.accidentPlace = accidentPlace;
	}

	public final String getLevelOfConsciousness() {
		return levelOfConsciousness;
	}

	public final void setLevelOfConsciousness(String levelOfConsciousness) {
		this.levelOfConsciousness = levelOfConsciousness;
	}

	public final String getCauseOfInjury() {
		return causeOfInjury;
	}

	public final void setCauseOfInjury(String causeOfInjury) {
		this.causeOfInjury = causeOfInjury;
	}

	public final String getInjuryType() {
		return injuryType;
	}

	public final void setInjuryType(String injuryType) {
		this.injuryType = injuryType;
	}

	public final Integer getEstimatedTimeOfDiscovery() {
		return estimatedTimeOfDiscovery;
	}

	public final void setEstimatedTimeOfDiscovery(Integer estimatedTimeOfDiscovery) {
		this.estimatedTimeOfDiscovery = estimatedTimeOfDiscovery;
	}

	public final Integer getEstimatedMonthOfDiscovery() {
		return estimatedMonthOfDiscovery;
	}

	public final void setEstimatedMonthOfDiscovery(Integer estimatedMonthOfDiscovery) {
		this.estimatedMonthOfDiscovery = estimatedMonthOfDiscovery;
	}

	public final Date getPrevTreatmentDate() {
		return prevTreatmentDate;
	}

	public final void setPrevTreatmentDate(Date prevTreatmentDate) {
		this.prevTreatmentDate = prevTreatmentDate;
	}

	public final Date getTreatmentDate() {
		return treatmentDate;
	}

	public final void setTreatmentDate(Date treatmentDate) {
		this.treatmentDate = treatmentDate;
	}

	public final String getTreatmentType() {
		return treatmentType;
	}

	public final void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public final String getCauseOfTreatment() {
		return causeOfTreatment;
	}

	public final void setCauseOfTreatment(String causeOfTreatment) {
		this.causeOfTreatment = causeOfTreatment;
	}

	public final Date getHospitalizationDate() {
		return hospitalizationDate;
	}

	public final void setHospitalizationDate(Date hospitalizationDate) {
		this.hospitalizationDate = hospitalizationDate;
	}

	public final String getHospitalizationReason() {
		return hospitalizationReason;
	}

	public final void setHospitalizationReason(String hospitalizationReason) {
		this.hospitalizationReason = hospitalizationReason;
	}

	public final Date getDischargeDate() {
		return dischargeDate;
	}

	public final void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public final Integer getLengthOfStay() {
		return lengthOfStay;
	}

	public final void setLengthOfStay(Integer lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public final Date getIcuAdmissionDate() {
		return icuAdmissionDate;
	}

	public final void setIcuAdmissionDate(Date icuAdmissionDate) {
		this.icuAdmissionDate = icuAdmissionDate;
	}

	public final Date getIcuDischargeDate() {
		return icuDischargeDate;
	}

	public final void setIcuDischargeDate(Date icuDischargeDate) {
		this.icuDischargeDate = icuDischargeDate;
	}

	public final Integer getIcuLengthOfStay() {
		return icuLengthOfStay;
	}

	public final void setIcuLengthOfStay(Integer icuLengthOfStay) {
		this.icuLengthOfStay = icuLengthOfStay;
	}

	public final String getIcuReason() {
		return icuReason;
	}

	public final void setIcuReason(String icuReason) {
		this.icuReason = icuReason;
	}

	public final String getOtherInsurer() {
		return otherInsurer;
	}

	public final void setOtherInsurer(String otherInsurer) {
		this.otherInsurer = otherInsurer;
	}

	public final Date getHomeLeaveFromDate() {
		return homeLeaveFromDate;
	}

	public final void setHomeLeaveFromDate(Date homeLeaveFromDate) {
		this.homeLeaveFromDate = homeLeaveFromDate;
	}

	public final Date getHomeLeaveToDt() {
		return homeLeaveToDt;
	}

	public final void setHomeLeaveToDt(Date homeLeaveToDt) {
		this.homeLeaveToDt = homeLeaveToDt;
	}

	public final String getHomeLeaveReason() {
		return homeLeaveReason;
	}

	public final void setHomeLeaveReason(String homeLeaveReason) {
		this.homeLeaveReason = homeLeaveReason;
	}

	public final String getReconsiderCase() {
		return reconsiderCase;
	}

	public final void setReconsiderCase(String reconsiderCase) {
		this.reconsiderCase = reconsiderCase;
	}

	public final String getDeleteInd() {
		return deleteInd;
	}

	public final void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}

	public final String getAutoClaimInd() {
		return autoClaimInd;
	}

	public final void setAutoClaimInd(String autoClaimInd) {
		this.autoClaimInd = autoClaimInd;
	}

	public final String getCptCode() {
		return cptCode;
	}

	public final void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public final String getAssessorCode() {
		return assessorCode;
	}

	public final void setAssessorCode(String assessorCode) {
		this.assessorCode = assessorCode;
	}

	public final String getApprovalCode() {
		return approvalCode;
	}

	public final void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

	public final String getPaymentInd() {
		return paymentInd;
	}

	public final void setPaymentInd(String paymentInd) {
		this.paymentInd = paymentInd;
	}

	public final String getHealthCardInd() {
		return healthCardInd;
	}

	public final void setHealthCardInd(String healthCardInd) {
		this.healthCardInd = healthCardInd;
	}

	public final String getCareCardInd() {
		return careCardInd;
	}

	public final void setCareCardInd(String careCardInd) {
		this.careCardInd = careCardInd;
	}

	public final String getOneCardInd() {
		return oneCardInd;
	}

	public final void setOneCardInd(String oneCardInd) {
		this.oneCardInd = oneCardInd;
	}

	public final String getClaimStatus() {
		return claimStatus;
	}

	public final void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public final String getProcessStatus() {
		return processStatus;
	}

	public final void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public final Date getClaimStatusDt() {
		return claimStatusDt;
	}

	public final void setClaimStatusDt(Date claimStatusDt) {
		this.claimStatusDt = claimStatusDt;
	}

	public final String getReceiptOfReferral() {
		return receiptOfReferral;
	}

	public final void setReceiptOfReferral(String receiptOfReferral) {
		this.receiptOfReferral = receiptOfReferral;
	}

	public final String getAppealInd() {
		return appealInd;
	}

	public final void setAppealInd(String appealInd) {
		this.appealInd = appealInd;
	}

	public final String getEmergencyInd() {
		return emergencyInd;
	}

	public final void setEmergencyInd(String emergencyInd) {
		this.emergencyInd = emergencyInd;
	}

	public final Integer getDayOfAdmitRoom() {
		return dayOfAdmitRoom;
	}

	public final void setDayOfAdmitRoom(Integer dayOfAdmitRoom) {
		this.dayOfAdmitRoom = dayOfAdmitRoom;
	}

	public final Integer getDayOfAdmitIcu() {
		return dayOfAdmitIcu;
	}

	public final void setDayOfAdmitIcu(Integer dayOfAdmitIcu) {
		this.dayOfAdmitIcu = dayOfAdmitIcu;
	}

	public final Integer getDayOfCall() {
		return dayOfCall;
	}

	public final void setDayOfCall(Integer dayOfCall) {
		this.dayOfCall = dayOfCall;
	}

	public final Integer getTotalDisability() {
		return totalDisability;
	}

	public final void setTotalDisability(Integer totalDisability) {
		this.totalDisability = totalDisability;
	}

	public final Integer getPartialDisability() {
		return partialDisability;
	}

	public final void setPartialDisability(Integer partialDisability) {
		this.partialDisability = partialDisability;
	}

	public final Date getDisabilityStartDt() {
		return disabilityStartDt;
	}

	public final void setDisabilityStartDt(Date disabilityStartDt) {
		this.disabilityStartDt = disabilityStartDt;
	}

	public final Date getDisabilityEndDt() {
		return disabilityEndDt;
	}

	public final void setDisabilityEndDt(Date disabilityEndDt) {
		this.disabilityEndDt = disabilityEndDt;
	}

	public String getSurgicalPercentage() {
		return surgicalPercentage;
	}

	public void setSurgicalPercentage(String surgicalPercentage) {
		this.surgicalPercentage = surgicalPercentage;
	}

	public final String getDoubleIndemnity() {
		return doubleIndemnity;
	}

	public final void setDoubleIndemnity(String doubleIndemnity) {
		this.doubleIndemnity = doubleIndemnity;
	}

	public final String getHomeMedicalInd() {
		return homeMedicalInd;
	}

	public final void setHomeMedicalInd(String homeMedicalInd) {
		this.homeMedicalInd = homeMedicalInd;
	}

	public final String getHbpType() {
		return hbpType;
	}

	public final void setHbpType(String hbpType) {
		this.hbpType = hbpType;
	}

	public final String getAttainedAgeInd() {
		return attainedAgeInd;
	}

	public final void setAttainedAgeInd(String attainedAgeInd) {
		this.attainedAgeInd = attainedAgeInd;
	}

	public final String getAnesthesiaInd() {
		return anesthesiaInd;
	}

	public final void setAnesthesiaInd(String anesthesiaInd) {
		this.anesthesiaInd = anesthesiaInd;
	}

	public final String getSurgeryInd() {
		return surgeryInd;
	}

	public final void setSurgeryInd(String surgeryInd) {
		this.surgeryInd = surgeryInd;
	}

	public final String getDiseaseInd() {
		return diseaseInd;
	}

	public final void setDiseaseInd(String diseaseInd) {
		this.diseaseInd = diseaseInd;
	}

	public final Integer getDayOfAdmitJunior() {
		return dayOfAdmitJunior;
	}

	public final void setDayOfAdmitJunior(Integer dayOfAdmitJunior) {
		this.dayOfAdmitJunior = dayOfAdmitJunior;
	}

	public String getMajorAccId() {
		return majorAccId;
	}

	public void setMajorAccId(String majorAccId) {
		this.majorAccId = majorAccId;
	}

	public final String getMajorInjuryDetail() {
		return majorInjuryDetail;
	}

	public final void setMajorInjuryDetail(String majorInjuryDetail) {
		this.majorInjuryDetail = majorInjuryDetail;
	}

	public final String getHbjSurgeryInd() {
		return hbjSurgeryInd;
	}

	public final void setHbjSurgeryInd(String hbjSurgeryInd) {
		this.hbjSurgeryInd = hbjSurgeryInd;
	}

	public final String getShortFallInd() {
		return shortFallInd;
	}

	public final void setShortFallInd(String shortFallInd) {
		this.shortFallInd = shortFallInd;
	}

	public final String getOrigCurrency() {
		return origCurrency;
	}

	public final void setOrigCurrency(String origCurrency) {
		this.origCurrency = origCurrency;
	}

	public final String getConvCurrency() {
		return convCurrency;
	}

	public final void setConvCurrency(String convCurrency) {
		this.convCurrency = convCurrency;
	}

	public final String getExchangeRateDesc() {
		return exchangeRateDesc;
	}

	public final void setExchangeRateDesc(String exchangeRateDesc) {
		this.exchangeRateDesc = exchangeRateDesc;
	}

	public final BigDecimal getTotalEstimatedCost() {
		return totalEstimatedCost;
	}

	public final void setTotalEstimatedCost(BigDecimal totalEstimatedCost) {
		this.totalEstimatedCost = totalEstimatedCost;
	}

	public final BigDecimal getTotalBilledAmt() {
		return totalBilledAmt;
	}

	public final void setTotalBilledAmt(BigDecimal totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

	public final String getHoldPaymentInd() {
		return holdPaymentInd;
	}

	public final void setHoldPaymentInd(String holdPaymentInd) {
		this.holdPaymentInd = holdPaymentInd;
	}

	public final Date getHoldPaymentDate() {
		return holdPaymentDate;
	}

	public final void setHoldPaymentDate(Date holdPaymentDate) {
		this.holdPaymentDate = holdPaymentDate;
	}

	public final String getReleaseHoldPaymentInd() {
		return releaseHoldPaymentInd;
	}

	public final void setReleaseHoldPaymentInd(String releaseHoldPaymentInd) {
		this.releaseHoldPaymentInd = releaseHoldPaymentInd;
	}

	public final Date getReleaseHoldPaymentDate() {
		return releaseHoldPaymentDate;
	}

	public final void setReleaseHoldPaymentDate(Date releaseHoldPaymentDate) {
		this.releaseHoldPaymentDate = releaseHoldPaymentDate;
	}

	public String getInitialPhase() {
		return initialPhase;
	}

	public void setInitialPhase(String initialPhase) {
		this.initialPhase = initialPhase;
	}

	public final String getPhase() {
		return phase;
	}

	public final void setPhase(String phase) {
		this.phase = phase;
	}

	public final Long getCaseId() {
		return caseId;
	}

	public final void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public final String getBatchNo() {
		return batchNo;
	}

	public final void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public final String getCreatedBy() {
		return createdBy;
	}

	public final void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public final String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public final void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public final Date getCreatedDt() {
		return createdDt;
	}

	public final void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public final Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public final void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public Date getPlannedHospitalizationDate() {
		return plannedHospitalizationDate;
	}

	public void setPlannedHospitalizationDate(Date plannedHospitalizationDate) {
		this.plannedHospitalizationDate = plannedHospitalizationDate;
	}

	public Date getPlannedDischargeDate() {
		return plannedDischargeDate;
	}

	public void setPlannedDischargeDate(Date plannedDischargeDate) {
		this.plannedDischargeDate = plannedDischargeDate;
	}

	public Date getPlannedIcuAdmissionDate() {
		return plannedIcuAdmissionDate;
	}

	public void setPlannedIcuAdmissionDate(Date plannedIcuAdmissionDate) {
		this.plannedIcuAdmissionDate = plannedIcuAdmissionDate;
	}

	public Date getPlannedIcuDischargeDate() {
		return plannedIcuDischargeDate;
	}

	public void setPlannedIcuDischargeDate(Date plannedIcuDischargeDate) {
		this.plannedIcuDischargeDate = plannedIcuDischargeDate;
	}

	public String getSubmissionAgentName() {
		return submissionAgentName;
	}

	public void setSubmissionAgentName(String submissionAgentName) {
		this.submissionAgentName = submissionAgentName;
	}

	public String getSubmissionAgencyName() {
		return submissionAgencyName;
	}

	public void setSubmissionAgencyName(String submissionAgencyName) {
		this.submissionAgencyName = submissionAgencyName;
	}

	public String getSubmissionOfficeName() {
		return submissionOfficeName;
	}

	public void setSubmissionOfficeName(String submissionOfficeName) {
		this.submissionOfficeName = submissionOfficeName;
	}

	public String getSubmissionAgencyLeaderName() {
		return submissionAgencyLeaderName;
	}

	public void setSubmissionAgencyLeaderName(String submissionAgencyLeaderName) {
		this.submissionAgencyLeaderName = submissionAgencyLeaderName;
	}

	public String getWritingAgencyLeaderName() {
		return writingAgencyLeaderName;
	}

	public void setWritingAgencyLeaderName(String writingAgencyLeaderName) {
		this.writingAgencyLeaderName = writingAgencyLeaderName;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public Boolean getAiOnly() {
		return aiOnly;
	}

	public void setAiOnly(Boolean aiOnly) {
		this.aiOnly = aiOnly;
	}

	public boolean isQuotationClaim() {
		return quotationClaim;
	}

	public void setQuotationClaim(boolean quotationClaim) {
		this.quotationClaim = quotationClaim;
	}

	public boolean isStp() {
		return stp;
	}

	public void setStp(boolean stp) {
		this.stp = stp;
	}

	public String getIpdStpFlag() {
		return ipdStpFlag;
	}

	public void setIpdStpFlag(String ipdStpFlag) {
		this.ipdStpFlag = ipdStpFlag;
	}

	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

	public String getHn() {
		return hn;
	}

	public void setHn(String hn) {
		this.hn = hn;
	}

	public String getAn() {
		return an;
	}

	public void setAn(String an) {
		this.an = an;
	}

	public BigDecimal getCsHBAmt() {
		return csHBAmt;
	}

	public void setCsHBAmt(BigDecimal csHBAmt) {
		this.csHBAmt = csHBAmt;
	}

	public boolean isFurther() {
		return isFurther;
	}

	public void setFurther(boolean isFurther) {
		this.isFurther = isFurther;
	}

	public String getMdrt() {
		return mdrt;
	}

	public void setMdrt(String mdrt) {
		this.mdrt = mdrt;
	}

	public String getBbl() {
		return bbl;
	}

	public void setBbl(String bbl) {
		this.bbl = bbl;
	}

	public String getEdiInd() {
		return ediInd;
	}

	public void setEdiInd(String ediInd) {
		this.ediInd = ediInd;
	}

	public String getIpdDrug() {
		return ipdDrug;
	}

	public void setIpdDrug(String ipdDrug) {
		this.ipdDrug = ipdDrug;
	}

	public String getClaimCriticalIllnesss() {
		return claimCriticalIllnesss;
	}

	public void setClaimCriticalIllnesss(String claimCriticalIllnesss) {
		this.claimCriticalIllnesss = claimCriticalIllnesss;
	}

	public String getStpInd() {
		return stpInd;
	}

	public void setStpInd(String stpInd) {
		this.stpInd = stpInd;
	}

	public String getInterestInd() {
		return interestInd;
	}

	public void setInterestInd(String interestInd) {
		this.interestInd = interestInd;
	}

	public Date getDocumentInTime() {
		return documentInTime;
	}

	public void setDocumentInTime(Date documentInTime) {
		this.documentInTime = documentInTime;
	}

	public String getCleanInd() {
		return cleanInd;
	}

	public void setCleanInd(String cleanInd) {
		this.cleanInd = cleanInd;
	}

	/**
	 * @return the firstAdmitDt
	 */
	public Date getFirstAdmitDt() {
		return firstAdmitDt;
	}

	/**
	 * @param firstAdmitDt the firstAdmitDt to set
	 */
	public void setFirstAdmitDt(Date firstAdmitDt) {
		this.firstAdmitDt = firstAdmitDt;
	}

	/**
	 * @return the ptcall
	 */
	public Integer getPtcall() {
		return ptcall;
	}

	/**
	 * @param ptcall the ptcall to set
	 */
	public void setPtcall(Integer ptcall) {
		this.ptcall = ptcall;
	}

	public final String getDataPrivacyConsent() {
		return dataPrivacyConsent;
	}

	public final void setDataPrivacyConsent(String dataPrivacyConsent) {
		this.dataPrivacyConsent = dataPrivacyConsent;
	}

	public String getDataPrivacyConsentDate() {
		return dataPrivacyConsentDate;
	}

	public void setDataPrivacyConsentDate(String dataPrivacyConsentDate) {
		this.dataPrivacyConsentDate = dataPrivacyConsentDate;
	}

	public String getAiInd() {
		return aiInd;
	}

	public void setAiInd(String aiInd) {
		this.aiInd = aiInd;
	}

	public String getAiBillingStatus() {
		return aiBillingStatus;
	}

	public String getAiBillingDeclineReason() {
		return aiBillingDeclineReason;
	}

	public String getAiVersion() {
		return aiVersion;
	}

	public void setAiBillingStatus(String aiBillingStatus) {
		this.aiBillingStatus = aiBillingStatus;
	}

	public void setAiBillingDeclineReason(String aiBillingDeclineReason) {
		this.aiBillingDeclineReason = aiBillingDeclineReason;
	}

	public void setAiVersion(String aiVersion) {
		this.aiVersion = aiVersion;
	}
	
	

}
