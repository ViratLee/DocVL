package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

public class HNWDeduct {
  private Long hnwDeductId;
  private String claimDeductNo;
  private Long caseId;
  private String claimNo;
  private Integer occurrence;
  private String policyNo;
  private String certNo;
  private String firstName;
  private String lastName;
  private String claimantName;
  private Date receivedDate;
  private Date accidentDt;
  private Date hospitalizationDate;
  private Date policyYearFromDt;
  private Date policyYearToDt;
  private Date dischargeDate;
  private Date icuAdmissionDate;
  private Date icuDischargeDate;
  private String typeOfTreat;
  private String typeOfTreatDesc;
  private String causeOfTreat;
  private String causeOfTreatDesc;
  private BigDecimal amount;
  private String confirm;
  private String exclude;
  private String memberId;
  private Long partyId;
  private String businessLine;
  private String submissionSource;
  private String providerCode;
  private String providerNameThai;

  
  

public Long getCaseId() {
	return caseId;
}



public void setCaseId(Long caseId) {
	this.caseId = caseId;
}



public Long getHnwDeductId() {
	return hnwDeductId;
}



public String getClaimDeductNo() {
	return claimDeductNo;
}



public String getClaimNo() {
	return claimNo;
}



public Integer getOccurrence() {
	return occurrence;
}



public String getPolicyNo() {
	return policyNo;
}



public String getCertNo() {
	return certNo;
}



public String getFirstName() {
	return firstName;
}



public String getLastName() {
	return lastName;
}



public String getClaimantName() {
	return claimantName;
}



public Date getReceivedDate() {
	return receivedDate;
}



public Date getAccidentDt() {
	return accidentDt;
}



public Date getHospitalizationDate() {
	return hospitalizationDate;
}



public Date getPolicyYearFromDt() {
	return policyYearFromDt;
}



public Date getPolicyYearToDt() {
	return policyYearToDt;
}



public Date getDischargeDate() {
	return dischargeDate;
}



public Date getIcuAdmissionDate() {
	return icuAdmissionDate;
}



public Date getIcuDischargeDate() {
	return icuDischargeDate;
}



public String getTypeOfTreat() {
	return typeOfTreat;
}



public String getTypeOfTreatDesc() {
	return typeOfTreatDesc;
}



public String getCauseOfTreat() {
	return causeOfTreat;
}



public String getCauseOfTreatDesc() {
	return causeOfTreatDesc;
}



public BigDecimal getAmount() {
	return amount;
}



public String getConfirm() {
	return confirm;
}



public String getExclude() {
	return exclude;
}



public String getMemberId() {
	return memberId;
}



public Long getPartyId() {
	return partyId;
}



public String getBusinessLine() {
	return businessLine;
}



public String getSubmissionSource() {
	return submissionSource;
}



public void setHnwDeductId(Long hnwDeductId) {
	this.hnwDeductId = hnwDeductId;
}



public void setClaimDeductNo(String claimDeductNo) {
	this.claimDeductNo = claimDeductNo;
}



public void setClaimNo(String claimNo) {
	this.claimNo = claimNo;
}



public void setOccurrence(Integer occurrence) {
	this.occurrence = occurrence;
}



public void setPolicyNo(String policyNo) {
	this.policyNo = policyNo;
}



public void setCertNo(String certNo) {
	this.certNo = certNo;
}



public void setFirstName(String firstName) {
	this.firstName = firstName;
}



public void setLastName(String lastName) {
	this.lastName = lastName;
}



public void setClaimantName(String claimantName) {
	this.claimantName = claimantName;
}



public void setReceivedDate(Date receivedDate) {
	this.receivedDate = receivedDate;
}



public void setAccidentDt(Date accidentDt) {
	this.accidentDt = accidentDt;
}



public void setHospitalizationDate(Date hospitalizationDate) {
	this.hospitalizationDate = hospitalizationDate;
}



public void setPolicyYearFromDt(Date policyYearFromDt) {
	this.policyYearFromDt = policyYearFromDt;
}



public void setPolicyYearToDt(Date policyYearToDt) {
	this.policyYearToDt = policyYearToDt;
}



public void setDischargeDate(Date dischargeDate) {
	this.dischargeDate = dischargeDate;
}



public void setIcuAdmissionDate(Date icuAdmissionDate) {
	this.icuAdmissionDate = icuAdmissionDate;
}



public void setIcuDischargeDate(Date icuDischargeDate) {
	this.icuDischargeDate = icuDischargeDate;
}



public void setTypeOfTreat(String typeOfTreat) {
	this.typeOfTreat = typeOfTreat;
}



public void setTypeOfTreatDesc(String typeOfTreatDesc) {
	this.typeOfTreatDesc = typeOfTreatDesc;
}



public void setCauseOfTreat(String causeOfTreat) {
	this.causeOfTreat = causeOfTreat;
}



public void setCauseOfTreatDesc(String causeOfTreatDesc) {
	this.causeOfTreatDesc = causeOfTreatDesc;
}



public void setAmount(BigDecimal amount) {
	this.amount = amount;
}



public void setConfirm(String confirm) {
	this.confirm = confirm;
}



public void setExclude(String exclude) {
	this.exclude = exclude;
}



public void setMemberId(String memberId) {
	this.memberId = memberId;
}



public void setPartyId(Long partyId) {
	this.partyId = partyId;
}



public void setBusinessLine(String businessLine) {
	this.businessLine = businessLine;
}



public void setSubmissionSource(String submissionSource) {
	this.submissionSource = submissionSource;
}


public String getProviderCode() {
	return providerCode;
}



public String getProviderNameThai() {
	return providerNameThai;
}



public void setProviderCode(String providerCode) {
	this.providerCode = providerCode;
}



public void setProviderNameThai(String providerNameThai) {
	this.providerNameThai = providerNameThai;
}



@Override
public String toString()
{
  return ToStringBuilder.reflectionToString(this);
}
  
}
