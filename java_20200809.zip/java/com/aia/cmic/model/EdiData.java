package com.aia.cmic.model;

import java.util.List;

public class EdiData {

	private List<EdiBillingItem> ediBillingItems;
	private List<EdiDoctor> ediDoctors;
	private List<EdiLaboratory> ediLaboratory;
	private List<EdiOrderItem> ediOrderItem;
	private List<EdiProcedure> ediProcedure;
	private List<EdiVitalSigns> ediVitalSigns;

	public List<EdiBillingItem> getEdiBillingItems() {
		return ediBillingItems;
	}

	public void setEdiBillingItems(List<EdiBillingItem> ediBillingItems) {
		this.ediBillingItems = ediBillingItems;
	}

	public List<EdiDoctor> getEdiDoctors() {
		return ediDoctors;
	}

	public void setEdiDoctors(List<EdiDoctor> ediDoctors) {
		this.ediDoctors = ediDoctors;
	}

	public List<EdiLaboratory> getEdiLaboratory() {
		return ediLaboratory;
	}

	public void setEdiLaboratory(List<EdiLaboratory> ediLaboratory) {
		this.ediLaboratory = ediLaboratory;
	}

	public List<EdiOrderItem> getEdiOrderItem() {
		return ediOrderItem;
	}

	public void setEdiOrderItem(List<EdiOrderItem> ediOrderItem) {
		this.ediOrderItem = ediOrderItem;
	}

	public List<EdiProcedure> getEdiProcedure() {
		return ediProcedure;
	}

	public void setEdiProcedure(List<EdiProcedure> ediProcedure) {
		this.ediProcedure = ediProcedure;
	}

	public List<EdiVitalSigns> getEdiVitalSigns() {
		return ediVitalSigns;
	}

	public void setEdiVitalSigns(List<EdiVitalSigns> ediVitalSigns) {
		this.ediVitalSigns = ediVitalSigns;
	}

}
