package com.aia.cmic.model;

import java.util.Date;

public class CaseDataEntry extends BaseCaseData {
	private String agencyCodeServicing;
	private String agentCodeServicing;
	private String dofurther;
	private Boolean aiOnly;
	private String partyId;
	private String icd10;
	private String policyNo;
	private String certificateNumber;

	private Date dob;
	private String lastName;
	private String firstName;
	private String nationalId;
	private String policyOwner;

	private String deleteInd;
	private boolean stp = false;
	private String ipdStpFlag;

	private String eligibilityLevel = "1";
	private Long policyOwnerPartyId;
	private String gender;

	private String qoutationClaimNo;

	private String riskLevel;

	private String dependentNo;
	private String dependentType;
	private String memberLastName;
	private String memberFirstName;

	private String updateFlag = "C";
	private Integer occurence;
	
	private String subofficeCode ;
	private String businessLine ;

	public String getEligibilityLevel() {
		return eligibilityLevel;
	}

	public void setEligibilityLevel(String eligibilityLevel) {
		this.eligibilityLevel = eligibilityLevel;
	}

	public String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	/**
	 * @return the dofurther
	 */
	public String getDofurther() {
		return dofurther;
	}

	/**
	 * @param dofurther
	 *            the dofurther to set
	 */
	public void setDofurther(String dofurther) {
		this.dofurther = dofurther;
	}

	public Boolean getAiOnly() {
		return aiOnly;
	}

	public void setAiOnly(Boolean aiOnly) {
		this.aiOnly = aiOnly;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getIcd10() {
		return icd10;
	}

	public void setIcd10(String icd10) {
		this.icd10 = icd10;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getPolicyOwner() {
		return policyOwner;
	}

	public void setPolicyOwner(String policyOwner) {
		this.policyOwner = policyOwner;
	}

	public String getDeleteInd() {
		return deleteInd;
	}

	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getPolicyOwnerPartyId() {
		return policyOwnerPartyId;
	}

	public void setPolicyOwnerPartyId(Long policyOwnerPartyId) {
		this.policyOwnerPartyId = policyOwnerPartyId;
	}

	public boolean isStp() {
		return stp;
	}

	public void setStp(boolean stp) {
		this.stp = stp;
	}

	public String getIpdStpFlag() {
		return ipdStpFlag;
	}

	public void setIpdStpFlag(String ipdStpFlag) {
		this.ipdStpFlag = ipdStpFlag;
	}

	public String getCertificateNumber() {
		return certificateNumber;
	}

	public void setCertificateNumber(String certificateNumber) {
		this.certificateNumber = certificateNumber;
	}

	public String getQoutationClaimNo() {
		return qoutationClaimNo;
	}

	public void setQoutationClaimNo(String qoutationClaimNo) {
		this.qoutationClaimNo = qoutationClaimNo;
	}

	public String getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getDependentType() {
		return dependentType;
	}

	public void setDependentType(String dependentType) {
		this.dependentType = dependentType;
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public String getUpdateFlag() {
		return updateFlag;
	}

	public void setUpdateFlag(String updateFlag) {
		this.updateFlag = updateFlag;
	}

	public Integer getOccurence() {
		return occurence;
	}

	public void setOccurence(Integer occurence) {
		this.occurence = occurence;
	}

	public String getSubofficeCode() {
		return subofficeCode;
	}

	public void setSubofficeCode(String subofficeCode) {
		this.subofficeCode = subofficeCode;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

}
