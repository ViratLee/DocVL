package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class ValidationReportResult {
	private String claimRulesLogId;
	private String claimNo;
	private String occurrenceNo;
	private Date settleDate;
	private String policyNo;
	private String planName;
	private String code;
	private String desc;
	private BigDecimal amount;
	private String approval;
	private String review;
	private String actionTaken;
	private Lookup reviewLookup;
	private Lookup actionTakenLookup;
	private String reviewer;
	private Date lastUpdate;
	private Long rownum;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getOccurrenceNo() {
		return occurrenceNo;
	}

	public void setOccurrenceNo(String occurrenceNo) {
		this.occurrenceNo = occurrenceNo;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getApproval() {
		return approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getClaimRulesLogId() {
		return claimRulesLogId;
	}

	public void setClaimRulesLogId(String claimRulesLogId) {
		this.claimRulesLogId = claimRulesLogId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public Lookup getReviewLookup() {
		return reviewLookup;
	}

	public void setReviewLookup(Lookup reviewLookup) {
		this.reviewLookup = reviewLookup;
	}

	public Lookup getActionTakenLookup() {
		return actionTakenLookup;
	}

	public void setActionTakenLookup(Lookup actionTakenLookup) {
		this.actionTakenLookup = actionTakenLookup;
	}

	public Long getRownum() {
		return rownum;
	}

	public void setRownum(Long rownum) {
		this.rownum = rownum;
	}

}
