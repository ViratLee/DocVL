package com.aia.cmic.model;

import java.util.Date;

public class InstitutionForm {

	//General Information
	private String providerID;
	private String providerStatus;
	private String providerNameTH;
	private String providerNameEN;
	private String registeredNameTH;
	private String registeredNameEN;
	private String providerGroup;
	private String providerType;
	private String providerTypeSector;
	private Date registrationEffectiveDate;
	private Date registrationTerminationDate;
	private Date startOperationDate;
	private String registeredBed;
	private String operatedBed;
	private String icuBed;
	private String icuRoom;
	private String examinationRoom;

	private String[] codingUsed;
	private String[] serviceProvided;
	private String[] medicalSpecialty;
	private String[] awardAndAccreditation;
	private String aiaQualityTier;
	private String providerAffordabilityTier;
	private String iaScore;
	private String servicePriority;
	private String[] otherInsuranceParticipation;
	private String prioritizeFaxClaimScore;

	//Black List
	private String blacklistIndicator;
	private Date startDate;
	private Date endDate;
	private String blacklistReason;
	private String[] cmacWarningCode;

	private String[] holdServices;
	private AddressForm addressForm;
	private ContactForm[] contactForm;

	//Payment Detail
	private String payeeName;
	private String bankAccount;
	private String bankCode;
	private String paymentCycle;
	private String paymentMethod;

	private DocumentForm[] documentForm;

	public String getProviderID() {
		return providerID;
	}

	public void setProviderID(String providerID) {
		this.providerID = providerID;
	}

	public String getProviderStatus() {
		return providerStatus;
	}

	public void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	public String getProviderNameTH() {
		return providerNameTH;
	}

	public void setProviderNameTH(String providerNameTH) {
		this.providerNameTH = providerNameTH;
	}

	public String getProviderNameEN() {
		return providerNameEN;
	}

	public void setProviderNameEN(String providerNameEN) {
		this.providerNameEN = providerNameEN;
	}

	public String getRegisteredNameTH() {
		return registeredNameTH;
	}

	public void setRegisteredNameTH(String registeredNameTH) {
		this.registeredNameTH = registeredNameTH;
	}

	public String getRegisteredNameEN() {
		return registeredNameEN;
	}

	public void setRegisteredNameEN(String registeredNameEN) {
		this.registeredNameEN = registeredNameEN;
	}

	public String getProviderGroup() {
		return providerGroup;
	}

	public void setProviderGroup(String providerGroup) {
		this.providerGroup = providerGroup;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getProviderTypeSector() {
		return providerTypeSector;
	}

	public void setProviderTypeSector(String providerTypeSector) {
		this.providerTypeSector = providerTypeSector;
	}

	public Date getRegistrationEffectiveDate() {
		return registrationEffectiveDate;
	}

	public void setRegistrationEffectiveDate(Date registrationEffectiveDate) {
		this.registrationEffectiveDate = registrationEffectiveDate;
	}

	public Date getRegistrationTerminationDate() {
		return registrationTerminationDate;
	}

	public void setRegistrationTerminationDate(Date registrationTerminationDate) {
		this.registrationTerminationDate = registrationTerminationDate;
	}

	public Date getStartOperationDate() {
		return startOperationDate;
	}

	public void setStartOperationDate(Date startOperationDate) {
		this.startOperationDate = startOperationDate;
	}

	public String getRegisteredBed() {
		return registeredBed;
	}

	public void setRegisteredBed(String registeredBed) {
		this.registeredBed = registeredBed;
	}

	public String getOperatedBed() {
		return operatedBed;
	}

	public void setOperatedBed(String operatedBed) {
		this.operatedBed = operatedBed;
	}

	public String getIcuBed() {
		return icuBed;
	}

	public void setIcuBed(String icuBed) {
		this.icuBed = icuBed;
	}

	public String getIcuRoom() {
		return icuRoom;
	}

	public void setIcuRoom(String icuRoom) {
		this.icuRoom = icuRoom;
	}

	public String getExaminationRoom() {
		return examinationRoom;
	}

	public void setExaminationRoom(String examinationRoom) {
		this.examinationRoom = examinationRoom;
	}

	public String[] getCodingUsed() {
		return codingUsed;
	}

	public void setCodingUsed(String[] codingUsed) {
		this.codingUsed = codingUsed;
	}

	public String[] getServiceProvided() {
		return serviceProvided;
	}

	public void setServiceProvided(String[] serviceProvided) {
		this.serviceProvided = serviceProvided;
	}

	public String[] getMedicalSpecialty() {
		return medicalSpecialty;
	}

	public void setMedicalSpecialty(String[] medicalSpecialty) {
		this.medicalSpecialty = medicalSpecialty;
	}

	public String[] getAwardAndAccreditation() {
		return awardAndAccreditation;
	}

	public void setAwardAndAccreditation(String[] awardAndAccreditation) {
		this.awardAndAccreditation = awardAndAccreditation;
	}

	public String getAiaQualityTier() {
		return aiaQualityTier;
	}

	public void setAiaQualityTier(String aiaQualityTier) {
		this.aiaQualityTier = aiaQualityTier;
	}

	public String getProviderAffordabilityTier() {
		return providerAffordabilityTier;
	}

	public void setProviderAffordabilityTier(String providerAffordabilityTier) {
		this.providerAffordabilityTier = providerAffordabilityTier;
	}

	public String getIaScore() {
		return iaScore;
	}

	public void setIaScore(String iaScore) {
		this.iaScore = iaScore;
	}

	public String getServicePriority() {
		return servicePriority;
	}

	public void setServicePriority(String servicePriority) {
		this.servicePriority = servicePriority;
	}

	public String[] getOtherInsuranceParticipation() {
		return otherInsuranceParticipation;
	}

	public void setOtherInsuranceParticipation(String[] otherInsuranceParticipation) {
		this.otherInsuranceParticipation = otherInsuranceParticipation;
	}

	public String getPrioritizeFaxClaimScore() {
		return prioritizeFaxClaimScore;
	}

	public void setPrioritizeFaxClaimScore(String prioritizeFaxClaimScore) {
		this.prioritizeFaxClaimScore = prioritizeFaxClaimScore;
	}

	public String getBlacklistIndicator() {
		return blacklistIndicator;
	}

	public void setBlacklistIndicator(String blacklistIndicator) {
		this.blacklistIndicator = blacklistIndicator;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getBlacklistReason() {
		return blacklistReason;
	}

	public void setBlacklistReason(String blacklistReason) {
		this.blacklistReason = blacklistReason;
	}

	public String[] getCmacWarningCode() {
		return cmacWarningCode;
	}

	public void setCmacWarningCode(String[] cmacWarningCode) {
		this.cmacWarningCode = cmacWarningCode;
	}

	public String[] getHoldServices() {
		return holdServices;
	}

	public void setHoldServices(String[] holdServices) {
		this.holdServices = holdServices;
	}

	public AddressForm getAddressForm() {
		return addressForm;
	}

	public void setAddressForm(AddressForm addressForm) {
		this.addressForm = addressForm;
	}

	public ContactForm[] getContactForm() {
		return contactForm;
	}

	public void setContactForm(ContactForm[] contactForm) {
		this.contactForm = contactForm;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getPaymentCycle() {
		return paymentCycle;
	}

	public void setPaymentCycle(String paymentCycle) {
		this.paymentCycle = paymentCycle;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public DocumentForm[] getDocumentForm() {
		return documentForm;
	}

	public void setDocumentForm(DocumentForm[] documentForm) {
		this.documentForm = documentForm;
	}

}
