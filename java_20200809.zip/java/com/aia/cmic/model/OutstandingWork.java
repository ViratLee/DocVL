package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class OutstandingWork {

	private String policyNo;
	private String submissionDate;
	private String pendingDate;
	private String claimStatus;
	private String claimNumber;
	private String certNo;
	private String memberId;
	private String firstName;
	private String lastName;
	private String insuredName;
	private String accidentDate;
	private String inHospitalDate;
	private String hospitalName;
	private String claimType;
	private String benefitType;
	private String lastUser;
	private String activity;

	private long caseId;
	private boolean urgent;
	private boolean vip;
	private String slaDt;
	private String receivedDate;

	private String risk;
	private String fyi;
	private String phase;
	private Integer aging;
	private String comment;
	private String previousUser;
	private String owner;

	private boolean bbl;
	private String mdrt;
	private String edi;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getBenefitType() {
		return benefitType;
	}

	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}

	public String getLastUser() {
		return lastUser;
	}

	public void setLastUser(String lastUser) {
		this.lastUser = lastUser;
	}

	public long getCaseId() {
		return caseId;
	}

	public void setCaseId(long caseId) {
		this.caseId = caseId;
	}

	public boolean isUrgent() {
		return urgent;
	}

	public void setUrgent(boolean urgent) {
		this.urgent = urgent;
	}

	public boolean isVip() {
		return vip;
	}

	public void setVip(boolean vip) {
		this.vip = vip;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getPendingDate() {
		return pendingDate;
	}

	public void setPendingDate(String pendingDate) {
		this.pendingDate = pendingDate;
	}

	public String getAccidentDate() {
		return accidentDate;
	}

	public void setAccidentDate(String accidentDate) {
		this.accidentDate = accidentDate;
	}

	public String getInHospitalDate() {
		return inHospitalDate;
	}

	public void setInHospitalDate(String inHospitalDate) {
		this.inHospitalDate = inHospitalDate;
	}

	public String getSlaDt() {
		return slaDt;
	}

	public void setSlaDt(String slaDt) {
		this.slaDt = slaDt;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getRisk() {
		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public Integer getAging() {
		return aging;
	}

	public void setAging(Integer aging) {
		this.aging = aging;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPreviousUser() {
		return previousUser;
	}

	public void setPreviousUser(String previousUser) {
		this.previousUser = previousUser;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getFyi() {
		return fyi;
	}

	public void setFyi(String fyi) {
		this.fyi = fyi;
	}


	public String getMdrt() {
		return mdrt;
	}

	public void setMdrt(String mdrt) {
		this.mdrt = mdrt;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public boolean isBbl() {
		return bbl;
	}

	public void setBbl(boolean bbl) {
		this.bbl = bbl;
	}

	public String getEdi() {
		return edi;
	}

	public void setEdi(String edi) {
		this.edi = edi;
	}
	
	
	
}
