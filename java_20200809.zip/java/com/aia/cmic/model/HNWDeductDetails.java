package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import com.aia.cmic.model.HNWBenefitCode;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * @author ASNPATD
 *
 */
public class HNWDeductDetails {
	
	private Integer hnwDeductId;
	private String hnwDeductClaimNo;
	private Integer hnwDeductOccurrence;
	private String hnwDeductpolicyNo;
	private String hnwDeductCertNo;
	private String hnwDeductClaimant;
	private Date hnwDeductAccidentDt; 
	private Date hnwDeductInHospDiscDt;
	private String hnwDeductTypeOfTreatment;
	private String hnwDeductCauseOfTreatment;
	private BigDecimal hnwDeductAmount;
	private String hnwDeductConfirm; 
	private String hnwDeductExclude; 
	
	private String hnwDeductClaimForm;
	private String hnwDeductmemNo;
	private String hnwDeductmedInst;
	private Date hnwDeductHospFrom;
	private Date hnwDeductHospTo;
	private Date hnwDeductICUFrom;
	private Date hnwDeductICUTo;
	
	private List<HNWBenefitCode> hnwBenefitCodeList;
	
	

	public Integer getHnwDeductId() {
		return hnwDeductId;
	}



	public String getHnwDeductClaimNo() {
		return hnwDeductClaimNo;
	}



	public Integer getHnwDeductOccurrence() {
		return hnwDeductOccurrence;
	}



	public String getHnwDeductpolicyNo() {
		return hnwDeductpolicyNo;
	}



	public String getHnwDeductCertNo() {
		return hnwDeductCertNo;
	}



	public String getHnwDeductClaimant() {
		return hnwDeductClaimant;
	}



	public Date getHnwDeductAccidentDt() {
		return hnwDeductAccidentDt;
	}



	public Date getHnwDeductInHospDiscDt() {
		return hnwDeductInHospDiscDt;
	}



	public String getHnwDeductTypeOfTreatment() {
		return hnwDeductTypeOfTreatment;
	}



	public String getHnwDeductCauseOfTreatment() {
		return hnwDeductCauseOfTreatment;
	}



	public BigDecimal getHnwDeductAmount() {
		return hnwDeductAmount;
	}



	public String getHnwDeductConfirm() {
		return hnwDeductConfirm;
	}



	public String getHnwDeductExclude() {
		return hnwDeductExclude;
	}



	public String getHnwDeductClaimForm() {
		return hnwDeductClaimForm;
	}



	public String getHnwDeductmemNo() {
		return hnwDeductmemNo;
	}



	public String getHnwDeductmedInst() {
		return hnwDeductmedInst;
	}



	public Date getHnwDeductHospFrom() {
		return hnwDeductHospFrom;
	}



	public Date getHnwDeductHospTo() {
		return hnwDeductHospTo;
	}



	public Date getHnwDeductICUFrom() {
		return hnwDeductICUFrom;
	}



	public Date getHnwDeductICUTo() {
		return hnwDeductICUTo;
	}



	public List<HNWBenefitCode> getHnwBenefitCodeList() {
		return hnwBenefitCodeList;
	}



	public void setHnwDeductId(Integer hnwDeductId) {
		this.hnwDeductId = hnwDeductId;
	}



	public void setHnwDeductClaimNo(String hnwDeductClaimNo) {
		this.hnwDeductClaimNo = hnwDeductClaimNo;
	}



	public void setHnwDeductOccurrence(Integer hnwDeductOccurrence) {
		this.hnwDeductOccurrence = hnwDeductOccurrence;
	}



	public void setHnwDeductpolicyNo(String hnwDeductpolicyNo) {
		this.hnwDeductpolicyNo = hnwDeductpolicyNo;
	}



	public void setHnwDeductCertNo(String hnwDeductCertNo) {
		this.hnwDeductCertNo = hnwDeductCertNo;
	}



	public void setHnwDeductClaimant(String hnwDeductClaimant) {
		this.hnwDeductClaimant = hnwDeductClaimant;
	}



	public void setHnwDeductAccidentDt(Date hnwDeductAccidentDt) {
		this.hnwDeductAccidentDt = hnwDeductAccidentDt;
	}



	public void setHnwDeductInHospDiscDt(Date hnwDeductInHospDiscDt) {
		this.hnwDeductInHospDiscDt = hnwDeductInHospDiscDt;
	}



	public void setHnwDeductTypeOfTreatment(String hnwDeductTypeOfTreatment) {
		this.hnwDeductTypeOfTreatment = hnwDeductTypeOfTreatment;
	}



	public void setHnwDeductCauseOfTreatment(String hnwDeductCauseOfTreatment) {
		this.hnwDeductCauseOfTreatment = hnwDeductCauseOfTreatment;
	}



	public void setHnwDeductAmount(BigDecimal hnwDeductAmount) {
		this.hnwDeductAmount = hnwDeductAmount;
	}



	public void setHnwDeductConfirm(String hnwDeductConfirm) {
		this.hnwDeductConfirm = hnwDeductConfirm;
	}



	public void setHnwDeductExclude(String hnwDeductExclude) {
		this.hnwDeductExclude = hnwDeductExclude;
	}



	public void setHnwDeductClaimForm(String hnwDeductClaimForm) {
		this.hnwDeductClaimForm = hnwDeductClaimForm;
	}



	public void setHnwDeductmemNo(String hnwDeductmemNo) {
		this.hnwDeductmemNo = hnwDeductmemNo;
	}



	public void setHnwDeductmedInst(String hnwDeductmedInst) {
		this.hnwDeductmedInst = hnwDeductmedInst;
	}



	public void setHnwDeductHospFrom(Date hnwDeductHospFrom) {
		this.hnwDeductHospFrom = hnwDeductHospFrom;
	}



	public void setHnwDeductHospTo(Date hnwDeductHospTo) {
		this.hnwDeductHospTo = hnwDeductHospTo;
	}



	public void setHnwDeductICUFrom(Date hnwDeductICUFrom) {
		this.hnwDeductICUFrom = hnwDeductICUFrom;
	}



	public void setHnwDeductICUTo(Date hnwDeductICUTo) {
		this.hnwDeductICUTo = hnwDeductICUTo;
	}



	public void setHnwBenefitCodeList(List<HNWBenefitCode> hnwBenefitCodeList) {
		this.hnwBenefitCodeList = hnwBenefitCodeList;
	}



	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
}
