package com.aia.cmic.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.aia.cmic.entity.Provider;

public class ProviderSearchResultForm {
	private String providerCode;
	private String providerName;
	private String providerType;
	private String providerTypeSector;
	private String province;
	private String region;
	private String telephone;
	private String fax;
	private String email;
	private String contract;
	private String providerStatus;
	private int page = 1;
	private int pageSize = 10;

	public ProviderSearchResultForm(ProviderSearchForm form, Provider provider) {
		this.providerCode = provider.getProviderCode();
		this.providerName = provider.getProviderNameThai();
		this.providerType = provider.getProviderType();
		this.providerTypeSector = provider.getProviderTypeSector();
	}

	public final String getProviderCode() {
		return providerCode;
	}

	public final void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public final String getProviderName() {
		return providerName;
	}

	public final void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public final String getProviderType() {
		return providerType;
	}

	public final void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public final String getProviderTypeSector() {
		return providerTypeSector;
	}

	public final void setProviderTypeSector(String providerTypeSector) {
		this.providerTypeSector = providerTypeSector;
	}

	public final String getProvince() {
		return province;
	}

	public final void setProvince(String province) {
		this.province = province;
	}

	public final String getRegion() {
		return region;
	}

	public final void setRegion(String region) {
		this.region = region;
	}

	public final String getTelephone() {
		return telephone;
	}

	public final void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public final String getFax() {
		return fax;
	}

	public final void setFax(String fax) {
		this.fax = fax;
	}

	public final String getEmail() {
		return email;
	}

	public final void setEmail(String email) {
		this.email = email;
	}

	public final String getContract() {
		return contract;
	}

	public final void setContract(String contract) {
		this.contract = contract;
	}

	public final String getProviderStatus() {
		return providerStatus;
	}

	public final void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	public final int getPage() {
		return page;
	}

	public final void setPage(int page) {
		this.page = page;
	}

	public final int getPageSize() {
		return pageSize;
	}

	public final void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
