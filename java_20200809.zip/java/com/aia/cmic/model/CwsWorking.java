package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.xml.bind.annotation.XmlElement;

public class CwsWorking {

	Long cwsWorkingId;

	Date cycleDate;

	String companyId;

	String claimNo;

	Integer occurrence;

	Date transactionDt;

	String policyNo;

	String businessLine;

	String productCode;

	String keyPolicyNo;

	BigDecimal transactionAmt;

	String collectionMethod;

	String providerCode;

	String payeeTitle;

	String payeeLastName;

	String payeeFirstName;

	String addressLine1;

	String addressLine2;

	String addressLine3;

	String addressLine4;

	String city;

	String state;

	String postalCode;

	String country;

	String insuredTitle;

	String insuredLastName;

	String insuredFirstName;

	String mediaClearingInd;

	String bankruptcyInd;

	String amloInd;

	String blacklistInd;

	String absoluteAssignInd;

	String suppressChequeInd;

	String servicingAgencyOfficeCode;

	String agencyCodeServicing;

	String agencyWritingCode;

	String agentCodeServicing;

	String agentWritingCode;

	String pickUpChqInd;

	Integer aggregationCounts;

	String lastModifiedUserDept;

	String lastModifiedUserDesk;

	String csFormatPolicyNo;

	String suspendCode;

	String fsuRelated;
	
	String deathInd;
	String certNo;
	String payeeType;
	String subOfficeCode;
	String distributionInd;

	
	public Long getCwsWorkingId() {
		return cwsWorkingId;
	}

	public void setCwsWorkingId(Long cwsWorkingId) {
		this.cwsWorkingId = cwsWorkingId;
	}

	public Date getCycleDate() {
		return cycleDate;
	}

	public void setCycleDate(Date cycleDate) {
		this.cycleDate = cycleDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public Date getTransactionDt() {
		return transactionDt;
	}

	public void setTransactionDt(Date transactionDt) {
		this.transactionDt = transactionDt;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getKeyPolicyNo() {
		return keyPolicyNo;
	}

	public void setKeyPolicyNo(String keyPolicyNo) {
		this.keyPolicyNo = keyPolicyNo;
	}

	public BigDecimal getTransactionAmt() {
		return transactionAmt;
	}

	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	public String getCollectionMethod() {
		return collectionMethod;
	}

	public void setCollectionMethod(String collectionMethod) {
		this.collectionMethod = collectionMethod;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getPayeeTitle() {
		return payeeTitle;
	}

	public void setPayeeTitle(String payeeTitle) {
		this.payeeTitle = payeeTitle;
	}

	public String getPayeeLastName() {
		return payeeLastName;
	}

	public void setPayeeLastName(String payeeLastName) {
		this.payeeLastName = payeeLastName;
	}

	public String getPayeeFirstName() {
		return payeeFirstName;
	}

	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getInsuredTitle() {
		return insuredTitle;
	}

	public void setInsuredTitle(String insuredTitle) {
		this.insuredTitle = insuredTitle;
	}

	public String getInsuredLastName() {
		return insuredLastName;
	}

	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}

	public String getInsuredFirstName() {
		return insuredFirstName;
	}

	public void setInsuredFirstName(String insuredFirstName) {
		this.insuredFirstName = insuredFirstName;
	}

	public String getMediaClearingInd() {
		return mediaClearingInd;
	}

	public void setMediaClearingInd(String mediaClearingInd) {
		this.mediaClearingInd = mediaClearingInd;
	}

	public String getBankruptcyInd() {
		return bankruptcyInd;
	}

	public void setBankruptcyInd(String bankruptcyInd) {
		this.bankruptcyInd = bankruptcyInd;
	}

	public String getAmloInd() {
		return amloInd;
	}

	public void setAmloInd(String amloInd) {
		this.amloInd = amloInd;
	}

	public String getBlacklistInd() {
		return blacklistInd;
	}

	public void setBlacklistInd(String blacklistInd) {
		this.blacklistInd = blacklistInd;
	}

	public String getAbsoluteAssignInd() {
		return absoluteAssignInd;
	}

	public void setAbsoluteAssignInd(String absoluteAssignInd) {
		this.absoluteAssignInd = absoluteAssignInd;
	}

	public String getSuppressChequeInd() {
		return suppressChequeInd;
	}

	public void setSuppressChequeInd(String suppressChequeInd) {
		this.suppressChequeInd = suppressChequeInd;
	}

	public String getServicingAgencyOfficeCode() {
		return servicingAgencyOfficeCode;
	}

	public void setServicingAgencyOfficeCode(String servicingAgencyOfficeCode) {
		this.servicingAgencyOfficeCode = servicingAgencyOfficeCode;
	}

	public String getAgencyCodeServicing() {
		return agencyCodeServicing;
	}

	public void setAgencyCodeServicing(String agencyCodeServicing) {
		this.agencyCodeServicing = agencyCodeServicing;
	}

	public String getAgencyWritingCode() {
		return agencyWritingCode;
	}

	public void setAgencyWritingCode(String agencyWritingCode) {
		this.agencyWritingCode = agencyWritingCode;
	}

	public String getAgentCodeServicing() {
		return agentCodeServicing;
	}

	public void setAgentCodeServicing(String agentCodeServicing) {
		this.agentCodeServicing = agentCodeServicing;
	}

	public String getAgentWritingCode() {
		return agentWritingCode;
	}

	public void setAgentWritingCode(String agentWritingCode) {
		this.agentWritingCode = agentWritingCode;
	}

	public String getPickUpChqInd() {
		return pickUpChqInd;
	}

	public void setPickUpChqInd(String pickUpChqInd) {
		this.pickUpChqInd = pickUpChqInd;
	}

	public Integer getAggregationCounts() {
		return aggregationCounts;
	}

	public void setAggregationCounts(Integer aggregationCounts) {
		this.aggregationCounts = aggregationCounts;
	}

	public String getLastModifiedUserDept() {
		return lastModifiedUserDept;
	}

	public void setLastModifiedUserDept(String lastModifiedUserDept) {
		this.lastModifiedUserDept = lastModifiedUserDept;
	}

	public String getLastModifiedUserDesk() {
		return lastModifiedUserDesk;
	}

	public void setLastModifiedUserDesk(String lastModifiedUserDesk) {
		this.lastModifiedUserDesk = lastModifiedUserDesk;
	}

	public String getCsFormatPolicyNo() {
		return csFormatPolicyNo;
	}

	public void setCsFormatPolicyNo(String csFormatPolicyNo) {
		this.csFormatPolicyNo = csFormatPolicyNo;
	}

	public String getSuspendCode() {
		return suspendCode;
	}

	public void setSuspendCode(String suspendCode) {
		this.suspendCode = suspendCode;
	}

	public String getFsuRelated() {
		return fsuRelated;
	}

	public void setFsuRelated(String fsuRelated) {
		this.fsuRelated = fsuRelated;
	}

	/**
	 * @return the deathInd
	 */
	public String getDeathInd() {
		return deathInd;
	}

	/**
	 * @param deathInd the deathInd to set
	 */
	public void setDeathInd(String deathInd) {
		this.deathInd = deathInd;
	}

	/**
	 * @return the certNo
	 */
	public String getCertNo() {
		return certNo;
	}

	/**
	 * @param certNo the certNo to set
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	/**
	 * @return the subOfficeCode
	 */
	public String getSubOfficeCode() {
		return subOfficeCode;
	}

	/**
	 * @param subOfficeCode the subOfficeCode to set
	 */
	public void setSubOfficeCode(String subOfficeCode) {
		this.subOfficeCode = subOfficeCode;
	}

	/**
	 * @return the distributionInd
	 */
	public String getDistributionInd() {
		return distributionInd;
	}

	/**
	 * @param distributionInd the distributionInd to set
	 */
	public void setDistributionInd(String distributionInd) {
		this.distributionInd = distributionInd;
	}

}
