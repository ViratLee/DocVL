package com.aia.cmic.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class GetFurtherClaim {
	private Long partyId;
	private String treatmentType;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private Date accidentDt;
	private List<String> accidentCode;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private Date hospitalizationDt;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dischargeDt;
	private Long currentClaimId;

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public Date getAccidentDt() {
		return accidentDt;
	}

	public void setAccidentDt(Date accidentDt) {
		this.accidentDt = accidentDt;
	}

	public List<String> getAccidentCode() {
		return accidentCode;
	}

	public void setAccidentCode(List<String> accidentCode) {
		this.accidentCode = accidentCode;
	}

	public Date getHospitalizationDt() {
		return hospitalizationDt;
	}

	public void setHospitalizationDt(Date hospitalizationDt) {
		this.hospitalizationDt = hospitalizationDt;
	}

	public Date getDischargeDt() {
		return dischargeDt;
	}

	public void setDischargeDt(Date dischargeDt) {
		this.dischargeDt = dischargeDt;
	}

	public Long getCurrentClaimId() {
		return currentClaimId;
	}

	public void setCurrentClaimId(Long currentClaimId) {
		this.currentClaimId = currentClaimId;
	}
}
