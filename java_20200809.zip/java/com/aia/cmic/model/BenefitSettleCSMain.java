package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitSettleCSMain {
	@XmlElement(name = "benefitSettleCSList")
	List<BenefitSettleCS> benefitSettleCSList;

	// for one last footer of CS 
	@XmlElement(name = "reimburseAmt")
	BigDecimal reimburseAmt = BigDecimal.ZERO;
	@XmlElement(name = "paidAmt")
	BigDecimal paidAmt = BigDecimal.ZERO;
	@XmlElement(name = "deductPaidAmt")
	BigDecimal deductPaidAmt = BigDecimal.ZERO;
	
	public List<BenefitSettleCS> getBenefitSettleCSList() {
		return benefitSettleCSList;
	}

	public void setBenefitSettleCSList(List<BenefitSettleCS> benefitSettleCSList) {
		this.benefitSettleCSList = benefitSettleCSList;
	}

	public BigDecimal getReimburseAmt() {
		return reimburseAmt;
	}

	public void setReimburseAmt(BigDecimal reimburseAmt) {
		this.reimburseAmt = reimburseAmt;
	}

	public BigDecimal getPaidAmt() {
		return paidAmt;
	}

	public void setPaidAmt(BigDecimal paidAmt) {
		this.paidAmt = paidAmt;
	}

	public BigDecimal getDeductPaidAmt() {
		return deductPaidAmt;
	}

	public void setDeductPaidAmt(BigDecimal deductPaidAmt) {
		this.deductPaidAmt = deductPaidAmt;
	}
	
	

}
