package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class ClaimPolicyCoverage {

	Long claimPolicyCoverageId;
	String claimNo;
	Integer occurrence;
	String policyNo;
	Long planId;
	String planCoverageNo;
	String productCode;
	String benefitCode;
	String saCalculateType;
	String sumDuplicateCheckInd;
	String oopInd;
	String fullCreditInd;
	String membershipType;
	Date effectiveDt;
	BigDecimal maxSaAmt;
	BigDecimal minSaAmt;
	BigDecimal flatAmt;
	BigDecimal multipleFactor;
	String benefitUnit;
	BigDecimal benefitAmount;
	Integer sumSequenceNo;
	Integer accumulatorNo;
	Integer unitNo;
	String sumCategory;
	String sumTimeFrame;
	String familyShareInd;
	BigDecimal outNetworkSumValue;
	BigDecimal inNetworkSumValue;
	String proRateInd;
	String shareInd;
	String shareDesc;
	String shareLevel;
	BigDecimal benefitDeductAmt;
	Integer waitingPeriod;
	String enableInd;
	String defClaimPayeeType;

	/**
	 * @return the claimPolicyCoverageId
	 */
	public Long getClaimPolicyCoverageId() {
		return claimPolicyCoverageId;
	}

	/**
	 * @param claimPolicyCoverageId the claimPolicyCoverageId to set
	 */
	public void setClaimPolicyCoverageId(Long claimPolicyCoverageId) {
		this.claimPolicyCoverageId = claimPolicyCoverageId;
	}

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the occurrence
	 */
	public Integer getOccurrence() {
		return occurrence;
	}

	/**
	 * @param occurrence the occurrence to set
	 */
	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the benefitCode
	 */
	public String getBenefitCode() {
		return benefitCode;
	}

	/**
	 * @param benefitCode the benefitCode to set
	 */
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	/**
	 * @return the saCalculateType
	 */
	public String getSaCalculateType() {
		return saCalculateType;
	}

	/**
	 * @param saCalculateType the saCalculateType to set
	 */
	public void setSaCalculateType(String saCalculateType) {
		this.saCalculateType = saCalculateType;
	}

	/**
	 * @return the sumDuplicateCheckInd
	 */
	public String getSumDuplicateCheckInd() {
		return sumDuplicateCheckInd;
	}

	/**
	 * @param sumDuplicateCheckInd the sumDuplicateCheckInd to set
	 */
	public void setSumDuplicateCheckInd(String sumDuplicateCheckInd) {
		this.sumDuplicateCheckInd = sumDuplicateCheckInd;
	}

	/**
	 * @return the oopInd
	 */
	public String getOopInd() {
		return oopInd;
	}

	/**
	 * @param oopInd the oopInd to set
	 */
	public void setOopInd(String oopInd) {
		this.oopInd = oopInd;
	}

	/**
	 * @return the membershipType
	 */
	public String getMembershipType() {
		return membershipType;
	}

	/**
	 * @param membershipType the membershipType to set
	 */
	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}

	/**
	 * @return the effectiveDt
	 */
	public Date getEffectiveDt() {
		return effectiveDt;
	}

	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 * @return the maxSaAmt
	 */
	public BigDecimal getMaxSaAmt() {
		return maxSaAmt;
	}

	/**
	 * @param maxSaAmt the maxSaAmt to set
	 */
	public void setMaxSaAmt(BigDecimal maxSaAmt) {
		this.maxSaAmt = maxSaAmt;
	}

	/**
	 * @return the minSaAmt
	 */
	public BigDecimal getMinSaAmt() {
		return minSaAmt;
	}

	/**
	 * @param minSaAmt the minSaAmt to set
	 */
	public void setMinSaAmt(BigDecimal minSaAmt) {
		this.minSaAmt = minSaAmt;
	}

	/**
	 * @return the flatAmt
	 */
	public BigDecimal getFlatAmt() {
		return flatAmt;
	}

	/**
	 * @param flatAmt the flatAmt to set
	 */
	public void setFlatAmt(BigDecimal flatAmt) {
		this.flatAmt = flatAmt;
	}

	/**
	 * @return the multipleFactor
	 */
	public BigDecimal getMultipleFactor() {
		return multipleFactor;
	}

	/**
	 * @param multipleFactor the multipleFactor to set
	 */
	public void setMultipleFactor(BigDecimal multipleFactor) {
		this.multipleFactor = multipleFactor;
	}

	/**
	 * @return the benefitUnit
	 */
	public String getBenefitUnit() {
		return benefitUnit;
	}

	/**
	 * @param benefitUnit the benefitUnit to set
	 */
	public void setBenefitUnit(String benefitUnit) {
		this.benefitUnit = benefitUnit;
	}

	/**
	 * @return the benefitAmount
	 */
	public BigDecimal getBenefitAmount() {
		return benefitAmount;
	}

	/**
	 * @param benefitAmount the benefitAmount to set
	 */
	public void setBenefitAmount(BigDecimal benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	/**
	 * @return the sumSequenceNo
	 */
	public Integer getSumSequenceNo() {
		return sumSequenceNo;
	}

	/**
	 * @param sumSequenceNo the sumSequenceNo to set
	 */
	public void setSumSequenceNo(Integer sumSequenceNo) {
		this.sumSequenceNo = sumSequenceNo;
	}

	/**
	 * @return the accumulatorNo
	 */
	public Integer getAccumulatorNo() {
		return accumulatorNo;
	}

	/**
	 * @param accumulatorNo the accumulatorNo to set
	 */
	public void setAccumulatorNo(Integer accumulatorNo) {
		this.accumulatorNo = accumulatorNo;
	}

	/**
	 * @return the unitNo
	 */
	public Integer getUnitNo() {
		return unitNo;
	}

	/**
	 * @param unitNo the unitNo to set
	 */
	public void setUnitNo(Integer unitNo) {
		this.unitNo = unitNo;
	}

	/**
	 * @return the sumCategory
	 */
	public String getSumCategory() {
		return sumCategory;
	}

	/**
	 * @param sumCategory the sumCategory to set
	 */
	public void setSumCategory(String sumCategory) {
		this.sumCategory = sumCategory;
	}

	/**
	 * @return the sumTimeFrame
	 */
	public String getSumTimeFrame() {
		return sumTimeFrame;
	}

	/**
	 * @param sumTimeFrame the sumTimeFrame to set
	 */
	public void setSumTimeFrame(String sumTimeFrame) {
		this.sumTimeFrame = sumTimeFrame;
	}

	/**
	 * @return the familyShareInd
	 */
	public String getFamilyShareInd() {
		return familyShareInd;
	}

	/**
	 * @param familyShareInd the familyShareInd to set
	 */
	public void setFamilyShareInd(String familyShareInd) {
		this.familyShareInd = familyShareInd;
	}

	/**
	 * @return the outNetworkSumValue
	 */
	public BigDecimal getOutNetworkSumValue() {
		return outNetworkSumValue;
	}

	/**
	 * @param outNetworkSumValue the outNetworkSumValue to set
	 */
	public void setOutNetworkSumValue(BigDecimal outNetworkSumValue) {
		this.outNetworkSumValue = outNetworkSumValue;
	}

	/**
	 * @return the inNetworkSumValue
	 */
	public BigDecimal getInNetworkSumValue() {
		return inNetworkSumValue;
	}

	/**
	 * @param inNetworkSumValue the inNetworkSumValue to set
	 */
	public void setInNetworkSumValue(BigDecimal inNetworkSumValue) {
		this.inNetworkSumValue = inNetworkSumValue;
	}

	/**
	 * @return the fullCreditInd
	 */
	public String getFullCreditInd() {
		return fullCreditInd;
	}

	/**
	 * @param fullCreditInd the fullCreditInd to set
	 */
	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	/**
	 * @return the proRateInd
	 */
	public String getProRateInd() {
		return proRateInd;
	}

	/**
	 * @param proRateInd the proRateInd to set
	 */
	public void setProRateInd(String proRateInd) {
		this.proRateInd = proRateInd;
	}

	/**
	 * @return the shareInd
	 */
	public String getShareInd() {
		return shareInd;
	}

	/**
	 * @param shareInd the shareInd to set
	 */
	public void setShareInd(String shareInd) {
		this.shareInd = shareInd;
	}

	/**
	 * @return the shareDesc
	 */
	public String getShareDesc() {
		return shareDesc;
	}

	/**
	 * @param shareDesc the shareDesc to set
	 */
	public void setShareDesc(String shareDesc) {
		this.shareDesc = shareDesc;
	}

	/**
	 * @return the shareLevel
	 */
	public String getShareLevel() {
		return shareLevel;
	}

	/**
	 * @param shareLevel the shareLevel to set
	 */
	public void setShareLevel(String shareLevel) {
		this.shareLevel = shareLevel;
	}

	/**
	 * @return the benefitDeductAmt
	 */
	public BigDecimal getBenefitDeductAmt() {
		return benefitDeductAmt;
	}

	/**
	 * @param benefitDeductAmt the benefitDeductAmt to set
	 */
	public void setBenefitDeductAmt(BigDecimal benefitDeductAmt) {
		this.benefitDeductAmt = benefitDeductAmt;
	}

	/**
	 * @return the waitingPeriod
	 */
	public Integer getWaitingPeriod() {
		return waitingPeriod;
	}

	/**
	 * @param waitingPeriod the waitingPeriod to set
	 */
	public void setWaitingPeriod(Integer waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	public String getEnableInd() {
		return enableInd;
	}

	public void setEnableInd(String enableInd) {
		this.enableInd = enableInd;
	}

	public String getDefClaimPayeeType() {
		return defClaimPayeeType;
	}

	public void setDefClaimPayeeType(String defClaimPayeeType) {
		this.defClaimPayeeType = defClaimPayeeType;
	}

}
