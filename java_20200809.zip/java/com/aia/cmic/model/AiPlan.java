package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class AiPlan {
	private String BENEFITTYPE;
	private Long DEFAULTPLANID;
	private String EFFECTIVEDT;
	private Integer FURTHERCLAIMDAY;
	private String GEOGRAPHICCOVERAGE;
	private Integer NETWORKCODE;
	private Long PLANID;
	private String PLANNAME;
	private String PLANSHORTNAME;
	private Integer SUBPLANCODE;
	
	// New Field
	private String BENEFITTYPEACCIDENT;
	private String BENEFITTYPEASSAULT;
	private String BENEFITTYPECANCER;
	private String BENEFITTYPEDENTAL;
	private String BENEFITTYPEMATERNITY;
	private String BENEFITTYPEOTHERS;
	private String BENEFITTYPEVISION;
	private String BUSINESSLINE;
	private Integer EMERGENCYDAY;
	private String NETWORKBENEFITIND;
	private String PLANCODE;
	private String PLANSTATUS;
	private String POLICYNO;
	private String PRODUCTCODE;
	private BigDecimal RESERVECASHLESSPERCENTAGE;
	private BigDecimal RESERVECASHPERCENTAGE;
	private String TERMINATEDT;
	private String TYPEOFSERVICEDAYCASE;
	private String TYPEOFSERVICEIPD;
	private String TYPEOFSERVICEOPD;
	
	public String getBENEFITTYPE() {
		return BENEFITTYPE;
	}
	public void setBENEFITTYPE(String bENEFITTYPE) {
		BENEFITTYPE = bENEFITTYPE;
	}
	public Long getDEFAULTPLANID() {
		return DEFAULTPLANID;
	}
	public void setDEFAULTPLANID(Long dEFAULTPLANID) {
		DEFAULTPLANID = dEFAULTPLANID;
	}
	public String getEFFECTIVEDT() {
		return EFFECTIVEDT;
	}
	public void setEFFECTIVEDT(String eFFECTIVEDT) {
		EFFECTIVEDT = eFFECTIVEDT;
	}
	public Integer getFURTHERCLAIMDAY() {
		return FURTHERCLAIMDAY;
	}
	public void setFURTHERCLAIMDAY(Integer fURTHERCLAIMDAY) {
		FURTHERCLAIMDAY = fURTHERCLAIMDAY;
	}
	public String getGEOGRAPHICCOVERAGE() {
		return GEOGRAPHICCOVERAGE;
	}
	public void setGEOGRAPHICCOVERAGE(String gEOGRAPHICCOVERAGE) {
		GEOGRAPHICCOVERAGE = gEOGRAPHICCOVERAGE;
	}
	public Integer getNETWORKCODE() {
		return NETWORKCODE;
	}
	public void setNETWORKCODE(Integer nETWORKCODE) {
		NETWORKCODE = nETWORKCODE;
	}
	public Long getPLANID() {
		return PLANID;
	}
	public void setPLANID(Long pLANID) {
		PLANID = pLANID;
	}
	public String getPLANNAME() {
		return PLANNAME;
	}
	public void setPLANNAME(String pLANNAME) {
		PLANNAME = pLANNAME;
	}
	public String getPLANSHORTNAME() {
		return PLANSHORTNAME;
	}
	public void setPLANSHORTNAME(String pLANSHORTNAME) {
		PLANSHORTNAME = pLANSHORTNAME;
	}
	public Integer getSUBPLANCODE() {
		return SUBPLANCODE;
	}
	public void setSUBPLANCODE(Integer sUBPLANCODE) {
		SUBPLANCODE = sUBPLANCODE;
	}
	public String getBENEFITTYPEACCIDENT() {
		return BENEFITTYPEACCIDENT;
	}
	public void setBENEFITTYPEACCIDENT(String bENEFITTYPEACCIDENT) {
		BENEFITTYPEACCIDENT = bENEFITTYPEACCIDENT;
	}
	public String getBENEFITTYPEASSAULT() {
		return BENEFITTYPEASSAULT;
	}
	public void setBENEFITTYPEASSAULT(String bENEFITTYPEASSAULT) {
		BENEFITTYPEASSAULT = bENEFITTYPEASSAULT;
	}
	public String getBENEFITTYPECANCER() {
		return BENEFITTYPECANCER;
	}
	public void setBENEFITTYPECANCER(String bENEFITTYPECANCER) {
		BENEFITTYPECANCER = bENEFITTYPECANCER;
	}
	public String getBENEFITTYPEDENTAL() {
		return BENEFITTYPEDENTAL;
	}
	public void setBENEFITTYPEDENTAL(String bENEFITTYPEDENTAL) {
		BENEFITTYPEDENTAL = bENEFITTYPEDENTAL;
	}
	public String getBENEFITTYPEMATERNITY() {
		return BENEFITTYPEMATERNITY;
	}
	public void setBENEFITTYPEMATERNITY(String bENEFITTYPEMATERNITY) {
		BENEFITTYPEMATERNITY = bENEFITTYPEMATERNITY;
	}
	public String getBENEFITTYPEOTHERS() {
		return BENEFITTYPEOTHERS;
	}
	public void setBENEFITTYPEOTHERS(String bENEFITTYPEOTHERS) {
		BENEFITTYPEOTHERS = bENEFITTYPEOTHERS;
	}
	public String getBENEFITTYPEVISION() {
		return BENEFITTYPEVISION;
	}
	public void setBENEFITTYPEVISION(String bENEFITTYPEVISION) {
		BENEFITTYPEVISION = bENEFITTYPEVISION;
	}
	public String getBUSINESSLINE() {
		return BUSINESSLINE;
	}
	public void setBUSINESSLINE(String bUSINESSLINE) {
		BUSINESSLINE = bUSINESSLINE;
	}
	public String getNETWORKBENEFITIND() {
		return NETWORKBENEFITIND;
	}
	public void setNETWORKBENEFITIND(String nETWORKBENEFITIND) {
		NETWORKBENEFITIND = nETWORKBENEFITIND;
	}
	public String getPLANCODE() {
		return PLANCODE;
	}
	public void setPLANCODE(String pLANCODE) {
		PLANCODE = pLANCODE;
	}
	public String getPLANSTATUS() {
		return PLANSTATUS;
	}
	public void setPLANSTATUS(String pLANSTATUS) {
		PLANSTATUS = pLANSTATUS;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	public String getPRODUCTCODE() {
		return PRODUCTCODE;
	}
	public void setPRODUCTCODE(String pRODUCTCODE) {
		PRODUCTCODE = pRODUCTCODE;
	}
	public String getTERMINATEDT() {
		return TERMINATEDT;
	}
	public void setTERMINATEDT(String tERMINATEDT) {
		TERMINATEDT = tERMINATEDT;
	}
	public String getTYPEOFSERVICEDAYCASE() {
		return TYPEOFSERVICEDAYCASE;
	}
	public void setTYPEOFSERVICEDAYCASE(String tYPEOFSERVICEDAYCASE) {
		TYPEOFSERVICEDAYCASE = tYPEOFSERVICEDAYCASE;
	}
	public String getTYPEOFSERVICEIPD() {
		return TYPEOFSERVICEIPD;
	}
	public void setTYPEOFSERVICEIPD(String tYPEOFSERVICEIPD) {
		TYPEOFSERVICEIPD = tYPEOFSERVICEIPD;
	}
	public String getTYPEOFSERVICEOPD() {
		return TYPEOFSERVICEOPD;
	}
	public void setTYPEOFSERVICEOPD(String tYPEOFSERVICEOPD) {
		TYPEOFSERVICEOPD = tYPEOFSERVICEOPD;
	}
	public Integer getEMERGENCYDAY() {
		return EMERGENCYDAY;
	}
	public void setEMERGENCYDAY(Integer eMERGENCYDAY) {
		EMERGENCYDAY = eMERGENCYDAY;
	}
	public BigDecimal getRESERVECASHLESSPERCENTAGE() {
		return RESERVECASHLESSPERCENTAGE;
	}
	public void setRESERVECASHLESSPERCENTAGE(BigDecimal rESERVECASHLESSPERCENTAGE) {
		RESERVECASHLESSPERCENTAGE = rESERVECASHLESSPERCENTAGE;
	}
	public BigDecimal getRESERVECASHPERCENTAGE() {
		return RESERVECASHPERCENTAGE;
	}
	public void setRESERVECASHPERCENTAGE(BigDecimal rESERVECASHPERCENTAGE) {
		RESERVECASHPERCENTAGE = rESERVECASHPERCENTAGE;
	}
	
}
