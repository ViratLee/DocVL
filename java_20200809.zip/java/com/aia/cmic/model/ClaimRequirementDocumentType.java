package com.aia.cmic.model;

import java.util.List;

public class ClaimRequirementDocumentType {
	List<String> documentType;
	private List<OnlinePrintField> onlinePrintDatas;

	public List<String> getDocumentType() {
		return documentType;
	}

	public void setDocumentType(List<String> documentType) {
		this.documentType = documentType;
	}

	public List<OnlinePrintField> getOnlinePrintDatas() {
		return onlinePrintDatas;
	}

	public void setOnlinePrintDatas(List<OnlinePrintField> onlinePrintDatas) {
		this.onlinePrintDatas = onlinePrintDatas;
	}

}
