package com.aia.cmic.model;

import com.aia.cmic.util.FormatUtil;

public class LimitDetail {

	String policyNo;
	String certNo;
	String claimant;
	String policyYearFromDt;
	String policyYearToDt;

	public LimitDetail() {
	}

	public LimitDetail(CMiCClaim cmicClaim) {
		if (cmicClaim != null) {
			if (cmicClaim.getClaimCanonical() != null) {
				if (cmicClaim.getClaimCanonical().getClaim() != null) {
					this.certNo = cmicClaim.getClaimCanonical().getClaim().getCertNo();
					this.claimant = cmicClaim.getClaimCanonical().getClaim().getFirstName() + " " + cmicClaim.getClaimCanonical().getClaim().getLastName();
					this.policyNo = cmicClaim.getClaimCanonical().getClaim().getPolicyNo();
					this.policyYearFromDt = FormatUtil.formatDate(cmicClaim.getClaimCanonical().getClaim().getPolicyYearFromDt());
					this.policyYearToDt = FormatUtil.formatDate(cmicClaim.getClaimCanonical().getClaim().getPolicyYearToDt());
				}
			}
		}
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getClaimant() {
		return claimant;
	}

	public void setClaimant(String claimant) {
		this.claimant = claimant;
	}

	public String getPolicyYearFromDt() {
		return policyYearFromDt;
	}

	public void setPolicyYearFromDt(String policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}

	public String getPolicyYearToDt() {
		return policyYearToDt;
	}

	public void setPolicyYearToDt(String policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}

}
