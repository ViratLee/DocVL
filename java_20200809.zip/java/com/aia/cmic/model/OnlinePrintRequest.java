package com.aia.cmic.model;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public class OnlinePrintRequest {
	private String claimNo;
	private Long caseId;
	private Integer occurrence;
	private String formID;
	private String formName;
	private String policyNo;
	private String faxNo;
	private String eMail;
	private String providerCode;
	private String certNo;
	private String memberId;
	private String dependentNo;
	private String claimant;
	private String eFormCodeName;

	private List<OnlinePrintField> onlinePrintDatas;

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Integer getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(Integer occurrence) {
		this.occurrence = occurrence;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public List<OnlinePrintField> getOnlinePrintDatas() {
		return onlinePrintDatas;
	}

	public void setOnlinePrintDatas(List<OnlinePrintField> onlinePrintDatas) {
		this.onlinePrintDatas = onlinePrintDatas;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getDependentNo() {
		return dependentNo;
	}

	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	public String getClaimant() {
		return claimant;
	}

	public void setClaimant(String claimant) {
		this.claimant = claimant;
	}

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String geteFormCodeName() {
		return eFormCodeName;
	}

	public void seteFormCodeName(String eFormCodeName) {
		this.eFormCodeName = eFormCodeName;
	}

}
