package com.aia.cmic.model;

import java.util.Date;

public class PTHistory {
	String policyNo;
	String planShortName;
	Integer totalPTCall;
	Date policyYearFromDt;
	Date policyYearToDt;
	public String getPolicyNo() {
		return policyNo;
	}
	public String getPlanShortName() {
		return planShortName;
	}
	public Integer getTotalPTCall() {
		return totalPTCall;
	}
	public Date getPolicyYearFromDt() {
		return policyYearFromDt;
	}
	public Date getPolicyYearToDt() {
		return policyYearToDt;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}
	public void setTotalPTCall(Integer totalPTCall) {
		this.totalPTCall = totalPTCall;
	}
	public void setPolicyYearFromDt(Date policyYearFromDt) {
		this.policyYearFromDt = policyYearFromDt;
	}
	public void setPolicyYearToDt(Date policyYearToDt) {
		this.policyYearToDt = policyYearToDt;
	}
	
	
}
