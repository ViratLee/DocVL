package com.aia.cmic.model;


public class ClaimSpecialCondition {

	private Long claimSupplementId;
	private String policyNo;
	private String strValue;
	private String description;

	public Long getClaimSupplementId() {
		return claimSupplementId;
	}

	public void setClaimSupplementId(Long claimSupplementId) {
		this.claimSupplementId = claimSupplementId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getStrValue() {
		return strValue;
	}

	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
