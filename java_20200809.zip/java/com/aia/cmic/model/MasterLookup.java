package com.aia.cmic.model;

public class MasterLookup {
	protected String key;
	protected String value;

	public MasterLookup() {
	}

	public MasterLookup(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}
}
