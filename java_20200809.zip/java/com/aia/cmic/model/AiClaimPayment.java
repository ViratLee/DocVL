package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class AiClaimPayment {
	private Long CLAIMPAYMENTID;
	
	private String ADJUSTEDREASON;
	private BigDecimal ALLOCATEDAMT;
	private BigDecimal APPROVEDAMT;
	private String CLAIMNO;
	private String DECLINEREASON;
	private BigDecimal ELIGIBLEAMT;
	private Integer NOOFDAYSALLOCATED;
	private Integer OCCURRENCE;
	private String PAYEETYPE;
	private String PAYMENTCHANNEL;
	private String PAYMENTSTATUS;
	private String PAYMENTTRANSFERDT;
	private BigDecimal PERCENTAGEALLOCATED;
	private String PLANCODE;
	private String PLANCOVERAGENO;
	private Long PLANID;
	private String POLICYNO;
	private BigDecimal PRESENTEDAMT;
	private String PRODUCTCODE;
	private String PRODUCTTYPE;
	private String SETTLEMENTDATE;
	private BigDecimal SHORTFALLAMT;
	private String SUPPRESSCHEQUEIND;
	private String SYSTEMELIGIBILITY;
	
	
	// New Field
	private BigDecimal COPAYMENTPERCENT;
	private String PAYMENTRANSFERREMARK;
	private String PAYMENTTRANSFERSTATUS;
	private String PAYNONCOVERITEMIND;
	private Integer REIMBURSEDDAY;
	
	// Remove Field
	/*private BigDecimal ADJUSTEDAMT;
	private String ELIGIBILITY;
	private String PAYMENTTRANSFERREMARK;*/
	
	
	public Long getCLAIMPAYMENTID() {
		return CLAIMPAYMENTID;
	}
	public void setCLAIMPAYMENTID(Long cLAIMPAYMENTID) {
		CLAIMPAYMENTID = cLAIMPAYMENTID;
	}

	public String getADJUSTEDREASON() {
		return ADJUSTEDREASON;
	}
	public void setADJUSTEDREASON(String aDJUSTEDREASON) {
		ADJUSTEDREASON = aDJUSTEDREASON;
	}
	public BigDecimal getALLOCATEDAMT() {
		return ALLOCATEDAMT;
	}
	public void setALLOCATEDAMT(BigDecimal aLLOCATEDAMT) {
		ALLOCATEDAMT = aLLOCATEDAMT;
	}
	public BigDecimal getAPPROVEDAMT() {
		return APPROVEDAMT;
	}
	public void setAPPROVEDAMT(BigDecimal aPPROVEDAMT) {
		APPROVEDAMT = aPPROVEDAMT;
	}
	public String getCLAIMNO() {
		return CLAIMNO;
	}
	public void setCLAIMNO(String cLAIMNO) {
		CLAIMNO = cLAIMNO;
	}
	public String getDECLINEREASON() {
		return DECLINEREASON;
	}
	public void setDECLINEREASON(String dECLINEREASON) {
		DECLINEREASON = dECLINEREASON;
	}
	
	public BigDecimal getELIGIBLEAMT() {
		return ELIGIBLEAMT;
	}
	public void setELIGIBLEAMT(BigDecimal eLIGIBLEAMT) {
		ELIGIBLEAMT = eLIGIBLEAMT;
	}
	public Integer getNOOFDAYSALLOCATED() {
		return NOOFDAYSALLOCATED;
	}
	public void setNOOFDAYSALLOCATED(Integer nOOFDAYSALLOCATED) {
		NOOFDAYSALLOCATED = nOOFDAYSALLOCATED;
	}
	public Integer getOCCURRENCE() {
		return OCCURRENCE;
	}
	public void setOCCURRENCE(Integer oCCURRENCE) {
		OCCURRENCE = oCCURRENCE;
	}
	public String getPAYEETYPE() {
		return PAYEETYPE;
	}
	public void setPAYEETYPE(String pAYEETYPE) {
		PAYEETYPE = pAYEETYPE;
	}
	public String getPAYMENTCHANNEL() {
		return PAYMENTCHANNEL;
	}
	public void setPAYMENTCHANNEL(String pAYMENTCHANNEL) {
		PAYMENTCHANNEL = pAYMENTCHANNEL;
	}
	public String getPAYMENTSTATUS() {
		return PAYMENTSTATUS;
	}
	public void setPAYMENTSTATUS(String pAYMENTSTATUS) {
		PAYMENTSTATUS = pAYMENTSTATUS;
	}
	public String getPAYMENTTRANSFERDT() {
		return PAYMENTTRANSFERDT;
	}
	public void setPAYMENTTRANSFERDT(String pAYMENTTRANSFERDT) {
		PAYMENTTRANSFERDT = pAYMENTTRANSFERDT;
	}
	
	public BigDecimal getPERCENTAGEALLOCATED() {
		return PERCENTAGEALLOCATED;
	}
	public void setPERCENTAGEALLOCATED(BigDecimal pERCENTAGEALLOCATED) {
		PERCENTAGEALLOCATED = pERCENTAGEALLOCATED;
	}
	public String getPLANCODE() {
		return PLANCODE;
	}
	public void setPLANCODE(String pLANCODE) {
		PLANCODE = pLANCODE;
	}
	public String getPLANCOVERAGENO() {
		return PLANCOVERAGENO;
	}
	public void setPLANCOVERAGENO(String pLANCOVERAGENO) {
		PLANCOVERAGENO = pLANCOVERAGENO;
	}
	public Long getPLANID() {
		return PLANID;
	}
	public void setPLANID(Long pLANID) {
		PLANID = pLANID;
	}
	public String getPOLICYNO() {
		return POLICYNO;
	}
	public void setPOLICYNO(String pOLICYNO) {
		POLICYNO = pOLICYNO;
	}
	public BigDecimal getPRESENTEDAMT() {
		return PRESENTEDAMT;
	}
	public void setPRESENTEDAMT(BigDecimal pRESENTEDAMT) {
		PRESENTEDAMT = pRESENTEDAMT;
	}
	public String getPRODUCTCODE() {
		return PRODUCTCODE;
	}
	public void setPRODUCTCODE(String pRODUCTCODE) {
		PRODUCTCODE = pRODUCTCODE;
	}
	public String getPRODUCTTYPE() {
		return PRODUCTTYPE;
	}
	public void setPRODUCTTYPE(String pRODUCTTYPE) {
		PRODUCTTYPE = pRODUCTTYPE;
	}
	public String getSETTLEMENTDATE() {
		return SETTLEMENTDATE;
	}
	public void setSETTLEMENTDATE(String sETTLEMENTDATE) {
		SETTLEMENTDATE = sETTLEMENTDATE;
	}
	public BigDecimal getSHORTFALLAMT() {
		return SHORTFALLAMT;
	}
	public void setSHORTFALLAMT(BigDecimal sHORTFALLAMT) {
		SHORTFALLAMT = sHORTFALLAMT;
	}
	public String getSUPPRESSCHEQUEIND() {
		return SUPPRESSCHEQUEIND;
	}
	public void setSUPPRESSCHEQUEIND(String sUPPRESSCHEQUEIND) {
		SUPPRESSCHEQUEIND = sUPPRESSCHEQUEIND;
	}
	public String getSYSTEMELIGIBILITY() {
		return SYSTEMELIGIBILITY;
	}
	public void setSYSTEMELIGIBILITY(String sYSTEMELIGIBILITY) {
		SYSTEMELIGIBILITY = sYSTEMELIGIBILITY;
	}

	public String getPAYMENTRANSFERREMARK() {
		return PAYMENTRANSFERREMARK;
	}
	public void setPAYMENTRANSFERREMARK(String pAYMENTRANSFERREMARK) {
		PAYMENTRANSFERREMARK = pAYMENTRANSFERREMARK;
	}
	public String getPAYMENTTRANSFERSTATUS() {
		return PAYMENTTRANSFERSTATUS;
	}
	public void setPAYMENTTRANSFERSTATUS(String pAYMENTTRANSFERSTATUS) {
		PAYMENTTRANSFERSTATUS = pAYMENTTRANSFERSTATUS;
	}
	public String getPAYNONCOVERITEMIND() {
		return PAYNONCOVERITEMIND;
	}
	public void setPAYNONCOVERITEMIND(String pAYNONCOVERITEMIND) {
		PAYNONCOVERITEMIND = pAYNONCOVERITEMIND;
	}
	
	public BigDecimal getCOPAYMENTPERCENT() {
		return COPAYMENTPERCENT;
	}
	public void setCOPAYMENTPERCENT(BigDecimal cOPAYMENTPERCENT) {
		COPAYMENTPERCENT = cOPAYMENTPERCENT;
	}
	public Integer getREIMBURSEDDAY() {
		return REIMBURSEDDAY;
	}
	public void setREIMBURSEDDAY(Integer rEIMBURSEDDAY) {
		REIMBURSEDDAY = rEIMBURSEDDAY;
	}
	
	/*public String getPAYMENTTRANSFERREMARK() {
		return PAYMENTTRANSFERREMARK;
	}
	public void setPAYMENTTRANSFERREMARK(String pAYMENTTRANSFERREMARK) {
		PAYMENTTRANSFERREMARK = pAYMENTTRANSFERREMARK;
	}
	
	public String getELIGIBILITY() {
		return ELIGIBILITY;
	}
	public void setELIGIBILITY(String eLIGIBILITY) {
		ELIGIBILITY = eLIGIBILITY;
	}
	
	public BigDecimal getADJUSTEDAMT() {
		return ADJUSTEDAMT;
	}
	public void setADJUSTEDAMT(BigDecimal aDJUSTEDAMT) {
		ADJUSTEDAMT = aDJUSTEDAMT;
	}*/
}
