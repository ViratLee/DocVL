package com.aia.cmic.model;

import java.io.Serializable;
import java.util.List;

import com.aia.cmic.uam.Function;

public class Menu implements Serializable {
	private String text;
	private String imageUrl;
	private String cssClass;
	private String url;
	private List<Function> permission;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getCssClass() {
		return cssClass;
	}

	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public List<Function> getPermission() {
		return permission;
	}

	public void setPermission(List<Function> permission) {
		this.permission = permission;
	}
}
