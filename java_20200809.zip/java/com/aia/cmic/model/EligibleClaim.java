package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.Date;

public class EligibleClaim {
	/**
	 * @param claimNo
	 * @param companyId
	 * @param occurence
	 * @param policyNo
	 * @param businessLine
	 * @param productCode
	 * @param fullCreditInd
	 * @param planId
	 * @param planName
	 * @param planShortName
	 * @param planCoverageNo
	 * @param paBonusAmt
	 * @param paBonusDt
	 */
	public EligibleClaim(String claimNo, String companyId, Integer occurence, String policyNo, String businessLine, String productCode, String fullCreditInd, String csProductCategory, Long planId,
			String planCoverageNo, String productType, BigDecimal paBonusAmt, Date paBonusDt, String csProductCode, String planName,  Date policyIssueDt, String planCode, Long claimPaymentId) {
		super();
		this.claimNo = claimNo;
		this.companyId = companyId;
		this.occurence = occurence;
		this.policyNo = policyNo;
		this.businessLine = businessLine;
		this.productCode = productCode;
		this.productType = productType;
		this.fullCreditInd = fullCreditInd;
		this.csProductCategory = csProductCategory;
		this.planId = planId;
		this.planCoverageNo = planCoverageNo;
		this.paBonusAmt = paBonusAmt;
		this.paBonusDt = paBonusDt;
		this.csProductCode = csProductCode;
		this.setPlanName(planName);
		this.setPolicyIssueDt(policyIssueDt);
		this.setPlanCode(planCode);
		this.setClaimPaymentId(claimPaymentId);
	}

	private String claimNo;
	private String companyId;
	private Integer occurence;
	private String policyNo;
	private String businessLine;
	private String productCode;
	private String fullCreditInd;
	private String csProductCategory;
	private Long planId;
	private String planCoverageNo;
	private BigDecimal paBonusAmt;
	private Date paBonusDt;
	private String productType;
	private String csProductCode;
	private String planName;
	private Date policyIssueDt;
	private String planCode;
	private Long claimPaymentId ;

	/**
	 * @return the claimNo
	 */
	public String getClaimNo() {
		return claimNo;
	}

	/**
	 * @param claimNo the claimNo to set
	 */
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the occurence
	 */
	public Integer getOccurence() {
		return occurence;
	}

	/**
	 * @param occurence the occurence to set
	 */
	public void setOccurence(Integer occurence) {
		this.occurence = occurence;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the businessLine
	 */
	public String getBusinessLine() {
		return businessLine;
	}

	/**
	 * @param businessLine the businessLine to set
	 */
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the fullCreditInd
	 */
	public String getFullCreditInd() {
		return fullCreditInd;
	}

	/**
	 * @param fullCreditInd the fullCreditInd to set
	 */
	public void setFullCreditInd(String fullCreditInd) {
		this.fullCreditInd = fullCreditInd;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planCoverageNo
	 */
	public String getPlanCoverageNo() {
		return planCoverageNo;
	}

	/**
	 * @param planCoverageNo the planCoverageNo to set
	 */
	public void setPlanCoverageNo(String planCoverageNo) {
		this.planCoverageNo = planCoverageNo;
	}

	/**
	 * @return the paBonusAmt
	 */
	public BigDecimal getPaBonusAmt() {
		return paBonusAmt;
	}

	/**
	 * @param paBonusAmt the paBonusAmt to set
	 */
	public void setPaBonusAmt(BigDecimal paBonusAmt) {
		this.paBonusAmt = paBonusAmt;
	}

	/**
	 * @return the paBonusDt
	 */
	public Date getPaBonusDt() {
		return paBonusDt;
	}

	/**
	 * @param paBonusDt the paBonusDt to set
	 */
	public void setPaBonusDt(Date paBonusDt) {
		this.paBonusDt = paBonusDt;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the csProductCategory
	 */
	public String getCsProductCategory() {
		return csProductCategory;
	}

	/**
	 * @param csProductCategory the csProductCategory to set
	 */
	public void setCsProductCategory(String csProductCategory) {
		this.csProductCategory = csProductCategory;
	}

	public String getCsProductCode() {
		return csProductCode;
	}

	public void setCsProductCode(String csProductCode) {
		this.csProductCode = csProductCode;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
	
	/**
	 * @return the policyIssueDt
	 */
	public Date getPolicyIssueDt() {
		return policyIssueDt;
	}

	/**
	 * @param policyIssueDt the policyIssueDt to set
	 */
	public void setPolicyIssueDt(Date policyIssueDt) {
		this.policyIssueDt = policyIssueDt;
	}

	/**
	 * @return the planCode
	 */
	public String getPlanCode() {
		return planCode;
	}

	/**
	 * @param planCode the planCode to set
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	/**
	 * @return the claimPaymentId
	 */
	public Long getClaimPaymentId() {
		return claimPaymentId;
	}

	/**
	 * @param claimPaymentId the claimPaymentId to set
	 */
	public void setClaimPaymentId(Long claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

}
