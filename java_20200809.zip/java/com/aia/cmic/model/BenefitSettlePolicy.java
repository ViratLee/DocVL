package com.aia.cmic.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class BenefitSettlePolicy {
	@XmlElement(name = "benefitSettlePlanList")
	List<BenefitSettlePlan> benefitSettlePlanList;
	@XmlElement(name = "policyName")
	String policyName;
	@XmlElement(name = "businessLine")
	String businessLine;
	@XmlElement(name = "planAmtSum")
	BigDecimal planAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "planReimbursedSum")
	BigDecimal planReimbursedSum = BigDecimal.ZERO;
	@XmlElement(name = "eligibleMinusShortfallSum")
	BigDecimal eligibleMinusShortfallSum = BigDecimal.ZERO;
	@XmlElement(name = "presentedAmtSum")
	BigDecimal presentedAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "planReimbursedAmtSum")
	BigDecimal planReimbursedAmtSum = BigDecimal.ZERO;
	@XmlElement(name = "paNoPolicyBonusAmt")
	BigDecimal paNoPolicyBonusAmt = BigDecimal.ZERO;
	@XmlElement(name = "paNoTotalBonusAmt")
	BigDecimal paNoTotalBonusAmt = BigDecimal.ZERO;
	
	public BigDecimal getPresentedAmtSum() {
		return presentedAmtSum;
	}

	public BenefitSettlePolicy() {
		benefitSettlePlanList = new ArrayList<BenefitSettlePlan>();
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public BigDecimal getPlanAmtSum() {
		return planAmtSum;
	}

	public void setPlanAmtSum(BigDecimal planAmtSum) {
		this.planAmtSum = planAmtSum;
	}

	public BigDecimal getPlanReimbursedSum() {
		return planReimbursedSum;
	}

	public void setPlanReimbursedSum(BigDecimal planReimbursedSum) {
		this.planReimbursedSum = planReimbursedSum;
	}

	public void setPresentedAmtSum(BigDecimal presentedAmtSum) {
		this.presentedAmtSum = presentedAmtSum;
	}

	public List<BenefitSettlePlan> getBenefitSettlePlanList() {
		return benefitSettlePlanList;
	}

	public void setBenefitSettlePlanList(List<BenefitSettlePlan> benefitSettlePlanList) {
		this.benefitSettlePlanList = benefitSettlePlanList;
		sumPlanAmountForEachPolicy();
	}

	public BigDecimal getEligibleMinusShortfallSum() {
		return eligibleMinusShortfallSum;
	}

	public void setEligibleMinusShortfallSum(BigDecimal eligibleMinusShortfallSum) {
		this.eligibleMinusShortfallSum = eligibleMinusShortfallSum;
	}

	public BigDecimal getPlanReimbursedAmtSum() {
		return planReimbursedAmtSum;
	}

	public void setPlanReimbursedAmtSum(BigDecimal planReimbursedAmtSum) {
		this.planReimbursedAmtSum = planReimbursedAmtSum;
	}
	
	public BigDecimal getPaNoPolicyBonusAmt() {
		return paNoPolicyBonusAmt;
	}

	public BigDecimal getPaNoTotalBonusAmt() {
		return paNoTotalBonusAmt;
	}

	public void setPaNoPolicyBonusAmt(BigDecimal paNoPolicyBonusAmt) {
		this.paNoPolicyBonusAmt = paNoPolicyBonusAmt;
	}

	public void setPaNoTotalBonusAmt(BigDecimal paNoTotalBonusAmt) {
		this.paNoTotalBonusAmt = paNoTotalBonusAmt;
	}

	private void sumPlanAmountForEachPolicy() {
		if ((this.benefitSettlePlanList != null) && (this.benefitSettlePlanList.size() > 0)) {
			this.planAmtSum = BigDecimal.ZERO;
			this.planReimbursedSum = BigDecimal.ZERO;
			this.presentedAmtSum = BigDecimal.ZERO;
			this.planReimbursedAmtSum = BigDecimal.ZERO;
			for (BenefitSettlePlan plan : this.benefitSettlePlanList) {
				BigDecimal amount = plan.getBenefitAmtSum();

				this.planAmtSum = this.planAmtSum.add(amount);
				BigDecimal reimbursedSum = plan.getBenefitReimbursedSum();

				this.planReimbursedSum = this.planReimbursedSum.add(reimbursedSum);

				BigDecimal reimbursedAmtSum = plan.getBenefitReimbursedAmtSum();
				this.planReimbursedAmtSum = this.planReimbursedAmtSum.add(reimbursedAmtSum);

				this.eligibleMinusShortfallSum = this.eligibleMinusShortfallSum.add(plan.getEligibleMinusShortfallSum());

				BigDecimal presentedAmtS = plan.getPresentedAmtSum();
				this.presentedAmtSum = this.presentedAmtSum.add(presentedAmtS);
			}
		}
	}
}
