$(document).ready(function() {

	renderContactListTable();

});

// Contac tList
function renderContactListTable(){
	$("#ContractListGrid").kendoGrid({
		dataSource: {
	        data: datacontractlist,
	        pageSize: 10,
	    },
	    sortable: true,
	    selectable: "multiple, row",
	    rowTemplate : kendo.template($("#ContractListTemplate").html()),
	    autoBind: true,
	    scrollable: true,
	    sortable: true,
	    pageable: {
	        buttonCount: 5,
	        pageSizes: true,
	    },
	    columns : [ 
			{title : "Provider<br/>Code", field : "providerCode", width:100}, 
			{title : "Provider<br/>Name",field : "providerName", width:100}, 
			{title : "Provider<br/>Type",field : "providerType", width:100}, 
			{title : "province", field : "province", width:100}, 
			{title : "Region", field : "region", width:100}, 
			{title : "Network",field : "network", width:150}, 
			{title : "Provider<br>Status",field : "providerStatus", width:100}, 
			{title : "Contract<br>Status",field : "contractStatus", width:150} 
		]
	});
}

var datacontractlist = [
	{
		Id : 1,
		providerCode : "123695997",
		ContractListLink: "contract.html",
		providerName : "กรุงเทพ",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 2,
		providerCode : "215498544",
		ContractListLink: "contract.html",
		providerName : "กรุงเทพคริสเตียน",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 3,
		providerCode : "123695997",
		ContractListLink: "contract.html",
		providerName : "กรุงเทพ",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 4,
		providerCode : "215498544",
		ContractListLink: "contract.html",
		providerName : "พญาไท 1",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	},{
		Id : 5,
		providerCode : "123695997",
		ContractListLink: "contract.html",
		providerName : "พญาไท 2",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 6,
		providerCode : "215498544",
		ContractListLink: "contract.html",
		providerName : "พญาไท 3",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	},{
		Id : 7,
		providerCode : "123695997",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 8,
		providerCode : "215498544",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	},{
		Id : 9,
		providerCode : "123695997",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 10,
		providerCode : "215498544",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	},{
		Id : 11,
		providerCode : "123695997",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}, {
		Id : 12,
		providerCode : "215498544",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		contractStatus : "Waiting for approval"
	}
];