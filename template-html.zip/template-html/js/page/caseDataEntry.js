$(document).ready(function () {
    RenderCheckboxOption();
    RenderAuditTrailTable();
    RenderHistryNameTable();
    RenderBillingTable();
    RenderUploadDocument();
    RenderFurtherClaimTable();
});

//kendo Upload
function RenderUploadDocument(){
     $("#FilesUpload").kendoUpload({
        async: {
            saveUrl: "save",
            removeUrl: "remove",
            allowmultiple: false,
            autoUpload: true
            
        },
        localization: {
            select: "Browse File"
        }
    });
}

function RenderCheckboxOption(){
    $(".doctoroption-1 input[type='checkbox']").click(function(){
        $(".doctorresult-1").toggleClass("none");
    });
    $(".doctoroption-2 input[type='checkbox']").click(function(){
        $(".doctorresult-2").toggleClass("none");
    });
    $(".doctoroption-3 input[type='checkbox']").click(function(){
        $(".doctorresult-3").toggleClass("none");
    });
    // Reason for ICU Admission
    $(".admissionreason-1 input[type='checkbox']").click(function(){
        $(".admissionresult-1").toggleClass("none");
    });
    
    $(".admissionreason-2 input[type='checkbox']").click(function(){
        $(".admissionresult-2").toggleClass("none");
    });
}
//after click audit trail
function RenderAuditTrailTable(){
    $("#AuditTrail").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 10,
            data: [
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 12:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 18:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 09:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 14:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 08:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 12:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 18:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 09:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 14:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 08:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"}
            ]
        }
        ,
        columns: [
            {field: "Timestamp", title: "Timestamp", width: 150},
            {field: "Action", title: "Action"}, 
            {field: "DocID", title: "DocID", width:120}
        ]
    });
}

//Histry Name
function RenderHistryNameTable(){
    $(".hname-data").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 5,
            data: [
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"}
            ]
        }
        ,
        columns: [{
            field: "historyname",
            title: "History name"
        }, {
            field: "updateddate",
            title: "Updated date"
        }]
    });
}

//Billing
function RenderBillingTable(){
    var BillingForm = new kendo.data.DataSource({
        pageSize: 20,
        data: databilling,
        autoSync: true,
        schema: {
            model: {
                id: "BillingId",
                fields: {
                    BillingId: { editable: false, nullable: true },
                    BillingItems:{ defaultValue: { BillingTypeName: "Operating Theater", BillingTypeId: "1" } },
                    BillingCategory :{ editable: false },
                    BillingGrossamount :{ type: "number", editable: true }, 
                    BillingDiscountamount :{ type: "number", editable: true }, 
                    BillingDiscount :{ type: "number", editable: true },
                    BillingNetamount :{ type: "number", editable: false },
                    BillingAgreeddiscount :{ type: "number", editable: false }
                }
            }
        }
    });

    $("#billingitem").kendoGrid({
        autobind: true,
        dataSource: BillingForm,
        scrollable: true,
        sortable: true,
        toolbar: [
            {template: kendo.template($("#BillingToolbar").html())}
        ],
        columns: [
            {
                field: "BillingItems", 
                title: "Billing items", 
                editor: BillingTypeDropDownEditor, 
                template: "#=BillingItems.BillingTypeName#",
                width:200
            },
            {
                field: "BillingCategory",
                title: "Category"
            },
            {
                field: "BillingGrossamount",
                title: "Gross amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                field: "BillingDiscountamount",
                title: "Discount amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:170
            },
            {
                field: "BillingDiscount",
                headerTemplate: "Discount",
                template: '#=kendo.format("{0:p0}", BillingDiscount/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },
            {
                field: "BillingNetamount",
                title: "Net amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                field: "BillingAgreeddiscount",
                title: "Agreed amount",
                template: '#=kendo.format("{0:p0}", BillingAgreeddiscount/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
        ],
        editable: {createAt : "top"},
        navigatable: true,
        pageable: {buttonCount: 5,pageSizes: true}
    });
}

var BillingTypeData = new kendo.data.DataSource({
    data: [
        { BillingTypeName: "Operating Theater", BillingTypeId: "1" },
        { BillingTypeName: "Surgeon fee", BillingTypeId: "2" },
        { BillingTypeName: "Hospital loan", BillingTypeId: "3" },
        { BillingTypeName: "Hopital Option", BillingTypeId: "4" }
    ]
});

function BillingTypeDropDownEditor(container, options) {
    $('<input name="BillingTypeDisplay" class="cmic-edit" required data-text-field="BillingTypeName" data-value-field="BillingTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "BillingTypeName",
            dataValueField: "BillingItems",
            dataSource: BillingTypeData
        });
}

//Content for Billing Item
var databilling = [
    {
        BillingId:1, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "Operating Theater"
        },
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16,000",
        BillingAgreeddiscount : "50"
    },{
        BillingId:2, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "Surgeon fee"
        } ,
        BillingCategory : "Doctor Charge", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "20", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "20"
    },{
        BillingId:3, 
        BillingItems : {
            BillingTypeId : 4,
            BillingTypeName : "Hopital Option"
        } ,
        BillingCategory : "Doctor Charge", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "70"
    },{
        BillingId:4, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "Operating Theater"
        } ,
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "50", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "60"
    },{
        BillingId:5, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "Surgeon fee"
        } ,
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "50", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "50"
    },{
        BillingId:6, 
        BillingItems : {
            BillingTypeId : 4,
            BillingTypeName : "Hopital Option"
        } ,
        BillingCategory : "Doctor Charge", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "70", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "10"
    },{
        BillingId:7, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "Operating Theater"
        } ,
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "40"
    }
];

//Further Claim
function RenderFurtherClaimTable(){
    var FurtherClaim = $("#FurtherClaimGrid").kendoGrid({
        dataSource: {
            data: DataFurtherClaim,
            pageSize: 10,
            schema: {
                model: {
                    id: "FurtherClaimId",
                    fields: {
                        DateReceived: { type: "string",editable: false },
                        PolicyNumber: { type: "string",editable: false },
                        CertNumber: { type: "string",editable: false },
                        InsuredName:{ type: "string",editable: false },
                        ClaimNo: { type: "string",editable: false },
                        ClaimStatus: { type: "string",editable: false },
                        AccidentDate: { type: "string",editable: false },
                        PrimaryDiagnosiscode: { type: "string",editable: false },
                        PartOfBodyInjury: { type: "string",editable: false },
                        InHospitalDate: { type: "string",editable: false },
                        DischargeDate: { type: "string",editable: false },
                        HospitalName: { type: "string",editable: false }
                    }
                }
            }
        },
        sortable: true,
        autoBind: true,
        scrollable: true,
        pageable: {buttonCount: 5, pageSizes: true},
        columns: [
            {
                field: "", 
                title: " ",
                width: 40,
                template: "<div class='grid-ticklist'><input type='radio' name='furtherclaimN' class='furtherclaimC k-radio cmic-radio' /><label class='k-radio-label grid-radio-label'></label></div>"
            },
            {field : "DateReceived", title : "Date<br/>Received", width: 150}, 
            {field : "PolicyNumber", title : "Policy<br/>Number",width: 100}, 
            {field : "CertNumber",title : "Cert<br/>Number", width: 100}, 
            {field : "InsuredName",title : "Insured<br/>Name", width: 150}, 
            {field : "ClaimNo",title : "Claim<br/>no.", width: 100}, 
            {field : "ClaimStatus",title : "Claim<br/>status", width: 100},
            {field : "AccidentDate",title : "Accident<br/>Date", width: 100},
            {field : "PrimaryDiagnosisCode",title : "Primary<br/>diagnosis code", width: 150},
            {field : "PartOfBodyInjury",title : "Part of<br/>Body injury", width: 100},
            {field : "InHospitalDate",title : "In hospital<br/>date", width: 100},
            {field : "DischargeDate",title : "Discharge<br/>date", width: 100},
            {field : "HospitalName",title : "Hospital<br/>name", width: 100},
        ],
        editable: false
    }).data("kendoGrid");

}

//Content for Further Claim
var DataFurtherClaim = [
    {
        FurtherClaimId: 1,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosisCode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 2,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 3,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 4,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 5,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    }
];