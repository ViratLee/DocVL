$(document).ready(function() {
	
	renderDropdownList();
	renderServiceListTable();
	renderPackagePriceTable();
	renderTierPricingTable();
	
});

var capitatedServiceData = [];

function renderCapServiceAutocomplete(){
	$("#capitated-service").kendoAutoComplete({
        dataSource: capitatedServiceData,
        filter: "contains",
        separator: ", "
    });
}

function renderDropdownList(){
	$("#providerID").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {text : "1",value : "1"}, 
		               {text : "2",value : "2"}, 
		               {text : "3",value : "3"} ],
		filter : "contains",
		suggest : true,
		index : 1
	});
	
	$("#providerName").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {text : "AA",value : "1"}, 
		               {text : "BB",value : "2"}, 
		               {text : "CC",value : "3"} ],
		filter : "contains",
		suggest : true,
		index : 2
	});
	$("#network").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {text : "Network 1",value : "1"}, 
		               {text : "Network 2",value : "2"}, 
		               {text : "Network 3",value : "3"}, 
		               {text : "Network 4",value : "4"} ],
		filter : "contains",
		suggest : true
	});
}

var dataServiceList = [{
	ServiceId:1, 
	ServiceItem : {
		ServiceTypeId : 1,
        ServiceTypeName : "Medicines"
    },
    ServiceDiscount : "10", 
    ServiceListPrice : "10,000", 
    ServiceAgreeFee : "0.00", 
    ServiceNoDiscount : "No", 
    ServiceNotPaid : "Yes"
},{
	ServiceId:2, 
	ServiceItem : {
		ServiceTypeId : 2,
		ServiceTypeName : "Medical Supplies 1"
    } ,
    ServiceDiscount : "20", 
    ServiceListPrice : "20,000", 
    ServiceAgreeFee : "0.00", 
    ServiceNoDiscount : "Yes", 
    ServiceNotPaid : "No"
}];

function renderServiceListTable(){
	var serviceList = new kendo.data.DataSource({
	    pageSize: 10,
	    data: dataServiceList,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "ServiceId",
	            fields: {
	                ServiceId: { editable: false, nullable: true },
	                ServiceItem:{ defaultValue: { ServiceTypeName: "Operating Theater", ServiceTypeId: "1" } },
	                ServiceDiscount :{ editable: true },
	                ServiceListPrice :{ type: "number", editable: true }, 
	                ServiceAgreeFee :{ type: "number", editable: true }, 
	                ServiceNoDiscount :{ type: "boolean" },
	                ServiceNotPaid :{ type: "boolean" }
	            }
	        }
	    }
	});
	
	$("#serviceList").kendoGrid({
	    autobind: true,
	    dataSource: serviceList,
	    pageable: false,
	    pageSize: 20,
	    toolbar: [{ name: "create", text: "Add New Service", iconClass: "glyphicon glyphicon-plus-sign"}],
	    columns: [
	        {field: "ServiceItem", title: "Service items", width: "260px", editor: serviceItemDropDownEditor, template: "#=ServiceItem.ServiceTypeName#" },
	        {field: "ServiceDiscount",title: "Discount %",format: "{0:p0}",},
	        {field: "ServiceListPrice",title: "List price"},
	        {field: "ServiceAgreeFee",title: "Agreed fee"},
			{template: '<input type="checkbox" #= ServiceNoDiscount ? \'checked="checked"\' : "" # class="cmic-checkbox" id="nodiscount"/>'
					, title: "No Discount"},
	        {template: '<input type="checkbox" #= ServiceNotPaid ? \'checked="checked"\' : "" # class="cmic-checkbox" />', title: "Not Paid"   },
	        { command: "destroy", title: " ", width: "100px" }],
	    editable: true,
	    navigatable: true
		});
	
}

var serviceTypeData = new kendo.data.DataSource({
    data: [
        { ServiceTypeName: "Medicines", ServiceTypeId: "1" },
        { ServiceTypeName: "Medical Supplies 1", ServiceTypeId: "2" },
        { ServiceTypeName: "Medical Supplies 2", ServiceTypeId: "3" },
        { ServiceTypeName: "Medical Supplies 3", ServiceTypeId: "4" },
        { ServiceTypeName: "Laboratory Investigation and Pathology", ServiceTypeId: "5" },
        { ServiceTypeName: "Diagnostic Radiology and Radiotherapy", ServiceTypeId: "6" }
    ]
});


function serviceItemDropDownEditor(container, options) {
    $('<input name="serviceItemDisplay" class="cmic-edit" required data-text-field="ServiceTypeName" data-value-field="ServiceTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "ServiceTypeName",
            dataValueField: "ServiceItem",
            dataSource: serviceTypeData
        });
}


//  ===================== Package Pricing
var dataPackagePricing = [{
	PackagePriceId:1, 
	PackagePriceItems: {
		icdCode : "icd9",
		icdName : "ICD 9"
    },
    PackagePriceName : "xxxxxxxx", 
    PackagePrice : "10000"
},{
	PackagePriceId:2, 
	PackagePriceItems : {
		icdCode : "icd10",
		icdName : "ICD 10"
    },
    PackagePriceName : "kkkkkkkkk", 
    PackagePrice : "5000"
}];
function renderPackagePriceTable(){
	var packageList = new kendo.data.DataSource({
	    pageSize: 10,
	    data: dataPackagePricing,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "PackagePriceId",
	            fields: {
	            	PackagePriceId: { editable: false, nullable: true },
	            	PackagePriceItems:{ defaultValue: { icdCode: "icd9", icdName: "ICD 9" } },
	            	PackagePriceName :{ editable: true },
	            	PackagePrice :{ type: "number", editable: true }
	            }
	        }
	    }
	});
	$("#packagePricing").kendoGrid({
	    autobind: true,
	    dataSource: packageList,
	    pageable: false,
	    pageSize: 20,
	    toolbar: [{ name: "create", text: "Add New Package", iconClass: "glyphicon glyphicon-plus-sign"}],
	    columns: [
	        {field: "PackagePriceName", title: "Package name", width: "260px", },
	        {field: "PackagePriceItems",title: "ICD Code",editor: packageItemDropDownEditor, template: "#=PackagePriceItems.icdName#" },
	        {field: "PackagePrice",title: "Price (THB)",format: "{0:n0}", decimals: 1 },
	        { command: "destroy", title: " ", width: "100px" }],
	    editable: true,
	    navigatable: true
		});
}
var icdCodeData = new kendo.data.DataSource({
    data: [
        { icdName: "ICD 9", icdCode: "icd9" },
        { icdName: "ICD 10", icdCode: "icd10" }
    ]
});
function packageItemDropDownEditor(container, options) {
    $('<input name="icdCodeDisplay" class="cmic-edit" required data-text-field="icdName" data-value-field="icdCode" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "icdName",
            dataValueField: "PackagePriceItems",
            dataSource: icdCodeData
        });
}

//  ===================== Tier Pricing
var dataTierPricing = [{
	Id:1, 
	VolumnDiscount : "20", 
    TierPricing : "2"
},{
	Id:2, 
	VolumnDiscount : "30", 
    TierPricing : "3"
}];
function renderTierPricingTable(){
	var tierList = new kendo.data.DataSource({
	    pageSize: 10,
	    data: dataTierPricing,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "Id",
	            fields: {
	            	Id: { editable: false, nullable: true },
	            	VolumnDiscount:{ type: "number", editable: true},
	            	TierPricing :{ type: "number", editable: true}
	            }
	        }
	    }
	});
	$("#tierPricing").kendoGrid({
	    autobind: true,
	    dataSource: tierList,
	    pageable: false,
	    pageSize: 20,
	    toolbar: [{ name: "create", text: "Add New Tier Pricing", iconClass: "glyphicon glyphicon-plus-sign"}],
	    columns: [
	        {field: "VolumnDiscount", title: "Volumn Discount (MTHB)",  },
	        {field: "TierPricing",title: "Tier Pricing (%)"},
	        { command: "destroy", title: " ", width: "100px" }],
	    editable: true,
	    navigatable: true
		});
}


