$(document).ready(function() {
	renderContactDetailTable();
	renderDocumentUpload();
});

//kendo Upload
function renderDocumentUpload(){
	 $("#FilesUpload").kendoUpload({
		async: {
			saveUrl: "save",
			removeUrl: "remove",
			allowmultiple: false,
			autoUpload: true
			
		},
		localization: {
			select: "Browse File"
		}
	});
}
		
//Contact Detail
function renderContactDetailTable(){
	var ContactDetail = new kendo.data.DataSource({
	    pageSize: 10,
	    data: DataContactDetail,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "Id",
	            fields: {
	            	Id: { editable: false, nullable: true },
	            	ContactPoint:{ type: "string", editable: true},
	            	Telephone :{ type: "string", editable: true},
	            	Fax :{ type: "string", editable: true},
	            	Email :{ type: "string", editable: true}
	            }
	        }
	    }
	});
	$("#ContactDetailGrid").kendoGrid({
		autobind: true,
		dataSource: ContactDetail,
		scrollable: true,
		sortable: true,
		toolbar: [
		    {template: kendo.template($("#ContactDetailToolbar").html())}
		],
	    columns: [
	        {field: "ContactPoint", title: "Contact point", width:300},
	        {field: "Telephone", title: "Telephone"},
	        {field: "Fax", title: "Fax"},
	        {field: "Email", title: "Email"},
	        {
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
	    ],
	    editable: {createAt : "top"},
	    navigatable: true,
	    pageable: {buttonCount: 5,pageSizes: true}
	});
}

//Content for Contact Detail
var DataContactDetail = [
	{
		Id: 1,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 2,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 3,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 4,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 5,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 6,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 7,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 8,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 10,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 11,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 12,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 13,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	},{
		Id: 14,
		ContactPoint: "Medical institution",
		Telephone: "025551234",
		Fax: "025551234",
		Email: "example@email.com"
	}
];
