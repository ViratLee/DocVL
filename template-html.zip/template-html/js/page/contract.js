$(document).ready(function() {
	renderServiceListTable();
	renderPackagePriceTable();
	renderTierPricingTable();
});

//Service list
function renderServiceListTable(){
	var serviceList = new kendo.data.DataSource({
	    pageSize: 10,
	    data: dataServiceList,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "ServiceId",
	            fields: {
	                ServiceId: { editable: false, nullable: true },
	                ServiceItem:{ defaultValue: { ServiceTypeName: "Operating Theater", ServiceTypeId: "1" } },
	                ServiceDiscount :{ type: "number", editable: true },
	                ServiceListPrice :{ type: "number", editable: true }, 
	                ServiceAgreeFee :{ type: "number", editable: true }, 
	                ServiceNoDiscount :{ type: "boolean" },
	                ServiceNotPaid :{ type: "boolean" }
	            }
	        }
	    }
	});
	
	$("#serviceList").kendoGrid({
	    autobind: true,
	    dataSource: serviceList,
	    scrollable: true,
	    sortable: true,
	    pageable: {
	        buttonCount: 5,
	        pageSizes: true
	    },
	    toolbar: [
            {template: kendo.template($("#serviceListtoolbar").html())}
        ],
	    columns: [
	        {
	        	field: "ServiceItem", 
	        	title: "Service items", 
	        	editor: serviceItemDropDownEditor, 
	        	template: "#=ServiceItem.ServiceTypeName#",
	        	width: 260
	        },
	        {
	        	field: "ServiceDiscount", 
	        	template: '#=kendo.format("{0:p0}", ServiceDiscount/100)#',
	        	title: "Discount",
	        	headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:100
	        },
	        {
	        	field: "ServiceListPrice",
	        	title: "List price",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:200
	        },
	        {
	        	field: "ServiceAgreeFee",
	        	title: "Agreed fee",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:200
	        },
			{
				field: "ServiceNoDiscount",
				template: '<input type="checkbox" #= ServiceNoDiscount ? \'checked="checked"\' : "" # id="nodiscount"/>', 
				title: "No Discount",
				headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-center"},
                width:120
			},
	        {
	        	field: "ServiceNotPaid",
	        	template: '<input type="checkbox" #= ServiceNotPaid ? \'checked="checked"\' : "" # />', 
	        	title: "Not Paid",
	        	headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-center"},
                width:120
	        },
	        {
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
	    ],
	    editable: {createAt : "top"},
	    navigatable: true
	});
}

//Content for Service list	
var serviceTypeData = new kendo.data.DataSource({
    data: [
        { ServiceTypeName: "Medicines", ServiceTypeId: "1" },
        { ServiceTypeName: "Medical Supplies 1", ServiceTypeId: "2" },
        { ServiceTypeName: "Medical Supplies 2", ServiceTypeId: "3" },
        { ServiceTypeName: "Medical Supplies 3", ServiceTypeId: "4" },
        { ServiceTypeName: "Laboratory Investigation and Pathology", ServiceTypeId: "5" },
        { ServiceTypeName: "Diagnostic Radiology and Radiotherapy", ServiceTypeId: "6" }
    ]
});

function serviceItemDropDownEditor(container, options) {
    $('<input name="serviceItemDisplay" class="cmic-edit" required data-text-field="ServiceTypeName" data-value-field="ServiceTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "ServiceTypeName",
            dataValueField: "ServiceItem",
            dataSource: serviceTypeData
        });
}

var dataServiceList = [
	{
		ServiceId: 1, 
		ServiceItem : {
			ServiceTypeId : 1,
	        ServiceTypeName : "Medicines"
	    },
	    ServiceDiscount : "50", 
	    ServiceListPrice : "10000", 
	    ServiceAgreeFee : "12000", 
	    ServiceNoDiscount : false, 
	    ServiceNotPaid : true
	},{
		ServiceId: 2, 
		ServiceItem : {
			ServiceTypeId : 2,
			ServiceTypeName : "Medical Supplies 1"
	    } ,
	    ServiceDiscount : "20", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "40000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : false
	},{
		ServiceId: 3, 
		ServiceItem : {
			ServiceTypeId : 3,
			ServiceTypeName : "Medical Supplies 2"
	    } ,
	    ServiceDiscount : "30", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "60000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : true
	},{
		ServiceId: 4, 
		ServiceItem : {
			ServiceTypeId : 1,
	        ServiceTypeName : "Medicines"
	    },
	    ServiceDiscount : "50", 
	    ServiceListPrice : "10000", 
	    ServiceAgreeFee : "12000", 
	    ServiceNoDiscount : false, 
	    ServiceNotPaid : true
	},{
		ServiceId: 5, 
		ServiceItem : {
			ServiceTypeId : 2,
			ServiceTypeName : "Medical Supplies 1"
	    } ,
	    ServiceDiscount : "90", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "40000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : false
	},{
		ServiceId: 6, 
		ServiceItem : {
			ServiceTypeId : 3,
			ServiceTypeName : "Medical Supplies 2"
	    } ,
	    ServiceDiscount : "65", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "60000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : true
	},{
		ServiceId: 7, 
		ServiceItem : {
			ServiceTypeId : 1,
	        ServiceTypeName : "Medicines"
	    },
	    ServiceDiscount : "42", 
	    ServiceListPrice : "10000", 
	    ServiceAgreeFee : "12000", 
	    ServiceNoDiscount : false, 
	    ServiceNotPaid : true
	},{
		ServiceId: 8, 
		ServiceItem : {
			ServiceTypeId : 2,
			ServiceTypeName : "Medical Supplies 1"
	    } ,
	    ServiceDiscount : "12", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "40000", 
	    ServiceNoDiscount : true,
	    ServiceNotPaid : false
	},{
		ServiceId: 9, 
		ServiceItem : {
			ServiceTypeId : 3,
			ServiceTypeName : "Medical Supplies 2"
	    } ,
	    ServiceDiscount : "56", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "60000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : true
	},{
		ServiceId: 10, 
		ServiceItem : {
			ServiceTypeId : 1,
	        ServiceTypeName : "Medicines"
	    },
	    ServiceDiscount : "78", 
	    ServiceListPrice : "10000", 
	    ServiceAgreeFee : "12000", 
	    ServiceNoDiscount : false, 
	    ServiceNotPaid : true
	},{
		ServiceId: 11, 
		ServiceItem : {
			ServiceTypeId : 2,
			ServiceTypeName : "Medical Supplies 1"
	    } ,
	    ServiceDiscount : "98", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "40000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : false
	},{
		ServiceId: 12, 
		ServiceItem : {
			ServiceTypeId : 3,
			ServiceTypeName : "Medical Supplies 2"
	    } ,
	    ServiceDiscount : "89", 
	    ServiceListPrice : "20000", 
	    ServiceAgreeFee : "60000", 
	    ServiceNoDiscount : true, 
	    ServiceNotPaid : true
	}
];

//Package pricing
function renderPackagePriceTable(){
	var packageList = new kendo.data.DataSource({
	    pageSize: 10,
	    data: dataPackagePricing,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "PackagePriceId",
	            fields: {
	            	PackagePriceId: { editable: false, nullable: true },
	            	PackagePriceItems:{ defaultValue: { icdCode: "icd9", icdName: "ICD 9" } },
	            	PackagePriceName :{ editable: true },
	            	PackagePrice :{ type: "number", editable: true }
	            }
	        }
	    }
	});

	$("#packagePricing").kendoGrid({
	    autobind: true,
	    dataSource: packageList,
	    scrollable: true,
	    sortable: true,
	    pageable: {buttonCount: 5, pageSizes: true},
	    toolbar: [{template: kendo.template($("#packagePricingtoolbar").html())}],
	    columns: [
	        {
	        	field: "PackagePriceName", 
	        	title: "Package name", 
	        	width:"50%" 
	        },
	        {
	        	field: "PackagePriceItems",
	        	title: "ICD Code",
	        	editor: packageItemDropDownEditor, 
	        	template: "#=PackagePriceItems.icdName#", 
	        	width:"20%" 
	        },
	        {
	        	field: "PackagePrice",
	        	decimals: 1, 
	        	width:"20%",
	        	title: "Price (THB)",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"}
	        },
	        {
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
        	}
	    ],
	    editable: {createAt: "top"},
	    navigatable: true
	});

}

//Content for Package pricing
var icdCodeData = new kendo.data.DataSource({
    data: [
        { icdName: "ICD 9", icdCode: "icd9" },
        { icdName: "ICD 10", icdCode: "icd10" }
    ]
});

function packageItemDropDownEditor(container, options) {
    $('<input name="icdCodeDisplay" class="cmic-edit" required data-text-field="icdName" data-value-field="icdCode" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "icdName",
            dataValueField: "PackagePriceItems",
            dataSource: icdCodeData
        });
}

var dataPackagePricing = [
	{
		PackagePriceId: 1, 
		PackagePriceItems: {
			icdCode : "icd9",
			icdName : "ICD 9"
	    },
	    PackagePriceName : "More custom specifiers", 
	    PackagePrice : "10000"
	},{
		PackagePriceId: 2, 
		PackagePriceItems : {
			icdCode : "icd10",
			icdName : "ICD 10"
	    },
	    PackagePriceName : "Separator placeholder", 
	    PackagePrice : "5000"
	},{
		PackagePriceId: 3, 
		PackagePriceItems: {
			icdCode : "icd9",
			icdName : "ICD 9"
	    },
	    PackagePriceName : "More custom specifiers", 
	    PackagePrice : "10000"
	},{
		PackagePriceId: 4, 
		PackagePriceItems : {
			icdCode : "icd10",
			icdName : "ICD 10"
	    },
	    PackagePriceName : "Separator placeholder", 
	    PackagePrice : "5000"
	},{
		PackagePriceId: 5, 
		PackagePriceItems: {
			icdCode : "icd9",
			icdName : "ICD 9"
	    },
	    PackagePriceName : "More custom specifiers", 
	    PackagePrice : "10000"
	},{
		PackagePriceId: 6, 
		PackagePriceItems : {
			icdCode : "icd10",
			icdName : "ICD 10"
	    },
	    PackagePriceName : "Separator placeholder", 
	    PackagePrice : "5000"
	},{
		PackagePriceId: 7, 
		PackagePriceItems: {
			icdCode : "icd9",
			icdName : "ICD 9"
	    },
	    PackagePriceName : "More custom specifiers", 
	    PackagePrice : "10000"
	},{
		PackagePriceId: 8, 
		PackagePriceItems : {
			icdCode : "icd10",
			icdName : "ICD 10"
	    },
	    PackagePriceName : "Separator placeholder", 
	    PackagePrice : "5000"
	},{
		PackagePriceId: 9, 
		PackagePriceItems: {
			icdCode : "icd9",
			icdName : "ICD 9"
	    },
	    PackagePriceName : "More custom specifiers", 
	    PackagePrice : "10000"
	},{
		PackagePriceId: 10, 
		PackagePriceItems : {
			icdCode : "icd10",
			icdName : "ICD 10"
	    },
	    PackagePriceName : "Separator placeholder", 
	    PackagePrice : "5000"
	},{
		PackagePriceId: 11, 
		PackagePriceItems: {
			icdCode : "icd9",
			icdName : "ICD 9"
	    },
	    PackagePriceName : "More custom specifiers", 
	    PackagePrice : "10000"
	},{
		PackagePriceId: 12, 
		PackagePriceItems : {
			icdCode : "icd10",
			icdName : "ICD 10"
	    },
	    PackagePriceName : "Separator placeholder", 
	    PackagePrice : "5000"
	}
];

//Payment
function renderTierPricingTable(){
	var tierList = new kendo.data.DataSource({
	    pageSize: 10,
	    data: dataTierPricing,
	    autoSync: true,
	    schema: {
	        model: {
	            id: "Id",
	            fields: {
	            	Id: { editable: false, nullable: true },
	            	VolumnDiscount:{ type: "number", editable: true},
	            	TierPricing :{ type: "number", editable: true}
	            }
	        }
	    }
	});
	$("#tierPricing").kendoGrid({
		autobind: true,
		dataSource: tierList,
		scrollable: true,
		sortable: true,
		pageable: true,
		toolbar: [
		    {template: kendo.template($("#tierListtoolbar").html())}
		],
	    columns: [
	        {
	        	field: "VolumnDiscount", 
	        	title: "Volumn Discount (MTHB)", 
	        	width:"50%",
	        	headerAttributes: {"class": "text-left"},
                attributes: {"class": "text-left"}
	        },
	        {
	        	field: "TierPricing",
	        	title: "Tier Pricing", 
	        	template: '#=kendo.format("{0:p0}", TierPricing/100)#', 
	        	width:"30%",
	        	headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"}
	        },
	        {
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "20%"
            }
	    ],
	    editable: {createAt : "top"},
	    navigatable: true
	});
}

//Content for Payment
var dataTierPricing = [
	{
		Id: 1, 
		VolumnDiscount : "10", 
	    TierPricing : "10"
	},{
		Id: 2, 
		VolumnDiscount : "20", 
	    TierPricing : "20"
	},{
		Id: 3, 
		VolumnDiscount : "30", 
	    TierPricing : "30"
	},{
		Id: 4, 
		VolumnDiscount : "40", 
	    TierPricing : "40"
	},{
		Id: 5, 
		VolumnDiscount : "50", 
	    TierPricing : "50"
	},{
		Id: 6, 
		VolumnDiscount : "60", 
	    TierPricing : "60"
	},{
		Id: 7, 
		VolumnDiscount : "70", 
	    TierPricing : "70"
	},{
		Id: 8, 
		VolumnDiscount : "80", 
	    TierPricing : "80"
	},{
		Id: 9, 
		VolumnDiscount : "90", 
	    TierPricing : "90"
	},{
		Id: 10, 
		VolumnDiscount : "100", 
	    TierPricing : "100"
	},{
		Id: 11, 
		VolumnDiscount : "90", 
	    TierPricing : "90"
	},{
		Id: 12, 
		VolumnDiscount : "80", 
	    TierPricing : "80"
	}
];