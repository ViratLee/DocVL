$(document).ready(function() {
    RenderBillingTable();
 });   

function RenderBillingTable(){
    var billinggrid = $("#billingGrid").kendoGrid({
        dataSource: {
            data: databilling,
            pageSize: 10,
            schema: {
                model: {
                    fields: {
                        BatchNo: { type: "string",editable: false },
                        TypeOfTreatment: { type: "string",editable: false },
                        PolicyNumber: { type: "string",editable: false },
                        CertNumber: { type: "string",editable: false },
                        MemberID: { type: "string",editable: false }, 
                        InsuredName: { type: "string",editable: false },
                        ClaimsNumber: { type: "string",editable: false },
                        HospitalName: { type: "string",editable: false },
                        HospitalDate: { type: "string",editable: false },
                        DischargeDate: { type: "string",editable: false },
                        SettlementDate: { type: "string",editable: false},
                        Amount: { type: "Number",editable: false },
                        Decision: { editable: true },
                        DecisionDate: { type: "string",editable: false },
                        Reason: { editable: true },
                        TransferDate: { type: "string",editable: false }
                    }
                }
            }
        },
        sortable: true,
        selectable: "multiple, row",
        autoBind: true,
        scrollable: true,
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        },
        columns: [
            {
                field: "", 
                title: "<input id='chkall' name='chkall' type='checkbox' class='checkboxall'/>",
                width: 40,
                //locked: true,
                template: "<input name='chklist' type='checkbox' class='checkboxsub'/>"
            },
            {field: "BatchNo", title: "Batch<br/>no",width:"100px"},
            {field: "TypeOfTreatment", title: "Type of<br/>Treatment",width:"110px"},
            {field: "PolicyNumber", title: "Policy<br/>Number",width:"100px"},
            {field: "CertNumber", title: "Cert<br/>Number",width:"100px"},
            {field: "MemberID", title: "Member<br/>ID",width:"100px"},
            {field: "InsuredName", title: "Insured<br/>name",width:"100px"},
            {field: "ClaimsNumber", title: "Claims<br/>Number",width:"100px"},
            {field: "HospitalName", title: "Hospital<br/>name",width:"150px"},
            {field: "HospitalDate", title: "Hospital<br/>date",width:"100px"},
            {field: "DischargeDate", title: "Discharge<br/>date",width:"100px"},
            {
                field: "SettlementDate", 
                title: "Settlement<br/>date",
                width:"120px"
            },
            {
                field: "Amount", 
                title: "Amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:"120px"
            },
            {field: "Decision", title: "Decision",width:"150px", editor: DecisionTypeDropDownEditor, template: "#=Decision.DecisionTypeName#"},
            {field: "DecisionDate", title: "Decision<br/>date",width:"100px"},
            {field: "Reason", title: "Reason",width:"150px", editor: ReasonTypeDropDownEditor, template: "#=Reason.ReasonTypeName#"},
            {field: "TransferDate", title: "Transfer<br/>date",width:"100px"}
        ],
        editable: true
    //}).data("kendoGrid");
    });
    kendo.bind($('#detailBilling'));
    // Checkbox all
    $(".checkboxall").click(function(){
       var selectall = $("#chkall")[0].checked;
       $(".checkboxsub").each(function( index ) {
         $( this ).prop('checked', selectall);
       });
        if (selectall) {
            $("tr").addClass("k-state-selected");
        } else {
            $("tr").removeClass("k-state-selected");
        }
    });
    // Checkbox 
    $(".checkboxsub").click(function(){
           var row = $(this).closest("tr");
        if (this.checked) {
            row.addClass("k-state-selected");
        } else {
            row.removeClass("k-state-selected");
        }
    });
}
var DecisionTypeData = new kendo.data.DataSource({
    data: [
        { DecisionTypeName: "Approved", DecisionTypeId: "1" },
        { DecisionTypeName: "Declined", DecisionTypeId: "2" }
    ]
});
function DecisionTypeDropDownEditor(container, options) {
    $('<input name="DecisionTypeDisplay" class="cmic-edit" required data-text-field="DecisionTypeName" data-value-field="DecisionTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "DecisionTypeName",
            dataValueField: "Decision",
            dataSource: DecisionTypeData
        });
}
var ReasonTypeData = new kendo.data.DataSource({
    data: [
        {ReasonTypeName: "Good", ReasonTypeId: "1" },
        {ReasonTypeName: "Normal", ReasonTypeId: "2" },
        {ReasonTypeName: "Fair", ReasonTypeId: "3" },
        {ReasonTypeName: "Poor", ReasonTypeId: "4" }
    ]
});
function ReasonTypeDropDownEditor(container, options) {
    $('<input name="DecisionTypeDisplay" class="cmic-edit" required data-text-field="ReasonTypeName" data-value-field="ReasonTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "ReasonTypeName",
            dataValueField: "Reason",
            dataSource: ReasonTypeData
        });
}
//Content for billing
var databilling = [
    {
        ID: 1,
        BatchNo: "362514",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "10000000000",
        Decision : {
            DecisionTypeId : 1,
            DecisionTypeName : "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason : {
            ReasonTypeId : 2,
            ReasonTypeName : "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 2,
        BatchNo: "789456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "วีรา มณีแจ่ม",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "2500000000",
        Decision : {
            DecisionTypeId : 2,
            DecisionTypeName : "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason : {
            ReasonTypeId : 1,
            ReasonTypeName : "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 3,
        BatchNo: "159486",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "เจษฏา พรเทพ",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "60000000",
        Decision : {
            DecisionTypeId : 1,
            DecisionTypeName : "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason : {
            ReasonTypeId : 2,
            ReasonTypeName : "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 4,
        BatchNo: "357241",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "ไชยา สารสุข",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "7500000000",
        Decision : {
            DecisionTypeId : 2,
            DecisionTypeName : "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason : {
            ReasonTypeId : 1,
            ReasonTypeName : "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 5,
        BatchNo: "481523",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 6,
        BatchNo: "963147",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 7,
        BatchNo: "456123",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 8,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 9,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 10,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 11,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 12,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 13,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "200000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 14,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "300000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 15,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "20000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 16,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "100000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 17,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "900000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 18,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "700000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 19,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "800000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 20,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "600000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 21,
        BatchNo: "123456",
        TypeOfTreatment: "IPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "400000000",
        Decision: {
            DecisionTypeId: 1,
            DecisionTypeName: "Approved"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 2,
            ReasonTypeName: "Normal"
        },
        TransferDate: "06/25/2559"
    },{
        ID: 22,
        BatchNo: "123456",
        TypeOfTreatment: "OPD",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        MemberID: "12345678",
        InsuredName: "สมชาย ใจดี",
        ClaimsNumber: "12345678",
        HospitalName: "พญาไท 3",
        HospitalDate: "02/25/2559",
        DischargeDate: "03/25/2559",
        SettlementDate: "06/25/2559",
        Amount: "300000000",
        Decision: {
            DecisionTypeId: 2,
            DecisionTypeName: "Declined"
        },
        DecisionDate: "07/25/2559",
        Reason: {
            ReasonTypeId: 1,
            ReasonTypeName: "Good"
        },
        TransferDate: "06/25/2559"
    }
];