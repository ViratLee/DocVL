$(document).ready(function() {
	
	$("#show-search").click();
	renderDropdownList();
	showResult();
	$('#existing-contract').kendoComboBox();
	
	
	var myWindow = $("#select-duplicate-contract");
	myWindow.kendoWindow({
        title: "Select existing contract",
        actions: ["Close"],
        width: "300px",
        height: "100px",
        modal: true,
        visible: false
    });
	
	$("#dupContract").click(function(e){
		myWindow.data("kendoWindow").center();
		myWindow.data("kendoWindow").open();
	});
	
});

function renderDropdownList(){
	$("#providerType").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {
			text : "Public",
			value : "1"
		}, {
			text : "Private",
			value : "2"
		}, {
			text : "Hospital",
			value : "3"
		} ],
		filter : "contains",
		suggest : true,
		index : 3
	});
	$("#providerTypeSector").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {
			text : "Public",
			value : "1"
		}, {
			text : "Private",
			value : "2"
		}, {
			text : "Hospital",
			value : "3"
		} ],
		filter : "contains",
		suggest : true,
		index : 3
	});
	$("#contact").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {
			text : "CC",
			value : "1"
		}, {
			text : "HC",
			value : "2"
		}, {
			text : "OPD",
			value : "3"
		}, {
			text : "IPD",
			value : "4"
		} ],
		filter : "contains",
		suggest : true
	});
	$("#contactStatus").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {
			text : "Active",
			value : "1"
		}, {
			text : "Terminate",
			value : "2"
		} ],
		filter : "contains",
		suggest : true
	});
	
	$("#region").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {
			text : "Northeast",
			value : "1"
		}, {
			text : "North",
			value : "2"
		}, {
			text : "Central",
			value : "3"
		}, {
			text : "East",
			value : "4"
		}, {
			text : "West",
			value : "5"
		}, {
			text : "South",
			value : "6"
		} ],
		filter : "contains",
		suggest : true

	});
	$("#province").kendoComboBox({
		dataTextField : "text",
		dataValueField : "value",
		dataSource : [ {
			text : "Bangkok",
			value : "1"
		}, {
			text : "Chaing Mai",
			value : "2"
		}, {
			text : "Khon Kaen",
			value : "3"
		}, {
			text : "Songkhla",
			value : "4"
		}, {
			text : "Kanchanaburi",
			value : "5"
		}, {
			text : "Ayuthaya",
			value : "6"
		} ],
		filter : "contains",
		suggest : true
	});
}

function showResult(e) {
	//$('#resultDiv').show();
	var orders = [ {
		providerId : 1,
		providerName : "AAA",
		providerType : "HS",
		province : "Bangkok",
		region : "central",
		network : "022345678",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	}, {
		providerId : 2,
		providerName : "BBB",
		providerType : "HS",
		province : "Bangkok",
		region : "central",
		network : "022345678",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	}, {
		providerId : 3,
		providerName : "CCC",
		providerType : "HS",
		province : "Bangkok",
		region : "central",
		network : "022345678",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	}, {
		providerId : 4,
		providerName : "DDD",
		providerType : "HS",
		province : "Bangkok",
		region : "central",
		network : "022345678",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	} ];

	$("#grid").kendoGrid({
		columns : [ {
			title : "Provider ID",
			field : "providerId"
		}, {
			title : "Provider<br/>Name",
			field : "providerName"
		}, {
			title : "Provider<br/>Type",
			field : "providerType"
		}, {
			title : "province",
			field : "province"
		}, {
			title : "Region",
			field : "region"
		}, {
			title : "Network",
			field : "network"
		}, {
			title : "Provider<br>Status",
			field : "providerStatus"
		}, {
			title : "Effective<br>Date",
			field : "effectiveDate"
		}, {
			title : "Expiry<br>Date",
			field : "expiryDate"
		}, {
			title : "Contract<br>Status",
			field : "contractStatus"
		} ],
		scrollable : true,
		selectable : "row",
		sortable : true,
		dataSource : {
			data : orders,
			pageSize : 5,
			serverPaging : true,
			serverFiltering : true,
			serverSorting : true
		},
		pageable: {
            buttonCount: 5,
            pageSizes: true,
		},
		navigatable : true,
		scrollable : true
	});
}

function hideResult(e) {
	$('#resultDiv').hide();
}


