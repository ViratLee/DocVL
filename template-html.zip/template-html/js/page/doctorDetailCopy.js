$(document).ready(function() {
	getTable();
    $('.ic_table').kendoTooltip({
        position: "top",
        autoHide: true
      });
});

function getTable(){
	var data = getDataTable();
	
}

function getDataTable(){
	var returnData = new kendo.data.DataSource({
	data : [{
		ID : "1",
		OrderID : 10248,
		contactPoint : "AAA",
		telephone : "021234567",
		fax : "021234567",
		email : "test@test1.com"
	}, {
		ID : "2",
		OrderID : 10249,
		contactPoint : "BBB",
		telephone : "021234567",
		fax : "021234567",
		email : "test@test2.com"
	}, {
		ID : "3",
		OrderID : 10250,
		contactPoint : "CCC",
		telephone : "021234567",
		fax : "021234567",
		email : "test@test3.com"
	}, {
		ID : "4",
		OrderID : 10252,
		contactPoint : "DDD",
		telephone : "021234567",
		fax : "021234567",
		email : "test@test4.com"
	} ],
    pageSize: 10
    });
    return returnData;
	
}

function LinkToPageWithID(Link) {
    window.location.href = Link;
}
function DBLinkToPageWithID(Link) {
    alert("Double Click : " + Link);
}

// Add more provider name
var providercnt = 4;
var DataForProvider = [
    {key: "1", value: "หนูนา ร่าเริง"}, 
    {key: "2", value: "นภา เดชอุดม"}, 
    {key: "3", value: "สมพิศ ทัพเทพ"},
    {key: "4", value: "สมศรี เวชาชี"}
];
$(function() {
    $("#ListviewProviderName").kendoListView({
        template: kendo.template($("#listview-provider-template").html()),
        dataBound: function(e) {
        for (i = 1; i < providercnt; i++) {
            if($("#providercol"+i) != undefined) {$("#providercol"+ i).kendoComboBox({
                    filter: "contains",
                    autoBind: true,
                    dataTextField: "value", 
                    dataValueField: "key", 
                    dataSource: DataForProvider, 
                    index: 0
                });
            }
        }
        },
        dataSource: {data: dataprovider}
    });
    $("#AddProvider").kendoButton({click: function(e) {$("#ListviewProviderName").data("kendoListView").dataSource.add({id: providercnt++});}
    });
});
var dataprovider = [{id:1},{id:2},{id:3}];




// Add more CMaC warning code
var cmaccnt = 4;
var DataForCmac = [
    {key: "1", value: "CMAC001"}, 
    {key: "2", value: "CMAC002"}, 
    {key: "3", value: "CMAC003"},
    {key: "4", value: "CMAC004"}
];
$(function() {
    $("#CmacWarningCode").kendoListView({
        template: kendo.template($("#cmacwarningcode-template").html()),
        dataBound: function(e) {
        for (i = 1; i < cmaccnt; i++) {
            if($("#Cmaccol"+i) != undefined) {$("#Cmaccol"+ i).kendoComboBox({
                    filter: "contains",
                    autoBind: true,
                    dataTextField: "value", 
                    dataValueField: "key", 
                    dataSource: DataForCmac, 
                    index: 0
                });
            }
        }
        },
        dataSource: {data: datacmac}
    });
    $("#AddCmac").kendoButton({click: function(e) {$("#CmacWarningCode").data("kendoListView").dataSource.add({id: cmaccnt++});}
    });
});
var datacmac = [{id:1},{id:2},{id:3}];

// Award and certification
var awacertcnt = 4;
var DataForAwardCertification = [
    {key: "1", value: "Award and Certification 1"}, 
    {key: "2", value: "Award and Certification 2"}, 
    {key: "3", value: "Award and Certification 3"},
    {key: "4", value: "Award and Certification 4"}
];
$(function() {
    $("#AwardCertification").kendoListView({
        template: kendo.template($("#AwardCertification-template").html()),
        dataBound: function(e) {
        for (i = 1; i < awacertcnt; i++) {
            if($("#awacertcol"+i) != undefined) {$("#awacertcol"+ i).kendoComboBox({
                    filter: "contains",
                    autoBind: true,
                    dataTextField: "value", 
                    dataValueField: "key", 
                    dataSource: DataForAwardCertification, 
                    index: 0
                });
            }
        }
        },
        dataSource: {data: dataawacert}
    });
    $("#Addawacert").kendoButton({click: function(e) {$("#AwardCertification").data("kendoListView").dataSource.add({id: awacertcnt++});}
    });
});
var dataawacert = [{id:1},{id:2},{id:3}];