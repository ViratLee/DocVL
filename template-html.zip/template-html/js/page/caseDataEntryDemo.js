$(document).ready(function () {
    RenderCheckboxOption();
    RenderAuditTrailTable();
    RenderHistryNameTable();
    RenderBillingTable();
    RenderUploadDocument();
    RenderFurtherClaimTable();
    renderSelectAll();
    renderUncheckall();
    renderInjury();
    renderAttendingPractitioner();
    renderAttendingSpecialist();
    renderReferralPractitioner();
    renderInvestigationTestProcedure();
    renderDiagnosticCode();
    renderProcedureCode();
    renderPlannedTreatmentDM();
    renderPlannedTreatmentS();
    renderBB();
});


// Part of Body injury
function renderInjury(){
    var injurycnt = 4;
    var data = [
        {key: "1", value: "S39.7 - Other multiple injuries of abdomen, lower back and pelvis"}, 
        {key: "2", value: "S40.0 - Contusion of shoulder and upper arm"}
    ];

    $(function() {
        $("#listview-injury").kendoListView({
            template: kendo.template($("#listview-injury-template").html()),
            dataBound: function(e) {
            for (i = 1; i < injurycnt; i++) {
                if($("#injurycol"+i) != undefined) {$("#injurycol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: datainjury}
        });
        $("#AddInjury").kendoButton({click: function(e) {$("#listview-injury").data("kendoListView").dataSource.add({id: injurycnt++});}
        });
    });
    var datainjury = [{id:1},{id:2},{id:3}];
}

// Attending Practitioner
function renderAttendingPractitioner(){
    var apcnt = 2;
    var data = [
        {key: "1", value: "นายแพทย์รัฐพงศ์ โกรเมศ"}, 
        {key: "2", value: "แพทย์หญิงนภาเนตร เจตจำนงค์"}
    ];

    $(function() {
        $("#listviewap").kendoListView({
            template: kendo.template($("#listviewaptemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < apcnt; i++) {
                if($("#apcol"+i) != undefined) {$("#apcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: dataap}
        });
        $("#Addap").kendoButton({click: function(e) {$("#listviewap").data("kendoListView").dataSource.add({id: apcnt++});}
        });
    });
    var dataap = [{id:1}];
}

// Attending Specialist
function renderAttendingSpecialist(){
    var ascnt = 2;
    var data = [
        {key: "1", value: "1แพทย์หญิงรพีพัฒน์ ลานสภา"}, 
        {key: "2", value: "นายแพทย์วัลลภ ชรารัตน์"}
    ];

    $(function() {
        $("#listviewas").kendoListView({
            template: kendo.template($("#listviewastemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < ascnt; i++) {
                if($("#ascol"+i) != undefined) {$("#ascol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: dataas}
        });
        $("#Addas").kendoButton({click: function(e) {$("#listviewas").data("kendoListView").dataSource.add({id: ascnt++});}
        });
    });
    var dataas = [{id:1}];
}

// Referral Practitioner
function renderReferralPractitioner(){
    var rpcnt = 2;
    var data = [
        {key: "1", value: "นายแพทย์วิรัตน์ จันแก้ว"}, 
        {key: "2", value: "แพทย์หญิงนชยา อาภากร"}
    ];

    $(function() {
        $("#listviewrp").kendoListView({
            template: kendo.template($("#listviewrptemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < rpcnt; i++) {
                if($("#rpcol"+i) != undefined) {$("#rpcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: datarp}
        });
        $("#Addrp").kendoButton({click: function(e) {$("#listviewrp").data("kendoListView").dataSource.add({id: rpcnt++});}
        });
    });
    var datarp = [{id:1}];
}

// Investigation Test/Procedure
function renderInvestigationTestProcedure(){
    var itpcnt = 4;
    var data = [
        {key: "1", value: "X Ray - NPC (3 views)"}, 
        {key: "2", value: "X Ray - NPC (5 views)"}, 
        {key: "3", value: "X Ray - Optic Foramen (Both, 2 views)"},
        {key: "4", value: "X Ray - Orbits (2 views)"}
    ];

    $(function() {
        $("#listviewitp").kendoListView({
            template: kendo.template($("#listviewitptemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < itpcnt; i++) {
                if($("#itpcol"+i) != undefined) {$("#itpcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: dataitp}
        });
        $("#Additp").kendoButton({click: function(e) {$("#listviewitp").data("kendoListView").dataSource.add({id: itpcnt++});}
        });
    });
    var dataitp = [{id:1},{id:2},{id:3}];
}

// Diagnostic code
function renderDiagnosticCode(){
    var dccnt = 3;
    var data = [
        {key: "1", value: "X68.51 - Intentional self-poisoning by and exposure to pesticides: at trade & service area: in leisure activity"}, 
        {key: "2", value: "X68.52 - Intentional self-poisoning by and exposure to pesticides: at trade & service area: while work for income"}
    ];

    $(function() {
        $("#listviewdc").kendoListView({
            template: kendo.template($("#listviewdctemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < dccnt; i++) {
                if($("#dccol"+i) != undefined) {$("#dccol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: datadc}
        });
        $("#Adddc").kendoButton({click: function(e) {$("#listviewdc").data("kendoListView").dataSource.add({id: dccnt++});}
        });
    });
    var datadc = [{id:1},{id:2}];
}

// Procedure code
function renderProcedureCode(){
    var pccnt = 3;
    var data = [
        {key: "1", value: "99.03 - Whole blood transfus NEC"}, 
        {key: "2", value: "99.07 - Serum transfusion NEC"}
    ];

    $(function() {
        $("#listviewpc").kendoListView({
            template: kendo.template($("#listviewpctemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < pccnt; i++) {
                if($("#pccol"+i) != undefined) {$("#pccol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: datapc}
        });
        $("#Addpc").kendoButton({click: function(e) {$("#listviewpc").data("kendoListView").dataSource.add({id: pccnt++});}
        });
    });
    var datapc = [{id:1},{id:2}];
}

// Planned Treatment- Drug/Medication
function renderPlannedTreatmentDM(){
    var ptdcnt = 4;
    var data = [
        {key: "1", value: "99.07 - Serum transfusion NEC"}, 
        {key: "2", value: "99.03 - Whole blood transfus NEC"}
    ];

    $(function() {
        $("#listviewptd").kendoListView({
            template: kendo.template($("#listviewptdtemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < ptdcnt; i++) {
                if($("#ptdcol"+i) != undefined) {$("#ptdcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: dataptd}
        });
        $("#Addptd").kendoButton({click: function(e) {$("#listviewptd").data("kendoListView").dataSource.add({id: ptdcnt++});}
        });
    });
    var dataptd = [{id:1},{id:2},{id:3}];
}

// Planned Treatment- Surgery
function renderPlannedTreatmentS(){
    var ptscnt = 4;
    var data = [
        {key: "1", value: "99.04 - Packed cell transfusion"}, 
        {key: "2", value: "99.06 - Coag factor transfusion"}
    ];

    $(function() {
        $("#listviewpts").kendoListView({
            template: kendo.template($("#listviewptstemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < ptscnt; i++) {
                if($("#ptscol"+i) != undefined) {$("#ptscol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
                if($("#datecol"+i) != undefined) {$("#datecol"+ i).kendoDatePicker({
                       value:new Date(),
                       format: "yyyy/MM/dd"
                    });
                }
            }

            },
            dataSource: {data: datapts}
        });
        $("#Addpts").kendoButton({click: function(e) {$("#listviewpts").data("kendoListView").dataSource.add({id: ptscnt++});}
        });
    });
    var datapts = [{id:1},{id:2},{id:3}];
}

// BB-LIFE/BB-PA
function renderBB(){
    var bbcnt = 4;
    var data = [
        {key: "1", value: "ขาท่อนล่าง, กะโหลกศรีษะ, กระดูกไหปลาร้า, ข้อเท้า ,ข้อศอก, แขนท่อนบนและท่อนล่าง - การแตกหักโดยมีการทิ่มทะลุ - 15%"}, 
        {key: "2", value: "ขาท่อนล่าง, กะโหลกศรีษะ, กระดูกไหปลาร้า, ข้อเท้า ,ข้อศอก, แขนท่อนบนและท่อนล่าง - การแตกหักมากกว่า 1 แห่ง โดยมีการหักจากกันอย่างสมบูรณ์อย่างน้อย 1 แห่ง - 12%"}, 
        {key: "3", value: "ขาท่อนล่าง, กะโหลกศรีษะ, กระดูกไหปลาร้า, ข้อเท้า ,ข้อศอก, แขนท่อนบนและท่อนล่าง - กะโหลกศรีษะยุบ (Depressed Fracture) ซึ่งจำเป็นต้องแก้ไขโดยการศัลยกรรม - 7.2%"}
    ];

    $(function() {
        $("#listviewbb").kendoListView({
            template: kendo.template($("#listviewbbtemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < bbcnt; i++) {
                if($("#bbcol"+i) != undefined) {$("#bbcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "value", 
                        dataValueField: "key", 
                        dataSource: data, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: databb}
        });
        $("#Addbb").kendoButton({click: function(e) {$("#listviewbb").data("kendoListView").dataSource.add({id: bbcnt++});}
        });
    });
    var databb = [{id:1},{id:2},{id:3}];
}

//check all 
function renderSelectAll(){
    $('#selectAll').click(function(){
        $('.spcheckbox').each(function(){
        $(this).prop("checked",true);
        });
    });
}

//uncheck all
function renderUncheckall(){
    $('#unSelectAll').click(function(){
        $('.spcheckbox').each(function(){
        $(this).prop("checked",false);
        });
    });
}

//kendo Upload
function RenderUploadDocument(){
     $("#FilesUpload").kendoUpload({
        async: {
            saveUrl: "save",
            removeUrl: "remove",
            allowmultiple: false,
            autoUpload: true
            
        },
        localization: {
            select: "Browse File"
        }
    });
}

function RenderCheckboxOption(){
    $(".doctoroption-1 input[type='checkbox']").click(function(){
        $(".doctorresult-1").toggleClass("none");
    });
    $(".doctoroption-2 input[type='checkbox']").click(function(){
        $(".doctorresult-2").toggleClass("none");
    });
    $(".doctoroption-3 input[type='checkbox']").click(function(){
        $(".doctorresult-3").toggleClass("none");
    });
    // Reason for ICU Admission
    $(".admissionreason-1 input[type='checkbox']").click(function(){
        $(".admissionresult-1").toggleClass("none");
    });
    
    $(".admissionreason-2 input[type='checkbox']").click(function(){
        $(".admissionresult-2").toggleClass("none");
    });
}
//after click audit trail
function RenderAuditTrailTable(){
    $("#AuditTrail").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 10,
            data: [
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 12:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 18:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 09:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 14:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 08:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 12:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 18:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 09:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 14:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 08:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"}
            ]
        }
        ,
        columns: [
            {field: "Timestamp", title: "Timestamp", width: 150},
            {field: "Action", title: "Action"}, 
            {field: "DocID", title: "DocID", width:120}
        ]
    });
}

//Histry Name
function RenderHistryNameTable(){
    $(".hname-data").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 5,
            data: [
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"}
            ]
        }
        ,
        columns: [{
            field: "historyname",
            title: "History name"
        }, {
            field: "updateddate",
            title: "Updated date"
        }]
    });
}

//Billing
function RenderBillingTable(){
    var BillingForm = new kendo.data.DataSource({
        pageSize: 20,
        data: databilling,
        autoSync: true,
        schema: {
            model: {
                id: "BillingId",
                fields: {
                    BillingId: { editable: false, nullable: true },
                    BillingItems:{ defaultValue: { BillingTypeName: "Operating Theater", BillingTypeId: "1" } },
                    BillingCategory :{ editable: false },
                    BillingGrossamount :{ type: "number", editable: true }, 
                    BillingDiscountamount :{ type: "number", editable: true }, 
                    BillingDiscount :{ type: "number", editable: true },
                    BillingNetamount :{ type: "number", editable: false },
                    BillingAgreeddiscount :{ type: "number", editable: false }
                }
            }
        }
    });

    $("#billingitem").kendoGrid({
        autobind: true,
        dataSource: BillingForm,
        scrollable: true,
        sortable: true,
        toolbar: [
            {template: kendo.template($("#BillingToolbar").html())}
        ],
        columns: [
            {
                field: "BillingItems", 
                title: "Billing items", 
                editor: BillingTypeDropDownEditor, 
                template: "#=BillingItems.BillingTypeName#",
                width:300
            },
            {
                field: "BillingCategory",
                title: "Category",
                width:250
            },
            {
                field: "BillingGrossamount",
                title: "Gross amount",
                format: "{0:n2}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                field: "BillingDiscountamount",
                title: "Discount amount",
                format: "{0:n2}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:170
            },
            {
                field: "BillingDiscount",
                headerTemplate: "Discount",
                template: '#=kendo.format("{0:p0}", BillingDiscount/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },
            {
                field: "BillingNetamount",
                title: "Net amount",
                format: "{0:n2}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                field: "BillingAgreeddiscount",
                title: "Agreed amount",
                template: '#=kendo.format("{0:p0}", BillingAgreeddiscount/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
        ],
        editable: {createAt : "bottom"},
        navigatable: true,
        pageable: {buttonCount: 5,pageSizes: true},
        beforeEdit: function (e) {
        if (e.field === "BillingItems") {
            e.preventDefault();
            var grid = $("#billingItem").data("kendoGrid");
            var current = grid.current();
            $(current).find(".k-input").first().focus();
        }
    }
    });
}

var BillingTypeData = new kendo.data.DataSource({
    data: [
        { BillingTypeName: "1.2.1 - Physician Evaluation and Management Services", BillingTypeId: "1" },
        { BillingTypeName: "2.6 - Other Hospital Charge ค่าบริการอื่นๆ ", BillingTypeId: "2" }
    ]
});

function BillingTypeDropDownEditor(container, options) {
    $('<input name="BillingTypeDisplay" class="cmic-edit" required data-text-field="BillingTypeName" data-value-field="BillingTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "BillingTypeName",
            dataValueField: "BillingItems",
            dataSource: BillingTypeData,
            dataBound: function (e) {
                var combo = $("name['BillingTypeDisplay']").data("kendoComboBox");
                combo.select();
            }
        });

        
}

//Content for Billing Item
var databilling = [
    {
        BillingId:1, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "1.2.1 - Physician Evaluation and Management Services"
        },
        BillingCategory : "Physician Evaluation and Management Services", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16,000",
        BillingAgreeddiscount : "50"
    },{
        BillingId:2, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "2.6 - Other Hospital Charge ค่าบริการอื่นๆ "
        } ,
        BillingCategory : "Other Hospital Charge ค่าบริการอื่นๆ ", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "20", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "20"
    },{
        BillingId:3, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "1.2.1 - Physician Evaluation and Management Services"
        } ,
        BillingCategory : "Physician Evaluation and Management Services", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "70"
    },{
        BillingId:4, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "1.2.1 - Physician Evaluation and Management Services"
        } ,
        BillingCategory : "Other Hospital Charge  ค่าบริการอื่นๆ ", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "50", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "60"
    },{
        BillingId:5, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "2.6 - Other Hospital Charge ค่าบริการอื่นๆ "
        } ,
        BillingCategory : "Physician Evaluation and Management Services", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "50", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "50"
    },{
        BillingId:6, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "1.2.1 - Physician Evaluation and Management Services"
        } ,
        BillingCategory : "Other Hospital Charge ค่าบริการอื่นๆ ", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "70", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "10"
    },{
        BillingId:7, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "2.6 - Other Hospital Charge ค่าบริการอื่นๆ "
        } ,
        BillingCategory : "Other Hospital Charge ค่าบริการอื่นๆ ", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "40"
    }
];

//Further Claim
function RenderFurtherClaimTable(){
    var FurtherClaim = $("#FurtherClaimGrid").kendoGrid({
        dataSource: {
            data: DataFurtherClaim,
            pageSize: 10,
            schema: {
                model: {
                    id: "FurtherClaimId",
                    fields: {
                        DateReceived: { type: "string",editable: false },
                        PolicyNumber: { type: "string",editable: false },
                        CertNumber: { type: "string",editable: false },
                        InsuredName:{ type: "string",editable: false },
                        ClaimNo: { type: "string",editable: false },
                        ClaimStatus: { type: "string",editable: false },
                        AccidentDate: { type: "string",editable: false },
                        PrimaryDiagnosiscode: { type: "string",editable: false },
                        PartOfBodyInjury: { type: "string",editable: false },
                        InHospitalDate: { type: "string",editable: false },
                        DischargeDate: { type: "string",editable: false },
                        HospitalName: { type: "string",editable: false }
                    }
                }
            }
        },
        sortable: true,
        autoBind: true,
        scrollable: true,
        pageable: {buttonCount: 5, pageSizes: true},
        columns: [
            {
                field: "", 
                title: " ",
                width: 40,
                template: "<div class='grid-ticklist'><input type='radio' name='furtherclaimN' class='furtherclaimC k-radio cmic-radio' /><label class='k-radio-label grid-radio-label'></label></div>"
            },
            {field : "DateReceived", title : "Date<br/>Received", width: 150}, 
            {field : "PolicyNumber", title : "Policy<br/>Number",width: 100}, 
            {field : "CertNumber",title : "Cert<br/>Number", width: 100}, 
            {field : "InsuredName",title : "Insured<br/>Name", width: 150}, 
            {field : "ClaimNo",title : "Claim<br/>no.", width: 100}, 
            {field : "ClaimStatus",title : "Claim<br/>status", width: 100},
            {field : "AccidentDate",title : "Accident<br/>Date", width: 100},
            {field : "PrimaryDiagnosisCode",title : "Primary<br/>diagnosis code", width: 150},
            {field : "PartOfBodyInjury",title : "Part of<br/>Body injury", width: 100},
            {field : "InHospitalDate",title : "In hospital<br/>date", width: 100},
            {field : "DischargeDate",title : "Discharge<br/>date", width: 100},
            {field : "HospitalName",title : "Hospital<br/>name", width: 100},
        ],
        editable: false
    }).data("kendoGrid");

}

//Content for Further Claim
var DataFurtherClaim = [
    {
        FurtherClaimId: 1,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosisCode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 2,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 3,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 4,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    },{
        FurtherClaimId: 5,
        DateReceived: "06/12/2559  15:35",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "ชื่อ นามสกุล",
        ClaimNo: "11111222",
        ClaimStatus: "xxxxxxxxx",
        AccidentDate: "06/12/2559",
        PrimaryDiagnosiscode: "12345678",
        PartOfBodyInjury: "xxxxxxxxx",
        InHospitalDate: "06/12/2559",
        DischargeDate: "06/15/2559",
        HospitalName: "พญาไท 3"
    }
];