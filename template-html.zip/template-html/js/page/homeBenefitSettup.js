$(document).ready(function() {
    var databenefit = [
            {
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "IL",
                "ProductType": "-",
                "PolicyNo": "0000080176",
                "FurtherClaimDay": "90",
                "EmergencyDay": "1",
                "ProductCode": "HSN7",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "HSN7",
                "PlanThaiName": "สัญญาเพิ่มเติมค่ารักษาพยาบาลและศัลยกรรม",
                "EffectiveDate": "05/01/2001",
                "TerminationDate": "05/01/2001",
                "NetworkCode": "-",
                "NetworkBenefit": "- ",
                "BenefitType": "HSN7",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "CS",
                "ProductType": "-",
                "PolicyNo": "0000011644",
                "FurtherClaimDay": "60",
                "EmergencyDay": "1",
                "ProductCode": "31400",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "DENTAL",
                "PlanThaiName": "ผลประโยชน์แบบค่ารักษาฟัน",
                "EffectiveDate": "04/18/2015",
                "TerminationDate": "04/18/2015",
                "NetworkCode": "-",
                "NetworkBenefit": "Network ",
                "BenefitType": "Dental Care",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "IL",
                "ProductType": "-",
                "PolicyNo": "0000080176",
                "FurtherClaimDay": "90",
                "EmergencyDay": "1",
                "ProductCode": "HSN7",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "HSN7",
                "PlanThaiName": "สัญญาเพิ่มเติมค่ารักษาพยาบาลและศัลยกรรม",
                "EffectiveDate": "05/01/2001",
                "TerminationDate": "05/01/2001",
                "NetworkCode": "-",
                "NetworkBenefit": "- ",
                "BenefitType": "HSN7",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "IL",
                "ProductType": "-",
                "PolicyNo": "0000080176",
                "FurtherClaimDay": "90",
                "EmergencyDay": "1",
                "ProductCode": "HSN7",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "HSN7",
                "PlanThaiName": "สัญญาเพิ่มเติมค่ารักษาพยาบาลและศัลยกรรม",
                "EffectiveDate": "05/01/2001",
                "TerminationDate": "05/01/2001",
                "NetworkCode": "-",
                "NetworkBenefit": "- ",
                "BenefitType": "HSN7",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "IL",
                "ProductType": "-",
                "PolicyNo": "0000080176",
                "FurtherClaimDay": "90",
                "EmergencyDay": "1",
                "ProductCode": "HSN7",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "HSN7",
                "PlanThaiName": "สัญญาเพิ่มเติมค่ารักษาพยาบาลและศัลยกรรม",
                "EffectiveDate": "05/01/2001",
                "TerminationDate": "05/01/2001",
                "NetworkCode": "-",
                "NetworkBenefit": "- ",
                "BenefitType": "HSN7",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "IL",
                "ProductType": "-",
                "PolicyNo": "0000080176",
                "FurtherClaimDay": "90",
                "EmergencyDay": "1",
                "ProductCode": "HSN7",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "HSN7",
                "PlanThaiName": "สัญญาเพิ่มเติมค่ารักษาพยาบาลและศัลยกรรม",
                "EffectiveDate": "05/01/2001",
                "TerminationDate": "05/01/2001",
                "NetworkCode": "-",
                "NetworkBenefit": "- ",
                "BenefitType": "HSN7",
                "Cash": "100",
                "Cashless": "80"
            },{
                "BussinessLine": "IL",
                "ProductType": "-",
                "PolicyNo": "0000080176",
                "FurtherClaimDay": "90",
                "EmergencyDay": "1",
                "ProductCode": "HSN7",
                "SubPlanCode": "003",
                "PlanCode": "20110",
                "PlanShortName": "DENTAL",
                "PlanName": "HSN7",
                "PlanThaiName": "สัญญาเพิ่มเติมค่ารักษาพยาบาลและศัลยกรรม",
                "EffectiveDate": "05/01/2001",
                "TerminationDate": "05/01/2001",
                "NetworkCode": "-",
                "NetworkBenefit": "- ",
                "BenefitType": "HSN7",
                "Cash": "100",
                "Cashless": "80"
            }
        ];

    var benefitgrid = $("#benefitgrid").kendoGrid({
        toolbar: [
            {template: kendo.template($("#cust_toolbar").html())}
        ],
        dataSource: {
            data: databenefit,
            pageSize: 10,
            schema: {
                model: {
                    fields: {
                        BussinessLine: { type: "string",editable: false },
                        ProductType: { type: "string",editable: false },
                        PolicyNo: { type: "string",editable: false },
                        FurtherClaimDay: { type: "string",editable: false },
                        EmergencyDay: { type: "string",editable: false },
                        ProductCode: { type: "string",editable: false },
                        SubPlanCode: { type: "string",editable: false },
                        PlanCode: { type: "string",editable: false },
                        PlanShortName: { type: "string",editable: false },
                        PlanName: { type: "string",editable: false },
                        PlanThaiName: { type: "string",editable: false },
                        EffectiveDate: { type: "string",editable: false },
                        TerminationDate: { type: "string",editable: false },
                        NetworkCode: { type: "string",editable: false },
                        NetworkBenefit: { type: "string",editable: false },
                        BenefitType: { type: "string",editable: false },
                        Cash: { type: "string",editable: false },
                        Cashless: { type: "string",editable: false }
                    }
                }
            }
        },
        sortable: true,
        selectable: "multiple, row",
        autoBind: true,
        scrollable: true,
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        },
        columns: [
            {
                field: "", 
                title: " ",
                width: 40, 
                template: "<input name='chkbenefit' type='checkbox' class='checkboxsub cmic-checkbox-table large custom'/>",
                locked: true
            },
            {
                field: "", 
                title: " ",
                width: 40, 
                template: "<a href='\\#ModalBenefitPart3' data-toggle='modal' class='clickmodal'><span class='glyphicon glyphicon-pencil'></span></a>",
                locked: true
            },
            {field: "BussinessLine", title: "Bussiness<br/>Line",width:"100px"},
            {field: "ProductType", title: "Product<br/>Type",width:"100px"},
            {field: "PolicyNo", title: "Policy<br/>No.",width:"100px"},
            {field: "FurtherClaimDay", title: "Further<br/>Claim Day",width:"100px"},
            {field: "EmergencyDay", title: "Emergency<br/>Day",width:"120px"},
            {field: "ProductCode", title: "Product<br/>Code",width:"100px"},
            {field: "SubPlanCode", title: "SubPlan<br/>Code",width:"100px"},
            {field: "PlanCode", title: "Plan<br/>Code",width:"100px"},
            {field: "PlanShortName", title: "Plan Short<br/>Name",width:"120px"},
            {field: "PlanName", title: "Plan<br/>Name",width:"100px"},
            {field: "PlanThaiName", title: "Plan Thai<br/>Name",width:"350px"},
            {field: "EffectiveDate", title: "Effective<br/>Date",width:"120px"},
            {field: "TerminationDate", title: "Termination<br/>Date",width:"120px"},
            {field: "NetworkCode", title: "Network<br/>Code",width:"100px"},
            {field: "NetworkBenefit", title: "Network<br/>Benefit",width:"100px"},
            {field: "BenefitType", title: "Benefit<br/>Type",width:"100px"},
            {field: "Cash", title: "Cash",width:"100px"},
            {field: "Cashless", title: "Cashless",width:"100px"}
        ],
        editable: true
    }).data("kendoGrid");
    hideExtraBtns();

    // Checkbox 
    $(".checkboxsub").click(function(){
           var row = $(this).closest("tr");
        if (this.checked) {
            row.addClass("k-state-selected");
        } else {
            row.removeClass("k-state-selected");
        }
    });

    //Add new row to grid on click of Add button.
    $(".k-cust-add", benefitgrid.element).on("click", function(ev) {
        benefitgrid.addRow();
        $(".k-cust-add").hide();
        $(".k-cust-save").show();
        $(".k-cust-cancel").show();
        $(".k-cust-edit").addClass("k-state-disabled").attr('disabled', 'disabled');
        $(".k-cust-delete").addClass("k-state-disabled").attr('disabled', 'disabled');
    });

    //Save the added row
    $(".k-cust-save", benefitgrid.element).on("click", function(ev) {
        benefitgrid.saveRow();
        restoreGridToolbar();
    });

    //Edit the currently selected row
    $(".k-cust-edit", benefitgrid.element).on("click", function(ev) {
        var selectedRows = benefitgrid.tbody.find(".k-state-selected");

        if (selectedRows.length === 0) {
            alert("Please select a record to edit.");
        } else if (selectedRows.length > 1) {
            alert("Please select a single record for editing.");
        } else if (selectedRows.length === 1) {
            benefitgrid.editRow(selectedRows);
            selectedRows.find(".grid_checkbox").attr("checked", "checked").attr('disabled','disabled');
            $(".k-cust-edit").hide();
            $(".k-cust-update").show();
            $(".k-cust-cancel").show();
            $(".k-cust-add").addClass("k-state-disabled").attr('disabled', 'disabled');
            $(".k-cust-duplicate").addClass("k-state-disabled").attr('disabled', 'disabled');
            $(".k-cust-delete").addClass("k-state-disabled").attr('disabled', 'disabled');
        }
    });

    //duplicate
     $(".k-cust-duplicate").on("click", function() {
        var items = [];
            // For the rows with checked item
            $(":checked", grid.tbody).each(function(idx, elem) {
                 // Get the row 
                 var row = $(elem).closest("tr");
                 // Get the item for that row
                 var item = grid.dataItem(row);
                 items.push(item);
            });
            // Insert it in the DataSource
            for (var i = 0; i < items.length; i++) {
                grid.dataSource.add(items[i]);
            }
      });

    //Update the details
    $(".k-cust-update", benefitgrid.element).on("click", function(ev) {
        benefitgrid.saveChanges();
        restoreGridToolbar();
    });

    //Cancel the add/edit of grid
    $(".k-cust-cancel", benefitgrid.element).on("click", function(ev) {
        benefitgrid.cancelChanges();
        restoreGridToolbar();
    });

    //Delete the selected records
    $(".k-cust-delete", benefitgrid.element).on("click", function(ev) {
        var selRows = benefitgrid.tbody.find(".k-state-selected");

        if (selRows.length > 0 && confirm("Do you want to delete " + selRows.length + " record(s)?")) {
            $.each(selRows, function(index, value) {
                benefitgrid.removeRow(value);
            });

        } else if (selRows.length === 0) {
            alert("Please select a record to delete.");
        }
    });


// Content of Benefit Part3
    var sharedDataSource = [
            {
                "Part3BenefitCode": "D01",
                "Part3IPD": "Y",
                "Part3OPD": "Y",
                "Part3DayCase": "Y",
                "Part3IndemnityPercentage": "5",
                "Part3NoOfDays": "4",
                "Part3MaxNoOfDays": "5",
                "Part3confinementDay": "0",
                "Part3MaxBenefitAmount": "1",
                "Part3MaxConfinementAmount": "5",
                "Part3MaxYearAmount": "4",
                "Part3MaxMajorConfinement": "9",
                "Part3NonIpdSurgeryAmount": "7",
                "Part3IpdSurgeryAmount": "5",
                "Part3SpecialIpdAmount": "4",
                "Part3ChangeDate": "01/01/2010",
                "Part3MaxNoOfDaysHist": "5",
                "Part3TotalBenefitAmount": "5",
                "Part3WaitingPeriod": "5",
                "Part3SACalculateType": "5"
            },{
                "Part3BenefitCode": "D88",
                "Part3IPD": "Y",
                "Part3OPD": "Y",
                "Part3DayCase": "Y",
                "Part3IndemnityPercentage": "5",
                "Part3NoOfDays": "4",
                "Part3MaxNoOfDays": "5",
                "Part3confinementDay": "0",
                "Part3MaxBenefitAmount": "1",
                "Part3MaxConfinementAmount": "5",
                "Part3MaxYearAmount": "4",
                "Part3MaxMajorConfinement": "9",
                "Part3NonIpdSurgeryAmount": "7",
                "Part3IpdSurgeryAmount": "5",
                "Part3SpecialIpdAmount": "4",
                "Part3ChangeDate": "01/01/2010",
                "Part3MaxNoOfDaysHist": "5",
                "Part3TotalBenefitAmount": "5",
                "Part3WaitingPeriod": "5",
                "Part3SACalculateType": "5"
            },{
                "Part3BenefitCode": "H01",
                "Part3IPD": "Y",
                "Part3OPD": "Y",
                "Part3DayCase": "Y",
                "Part3IndemnityPercentage": "5",
                "Part3NoOfDays": "4",
                "Part3MaxNoOfDays": "5",
                "Part3confinementDay": "0",
                "Part3MaxBenefitAmount": "1",
                "Part3MaxConfinementAmount": "5",
                "Part3MaxYearAmount": "4",
                "Part3MaxMajorConfinement": "9",
                "Part3NonIpdSurgeryAmount": "7",
                "Part3IpdSurgeryAmount": "5",
                "Part3SpecialIpdAmount": "4",
                "Part3ChangeDate": "01/01/2010",
                "Part3MaxNoOfDaysHist": "5",
                "Part3TotalBenefitAmount": "5",
                "Part3WaitingPeriod": "5",
                "Part3SACalculateType": "5"
            }
        ];

    var benefitpart3 = $("#benefitpart3").kendoGrid({
        toolbar: [
            {template: kendo.template($("#ToolbarBenefitPart3").html())}
        ],
        dataSource: {
            data: sharedDataSource,
            pageSize: 20,
            schema: {
                model: {
                    fields: {
                        Part3BenefitCode: { type: "string",editable: true },
                        Part3IPD: { type: "string",editable: true },
                        Part3OPD: { type: "string",editable: true },
                        Part3DayCase: { type: "string",editable: true },
                        Part3IndemnityPercentage: { type: "string",editable: true },
                        Part3NoOfDays: { type: "string",editable: true },
                        Part3MaxNoOfDays: { type: "string",editable: true },
                        Part3confinementDay: { type: "string",editable: true },
                        Part3MaxBenefitAmount: { type: "string",editable: true },
                        Part3MaxConfinementAmount: { type: "string",editable: true },
                        Part3MaxYearAmount: { type: "string",editable: true },
                        Part3MaxMajorConfinement: { type: "string",editable: true },
                        Part3NonIpdSurgeryAmount: { type: "string",editable: true },
                        Part3IpdSurgeryAmount: { type: "string",editable: true },
                        Part3SpecialIpdAmount: { type: "string",editable: true },
                        Part3ChangeDate: { type: "date",editable: true },
                        Part3MaxNoOfDaysHist: { type: "string",editable: true },
                        Part3TotalBenefitAmount: { type: "string",editable: true },
                        Part3WaitingPeriod: { type: "string",editable: true },
                        Part3SACalculateType: { type: "string",editable: true }
                    }
                }
            }
        },
        sortable: true,
        selectable: "multiple, row",
        autoBind: true,
        scrollable: true,
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        },
        columns: [
            {
                field: "", 
                title: " ",
                width: 40, 
                template: "<input name='part3' type='checkbox' class='part3checkbox cmic-checkbox-table large custom'/>",
                headerAttributes: {"class": "height-cell"},
            },{
                field: "Part3BenefitCode",
                title: "Benefit Code",
                width:120,
                headerAttributes: {"class": "right-cell"}
            },{
                title: "Benefit Calculation Rule ",
                headerAttributes: {
                    "class": "header-cell"
                },
                columns: [
                    { field: "Part3IndemnityPercentage", title: "Indemnity<br/>percentage", width:120 },
                    { field: "Part3NoOfDays", title: "No of<br/>days", width:100 },
                    { field: "Part3MaxNoOfDays", title: "Max no<br/>of days", width:100 },
                    { field: "Part3confinementDay", title: "Confinement<br/>day", width:120 },
                    { field: "Part3MaxBenefitAmount", title: "Max benefit<br/>amount", width:120 },
                    { field: "Part3MaxConfinementAmount", title: "Max confinement<br/>amount", width:150 },
                    { field: "Part3MaxYearAmount", title: "Max year<br/>amount", width:100 },
                    { field: "Part3MaxMajorConfinement", title: "Max major<br/>confinement", width:120 },
                    { field: "Part3NonIpdSurgeryAmount", title: "Non ipd<br/>surgery amount", width:150 },
                    { field: "Part3IpdSurgeryAmount", title: "Ipd surgery<br/>amount", width:120 },
                    { field: "Part3SpecialIpdAmount", title: "Special ipd<br/>amount", width:120 },
                    { field: "Part3ChangeDate", title: "Change<br/>date", width:150, format:"{0:MM-dd-yyyy}",editor: dateTimeEditor },
                    { field: "Part3MaxNoOfDaysHist", title: "Max no of<br/>days hist", width:120 },
                    { field: "Part3TotalBenefitAmount", title: "Total benefit<br/>amount", width:140 },
                    { field: "Part3WaitingPeriod", title: "Waiting<br/>Period", width:100 },
                    { field: "Part3SACalculateType", title: "SA<br/>CalculateType", width:130 }
                ]
            }
        ],
        editable: true
    }).data("kendoGrid");
    //sharedDataSource.read();
    hideExtraBtnsPart3();

    function dateTimeEditor(container, options) {
        $('<input class="cmic-edit" data-text-field="' + options.field + '" data-value-field="' + options.field + '" data-bind="value:' + options.field + '" data-format="' + options.format + '"/>')
            .appendTo(container)
            .kendoDatePicker({});    
    }

    benefitpart3.table.on("click", ".part3checkbox", function() {
        var row = $(this).closest("tr");
        if (this.checked) {
            row.addClass("k-state-selected");
        } else {
            row.removeClass("k-state-selected");
        }
    });

    $(".k-part3-add", benefitpart3.element).on("click", function(ev) {
        benefitpart3.addRow();
        $(".k-part3-add").hide();
        $(".k-part3-save").show();
        $(".k-part3-cancel").show();
        $(".k-part3-edit").addClass("k-state-disabled").attr('disabled', 'disabled');
        $(".k-part3-delete").addClass("k-state-disabled").attr('disabled', 'disabled');
    });

    $(".k-part3-save", benefitpart3.element).on("click", function(ev) {
        benefitpart3.saveRow();
        restoreGridToolbarPart3();
    });

    $(".k-part3-edit", benefitpart3.element).on("click", function(ev) {
        var selectedRows = benefitpart3.tbody.find(".k-state-selected");
        if (selectedRows.length === 0) {
            alert("Please select a record to edit.");
        } else if (selectedRows.length > 1) {
            alert("Please select a single record for editing.");
        } else if (selectedRows.length === 1) {
            benefitpart3.editRow(selectedRows);
            selectedRows.find(".grid_checkbox").attr("checked", "checked").attr('disabled','disabled');
            $(".k-part3-edit").hide();
            $(".k-part3-update").show();
            $(".k-part3-cancel").show();
            $(".k-part3-add").addClass("k-state-disabled").attr('disabled', 'disabled');
            $(".k-part3-duplicate").addClass("k-state-disabled").attr('disabled', 'disabled');
            $(".k-part3-delete").addClass("k-state-disabled").attr('disabled', 'disabled');
        }
    });


     $(".k-part3-duplicate").on("click", function() {
        var items = [];
            // For the rows with checked item
            $(":checked", grid.tbody).each(function(idx, elem) {
                 // Get the row 
                 var row = $(elem).closest("tr");
                 // Get the item for that row
                 var item = grid.dataItem(row);
                 items.push(item);
            });
            // Insert it in the DataSource
            for (var i = 0; i < items.length; i++) {
                grid.dataSource.add(items[i]);
            }
      });

    $(".k-part3-update", benefitpart3.element).on("click", function(ev) {
        benefitpart3.saveChanges();
        restoreGridToolbarPart3();
    });

    $(".k-part3-cancel", benefitpart3.element).on("click", function(ev) {
        benefitpart3.cancelChanges();
        restoreGridToolbarPart3();
    });

    $(".k-part3-delete", benefitpart3.element).on("click", function(ev) {
        var selRows = benefitpart3.tbody.find(".k-state-selected");
        if (selRows.length > 0 && confirm("Do you want to delete " + selRows.length + " record(s)?")) {
            $.each(selRows, function(index, value) {
                benefitpart3.removeRow(value);
            });
        } else if (selRows.length === 0) {
            alert("Please select a record to delete.");
        }
    });
	
	RenderGeneralExclusion();
	RenderGeographicLimit();
	RenderCoverageForCauseOfTreatment();
	RenderMedicalCondition();
	RenderResctrictedSector();
	RenderRestrictedRoomType();

});

//This function hides the save/update/cancel buttons on the grid toolbar
function hideExtraBtns() {
    $(".k-cust-save").hide();
    $(".k-cust-update").hide();
    $(".k-cust-cancel").hide();
}

//This function hides the update/save/cancel buttons and shows edit/add buttons
function restoreGridToolbar() {
    $(".k-cust-edit").show();
    $(".k-cust-update").hide();
    $(".k-cust-add").show();
    $(".k-cust-save").hide();
    $(".k-cust-cancel").hide();
    $(".k-cust-add").removeClass("k-state-disabled").removeAttr('disabled');
    $(".k-cust-duplicate").removeClass("k-state-disabled").removeAttr('disabled');
    $(".k-cust-edit").removeClass("k-state-disabled").removeAttr('disabled');
    $(".k-cust-delete").removeClass("k-state-disabled").removeAttr('disabled');
}

function hideExtraBtnsPart3() {
    $(".k-part3-save").hide();
    $(".k-part3-update").hide();
    $(".k-part3-cancel").hide();
}

function restoreGridToolbarPart3() {
    $(".k-part3-edit").show();
    $(".k-part3-update").hide();
    $(".k-part3-add").show();
    $(".k-part3-save").hide();
    $(".k-part3-cancel").hide();
    $(".k-part3-add").removeClass("k-state-disabled").removeAttr('disabled');
    $(".k-part3-duplicate").removeClass("k-state-disabled").removeAttr('disabled');
    $(".k-part3-edit").removeClass("k-state-disabled").removeAttr('disabled');
    $(".k-part3-delete").removeClass("k-state-disabled").removeAttr('disabled');
}

//General Exclusion
function RenderGeneralExclusion() {
	var gecnt = 4;
	var dataGE = [
		{gekey: "1", gevalue: "General Exclusion type"}, 
		{gekey: "2", gevalue: "Charge for non- medical expense (administrative fee)"}, 
		{gekey: "3", gevalue: "Occupation"},
		{gekey: "4", gevalue: "Equipment/Appliance"},
		{gekey: "5", gevalue: "Prosthesis"},
		{gekey: "6", gevalue: "Service delivered by unqualified provider"},
		{gekey: "7", gevalue: "Service rendered in unqualified facility"},
		{gekey: "8", gevalue: "Treatment due the specific cause"},
		{gekey: "9", gevalue: "Pre-existing condition"}
	];
	$(function() {
		$("#listviewGeneralExclusion").kendoListView({
			template: kendo.template($("#GeneralExclusionTemplate").html()),
			dataBound: function(e) {
			for (i = 1; i < gecnt; i++) {
				if($("#gecol"+i) != undefined) {$("#gecol"+ i).kendoComboBox({
						filter: "contains",
						autoBind: true,
						dataTextField: "gevalue", 
						dataValueField: "gekey", 
						dataSource: dataGE, 
						index: 0
					});
				}
			}
			},
			dataSource: {data: dataGeneralExclusion}
		});
		$("#AddGE").kendoButton({click: function(e) {$("#listviewGeneralExclusion").data("kendoListView").dataSource.add({id: gecnt++});}
		});
	});
	var dataGeneralExclusion = [{id:1},{id:2},{id:3}];
}
//General limit
function RenderGeographicLimit(){
	var glcnt = 4;
	var dataGL = [
		{glkey: "1", glvalue: "Thailand"}, 
		{glkey: "2", glvalue: "England"}, 
		{glkey: "3", glvalue: "Japan"}
	];
	$(function() {
		$("#listviewGeographicLimit").kendoListView({
			template: kendo.template($("#GeographicLimitTemplate").html()),
			dataBound: function(e) {
			for (i = 1; i < glcnt; i++) {
				if($("#glcol"+i) != undefined) {$("#glcol"+ i).kendoComboBox({
						filter: "contains",
						autoBind: true,
						dataTextField: "glvalue", 
						dataValueField: "glkey", 
						dataSource: dataGL, 
						index: 0
					});
				}
			}
			},
			dataSource: {data: dataGeneralLimit}
		});
		$("#AddGL").kendoButton({click: function(e) {$("#listviewGeographicLimit").data("kendoListView").dataSource.add({id: glcnt++});}
		});
	});
	var dataGeneralLimit = [{id:1},{id:2},{id:3}];
}

//Coverage for cause of treatment 
function RenderCoverageForCauseOfTreatment () {
	var ctcnt = 4;
	var dataCT = [
		{ctkey: "1", ctvalue: "Accident or Illness"}, 
		{ctkey: "2", ctvalue: "Other option"}
	];
	$(function() {
		$("#listviewCoverage").kendoListView({
			template: kendo.template($("#CoverageTemplate").html()),
			dataBound: function(e) {
			for (i = 1; i < ctcnt; i++) {
				if($("#ctcol"+i) != undefined) {$("#ctcol"+ i).kendoComboBox({
						filter: "contains",
						autoBind: true,
						dataTextField: "ctvalue", 
						dataValueField: "ctkey", 
						dataSource: dataCT, 
						index: 0
					});
				}
			}
			},
			dataSource: {data: dataCoverage}
		});
		$("#AddCT").kendoButton({click: function(e) {$("#listviewCoverage").data("kendoListView").dataSource.add({id: ctcnt++});}
		});
	});
	var dataCoverage = [{id:1},{id:2},{id:3}];
}

//Cover for specific Medical condition
function RenderMedicalCondition() {
	var mccnt = 4;
	var dataMC = [
		{mckey: "1", mcvalue: "Cancer"}, 
		{mckey: "2", mcvalue: "Dental Care"}
	];
	$(function() {
		$("#listviewMedicalCondition").kendoListView({
			template: kendo.template($("#MedicalConditionTemplate").html()),
			dataBound: function(e) {
			for (i = 1; i < mccnt; i++) {
				if($("#mccol"+i) != undefined) {$("#mccol"+ i).kendoComboBox({
						filter: "contains",
						autoBind: true,
						dataTextField: "mcvalue", 
						dataValueField: "mckey", 
						dataSource: dataMC, 
						index: 0
					});
				}
			}
			},
			dataSource: {data: dataMedicalCondition}
		});
		$("#AddMC").kendoButton({click: function(e) {$("#listviewMedicalCondition").data("kendoListView").dataSource.add({id: mccnt++});}
		});
	});
	var dataMedicalCondition = [{id:1},{id:2},{id:3}];
}

//Resctricted sector
function RenderResctrictedSector() {
	var rscnt = 4;
	var dataRS = [
		{rskey: "1", rsvalue: "Private"}, 
		{rskey: "2", rsvalue: "Public"},
		{rskey: "3", rsvalue: "No specification"}
	];
	$(function() {
		$("#listviewResctrictedSector").kendoListView({
			template: kendo.template($("#ResctrictedSectorTemplate").html()),
			dataBound: function(e) {
			for (i = 1; i < rscnt; i++) {
				if($("#rscol"+i) != undefined) {$("#rscol"+ i).kendoComboBox({
						filter: "contains",
						autoBind: true,
						dataTextField: "rsvalue", 
						dataValueField: "rskey", 
						dataSource: dataRS, 
						index: 0
					});
				}
			}
			},
			dataSource: {data: dataResctrictedSector}
		});
		$("#AddRS").kendoButton({click: function(e) {$("#listviewResctrictedSector").data("kendoListView").dataSource.add({id: rscnt++});}
		});
	});
	var dataResctrictedSector = [{id:1},{id:2},{id:3}];
}

//Restricted Room Type
function RenderRestrictedRoomType() {
	var rtcnt = 4;
	var dataRT = [
		{rtkey: "1", rtvalue: "Room type table"}, 
		{rtkey: "2", rtvalue: "No restriction "},
		{rtkey: "3", rtvalue: "No specification"}
	];
	$(function() {
		$("#listviewRestrictedRoomType").kendoListView({
			template: kendo.template($("#RestrictedRoomTypeTemplate").html()),
			dataBound: function(e) {
			for (i = 1; i < rtcnt; i++) {
				if($("#rtcol"+i) != undefined) {$("#rtcol"+ i).kendoComboBox({
						filter: "contains",
						autoBind: true,
						dataTextField: "rtvalue", 
						dataValueField: "rtkey", 
						dataSource: dataRT, 
						index: 0
					});
				}
			}
			},
			dataSource: {data: dataRestrictedRoomType}
		});
		$("#AddRT").kendoButton({click: function(e) {$("#listviewRestrictedRoomType").data("kendoListView").dataSource.add({id: rtcnt++});}
		});
	});
	var dataRestrictedRoomType = [{id:1},{id:2},{id:3}];
}























































