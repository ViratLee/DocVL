$(document).ready(function(){
    renderDocumentItemTable();
    renderCustomerMatchingTable();
    renderRequestDocTable();
    renderViewNewWindow();

});
//Table for Document
function renderDocumentItemTable(){
    var DocumentForms = new kendo.data.DataSource({
        pageSize: 10,
        data: dataDocument,
        autoSync: true,
        schema: {
            model: {
                id: "DocumentID",
                fields: {
                    DocumentID: { editable: false, nullable: true },
                    DocumentName :{editable: false, defaultValue: "FAXSERVER1263545646456466" },
                    DocumentType:{ defaultValue: { DocumentTypeName: "C10100-HC Claim Form", DocumentTypeId: "1" } },
                    DocumentIDTEXT :{ editable: false, defaultValue: "C10300" },
                    DocumentPage :{ editable: true, defaultValue: "1" }
                }
            }
        }
    });
    var grid= $("#DocumentItem").kendoGrid({
        autobind: true,
        dataSource: DocumentForms,
        pageable: true,
        pageSize: 5,
        columns: [
            {field: "DocumentName",title: "Doc Name", template:"<a href='#=docUrl#' class='viewdociframe' target='displayDocument'>#= DocumentName #</a>"},
            {field: "DocumentType", title: "Doc Type", width: "180px", editor: DocumentTypeEditor, template: "#=DocumentType.DocumentTypeName#" },
            {field: "DocumentIDTEXT",title: "Doc ID", width: 90},
            {field: "DocumentPage",title: "Doc Pag e", width: 80},
            {
            command: [
                { text: "destroy", template: "<a class='k-button k-grid-delete btn btn-blue removed' style='min-width:30px;'><span class='glyphicon glyphicon-trash'></span></a>" },
                { text: "create", template: "<a class='k-button k-grid-add-sub btn btn-blue removed' style='min-width:30px;' onclick='addSubRow(this)'><span class='glyphicon glyphicon-plus'></span></a>" }
            ],
            title: " ",
            width: "100px"
        }
            ],
        editable: {
            createAt : "bottom"
        },
        navigatable: true
    }).data("kendoGrid");

    grid.tbody.on('keydown',function(e){
        if($(e.target).closest('td').is(':last-child') && $(e.target).closest('tr').is(':last-child')){
          grid.addRow();
        }
    })
}
function addSubRow(e){
    var position_at = $(e).closest('tr').index();
    var grid = $("#DocumentItem").data("kendoGrid");
    var obj = grid.dataSource.at(position_at);
    var clone = {
        DocumentName: "",
        DocumentType: obj.DocumentType,
        DocumentIDTEXT: obj.DocumentIDTEXT,
        DocumentPage: obj.DocumentPage,
    }
    grid.dataSource.insert((position_at + 1), clone);
    console.log('success index at: ' + (position_at + 1));
}

var DocumentTypeData = new kendo.data.DataSource({
    data: [
        { DocumentTypeName: "C10100-HC Claim Form", DocumentTypeId: "1" },
        { DocumentTypeName: "C10200-HC Claim Form", DocumentTypeId: "2" },
        { DocumentTypeName: "C10300-HC Claim Form", DocumentTypeId: "3"},
        { DocumentTypeName: "C10400-HC Claim Form", DocumentTypeId: "4" }
    ]
});
function DocumentTypeEditor(container, options) {
    $('<input name="DocumentTypeDisplay" class="cmic-edit" data-text-field="DocumentTypeName" data-value-field="DocumentTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "DocumentTypeName",
            dataValueField: "DocumentType",
            dataSource: DocumentTypeData
        });
}
//content for Document
var dataDocument = [
    {
        DocumentID:1,
        DocumentName : "export",
        DocumentType : {
            DocumentTypeId : 1,
            DocumentTypeName : "C10100-HC Claim Form"
        },
        DocumentIDTEXT : "C10300", 
        DocumentPage : "1",
        docUrl: "doc/export.pdf"
    },{
        DocumentID:2,
        DocumentName : "test2",
        DocumentType : {
            DocumentTypeId : 2,
            DocumentTypeName : "C10200-HC Claim Form"
        },
        DocumentIDTEXT : "C10300", 
        DocumentPage : "1-2",
        docUrl: "doc/test2.pdf"
    },{
        DocumentID:3,
        DocumentName : "test3", 
        DocumentType : {
            DocumentTypeId : 1,
            DocumentTypeName : "C10100-HC Claim Form"
        }, 
        DocumentIDTEXT : "C10300", 
        DocumentPage : "1-2",
        docUrl: "doc/test3.pdf"
    },{
        DocumentID:4,
        DocumentName : "FAXSERVER1263545646456466", 
        DocumentType : {
            DocumentTypeId : 1,
            DocumentTypeName : "C10100-HC Claim Form"
        }, 
        DocumentIDTEXT : "C10300", 
        DocumentPage : "3-4",
        docUrl: "doc/test2.pdf"
    },{
        DocumentID:5,
        DocumentName : "FAXSERVER1263545646456466", 
        DocumentType : {
            DocumentTypeId : 1,
            DocumentTypeName : "C10100-HC Claim Form"
        }, 
        DocumentIDTEXT : "C10300", 
        DocumentPage : "1-2",
        docUrl: "doc/test3.pdf"
    }
];
//Table for customer matching
function renderCustomerMatchingTable(){
    var grid= $("#CustomerMatching").kendoGrid({
        groupable: false,
        sortable: true,
        selectable : "row",
        pageSize: 10,
        pageable: false,
        dataSource:[{
            ID: 1,
            cName : "สมชาย", 
            cDOB : "2 มิ.ย.19", 
            cGender : "Male", 
            cPolicyNo : "T123456", 
            cCertificationNo : "1235666",
             cNationalID : "3210500712291", 
             cRole : "Insured"
         },{
            ID: 2,
            cName : "สมชาย", 
            cDOB : "2 มิ.ย.19", 
            cGender : "Male", 
            cPolicyNo : "T123456", 
            cCertificationNo : "1235666", 
            cNationalID : "3210500712291", 
            cRole : "Insured"
        },{
            ID: 3,
            cName : "สมชาย", 
            cDOB : "2 มิ.ย.19", 
            cGender : "Male", 
            cPolicyNo : "T123456", 
            cCertificationNo : "1235666", 
            cNationalID : "3210500712291", 
            cRole : "Insured"
        }],
        columns: [
            {field: "cName", title: "Name"},
            {field: "cDOB", title: "DOB"}, 
            {field: "cGender", title: "Gender"}, 
            {field: "cPolicyNo", title: "Policy No"}, 
            {field: "cCertificationNo", title: "Cert No"}, 
            {field: "cNationalID", title: "National ID"},  
            {field: "cRole",title: "Role"}
        ]
    });
}

//Request for document
function renderRequestDocTable(){
    var docgrid = $("#RequestDoc").kendoGrid({
        dataSource: {
            data: datadoc,
            pageSize: 10,
            schema: {model: {fields: {BatchNo: { type: "string",editable: false },}}}
        },
        sortable: true,
        selectable: "multiple, row",
        autoBind: true,
        scrollable: true,
        sortable: true,
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        },
        columns: [
            {
                field: "", 
                title: "<input id='chkall' name='chkall' type='checkbox' class='checkboxall cmic-checkbox-table'/>",
                width: 60,
                template: "<input name='chklist' type='checkbox' class='checkboxsub cmic-checkbox-table'/>"
            },
            {
                field: "RequireDocument", 
                title: "Require Document", 
                encoded: false
            }
        ],
        editable: false
    }).data("kendoGrid");
    // Checkbox all
    $(".checkboxall").click(function(){
       var selectall = $("#chkall")[0].checked;
       $(".checkboxsub").each(function( index ) {
         $( this ).prop('checked', selectall);
       });
        if (selectall) {
            $("#RequestDoc tr").addClass("k-state-selected");
            if($("#RequestDoc tr").find('span.textother').length != 0){
                $("#RequestDoc tr").find('span.textother').parent().append('<input type="textbox" name="textother" class="inputother" />');
            }
        } else {
            $("#RequestDoc tr").removeClass("k-state-selected");
            if($("#RequestDoc tr").find('span.textother').length != 0){
                $("#RequestDoc tr").find('span.textother').next().remove();
            }
        }
    });
    // Checkbox 
    $(".checkboxsub").click(function(){
           var row = $(this).closest("tr");
        if (this.checked) {
            row.addClass("k-state-selected");
            if(row.find('span.textother').length != 0){
                row.find('span.textother').parent().append('<input type="textbox" name="textother" class="inputother" />');
            }
        } else {
            row.removeClass("k-state-selected");
            if(row.find('span.textother').length != 0){
                row.find('span.textother').next().remove();
            }
        }
    });
}
//Content for Request for Document
var datadoc = [
    {"RequireDocument": "ส่วน 1"},
    {"RequireDocument": "ส่วน 2"},
    {"RequireDocument": "ใบแจ้งรายการค่ารักษาพยาบาล"},
    {"RequireDocument": "สำเนาบัตรประจำตัวประชาชน"},
    {"RequireDocument": "สำเนาเอไอเอการ์ด/ One Card"},
    {"RequireDocument": "สำเนาบัตรประกันกลุ่ม/ FCS"},
    {"RequireDocument": "<span class=\"textother\">อื่นๆ</span>"}
];

function renderViewNewWindow(url){
    $("#viewNewWindow").click(function(e) {
      var windowBlock = window.open("","displayFull",'location=yes,height=1600,width=1800,resizable=yes,scrollbars=yes,toolbar=yes,menubar=yes,location=yes');
                windowBlock.document.write("<iframe id='displayDocument' class='framesetblock' name='displayDocument' src='" + $('#displayDocument')[0].src + "' style='width:100%;height:100%;'></iframe>");
       
        $("body").removeClass("indexing50").addClass("indexing100");
        $("#indexViewer").removeClass("showapplet").addClass("hideapplet");
        $("#indexWrapper").removeClass("colindex").addClass("col-xs-12");
        $(".changedisplay").removeClass("col-xs-6").addClass("col-xs-4");
        $(".changemore").removeClass("col-xs-12").addClass("col-xs-8");

        var setTimer = setInterval(function() {  
        if(windowBlock.closed) {  
            clearInterval(setTimer);  
            $("body").removeClass("indexing100").addClass("indexing50");
                $("#indexViewer").removeClass("hideapplet").addClass("showapplet");
                $("#indexWrapper").removeClass("col-xs-12").addClass("colindex");
                $(".changedisplay").removeClass("col-xs-4").addClass("col-xs-6");
                $(".changemore").removeClass("col-xs-8").addClass("col-xs-12");
          }

        }, 300);      
    });     
}


  



