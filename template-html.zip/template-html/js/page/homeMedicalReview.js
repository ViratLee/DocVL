$(document).ready(function(){

    // Chart
    function addCommas(nStr){
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {x1 = x1.replace(rgx, '$1' + ',' + '$2');}
    return x1 + x2;
}
    function createChart(id,title,MidleText,showData,showIndex) {
    var color = "";
    if (showData.length == 2) {
        color = [ "#97cb5d","#ff95a9","#FBBF56"];
    }else if (showData.length == 3){
        color = ["#97cb5d","#ff95a9","#FBBF56"];
    }
    $(id).kendoChart({
        legend : {
            visible : false
        },
        chartArea : {
            background : ""
        },
        seriesDefaults : {
            type : "donut",
            startAngle : 90,
            holeSize: 100,
            size: 15,
            overlay: {
                gradient: "none"
            },
        },
        seriesColors: color,
        series : [ {
            data : showData
        } ]
    });
    $(id).append('<span class="allChartTxt chartTitle">'+title+'</span>');
    $(id).append('<div class="chartTxt">'+MidleText+'</div>');

    var titleHtml = '<div class="chartTextCenter">';
    titleHtml += '<span class="chartValue" id="chartData">'+addCommas(showData[showIndex].value)+'</span>';
    titleHtml += '<div class="chartTxt" id="chartTxt">'+showData[showIndex].MidleText+'</div>';
    titleHtml += '</div>';
    $(id).append(titleHtml);

        var html = '<div class="chartBottom">';
        for (var k = showData.length-1; k >= 0; k--) {
            html += '<span class=" chartValueBottom" style="background:'+color[k]+'">'+addCommas(showData[k].value)+'</span><span class=" chartTxtBottom">'+showData[k].title+'</span>';
        }
        html += '</div>';
        $(id).append(html);
}

    var dataChart1 = [{
        MidleText: "Completed",
        title : "Completed",
        value : "100"
    },{
        title : "Waiting",
        value : "500"
    },{
        title : "Owned",
        value : "200"
    }];
    createChart('#Eligibility-donutChart1','You','',dataChart1,'0');

    var dataChart2 = [{
        MidleText: "Completed",
        title : "Completed",
        value : "200"
    },{
        title : "Waiting",
        value : "500"
    }];
    createChart('#Eligibility-donutChart2','Team','',dataChart2,'0');

    //Table
getTable();
    $('.ic_table').kendoTooltip({
      position: "top",
      autoHide: true,
      width: 85
    });
});

function LinkToPageWithID(Link) {
    window.location.href = Link;
}
function DBLinkToPageWithID(Link) {
    alert("Double Click : " + Link);
}
function getTable() {
    var data = getDataTable();
    $("#tableIndexMedicalReview").kendoGrid({
        columns : [ {
            title : " ",
            field : "Icon",
            width:85
        }, {
            title : "Date received",
            field : "DateReceived",
            width: 120
        },{
            title : "Claim number",
            field : "Claimnumber",
            width: 120
        }, {
            title : "Policy number",
            field : "Policynumber",
            width: 120
        }, {
            title : "Cert. number",
            field : "Certnumber",
            width: 120
        }, {
            title : "Insured name",
            field : "Insuredname",
            width: 120
        }, {
            title : "Hospital name",
            field : "Hospitalname",
            width: 120
        }, {
            title : "Request Type",
            field : "RequestType"
        },{
            title : "Previous user",
            field : "Previoususer",
            width: 120
        }, {
            title : "Risk",
            field : "Risk"
        }
        ],
        rowTemplate : kendo.template($("#tableIndexMedicalReviewTemplate").html()),
        dataSource : data,
        sortable: false,
        selectable: "multiple, row",
        autoBind: true,
        scrollable: true,
        pageable: {buttonCount: 5, pageSizes: true}
    }); 
    
}


function getDataTable() {
    var returnData = new kendo.data.DataSource({
     data : [{
        ID : "1",
        Highlight  : "statuspast",
        Link : "homeIndexSearchResult.html",
        IconOwner: "enable",
        IconVIP: "enable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "เวชธานี",
        RequestType: "HC Part 2",
        Previoususer: "12345678",
        Risk: "3"
    }, {
        ID : "2",
        Highlight  : "statuspast",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "enable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "มิชชั่น",
        RequestType: "Cheque",
        Previoususer: "12345678",
        Risk: "3"
    }, {
        ID : "3",
        Highlight  : "statustoday",
        Link : "homeIndexSearchResult.html",
        IconOwner: "enable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "2"
    }, {
        ID : "4",
        Highlight  : "statustoday",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "2"
    }, {
        ID : "5",
        Highlight  : "statusfuther",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "1"
    },{
        ID : "6",
        Highlight  : "statusfuther",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "1"
    },{
        ID : "7",
        Highlight  : "statusfuther",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "1"
    },{
        ID : "8",
        Highlight  : "statusfuther",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "1"
    },{
        ID : "9",
        Highlight  : "statusfuther",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "1"
    },{
        ID : "10",
        Highlight  : "statusfuther",
        Link : "homeIndexSearchResult.html",
        IconOwner: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  00:000:00",
        Claimnumber: "123456789",
        Policynumber: "T12345678",
        Certnumber: "12345678",
        Insuredname: "สมชาย ใจดี",
        Hospitalname: "Bangkok",
        RequestType: "HC Part 1",
        Previoususer: "12345678",
        Risk: "1"
    }
],
    pageSize: 10
    });
    return returnData;
}

