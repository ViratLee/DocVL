$(document).ready(function(){
    // Chart
    function addCommas(nStr){
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {x1 = x1.replace(rgx, '$1' + ',' + '$2');}
    return x1 + x2;
}
    function createChart(id,title,MidleText,showData,showIndex) {
    var color = "";
    if (showData.length == 2) {
        color = [ "#97cb5d","#ff95a9","#FBBF56"];
    }else if (showData.length == 3){
        color = ["#97cb5d","#ff95a9","#FBBF56"];
    }
    $(id).kendoChart({
        legend : {
            visible : false
        },
        chartArea : {
            background : ""
        },
        seriesDefaults : {
            type : "donut",
            startAngle : 90,
            holeSize: 100,
            size: 15,
            overlay: {
                gradient: "none"
            },
        },
        seriesColors: color,
        series : [ {
            data : showData
        } ]
    });
    $(id).append('<span class="allChartTxt chartTitle">'+title+'</span>');
    $(id).append('<div class="chartTxt">'+MidleText+'</div>');

    var titleHtml = '<div class="chartTextCenter">';
    titleHtml += '<span class="chartValue" id="chartData">'+addCommas(showData[showIndex].value)+'</span>';
    titleHtml += '<div class="chartTxt" id="chartTxt">'+showData[showIndex].MidleText+'</div>';
    titleHtml += '</div>';
    $(id).append(titleHtml);

        var html = '<div class="chartBottom">';
        for (var k = showData.length-1; k >= 0; k--) {
            html += '<span class=" chartValueBottom" style="background:'+color[k]+'">'+addCommas(showData[k].value)+'</span><span class=" chartTxtBottom">'+showData[k].title+'</span>';
        }
        html += '</div>';
        $(id).append(html);
}

    var dataChart1 = [{
        MidleText: "Completed",
        title : "Completed",
        value : "100"
    },{
        title : "Waiting",
        value : "500"
    }];
    createChart('#CaseValidateComplete','You','',dataChart1,'0');

    var dataChart2 = [{
        MidleText: "Completed",
        title : "Completed",
        value : "200"
    },{
        title : "Waiting",
        value : "500"
    }];
    createChart('#CaseValidateWorkAwary','Team','',dataChart2,'0');

    //Table
    renderHomeCaseValidationTable();

});

function renderHomeCaseValidationTable() {
    var homeCaseValidationForm = new kendo.data.DataSource({
        pageSize: 10,
        data: dataHomeCaseValidation,
        autoSync: true,
        schema: {
            model: {
                id: "homeCaseValidationID",
                fields: {
                    homeCaseValidationID: { editable: false, nullable: true },
                    slaDt: {type: "date", editable: false, nullable: true }
                }
            }
        }
    });

    $("#homeCaseValidationGrid").kendoGrid({
        columns : [ 
            {
                title : " ",
                field : "Icon", 
                width:85,
                attributes:{"class": "text-center"},
                template: "<span class='ic_table icon-alert cmictooltip #= IconUrgent#' title='Urgent'></span><span class='ic_table icon-vip cmictooltip #= IconVIP#' title='VIP'></span>"
            },
            {title : " ",field : "slaDt", template: "#= kendo.toString(slaDt,'MM/dd/yyyy') #"}, 
            {title : "Date<br>Received",field : "DateReceived",width : 150}, 
            {title : "Hospital<br>Name",field : "HospitalName"}, 
            {title : "Policy<br>Number",field : "PolicyNumber"}, 
            {title : "Cert<br>Number",field : "CertNumber"}, 
            {title : "Member<br>ID",field : "MemberID"}, 
            {title : "Insured<br>Name",field : "InsuredName"},
            {title : "Batch<br>Number",field : "BatchNumber"}, 
            {title : "Channel",field : "Channel"}, 
            {title : "Locations",field : "DataEentrylocation"} 
        ],
        scrollable : true,
        selectable : "row",
        sortable : true,
        dataBound: checkDateDataBound,
        dataSource : homeCaseValidationForm,
        pageable: {
            buttonCount: 5,
            previousNext: true
        },
    });

    $("#homeCaseValidationGrid").kendoTooltip({
        filter: "span.cmictooltip",
        position: "top",
        width: 85
    }).data("kendoTooltip");
    
     var grid = $("#homeCaseValidationGrid").data("kendoGrid");
        grid.bind("dataBound", checkDateDataBound);
        grid.dataSource.fetch();

    function checkDateDataBound() {
        var currentDate = new Date();
        currentDate = currentDate.setHours(0, 0, 0, 0);
        dataView = this.dataSource.view();
        for (var i = 0; i < dataView.length; i++) {
            // check if the fields match and apply a class to the row if so
            var showingdate = dataView[i].slaDt.setHours(0, 0, 0, 0);
            var uid = dataView[i].uid;
            
            if (showingdate == currentDate) {
                $("#homeCaseValidationGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statustoday");
            }
            else if (showingdate < currentDate) {
                $("#homeCaseValidationGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statuspast");
            }
            else {
                $("#homeCaseValidationGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statusfuture");
            }
        }
    }
    
}

var dataHomeCaseValidation = [
    {
        homeCaseValidationID : 1,
        Link : "caseValidation.html",
        slaDt: "2014-10-21T00:23:00",
        IconUrgent: "enable",
        IconVIP: "enable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 2,
        Link : "caseValidation.html",
        slaDt: "2014-10-21T00:23:00",
        IconUrgent: "enable",
        IconVIP: "enable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "JCB"
    }, {
        homeCaseValidationID : 3,
        Link : "caseValidation.html",
        slaDt: "2016-10-27T00:23:00",
        IconUrgent: "enable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 4,
        Link : "caseValidation.html",
        slaDt: "2016-10-27T00:23:00",
        IconUrgent: "enable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIT"
    }, {
        homeCaseValidationID : 5,
        Link : "caseValidation.html",
        slaDt: "2016-10-27T00:23:00",
        IconUrgent: "enable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 6,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 7,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 8,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 9,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 10,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 11,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, {
        homeCaseValidationID : 12,
        Link : "caseValidation.html",
        slaDt: "2018-10-27T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        HospitalName : "พญาไท 3",
        PolicyNumber : "12345678",
        CertNumber : "12345678",
        MemberID : "12345678",
        InsuredName : "john smith",
        BatchNumber : "12345678",
        Channel : "Fax",
        DataEentrylocation: "AIG"
    }, 
];


