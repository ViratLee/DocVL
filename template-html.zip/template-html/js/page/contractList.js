$(document).ready(function() {
	renderContactListTable();
});

// Contac tList
function renderContactListTable(){
	$("#ContractListGrid").kendoGrid({
		dataSource: {
	        data: dataclaimslist,
	        pageSize: 10,
	    },
	    sortable: true,
	    selectable: "multiple, row",
	    rowTemplate : kendo.template($("#ContractListTemplate").html()),
	    autoBind: true,
	    scrollable: true,
	    sortable: true,
	    pageable: {
	        buttonCount: 5,
	        pageSizes: true,
	    },
	    columns : [ 
			{title : "Provider<br/>ID", field : "providerId", width:100}, 
			{title : "Provider<br/>Name",field : "providerName", width:150}, 
			{title : "Provider<br/>Type",field : "providerType", width:100}, 
			{title : "province", field : "province", width:100}, 
			{title : "Region", field : "region", width:100}, 
			{title : "Network",field : "network", width:150}, 
			{title : "Provider<br>Status",field : "providerStatus", width:100}, 
			{title : "Effective<br>Date",field : "effectiveDate", width:100}, 
			{title : "Expiry<br>Date",field : "expiryDate", width:100}, 
			{title : "Contract<br>Status",field : "contractStatus", width:150} 
		]
	});
}
//Content for Contract List
var dataclaimslist = [
	{
		Id : 1,
		providerId : "123695997",
		ContractListLink: "contract.html",
		providerName : "กรุงเทพ",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	}, {
		Id : 2,
		providerId : "215498544",
		ContractListLink: "contract.html",
		providerName : "กรุงเทพคริสเตียน",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Preparation"
	}, {
		Id : 3,
		providerId : "123695997",
		ContractListLink: "contract.html",
		providerName : "กรุงเทพ",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Inactive"
	}, {
		Id : 4,
		providerId : "215498544",
		ContractListLink: "contract.html",
		providerName : "พญาไท 1",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	},{
		Id : 5,
		providerId : "123695997",
		ContractListLink: "contract.html",
		providerName : "พญาไท 2",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Preparation"
	}, {
		Id : 6,
		providerId : "215498544",
		ContractListLink: "contract.html",
		providerName : "พญาไท 3",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Inactive"
	},{
		Id : 7,
		providerId : "123695997",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Waiting for approval"
	}, {
		Id : 8,
		providerId : "215498544",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	},{
		Id : 9,
		providerId : "123695997",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Hospital",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Preparation"
	}, {
		Id : 10,
		providerId : "215498544",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Waiting for approval"
	},{
		Id : 11,
		providerId : "123695997",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	}, {
		Id : 12,
		providerId : "215498544",
		ContractListLink: "contract.html",
		providerName : "พระรามเก้า",
		providerType : "Clinic",
		province : "Bangkok",
		region : "central",
		network : "HC, CC, CS, PPO",
		providerStatus : "Active",
		effectiveDate : "8/10/2558",
		expiryDate : "8/10/2564",
		contractStatus : "Active"
	}
];