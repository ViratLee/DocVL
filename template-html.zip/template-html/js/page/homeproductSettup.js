$(document).ready(function(){
    $('.ic_table').kendoTooltip({
      position: "top",
      autoHide: true
    });

    var grid= $(".information1").kendoGrid({
        groupable: false,
        sortable: true,
        selectable : "row",
        dataSource: DescriptionInformation1,
        rowTemplate : kendo.template($("#Information1Template").html()),
        columns : [ 
            {field : "Icon",title : " ",width:85}, 
            {field : "DateReceived",title : "Date<br>Received"}, 
            {field : "HospitalName",title : "Hospital<br>Name"}, 
            {field : "PolicyNumber",title : "Policy<br>Number"}, 
            {field : "CertNumber",title : "Cert<br>Number"}, 
            {field : "MemberID",title : "Member<br>ID"}, 
            {field : "InsuredName",title : "Insured<br>Name"}, 
            {field : "DocType",title : "Doc<br>Type"}, 
            {field : "BatchNumber",title : "Batch<br>Number"}, 
            {field : "Channel",title : "Channel"} 
        ],
        scrollable : true,
        pageable: {
            buttonCount: 10,
            previousNext: false
        }
    }).data("kendoGrid");

     $(".autohide").kendoTooltip({
            position: "top"
     });
});

//var DescriptionInformation1 = [{
    var DescriptionInformation1 = new kendo.data.DataSource({
    data: [
    {
        ID : 1,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 26,300,000",
        IconHighlight : "icon-highlight",
        TitleIconHighlight : "Canton - 300,000",
        DateReceived : "7/8/2016",
        HospitalName : "Jame",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Fax"
    },{
        ID : 2,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 26,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "5/8/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Email"
    },{
        ID : 3,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 26,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "9/12/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Hojimin",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Scan"
    },{
        ID : 4,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 900,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "7/8/2016",
        HospitalName : "Jame",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Fax"
    },{
        ID : 5,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "5/8/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Email"
    },{
        ID : 6,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 60,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "9/12/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Hojimin",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Scan"
    },{
        ID : 7,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 7,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "7/8/2016",
        HospitalName : "Jame",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Fax"
    },{
        ID : 8,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 26,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "5/8/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Email"
    },{
        ID : 9,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 16,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "9/12/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Hojimin",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Scan"
    },{
        ID : 10,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 4,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "7/8/2016",
        HospitalName : "Jame",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Fax"
    },{
        ID : 11,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 4,300,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "5/8/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Jammi",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Email"
    },{
        ID : 12,
        Link : "validate.html",
        IconAlert : "icon-alert",
        TitleIconAlert : "Canton - 900,000",
        IconHighlight : "",
        TitleIconHighlight : "",
        DateReceived : "9/12/2016",
        HospitalName : "Smith",
        PolicyNumber : "T0658",
        CertNumber : "AIA456789",
        MemberID : "Hojimin",
        InsuredName : "Netnapha",
        DocType : "Insured",
        BatchNumber : "T6B08",
        Channel : "Scan"
    }
],
    pageSize: 10
});

// $(".autohide").kendoTooltip({
//     position: "top"
// });

// $(function () {
//   $('[data-toggle="tooltip"]').tooltip()
// })