$(document).ready(function () {
    renderPresentedTable();
    renderTotalReimbursementTable();
    renderForLifePolicyTable();
    renderForCSePolicyTable();
});

//Presented
function renderPresentedTable(){
    $("#PresentedGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataPresented,
            autoSync: true,
            schema: {
                model: {
                    id: "presentedID",
                    fields: {
                        presentedID: {editable: false, nullable: true },
                        presentedBillingItems:{ editable: false },
                        presentedAmount: {type: "number", editable: false},
                        presentedDay:{type: "number", editable: false },
                        presentedStartDate :{type: "date", editable: false }, 
                        presentedEndDate:{type: "date", editable: false }, 
                        presentedPercentage :{type: "number", editable: false },
                        presentedCode:{type: "string", editable: false }
                    }
                }
            },
            aggregate:[{field: "presentedAmount", aggregate: "sum"}]
        },
        columns: [
            {
                field: "presentedBillingItems", 
                title: "Billing Items",
                headerAttributes: {"class": "right-cell"},
                footerTemplate: "<div class='totaltext'>Total Bill Amount</div>",
                //footerAttribute: {"class":"totalblock"},
                groupFooterTemplate: "this is a footer",
                width:200
            },{
                field: "presentedAmount",
                title: "Amount (THB)",
                headerAttributes:{"class": "text-right right-cell"},
                attributes: {"class": "text-right"},
                template: '#=kendo.format("{0:n2}", presentedAmount)#',
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                footerAttribute: {"class":"totalblock"},
                width:150
            },{
                field: "presentedDay",
                title: "Day",
                headerAttributes:{"class": "right-cell"},
                width:100
            },{
                title: "Date",
                headerAttributes: {"class": "header-cell"},
                columns: [
                    {
                        field: "presentedStartDate",
                        title: "Start",
                        format:"{0:MM-dd-yyyy}", 
                        headerAttributes:{"class": "right-cell"},
                        attributes:{"class": "dategrid"},
                        width:120
                    },{
                        field: "presentedEndDate",
                        title: "End",
                        format:"{0:MM-dd-yyyy}",
                        headerAttributes: {"class": "right-cell"},
                        attributes:{"class": "dategrid"},
                        width:120
                    }
                ]
            },{
                field: "presentedPercentage",
                title: "%",
                template: '#=kendo.format("{0:p0}", presentedPercentage/100)#',
                headerAttributes: {"class": "text-right right-cell"},
                attributes: {"class": "text-right"},
                width:100
            }
        ],
        scrollable: false,
        sortable: true,
        editable:false,
        selectable : false,
        navigatable: false,
        pageable: false
    });

}

//Content for Presented
var dataPresented = [
    {
        presentedID: 1, 
        presentedBillingItems : "AI",
        presentedAmount: 20000000,
        presentedDay : "15", 
        presentedStartDate : "10/09/2016", 
        presentedEndDate : "12/09/2016", 
        presentedPercentage : "50"
    },{
        presentedID: 2, 
        presentedBillingItems :"HS",
        presentedAmount: 30000000,
        presentedDay : "15", 
        presentedStartDate : "07/07/2014", 
        presentedEndDate : "12/11/2018", 
        presentedPercentage : "90"
    },{
        presentedID: 3, 
        presentedBillingItems : "AI",
        presentedAmount: 90000000,
        presentedDay : "15", 
        presentedStartDate : "10/09/2016", 
        presentedEndDate : "12/09/2016", 
        presentedPercentage : "50"
    },{
        presentedID: 4, 
        presentedBillingItems :"HS",
        presentedAmount: 60000000,
        presentedDay : "15", 
        presentedStartDate : "07/07/2014", 
        presentedEndDate : "12/11/2018", 
        presentedPercentage : "90"
    }
];

//Total Reimbursement
function renderTotalReimbursementTable(){
    $("#TotalReimbursementGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataTotalReimbursement,
            autoSync: true,
            schema: {
                model: {
                    id: "totalRID",
                    fields: {
                        totalRID: {editable: false, nullable: true },
                        totalRName:{ editable: false },
                        totalRAmount :{type: "number", editable: false }
                    }
                }
            },
            aggregate:[{field: "totalRAmount", aggregate: "sum"}]
        },
        columns: [
            {
                field: "totalRName", 
                title: "Reimbursement",
                footerTemplate: "Total Reimbursement",
                width: "50%"
            },{
                field: "totalRAmount",
                title: "Amount (THB)",
                template: '#=kendo.format("{0:n2}", totalRAmount)#',
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width: "50%"
            }
        ],
        scrollable: false,
        sortable: true,
        editable:false,
        selectable : false,
        navigatable: false,
        pageable: false
    });
}

var dataTotalReimbursement = [
    {
        totalRID: 1,
        totalRName: "AI",
        totalRAmount: "1000000"
    },{
        totalRID: 2,
        totalRName: "HS",
        totalRAmount: "2000000"
    },{
        totalRID: 3,
        totalRName: "HB",
        totalRAmount: "4000000"
    },{
        totalRID: 4,
        totalRName: "CI",
        totalRAmount: "6000000"
    },{
        totalRID: 5,
        totalRName: "CS",
        totalRAmount: "8000000"
    }
];

//Settled For life policy
function renderForLifePolicyTable(){
    $("#settledForLifePolicyGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataForLifePolicy,
            autoSync: true,
            schema: {
                model: {
                    id: "forLID",
                    fields: {
                        forLID: {editable: false, nullable: true },
                        forLBenefit: {type: "string", editable: false},
                        forLAmount: {type: "number", editable: false},
                        forLDay: {type: "number", editable: false},
                        forLPercentage: {type: "number", editable: false},
                        forLReimbursed: {type: "number", editable: false},
                        forLDbInd: {type: "boolean", editable: false}
                    }
                }
            },
            group:[ 
                {
                    field: "forLPlan",
                    aggregate:[
                        {field: "forLAmount", aggregate: "sum"},
                        {field: "forLReimbursed", aggregate: "sum"}
                    ]
                }
            ],
            aggregate:[
                {field: "forLAmount", aggregate: "sum"},
                {field: "forLReimbursed", aggregate: "sum"}
            ]
        },
        columns: [
            {
                field: "forLBenefit", 
                title: "Benefit",
                footerTemplate: "Total Amount",
                width:200
            },{
                field: "forLAmount", 
                title: "Amount",
                aggregates: ["sum"],
                template: '#=kendo.format("{0:n2}", forLAmount)#',
                groupHeaderTemplate: "test",
                groupFooterTemplate: "<div class='text-right'>10,000,000.00</div>",
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",//http://jsfiddle.net/dimodi/pcDq5/
                footerAttributes: {"class": "hhhhh"},
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },{
                field: "forLDay", 
                title: "Day",
                width:100
            },{
                field: "forLPercentage", 
                title: "%",
                template: '#=kendo.format("{0:p0}", forLPercentage/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:100
            },{
                field: "forLDbInd", 
                title: "Db/Ind",
                template: '<input type="checkbox" #= forLDbInd ? \'checked="checked"\' : "" # id="DbInd" disabled />',
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-center"},
                width:120
            },{
                field: "forLReimbursed", 
                title: "Reimbursed Paid Amount",
                template: '#=kendo.format("{0:n2}", forLReimbursed)#',
                groupFooterTemplate: "<div class='text-right'>10,000,000.00</div>",
                footerTemplate: "<div class='text-left pull-left'>Total Reimbursed Paid Amount</div><div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"}
            }
        ],
        scrollable: false,
        sortable: true,
        editable:false,
        selectable : false,
        navigatable: false
    });

}

var dataForLifePolicy = [
    {   
        forLPlan: "Plan A",
        forLID: 1,
        forLBenefit: "TOTAL DISABILITY (10/10/2016 - 11/25/2017)",
        forLAmount: "20000000",
        forLDay: "20",
        forLPercentage: "50",
        forLReimbursed: "4000000",
        forLDbInd: true
    },{
        forLPlan: "Plan A",
        forLID: 2,
        forLBenefit: "PARTIAL DISABILITY",
        forLAmount: "40000000",
        forLDay: "60",
        forLPercentage: "90",
        forLReimbursed: "7000000",
        forLDbInd: false
    },{
        forLPlan: "Plan B",
        forLID: 3,
        forLBenefit: "HOSPITAL INDEMNITY",
        forLAmount: "9000000",
        forLDay: "30",
        forLPercentage: "40",
        forLReimbursed: "800000",
        forLDbInd: true
    },{
        forLPlan: "Plan B",
        forLID: 4,
        forLBenefit: "HI",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPlan: "Plan B",
        forLID: 5,
        forLBenefit: "OPD HDCHEMORADIO",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPlan: "Plan C",
        forLID: 6,
        forLBenefit: "OPERATING THEATRE FEE",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPlan: "Plan C",
        forLID: 7,
        forLBenefit: "HBJ-ADMIT",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPlan: "Plan C",
        forLID: 8,
        forLBenefit: "CR DAY",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    }
];

//Settled For CS policy
function renderForCSePolicyTable(){
    $("#settledForCSePolicyGrid").kendoGrid({
        autobind: true,
        pageable: false,
        dataSource: {
            data: dataForCSPolicy,
            pageSize: false,
            autoSync: true,
            schema: {
                model: {
                    id: "forCSID",
                    fields: {
                        forCSID: {editable: false, nullable: true },
                        forCSBenefit: {type: "string", editable: false},
                        forCSBenefitAmount: {type: "number", editable: false},
                        forCSDayTime: {type: "date", editable: false},
                        forCSPercentage: {type: "number", editable: false},
                        forCSCopayment: {type: "number", editable: false},
                        forCSReimbursed: {type: "number", editable: false},
                        forCSCO: {type: "number", editable: false}
                    }
                }
            }
        },
        columns: [
            {
                field: "forCSBenefit",
                title: "Benefit",
                width:120
            },{
                field: "forCSBenefitAmount",
                title: "Benefit Amount",
                template: '#=kendo.format("{0:n2}", forCSBenefitAmount)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },{
                field: "forCSDayTime", 
                title: "Day/Time",
                template: '#=kendo.format("{0:g}", forCSDayTime)#',
                width: 120
            },{
                field: "forCSPercentage", 
                title: "%",
                template: '#=kendo.format("{0:p0}", forCSPercentage/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:80
            },{
                field: "forCSCopayment",
                title: "Co-payment",
                template: '#=kendo.format("{0:n2}", forCSCopayment)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },{
                field: "forCSReimbursed",
                title: "Reimbursed Paid Amount",
                template: '#=kendo.format("{0:n2}", forCSReimbursed)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },{
                field: "forCSCO",
                title: "COMP/PAY",
                template: '#=kendo.format("{0:p0}", forCSCO/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:80
            }
        ],
        scrollable: false,
        sortable: true,
        editable:false,
        selectable : false,
        navigatable: false,
        pageable: false
    });
}

var dataForCSPolicy = [
    {
        forCSID: 1,
        forCSBenefit: "DAILY ROOM & BOARD",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSID: 2,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSID: 3,
        forCSBenefit: "DAILY ROOM & BOARD",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSID: 4,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    }
];