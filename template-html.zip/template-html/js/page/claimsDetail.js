$(document).ready(function () {
    renderHistryNameTable();
    renderBillingItemTable();
    renderPendingManagementTable();
    renderPresentedTable();
    renderTotalReimbursementTable();
    renderForLifePolicyTable();
    renderForCSePolicyTable();
});

 //Histry Name
function renderHistryNameTable(){
    $(".hname-data").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 5,
            data: [
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"}
            ]
        }
        ,
        columns: [{
            field: "historyname",
            title: "History name"
        }, {
            field: "updateddate",
            title: "Updated date"
        }]
    });
}

function renderBillingItemTable(){
    var BillingForm = new kendo.data.DataSource({
        pageSize: 20,
        data: databilling,
        autoSync: true,
        schema: {
            model: {
                id: "BillingId",
                fields: {
                    BillingId: { editable: false, nullable: true },
                    BillingItems:{ editable: false },
                    BillingCategory :{ editable: false },
                    BillingGrossamount :{ type: "number", editable: false }, 
                    BillingDiscountamount :{ type: "number", editable: false }, 
                    BillingDiscount :{ type: "number", editable: false },
                    BillingNetamount :{ type: "number", editable: false },
                    BillingAgreeddiscount :{ type: "number", editable: false }
                }
            }
        }
    });

    $("#billingitem").kendoGrid({
        dataSource: BillingForm,
        sortable: true,
        selectable: "multiple, row",
        autoBind: true,
        scrollable: true,
        sortable: true,
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        },
        columns: [
            {
                field: "BillingItems", 
                title: "Billing items", 
                editor: BillingTypeDropDownEditor, 
                template: "#=BillingItems.BillingTypeName#",
                width:200
            },{
                field: "BillingCategory",
                title: "Category"
            },
            {
                field: "BillingGrossamount",
                title: "Gross amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                field: "BillingDiscountamount",
                title: "Discount amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:170
            },
            {
                field: "BillingDiscount",
                headerTemplate: "Discount",
                template: '#=kendo.format("{0:p0}", BillingDiscount/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },
            {
                field: "BillingNetamount",
                title: "Net amount",
                format: "{0:n0}",
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            },
            {
                field: "BillingAgreeddiscount",
                title: "Agreed amount",
                template: '#=kendo.format("{0:p0}", BillingAgreeddiscount/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:150
            }
        ]
    });

    var BillingTypeData = new kendo.data.DataSource({
        data: [
            { BillingTypeName: "Operating Theater", BillingTypeId: "1" },
            { BillingTypeName: "Surgeon fee", BillingTypeId: "2" },
            { BillingTypeName: "Hospital loan", BillingTypeId: "3" },
            { BillingTypeName: "Hopital Option", BillingTypeId: "4" }
        ]
    });

    function BillingTypeDropDownEditor(container, options) {
        $('<input name="BillingTypeDisplay" class="cmic-edit" required data-text-field="BillingTypeName" data-value-field="BillingTypeId" data-bind="value:' + options.field + '"/>')
            .appendTo(container)
            .kendoComboBox({
                autoBind: true,
                filter: "contains",
                dataTextField: "BillingTypeName",
                dataValueField: "BillingItems",
                dataSource: BillingTypeData
            });
    }
}

var databilling = [
    {
        BillingId:1, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "Operating Theater"
        },
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16,000",
        BillingAgreeddiscount : "50"
    },{
        BillingId:2, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "Surgeon fee"
        } ,
        BillingCategory : "Doctor Charge", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "20", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "20"
    },{
        BillingId:3, 
        BillingItems : {
            BillingTypeId : 4,
            BillingTypeName : "Hopital Option"
        } ,
        BillingCategory : "Doctor Charge", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "70"
    },{
        BillingId:4, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "Operating Theater"
        } ,
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "50", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "60"
    },{
        BillingId:5, 
        BillingItems : {
            BillingTypeId : 2,
            BillingTypeName : "Surgeon fee"
        } ,
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "50", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "50"
    },{
        BillingId:6, 
        BillingItems : {
            BillingTypeId : 4,
            BillingTypeName : "Hopital Option"
        } ,
        BillingCategory : "Doctor Charge", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "70", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "10"
    },{
        BillingId:7, 
        BillingItems : {
            BillingTypeId : 1,
            BillingTypeName : "Operating Theater"
        } ,
        BillingCategory : "Hopital Expense", 
        BillingGrossamount : "200000", 
        BillingDiscountamount : "40000", 
        BillingDiscount : "60", 
        BillingNetamount : "16000",
        BillingAgreeddiscount : "40"
    }
];

//Pending Management
function renderPendingManagementTable(){
    var PendMangeForm = new kendo.data.DataSource({
        pageSize: 20,
        data: dataPendMange,
        autoSync: true,
        schema: {
            model: {
                id: "PendMangeId",
                fields: {
                    PendMangeId: { editable: false, nullable: true },
                    PendMangeStatus:{ editable: false, defaultValue: { PendMangeStatusName: "Outstanding", PendMangeStatusId: "1" }},
                    PendingRequirement: {editable: false},
                    CreatedDate: {editable: false},
                    CreatedUser: {editable: false},
                    ResolvedDate: {editable: false},
                    ResolvedUser: {editable: false}
                }
            }
        }
    });
    $("#pendingManagementGrid").kendoGrid({
        autobind: false,
        dataSource: PendMangeForm,
        scrollable: false,
        sortable: true,
        columns: [
            {
                field: "PendMangeStatus", 
                title: "Status", 
                editor: PendMangeDropDownEditor, 
                template: "#=PendMangeStatus.PendMangeStatusName#",
                width:100
            },
            {field: "PendingRequirement", title: "Pending<br/>Requirement", width:250},
            {field: "CreatedDate", title: "Created<br/>Date", width:100},
            {field: "CreatedUser", title: "Created<br/>User", width:100},
            {field: "ResolvedDate", title: "Resolved<br/>Date", width:100},
            {field: "ResolvedUser", title: "Resolved<br/>User", width:100}
        ],
        editable: {createAt : "top"},
        navigatable: true,
        pageable: {buttonCount: 5,pageSizes: false}
    });
}

var PendMangeData = new kendo.data.DataSource({
    data: [
        { PendMangeStatusName: "Outstanding", PendMangeStatusId: "1" },
        { PendMangeStatusName: "Resolved", PendMangeStatusId: "2" },
        { PendMangeStatusName: "Cancel", PendMangeStatusId: "3" }
    ]
});

function PendMangeDropDownEditor(container, options) {
    $('<input name="PendMangeStatusDisplay" class="cmic-edit" required data-text-field="PendMangeStatusName" data-value-field="PendMangeStatusId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "PendMangeStatusName",
            dataValueField: "PendMangeStatus",
            dataSource: PendMangeData
        });
}

var dataPendMange = [
    {
        PendMangeId: 1, 
        PendMangeStatus : {PendMangeStatusId : 1, PendMangeStatusName : "Outstanding"},
        PendingRequirement: "EA001-Request claims form",
        CreatedDate: "06/12/2559",
        CreatedUser: "mclm022",
        ResolvedDate: "06/15/2559",
        ResolvedUser: "mclm022"
    },{
        PendMangeId: 2, 
        PendMangeStatus : {PendMangeStatusId : 2, PendMangeStatusName : "Resolved"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "05/12/2559",
        CreatedUser: "mclm021",
        ResolvedDate: "05/15/2559",
        ResolvedUser: "mclm021"
    },{
        PendMangeId: 3, 
        PendMangeStatus : {PendMangeStatusId : 3, PendMangeStatusName : "Cancel"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "04/12/2559",
        CreatedUser: "mclm023",
        ResolvedDate: "04/15/2559",
        ResolvedUser: "mclm023"
    },{
        PendMangeId: 4, 
        PendMangeStatus : {PendMangeStatusId : 1, PendMangeStatusName : "Outstanding"},
        PendingRequirement: "EA001-Request claims form",
        CreatedDate: "06/12/2559",
        CreatedUser: "mclm022",
        ResolvedDate: "06/15/2559",
        ResolvedUser: "mclm022"
    },{
        PendMangeId: 5, 
        PendMangeStatus : {PendMangeStatusId : 2, PendMangeStatusName : "Resolved"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "05/12/2559",
        CreatedUser: "mclm021",
        ResolvedDate: "05/15/2559",
        ResolvedUser: "mclm021"
    },{
        PendMangeId: 6, 
        PendMangeStatus : {PendMangeStatusId : 3, PendMangeStatusName : "Cancel"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "04/12/2559",
        CreatedUser: "mclm023",
        ResolvedDate: "04/15/2559",
        ResolvedUser: "mclm023"
    }
];

//Presented
function renderPresentedTable(){
    $("#PresentedGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataPresented,
            autoSync: true,
            schema: {
                model: {
                    id: "presentedID",
                    fields: {
                        presentedID: {editable: false, nullable: true },
                        presentedBillingItems:{ editable: false },
                        presentedAmount: {type: "number", editable: false},
                        presentedDay:{type: "number", editable: false },
                        presentedStartDate :{type: "date", editable: false }, 
                        presentedEndDate:{type: "date", editable: false }, 
                        presentedPercentage :{type: "number", editable: false },
                        presentedCode:{type: "string", editable: false }
                    }
                }
            },
            aggregate:[{field: "presentedAmount", aggregate: "sum"}]
        },
        columns: [
            {
                field: "presentedBillingItems", 
                title: "Billing Items",
                headerAttributes: {"class": "text-center"},
                footerTemplate: "<div class='totaltext'>Total Bill Amount</div>",
                width:200
            },{
                field: "presentedAmount",
                title: "Amount (THB)",
                headerAttributes:{"class": "text-right"},
                attributes: {"class": "text-right"},
                template: '#=kendo.format("{0:n2}", presentedAmount)#',
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                footerAttribute: {"class":"totalblock"},
                width:150
            },{
                field: "presentedDay",
                title: "Day",
                headerAttributes:{"class": "text-center"},
                attributes: {"class": "text-center"},
                width:100
            },{
                field: "presentedPercentage",
                title: "%",
                template: '#=kendo.format("{0:p0}", presentedPercentage/100)#',
                headerAttributes: {"class": "text-right right-cell"},
                attributes: {"class": "text-right"},
                width:100
            }
        ],
        scrollable: false,
        sortable: true,
        editable:false,
        selectable : false,
        navigatable: false,
        pageable: false
    });

}

//Content for Presented
var dataPresented = [
    {
        presentedID: 1, 
        presentedBillingItems : "AI",
        presentedAmount: 20000000,
        presentedDay : "15", 
        presentedStartDate : "10/09/2016", 
        presentedEndDate : "12/09/2016", 
        presentedPercentage : "50"
    },{
        presentedID: 2, 
        presentedBillingItems :"HS",
        presentedAmount: 30000000,
        presentedDay : "15", 
        presentedStartDate : "07/07/2014", 
        presentedEndDate : "12/11/2018", 
        presentedPercentage : "90"
    },{
        presentedID: 3, 
        presentedBillingItems : "AI",
        presentedAmount: 90000000,
        presentedDay : "15", 
        presentedStartDate : "10/09/2016", 
        presentedEndDate : "12/09/2016", 
        presentedPercentage : "50"
    },{
        presentedID: 4, 
        presentedBillingItems :"HS",
        presentedAmount: 60000000,
        presentedDay : "15", 
        presentedStartDate : "07/07/2014", 
        presentedEndDate : "12/11/2018", 
        presentedPercentage : "90"
    }
];

//Total Reimbursement
function renderTotalReimbursementTable(){
    $("#TotalReimbursementGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataTotalReimbursement,
            autoSync: true,
            schema: {
                model: {
                    id: "totalRID",
                    fields: {
                        totalRID: {editable: false, nullable: true },
                        totalRName:{ editable: false },
                        totalRAmount :{type: "number", editable: false }
                    }
                }
            },
            aggregate:[{field: "totalRAmount", aggregate: "sum"}]
        },
        columns: [
            {
                field: "totalRName", 
                title: "Reimbursement",
                headerAttributes: {"class": "text-center"},
                footerTemplate: "Total Reimbursement",
                width: "50%"
            },{
                field: "totalRAmount",
                title: "Amount (THB)",
                template: '#=kendo.format("{0:n2}", totalRAmount)#',
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-right"},
                width: "50%"
            }
        ],
        scrollable: false,
        sortable: true,
        editable:false,
        selectable : false,
        navigatable: false,
        pageable: false
    });
}

var dataTotalReimbursement = [
    {
        totalRID: 1,
        totalRName: "AI",
        totalRAmount: "1000000"
    },{
        totalRID: 2,
        totalRName: "HS",
        totalRAmount: "2000000"
    },{
        totalRID: 3,
        totalRName: "HB",
        totalRAmount: "4000000"
    },{
        totalRID: 4,
        totalRName: "CI",
        totalRAmount: "6000000"
    },{
        totalRID: 5,
        totalRName: "CS",
        totalRAmount: "8000000"
    }
];

//Settled For life policy
function renderForLifePolicyTable(){
    $("#settledForLifePolicyGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataForLifePolicy,
            autoSync: true,
            schema: {
                model: {
                    id: "forLID",
                    fields: {
                        forLID: {editable: false, nullable: true },
                        forLPolicyNo: {editable: false, nullable: true },
                        forLPlan: {editable: false, nullable: true },
                        forLBenefit: {type: "string", editable: false},
                        forLAmount: {type: "number", editable: false},
                        forLDay: {type: "number", editable: false},
                        forLPercentage: {type: "number", editable: false},
                        forLReimbursed: {type: "number", editable: false},
                        forLDbInd: {type: "boolean", editable: false}
                    }
                }
            },
            group:[ 
                {
                    field: "forLPolicyNo",
                    aggregate:[
                        {field: "forLAmount", aggregate: "sum"},
                        {field: "forLReimbursed", aggregate: "sum"}
                    ]
                },{
                    field: "forLPlan",
                    aggregate:[
                        {field: "forLAmount", aggregate: "sum"},
                        {field: "forLReimbursed", aggregate: "sum"}
                    ]
                }
            ],
            aggregate:[
                {field: "forLAmount", aggregate: "sum"},
                {field: "forLReimbursed", aggregate: "sum"}
            ]
        },
        columns: [
            {
                field: "forLPolicyNo",
                hidden: true,
                groupHeaderTemplate: "<div class='templatevalue'>#= value #</div><div class='firstvalue'>200,000,000.00</div><div class='secondvalue'>300,000,000.00</div>"
            },{
                field: "forLPlan",
                hidden: true,
                groupHeaderTemplate: "<div class='templatevalue'>#= value #</div><div class='firstvalue'>12,000,000.00</div><div class='secondvalue'>19,000,000.00</div>",
                width:200
            },{
                field: "forLBenefit", 
                title: "Benefit",
                headerAttributes: {"class": "text-center"},
                template: "#=forLBenefit#<br/>#=forLDateStartEnd#",
                footerTemplate: "Total Amount",
                width:200
            },{
                field: "forLAmount", 
                title: "Amount",
                headerAttributes: {"class": "text-center"},
                aggregates: ["sum"],
                template: '#=kendo.format("{0:n2}", forLAmount)#',
                groupFooterTemplate: "<div class='text-right'>10,000,000.00</div>",
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                attributes: {"class": "text-right"},
                width:150
            },{
                field: "forLDay", 
                title: "Day",
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-center"},
                width:100
            },{
                field: "forLPercentage", 
                title: "%",
                headerAttributes: {"class": "text-center"},
                template: '#=kendo.format("{0:p0}", forLPercentage/100)#',
                attributes: {"class": "text-right"},
                width:100
            },{
                field: "forLReimbursed", 
                title: "Reimbursed Paid Amount",
                template: '#=kendo.format("{0:n2}", forLReimbursed)#',
                groupFooterTemplate: "<div class='text-right'>10,000,000.00</div>",
                footerTemplate: "<div class='text-left pull-left'>Total Reimbursed Paid Amount</div><div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-right"}
            },{
                field: "forLDbInd", 
                title: "Db/Ind",
                template: '<input type="checkbox" #= forLDbInd ? \'checked="checked"\' : "" # id="DbInd" disabled />',
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-center"},
                width:120
            }
        ],
        scrollable: false,
        sortable: false,
        editable:false,
        selectable : false,
        navigatable: false,
        dataBound: function () {
            $( "#settledForLifePolicyGrid .k-reset" ).click(function(e) {
                var resets = $(this).parent().next();
                $(this).toggleClass("collapsed");
                e.preventDefault();
            });
        }
    });

    
}

var dataForLifePolicy = [
    {   
        forLPolicyNo: "T12345678",
        namePolicy: "T12345678",
        forLPlan: "Plan A",
        forLID: 1,
        forLBenefit: "TOTAL DISABILITY",
        forLDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forLAmount: "20000000",
        forLDay: "20",
        forLPercentage: "50",
        forLReimbursed: "4000000",
        forLDbInd: true
    },{
        forLPolicyNo: "T12345678",
        namePolicy: "T12345678",
        forLPlan: "Plan A",
        forLID: 2,
        forLBenefit: "PARTIAL DISABILITY",
        forLDateStartEnd: " ",
        forLAmount: "40000000",
        forLDay: "60",
        forLPercentage: "90",
        forLReimbursed: "7000000",
        forLDbInd: false
    },{
        forLPolicyNo: "T12345678",
        namePolicy: "T12345678",
        forLPlan: "Plan A",
        forLID: 3,
        forLBenefit: "DISABILITY",
        forLDateStartEnd: " ",
        forLAmount: "40000000",
        forLDay: "60",
        forLPercentage: "90",
        forLReimbursed: "7000000",
        forLDbInd: false
    },{
        forLPolicyNo: "T12345678",
        namePolicy: "T12345678",
        forLPlan: "Plan A",
        forLID: 4,
        forLBenefit: "PARTIAL",
        forLDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forLAmount: "40000000",
        forLDay: "60",
        forLPercentage: "90",
        forLReimbursed: "7000000",
        forLDbInd: false
    },{
        forLPolicyNo: "A98765432",
        namePolicy: "A98765432",
        forLPlan: "Plan B",
        forLID: 5,
        forLBenefit: "HOSPITAL INDEMNITY",
        forLDateStartEnd: " ",
        forLAmount: "9000000",
        forLDay: "30",
        forLPercentage: "40",
        forLReimbursed: "800000",
        forLDbInd: true
    },{
        forLPolicyNo: "A98765432",
        namePolicy: "A98765432",
        forLPlan: "Plan B",
        forLID: 6,
        forLBenefit: "HI",
        forLDateStartEnd: " ",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPolicyNo: "A98765432",
        namePolicy: "A98765432",
        forLPlan: "Plan B",
        forLID: 7,
        forLBenefit: "INDEMNITY",
        forLDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forLAmount: "9000000",
        forLDay: "30",
        forLPercentage: "40",
        forLReimbursed: "800000",
        forLDbInd: true
    },{
        forLPolicyNo: "A98765432",
        namePolicy: "A98765432",
        forLPlan: "Plan B",
        forLID: 8,
        forLBenefit: "HI INDEMNITY",
        forLDateStartEnd: " ",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPolicyNo: "R45678914",
        namePolicy: "R45678914",
        forLPlan: "Plan A",
        forLID: 9,
        forLBenefit: "HOSPITAL",
        forLDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forLAmount: "9000000",
        forLDay: "30",
        forLPercentage: "40",
        forLReimbursed: "800000",
        forLDbInd: true
    },{
        forLPolicyNo: "R45678914",
        namePolicy: "R45678914",
        forLPlan: "Plan A",
        forLID: 10,
        forLBenefit: "HI INDEMNITY",
        forLDateStartEnd: " ",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    },{
        forLPolicyNo: "R45678914",
        namePolicy: "R45678914",
        forLPlan: "Plan B",
        forLID: 11,
        forLBenefit: "HOSPITAL",
        forLDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forLAmount: "9000000",
        forLDay: "30",
        forLPercentage: "40",
        forLReimbursed: "800000",
        forLDbInd: true
    },{
        forLPolicyNo: "R45678914",
        namePolicy: "R45678914",
        forLPlan: "Plan B",
        forLID: 12,
        forLBenefit: "HI INDEMNITY",
        forLDateStartEnd: " ",
        forLAmount: "19000000",
        forLDay: "70",
        forLPercentage: "40",
        forLReimbursed: "6800000",
        forLDbInd: true
    }
];


//Settled For CS policy
function renderForCSePolicyTable(){
    $("#settledForCSePolicyGrid").kendoGrid({
        autobind: true,
        dataSource: {
            data: dataForCSPolicy,
            autoSync: true,
            schema: {
                model: {
                    id: "forCSID",
                    fields: {
                        forCSID: {editable: false, nullable: true },
                        forCSPolicyNo: {editable: false, nullable: true },
                        forCSPlan: {editable: false, nullable: true },
                        forCSBenefit: {type: "string", editable: false},
                        forCSBenefitAmount: {type: "number", editable: false},
                        forCSDayTime: {type: "date", editable: false},
                        forCSPercentage: {type: "number", editable: false},
                        forCSCopayment: {type: "number", editable: false},
                        forCSReimbursed: {type: "number", editable: false},
                        forCSCO: {type: "number", editable: false}
                    }
                }
            },
            group:[ 
                {
                    field: "forCSPolicyNo",
                    aggregate:[
                        {field: "forCSBenefitAmount", aggregate: "sum"},
                        {field: "forCSReimbursed", aggregate: "sum"}
                    ]
                },{
                    field: "forCSPlan",
                    aggregate:[
                        {field: "forCSBenefitAmount", aggregate: "sum"},
                        {field: "forCSReimbursed", aggregate: "sum"}
                    ]
                }
            ],
            aggregate:[
                {field: "forCSBenefitAmount", aggregate: "sum"},
                {field: "forCSReimbursed", aggregate: "sum"}
            ]
        },
        columns: [
            {
                field: "forCSPolicyNo",
                hidden: true,
                groupHeaderTemplate: "<div class='templatevalue'>#= value #</div><div class='firstvalue'>200,000,000.00</div><div class='secondvalue'>300,000,000.00</div>"
            },{
                field: "forCSPlan",
                hidden: true,
                groupHeaderTemplate: "<div class='templatevalue'>#= value #</div><div class='firstvalue'>12,000,000.00</div><div class='secondvalue'>19,000,000.00</div>"
            },{
                field: "forCSBenefit", 
                title: "Benefit",
                headerAttributes: {"class": "text-center"},
                template: "#=forCSBenefit#<br/>#=forCSDateStartEnd#",
                footerTemplate: "Total",
                width:200
            },{
                field: "forCSBenefitAmount", 
                title: "Benefit Amount",
                aggregates: ["sum"],
                template: '#=kendo.format("{0:n2}", forCSBenefitAmount)#',
                groupFooterTemplate: "<div class='text-right'>10,000,000.00</div>",
                footerTemplate: "<div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-right"},
                width:150
            },{
                field: "forCSDayTime", 
                title: "Day/Time",
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-center"},
                template: '#=kendo.format("{0:g}", forCSDayTime)#',
                width: 120
            },{
                field: "forCSPercentage", 
                title: "%",
                template: '#=kendo.format("{0:p0}", forCSPercentage/100)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:80
            },{
                field: "forCSCopayment",
                title: "Co-payment",
                template: '#=kendo.format("{0:n2}", forCSCopayment)#',
                headerAttributes: {"class": "text-right"},
                attributes: {"class": "text-right"},
                width:120
            },{
                field: "forCSReimbursed", 
                title: "Reimbursed Paid Amount",
                template: '#=kendo.format("{0:n2}", forCSReimbursed)#',
                groupFooterTemplate: "<div class='text-right'>10,000,000.00</div>",
                footerTemplate: "<div class='text-left pull-left'>Total</div><div class='text-right'>#= kendo.toString(sum, 'n2')#</div>",
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-right"},
                width:120
            },{
                field: "forCSCO",
                title: "COMP/PAY",
                template: '#=kendo.format("{0:p0}", forCSCO/100)#',
                headerAttributes: {"class": "text-center"},
                attributes: {"class": "text-right"},
                width:100
            }
        ],
        scrollable: false,
        sortable: false,
        editable:false,
        selectable : false,
        navigatable: false,
        dataBound: function () {
            $( "#settledForCSePolicyGrid .k-reset" ).click(function(e) {
                var resets = $(this).parent().next();
                $(this).toggleClass("collapsed");
                //e.preventDefault();
            });
        }
    });
}

var dataForCSPolicy = [
    {
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan A",
        forCSID: 1,
        forCSBenefit: "DAILY ROOM & BOARD",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan A",
        forCSID: 2,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan A",
        forCSID: 3,
        forCSBenefit: "HI",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan A",
        forCSID: 4,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan B",
        forCSID: 5,
        forCSBenefit: "DAILY ROOM & BOARD",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan B",
        forCSID: 6,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan B",
        forCSID: 7,
        forCSBenefit: "HI",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy A",
        forCSPlan: "Plan B",
        forCSID: 8,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy B",
        forCSPlan: "Plan A",
        forCSID: 9,
        forCSBenefit: "DAILY ROOM & BOARD",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy B",
        forCSPlan: "Plan A",
        forCSID: 10,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy B",
        forCSPlan: "Plan A",
        forCSID: 11,
        forCSBenefit: "HI",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy B",
        forCSPlan: "Plan A",
        forCSID: 12,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy B",
        forCSPlan: "Plan B",
        forCSID: 13,
        forCSBenefit: "DAILY ROOM & BOARD",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy B",
        forCSPlan: "Plan B",
        forCSID: 14,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    },{
        forCSPolicyNo: "Policy C",
        forCSPlan: "Plan B",
        forCSID: 15,
        forCSBenefit: "HI",
        forCSDateStartEnd: " ",
        forCSBenefitAmount: "20000000",
        forCSDayTime: "11/6/2000 12:00 AM",
        forCSPercentage: "40",
        forCSCopayment: "40000000",
        forCSReimbursed: "90000000",
        forCSCO: "25"
    },{
        forCSPolicyNo: "Policy C",
        forCSPlan: "Plan B",
        forCSID: 16,
        forCSBenefit: "OTHER HOSPITAL SERVICES",
        forCSDateStartEnd: "(10/10/2016 - 11/25/2017)",
        forCSBenefitAmount: "30000000",
        forCSDayTime: "12/6/2016 10:00 AM",
        forCSPercentage: "66",
        forCSCopayment: "40000000",
        forCSReimbursed: "75000000",
        forCSCO: "75"
    }
];