$(document).ready(function() {
    renderMyTeamWorkGrid();

});

function renderMyTeamWorkGrid() {
    var myTeamWorkGridForm = new kendo.data.DataSource({
        pageSize: 10,
        data: DataMyTeamWork,
        autoSync: true,
        schema: {
            model: {
                id: "myTeamWorkID",
                fields: {
                    myTeamWorkID: { editable: false, nullable: true },
                    slaDt: {type: "date", editable: false, nullable: true },
                    DateReceived: { type: "string",editable: false },
                    ClaimNumber: { type: "string",editable: false },
                    ClaimStatus: { type: "string",editable: false },
                    PolicyNumber: { type: "string",editable: false },
                    CertNumber: { type: "string",editable: false },
                    InsuredName: { type: "string",editable: false },
                    HospitalName: { type: "string",editable: false },
                    RequestType: { type: "string",editable: false },
                    Channel: { type: "string",editable: false },
                    Activity: { type: "string",editable: false },
                    ActivityOwner: { type: "string",editable: false },
                    PreviousUser: { type: "string",editable: false },
                    Risk: { type: "string",editable: false }
            }
            }
        }
    });

    grid = $("#MyTeamWorkGrid").kendoGrid({
        toolbar: [{template: kendo.template($("#assignToolbar").html())}],
        dataSource:myTeamWorkGridForm,
        dataBound: checkDateDataBound,
        sortable: true,
        selectable: "row",
        autoBind: true,
        scrollable: true,
        pageable: {buttonCount: 5, pageSizes: true},
        columns: [
            {
                field: "", 
                title: "<input id='chkall' name='chkall' type='checkbox' class='checkboxall'/>",
                width: 40,
                template: "<input name='chklist' type='checkbox' class='checkboxsub'/>"
            },{
                title : " ",
                field : "Icon", 
                width:120,
                attributes:{"class": "text-center"},
                template: "<span class='ic_table icon-alert cmictooltip #= IconUrgent#' title='Urgent'></span><span class='ic_table icon-vip cmictooltip #= IconVIP#' title='VIP'></span><span class='ic_table icon-assigned cmictooltip #= IconAssigned#' title='Assigned'></span>"
            },
             {title : " ",field : "slaDt", template: "#= kendo.toString(slaDt,'MM/dd/yyyy') #", hidden: true}, 
            {field: "DateReceived", title: "Date<br/>received",width:150},
            {field: "ClaimNumber", title: "Claim<br/>number", width: 100},
            {field: "ClaimStatus", title: "Claim<br/>status", width: 100},
            {field: "PolicyNumber", title: "Policy<br/>Number", width: 100},
            {field: "CertNumber", title: "Cert.<br/>Number", width: 100},
            {field: "InsuredName", title: "Insured<br/>name", width: 100},
            {field: "HospitalName", title: "Hospital<br/>name", width: 150},
            {field: "RequestType", title: "Request<br/>Type", width: 100},
            {field: "Channel", title: "Channel", width: 100},
            {field: "Activity", title: "Activity", width: 100},
            {field: "ActivityOwner", title: "Activity<br/>owner", width: 100},
            {field: "PreviousUser", title: "Previous<br/>user", width: 100},
            {field: "Risk", title: "Risk", width: 100}
        ],
        editable: false
    }).data("kendoGrid");

    $("#MyTeamWorkGrid").kendoTooltip({
        filter: "span.cmictooltip",
        position: "top",
        width: 85
    }).data("kendoTooltip");

    var grid = $("#MyTeamWorkGrid").data("kendoGrid");
    grid.bind("dataBound", checkDateDataBound);
    grid.dataSource.fetch();

    function checkDateDataBound() {
        var currentDate = new Date();
        currentDate = currentDate.setHours(0, 0, 0, 0);
        dataView = this.dataSource.view();
        for (var i = 0; i < dataView.length; i++) {
            // check if the fields match and apply a class to the row if so
            var showingdate = dataView[i].slaDt.setHours(0, 0, 0, 0);
            var uid = dataView[i].uid;
            
            if (showingdate == currentDate) {
                $("#MyTeamWorkGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statustoday");
            }
            else if (showingdate < currentDate) {
                $("#MyTeamWorkGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statuspast");
            }
            else {
                $("#MyTeamWorkGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statusfuture");
            }
        }
    }

    // Checkbox all
    $(".checkboxall").click(function(){
       var selectall = $("#chkall")[0].checked;
       $(".checkboxsub").each(function( index ) {
         $( this ).prop('checked', selectall);
       });
        if (selectall) {
            $("tr").addClass("k-state-selected");
        } else {
            $("tr").removeClass("k-state-selected");
        }
    });

    // Checkbox 
    $(".checkboxsub").click(function(){
        var row = $(this).closest("tr");
        if (this.checked) {
            row.addClass("k-state-selected");
        } else {
            row.removeClass("k-state-selected");
        }
    });
}

var DataMyTeamWork = [
    {
        myTeamWorkID: 1,
        slaDt: "2016-11-11T00:23:00",
        IconUrgent: "enable",
        IconVIP: "disable",
        IconAssigned: "enable",
        DateReceived: "06/10/2559 15:35",
        ClaimNumber: "12345678",
        ClaimStatus: "MCS Final",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "สมชาย ใจดี",
        HospitalName: "เวชธานี",
        RequestType: "HC Part 2",
        Channel: "Fax",
        Activity: "Processing",
        ActivityOwner: "MCLM123",
        PreviousUser: "MCLM066",
        Risk: "3"
    },{
        myTeamWorkID: 2,
        slaDt: "2016-11-11T00:23:00",
        IconUrgent: "enable",
        IconVIP: "disable",
        IconAssigned: "enable",
        DateReceived: "06/10/2559 15:35",
        ClaimNumber: "12345678",
        ClaimStatus: "MCS Final",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "สมชาย ใจดี",
        HospitalName: "เวชธานี",
        RequestType: "HC Part 2",
        Channel: "Fax",
        Activity: "Processing",
        ActivityOwner: "MCLM123",
        PreviousUser: "MCLM066",
        Risk: "3"
    },{
        myTeamWorkID: 3,
        slaDt: "2014-11-11T00:23:00",
        IconUrgent: "enable",
        IconVIP: "enable",
        IconAssigned: "enable",
        DateReceived: "06/10/2559 15:35",
        ClaimNumber: "12345678",
        ClaimStatus: "MCS Final",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "สมชาย ใจดี",
        HospitalName: "เวชธานี",
        RequestType: "HC Part 2",
        Channel: "Fax",
        Activity: "Processing",
        ActivityOwner: "MCLM123",
        PreviousUser: "MCLM066",
        Risk: "3"
    },{
        myTeamWorkID: 4,
        slaDt: "2014-11-11T00:23:00",
        IconUrgent: "enable",
        IconVIP: "disable",
        IconAssigned: "enable",
        DateReceived: "06/10/2559 15:35",
        ClaimNumber: "12345678",
        ClaimStatus: "MCS Final",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "สมชาย ใจดี",
        HospitalName: "เวชธานี",
        RequestType: "HC Part 2",
        Channel: "Fax",
        Activity: "Processing",
        ActivityOwner: "MCLM123",
        PreviousUser: "MCLM066",
        Risk: "3"
    },{
        myTeamWorkID: 5,
        slaDt: "2018-11-11T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        IconAssigned: "enable",
        DateReceived: "06/10/2559 15:35",
        ClaimNumber: "12345678",
        ClaimStatus: "MCS Final",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "สมชาย ใจดี",
        HospitalName: "เวชธานี",
        RequestType: "HC Part 2",
        Channel: "Fax",
        Activity: "Processing",
        ActivityOwner: "MCLM123",
        PreviousUser: "MCLM066",
        Risk: "3"
    },{
        myTeamWorkID: 6,
        slaDt: "2018-11-11T00:23:00",
        IconUrgent: "disable",
        IconVIP: "disable",
        IconAssigned: "enable",
        DateReceived: "06/10/2559 15:35",
        ClaimNumber: "12345678",
        ClaimStatus: "MCS Final",
        PolicyNumber: "T12345678",
        CertNumber: "12345678",
        InsuredName: "สมชาย ใจดี",
        HospitalName: "เวชธานี",
        RequestType: "HC Part 2",
        Channel: "Fax",
        Activity: "Processing",
        ActivityOwner: "MCLM123",
        PreviousUser: "MCLM066",
        Risk: "3"
    }
];

