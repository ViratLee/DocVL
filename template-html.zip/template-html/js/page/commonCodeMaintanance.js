$(document).ready(function() {
    rendercommonCodeMaintanance();

});

function rendercommonCodeMaintanance(){
    var commonCodeMaintanance = $("#commonCodeGrid").kendoGrid({
        dataSource: {
            data: dataCommonCodeMaintanance,
            pageSize: 10,
            schema: {
                model: {
                    id: "commonCodeID",
                    fields: {
                        commonCodeID: { editable: false, nullable: true },
                        commonCodeCodeValue: { type: "string", editable: false},
                        commonCodeCodeDesc: { type: "string", editable: false},
                        commonCodeCodeDescThai: { type: "string", editable: false},
                        commonCodeCodeDescLong: { type: "string", editable: false},
                        commonCodeCodeDescLongThai: { type: "string", editable: false},
                        commonCodeLastModifiedBy: { type: "string", editable: false},
                        commonCodeLastModifiedDT: { type: "string", editable: false}
                    }
                }
            }
        },
        scrollable: true,
        sortable: true,
        pageable: {buttonCount: 5,pageSizes: true},
        selectable: "multiple, row",
        rowTemplate : kendo.template($("#commonCodeRowTemplate").html()),
        toolbar: [{template: kendo.template($("#commonCodeToolbar").html())}],
        columns: [
            {field: "commonCodeCodeValue", title: "Code Value",width: 120},
            {field: "commonCodeCodeDesc", title: "Code Desc",width: 200},
            {field: "commonCodeCodeDescThai", title: "Code Desc Thai",width:200},
            {field: "commonCodeCodeDescLong", title: "Code Desc Long",width: 450},
            {field: "commonCodeCodeDescLongThai", title: "Code Desc Long Thai",width: 450},
            {field: "commonCodeLastModifiedBy", title: "Last Modified By",width:150},
            {field: "commonCodeLastModifiedDT", title:"Last Modified Date",width: 250}
        ],
            editable: true,
            navigatable: true
        });
}

var dataCommonCodeMaintanance = [
    {
        commonCodeID: 1,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 3,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016",
    },{
        commonCodeID: 2,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 4,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 5,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 6,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 7,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 8,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 9,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    },{
        commonCodeID: 10,
        commonCodeCodeValue : "37H",
        commonCodeCodeDesc : "H37-HSHBTonsil",
        commonCodeCodeDescThai : "Example Vale",
        commonCodeCodeDescLong : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        commonCodeCodeDescLongThai : "เป็นข้อยกเว้นของสัญญาซึ่งไม่คุ้มครอง การรักษา หรือผ่าตัดต่อมทอนซิลขณะที่ได้รับ ความคุ้มครองต่อเนื่องกัน เป็นเวลาน้อยกว่า 120วัน",
        commonCodeLastModifiedBy : "SYS",
        commonCodeLastModifiedDT : "11/25/2016"
    }
];  

