$(document).ready(function() {
	$("#show-search").click();

	// Doctor list table
	$("#DoctorListGrid").kendoGrid({
		columns : [ {
			title : "Doctor name",field : "doctorName",width:200}, 
			{title : "License",field : "license", width:150}, 
			{title : "Specialist",field : "specialist", width:200},
			{title : "Doctor ID",field : "DoctorID"}, 
			{title : "Telephone",field : "tel"}, 
			{title : "Fax",field : "fax"}, 
			{title : "E-mail",field : "email"} 
		],
		scrollable : true,
		rowTemplate: kendo.template($("#DoctorListTemplate").html()),
		selectable : "row",
		sortable : true,
		dataSource : {data: DataDoctorList,pageSize: 10},
		pageable: {buttonCount: 5,pageSizes: true}
	});

});

//Content for doctor list table
var DataDoctorList = [ 
		{
			ID : 1,
			DoctorListLink : "doctorDetail.html",
			Highlight  : "colorred",
			doctorName : "พพ.สมชาย ได้ดี",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 2,
			Highlight  : "colorred",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พญ.ทานทิพย์ มารยาทงาม",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 3,
			Highlight  : "colorred",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พพ.สมชาย ได้ดี",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 4,
			Highlight  : "coloryellow",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พญ.ทานทิพย์ มารยาทงาม",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		},{
			ID : 5,
			Highlight  : "coloryellow",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พพ.สมชาย ได้ดี",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 6,
			Highlight  : "coloryellow",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พญ.ทานทิพย์ มารยาทงาม",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		},{
			ID : 7,
			Highlight  : "",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พพ.สมชาย ได้ดี",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 8,
			Highlight  : "",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พญ.ทานทิพย์ มารยาทงาม",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		},{
			ID : 9,
			Highlight  : "",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พพ.สมชาย ได้ดี",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 10,
			Highlight  : "",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พญ.ทานทิพย์ มารยาทงาม",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		},{
			ID : 11,
			Highlight  : "",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พพ.สมชาย ได้ดี",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}, {
			ID : 12,
			Highlight  : "",
			DoctorListLink : "doctorDetail.html",
			doctorName : "พญ.ทานทิพย์ มารยาทงาม",
			license : "9876543431",
			specialist : "Infectious Medicine",
			DoctorID : "12345678",
			tel : "0861618944",
			fax : "022345678",
			email: "example@email.com"
		}
	];

function showResult(e) {
	$('#resultDiv').show();
}

function hideResult(e) {
	$('#resultDiv').hide();
}


