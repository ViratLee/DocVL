$(document).ready(function(){

    // Chart
    function addCommas(nStr){
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {x1 = x1.replace(rgx, '$1' + ',' + '$2');}
    return x1 + x2;
}
    function createChart(id,title,MidleText,showData,showIndex) {
    var color = "";
    if (showData.length == 2) {
        color = [ "#97cb5d","#ff95a9","#FBBF56"];
    }else if (showData.length == 3){
        color = ["#97cb5d","#FBBF56","#FBBF56"];
    }
    $(id).kendoChart({
        legend : {
            visible : false
        },
        chartArea : {
            background : ""
        },
        seriesDefaults : {
            type : "donut",
            startAngle : 90,
            holeSize: 100,
            size: 15,
            overlay: {
                gradient: "none"
            },
        },
        seriesColors: color,
        series : [ {
            data : showData
        } ]
    });
    $(id).append('<span class="allChartTxt chartTitle">'+title+'</span>');
    $(id).append('<div class="chartTxt">'+MidleText+'</div>');

    var titleHtml = '<div class="chartTextCenter">';
    titleHtml += '<span class="chartValue" id="chartData">'+addCommas(showData[showIndex].value)+'</span>';
    titleHtml += '<div class="chartTxt" id="chartTxt">'+showData[showIndex].MidleText+'</div>';
    titleHtml += '</div>';
    $(id).append(titleHtml);

        var html = '<div class="chartBottom">';
        for (var k = showData.length-1; k >= 0; k--) {
            html += '<span class=" chartValueBottom" style="background:'+color[k]+'">'+addCommas(showData[k].value)+'</span><span class=" chartTxtBottom">'+showData[k].title+'</span>';
        }
        html += '</div>';
        $(id).append(html);
}

    var dataChart1 = [{
        MidleText: "Completed",
        title : "Completed",
        value : "100"
    },{
        title : "Waiting",
        value : "500"
    }];
    createChart('#homeIndex-donutChart1','You','',dataChart1,'0');

    var dataChart2 = [{
        MidleText: "Completed",
        title : "Completed",
        value : "200"
    },{
        title : "Waiting",
        value : "500"
    }];
    createChart('#homeIndex-donutChart2','Team','',dataChart2,'0');

    //Table
    RenderIndexingGrid();

});

function RenderIndexingGrid() {
    $("#IndexingGrid").kendoGrid({
        columns : [
            {title : " ",field : "Icon", width: 85}, 
            {title : "Date<br>received",field : "Datereceived"}, 
            {title : "Channel",field : "Channel"}, 
            {title : "Total<br>page",field : "Totalpage"}, 
            {title : "Identified<br>no.",field : "Identifiedno"}, 
            {title : "Membership<br>No.",field : "MemberID"}, 
            {title : "Doc Type",field : "DocType"}, 
            {title : "Batch<br>Number",field : "BatchNumber"}
        ],
        rowTemplate : kendo.template($("#tableIndexingTemplate").html()),
        scrollable : true,
        selectable : "row",
        sortable :true,
        dataSource : {
            data: dataindexing,
            pageable: 10
        },
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        }
    });
    $("#IndexingGrid").kendoTooltip({
        filter: "span.cmictooltip",
        position: "top",
        width: 85
    }).data("kendoTooltip"); 
}

//content for indexing
var dataindexing = [
    {
        ID : "1",
        Highlight  : "colorred",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "enable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax 02-1234567",
        Totalpage : "9",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "2",
        Highlight  : "colorred",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "enable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax",
        Totalpage : "7",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "3",
        Highlight  : "coloryellow",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax",
        Totalpage : "6",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "4",
        Highlight  : "coloryellow",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Internet",
        Totalpage : "2",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "5",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Scan",
        Totalpage : "5",
        Identifiedno : "T12345639",
        MemberID : "AIA123639",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "6",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Email",
        Totalpage : "6",
        Identifiedno : "T12345676",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345676"
    },
    {
        ID : "7",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Internet",
        Totalpage : "9",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "8",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax",
        Totalpage : "7",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "9",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax",
        Totalpage : "6",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "10",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax",
        Totalpage : "2",
        Identifiedno : "T12345678",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "11",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Fax",
        Totalpage : "5",
        Identifiedno : "T12345639",
        MemberID : "AIA123639",
        DocType : "HC Claim form",
        BatchNumber : "IM12345678"
    }, {
        ID : "12",
        Highlight  : "No",
        Link : "homeIndexSearchResult.html",
        IconUrgent: "disable",
        IconVIP: "disable",
        DateReceived : "06/12/2559  15:35",
        Channel : "Email",
        Totalpage : "6",
        Identifiedno : "T12345676",
        MemberID : "AIA123658",
        DocType : "HC Claim form",
        BatchNumber : "IM12345676"
    }
];


