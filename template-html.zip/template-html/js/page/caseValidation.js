$(document).ready(function(){
    renderReleatedCliamGrid();
    RenderUploadDocument();   
});

//kendo Upload
function RenderUploadDocument(){
     $("#FilesUpload").kendoUpload({
        async: {
            saveUrl: "save",
            removeUrl: "remove",
            allowmultiple: false,
            autoUpload: true
            
        },
        localization: {
            select: "Browse File"
        }
    });
}

function renderReleatedCliamGrid() {
	
		 var ReleatedCliamForm = new kendo.data.DataSource({
			pageSize: 10,
			data: dataReleatedCliam,
			autoSync: true,
			schema: {
				model: {
					id: "ReleatedCliamID",
					fields: {
						ReleatedCliamID: { editable: false, nullable: true },
						slaDt: {type: "date", editable: false, nullable: true }
					}
				}
			}
		});
	
        grid = $("#ReleatedCliamGrid").kendoGrid({
        columns : [
            {
				title : " ",
				field : "Icon", 
				width:85,
                attributes:{"class": "text-center"},
				template: "<span class='ic_table icon-alert cmictooltip #= IconUrgent#' title='Urgent'></span><span class='ic_table icon-vip cmictooltip #= IconVIP#' title='VIP'></span>"
			},
			{title : " ",field : "slaDt", template: "#= kendo.toString(slaDt,'MM/dd/yyyy') #", hidden: true}, 			
            {title : "Date<br/>Received",field : "DateReceived", width: 150}, 
            {title : "Policy<br/>Number",field : "PolicyNumber", width: 100}, 
            {title : "Cert<br/>Number",field : "CertNumber", width: 100}, 
            {title : "Insured<br>Name",field : "InsuredName", width: 150}, 
            {title : "Claim<br/>no.",field : "ClaimNo", width: 100}, 
            {title : "Claim<br/>status",field : "ClaimStatus", width: 100},
            {title : "Loss<br/>date",field : "LossDate", width: 100, format: "{0:MM/dd/yyyy}"},
            {title : "Loss<br/>code",field : "LossCode", width: 120},
            {title : "Injury<br/>area",field : "InjuryArea", width: 150},
            {title : "In hospital<br/>date",field : "InHospitalDate", width: 100},
            {title : "Discharge<br/>date",field : "DischargeDate", width: 100},
            {title : "Hospital<br>Name",field : "HospitalName", width: 150},
            {title : "Channel",field : "Channel", width: 100},
            {
                title: " ",  
                template: "<a href='#= Link #' class='btn btn-blue addtoexiting'><span class='glyphicon glyphicon-plus'></span>Add</a>",
                width: 80
            },
        ],
        scrollable : true,
        selectable : "row",
        sortable : true,
		dataBound: checkDateDataBound,
        dataSource : ReleatedCliamForm,
        pageable: {
            buttonCount: 5,
            pageSizes: true,
        }
    }).data("kendoGrid");
        
    $("#ReleatedCliamGrid").kendoTooltip({
        filter: "span.cmictooltip",
        position: "top",
        width: 85
    }).data("kendoTooltip");
	
	var grid = $("#ReleatedCliamGrid").data("kendoGrid");
	grid.bind("dataBound", checkDateDataBound);
	grid.dataSource.fetch();

	function checkDateDataBound() {
		var currentDate = new Date();
		currentDate = currentDate.setHours(0, 0, 0, 0);
		dataView = this.dataSource.view();
		for (var i = 0; i < dataView.length; i++) {
			// check if the fields match and apply a class to the row if so
			var showingdate = dataView[i].slaDt.setHours(0, 0, 0, 0);
			var uid = dataView[i].uid;
			
			if (showingdate == currentDate) {
				$("#ReleatedCliamGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statustoday");
			}
			else if (showingdate < currentDate) {
				$("#ReleatedCliamGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statuspast");
			}
			else {
				$("#ReleatedCliamGrid tbody").find("tr[data-uid=" + uid + "]").addClass("statusfuture");
			}
		}
	}
}
//Data of dataReleatedCliam
var dataReleatedCliam = [
    {
        ReleatedCliamID : 1,
		slaDt: "2016-11-11T00:23:00",
		IconUrgent: "enable",
        IconVIP: "enable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345678",
        InsuredName : "สมฤดี ศรีสุข",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/01/2016",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "06/12/2559",
        DischargeDate : "06/12/2559",
        HospitalName : "พญาไท 3",
        Channel : "Internet"
    }, {
        ReleatedCliamID : 2,
		slaDt: "2014-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "enable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "นภา แจ่มจันทร์",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/01/2014",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 3,
		slaDt: "2016-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "enable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "เอกชัย เกศนี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/01/2017",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Email"
    },{
        ReleatedCliamID : 4,
		slaDt: "2016-11-10T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "บุญชัย แสงจันทร์",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 5,
		slaDt: "2016-10-27T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "วันวิภา มาลี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 6,
		slaDt: "2018-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "วันวิภา มาลี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 7,
		slaDt: "2018-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "วันวิภา มาลี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 8,
		slaDt: "2018-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "วันวิภา มาลี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 9,
		slaDt: "2018-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "วันวิภา มาลี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    },{
        ReleatedCliamID : 10,
		slaDt: "2018-10-21T00:23:00",
		IconUrgent: "disable",
        IconVIP: "disable",
        Link : "caseDataEntry.html",
        DateReceived  : "06/12/2559  15:35",
        PolicyNumber : "T12345678",
        CertNumber : "12345679",
        InsuredName : "วันวิภา มาลี",
        ClaimNo : "11111222",
        ClaimStatus : "xxxx",
        LossDate : "06/12/2559",
        LossCode : "12345678",
        InjuryArea : "xxxxxx",
        InHospitalDate : "07/12/2559",
        DischargeDate : "07/12/2559",
        HospitalName : "พญาไท 1",
        Channel : "Fax"
    }
];

$("#CustomerMatching").kendoGrid({
    groupable: false,
    sortable: true,
    selectable : "row",
    pageSize: 10,
    pageable: false,
    dataSource:[{
        ID: 1,
        cName : "สมชาย ใจดี", 
        cDOB : "2 มิ.ย.2519", 
        cGender : "Male", 
        cPolicyNo : "T123456", 
        cCertificationNo : "1235666",
         cNationalID : "3210500712291", 
         cRole : "Insured", 
         Link: "caseDataEntry.html"
     },{
        ID: 2,
        cName : "สมชาย ใจดี", 
        cDOB : "2 มิ.ย.2519", 
        cGender : "Male", 
        cPolicyNo : "T123456", 
        cCertificationNo : "1235666", 
        cNationalID : "3210500712291", 
        cRole : "Insured", 
        Link: "caseDataEntry.html"
    },{
        ID: 3,
        cName : "สมชาย ใจดี", 
        cDOB : "2 มิ.ย.2519", 
        cGender : "Male", 
        cPolicyNo : "T123456", 
        cCertificationNo : "1235666", 
        cNationalID : "3210500712291", 
        cRole : "Insured", 
        Link: "caseDataEntry.html"
    },{
        ID: 4,
        cName : "สมชาย ใจดี", 
        cDOB : "2 มิ.ย.2519", 
        cGender : "Male", 
        cPolicyNo : "T123456", 
        cCertificationNo : "1235666", 
        cNationalID : "3210500712291", 
        cRole : "Insured", 
        Link: "caseDataEntry.html"
    },{
        ID: 5,
        cName : "สมชาย ใจดี", 
        cDOB : "2 มิ.ย.2519", 
        cGender : "Male", 
        cPolicyNo : "T123456", 
        cCertificationNo : "1235666", 
        cNationalID : "3210500712291", 
        cRole : "Insured", 
        Link: "caseDataEntry.html"
    }],
    rowTemplate : kendo.template($("#tableTemplateCustomerMatching").html()),
    columns: [
        {field: "cName", title: "Name"},
        {field: "cDOB", title: "DOB"}, 
        {field: "cGender", title: "Gender"}, 
        {field: "cPolicyNo", title: "Policy No"}, 
        {field: "cCertificationNo", title: "Cert No"}, 
        {field: "cNationalID", title: "National ID"},  
        {field: "cRole",title: "Role"}
    ]
});


