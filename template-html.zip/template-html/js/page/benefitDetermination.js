$(document).ready(function () {
    RenderAuditTrailTable();
    RenderHistryNameTable();
    RenderBenefitTable();
    RenderDocTypeTable();
    RenderPendingManagementTable();
    renderInsertRiderTable();
    renderAmountPercentage();
    renderClaimRulesLogTable1();
    renderClaimRulesLogTable2();
});


//after click audit trail
function RenderAuditTrailTable(){
    $("#AuditTrail").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 10,
            data: [
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 12:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 18:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 09:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 14:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 08:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 12:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 18:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 09:35", Action: " เนื้อหาจำลองแบบเรียบๆ ด้านล่างของหน้านี้คือท่อนมาตรฐาน", DocID: "Z12222"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 14:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"},
                {Timestamp: "06/12/2559 08:35", Action: " เนื้อหาจำลองแบบเรียบๆ เมื่อเครื่องพิมพ์", DocID: "C10300"},
                {Timestamp: "06/12/2559 15:35", Action: " เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์", DocID: "Z12222"}
            ]
        }
        ,
        columns: [
            {field: "Timestamp", title: "Timestamp", width: 150},
            {field: "Action", title: "Action"}, 
            {field: "DocID", title: "DocID", width:120}
        ]
    });
}

//Histry Name
function RenderHistryNameTable(){
    $(".hname-data").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 5,
            data: [
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "John Smith", updateddate : "05/08/2014"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"},
                {historyname : "Knda lemon", updateddate : "03/09/2015"}
            ]
        }
        ,
        columns: [{
            field: "historyname",
            title: "History name"
        }, {
            field: "updateddate",
            title: "Updated date"
        }]
    });
}

//Table for Benefit
function RenderBenefitTable(){
    var BenefitForms = new kendo.data.DataSource({
        pageSize: 10,
        data: dataBenefit,
        autoSync: true,
        schema: {
            model: {
                id: "BenefitID",
                fields: {
                    BenefitID: {editable: false, nullable: true },
                    BenefitProductType: {editable: false},
                    BenefitPlanShortName: {editable: false},
                    BenefitPolicyNo: {editable: false},
                    BenefitExclusion: {editable: false},
                    BenefitImpairmentCode: {editable: false},
                    BenefitEligibility: {editable: false},
                    BenefitClaimsDecision: {editable: true},
                    BenefitDeclineReason: {editable: true},
                    BenefitSumAssured: {editable: false},
                    BenefitPayee: {editable: true},
                    BenefitSystemQuotation: {editable: false},
                    BenefitCoPayment: {type: "number", editable: false},
                    BenefitAdjusted: {editable: true},
                    BenefitAdjustedReason: {editable: true},
                    BenefitSuppressCheque: {editable: false},
                    BenefitTotal: {editable: false}
                }
            }
        }
    });
    var grid= $("#BenefitItem").kendoGrid({
        autobind: true,
        dataSource: BenefitForms,
        pageable: false,
        pageSize: 10,
        columns: [
            {field:"BenefitProductType", title:"Product<br/>type"},
            {field:"BenefitPlanShortName", title:"Plan short<br/>name",template:"<a href='\\#PolicyDetails' data-toggle='modal'>#= BenefitPlanShortName #</a>"},
            {field:"BenefitPolicyNo", title:"Policy<br/>no.", width:100},
            {field:"BenefitExclusion", title:"Exclusion"},
            {field:"BenefitImpairmentCode", title:"Impairment<br/>code"},
            {field:"BenefitEligibility", title:"Eligibility", template:"<a href='\\#PolicyDetails' data-toggle='modal'>#= BenefitPlanShortName #</a>"},
            {field:"BenefitClaimsDecision", title:"Claims<br/>decision", editor: ClaimsDecisionTypeEditor, template: "#=BenefitClaimsDecision.ClaimsDecisionTypeName#"},
            {field:"BenefitDeclineReason", title:"Decline<br/>reason", editor: DeclineReasonTypeEditor, template: "#=BenefitDeclineReason.DeclineReasonTypeName#", width:100},
            {field:"BenefitSumAssured", title:"Sum assured<br/>[THB]"},
            {field:"BenefitPayee", title:"Payee", editor: PayeeTypeEditor, template: "#=BenefitPayee.PayeeTypeName#"},
            {field:"BenefitSystemQuotation", title:"System Quotation<br/>[THB]"},
            {field:"BenefitCoPayment", title:"Co-payment", format: "{0:p0}",},
            {field:"BenefitAdjusted", title:"Adjusted"},
            {field:"BenefitAdjustedReason", title:"Adjusted<br/>Reason", editor: AdjustedReasonTypeEditor, template: "#=BenefitAdjustedReason.AdjustedReasonTypeName#"},
            {field:"BenefitSuppressCheque", title:"Suppress<br/>Cheque", template: "<input type='checkbox' class=''/>"},
            {field:"BenefitTotal", title:"Total<br/>[THB]", footerTemplate: "3000"}
        ],
        editable: {createAt : "bottom"},
        navigatable: true
    }).data("kendoGrid");
}

var ClaimsDecisionTypeData = new kendo.data.DataSource({
    data: [
        { ClaimsDecisionTypeName: "Eligible", ClaimsDecisionTypeId: "1" },
        { ClaimsDecisionTypeName: "Pending", ClaimsDecisionTypeId: "2" },
        { ClaimsDecisionTypeName: "Decline", ClaimsDecisionTypeId: "3" }
    ]
});

function ClaimsDecisionTypeEditor(container, options) {
    $('<input name="ClaimsDecisionTypeDisplay" class="cmic-edit" data-text-field="ClaimsDecisionTypeName" data-value-field="ClaimsDecisionTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "BenefitClaimsDecision",
            dataValueField: "ClaimsDecisionTypeName",
            dataSource: ClaimsDecisionTypeData
        });
}

var DeclineReasonTypeData = new kendo.data.DataSource({
    data: [
        {DeclineReasonTypeName: "Reason 1", DeclineReasonTypeId: "1" },
        {DeclineReasonTypeName: "Reason 2", DeclineReasonTypeId: "2" },
        {DeclineReasonTypeName: "Reason 3", DeclineReasonTypeId: "3" }
    ]
});

function DeclineReasonTypeEditor(container, options) {
    $('<input name="DeclineReasonTypeDisplay" class="cmic-edit" data-text-field="DeclineReasonTypeName" data-value-field="DeclineReasonTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "BenefitDeclineReason",
            dataValueField: "DeclineReasonTypeName",
            dataSource: DeclineReasonTypeData
        });
}

var PayeeTypeData = new kendo.data.DataSource({
    data: [
        {PayeeTypeName: "Insured", PayeeTypeId: "1" },
        {PayeeTypeName: "Company", PayeeTypeId: "2" },
        {PayeeTypeName: "Provider", PayeeTypeId: "3" }
    ]
});

function PayeeTypeEditor(container, options) {
    $('<input name="PayeeTypeDisplay" class="cmic-edit" data-text-field="PayeeTypeName" data-value-field="PayeeTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "BenefitPayee",
            dataValueField: "PayeeTypeName",
            dataSource: PayeeTypeData
        });
}

var AdjustedReasonTypeData = new kendo.data.DataSource({
    data: [
        {AdjustedReasonTypeName: "Adjusted1", AdjustedReasonTypeId: "1" },
        {AdjustedReasonTypeName: "Adjusted2", AdjustedReasonTypeId: "2" },
        {AdjustedReasonTypeName: "Adjusted3", AdjustedReasonTypeId: "3" }
    ]
});

function AdjustedReasonTypeEditor(container, options) {
    $('<input name="AdjustedReasonTypeDisplay" class="cmic-edit" data-text-field="AdjustedReasonTypeName" data-value-field="AdjustedReasonTypeId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "BenefitAdjustedReason",
            dataValueField: "AdjustedReasonTypeName",
            dataSource: AdjustedReasonTypeData
        });
}
//Content for Benefit table
var dataBenefit = [
    {
        BenefitID:1,
        BenefitProductType : "HS",
        BenefitPlanShortName: "HSN5",
        BenefitPolicyNo: "T54987",
        BenefitExclusion: "Y",
        BenefitImpairmentCode: "N",
        BenefitEligibility: "Eligible",
        BenefitClaimsDecision : {
            ClaimsDecisionTypeId : 1,
            ClaimsDecisionTypeName : "Eligible"
        },
        BenefitDeclineReason : {
            DeclineReasonTypeId : 1,
            DeclineReasonTypeName : "Reason 1"
        },
        BenefitSumAssured : "1000", 
        BenefitPayee : {
            PayeeTypeId : 1,
            PayeeTypeName : "Insured"
        },
        BenefitSystemQuotation: "500",
        BenefitCoPayment: "0.2",
        BenefitAdjusted: "200",
        BenefitAdjustedReason : {
            AdjustedReasonTypeId : 1,
            AdjustedReasonTypeName : "Adjusted1"
        },
        BenefitTotal: "1500"
    },{
        BenefitID:2,
        BenefitProductType : "HS",
        BenefitPlanShortName: "HSN5",
        BenefitPolicyNo: "T54987",
        BenefitExclusion: "Y",
        BenefitImpairmentCode: "N",
        BenefitEligibility: "Eligible",

        BenefitClaimsDecision : {
            ClaimsDecisionTypeId : 2,
            ClaimsDecisionTypeName : "Pending"
        },
        BenefitDeclineReason : {
            DeclineReasonTypeId : 2,
            DeclineReasonTypeName : "Reason 2"
        },
        BenefitSumAssured : "1000", 
        BenefitPayee : {
            PayeeTypeId : 2,
            PayeeTypeName : "Company"
        },
        BenefitSystemQuotation: "500",
        BenefitCoPayment: "0.3",
        BenefitAdjusted: "200",
        BenefitAdjustedReason : {
            AdjustedReasonTypeId : 2,
            AdjustedReasonTypeName : "Adjusted2"
        },
        BenefitTotal: "1500"
    },{
        BenefitID:3,
        BenefitProductType : "HS",
        BenefitPlanShortName: "HSN5",
        BenefitPolicyNo: "T54987",
        BenefitExclusion: "Y",
        BenefitImpairmentCode: "N",
        BenefitEligibility: "Eligible",

        BenefitClaimsDecision : {
            ClaimsDecisionTypeId : 3,
            ClaimsDecisionTypeName : "Decline"
        },
        BenefitDeclineReason : {
            DeclineReasonTypeId : 3,
            DeclineReasonTypeName : "Reason 3"
        },
        BenefitSumAssured : "1000", 
        BenefitPayee : {
            PayeeTypeId : 3,
            PayeeTypeName : "Provider"
        },
        BenefitSystemQuotation: "500",
        BenefitCoPayment: "0.3",
        BenefitAdjusted: "200",
        BenefitAdjustedReason : {
            AdjustedReasonTypeId : 3,
            AdjustedReasonTypeName : "Adjusted3"
        },
        BenefitTotal: "1500"
    },{
        BenefitID:4,
        BenefitProductType : "HB",
        BenefitPlanShortName: "HSN7",
        BenefitPolicyNo: "T54987",
        BenefitExclusion: "Y",
        BenefitImpairmentCode: "N",
        BenefitEligibility: "Eligible",

        BenefitClaimsDecision : {
            ClaimsDecisionTypeId : 1,
            ClaimsDecisionTypeName : "Eligible"
        },
        BenefitDeclineReason : {
            DeclineReasonTypeId : 1,
            DeclineReasonTypeName : "Reason 1"
        },
        BenefitSumAssured : "1000", 
        BenefitPayee : {
            PayeeTypeId : 1,
            PayeeTypeName : "Insured"
        },
        BenefitSystemQuotation: "500",
        BenefitCoPayment: "0.2",
        BenefitAdjusted: "200",
        BenefitAdjustedReason : {
            AdjustedReasonTypeId : 1,
            AdjustedReasonTypeName : "Adjusted1"
        },
        BenefitTotal: "1500"
    },{
        BenefitID:5,
        BenefitProductType : "HB",
        BenefitPlanShortName: "HSN9",
        BenefitPolicyNo: "POL7896",
        BenefitExclusion: "Y",
        BenefitImpairmentCode: "N",
        BenefitEligibility: "Eligible",

        BenefitClaimsDecision : {
            ClaimsDecisionTypeId : 2,
            ClaimsDecisionTypeName : "Pending"
        },
        BenefitDeclineReason : {
            DeclineReasonTypeId : 2,
            DeclineReasonTypeName : "Reason 2"
        },
        BenefitSumAssured : "1000", 
        BenefitPayee : {
            PayeeTypeId : 2,
            PayeeTypeName : "Company"
        },
        BenefitSystemQuotation: "500",
        BenefitCoPayment: "0.3",
        BenefitAdjusted: "200",
        BenefitAdjustedReason : {
            AdjustedReasonTypeId : 2,
            AdjustedReasonTypeName : "Adjusted2"
        },
        BenefitTotal: "1500"
    },{
        BenefitID:6,
        BenefitProductType : "HB",
        BenefitPlanShortName: "HSN10",
        BenefitPolicyNo: "POL5555",
        BenefitExclusion: "Y",
        BenefitImpairmentCode: "N",
        BenefitEligibility: "Eligible",

        BenefitClaimsDecision : {
            ClaimsDecisionTypeId : 3,
            ClaimsDecisionTypeName : "Decline"
        },
        BenefitDeclineReason : {
            DeclineReasonTypeId : 3,
            DeclineReasonTypeName : "Reason 3"
        },
        BenefitSumAssured : "1000", 
        BenefitPayee : {
            PayeeTypeId : 3,
            PayeeTypeName : "Provider"
        },
        BenefitSystemQuotation: "500",
        BenefitCoPayment: "0.3",
        BenefitAdjusted: "200",
        BenefitAdjustedReason : {
            AdjustedReasonTypeId : 3,
            AdjustedReasonTypeName : "Adjusted3"
        },
        BenefitTotal: "1500"
    }
];

//Document Type
function RenderDocTypeTable(){
    var DocTypeForm = new kendo.data.DataSource({
        pageSize: 20,
        data: dataDocType,
        autoSync: true,
        schema: {
            model: {
                id: "DocTypeId",
                fields: {
                    DocTypeId: { editable: false, nullable: true },
                    DocTypeItems:{ defaultValue: { DocTypeItemsName: "Claims form", DocTypeItemsId: "1" } }
                }
            }
        }
    });
    $("#DocumentTypeGrid").kendoGrid({
        autobind: false,
        dataSource: DocTypeForm,
        scrollable: false,
        sortable: false,
        toolbar: [
            {template: kendo.template($("#DocTypeToolbar").html())}
        ],
        columns: [
            {
                field: "DocTypeItems", 
                title: "Document Type", 
                editor: DocTypeDropDownEditor, 
                template: "#=DocTypeItems.DocTypeItemsName#"
            },{
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
        ],
        editable: {createAt : "top"},
        navigatable: true,
        pageable: {buttonCount: 5,pageSizes: false}
    });
}

var DocTypeData = new kendo.data.DataSource({
    data: [
        { DocTypeItemsName: "Claims form", DocTypeItemsId: "1" },
        { DocTypeItemsName: "ID Card", DocTypeItemsId: "2" }
    ]
});

function DocTypeDropDownEditor(container, options) {
    $('<input name="DocTypeDisplay" class="cmic-edit" required data-text-field="DocTypeItemsName" data-value-field="DocTypeItemsId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "DocTypeItemsName",
            dataValueField: "DocTypeItems",
            dataSource: DocTypeData
        });
}

var dataDocType = [
    {
        DocTypeId:1, 
        DocTypeItems : {DocTypeItemsId : 1, DocTypeItemsName : "Claims form"}
    },{
        DocTypeId:2, 
        DocTypeItems : {DocTypeItemsId : 2, DocTypeItemsName : "ID Card"}
    },{
        DocTypeId:1, 
        DocTypeItems : {DocTypeItemsId : 1, DocTypeItemsName : "Claims form"}
    },{
        DocTypeId:2, 
        DocTypeItems : {DocTypeItemsId : 2, DocTypeItemsName : "ID Card"}
    },{
        DocTypeId:1, 
        DocTypeItems : {DocTypeItemsId : 1, DocTypeItemsName : "Claims form"}
    },{
        DocTypeId:2, 
        DocTypeItems : {DocTypeItemsId : 2, DocTypeItemsName : "ID Card"}
    }
];


//Pending Management
function RenderPendingManagementTable(){
    var PendMangeForm = new kendo.data.DataSource({
        pageSize: 20,
        data: dataPendMange,
        autoSync: true,
        schema: {
            model: {
                id: "PendMangeId",
                fields: {
                    PendMangeId: { editable: false, nullable: true },
                    PendMangeStatus:{ editable: true, defaultValue: { PendMangeStatusName: "Outstanding", PendMangeStatusId: "1" }},
                    PendingRequirement: {editable: false},
                    CreatedDate: {editable: false},
                    CreatedUser: {editable: false},
                    ResolvedDate: {editable: false},
                    ResolvedUser: {editable: false}
                }
            }
        }
    });
    $("#PendingManagementGrid").kendoGrid({
        autobind: false,
        dataSource: PendMangeForm,
        scrollable: false,
        sortable: true,
        columns: [
            {
                field: "PendMangeStatus", 
                title: "Status", 
                editor: PendMangeDropDownEditor, 
                template: "#=PendMangeStatus.PendMangeStatusName#",
                width:100
            },
            {field: "PendingRequirement", title: "Pending<br/>Requirement", width:250},
            {field: "CreatedDate", title: "Created<br/>Date", width:100},
            {field: "CreatedUser", title: "Created<br/>User", width:100},
            {field: "ResolvedDate", title: "Resolved<br/>Date", width:100},
            {field: "ResolvedUser", title: "Resolved<br/>User", width:100}
        ],
        editable: {createAt : "top"},
        navigatable: true,
        pageable: {buttonCount: 5,pageSizes: false}
    });
}

var PendMangeData = new kendo.data.DataSource({
    data: [
        { PendMangeStatusName: "Outstanding", PendMangeStatusId: "1" },
        { PendMangeStatusName: "Resolved", PendMangeStatusId: "2" },
        { PendMangeStatusName: "Cancel", PendMangeStatusId: "3" }
    ]
});

function PendMangeDropDownEditor(container, options) {
    $('<input name="PendMangeStatusDisplay" class="cmic-edit" required data-text-field="PendMangeStatusName" data-value-field="PendMangeStatusId" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "PendMangeStatusName",
            dataValueField: "PendMangeStatus",
            dataSource: PendMangeData
        });
}

var dataPendMange = [
    {
        PendMangeId: 1, 
        PendMangeStatus : {PendMangeStatusId : 1, PendMangeStatusName : "Outstanding"},
        PendingRequirement: "EA001-Request claims form",
        CreatedDate: "06/12/2559",
        CreatedUser: "mclm022",
        ResolvedDate: "06/15/2559",
        ResolvedUser: "mclm022"
    },{
        PendMangeId: 2, 
        PendMangeStatus : {PendMangeStatusId : 2, PendMangeStatusName : "Resolved"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "05/12/2559",
        CreatedUser: "mclm021",
        ResolvedDate: "05/15/2559",
        ResolvedUser: "mclm021"
    },{
        PendMangeId: 3, 
        PendMangeStatus : {PendMangeStatusId : 3, PendMangeStatusName : "Cancel"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "04/12/2559",
        CreatedUser: "mclm023",
        ResolvedDate: "04/15/2559",
        ResolvedUser: "mclm023"
    },{
        PendMangeId: 4, 
        PendMangeStatus : {PendMangeStatusId : 1, PendMangeStatusName : "Outstanding"},
        PendingRequirement: "EA001-Request claims form",
        CreatedDate: "06/12/2559",
        CreatedUser: "mclm022",
        ResolvedDate: "06/15/2559",
        ResolvedUser: "mclm022"
    },{
        PendMangeId: 5, 
        PendMangeStatus : {PendMangeStatusId : 2, PendMangeStatusName : "Resolved"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "05/12/2559",
        CreatedUser: "mclm021",
        ResolvedDate: "05/15/2559",
        ResolvedUser: "mclm021"
    },{
        PendMangeId: 6, 
        PendMangeStatus : {PendMangeStatusId : 3, PendMangeStatusName : "Cancel"},
        PendingRequirement: "HC Doctor comment Form, Part 2",
        CreatedDate: "04/12/2559",
        CreatedUser: "mclm023",
        ResolvedDate: "04/15/2559",
        ResolvedUser: "mclm023"
    }
];

//Insert Rider
function renderInsertRiderTable(){
    var InsertRiderForm = new kendo.data.DataSource({
        pageSize: 20,
        data: dataInsertRider,
        autoSync: true,
        schema: {
            model: {
                id: "insertRiderID",
                fields: {
                    insertRiderID: { editable: false, nullable: true },
                    policyNumber :{ defaultValue: { policyNumberTypeName: "Value 1", policyNumberTypeID: "1" } },
                    planName :{ defaultValue: { planNameTypeName: "Value 1", planNameTypeID: "1" } }
                }
            }
        }
    });

    $("#insertRiderGrid").kendoGrid({
        autobind: true,
        dataSource: InsertRiderForm,
        scrollable: true,
        sortable: true,
        toolbar: [
            {template: kendo.template($("#insertRiderToolbar").html())}
        ],
        columns: [
            {
                field: "policyNumber", 
                title: "Policy Number", 
                editor: policyNumberEditor, 
                template: "#=policyNumber.policyNumberTypeName#",
                width:200
            },{
                field: "planName", 
                title: "Plan Name", 
                editor: planNameEditor, 
                template: "#=planName.planNameTypeName#",
                width:200
            },{
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
        ],
        editable: {createAt : "top"},
        navigatable: true,
        pageable: {buttonCount: 5,pageSizes: true}
    });
}

var policyNumberData = new kendo.data.DataSource({
    data: [
        { policyNumberTypeName: "Value 1", policyNumberTypeID: "1" },
        { policyNumberTypeName: "Value 2", policyNumberTypeID: "2" }
    ]
});

function policyNumberEditor(container, options) {
    $('<input name="policyNumberDisplay" class="cmic-edit" required data-text-field="policyNumberTypeName" data-value-field="policyNumberTypeID" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "policyNumberTypeName",
            dataValueField: "policyNumber",
            dataSource: policyNumberData
        });
}

var planNameData = new kendo.data.DataSource({
    data: [
        { planNameTypeName: "Value 1", planNameTypeID: "1" },
        { planNameTypeName: "Value 2", planNameTypeID: "2" }
    ]
});

function planNameEditor(container, options) {
    $('<input name="planNameDisplay" class="cmic-edit" required data-text-field="planNameTypeName" data-value-field="planNameTypeID" data-bind="value:' + options.field + '"/>')
        .appendTo(container)
        .kendoComboBox({
            autoBind: true,
            filter: "contains",
            dataTextField: "planNameTypeName",
            dataValueField: "planName",
            dataSource: planNameData
        });
}

//Content for Billing Item
var dataInsertRider = [
    {
        insertRiderID:1, 
        policyNumber : {policyNumberTypeID : 1, policyNumberTypeName : "Value 1"},
        planName : {planNameTypeID : 1, planNameTypeName : "Value 1"}
    },{
        insertRiderID:1, 
        policyNumber : {policyNumberTypeID : 2, policyNumberTypeName : "Value 2"},
        planName : {planNameTypeID : 2, planNameTypeName : "Value 2"}
    },{
        insertRiderID:1, 
        policyNumber : {policyNumberTypeID : 1, policyNumberTypeName : "Value 1"},
        planName : {planNameTypeID : 1, planNameTypeName : "Value 1"}
    },{
        insertRiderID:1, 
        policyNumber : {policyNumberTypeID : 2, policyNumberTypeName : "Value 2"},
        planName : {planNameTypeID : 2, planNameTypeName : "Value 2"}
    },{
        insertRiderID:1, 
        policyNumber : {policyNumberTypeID : 1, policyNumberTypeName : "Value 1"},
        planName : {planNameTypeID : 1, planNameTypeName : "Value 1"}
    },{
        insertRiderID:1, 
        policyNumber : {policyNumberTypeID : 2, policyNumberTypeName : "Value 2"},
        planName : {planNameTypeID : 2, planNameTypeName : "Value 2"}
    }
];

function renderAmountPercentage(){

var price = (".amountnumber");

// Remove non-numeric chars (except decimal point/minus sign):
priceVal = parseFloat(price.replace(/[^0-9-.]/g, '')); // 12345.99

}



// To set it up as a global function:
function formatMoney(number, places, symbol, thousand, decimal) {
    number = number || 0;
    places = !isNaN(places = Math.abs(places)) ? places : 2;
    symbol = symbol !== undefined ? symbol : "$";
    thousand = thousand || ",";
    decimal = decimal || ".";
    var negative = number < 0 ? "-" : "",
        i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
        j = (j = i.length) > 3 ? j % 3 : 0;
    return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");
}

//claim Rule Log Table 1
function renderClaimRulesLogTable1(){
    $(".claimRulesLogTable1").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 10,
            data: [
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"}
            ]
        }
        ,
        columns: [{
            field: "ClaimRulesPolicy",
            title: "Policy Number",
            width:"15%"
        },{
            field: "ClaimRulesCode",
            title: "Code",
            width:"10%"
        },{
            field: "ClaimRulesDesc",
            title: "Description",
            width:"75%"
        }]
    });
}

//claim Rule Log Table 1
function renderClaimRulesLogTable2(){
    $(".claimRulesLogTable2").kendoGrid({
        groupable: false,
        sortable: true,
        pageSize: 10,
        pageable: {
            refresh: false,
            pageSizes: true,
            buttonCount: 2
        },
        dataSource:{
            pageSize: 10,
            data: [
                {ClaimRulesPolicy : " ", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : " ", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : " ", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : " ", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"},
                {ClaimRulesPolicy : "T123456789", ClaimRulesCode: "R001", ClaimRulesDesc : "Default business rule decision - Insured Absolute Assign Indicator"}
            ]
        }
        ,
        columns: [{
            field: "ClaimRulesPolicy",
            title: "Policy Number",
            width:"15%"
        },{
            field: "ClaimRulesCode",
            title: "Code",
            width:"10%"
        },{
            field: "ClaimRulesDesc",
            title: "Description",
            width:"75%"
        }]
    });
} 