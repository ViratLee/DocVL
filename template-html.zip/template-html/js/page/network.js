$(document).ready(function() {
    renderNetworkTable();
    NetworkSpecificProductEditor();
    BusinessLineEditor();
    NetworkTypeEditor();
});


function renderNetworkTable(){
    var NetworkForm = new kendo.data.DataSource({
        pageSize: 20,
        data: dataNetworkList,
        schema: {
            model: {
                id: "NetId",
                fields: {
                    NetId: { editable: false, nullable: true },
                    networkName: { type: "string", editable: false},
                    terminateDate: { type: "date", editable: false},
                    networkId: { 
                        editable: false,
                        defaultValue: "12345678"
                     },
                    BusinessLineItems: { 
                        editable: false,
                        defaultValue: { BusinessLineValue: "Corporate Solution", BusinessLineID: "1" },
                        validation: { required: true} 
                    },
                    specialProduct: { type: "string", editable: false, validation: { required: true} },
                    NetworkTypeItems: {
                        editable: false,
                        defaultValue: { NetworkTypeName: "Hospital", NetworkTypeID: "1" },
                        validation: { required: true}
                    }
                   
                }
            }
        }
    });

    $("#NetworkList").kendoGrid({
        //autobind: true,
        dataSource: NetworkForm,
        scrollable: true,
        sortable: true,
        pageable: {
            buttonCount: 5,
            pageSizes: true
        },
        toolbar: [
            {template: kendo.template($("#NetworkToolbar").html())}
        ],
        columns: [
            {
                field: "networkName", 
                title: "Network<br/>name",
                width: 200
            },{
                field:"terminateDate", 
                title:"Termination date<br/>of Network", 
                format:"{0:MM-dd-yyyy}", 
                editor: dateTimeEditor,
                width: 150
            },{
                field: "networkId",
                title: "Network<br/>ID",
                template: "<a href='\\#AddNewNetwork' class='btn-link k-grid-edit' data-toggle='modal'> #= networkId # </a>",
                width: 120
            },{
                field: "BusinessLineItems",
                title: "Business<br/>Line",
                template: "<ul><li>#=BusinessLineItems.BusinessLineValue#</li></ul>",
                width: 200
            },{
                field: "specialProduct",
                title: "Network Specific<br/>Product",
                width: 200
            },{
                field: "NetworkTypeItems",
                title: "Network<br/>Type",
                editor: NetworkTypeEditor,
                template: "<ul><li>#=NetworkTypeItems.NetworkTypeName#</li></ul>",
                width: 120
            },{
                command: [
                    { 
                        name: "destroy", 
                        text: " ", 
                        template: "<a class='k-button k-grid-delete btn btn-blue removed'><span class='glyphicon glyphicon-trash'></span></a>" 
                    }
                ],
                title: " ",
                width: "70px"
            }
        ],
        editable: true,
        navigatable: true
        
        });
}
function dateTimeEditor(container, options) {
    $('<input data-text-field="' + options.field + '" data-value-field="' + options.field + '" data-bind="value:' + options.field + '" data-format="' + options.format + '"/>')
            .appendTo(container)
            .kendoDatePicker({});
}

function NetworkSpecificProductEditor(){
    var NSPcnt = 3;
    var NetworkSpecificProductData = new kendo.data.DataSource({
        data: [
            {NetworkSpecificProductID: 1, NetworkSpecificProductValue: "Some text 1"}, 
            {NetworkSpecificProductID: 2, NetworkSpecificProductValue: "Some text 2"}
        ]
    });

    $(function() {
        $("#ListviewNetworkSpecificProduct").kendoListView({
            template: kendo.template($("#NetworkSpecificProductTemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < NSPcnt; i++) {
                if($("#nspcol"+i) != undefined) {$("#nspcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "NetworkSpecificProductValue", 
                        dataValueField: "NetworkSpecificProductID", 
                        dataSource: {
                            data:NetworkSpecificProductData
                        },
                        index:0
                    });
                }
            }
            },
            dataSource: {
                data: datansp
            }
        });
        $("#AddNSP").kendoButton({click: function(e) {$("#ListviewNetworkSpecificProduct").data("kendoListView").dataSource.add({id: NSPcnt++});}
        });
    });

    var datansp = [
        {
            id:1
        },{
            id:2
        }
    ];

}

function  BusinessLineEditor(){
    var BLcnt = 3;
    var BusinessLineData = [
        {BusinessLineID: "1", BusinessLineValue: "Corporate Solution"}, 
        {BusinessLineID: "2", BusinessLineValue: "Care card"}
    ];

    $(function() {
        $("#ListviewBusinessLine").kendoListView({
            template: kendo.template($("#BusinessLinleTemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < BLcnt; i++) {
                if($("#blcol"+i) != undefined) {$("#blcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "BusinessLineValue", 
                        dataValueField: "BusinessLineID", 
                        dataSource: BusinessLineData, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: dataofbl}
        });
        $("#AddBL").kendoButton({click: function(e) {$("#ListviewBusinessLine").data("kendoListView").dataSource.add({id: BLcnt++});}
        });
    });
    var dataofbl = [{id:1},{id:2}];
}

function  NetworkTypeEditor(){
    var NTcnt = 3;
    var NetworkTypeData = [
        {NetworkTypeID: "1", NetworkTypeValue: "Hospital"}, 
        {NetworkTypeID: "2", NetworkTypeValue: "Practitioners"},
        {NetworkTypeID: "3", NetworkTypeValue: "Facilities"}
    ];

    $(function() {
        $("#ListviewNetworkType").kendoListView({
            template: kendo.template($("#NetworkTypeTemplate").html()),
            dataBound: function(e) {
            for (i = 1; i < NTcnt; i++) {
                if($("#ntcol"+i) != undefined) {$("#ntcol"+ i).kendoComboBox({
                        filter: "contains",
                        autoBind: true,
                        dataTextField: "NetworkTypeValue", 
                        dataValueField: "NetworkTypeID", 
                        dataSource: NetworkTypeData, 
                        index: 0
                    });
                }
            }
            },
            dataSource: {data: dataofnt}
        });
        $("#AddNT").kendoButton({click: function(e) {$("#ListviewNetworkType").data("kendoListView").dataSource.add({id: NTcnt++});}
        });
    });
    var dataofnt = [{id:1},{id:2}];
}

var dataNetworkList = [
    {
        NetId: 1,
        networkName : "Network name A",
        terminateDate : "10/09/2016",
        networkId : "123456",
        BusinessLineItems : {
            BusinessLineID : 2,
            BusinessLineValue : "Care card"
        },
        specialProduct : "Product A",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 2,
        networkName : "Network name B",
        terminateDate : "10/09/2016",
        networkId : "987654",
        BusinessLineItems : {
            BusinessLineID : 2,
            BusinessLineValue : "Care card"
        },
        specialProduct : "Product B",
        NetworkTypeItems : {
            NetworkTypeID : 2,
            BusinessLineValue : "Practitioners"
        }
    },{
        NetId: 3,
        networkName : "Network name C",
        terminateDate : "10/09/2016",
        networkId : "123456",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product C",
        NetworkTypeItems : {
            NetworkTypeID : 3,
            NetworkTypeName : "Facilities"
        }
    },{
        NetId: 4,
        networkName : "Network name D",
        terminateDate : "10/09/2016",
        networkId : "987654",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product D",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 5,
        networkName : "Network name A",
        terminateDate : "10/09/2016",
        networkId : "123456",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product A",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 6,
        networkName : "Network name B",
        terminateDate : "10/09/2016",
        networkId : "987654",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product B",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 7,
        networkName : "Network name C",
        terminateDate : "10/09/2016",
        networkId : "123456",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product C",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 8,
        networkName : "Network name D",
        terminateDate : "10/09/2016",
        networkId : "987654",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product D",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 9,
        networkName : "Network name A",
        terminateDate : "10/09/2016",
        networkId : "123456",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product A",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 10,
        networkName : "Network name B",
        terminateDate : "10/09/2016",
        networkId : "987654",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product B",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 11,
        networkName : "Network name C",
        terminateDate : "10/09/2016",
        networkId : "123456",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product C",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    },{
        NetId: 12,
        networkName : "Network name D",
        terminateDate : "10/09/2016",
        networkId : "987654",
        BusinessLineItems : {
            BusinessLineID : 1,
            BusinessLineValue : "Corporate Solution"
        },
        specialProduct : "Product D",
        NetworkTypeItems : {
            NetworkTypeID : 1,
            NetworkTypeName : "Hospital"
        }
    }
];  