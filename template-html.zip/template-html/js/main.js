$(document).ready(function() {
  //kendo memu
   $("#mainmenu").kendoMenu({
      dataSource:
      [
        {
          text: "Home",
          imageUrl: "image/dashboard-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Work Queue Monitor",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Team work",
          imageUrl: "image/search-2ndg.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Outstanding work",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Contract approval",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Provider",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Doctor",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Network",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Contract",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Return reciept",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Billing",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        },{
          text: "Claims inquiry",
          imageUrl: "image/myclaims-menu.png",
          cssClass: "active",
          url: "#"
        }
       ],
       orientation: 'vertical'
    })

   //Data Entry

    $('.scrollup').click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    // Click nav list
    function goToByScroll(id){
        id = id.replace("link", "");
        $('html,body').animate({
            scrollTop: $("#"+id).offset().top - 140 },'slow');
    }

    $(".section-hover").hover(            
      function() {
          $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
          $(this).toggleClass('open');              
      },
      function() {
          $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
          $(this).toggleClass('open');               
      });

    $(".navlist > ul > li > a").click(function(e) { 
        e.preventDefault(); 
        goToByScroll($(this).attr("id"));           
    });


    $('.dropdown-menu ul li label input, .dropdown-menu ul li label, .dropdown-menu ul li a').click(function(e) {
        e.stopPropagation();
    });

    //Date and Time
    $(".cmic-datetimepicker").kendoDateTimePicker({
       value:new Date()
    });

    //Just date
    // Fix all date pattern
	var cmicDatePicker = $(".cmic-datepicker").kendoDatePicker({
		format: "MM/dd/yyyy",
		rules: {
			date: function (input) {
				var d = kendo.parseDate(input.val(), "MM/dd/yyyy");
				return d instanceof Date;
			}
		}
	});
	cmicDatePicker.kendoMaskedTextBox({
	  mask: "00/00/0000"
	});


    //Just Time
    $(".cmic-timepicker").kendoTimePicker({
       value:new Date()
    });

    //intput(text+select)
    $(".cmic-combobox").kendoComboBox({
        filter: "contains",
        autoBind: false,
        minLength: 3              
    });

    //intput(kendoDropDownList)
    $(".cmic-select").kendoDropDownList({
		optionLabel: " ",
		valuePrimitive: true,
        autoBind: false,
        minLength: 3              
    });

    //MASKEDTEXTBOX
    $(".phone-number").kendoMaskedTextBox({
      mask: "00 000 0000"
    });

    $(".mobile-number").kendoMaskedTextBox({
      mask: "00 000 0000"
    });

    $(".national-id-card").kendoMaskedTextBox({
      mask: "0 0000 00000 00 0"
    });

    //kendo Upload
     $("#files").kendoUpload({
        async: {
            saveUrl: "save",
            removeUrl: "remove",
            autoUpload: true,
            allowmultiple: true
        },
        localization: {
            select: "Upload Document"
        }
    });

    $(".initialamount").kendoNumericTextBox({
        format: 'n2'
    });

    $(".initialnumber").kendoNumericTextBox({
        format: 'n0',
        min: 0
    });

    $(".initialweight").kendoNumericTextBox({
        format: "#.00 kg",
        min: 0
    });

    $(".initialheight").kendoNumericTextBox({
        format: "#.00 cm",
        min: 0
    });

});